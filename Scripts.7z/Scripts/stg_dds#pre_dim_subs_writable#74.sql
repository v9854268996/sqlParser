-- rev. 31320 20.06.2019

  INSERT INTO edw_stg_dds.t_000074_pre_dim_subs_writable
  (
    subs_key,
    account_key,
    service_key,
    duty_num_key,
    center_num_key,
    address_key,
    cpe_key,
    port_key,
    subs_code,
    subs_activation_dt,
    subs_cancellation_dt,
    start_date,
    end_date,
    service_id,
    serv_first_id,
    rc_key,
    start_id,
    src_id,
    eff_dttm,
    exp_dttm
  )
  SELECT
    subs_key,
    account_key,
    service_key,
    duty_num_key,
    center_num_key,
    address_key,
    cpe_key,
    port_key,
    subs_code,
    subs_activation_dt,
    subs_cancellation_dt,
    start_date,
    end_date,
    service_id,
    serv_first_id,
    rc_key,
    000058::smallint,
    000074::smallint,
    eff_dttm,
    exp_dttm
  FROM edw_stg_dds.t_000058_dim_subs s;