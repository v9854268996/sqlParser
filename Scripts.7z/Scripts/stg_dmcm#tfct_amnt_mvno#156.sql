/*rev. 32572 от 05.07.2019*/
truncate table edw_stg_dmcm.tfct_amnt_mvno_1_prt_p000156;

insert into edw_stg_dmcm.tfct_amnt_mvno_1_prt_p000156
  ( mrf_id_mvno          ,
    mrf_name_mvno        ,
    rf_id_mvno           ,
    rf_name_mvno         ,
    accn_id_mvno         ,
    accn_id              ,
    subs_id              ,
    goodok_clc           ,
    mms_clc              ,
    sms_clc              ,
    gprs_clc             ,
    gprs_clc_move        ,
    gprs_clc_use         ,
    gprs_clc_roum        ,
    in_mob_clc           ,
    in_mob_rtc_clc       ,
    in_fix_clc           ,
    in_fix_rtc_clc       ,
    in_other_clc         ,
    outcity_clc          ,
    outcntry_clc         ,
    out_mob_clc          ,
    out_mob_rtc_clc      ,
    out_fix_clc          ,
    out_fix_rtc_clc      ,
    out_rouming_clc      ,
    outcntry_rouming_clc ,
    outcity_rouming_clc  ,
    outvsr_rouming_clc   ,
    out_other_clc        ,
    outcity_rtc_clc      ,
    outcity_other_clc    ,
    outcntry_euro_clc    ,
    outcntry_other_clc   ,
    outcntry_sng_clc     ,
    outcntry_usa_clc     ,
    content_sms_clc      ,
    redirect_clc         ,
    ptp_transfer_clc     ,
    anti_aon_clc         ,
    account_clc          ,
    multy_call_clc       ,
    tp_change_clc        ,
    sms_insd_clc         ,
    sms_outctry_clc      ,
    sms_outvsr_clc       ,
    sms_outcity_clc      ,
    sms_recl_clc         ,
    sms_other_clc        ,
    abon_tp_clc          ,
    unclassified         ,
    abon_clc             ,
    all_clc              ,
    ao_abon_clc          ,
    total_in             ,
    total_out            ,
    total_in_unroum      ,
    total_out_unroum     ,
    eff_dttm             ,
    exp_dttm             ,
    load_dttm            ,
    src_id
  )
with miswh as
  (
    select *
    from
      (
        select
          period                                                    as period               ,
          accn_id_mvno                                              as accn_id_mvno         ,
          mrf_id                                                    as mrf_id_mvno          ,
          mrf_name                                                  as mrf_name_mvno        ,
          rf_id                                                     as rf_id_mvno           ,
          rf_name                                                   as rf_name_mvno         ,
          id_subs::varchar                                              as id_subs              ,
          goodok_clc           as goodok_clc           ,
          mms_clc              as mms_clc              ,
          sms_clc              as sms_clc              ,
          gprs_clc             as gprs_clc             ,
          gprs_clc_move        as gprs_clc_move        ,
          gprs_clc_use         as gprs_clc_use         ,
          gprs_clc_roum        as gprs_clc_roum        ,
          in_mob_clc           as in_mob_clc           ,
          in_mob_rtc_clc       as in_mob_rtc_clc       ,
          in_fix_clc           as in_fix_clc           ,
          in_fix_rtc_clc       as in_fix_rtc_clc       ,
          in_other_clc         as in_other_clc         ,
          outcity_clc          as outcity_clc          ,
          outcntry_clc         as outcntry_clc         ,
          out_mob_clc          as out_mob_clc          ,
          out_mob_rtc_clc      as out_mob_rtc_clc      ,
          out_fix_clc          as out_fix_clc          ,
          out_fix_rtc_clc      as out_fix_rtc_clc      ,
          out_rouming_clc      as out_rouming_clc      ,
          outcntry_rouming_clc as outcntry_rouming_clc ,
          outcity_rouming_clc  as outcity_rouming_clc  ,
          outvsr_rouming_clc   as outvsr_rouming_clc   ,
          out_other_clc        as out_other_clc        ,
          outcity_rtc_clc      as outcity_rtc_clc      ,
          outcity_other_clc    as outcity_other_clc    ,
          outcntry_euro_clc    as outcntry_euro_clc    ,
          outcntry_other_clc   as outcntry_other_clc   ,
          outcntry_sng_clc     as outcntry_sng_clc     ,
          outcntry_usa_clc     as outcntry_usa_clc     ,
          content_sms_clc      as content_sms_clc      ,
          redirect_clc         as redirect_clc         ,
          ptp_transfer_clc     as ptp_transfer_clc     ,
          anti_aon_clc         as anti_aon_clc         ,
          account_clc          as account_clc          ,
          multy_call_clc       as multy_call_clc       ,
          tp_change_clc        as tp_change_clc        ,
          sms_insd_clc         as sms_insd_clc         ,
          sms_outctry_clc      as sms_outctry_clc      ,
          sms_outvsr_clc       as sms_outvsr_clc       ,
          sms_outcity_clc      as sms_outcity_clc      ,
          sms_recl_clc         as sms_recl_clc         ,
          sms_other_clc        as sms_other_clc        ,
          abon_tp_clc          as abon_tp_clc          ,
          unclassified         as unclassified         ,
          abon_clc             as abon_clc             ,
          all_clc              as all_clc              ,
          ao_abon_clc          as ao_abon_clc          ,
          total_in             as total_in             ,
          total_out            as total_out            ,
          total_in_unroum      as total_in_unroum      ,
          total_out_unroum     as total_out_unroum     ,
          row_number() over (
                           partition by accn_id_mvno,
                             id_subs,
                             period
                           order by
                             mrf_id desc,
                             rf_id desc) rn
        from
          edw_ods.T_000171_V_MVNO_MONTH
        where
          accn_id_mvno is not null
          and tech_dt=to_date('20190601', 'YYYYMMDD')
      )
      tab
    where
      rn = 1
  )
  
select distinct
  mrf_id_mvno                                                  ,
  mrf_name_mvno                                                ,
  rf_id_mvno                                                   ,
  rf_name_mvno                                                 ,
  accn_id_mvno                                                 ,
  coalesce(NLS, mvno.account_ext, '') as accn_id     ,
  id_subs                                      as subs_id              ,
  coalesce(goodok_clc, 0.00)                   as goodok_clc           ,
  coalesce(mms_clc, 0.00)                      as mms_clc              ,
  coalesce(sms_clc, 0.00)                      as sms_clc              ,
  coalesce(gprs_clc, 0.00)                     as gprs_clc             ,
  coalesce(gprs_clc_move, 0.00)                as gprs_clc_move        ,
  coalesce(gprs_clc_use, 0.00)                 as gprs_clc_use         ,
  coalesce(gprs_clc_roum, 0.00)                as gprs_clc_roum        ,
  coalesce(in_mob_clc, 0.00)                   as in_mob_clc           ,
  coalesce(in_mob_rtc_clc, 0.00)               as in_mob_rtc_clc       ,
  coalesce(in_fix_clc, 0.00)                   as in_fix_clc           ,
  coalesce(in_fix_rtc_clc, 0.00)               as in_fix_rtc_clc       ,
  coalesce(in_other_clc, 0.00)                 as in_other_clc         ,
  coalesce(outcity_clc, 0.00)                  as outcity_clc          ,
  coalesce(outcntry_clc, 0.00)                 as outcntry_clc         ,
  coalesce(out_mob_clc, 0.00)                  as out_mob_clc          ,
  coalesce(out_mob_rtc_clc, 0.00)              as out_mob_rtc_clc      ,
  coalesce(out_fix_clc, 0.00)                  as out_fix_clc          ,
  coalesce(out_fix_rtc_clc, 0.00)              as out_fix_rtc_clc      ,
  coalesce(out_rouming_clc, 0.00)              as out_rouming_clc      ,
  coalesce(outcntry_rouming_clc, 0.00)         as outcntry_rouming_clc ,
  coalesce(outcity_rouming_clc, 0.00)          as outcity_rouming_clc  ,
  coalesce(outvsr_rouming_clc, 0.00)           as outvsr_rouming_clc   ,
  coalesce(out_other_clc, 0.00)                as out_other_clc        ,
  coalesce(outcity_rtc_clc, 0.00)              as outcity_rtc_clc      ,
  coalesce(outcity_other_clc, 0.00)            as outcity_other_clc    ,
  coalesce(outcntry_euro_clc, 0.00)            as outcntry_euro_clc    ,
  coalesce(outcntry_other_clc, 0.00)           as outcntry_other_clc   ,
  coalesce(outcntry_sng_clc, 0.00)             as outcntry_sng_clc     ,
  coalesce(outcntry_usa_clc, 0.00)             as outcntry_usa_clc     ,
  coalesce(content_sms_clc, 0.00)              as content_sms_clc      ,
  coalesce(redirect_clc, 0.00)                 as redirect_clc         ,
  coalesce(ptp_transfer_clc, 0.00)             as ptp_transfer_clc     ,
  coalesce(anti_aon_clc, 0.00)                 as anti_aon_clc         ,
  coalesce(account_clc, 0.00)                  as account_clc          ,
  coalesce(multy_call_clc, 0.00)               as multy_call_clc       ,
  coalesce(tp_change_clc, 0.00)                as tp_change_clc        ,
  coalesce(sms_insd_clc, 0.00)                 as sms_insd_clc         ,
  coalesce(sms_outctry_clc, 0.00)              as sms_outctry_clc      ,
  coalesce(sms_outvsr_clc, 0.00)               as sms_outvsr_clc       ,
  coalesce(sms_outcity_clc, 0.00)              as sms_outcity_clc      ,
  coalesce(sms_recl_clc, 0.00)                 as sms_recl_clc         ,
  coalesce(sms_other_clc, 0.00)                as sms_other_clc        ,
  coalesce(abon_tp_clc, 0.00)                  as abon_tp_clc          ,
  coalesce(unclassified, 0.00)                 as unclassified         ,
  coalesce(abon_clc, 0.00)                     as abon_clc             ,
  coalesce(all_clc, 0.00)                      as all_clc              ,
  coalesce(ao_abon_clc, 0.00)                  as ao_abon_clc          ,
  coalesce(total_in, 0.00)                     as total_in             ,
  coalesce(total_out, 0.00)                    as total_out            ,
  coalesce(total_in_unroum, 0.00)              as total_in_unroum      ,
  coalesce(total_out_unroum, 0.00)             as total_out_unroum     ,
  period::date                                 as eff_dttm             ,
  period::date + interval '1 month - 1 second' as exp_dttm             ,
  now()                                        as load_dttm            ,
  000156                                     as src_id
from
  (
    select
      miswh.*                ,
      mvno.period as period1 ,
      mvno.account           ,
      mvno.subs_id           ,
      mvno.mrf_id as mrf_id1 ,
      mvno.rf_id  as rf_id1  ,
      mvno.account_ext       ,
	    SOUTH_NLS_ACCOUNT.NLS
    from
      miswh
      left join
        (
          select distinct
            period  ,
            account ,
            subs_id ,
            mrf_id  ,
            rf_id   ,
            account_ext
          from
            edw_ods.t_000156_EFFTP_OO_EFF_TP_MVNO
            where tech_dt=to_date('20190601', 'YYYYMMDD')
        )
        as mvno
        on
          miswh.accn_id_mvno                                                             = mvno.account
          and miswh.id_subs                                                              = mvno.subs_id
          and decode(miswh.mrf_id_mvno, 7, 11, 4, 12, 2, 13, 8, 14, 6, 15, 5, 16, 3, 17) = mvno.mrf_id
          --and to_char(miswh.period ::timestamp, 'YYYYMMDD')                              = to_char((mvno.period|| '01') ::timestamp, 'YYYYMMDD')
      left join
      (
        select
          account   ,
          nls       ,
          rf_id     ,
          mrf_id    ,
          date_begin,
          coalesce(LEAD (DATE_BEGIN,1) over (
                                           partition by account
                                           ORDER BY
                                             DATE_END) - interval '1 second' ,DATE_END, date '2999-12-31') as DATE_END
        from
          edw_ods.t_000158_efftp_south_nls_accnt
        where
          account is not null
          and date_begin   <= to_date('20190601', 'YYYYMMDD') + interval '1 month - 1 second'
      ) SOUTH_NLS_ACCOUNT on
        (
          SOUTH_NLS_ACCOUNT.rf_id = mvno.rf_id
          or
          (
            SOUTH_NLS_ACCOUNT.rf_id in (1401,1407) 
            and mvno.rf_id=14999
          )
        )
        and SOUTH_NLS_ACCOUNT.mrf_id  = mvno.mrf_id
        and SOUTH_NLS_ACCOUNT.account = mvno.account_ext
        and to_date('20190601', 'YYYYMMDD') + interval '1 month - 1 second' between SOUTH_NLS_ACCOUNT.date_begin and SOUTH_NLS_ACCOUNT.date_end
    where
      decode(miswh.mrf_id_mvno, 7, 151, 4, 152, 2, 153, 8, 154, 6, 155, 5, 156, 3, 157) = 000156
      and
      not exists
      (
        select
          1
        from
          miswh msh
          inner join
            (
              select distinct
                period ,
                account,
                subs_id,
                mrf_id ,
                rf_id  ,
                account_ext
              from
                edw_ods.t_000156_EFFTP_OO_EFF_TP_MVNO
                where tech_dt=to_date('20190601', 'YYYYMMDD')
            )
            as mvno
            on
              msh.accn_id_mvno                                                       = mvno.account
              and miswh.id_subs                                                      = mvno.subs_id
              and decode(msh.mrf_id_mvno, 7,11, 4,12, 2,13, 8,14, 6,15, 5,16, 3,17) != mvno.mrf_id
              --and to_char(msh.period ::timestamp, 'YYYYMMDD')                        = to_char((mvno.period|| '01') ::timestamp, 'YYYYMMDD')
        where
          msh.accn_id_mvno    = miswh.accn_id_mvno
          and msh.mrf_id_mvno = miswh.mrf_id_mvno
          and msh.id_subs     = miswh.id_subs
      )
  )
  mvno
--where
--  period between to_date('20190601', 'YYYYMMDD') and to_date('20190601', 'YYYYMMDD') + interval'1 month - 1 second'
;

analyse edw_stg_dmcm.tfct_amnt_mvno_1_prt_p000156;
