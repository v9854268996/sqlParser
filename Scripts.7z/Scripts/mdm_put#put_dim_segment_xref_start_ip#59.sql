/*rev.10473 от 11.05.2018*/
delete from edw_stg_mdm.put_dim_segment_xref_start where region_id = 'CENTER' and src_id = 000059;

insert into edw_stg_mdm.put_dim_segment_xref_start (segment_key,segment_name,region_id,src_id)
	select distinct 
       (round(user_type.user_type_id)) as code,
       user_type.name,
	   'CENTER' as region_id
	   ,src_id
    from edw_ods.t_000059_t_users t_users
       join edw_ods.t_000062_t_user_type_ref user_type on t_users.user_type_id = user_type.user_type_id
;
commit;
analyse edw_stg_mdm.put_dim_segment_xref_start;
