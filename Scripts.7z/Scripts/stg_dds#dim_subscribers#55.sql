/*rev.xxxx  08.02.2019*/truncate table edw_stg_dds.t_000055_dim_subscribers;
insert into edw_stg_dds.t_000055_dim_subscribers
	( subs_key
	, src_id
	, subs_activation_dttm
	, subs_cancellation_dttm
	, eff_dttm
	, exp_dttm
	, load_dttm
	)
SELECT 
	subs_key,
	src_id,
	subs_activation_dt,
	subs_cancellation_dt,
	'1900-01-01 00:00:00' as eff_dttm,
	'2999-12-31 00:00:00' as exp_dttm,
	now()
FROM
	edw_stg_dds.t_000055_dim_subs
WHERE
	 date_trunc('DAY',exp_dttm) = date_trunc('DAY',subs_cancellation_dt);
	 analyze edw_stg_dds.t_000055_dim_subscribers;
