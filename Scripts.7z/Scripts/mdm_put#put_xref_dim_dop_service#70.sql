/*rev.47398 от 24.01.2020*/

delete from edw_stg_mdm.put_xref_dim_dop_service
where src_id = 000070;

insert into edw_stg_mdm.put_xref_dim_dop_service
(
    source_key,
    mrf_add_service_name,
    id_enaza,
    src_id
)
select distinct
    eor.eor_srd_code || '#' || eor.eor_int_code || '#' as source_key,
    tsd.srd_name as mrf_add_service_name,
    null as id_enaza,
    eor.src_id
from edw_ods.t_000070_elk_opt_ref eor
left join edw_ods.t_000070_tb_serv_defs tsd on eor.eor_srd_code = tsd.srd_code
    and tsd.exp_dttm = '2999-12-31 00:00:00'
where eor.src_id = 000070
union
select distinct
    tts.trs_srd_code || '#' || tts.trs_int_code || '#' || tts.trs_tfp_code as source_key,
    coalesce(tsd.srd_name,'') || '#' || coalesce(ttp.tfp_name,'') as mrf_add_service_name,
    null as id_enaza,
    tts.src_id
from edw_ods.t_000070_tb_tariff_services tts
left join edw_ods.t_000070_tb_serv_defs tsd on tts.trs_srd_code = tsd.srd_code
    and tsd.exp_dttm = '2999-12-31 00:00:00'
left join edw_ods.t_000070_tb_tariff_plans ttp on tts.trs_tfp_code = ttp.tfp_code
    and ttp.exp_dttm = '2999-12-31 00:00:00'
where tts.exp_dttm = '2999-12-31 00:00:00'
    and tts.src_id = 000070;

analyze edw_stg_mdm.put_xref_dim_dop_service;
