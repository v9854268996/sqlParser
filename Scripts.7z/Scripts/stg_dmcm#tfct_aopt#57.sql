/*rev. 38026 от 19.09.2019*/
truncate table edw_stg_dmcm.tfct_aopt_1_prt_p000057;

INSERT INTO edw_stg_dmcm.tfct_aopt_1_prt_p000057
  ( mrf_id          ,
    cm_id           ,
    accn_id         ,
    srvs_type       ,
    srvs_id         ,
    OPTN_MRF_FULL_ID,
    MRF_SERVICE_KEY ,
    optn_type       ,
    optn_name       ,
    optn_name_full  ,
    optn_region     ,
    optn_mr         ,
    dt_start_optn   ,
    cnt_pay_days    ,
    cnt_notpay_days ,
    add_service_key ,
    srvs_status     ,
    load_dttm       ,
    src_id          ,
    eff_dttm        ,
    exp_dttm
  )
select
  mrf_id          ,
  cm_id           ,
  accn_id         ,
  srvs_type       ,
  srvs_id         ,
  OPTN_MRF_FULL_ID,
  MRF_SERVICE_KEY ,
  optn_type       ,
  optn_name       ,
  optn_name_full  ,
  optn_region     ,
  optn_mr         ,
  dt_start_optn   ,
  cnt_pay_days    ,
  cnt_notpay_days ,
  add_service_key ,
  srvs_status     ,
  load_dttm       ,
  src_id          ,
  eff_dttm        ,
  exp_dttm
from
  (
    select
      oo_eff_tp.P2_MRF_ID                                                               as mrf_id ,
      coalesce(OO_EFF_TP.hflat, '-'||OO_EFF_TP.account)                                 as cm_id     ,
      add_service.account_name                                                          as accn_id   ,
      dir_services.DEF                                                                  as srvs_type ,
      oo_eff_tp.SERV_ID                                                                 as srvs_id   ,
      add_service.src_id||'#'||add_service.mrf_service_key                              as OPTN_MRF_FULL_ID ,
      add_service.mrf_service_key                                                       as MRF_SERVICE_KEY  ,
      coalesce(mas.FREQUENCY_TYPE_NAME ,dim_frequency_services.frequency_services_name) as optn_type        ,
      dim_service.service_name                                                          as optn_name        ,
      add_service.mrf_add_service_name                                                  as optn_name_full   ,
      dim_branch.branch_name                                                           as optn_region      ,
      dim_branch_parent.branch_name                                                    as optn_mr          ,
      add_service.start_date                                                            as dt_start_optn    ,
      case
        when coalesce(mas.dop_usluga_promo_name,'0') ='0'
          then date_part('day',least(add_service.end_date, to_date('20190601', 'YYYYMMDD') + INTERVAL'1 month')- to_date('20190601', 'YYYYMMDD'))
          else 0
      end                                                                               as cnt_pay_days ,
      case
        when coalesce(mas.dop_usluga_promo_name,'0') = '1'
          then date_part('day',least(add_service.end_date, to_date('20190601', 'YYYYMMDD') + INTERVAL'1 month')- to_date('20190601', 'YYYYMMDD'))
          else 0
      end                                                                               as cnt_notpay_days ,
      add_service.add_service_key::numeric                                              as add_service_key ,
      dim_service.service_type_key                                                      as srvs_status     ,
      now()                                                                             as load_dttm       ,
      add_service.src_id                                                                as src_id          ,
      to_date('20190601', 'YYYYMMDD')                                              as eff_dttm        ,
      to_date('20190601', 'YYYYMMDD') + INTERVAL'1 month - 1 second'               as exp_dttm        ,
      row_number () over (
                        partition by add_service.add_service_key
                        order by
                          case
                            when dim_business_service.business_service_key = oo_eff_tp.business_service_key
                              then 1
                              else 0
                          end desc,oo_eff_tp.rn)                                        as bs_rn
    from
      edw_dds.dim_add_service add_service
      left join
        edw_dds.dim_service dim_service
        on
          dim_service.service_key =add_service.service_key
          and to_date('20190601', 'YYYYMMDD') between dim_service.eff_dttm and dim_service.exp_dttm
      left join
        edw_dds.dim_business_service dim_business_service
        on
          dim_service.business_service_key =dim_business_service.business_service_key
          and dim_business_service.exp_dttm=dim_service.exp_dttm
      left join
        edw_dds.dim_frequency_services dim_frequency_services
        on
          dim_service.frequency_services_key =dim_frequency_services.frequency_services_key
          and dim_frequency_services.exp_dttm=dim_service.exp_dttm
      left join 
        edw_dds.dim_branch dim_branch 
        on      
          add_service.branch_key=dim_branch.branch_key
          and to_date('20190601', 'YYYYMMDD') between dim_branch.eff_dttm and dim_branch.exp_dttm
      left join 
        edw_dds.dim_branch dim_branch_parent
        on      
          dim_branch.parent_branch_key=dim_branch_parent.branch_key
          and to_date('20190601', 'YYYYMMDD') between dim_branch_parent.eff_dttm and dim_branch_parent.exp_dttm                        
      left join
        edw_stg_dmcm.dim_dop_service mas
        on
          mas.mrf_service_key=add_service.mrf_service_key
          and mas.src_id=add_service.src_id
          and to_date('20190601', 'YYYYMMDD') between mas.eff_dttm and mas.exp_dttm
      inner join
        (
          select
            account                   ,
            serv_id                   ,
            P2_MRF_ID                 ,
            hflat                     ,
            ABN_ID                    ,
            p3_rf_id                  ,
            IS_ARENDA_SUBS            ,
            data_activ_prev           ,
            xref.business_service_key business_service_key ,
            date_start                ,
            row_number() over (partition by account order by date_start desc) as rn
          from
            edw_ods.t_000151_efftp_oo_eff_tp oo_eff_tp
            join
              edw_dds.hub_dim_business_service xref --edw_stg_mdm.get_xref_dim_business_service xref
              on
                oo_eff_tp.serv_id ||'#' ||oo_eff_tp.tech_id = xref.source_key
                and to_date('20190601', 'YYYYMMDD') between xref.eff_dttm and xref.exp_dttm
                and xref.src_id=158
          where
            tech_dt = to_date('20190601', 'YYYYMMDD')
            and serv_id in (1,2,3)
        )
        oo_eff_tp
        on
          oo_eff_tp.account =add_service.account_name::text
      left join
        edw_ods.t_000158_rprt_dir_services dir_services
        on
          coalesce(OO_EFF_TP.serv_id,-1) = dir_services.serv_id
    where
      to_date('20190601', 'YYYYMMDD') between date_trunc('month',add_service.start_date)::timestamp and date_trunc('month',coalesce(add_service.end_date,'2999-12-31 00:00:00'))::timestamp
      and add_service.src_id=000057
      and to_date('20190601', 'YYYYMMDD') + interval '1 month - 1 second' between add_service.eff_dttm and add_service.exp_dttm
      and add_service.deleted_ind = 0
  )
  last_lvl
where
  bs_rn=1;

  analyze edw_stg_dmcm.tfct_aopt_1_prt_p000057;  
