/*rev. 27892 от 23.04.2019*/
delete from edw_stg_mdm.put_dim_xref_tariff_plans where src_id = 000154;

/*insert into edw_stg_mdm.put_dim_xref_tariff_plans (source_key, rtpl_name, tech_name, src_id)
select distinct null as id_rtpl_name, rtpl_name, null as tech_name, 000154 as src_id from edw_ods.t_000154_efftp_oo_eff_tp_mvno where rtpl_name ilike '%бесконечная%';*/

insert into edw_stg_mdm.put_dim_xref_tariff_plans (source_key, rtpl_name, tech_name, src_id)
select tab.id_rtpl_name, tab.rtpl_name, tab.tech_name, 000154
 from  (select distinct on (id_rtpl_name) id_rtpl_name, rtpl_name, tech_name, max(length(coalesce(tech_name, '1'))) over (partition by id_rtpl_name, rtpl_name) lenstr  from edw_ods.t_000154_rprt_vrate_plans_dwh where rtpl_name ilike '%бесконечная%'   union
        select distinct on (id_rtpl_name) id_rtpl_name, rtpl_name, tech_name, max(length(coalesce(tech_name, '1'))) over (partition by id_rtpl_name, rtpl_name) lenstr  from edw_ods.t_000154_rprt_vrate_plans_dwh where rtpl_name ilike '%для своих%'     union
        select distinct on (id_rtpl_name) id_rtpl_name, rtpl_name, tech_name, max(length(coalesce(tech_name, '1'))) over (partition by id_rtpl_name, rtpl_name) lenstr  from edw_ods.t_000154_rprt_vrate_plans_dwh where rtpl_name ilike '%киновип%'       union
        select distinct on (id_rtpl_name) id_rtpl_name, rtpl_name, tech_name, max(length(coalesce(tech_name, '1'))) over (partition by id_rtpl_name, rtpl_name) lenstr  from edw_ods.t_000154_rprt_vrate_plans_dwh where rtpl_name ilike '%стартовый%'     union
        select distinct on (id_rtpl_name) id_rtpl_name, rtpl_name, tech_name, max(length(coalesce(tech_name, '1'))) over (partition by id_rtpl_name, rtpl_name) lenstr  from edw_ods.t_000154_rprt_vrate_plans_dwh where rtpl_name ilike '%оптимальный%'   union
        select distinct on (id_rtpl_name) id_rtpl_name, rtpl_name, tech_name, max(length(coalesce(tech_name, '1'))) over (partition by id_rtpl_name, rtpl_name) lenstr  from edw_ods.t_000154_rprt_vrate_plans_dwh where rtpl_name ilike '%экспресс%'      union
        select distinct on (id_rtpl_name) id_rtpl_name, rtpl_name, tech_name, max(length(coalesce(tech_name, '1'))) over (partition by id_rtpl_name, rtpl_name) lenstr  from edw_ods.t_000154_rprt_vrate_plans_dwh where rtpl_name ilike '%для ценителей%' union
        select distinct on (id_rtpl_name) id_rtpl_name, rtpl_name, tech_name, max(length(coalesce(tech_name, '1'))) over (partition by id_rtpl_name, rtpl_name) lenstr  from edw_ods.t_000154_rprt_vrate_plans_dwh where rtpl_name ilike '%продвинутый%'   union
        select distinct on (id_rtpl_name) id_rtpl_name, rtpl_name, tech_name, max(length(coalesce(tech_name, '1'))) over (partition by id_rtpl_name, rtpl_name) lenstr  from edw_ods.t_000154_rprt_vrate_plans_dwh where rtpl_name ilike '%перезагрузка%'  union
        select distinct on (id_rtpl_name) id_rtpl_name, rtpl_name, tech_name, max(length(coalesce(tech_name, '1'))) over (partition by id_rtpl_name, rtpl_name) lenstr  from edw_ods.t_000154_rprt_vrate_plans_dwh where rtpl_name ilike '%максимальный%'  union
        select distinct on (id_rtpl_name) id_rtpl_name, rtpl_name, tech_name, max(length(coalesce(tech_name, '1'))) over (partition by id_rtpl_name, rtpl_name) lenstr  from edw_ods.t_000154_rprt_vrate_plans_dwh where rtpl_name ilike '%для семьи и учебы%'
       ) tab
 where lenstr = length(coalesce(tech_name, '1'));
analyze edw_stg_mdm.put_dim_xref_tariff_plans;