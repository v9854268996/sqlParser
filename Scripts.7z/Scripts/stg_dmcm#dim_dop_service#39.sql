/*rev. 37947 от 18.09.2019 Changed by: MAKSIM.GERASIMOV */
truncate table edw_stg_dmcm.pre_dim_dop_service_stg_1_1_prt_p000039;
insert into edw_stg_dmcm.pre_dim_dop_service_stg_1_1_prt_p000039
  ( dop_service_key             ,
    dop_usluga_id               ,
    dop_usluga_name             ,
    dop_usluga_product_type_name,
    dop_usluga_service_type_name,
    dop_usluga_promo_name       ,
    dop_usluga_bonus_type_name  ,
    dop_usluga_vendor_name      ,
    dop_usluga_product_name     ,
    id_enaza_name               ,
    frequency_type_name         ,
    srvs_type                   ,
    asr_src_id                  ,
    mrf_service_name            ,
    mrf_service_key             ,
    optn_mrf_full_id            ,
    load_dttm                   ,
    src_id                      ,
    eff_dttm                    ,
    exp_dttm                    
    
  )
select
  ddops.DOP_SERVICE_KEY             ,
  ddops.DOP_USLUGA_ID               ,
  ddops.DOP_USLUGA_NAME             ,
  ddops.DOP_USLUGA_PRODUCT_TYPE_NAME,
  ddops.DOP_USLUGA_SERVICE_TYPE_NAME,
  ddops.DOP_USLUGA_PROMO_NAME       ,
  ddops.DOP_USLUGA_BONUS_TYPE_NAME  ,
  ddops.DOP_USLUGA_VENDOR_NAME      ,
  ddops.DOP_USLUGA_PRODUCT_NAME     ,
  ddops.ID_ENAZA_NAME               ,
  ddops.FREQUENCY_TYPE_NAME         ,
  SRVS_TYPE                         ,
  hddops.src_id                     ,
  get_mdm.dfnamesmall as mrf_add_service_name,
  hddops.source_key                 ,
  hddops.src_id||'#'||hddops.source_key as OPTN_MRF_FULL_ID,
  now()                             ,
  000039                      ,  
  hddops.eff_dttm                   ,
  hddops.exp_dttm
from
  edw_dds.hub_dim_dop_service hddops
  join
    edw_dds.dim_dop_service ddops
    on
      hddops.dop_service_key=ddops.dop_service_key
      and to_date('20190630','YYYYMMDD') between ddops.start_dttm and ddops.end_dttm
  join
    edw_ods.t_000039_tservice get_mdm
    on
      round(get_mdm.dfservice)::varchar  = hddops.source_key
      and get_mdm.deleted_ind = 0
where
  to_date('20190630','YYYYMMDD') BETWEEN hddops.eff_dttm AND hddops.exp_dttm
  and hddops.src_id=000039;

ANALYZE edw_stg_dmcm.pre_dim_dop_service_stg_1_1_prt_p000039;

insert into edw_stg_dmcm.pre_dim_dop_service_stg_1_1_prt_p000039
(
  dop_service_key,
  dop_usluga_id,
  dop_usluga_name,
  dop_usluga_product_type_name,
  dop_usluga_service_type_name,
  dop_usluga_promo_name,
  dop_usluga_bonus_type_name,
  dop_usluga_vendor_name,
  dop_usluga_product_name,
  id_enaza_name,
  frequency_type_name,
  srvs_type,
  asr_src_id,
  mrf_service_name,
  mrf_service_key,
  optn_mrf_full_id,
  src_id,
  eff_dttm,
  exp_dttm,
  load_dttm
)
select
  null                       ,
  null                       ,
  null                       ,
  null                       ,
  null                       ,
  null                       ,
  null                       ,
  null                       ,
  ds.service_name            ,
  null                       ,
  dfs.frequency_services_name,
  dbs.business_service_name  ,
  hds.src_id                 ,
  tserv.dfnamesmall          ,
  hds.source_key             ,
  hds.src_id||'#'||hds.source_key as OPTN_MRF_FULL_ID,
  000039                          ,  
  hds.eff_dttm                          ,
  hds.exp_dttm                          ,
  now()
from
  edw_dds.hub_dim_service hds
  left join
    edw_ods.t_000039_tservice tserv
    on
      hds.source_key=tserv.src_id||';'||tserv.dfservice::numeric(38)
  join
    edw_dds.dim_service ds
    on
      hds.service_key=ds.service_key
      and hds.exp_dttm between ds.eff_dttm and ds.exp_dttm
  join
    edw_dds.dim_business_service dbs
    on
      ds.business_service_key=dbs.business_service_key
      and hds.exp_dttm between dbs.eff_dttm and dbs.exp_dttm
  join
    edw_dds.dim_frequency_services dfs
    on
      ds.frequency_services_key=dfs.frequency_services_key
      and hds.exp_dttm between dfs.eff_dttm and dfs.exp_dttm
  left join
    edw_stg_dmcm.pre_dim_dop_service_stg_1_1_prt_p000039 ddops
    on
      ddops.OPTN_MRF_FULL_ID=hds.src_id||'#'||hds.source_key
      and hds.exp_dttm between ddops.eff_dttm and ddops.exp_dttm
where
  hds.src_id                       =000039
  and hds.exp_dttm                 >=to_date('201801','YYYYMM')
  and ddops.OPTN_MRF_FULL_ID is null
;

ANALYZE edw_stg_dmcm.pre_dim_dop_service_stg_1_1_prt_p000039;

truncate table edw_stg_dmcm.dim_dop_service_1_prt_p000039;
insert into edw_stg_dmcm.dim_dop_service_1_prt_p000039
  (
    dop_service_key             ,
    dop_usluga_id               ,
    dop_usluga_name             ,
    dop_usluga_product_type_name,
    dop_usluga_service_type_name,
    dop_usluga_promo_name       ,
    dop_usluga_bonus_type_name  ,
    dop_usluga_vendor_name      ,
    dop_usluga_product_name     ,
    id_enaza_name               ,
    frequency_type_name         ,
    srvs_type                   ,
    asr_src_id                  ,
    mrf_service_name            ,
    mrf_service_key             ,
    optn_mrf_full_id            ,
    load_dttm                   ,
    src_id                      ,
    eff_dttm                    ,
    exp_dttm
  )
select *
from
  (
    select
      dop_service_key             ,
      dop_usluga_id               ,
      dop_usluga_name             ,
      dop_usluga_product_type_name,
      dop_usluga_service_type_name,
      dop_usluga_promo_name       ,
      dop_usluga_bonus_type_name  ,
      dop_usluga_vendor_name      ,
      dop_usluga_product_name     ,
      id_enaza_name               ,
      frequency_type_name         ,
      srvs_type                   ,
      asr_src_id                  ,
      mrf_service_name            ,
      mrf_service_key             ,
      optn_mrf_full_id            ,
      now() as load_dttm           ,
      src_id                      ,
      eff_dttm                    ,
      coalesce(lead(eff_dttm) over ( partition by optn_mrf_full_id order by eff_dttm, exp_dttm) - interval '1 second',exp_dttm) as exp_dttm
    from
      edw_stg_dmcm.pre_dim_dop_service_stg_1_1_prt_p000039
  )
  lvl0
where
  eff_dttm<exp_dttm;

analyze edw_stg_dmcm.dim_dop_service_1_prt_p000039;
