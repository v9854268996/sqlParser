/*rev.41328 28.10.2019*/
truncate table edw_stg_dds.t_000086_dim_partner;
insert into edw_stg_dds.t_000086_dim_partner 
( 
partner_key
, parent_tax_number_cval
, tax_number_cval
, segment_key
, tax_reg_reason_cval
, partner_full_name
, branch_key
, doc_number_cval
, src_id
, load_dttm
, eff_dttm
, exp_dttm
, start_date
, end_date
)

with t_saldo as  (
  	select distinct
  	   user_id
  	   , dept_id
  	   , user_type_id
  	   , billing_id
  	   , max(billing_id) over (partition by user_id) as max_billing_id
  	   , min(billing_id) over (partition by user_id) as min_billing_id 
  	from edw_ods.t_000086_t_saldo 
  	where billing_id <= substr('20190630', 1, 6)::numeric
  		  and tech_dt <= to_date(substr('20190630', 1, 8), 'YYYYMMDD')
  )  
,

t_vip_sp as  (
  	select
  	      round(sp.user_id_sp) as user_id_sp
  	    , round(v.user_id_vip) as user_id_vip
  	    , (round(sp.dept_id_vip))::varchar as dept_id_vip
  	    , case 
  	    	when coalesce(date_begin,'1900-01-01 00:00:00') = min(coalesce(date_begin,'1900-01-01 00:00:00')) over (partition by v.user_id_sp) 
  	    		then '1900-01-01 00:00:00'
  	    		else coalesce(date_begin,'1900-01-01 00:00:00') 
  	      end as date_begin_v2
  	    , case 
  	    	when coalesce(date_end,'2999-12-31 00:00:00') = max(coalesce(date_end,'2999-12-31 00:00:00')) over (partition by v.user_id_sp) 
  	    		then '2999-12-31 00:00:00' 
  	    		else coalesce(date_end,'2999-12-31 00:00:00') 
  	      end as date_end_v2
  	from edw_ods.t_000086_t_vip_sp sp
  	  inner join edw_ods.t_000086_t_vip v 
  		on sp.user_id_sp=v.user_id_sp
		and v.deleted_ind = 0
		and v.eff_dttm <= to_date('20190630','YYYYMMDD')
	    and v.exp_dttm >= to_date('20190630','YYYYMMDD')
  	where sp.deleted_ind = 0
	  and sp.eff_dttm <= to_date('20190630','YYYYMMDD')
	  and sp.exp_dttm >= to_date('20190630','YYYYMMDD')
  )  

select 
  partner_key
  , parent_tax_number_cval
  , tax_number_cval
  , segment_key
  , tax_reg_reason_cval
  , partner_full_name
  , branch_key
  , doc_number_cval
  , src_id
  , load_dttm
  , eff_dttm
  , case 
  	when date_trunc('day',exp_dttm)::timestamp = '2999-12-31' 
  		then date_trunc('day',exp_dttm)::timestamp 
  		else exp_dttm 
  end as exp_dttm
  , eff_dttm as start_date
  , case 
  	when date_trunc('day',exp_dttm)::timestamp = '2999-12-31' 
  		then date_trunc('day',exp_dttm)::timestamp 
  		else exp_dttm 
  end as end_date
from (
  select
      round(t_users.user_id) as partner_key
    , t_chief_users.inn as parent_tax_number_cval
    , t_users.inn as tax_number_cval
    , coalesce(t_saldo.dept_id,t_users.dept_id) as branch_key
    , coalesce(round(ttr.user_type_id)::text,t_saldo.user_type_id::text, t_users.user_type_id::text, 'nd_ekhd') as segment_key
    , t_users.kpp as tax_reg_reason_cval
    , trim(case when lower(t_users.iscorp) = 'y' then o_contract.fullname else t_users.name end) as partner_full_name
    , t_users.document_text as doc_number_cval
    , t_users.src_id as src_id
    , now() as load_dttm
    , coalesce(decode(t_saldo.billing_id,
	                  t_saldo.min_billing_id,
					  to_date('1900-01-01', 'yyyy-mm-dd')),
					  to_date((round(t_saldo.billing_id))::varchar, 'YYYYMM'), 
					  to_date('1900-01-01', 'yyyy-mm-dd')) as eff_dttm
    , coalesce(decode(t_saldo.billing_id,
	                  t_saldo.max_billing_id,
					  to_date('2999-12-31', 'yyyy-mm-dd')),
					  to_date((round(t_saldo.billing_id))::varchar, 'YYYYMM') + interval '1 month - 1 day', 
					  to_date('2999-12-31', 'yyyy-mm-dd')) + interval '1 day - 1 second' as exp_dttm
  from edw_ods.t_000086_t_users t_users
  left join  t_saldo 
  	on t_users.user_id = t_saldo.user_id 
  left join t_vip_sp 
  	on t_users.user_id = t_vip_sp.user_id_sp 
  	and to_date((round(t_saldo.billing_id))::varchar, 'YYYYMM') between t_vip_sp.date_begin_v2 and t_vip_sp.date_end_v2 
  left join edw_dds.hub_dim_branch hub 
  	on t_vip_sp.dept_id_vip = hub.source_key 
  	and t_users.src_id = hub.src_id
  	and hub.eff_dttm <= to_date('20190630','YYYYMMDD')
	and hub.exp_dttm >= to_date('20190630','YYYYMMDD')
  left join  edw_stg_dds.T_000086_PRE_TTR_SIBIR_START ttr 
  	on ttr.user_id = t_vip_sp.user_id_vip 
  	and hub.branch_key::text = ttr.branch_key
  	and ttr.billing_id = t_saldo.billing_id  	
  left join edw_ods.t_000086_t_users t_chief_users 
  	on t_chief_users.user_id = t_users.chief_user_id 
	and t_chief_users.deleted_ind = 0
    and t_chief_users.eff_dttm <= to_date('20190630','YYYYMMDD')
	and t_chief_users.exp_dttm >= to_date('20190630','YYYYMMDD')
  left join edw_ods.t_000086_o_contract o_contract 
  	on o_contract.user_id = t_users.user_id 
	and o_contract.deleted_ind = 0
    and o_contract.eff_dttm <= to_date('20190630','YYYYMMDD')
	and o_contract.exp_dttm >= to_date('20190630','YYYYMMDD')
  where t_users.eff_dttm <= to_date('20190630','YYYYMMDD')
    and t_users.exp_dttm >= to_date('20190630','YYYYMMDD')
  	and t_users.deleted_ind = 0
  )s;
commit;
analyse edw_stg_dds.t_000086_dim_partner;