/*rev.23170 25.02.2019*/

truncate edw_stg_dds.t_000007_dim_subs_01;
insert into edw_stg_dds.t_000007_dim_subs_01 (serv_first_id,date_begin,date_end,business_service,user_id,house_id,rn_child,rn_parent)
with ttt as
(
    select
        round(ts1.serv_first_id) as serv_first_id
        ,min(ts1.date_begin) as date_begin
        ,max(coalesce(ts1.date_end, to_date('29991231', 'YYYYMMDD'))
            ) as date_end
        --,es1.business_service as business_service
        ,et.business_service_key as  business_service
        ,round(ts1.user_id) as user_id
        ,round(ts1.house_id) as house_id
        from edw_ods.t_000007_t_services ts1
        --join edw_stg_dds.v_dim_services_xref_volga es1
        --  on (round(ts1.svc_id) = es1.svc_id and es1.sub_make = 1)
        --  and to_date(es1.exp_dttm, 'YYYYMMDD') = '29991231'
        --таблица постоянной услуги, для последующей реализации абонента
    join edw_stg_dds.t_dim_service_xref_start xref
        on xref.source_key = round(ts1.svc_id)::text
        and to_date('20190630', 'YYYYMMDD')
            + INTERVAL '1 MONTH - 1 second'
            between xref.eff_dttm and xref.exp_dttm
        and xref.region_id = 'VOLGA'
    join edw_dds.dim_service et
        on et.service_key = xref.service_key
        and to_date('20190630', 'YYYYMMDD')
          + INTERVAL '1 MONTH - 1 second'
          between et.eff_dttm and et.exp_dttm
    where   ts1.deleted_ind=0
        and xref.sub_make = 1
        and to_date(substr('20190630', 1, 8), 'YYYYMMDD')
            + INTERVAL '1 day - 1 second' + interval '6 days'
            between ts1.eff_dttm and ts1.exp_dttm
    group by
        serv_first_id
        ,et.business_service_key
        ,round(ts1.user_id)
        ,ts1.house_id
)
select
    serv_first_id
    ,date_begin
    ,date_end
    ,business_service
    ,user_id
    ,house_id
    ,row_number() over (partition by serv_first_id, business_service order by date_begin asc, date_end asc) as rn_child
    ,row_number() over (partition by serv_first_id, business_service order by date_end desc, date_begin desc) as rn_parent
from ttt;
commit;
analyse edw_stg_dds.t_000007_dim_subs_01;
------------------------------------------------------------------------
truncate edw_stg_dds.t_000007_dim_subs_02;
insert into edw_stg_dds.t_000007_dim_subs_02
    (serv_first_id, date_begin, date_end, business_service, user_id,
        inn, rn_child, rn_parent)
with ttt as
(
    select
        round(serv_first_id) as serv_first_id
        , min(ts1.date_begin) as date_begin
        , max(coalesce(ts1.date_end, to_date('29991231','YYYYMMDD'))
            ) as date_end
        , et.business_service_key as  business_service
        , round(ts1.user_id) as user_id
    from edw_ods.t_000007_t_services ts1
    join edw_stg_dds.t_dim_service_xref_start xref
        on xref.source_key = round(ts1.svc_id)::text
        and to_date('20190630', 'YYYYMMDD')
            + INTERVAL '1 MONTH - 1 second'
            between xref.eff_dttm and xref.exp_dttm
        and xref.region_id = 'VOLGA'
    join edw_dds.dim_service et
        on et.service_key = xref.service_key
        and to_date('20190630', 'YYYYMMDD')
            + INTERVAL '1 MONTH - 1 second'
            between et.eff_dttm and et.exp_dttm
    where ts1.deleted_ind=0
        and to_date(substr('20190630', 1, 8), 'YYYYMMDD')
            + INTERVAL '1 day - 1 second' + interval '6 days'
            between ts1.eff_dttm and ts1.exp_dttm
    group by
        round(serv_first_id)
        ,et.business_service_key
        ,ts1.user_id
)
select
    ts1.serv_first_id
    ,min(ts1.date_begin) as date_begin
    ,max(ts1.date_end) as date_end
    ,ts1.business_service as business_service
    ,ts1.user_id
    ,tu1.inn as inn
    ,row_number() over (
        partition by ts1.serv_first_id, ts1.business_service
        order by min(ts1.date_begin) asc
        ) as rn_child
    ,row_number() over (
        partition by ts1.serv_first_id, ts1.business_service
        order by max(ts1.date_end) desc
        ) as rn_parent
from ttt ts1
    --таблица постоянной услуги, для последующей реализации абонента
join edw_ods.t_000007_t_users tu1
    on round(ts1.user_id) = round(tu1.user_id)
        and iscorp = 'Y'
        and tu1.deleted_ind=0
        and to_date(substr('20190630', 1, 8), 'YYYYMMDD')
            + INTERVAL '1 day - 1 second' + interval '6 days'
            between tu1.eff_dttm and tu1.exp_dttm
where
    tu1.inn ~ '^([0-9]*)$' = true
    and coalesce(tu1.inn,'') <> ''
    and length(tu1.inn)>10
    and tu1.deleted_ind=0
group by
    ts1.serv_first_id
    ,ts1.business_service
    ,ts1.user_id
    ,tu1.inn
;
commit;
analyze edw_stg_dds.t_000007_dim_subs_02;
------------------------------------------------------------------------
truncate edw_stg_dds.t_000007_dim_subs_10_nariad;
------------------------------------------------------------------------
truncate table edw_stg_dds.t_000007_dim_subs_11_nariad_test;
insert into edw_stg_dds.t_000007_dim_subs_11_nariad_test
    (service_first_id_parent, service_first_id_child, business_service,
        src_id, eff_dttm, exp_dttm, day)
select distinct
   t2.serv_first_id as service_first_id_parent
  ,t1.serv_first_id as service_first_id_child
  ,t1.business_service
  ,000007 as src_id
  ,t1.date_begin as eff_dttm --потомок
  ,t2.date_end as exp_dttm --родитель
  ,abs(date_part('day', t1.date_begin::timestamp - t2.date_end::timestamp )) as day
from  edw_stg_dds.t_000007_dim_subs_01 t1,
    edw_stg_dds.t_000007_dim_subs_01 t2
where  1=1
        and t1.business_service  = t2.business_service
            --обе абонентообразующие услуги должны
            --относится к одной бизнес-услуге
        and t1.user_id = t2.user_id --постоянные услуги
            --относятся к одному клиенту
        and t1.serv_first_id > t2.serv_first_id
            --and abs(to_date(t1.date_begin, 'YYYYMMDD')
            --  - to_date(t2.date_end, 'YYYYMMDD'))<=7
    and date_part('day', t1.date_begin::timestamp - t2.date_end::timestamp ) between -7 and 30
    and t2.house_id = t1.house_id
    and t2.rn_parent = 1
    and t1.rn_child = 1;

analyse  edw_stg_dds.t_000007_dim_subs_11_nariad_test;
------------------------------------------------------------------------
select edw_stg_dds.f_dim_subs_get_pairs_start('000007');
analyse edw_stg_dds.t_000007_dim_subs_10_nariad;
------------------------------------------------------------------------
truncate table edw_stg_dds.t_000007_dim_subs_11_nariad_test;
insert into edw_stg_dds.t_000007_dim_subs_11_nariad_test
(service_first_id_parent, service_first_id_child, business_service,
    src_id, eff_dttm, exp_dttm, day)
select distinct
   t2.serv_first_id as service_first_id_parent
  ,t1.serv_first_id as service_first_id_child
  ,t1.business_service
  ,000007 as src_id
  ,t1.date_begin as eff_dttm --потомок
  ,t2.date_end as exp_dttm --родитель
  ,abs(date_part('day', t1.date_begin::timestamp - t2.date_end::timestamp )) as day
from  edw_stg_dds.t_000007_dim_subs_01 t1,
    edw_stg_dds.t_000007_dim_subs_01 t2
where   1=1
        and t1.business_service  = t2.business_service
            --обе абонентообразующие услуги должны
            --    относится к одной бизнес-услуге
        and t1.user_id = t2.user_id
            --постоянные услуги относятся к одному клиенту
        and t1.serv_first_id > t2.serv_first_id
        --and abs(to_date(t1.date_begin, 'YYYYMMDD')
            --- to_date(t2.date_end, 'YYYYMMDD'))<=7
    and date_part('day', t1.date_begin::timestamp - t2.date_end::timestamp ) between -7 and 30
    and t2.rn_parent = 1
    and t1.rn_child = 1;

analyse edw_stg_dds.t_000007_dim_subs_11_nariad_test;
------------------------------------------------------------------------
select edw_stg_dds.f_dim_subs_get_pairs_start('000007');
analyse edw_stg_dds.t_000007_dim_subs_10_nariad;
------------------------------------------------------------------------
truncate edw_stg_dds.t_000007_dim_subs_11_nariad_test;
insert into edw_stg_dds.t_000007_dim_subs_11_nariad_test
(service_first_id_parent, service_first_id_child, business_service,
    src_id, eff_dttm, exp_dttm, day)
select distinct
   t2.serv_first_id as service_first_id_parent
  ,t1.serv_first_id as service_first_id_child
  ,t1.business_service
  ,000007 as src_id
  ,t1.date_begin as eff_dttm --потомок
  ,t2.date_end as exp_dttm --родитель
  ,date_part('day', t1.date_begin::timestamp - t2.date_end::timestamp ) as day

from edw_stg_dds.t_000007_dim_subs_02 t1
  ,edw_stg_dds.t_000007_dim_subs_02 t2
where   1=1
        and (t1.business_service  = t2.business_service)
            --обе абонентообразующие услуги должны
            --    относится к одной бизнес-услуге
        and (t1.user_id <> t2.user_id)
    and t1.inn <> '' and t2.inn <> ''
    and (coalesce(t1.inn, 'inn1') = coalesce(t2.inn, 'inn2'))
        --постоянные услуги относятся к одному клиенту
        and t1.serv_first_id > t2.serv_first_id
        --and abs(to_date(t1.date_begin, 'YYYYMMDD')
        --    - to_date(t2.date_end, 'YYYYMMDD'))<=7
    and date_part('day', t1.date_begin::timestamp - t2.date_end::timestamp ) between -7 and 30
    and t2.rn_parent = 1
    and t1.rn_child = 1;
analyze edw_stg_dds.t_000007_dim_subs_11_nariad_test;
------------------------------------------------------------------------
select edw_stg_dds.f_dim_subs_get_pairs_start('000007');
analyse edw_stg_dds.t_000007_dim_subs_10_nariad;
------------------------------------------------------------------------
select edw_stg_dds.f_dim_subs_get_parent_child_start('000007');
analyze edw_stg_dds.t_000007_dim_subs_parent_child;
commit;
------------------------------------------------------------------------

truncate table edw_stg_dds.t_000007_dim_subs;

set optimizer = on;

INSERT INTO edw_stg_dds.t_000007_dim_subs
(subs_key,
subs_activation_dt,
subs_cancellation_dt,
address_key,
service_key,
account_key,
subs_code,
start_date,
end_date,
src_id,
load_dttm,
duty_num_key,
center_num_key,
service_id,
serv_first_id,
eff_dttm,
exp_dttm
)

select  src_id||'#'||subs_key as subs_key
      ,subs_activation_dt
      ,max(end_date) over (partition by subs_key order by end_date desc)
        + interval '1 day - 1 second' as subs_cancellation_dt
      ,address_key
      ,service_key
      ,src_id||'#'||account_key as account_key
      ,subs_code
      ,start_date
      ,end_date + interval '1 day - 1 second' as end_date
      ,src_id
      ,load_dttm
      ,duty_num_key
      ,center_num_key
      ,service_id
      ,serv_first_id
      ,start_date as eff_dttm
      ,end_date + interval '1 day - 1 second' as exp_dttm
from(
select  subs_key
      ,min(start_date)
        over (partition by subs_key order by start_date)
        as subs_activation_dt
      ,address_key
      ,service_key
      ,account_key
      ,subs_code
      ,src_id
      ,wf_run_id
      ,load_dttm
      ,start_date
      ,end_date
      ,duty_num_key
      ,center_num_key
      ,service_id
        ,serv_first_id
from(
select  subs_key
      ,address_key
        ,service_key
      ,account_key
      ,subs_code
      ,src_id
      ,wf_run_id
      ,load_dttm
        ,start_date
        ,coalesce( max(start_date)
            over (partition by subs_key order by start_date, end_date
                rows between 1 following and 1 following)
                - interval '1 day', end_date,
                to_date('29991231', 'YYYYMMDD')
            ) end_date
      ,duty_num_key
      ,center_num_key
      ,service_id
        ,serv_first_id
from(
select  subs_key
      ,subs_activation_dt
      ,subs_cancellation_dt
      ,address_key
        ,service_key
      ,account_key
      ,subs_code
      ,src_id
      ,wf_run_id
      ,load_dttm
        ,start_date
        ,end_date
      ,duty_num_key
      ,center_num_key
      ,service_id
        ,serv_first_id
        ,case when md5 = max(md5)
            over (partition by subs_key
                order by start_date, service_id asc
                rows between 1 following and 1 following
                ) then 'Y' else 'N' end
            as is_wrong_version
from(
select  subs_key
      ,subs_activation_dt
      ,subs_cancellation_dt
      ,address_key
        ,service_key
      ,account_key
      ,subs_code
      ,src_id
      ,wf_run_id
      ,load_dttm
        ,start_date
        ,end_date
      ,duty_num_key
      ,center_num_key
      ,service_id
        ,serv_first_id
        ,md5
from(
select  subs_key
      ,subs_activation_dt
      ,subs_cancellation_dt
      ,address_key
        ,service_key
      ,account_key
      ,subs_code
      ,src_id
      ,wf_run_id
      ,load_dttm
        ,start_date
        ,end_date
      ,duty_num_key
      ,center_num_key
      ,service_id
        ,serv_first_id
        ,md5
        ,md5_next
        ,case when md5 = md5_prev
                and md5_next is not null
            then 'Y'
            else 'N'
            end is_wrong_version
from(
select  subs_key
      ,subs_activation_dt
      ,subs_cancellation_dt
      ,address_key
        ,service_key
      ,account_key
      ,subs_code
      ,src_id
      ,wf_run_id
      ,load_dttm
        ,start_date
        ,end_date
      ,duty_num_key
      ,center_num_key
      ,service_id
        ,serv_first_id
        ,md5
        ,max(md5) over (
            partition by subs_key order by start_date, service_id asc
                rows between 1 preceding and 1 preceding)
            as md5_prev
        ,max(md5) over (
            partition by subs_key order by start_date, service_id asc
            rows between 1 following and 1 following)
            as md5_next
from(
select  subs_key
      ,subs_activation_dt
      ,subs_cancellation_dt
      ,address_key
        ,service_key
      ,account_key
      ,subs_code
      ,src_id
      ,wf_run_id
      ,load_dttm
        ,start_date
        ,end_date
      ,duty_num_key
      ,center_num_key
      ,service_id
      ,serv_first_id
        ,md5(cast(subs_key as varchar) ||'#'||
            cast(subs_activation_dt as varchar) ||'#'||
            cast(subs_cancellation_dt as varchar) ||'#'||
            coalesce(subs_code,'') ||'#'||
            cast(service_key as varchar) ||'#'||
            coalesce(address_key,'') ||'#'||
            cast(account_key as varchar) ||'#'||
            cast(service_id as varchar)||'#'||
            cast(serv_first_id as varchar)
            ) md5
from(
select  subs_key,
        min(subs_activation_dt) over (
                partition by subs_key)
            as subs_activation_dt,
        max(subs_cancellation_dt) over (
                partition by subs_key)
            as subs_cancellation_dt,
        address_key,
      service_key,
      account_key,
      subs_code,
      src_id,
      wf_run_id,
      load_dttm,
      start_date,
      end_date,
      duty_num_key,
      center_num_key,
      service_id,
      serv_first_id
from(
select  subs_pr_30days.subs_key||'#'||sum(subs_pr_30days.pr_30_days)
    over (partition by subs_pr_30days.subs_key
        order by subs_pr_30days.start_date, service_id asc
        ) as subs_key,
      subs_pr_30days.subs_activation_dt,
      subs_pr_30days.subs_cancellation_dt,
      subs_pr_30days.address_key,
      subs_pr_30days.service_key,
      subs_pr_30days.account_key,
      subs_pr_30days.subs_code,
      000007 as src_id,
      -1 as wf_run_id,
      now() as load_dttm,
      subs_pr_30days.start_date,
      subs_pr_30days.end_date,
      subs_pr_30days.duty_num_key,
      subs_pr_30days.center_num_key,
      subs_pr_30days.service_id,
      subs_pr_30days.serv_first_id
from(
select  s.subs_key,            -- id абонента
      s.subs_activation_dt,  -- дата активации абонента,
      s.subs_cancellation_dt,-- дата закрытия абонента,
      s.address_key,         -- id адреса оказания услуги
      s.service_key,         -- id услуги
    s.account_key,         -- id лицевого счета
    s.subs_code,           -- код доступа к услуге
    s.start_date,            -- дата начала действия записи
    s.end_date,
    s.duty_num_key,
    s.center_num_key,
    s.service_id,
    s.serv_first_id,
    case when extract(day from s.start_date - lag (s.end_date)
        over (partition by s.subs_key
            order by s.start_date asc, s.end_date asc, s.service_id asc)
                    ) >30
            then 1 else 0
        end
        as pr_30_days
from(
select sub_pr_bs.subs_key||'#'||sum(sub_pr_bs.pr_bs)
    over (partition by sub_pr_bs.subs_key
        order by sub_pr_bs.start_date, service_id asc)
    as subs_key,
      sub_pr_bs.subs_activation_dt,
      sub_pr_bs.subs_cancellation_dt,
      sub_pr_bs.address_key,
      sub_pr_bs.service_key,
      sub_pr_bs.account_key,
      sub_pr_bs.subs_code,
      sub_pr_bs.start_date,
      sub_pr_bs.end_date,
      sub_pr_bs.duty_num_key,
      sub_pr_bs.center_num_key,
      sub_pr_bs.service_id,
      sub_pr_bs.serv_first_id
from(
select  subs_pr_sub.subs_key as subs_key,
      subs_pr_sub.subs_activation_dt,
    subs_pr_sub.subs_cancellation_dt,
    subs_pr_sub.address_key,
    subs_pr_sub.service_key,
    subs_pr_sub.account_key,
    subs_pr_sub.subs_code,
    subs_pr_sub.start_date,
    subs_pr_sub.end_date,
    subs_pr_sub.duty_num_key,
    subs_pr_sub.center_num_key,
    subs_pr_sub.service_id,
    subs_pr_sub.serv_first_id,
    case when subs_pr_sub.business_service
        <> lag (subs_pr_sub.business_service)
            over (partition by subs_pr_sub.subs_key
                order by subs_pr_sub.start_date asc, service_id asc)
            then 1
            else 0
        end as PR_BS
from(
select coalesce(ss.service_first_id_parent_root::numeric,
    round(t_services.serv_first_id)) ||'#'||
        round(t_services.user_id)
        as subs_key,
        case when t_services.date_begin
            < to_date('19000101', 'YYYYMMDD')
                then to_date('19000101', 'YYYYMMDD')
            else coalesce(t_services.date_begin,
                to_date('19000101', 'YYYYMMDD'))
            end as subs_activation_dt,  -- дата активации абонента,
        coalesce(t_services.date_end, to_date('29991231',
                'YYYYMMDD'))
                as subs_cancellation_dt,
        round(t_services.house_id) ||'#'||
            coalesce(t_services.flat, '0')
            as address_key,
        round(t_services.svc_id)::text
            as service_key,
        round(t_services.user_id)::text
            as account_key,
        case when t_services.svctype = '0'
            then round(t_services.dev_id)::text
            else NULL
            end
            as subs_code,
        case when t_services.date_begin
                < to_date('19000101', 'YYYYMMDD')
            then to_date('19000101', 'YYYYMMDD')
            else coalesce(t_services.date_begin,
                to_date('19000101', 'YYYYMMDD'))
        end as start_date,          -- дата начала действия записи
        coalesce(t_services.date_end,
            to_date('29991231', 'YYYYMMDD'))
            as end_date,
      xref.sub_make,
      et.business_service_key as  business_service,
      round(t_services.service_id) as service_id,
      round(t_services.serv_first_id) as serv_first_id,
      case
          when coalesce(round(ttr.coef), round(t_user_type_ref.coef))
                = 1 then 0
          when coalesce(round(ttr.coef), round(t_user_type_ref.coef))
                = 0
                and coalesce(round(tu.user_type_id),
                    round(t_users.user_type_id))
                    in (1001521460324, 1001521459747, 38, 23, 22, 20)
                    then 0
          else 1
    end as duty_num_key,
    case
        when coalesce(round(ttr.coef), round(t_user_type_ref.coef))
            = 1 then 0
        when coalesce(round(ttr.coef), round(t_user_type_ref.coef))
            = 0
            and coalesce(round(tu.user_type_id),
                round(t_users.user_type_id))
                    in (1001521460324, 1001521459747, 38, 23, 22, 20)
                then 1
        else 0
    end as center_num_key

from edw_ods.t_000007_t_services t_services
join edw_stg_dds.t_dim_service_xref_start xref
        on xref.source_key = round(t_services.svc_id)::text
        and to_date('20190630', 'YYYYMMDD')+ INTERVAL '1 MONTH - 1 second'  between xref.eff_dttm and xref.exp_dttm
        and xref.region_id = 'VOLGA'
    join edw_dds.dim_service et
        on et.service_key = xref.service_key
        and to_date('20190630', 'YYYYMMDD') + INTERVAL '1 MONTH - 1 second' between et.eff_dttm and et.exp_dttm
LEFT JOIN edw_stg_dds.t_000007_dim_subs_parent_child ss
    ON round(t_services.serv_first_id)::text = ss.service_first_id_child
    and ss.business_service = et.business_service_key::text
/* parent-child */
left join edw_ods.t_000007_t_users t_users
    on round(t_services.user_id) = round(t_users.user_id)
    and t_users.DELETED_IND = 0
    and to_date('20190630', 'YYYYMMDD') + INTERVAL '1 day - 1 second' + interval '6 days' between t_users.eff_dttm and t_users.exp_dttm
left join edw_ods.t_000007_t_user_type_ref t_user_type_ref
    on round(t_user_type_ref.user_type_id) = round(t_users.user_type_id)
    and t_user_type_ref.DELETED_IND = 0
    and to_date('20190630', 'YYYYMMDD') + INTERVAL '1 day - 1 second' between t_user_type_ref.eff_dttm and t_user_type_ref.exp_dttm
left join edw_ods.t_000007_t_vip_sp t_vip_sp
    on round(t_users.user_id) = round(t_vip_sp.user_id_sp)
    and t_vip_sp.deleted_ind = 0
    and to_date('20190630', 'YYYYMMDD') + INTERVAL '1 day - 1 second' + interval '6 days'  between t_vip_sp.eff_dttm and t_vip_sp.exp_dttm
left join edw_ods.t_000007_t_users tu
    on round(tu.user_id) = round(t_vip_sp.user_id_vip)
    and tu.deleted_ind = 0
    and to_date('20190630', 'YYYYMMDD') + INTERVAL '1 day - 1 second'  + interval '6 days' between tu.eff_dttm and tu.exp_dttm
left join edw_ods.t_000007_t_user_type_ref ttr
    on round(ttr.user_type_id) = round(tu.user_type_id)
    and ttr.DELETED_IND = 0
    and to_date('20190630', 'YYYYMMDD') + INTERVAL '1 day - 1 second' between ttr.eff_dttm and ttr.exp_dttm
where t_services.DELETED_IND = 0
    and t_services.date_begin
        <= coalesce(t_services.date_end, to_date('29991231', 'YYYYMMDD'))
    and to_date('20190630', 'YYYYMMDD')
        + INTERVAL '1 day - 1 second' + interval '6 days'
        between t_services.eff_dttm and t_services.exp_dttm
and not exists (
    select 1
    from edw_ods.t_000007_t_services a
    join edw_stg_dds.t_dim_service_xref_start xref
        on xref.source_key = round(a.svc_id)::text
        and to_date('20190630', 'YYYYMMDD') + INTERVAL '1 MONTH - 1 second' between xref.eff_dttm and xref.exp_dttm
        and xref.region_id = 'VOLGA'
    join edw_dds.dim_service et
        on et.service_key = xref.service_key
        and to_date('20190630', 'YYYYMMDD')+ INTERVAL '1 MONTH - 1 second' between et.eff_dttm and et.exp_dttm
    JOIN edw_dds.dim_business_service bs
        ON bs.business_service_key = et.business_service_key
        and bs.business_service_key = 10101
        and to_date('20190630', 'YYYYMMDD')+ INTERVAL '1 MONTH - 1 second' between bs.eff_dttm and bs.exp_dttm
    where   a.deleted_ind = 0
        and a.svctype = '0'
        and round(a.service_id)=round(t_services.service_id)
        and round(a.svc_id)=round(t_services.svc_id)
        and (upper(a.phone) like '%П%'
            or a.phone like '%М%'
            or a.phone like '%К%'
            or a.phone like '%Д%'
            or a.phone like '%С%'
            or a.phone like '%В%')
        and to_date('20190630', 'YYYYMMDD')
            + INTERVAL '1 day - 1 second' + interval '6 days'
            between a.eff_dttm and a.exp_dttm
                )
) subs_pr_sub
where 1=1
and subs_pr_sub.sub_make = 1
) sub_pr_bs
) s
) subs_pr_30days
) core_logic
) subs
) v_calc_md5
) v_calc_prev_next
) v_calc_wrong_versions
where is_wrong_version = 'N'
) v_skip_wrong_versions
) v_calc_end_date
) v_dttm
where start_date <= end_date
) v_subs_activation_dt;

commit;
analyse edw_stg_dds.t_000007_dim_subs;