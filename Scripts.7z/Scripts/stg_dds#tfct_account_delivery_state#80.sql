/*rev.36895 от 02.09.2019*/
truncate table edw_stg_dds.t_000080_tfct_account_delivery_state;
insert into edw_stg_dds.t_000080_tfct_account_delivery_state 
(
	account_key,
	snap_dt,
	delivery_type_key,
	manager_fio,
	src_id,
	deleted_ind
)
select 
src_id||'#'||user_id account_key
, date_trunc('month',to_date('20190630', 'YYYYMMDD')) snap_dt  
, case 
	when sum(case when  t.cod = '53117' then 1 else 0 end) > 0 then 0
	when sum(case when  t.cod = '51050' then 1 else 0 end) > 0 then 19
	when sum(case when  t.cod = '51054' then 1 else 0 end) > 0 then 18
	when sum(case when  t.cod = '51057' then 1 else 0 end) > 0 then 28
	when sum(case when  t.cod in ('51055','51049') then 1 else 0 end) > 0 then 17
	when sum(case when  t.cod = '53103' then 1 else 0 end) > 0 then 6
	when sum(case when  t.cod = '51056' then 1 else 0 end) > 0 then 14
	when sum(case when  t.cod = '53050' then 1 else 0 end) > 0 then 3
	when sum(case when  t.cod = '53105' then 1 else 0 end) > 0 then 1
	when sum(case when  t.cod = '98452' then 1 else 0 end) > 0 then 2
	else -1 
end delivery_type_key
, max(content_str) as fio
, 000080::smallint as src_id
, deleted_ind
from 
(
	select 
		u.user_id
		,u.src_id
		,first_value(nc.content_str) OVER (PARTITION BY u.user_id 
							ORDER BY nc.date_begin DESC, nc.action_id desc
							ROWS BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING) content_str
		,t.cod
		,coalesce(nullif(nc.deleted_ind, 0), nullif(s.deleted_ind, 0), nullif(t.deleted_ind, 0), u.deleted_ind) as deleted_ind
	from edw_ods.t_000080_t_users u
		left join edw_ods.t_000080_n_titul_treaty nt
		on (1 = 1 
			and nt.id_host=u.user_id 
			and to_date('20190630', 'YYYYMMDD') between coalesce(nt.date_begin,to_date('19000101', 'YYYYMMDD')) and coalesce(nt.date_end,to_date('29991231', 'YYYYMMDD'))
			and nt.exp_dttm = to_date('29991231', 'YYYYMMDD')
			)
		left join edw_ods.t_000080_n_content_treaty nc
		on (1 = 1 
			and nc.id_treaty=nt.id_treaty 
			and nc.id_obj in (1000140)
			and to_date('20190630', 'YYYYMMDD') >= nc.date_begin
			and nc.exp_dttm = to_date('29991231', 'YYYYMMDD') 
			and nc.deleted_ind = '0'
			)
		left join edw_ods.t_000080_t_services s 
		on ( 1 = 1 
			and u.user_id = s.user_id
			and to_date('20190630', 'YYYYMMDD') between s.date_begin and coalesce(s.date_end,to_date('29991231', 'YYYYMMDD'))
			and s.exp_dttm = to_date('29991231', 'YYYYMMDD')
			and s.deleted_ind = '0'
			)
		left join edw_ods.t_000080_t_svc_ref t 
		on ( 1 = 1
			and t.svc_id=s.svc_id 
			and (t.full_name like '%эл.документооборот%' 
			or t.cod in ('51050','51054','51055','51057','53117','53103','51056','53050','53105', '98452')) 
			and t.deleted_ind = '0'
			and to_date('20190630', 'YYYYMMDD') between t.eff_dttm and t.exp_dttm
			)
	where  1=1
		and (t.cod is not null 
		or nc.content_str is not null)
		and to_date('20190630', 'YYYYMMDD') between coalesce(u.date_begin,to_date('19000101', 'YYYYMMDD')) and coalesce(u.date_end,to_date('29991231', 'YYYYMMDD'))
		and u.exp_dttm = to_date('29991231', 'YYYYMMDD')
		and u.deleted_ind = '0'
) t
where deleted_ind = '0'
group by src_id, account_key, deleted_ind;
commit;
analyse edw_stg_dds.t_000080_tfct_account_delivery_state;