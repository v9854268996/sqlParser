/*rev.56273 27.04.2020*/
  
truncate edw_stg_dds.t_000006_dim_account;
insert into edw_stg_dds.t_000006_dim_account
(
account_key
, account_name
, partner_key
, agent_scheme_key
, parent_account_key
, duty_num_key
, center_num_key
, branch_key
, region_key
, cession_date
, src_id
, load_dttm
, eff_dttm
, exp_dttm
, start_date
, end_date
)
with ttr as
(
SELECT round(tu.user_type_id) AS user_type_id, round(tu.user_id) AS user_id, round(ttr.coef) AS coef, round(tu.dept_id) AS dept_id, hub.branch_key, round(tu.billing_id) AS billing_id
FROM edw_ods.t_000001_t_saldo tu
LEFT JOIN edw_ods.t_000001_t_user_type_ref ttr
ON round(ttr.user_type_id) = round(tu.user_type_id)
AND ttr.deleted_ind <> 1
AND to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second'
    between ttr.eff_dttm AND ttr.exp_dttm
LEFT JOIN edw_dds.hub_dim_branch hub
ON round(tu.dept_id)::text = hub.source_key::text
AND hub.src_id = 1
AND to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second'
    between hub.eff_dttm AND hub.exp_dttm
WHERE tu.billing_id <= substr('20190601', 1, 6)::int
and tu.tech_dt <= to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second'

UNION ALL

SELECT round(tu.user_type_id) AS user_type_id, round(tu.user_id) AS user_id, round(ttr.coef) AS coef, round(tu.dept_id) AS dept_id, hub.branch_key, round(tu.billing_id) AS billing_id
FROM edw_ods.t_000002_t_saldo tu
LEFT JOIN edw_ods.t_000002_t_user_type_ref ttr
ON round(ttr.user_type_id) = round(tu.user_type_id)
AND ttr.deleted_ind <> 1
AND to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second'
    between ttr.eff_dttm AND ttr.exp_dttm
LEFT JOIN edw_dds.hub_dim_branch hub
ON round(tu.dept_id)::text = hub.source_key::text
AND hub.src_id = 2
AND to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second'
    between hub.eff_dttm AND hub.exp_dttm
WHERE tu.billing_id <= substr('20190601', 1, 6)::int
and tu.tech_dt <= to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second'

UNION ALL

SELECT round(tu.user_type_id) AS user_type_id, round(tu.user_id) AS user_id, round(ttr.coef) AS coef, round(tu.dept_id) AS dept_id, hub.branch_key, round(tu.billing_id) AS billing_id
FROM edw_ods.t_000003_t_saldo tu
LEFT JOIN edw_ods.t_000003_t_user_type_ref ttr
ON round(ttr.user_type_id) = round(tu.user_type_id)
AND ttr.deleted_ind <> 1
AND to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second'
    between ttr.eff_dttm AND ttr.exp_dttm
LEFT JOIN edw_dds.hub_dim_branch hub
ON round(tu.dept_id)::text = hub.source_key::text
AND hub.src_id = 3
AND to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second'
    between hub.eff_dttm AND hub.exp_dttm
WHERE tu.billing_id <= substr('20190601', 1, 6)::int
and tu.tech_dt <= to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second'

UNION ALL

SELECT round(tu.user_type_id) AS user_type_id, round(tu.user_id) AS user_id, round(ttr.coef) AS coef, round(tu.dept_id) AS dept_id, hub.branch_key, round(tu.billing_id) AS billing_id
FROM edw_ods.t_000004_t_saldo tu
LEFT JOIN edw_ods.t_000004_t_user_type_ref ttr
ON round(ttr.user_type_id) = round(tu.user_type_id)
AND ttr.deleted_ind <> 1
AND to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second'
    between ttr.eff_dttm AND ttr.exp_dttm
LEFT JOIN edw_dds.hub_dim_branch hub
ON round(tu.dept_id)::text = hub.source_key::text
AND hub.src_id = 4
AND to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second'
    between hub.eff_dttm AND hub.exp_dttm
WHERE tu.billing_id <= substr('20190601', 1, 6)::int
and tu.tech_dt <= to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second'

UNION ALL

SELECT round(tu.user_type_id) AS user_type_id, round(tu.user_id) AS user_id, round(ttr.coef) AS coef, round(tu.dept_id) AS dept_id, hub.branch_key, round(tu.billing_id) AS billing_id
FROM edw_ods.t_000005_t_saldo tu
LEFT JOIN edw_ods.t_000005_t_user_type_ref ttr
ON round(ttr.user_type_id) = round(tu.user_type_id)
AND ttr.deleted_ind <> 1
AND to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second'
    between ttr.eff_dttm AND ttr.exp_dttm
LEFT JOIN edw_dds.hub_dim_branch hub
ON round(tu.dept_id)::text = hub.source_key::text
AND hub.src_id = 5
AND to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second'
    between hub.eff_dttm AND hub.exp_dttm
WHERE tu.billing_id <= substr('20190601', 1, 6)::int
and tu.tech_dt <= to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second'

UNION ALL

SELECT round(tu.user_type_id) AS user_type_id, round(tu.user_id) AS user_id, round(ttr.coef) AS coef, round(tu.dept_id) AS dept_id, hub.branch_key, round(tu.billing_id) AS billing_id
FROM edw_ods.t_000006_t_saldo tu
LEFT JOIN edw_ods.t_000006_t_user_type_ref ttr
ON round(ttr.user_type_id) = round(tu.user_type_id)
AND ttr.deleted_ind <> 1
AND to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second'
    between ttr.eff_dttm AND ttr.exp_dttm
LEFT JOIN edw_dds.hub_dim_branch hub
ON round(tu.dept_id)::text = hub.source_key::text
AND hub.src_id = 6
AND to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second'
    between hub.eff_dttm AND hub.exp_dttm
WHERE tu.billing_id <= substr('20190601', 1, 6)::int
and tu.tech_dt <= to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second'

UNION ALL

SELECT round(tu.user_type_id) AS user_type_id, round(tu.user_id) AS user_id, round(ttr.coef) AS coef, round(tu.dept_id) AS dept_id, hub.branch_key, round(tu.billing_id) AS billing_id
FROM edw_ods.t_000007_t_saldo tu
LEFT JOIN edw_ods.t_000007_t_user_type_ref ttr
ON round(ttr.user_type_id) = round(tu.user_type_id)
AND ttr.deleted_ind <> 1
AND to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second'
    between ttr.eff_dttm AND ttr.exp_dttm
LEFT JOIN edw_dds.hub_dim_branch hub
ON round(tu.dept_id)::text = hub.source_key::text
AND hub.src_id = 7
AND to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second'
    between hub.eff_dttm AND hub.exp_dttm
WHERE tu.billing_id <= substr('20190601', 1, 6)::int
and tu.tech_dt <= to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second'

UNION ALL

SELECT round(tu.user_type_id) AS user_type_id, round(tu.user_id) AS user_id, round(ttr.coef) AS coef, round(tu.dept_id) AS dept_id, hub.branch_key, round(tu.billing_id) AS billing_id
FROM edw_ods.t_000008_t_saldo tu
LEFT JOIN edw_ods.t_000008_t_user_type_ref ttr
ON round(ttr.user_type_id) = round(tu.user_type_id)
AND ttr.deleted_ind <> 1
AND to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second'
    between ttr.eff_dttm AND ttr.exp_dttm
LEFT JOIN edw_dds.hub_dim_branch hub
ON round(tu.dept_id)::text = hub.source_key::text
AND hub.src_id = 8
AND to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second'
    between hub.eff_dttm AND hub.exp_dttm
WHERE tu.billing_id <= substr('20190601', 1, 6)::int
and tu.tech_dt <= to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second'

UNION ALL

SELECT round(tu.user_type_id) AS user_type_id, round(tu.user_id) AS user_id, round(ttr.coef) AS coef, round(tu.dept_id) AS dept_id, hub.branch_key, round(tu.billing_id) AS billing_id
FROM edw_ods.t_000009_t_saldo tu
LEFT JOIN edw_ods.t_000009_t_user_type_ref ttr
ON round(ttr.user_type_id) = round(tu.user_type_id)
AND ttr.deleted_ind <> 1
AND to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second'
    between ttr.eff_dttm AND ttr.exp_dttm
LEFT JOIN edw_dds.hub_dim_branch hub
ON round(tu.dept_id)::text = hub.source_key::text
AND hub.src_id = 9
AND to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second'
    between hub.eff_dttm AND hub.exp_dttm
WHERE tu.billing_id <= substr('20190601', 1, 6)::int
and tu.tech_dt <= to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second'

UNION ALL

SELECT round(tu.user_type_id) AS user_type_id, round(tu.user_id) AS user_id, round(ttr.coef) AS coef, round(tu.dept_id) AS dept_id, hub.branch_key, round(tu.billing_id) AS billing_id
FROM edw_ods.t_000010_t_saldo tu
LEFT JOIN edw_ods.t_000010_t_user_type_ref ttr
ON round(ttr.user_type_id) = round(tu.user_type_id)
AND ttr.deleted_ind <> 1
AND to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second'
    between ttr.eff_dttm AND ttr.exp_dttm
LEFT JOIN edw_dds.hub_dim_branch hub
ON round(tu.dept_id)::text = hub.source_key::text
AND hub.src_id = 10
AND to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second'
    between hub.eff_dttm AND hub.exp_dttm
WHERE tu.billing_id <= substr('20190601', 1, 6)::int
and tu.tech_dt <= to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second'

UNION ALL

SELECT round(tu.user_type_id) AS user_type_id, round(tu.user_id) AS user_id, round(ttr.coef) AS coef, round(tu.dept_id) AS dept_id, hub.branch_key, round(tu.billing_id) AS billing_id
FROM edw_ods.t_000011_t_saldo tu
LEFT JOIN edw_ods.t_000011_t_user_type_ref ttr
ON round(ttr.user_type_id) = round(tu.user_type_id)
AND ttr.deleted_ind <> 1
AND to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second'
    between ttr.eff_dttm AND ttr.exp_dttm
LEFT JOIN edw_dds.hub_dim_branch hub
ON round(tu.dept_id)::text = hub.source_key::text
AND hub.src_id = 11
AND to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second'
    between hub.eff_dttm AND hub.exp_dttm
WHERE tu.billing_id <= substr('20190601', 1, 6)::int
and tu.tech_dt <= to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second'

UNION ALL

SELECT round(tu.user_type_id) AS user_type_id, round(tu.user_id) AS user_id, round(ttr.coef) AS coef, round(tu.dept_id) AS dept_id, hub.branch_key, round(tu.billing_id) AS billing_id
FROM edw_ods.t_000012_t_saldo tu
LEFT JOIN edw_ods.t_000012_t_user_type_ref ttr
ON round(ttr.user_type_id) = round(tu.user_type_id)
AND ttr.deleted_ind <> 1
AND to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second'
    between ttr.eff_dttm AND ttr.exp_dttm
LEFT JOIN edw_dds.hub_dim_branch hub
ON round(tu.dept_id)::text = hub.source_key::text
AND hub.src_id = 12
AND to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second'
    between hub.eff_dttm AND hub.exp_dttm
WHERE tu.billing_id <= substr('20190601', 1, 6)::int
and tu.tech_dt <= to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second'
)
select
account_key
, account_name
, partner_key
, agent_scheme_key
, parent_account_key
, duty_num_key
, center_num_key
, branch_key
, region_key
, cession_date
, src_id
, load_dttm
, eff_dttm
, case
    when date_trunc('day',exp_dttm)::timestamp = to_date('29991231', 'YYYYMMDD')
        then date_trunc('day',exp_dttm)::timestamp
        else exp_dttm
    end as exp_dttm
, eff_dttm as start_date
, case
    when date_trunc('day',exp_dttm)::timestamp = to_date('29991231', 'YYYYMMDD')
        then date_trunc('day',exp_dttm)::timestamp
        else exp_dttm
    end as end_date
from
(
    select
    t_users.src_id||'#'||round(t_users.user_id) as account_key
    , t_users.account as account_name
    , round(t_users.user_id) as partner_key
    , 1 as agent_scheme_key
    , t_vip_sp.user_id_vip as parent_account_key
    , case
        when round(t_user_type_ref.user_type_id) in (1001521460324, 1001521459747, 38, 23, 22, 20)
            then 0
        when coalesce(round(ttr.coef),round(t_user_type_ref.coef)) = 1
            then 0
        when coalesce(round(ttr.coef),round(t_user_type_ref.coef)) = 0
            and coalesce(round(ttr.user_type_id),round(t_saldo.user_type_id),round(t_users.user_type_id)) in (1001521460324, 1001521459747, 38, 23, 22, 20)
            then 0
            else 1
        end as duty_num_key
    , case
        when round(t_user_type_ref.user_type_id) in (1001521460324, 1001521459747, 38, 23, 22, 20)
            then 1
        when coalesce(round(ttr.coef), round(t_user_type_ref.coef)) = 1
            then 0
        when coalesce(round(ttr.coef), round(t_user_type_ref.coef)) = 0
            and coalesce(round(ttr.user_type_id),round(t_saldo.user_type_id),round(t_users.user_type_id)) in (1001521460324, 1001521459747, 38, 23, 22, 20)
            then 1
            else 0
        end as center_num_key
    , coalesce(round(t_saldo.dept_id),round(t_users.dept_id)) as branch_key
    , coalesce(round(t_saldo.dept_id),round(t_users.dept_id)) as region_key
	, cession.cession_date
    , t_users.src_id as src_id
    , now() as load_dttm
    , coalesce(decode(t_saldo.billing_id,t_saldo.min_billing_id,to_date('19000101', 'YYYYMMDD')), to_date(round(t_saldo.billing_id)::text, 'YYYYMM'), to_date('19000101' , 'YYYYMMDD'))
        as eff_dttm
    , coalesce(decode(t_saldo.billing_id,t_saldo.max_billing_id,to_date('29991231', 'YYYYMMDD')), to_date(round(t_saldo.billing_id)::text, 'YYYYMM') + interval '1 month - 1 day', to_date('29991231', 'YYYYMMDD')) + interval '1 day - 1 second'
        as exp_dttm
    from edw_ods.t_000006_t_users t_users
    left join
    (
        select
        dept_id
        , user_id
        , user_type_id
        , billing_id
        , max(billing_id) over (PARTITION BY user_id) as max_billing_id
        , min(billing_id) over (PARTITION BY user_id) as min_billing_id
        from edw_ods.t_000006_t_saldo
        where billing_id <= substr('20190601', 1, 6)::int
            and tech_dt <= to_date(substr('20190601', 1, 6), 'YYYYMM')
    ) t_saldo
        on
            t_users.user_id = t_saldo.user_id
        and t_users.deleted_ind = 0
    inner join edw_ods.t_000006_t_user_type_ref t_user_type_ref
        on
            round(t_user_type_ref.user_type_id) = round(t_users.user_type_id)
        and t_user_type_ref.deleted_ind = 0
        AND to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second' 
            between t_user_type_ref.eff_dttm and t_user_type_ref.exp_dttm
    left join
    (
        select
        round(sp.user_id_sp) as user_id_sp
        , vip.user_id_vip as user_id_vip
        , round(sp.dept_id_vip) as dept_id_vip
        , case
            when date_begin = min(date_begin) over (PARTITION BY vip.user_id_sp)
                then to_date('19000101', 'YYYYMMDD')
                else date_begin
            end as date_begin_v2
        , case
            when coalesce(date_end, to_date('29991231', 'YYYYMMDD')) = max(coalesce(date_end, to_date('29991231', 'YYYYMMDD'))) over (PARTITION BY vip.user_id_sp)
                then to_date('29991231', 'YYYYMMDD')
                else coalesce(date_end, to_date('29991231', 'YYYYMMDD'))
            end as date_end_v2
        from edw_ods.t_000006_t_vip_sp sp
        inner join
            edw_ods.t_000006_t_vip vip
            on
                to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second' + interval '6 days'
                    between vip.eff_dttm and vip.exp_dttm
            and sp.user_id_sp = vip.user_id_sp
        where   1=1
            AND to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second' + interval '6 days'
                between sp.eff_dttm and sp.exp_dttm
            and sp.deleted_ind = 0 and vip.deleted_ind = 0
    ) t_vip_sp
        on
            round(t_users.user_id) = t_vip_sp.user_id_sp
        and to_date(round(t_saldo.billing_id)::text, 'YYYYMM')
            between date_begin_v2 and date_end_v2
    left join edw_dds.hub_dim_branch hub
        on
            round(t_vip_sp.dept_id_vip)::text = hub.source_key
        and t_users.src_id = hub.src_id
        AND to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second'
            between hub.eff_dttm and hub.exp_dttm
    left join ttr
        on
            ttr.user_id = round(t_vip_sp.user_id_vip)
        and hub.branch_key = ttr.branch_key
        and round(t_saldo.billing_id) = ttr.billing_id
    left join (select user_id , min(pay_date) cession_date
				from edw_ods.t_000006_t_pay_correction 
				where 1=1
				and pay_doc_id = 1801
				and tech_dt >= date_trunc('year',to_date(substr('20190630', 1, 8), 'YYYYMMDD')) - INTERVAL '12 months'
			group by user_id) cession
		on t_users.user_id = cession.user_id		
    where
        to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second' + interval '6 days'
            between t_users.eff_dttm and t_users.exp_dttm
)s;
commit;
 analyse edw_stg_dds.t_000006_dim_account;