/*rev.58629  от 25.05.2020*/

truncate table edw_stg_dm_feb.tfct_charge_address_1_prt_p000029;

insert into edw_stg_dm_feb.tfct_charge_address_1_prt_p000029
(
PERIOD,
MRF_CODE,
MRF_NAME,
RF_CODE,
RF_NAME,
USER_ID,
INN,
USER_NAME,
ACCOUNT,
SUMM_NO_NDS,
SUBS_ID,
SVC_ID,
SVC_START_DATE,
SVC_NAME,
R_ACC,		
R_ACC_DEF,
SEGMENT_NAME,
SEGMENT_NAME_DETAIL,
ADR_FULL_SOURCE,
GID_ORPON_ID,
ORPON_ADDRESS,
HOUSE,
STREET,
TOWN,
CONTRACT_ID,
CONTRACT_NUM,
SOURCE_SYSTEM,
load_dttm,
src_id

)
 select   T_period.Dfdatebegin as period
  ,branch_mrf.branch_key as MRF_CODE
  ,branch_mrf.short_name as MRF_NAME
  ,branch.branch_key as RF_CODE 
  ,branch.short_name as  RF_NAME
  ,T_servnach.dfabonent  as USER_ID 
  ,T_ABONENT.DFINN as INN
  ,coalesce (T_ABONENT.DFNAME,   T_ABONENT.dffamili ||' '|| T_ABONENT.dfim ||' '|| T_ABONENT.dfotch )  as USER_NAME
  ,dog.DFACCOUNT as  ACCOUNT
  ,sum(T_servnach.DFSUMMA) as SUMM_NO_NDS
  ,coalesce(T_servnach.dfservconst, T_servnach.dfonenach, -1 )  as  subs_id
  --,T_servnach.dfservice
  ,d_bus_service.business_service_key  as SVC_ID
  ,coalesce(oncsc.dfdatebegin, onc.dfdatebegin  )  as SVC_START_DATE
  --,T_SERVICE.dfnamesmall 
  ,d_bus_service.business_service_name as SVC_NAME
  ,rtk_det.service_rtk_detail_code as R_ACC
  ,rtk_det.service_rtk_detail_name as R_ACC_DEF
  ,seg.segment_name as SEGMENT_NAME
  ,seg.budget_segmentation as SEGMENT_NAME_DETAIL
  ,case when TCITYTYPE.dfnamesmall ='г.' then  decode (TCITYTYPE.dfnamesmall, null ,'', TCITYTYPE.dfnamesmall||' '|| tregion.DFNAME ||' ')
                 else case when TCITYTYPE2.dfnamesmall ='г.' then decode (TCITYTYPE.dfnamesmall, null ,'', TCITYTYPE.dfnamesmall||' '|| tregion.DFNAME ||' ')
               || decode (TCITYTYPE2.dfnamesmall, null ,'', TCITYTYPE2.dfnamesmall||' '|| TDISTRICT.DFNAME ||' ') 
                  else decode (TCITYTYPE2.dfnamesmall, null ,'', TCITYTYPE2.dfnamesmall||' '|| TDISTRICT.DFNAME ||' ') 
                 ||  decode (TCITYTYPE.dfnamesmall, null ,'', TCITYTYPE.dfnamesmall||' '|| tregion.DFNAME ||' ')
                 || decode (TCITYTYPE3.dfnamesmall, null ,'', TCITYTYPE3.dfnamesmall||' '|| city.DFNAME||' '  )      end end           
                 || ' ' || SUBSTRing (tstreettype.dfnamesmall
                 || ' '
                       || tstreet.dfname
                       || DECODE (oncsc.dfhouse, NULL, '', ' д.' || TRIM (oncsc.dfhouse))
                       || DECODE (oncsc.dfkorpus, NULL, '', ' корп.' || TRIM (oncsc.dfkorpus))
                       || DECODE (oncsc.dfflat, NULL, '', ' кв.' || LPAD (TRIM (oncsc.dfflat), 5))
                       || DECODE (oncsc.dfromm, NULL, '', ' комн.' || TRIM (oncsc.dfromm))  ,1,255)   || ' индекс ' ||  oncsc.DFINDEX as ADR_FULL_SOURCE
  ,oncsc.DFORPON_HOUSE::numeric  as GID_ORPON_ID
  ,house2.adr_adm_ter as ORPON_ADDRESS
  ,oncsc.dfhouse as  HOUSE
  ,TSTREET.dfname as STREET 
  ,TREGION.DFNAME as TOWN
  ,dog1.DFDOGOVOR as CONTRACT_ID
  ,dog1.dfnumber as CONTRACT_NUM
  ,000029 as SOURCE_SYSTEM
  , now()
  , 000029 as src_id
from edw_ods.t_000029_Tperiod t_period  
        left join edw_ods.t_000029_Tservnach T_servnach 
                on ( 1=1
                        and t_period.dfperiod=T_servnach.dfperiod
                        ) 
      left join edw_ods.t_000029_TABONENT  T_ABONENT 
                on ( 1=1
                        and T_ABONENT.dfabonent=T_servnach.dfabonent
                        ) 
        left join edw_ods.t_000029_TSERVICE_GLOB_LINK link1 
                on ( 1=1
                        and link1.DFSERVICE=T_servnach.dfservice 
                         and link1.dfdateend is null  
                         and link1.deleted_ind='0'   
                     )
        left join edw_ods.t_000029_TSERVICE_GLOB  glob 
                on ( 1=1
                     and glob.DFSERVICE_GLOB=link1.DFSERVICE_GLOB  
					 and glob.deleted_ind='0'
                        )
        left join edw_ods.t_000029_tonenach onc  
                on ( 1=1 
                         and T_servnach.dfonenach=onc.dfonenach 
						 and onc.deleted_ind='0'
                    )
        left join edw_ods.t_000029_tservconst oncsc  
                on ( 1=1 
                         and T_servnach.dfservconst=oncsc.dfservconst
						 and oncsc.deleted_ind='0'
                    )
        left join edw_ods.T_000029_TELS_DOGOVOR_LINK dog_link
    on  ( 1 = 1
    and dog_link.dfdogovor_ref=T_servnach.DFDOGOVOR 
    and dog_link.dfdateend is null
	and dog_link.deleted_ind='0'
        )
        
        left join edw_ods.t_000029_TDOGOVOR dog  
                on ( 1=1 
                         and dog.DFDOGOVOR=dog_link.dfels_dogovor 
						 and dog.deleted_ind='0'
                    )
        left join edw_ods.t_000029_TDOGOVOR dog1  
                on ( 1=1 
                         and dog1.DFDOGOVOR=T_servnach.DFDOGOVOR 
						 and dog1.deleted_ind='0'
                    )
        left join edw_ods.t_000029_TSERVICE t_service   
                on ( 1=1 
                         and t_service.dfservice=T_servnach.dfservice
						 and t_service.deleted_ind='0'						 
                    )
        left join edw_ods.t_000148_ENT_AS_HOUSE house2  
                on ( 1=1 
                         and house2.orponid::text=oncsc.DFORPON_HOUSE  
                         and  house2.livestatus ='1'  
						 and house2.deleted_ind ='0' 
                     )


        left join edw_ods.t_000029_TDOG_DOP_SEGMENT dop_seg  
                on ( 1=1 
                         and dop_seg.dfdogovor=dog.dfdogovor 
                         and dop_seg.deleted_ind='0'   
                         and dop_seg.dfdateend is  null
                        )
     left join edw_ods.t_000029_TSTREET tstreet
  on ( 1 = 1
    and tstreet.dfstreet = oncsc.DFSTREET
	and tstreet.deleted_ind='0' 
    )
   left join  edw_ods.t_000029_TSTREETTYPE TSTREETTYPE 
    on  ( 1 = 1
     and tstreettype.DFSTREETTYPE=tstreet. DFSTREETTYPE
        )
  left join edw_ods.t_000029_TCITY  city on city.DFCITY=oncsc.DFCITY  and city.deleted_ind='0' 
  left join edw_ods.t_000029_TREGION TREGION on TREGION.DFREGION=oncsc.DFREGION  and TREGION.deleted_ind='0' 
  left join edw_ods.t_000029_TDISTRICT TDISTRICT on TDISTRICT.DFDISTRICT=oncsc.DFDISTRICT   and TDISTRICT.deleted_ind='0' 
  left join edw_ods.t_000029_TCITYADD TCITYADD on TCITYADD.DFCITYADD=oncsc.DFCITYADD   and TCITYADD.deleted_ind='0' 
  left join edw_ods.t_000029_TCOUNTRY TCOUNTRY on TCOUNTRY.DFCOUNTRY=TREGION.DFCOUNTRY  and TCOUNTRY.deleted_ind='0' 
  left join edw_ods.t_000029_TCITYTYPE TCITYTYPE on TCITYTYPE.dfcitytype=TREGION.dfCITYTYPE    and TCITYTYPE.deleted_ind='0' 
  left join edw_ods.t_000029_TCITYTYPE TCITYTYPE2 on TCITYTYPE2.dfcitytype=TDISTRICT.dfCITYTYPE   and TCITYTYPE2.deleted_ind='0' 
  left join edw_ods.t_000029_TCITYTYPE TCITYTYPE3 on TCITYTYPE3.dfcitytype=city.dfCITYTYPE   and TCITYTYPE3.deleted_ind='0' 
        left join  edw_dds.hub_dim_segment hds  
                on ( 1=1 
                         and hds.source_key= round(dop_seg.dfactivity_dop_segment, 0)::text  
                         and hds.src_id=000029
                        and hds.exp_dttm = to_date('29991231', 'YYYYMMDD') 
                    )
        left join  edw_dds.dim_segment seg 
                on ( 1=1 
                         and seg.segment_key=hds.segment_key 
                         and seg.exp_dttm = to_date('29991231', 'YYYYMMDD') 
                    ) 
        left join edw_dds.hub_dim_branch hdb 
            on (1 = 1 
            and   substring( T_servnach.DFBRANCH ::text, 1 , position('.' in  T_servnach.DFBRANCH::text  )-1 )=substring(hdb.source_key,position(';' in  hdb.source_key )+1,length(hdb.source_key)-position(';' in  hdb.source_key ))
            and hdb.src_id=000029
            and hdb.exp_dttm=to_date('29991231', 'YYYYMMDD')
            )
            
         left join edw_dds.dim_branch  branch
           on (1 = 1 
           and branch.branch_key = hdb.branch_key
           and branch.exp_dttm=to_date('29991231', 'YYYYMMDD')
           )
    left join edw_dds.dim_branch  branch_mrf
           on (1 = 1 
           and (branch.parent_branch_key||'00')::numeric = branch_mrf.branch_key
           and branch_mrf.exp_dttm=to_date('29991231', 'YYYYMMDD')
           )
      left join edw_dds.hub_dim_service hsrv
            on (1 = 1 
            and substring( T_servnach.dfservice ::text, 1 , position('.' in  T_servnach.dfservice::text  )-1 )=substring(hsrv.source_key,position(';' in  hsrv.source_key )+1,length(hsrv.source_key)-position(';' in  hsrv.source_key ))
            and hsrv.src_id=000029
            and hsrv.exp_dttm=to_date('29991231', 'YYYYMMDD')
            )
   left join edw_dds.dim_service d_service
           on (1 = 1 
           and d_service.service_key =hsrv.service_key
           and d_service.exp_dttm=to_date('29991231', 'YYYYMMDD')
           )
	left join edw_dds.dim_business_service  d_bus_service  
           on (1 = 1 
           and d_service.business_service_key =d_bus_service.business_service_key
           and d_bus_service.exp_dttm=to_date('29991231', 'YYYYMMDD')
           )  	   
   left join edw_dds.dim_service_rtk_detail   rtk_det
           on (1 = 1 
           and d_service.service_rtk_detail_key =rtk_det.service_rtk_detail_key
           and rtk_det.exp_dttm=to_date('29991231', 'YYYYMMDD')
           )
 
 where 1=1
and  t_period.Dfdatebegin= to_date ('20190601', 'YYYYMMDD')
and T_servnach.DFSUMMA<>0
and t_servnach.DFDATEEND is not null
group by   T_period.Dfdatebegin  
		,branch_mrf.branch_key 
		,branch_mrf.short_name 
		,branch.branch_key
		,branch.short_name 
		,T_servnach.dfabonent  
		,T_ABONENT.DFINN 
		,coalesce (T_ABONENT.DFNAME,   T_ABONENT.dffamili ||' '||	T_ABONENT.dfim ||' '||	T_ABONENT.dfotch )  
		,dog.DFACCOUNT 
		,coalesce(T_servnach.dfservconst, T_servnach.dfonenach, -1 ) 
		--,T_servnach.dfservice  
		,d_bus_service.business_service_key  
		,coalesce(oncsc.dfdatebegin, onc.dfdatebegin  )  
		--,T_SERVICE.dfnamesmall 
		,d_bus_service.business_service_name 
		,rtk_det.service_rtk_detail_code 
		,rtk_det.service_rtk_detail_name 
		,seg.segment_name 
		,seg.budget_segmentation 
		,case when TCITYTYPE.dfnamesmall ='г.' then  decode (TCITYTYPE.dfnamesmall, null ,'', TCITYTYPE.dfnamesmall||' '|| tregion.DFNAME ||' ')
		              	else case when TCITYTYPE2.dfnamesmall ='г.' then decode (TCITYTYPE.dfnamesmall, null ,'', TCITYTYPE.dfnamesmall||' '|| tregion.DFNAME ||' ')
		            	|| decode (TCITYTYPE2.dfnamesmall, null ,'', TCITYTYPE2.dfnamesmall||' '|| TDISTRICT.DFNAME ||' ') 
				              else decode (TCITYTYPE2.dfnamesmall, null ,'', TCITYTYPE2.dfnamesmall||' '|| TDISTRICT.DFNAME ||' ') 
				             ||  decode (TCITYTYPE.dfnamesmall, null ,'', TCITYTYPE.dfnamesmall||' '|| tregion.DFNAME ||' ')
				             || decode (TCITYTYPE3.dfnamesmall, null ,'', TCITYTYPE3.dfnamesmall||' '|| city.DFNAME||' '  )      end end          	
				             || ' ' || SUBSTRing (tstreettype.dfnamesmall
				             || ' '
		                     || tstreet.dfname
		                     || DECODE (oncsc.dfhouse, NULL, '', ' д.' || TRIM (oncsc.dfhouse))
		                     || DECODE (oncsc.dfkorpus, NULL, '', ' корп.' || TRIM (oncsc.dfkorpus))
		                     || DECODE (oncsc.dfflat, NULL, '', ' кв.' || LPAD (TRIM (oncsc.dfflat), 5))
		                     || DECODE (oncsc.dfromm, NULL, '', ' комн.' || TRIM (oncsc.dfromm))  ,1,255)   || ' индекс ' ||  oncsc.DFINDEX
		,oncsc.DFORPON_HOUSE  
		,house2.adr_adm_ter 
		,oncsc.dfhouse 
		,TSTREET.dfname 
		,TREGION.DFNAME 
		,dog1.DFDOGOVOR 
		,dog1.dfnumber ;

commit;
analyze edw_stg_dm_feb.tfct_charge_address_1_prt_p000029;