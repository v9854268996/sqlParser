/*rev.35487  22.04.2020*/
delete from edw_stg_mdm.put_dim_service_xref_start where src_id = 000001;
insert into edw_stg_mdm.put_dim_service_xref_start (service_key,service_name,service_rtk_detail_key,subscriber_becoming,technology_type_key,region_id,src_id)
with svr as
(
select tslb.svc_id,
       ors.oebs_charge_code,
       substr(split_part(ors.oebs_charge_code, ' ',1),strpos(ors.oebs_charge_code,'R'),100) r12,
	   row_number() over(partition by tslb.svc_id order by tslb.date_change desc) as key
  from  edw_ods.t_000001_ors_charge_code ors
  join edw_ods.t_000001_t_svc_layer_bunch tslb 
 	on tslb.id_Cell_svc = ors.id_Cell_svc
   and to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second' between tslb.eff_dttm and tslb.exp_dttm
 --where ors.tech_dt = date_trunc('month', to_date(substr('20190630', 1, 8), 'YYYYMMDD'))
 where to_date('20190630','YYYYMMDD') + INTERVAL '1 day - 1 second'  between ors.eff_dttm and ors.exp_dttm 
 and ors.deleted_ind = 0 and tslb.deleted_ind =0
),
abon as
(
select  round(sr.svc_id)::text as svc_id

from 	edw_ods.t_000008_t_svc_ref sr
left join
(select round(svc_id) as svc_id, round(lc.id_cell_svc) as id_R_code, split_part(lc.note,'^',11) as R_code, lc.note as note_R_code
from edw_ods.t_000008_t_svc_layer_bunch lb
join edw_ods.t_000008_t_svc_layer_cell lc on lc.id_cell_svc = lb.id_cell_svc and lc.id_layer_svc = 5635582810 and lc.deleted_ind = 0
where lb.deleted_ind = 0
  and to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second' between lb.eff_dttm and lb.exp_dttm
  and to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second' between lc.eff_dttm and lc.exp_dttm) t1 on round(sr.svc_id) = t1.svc_id
left join
(select round(svc_id) as svc_id, round(lc.id_cell_svc) as id_sub_make, lc.name as sub_make
from edw_ods.t_000008_t_svc_layer_bunch lb
join edw_ods.t_000008_t_svc_layer_cell lc on lc.id_cell_svc = lb.id_cell_svc and lc.id_layer_svc = 5635684732 and lc.deleted_ind = 0
where lb.deleted_ind = 0
  and to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second' between lb.eff_dttm and lb.exp_dttm
  and to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second' between lc.eff_dttm and lc.exp_dttm) t2 on round(sr.svc_id) = t2.svc_id
where sr.deleted_ind = 0
  and t2.id_sub_make in
(
5635782834,5635782833,5635782836,5635782831,5635782837,6750948732,6750952186,5635782835,5635782839,5635782838,5635782829,5635782832,5635782840,
6560232648,6560232784,6560232139,7577790592,7577789738,7577791544,7577796822,7577796405,7123297607,7123297789,6818343141,7577797354,448125305,
448119417,6952934402,6603884236,8500740923,8500740091,7357835653,7357840211,8106204621,448123606,448123744,7499395874,7499395906,7499396000,
7499396046,7190713716,7190714098,7217091073,7190714421,7190714946,7217091712,8690186878,6481537515,7386533683,6454525916,7193550771,7386540027,
8403818550,7214597992,6509520576,7214598075,6509520311,7214598257,7214598025,6509520686,7277902701,7190713859,6453754311,6453754184,8656294657,
8461285233,8464529505,7252552352,7242721197,7252553010,7252544597,7253743816,7250048787,7253750253,7253750361,7253743002,7253749501,7277958271,
7277958118,7278834304,7278834334,7278834353,7278834317,7278834414,7278834431,7278834421,7278834439,7278834445,7278834456,7250049565,7252557019,
7252543496,7252557988,7253770583,7253770440,7253770893,7253770855,7253768774,7253769017,7252539400,7252558908,7252544917,7252560491,7253745454,
7253745196,7253753051,7253753206,7253744433,7253752071,8498256656
)  
)
select 
       t_svc_ref.svc_id::numeric(20) code,
	   substr(t_svc_ref.full_name,0,1100) "name",
	   svr.r12 service_rtk_detale_key,
	   case
		   when t_svc_ref.svc_id::text in (select r.svc_id  from abon r) then 1
		   else 0
	   end subscriber_becoming,  	   
	   case when upper(t_svc_ref.full_name) like '%TTH%' then 'ETTH'
            when upper(t_svc_ref.full_name) like '%PON%' then 'GPON'
		    when upper(t_svc_ref.full_name) like '%FTT%' then 'FTTb'
		    when upper(t_svc_ref.full_name) like '%MMDS%' then 'MMDS'
		    when upper(t_svc_ref.full_name) like '%CDMA%' then 'CDMA/GSM/3G/LTE'
		    when upper(t_svc_ref.full_name) like '%GSM%' then 'CDMA/GSM/3G/LTE'
			  --when upper(t_svc_ref.name) like '%3G%' then 'CDMA/GSM/3G/LTE'
		    when upper(t_svc_ref.full_name) like '%LTE%' then 'CDMA/GSM/3G/LTE'
		    when upper(t_svc_ref.full_name) like '%ETHERNET%' then 'ETHERNET'
		    when upper(t_svc_ref.full_name) like '%ISDN%' then 'Dial+ISDN'
		    when upper(t_svc_ref.full_name) like '%DIAL%' then 'Dial+ISDN'
		    when upper(t_svc_ref.full_name) like '%SHDSL%' then 'SHDSL'
            when upper(t_svc_ref.full_name) like '%DSL%' then 'XDSL'
		    when upper(t_svc_ref.full_name) like '%WI-FI%' then 'WiFi/WiMax'
		    when upper(t_svc_ref.full_name) like '%WIFI%' then 'WiFi/WiMax'
            when upper(t_svc_ref.full_name) like '%БШПД%' then 'БШПД'
		    when upper(t_svc_ref.full_name) like '%ШПД%' then 'ШПД'
			  --when upper(t_svc_ref.name) like '%РАДИО%' then 'Радиодоступ'
		    when upper(t_svc_ref.full_name) like '% ПРОВОД%' then 'Проводная'
        end  technology_type_key	
		,'VOLGA' as region_id
		,src_id

  from edw_ods.t_000001_t_svc_ref t_svc_ref
       left join svr on t_svc_ref.svc_id = svr.svc_id and svr.key = 1 
 where 
	to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second'  + interval '6 days'  between t_svc_ref.eff_dttm and t_svc_ref.exp_dttm 
	and t_svc_ref.deleted_ind=0;