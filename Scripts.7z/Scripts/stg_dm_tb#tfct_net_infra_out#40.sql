--rev. 43458 от 27.11.2019
truncate table edw_stg_dm_tb.tfct_net_infra_out_1_prt_p000040;
commit;
insert into edw_stg_dm_tb.tfct_net_infra_out_1_prt_p000040
  ( 
    load_date    ,
    mrf_id       ,
    rf_id        ,
    full_address ,
    addr_build_id,
    port_qty     ,
    load_dttm    ,
    src_id
  )
with tt as
  (
    select
      hb.house_key,
      e.external_id
    from
      edw_ods.t_000148_ent_id_vs_estate e
      inner join
        edw_ods.t_000148_ent_as_house hs
        on
          e.estate_id = hs.ob_ned_id
      inner join
        edw_dds.hub_dim_house hb
        on
          hs.orponid::varchar = hb.source_key
    where
      e.system_id                = 354541478
      and hs.mrf_id              = 354858666
      and hs.livestatus          = 1
      and hb.house_key is not null
  )
  ,
  all_t as
  (
    select
      mrf_id                                                   ,
      rf_id                                                    ,
      building                                                 ,
      building_id                                              ,
      cast(trunc(a.building_id) as varchar) as char_building_id,
      mounted
    from
      edw_ods.t_000040_capacity_fttb_pon a
    where
      a.tech_dt =to_date('20190601', 'YYYYMMDD')
    union all
    select
      mrf_id                                                   ,
      rf_id                                                    ,
      full_address_name                                        ,
      building_id                                              ,
      cast(trunc(a.building_id) as varchar) as char_building_id,
      mount_summ
    from
      edw_ods.t_000040_xdsl_equip a
    where
      a.tech_dt =to_date('20190601', 'YYYYMMDD')
      and to_date('20190601', 'YYYYMMDD')+interval '1 month - 1second' between valid_from and coalesce(valid_to::date, '2999-12-31'::date)
    union all
    select
      mrf_id                                                   ,
      rf_id                                                    ,
      full_address_name                                        ,
      building_id                                              ,
      cast(trunc(a.building_id) as varchar) as char_building_id,
      1
    from
      edw_ods.t_000040_wba_equip a
    where
      a.tech_dt =to_date('20190601', 'YYYYMMDD')
      and to_date('20190601', 'YYYYMMDD')+interval '1 month - 1second' between valid_from and coalesce(valid_to::date, '2999-12-31'::date)
  )
select
  to_date('20190601', 'YYYYMMDD') as load_date     ,
  a.mrf_id                                 as mrf_id        ,
  rf_id                                    as rf_id         ,
  building                                 as full_address  ,
  building_id                              as addr_build_id ,
  sum(mounted)                             as ports_qty     ,
  now()                                    as load_dttm     ,
  000040                             as src_id
from
  all_t a
  left join
    tt t
    on
      a.char_building_id=t.external_id
where
  t.house_key is null
group by
  a.mrf_id,
  rf_id   ,
  building,
  building_id
;
commit;
analyze edw_stg_dm_tb.tfct_net_infra_out_1_prt_p000040;
