/*rev.46649 от 17.01.2020*/

truncate table edw_stg_dds.t_000030_tfct_add_service_charges;

insert into edw_stg_dds.t_000030_tfct_add_service_charges
(
    add_service_key,
    service_key,
    branch_key,
    city_key,
    service_cost,
    dop_service_key,
    cnt_pay_days,
    cnt_notpay_days,
    charge_rub,
    vat_rub,
    charge_period_start_dttm,
    src_id
)
select add_service_key
    , service_key
    , branch_key
    , null                as city_key
    , null::numeric(38,5) as service_cost
    , service_key         as dop_service_key
    , cnt_pay_days
    , cnt_notpay_days    
    , charge_rub
    , vat_rub  
    , charge_period_start_dttm
    , src_id
from (
        select ads.add_service_key
            , ads.service_key
            , ads.branch_key
            , coalesce(sn1.dfservnach,sn2.dfservnach,sn3.dfservnach,sn4.dfservconst) as dfservnach
            , case 
                when coalesce(dds.dop_usluga_promo_name,0) + coalesce(dds.dop_usluga_bonus_type_name, 0) = 0
                then greatest(
                                ceil(EXTRACT(epoch from least(
                                                                date_trunc('day', ads.end_date) + interval '1 second',
                                                                coalesce(
                                                                          sn1.tperioddfdatebegin,
                                                                          sn2.tperioddfdatebegin,
                                                                          sn3.tperioddfdatebegin,
                                                                          sn4.tperioddfdatebegin,
                                                                          to_date('20190601', 'YYYYMMDD')
                                                                        ) + interval '1 month'
                                                              ) 
                                                        - greatest(
                                                                    ads.start_date,
                                                                    coalesce(
                                                                              sn1.tperioddfdatebegin,
                                                                              sn2.tperioddfdatebegin,
                                                                              sn3.tperioddfdatebegin,
                                                                              sn4.tperioddfdatebegin,
                                                                              to_date('20190601', 'YYYYMMDD')
                                                                            )
                                                                  ) )/86400 ), 0)
                else 0
              end as cnt_pay_days
            , case
                when coalesce(dds.dop_usluga_promo_name,0) + coalesce(dds.dop_usluga_bonus_type_name, 0) > 0 
                then greatest(
                                ceil(EXTRACT(epoch from least(
                                                                date_trunc('day',ads.end_date) + interval '1 second',
                                                                coalesce(
                                                                          sn1.tperioddfdatebegin,
                                                                          sn2.tperioddfdatebegin,
                                                                          sn3.tperioddfdatebegin,
                                                                          sn4.tperioddfdatebegin,
                                                                          to_date('20190601', 'YYYYMMDD')
                                                                        ) + interval '1 month'
                                                              )
                                                        - greatest(
                                                                    ads.start_date,
                                                                    coalesce(
                                                                              sn1.tperioddfdatebegin,
                                                                              sn2.tperioddfdatebegin,
                                                                              sn3.tperioddfdatebegin,
                                                                              sn4.tperioddfdatebegin,
                                                                              to_date('20190601', 'YYYYMMDD')
                                                                              )
                                                                  ) )/86400 ), 0)
                else 0
              end as cnt_notpay_days
            , coalesce(
                        DECODE(sn1.DFNDSINOUT,'T',sn1.DFSUMMA-sn1.DFNDSSUMMA,sn1.DFSUMMA), 
                        DECODE(sn2.DFNDSINOUT,'T',sn2.DFSUMMA-sn2.DFNDSSUMMA,sn2.DFSUMMA),
                        DECODE(sn3.DFNDSINOUT,'T',sn3.DFSUMMA-sn3.DFNDSSUMMA,sn3.DFSUMMA),
                        sn4.charge_rub,
                        0
                      ) as charge_rub
            , coalesce(
                        sn1.DFNDSSUMMA,
                        sn2.DFNDSSUMMA,
                        sn3.DFNDSSUMMA,
                        sn4.vat_rub,
                        0
                      ) as vat_rub
            , coalesce(
                        sn1.tperioddfdatebegin,
                        sn2.tperioddfdatebegin,
                        sn3.tperioddfdatebegin,
                        sn4.tperioddfdatebegin,
                        to_date('20190601', 'YYYYMMDD')
                      ) as charge_period_start_dttm
            , ads.src_id
            , ads.mrf_add_service_name
            , ads.start_date
            , ads.end_date
        from edw_stg_dds.t_000030_dim_add_service ads
        --привязываем начисления по услугам которые связаны с разовым начислением
        left join edw_ods.t_000030_tservnach sn1 on split_part(ads.add_service_key,'#',1) = (sn1.dfservconst::bigint)::text
            and split_part(ads.add_service_key,'#',2) = (sn1.dfonenach::bigint)::text
            and sn1.tperioddfdatebegin between to_date('20190601', 'YYYYMMDD') and to_date('20190601', 'YYYYMMDD') + INTERVAL'1 month' - interval'1 second'
            and sn1.dfdebetcredit <> 1
            and sn1.DFOPLATA IS NULL
            and sn1.deleted_ind = 0
        --привязываем начисления по услугам которые связаны с разовым начислением
        left join edw_ods.t_000030_tservnach sn2 on coalesce(split_part(ads.add_service_key,'#',1),'') = 'N'||(sn2.dfservnach::bigint)::text
            and coalesce(split_part(ads.add_service_key,'#',2),'') = coalesce((sn2.dfonenach::bigint)::text,'')
            and sn2.tperioddfdatebegin between to_date('20190601', 'YYYYMMDD') and to_date('20190601', 'YYYYMMDD') + INTERVAL'1 month'- interval'1 second'
            and sn2.dfdebetcredit <> 1
            and sn2.DFOPLATA IS NULL  
            and sn2.deleted_ind = 0
        --привязываем начисления по услугам которые связаны с разовым начислением и имеют выход на TSERVCONST
        left join edw_ods.t_000030_tservnach sn3 on coalesce(split_part(ads.add_service_key,'#',1),'') = 'C'||(sn3.dfservnach::bigint)::text
            and coalesce(split_part(ads.add_service_key,'#',2),'') = coalesce((sn3.dfonenach::bigint)::text,'')
            and sn3.tperioddfdatebegin between to_date('20190601', 'YYYYMMDD') and to_date('20190601', 'YYYYMMDD') + INTERVAL'1 month' - interval'1 second'
            and sn3.dfdebetcredit <> 1
            and sn3.DFOPLATA IS NULL  
            and sn3.deleted_ind = 0
        --привязываем начисления к постоянным услугам
        left join (
                    select dfservconst,
                        tperioddfdatebegin,
                        dfservice,
                        src_id,
                        sum(DECODE(DFNDSINOUT ,'T', DFSUMMA-DFNDSSUMMA,DFSUMMA)) as charge_rub,
                        sum(DFNDSSUMMA) as vat_rub
                    from edw_ods.t_000030_tservnach
                    where tperioddfdatebegin between to_date('20190601', 'YYYYMMDD') and to_date('20190601', 'YYYYMMDD') + INTERVAL '1 month' - interval '1 second'
                        and dfdebetcredit <> 1
                        and DFOPLATA IS NULL
                        and deleted_ind = 0
                    group by dfservconst,
                        tperioddfdatebegin,
                        dfservice,
                        src_id
        )sn4 on split_part(ads.add_service_key,'#',1) = (sn4.dfservconst::bigint)::text
            and split_part(ads.add_service_key,'#',1) != '' 
            and sn1.dfservconst is null
            and sn4.src_id || ';' || sn4.dfservice::bigint = ads.service_key
        left join edw_dds.hub_dim_dop_service hdds on hdds.source_key= ads.service_key and hdds.exp_dttm = '2999-12-31 00:00:00'
        left join edw_dds.dim_dop_service dds on hdds.dop_service_key= dds.dop_service_key and dds.end_dttm = '2999-12-31 00:00:00'
        where ads.src_id = 000030   
) lv1
where lv1.dfservnach is not null
    or (
          lv1.dfservnach is null
          and to_date('20190601', 'YYYYMMDD') between date_trunc('month',lv1.start_date) and date_trunc('month',lv1.end_date) + interval '1 month - 1 second'
      )
;
commit;

analyze edw_stg_dds.t_000030_tfct_add_service_charges;
