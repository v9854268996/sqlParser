/*rev.13041 10.08.2018*/

truncate table edw_stg_dds.t_000045_subs_histories;
insert into edw_stg_dds.t_000045_subs_histories(
subs_subs_id,rtpl_rtpl_id
	, number_history
	,eqpm_eqpm_id, navi_date,navi_user,
	scrd_scrd_id,slpt_slpt_id,subh_comment,zone_zone_id
	,start_date
	,end_date
)
with 
data_set_dup as (
	select
		*,
		row_number() over(partition by subs_subs_id,rtpl_rtpl_id,start_date order by number_history desc) as rn
	from edw_ods.t_000045_subs_histories 
	where deleted_ind = 0 
),
data_set_cleared as (
	select
		a1.*
	from data_set_dup a1 
	left join data_set_dup a2
	       on a2.rn = 1 
	       and a2.rtpl_rtpl_id = a1.rtpl_rtpl_id
		   and a2.subs_subs_id = a1.subs_subs_id
	       			and a1.start_date >= a2.start_date 
			and a1.start_date < a2.end_date
	    --   and a1.end_date between a2.start_date and a2.end_date
	       and a2.number_history > a1.number_history
	where 
		a1.rn = 1 
		and  a2.subs_subs_id is null
)

,hist_normalised as (
	select 
		subs_subs_id,rtpl_rtpl_id
		, number_history,
		
		eqpm_eqpm_id, navi_date,navi_user,
		scrd_scrd_id,slpt_slpt_id,subh_comment,zone_zone_id

		, min(start_date) as start_date
		, max(end_date) as end_date
	from
	    (
			select 
				*
				,row_number()over(partition by subs_subs_id,rtpl_rtpl_id,
						--		   number_history,
						eqpm_eqpm_id, navi_date,navi_user,
					scrd_scrd_id,slpt_slpt_id,subh_comment,zone_zone_id
						order by start_date)
					-row_number()over(partition by  subs_subs_id,rtpl_rtpl_id order by start_date)
				as gr
			from  data_set_cleared
			where  start_date < end_date 
	    ) t 
	group by subs_subs_id,rtpl_rtpl_id,number_history, gr,
		eqpm_eqpm_id, navi_date,navi_user,
		scrd_scrd_id,slpt_slpt_id,subh_comment,zone_zone_id


)
select 
	subs_subs_id,rtpl_rtpl_id
	, number_history
	,eqpm_eqpm_id, navi_date,navi_user,
	scrd_scrd_id,slpt_slpt_id,subh_comment,zone_zone_id
	,cast(start_date as timestamp without time zone) as start_date
	,coalesce(lead(start_date) over (partition by subs_subs_id,rtpl_rtpl_id order by start_date)- interval '1 second',end_date) end_date
from   hist_normalised  	
--where clnt_clnt_id = 1601286 -- Для тестов
;
analyze edw_stg_dds.t_000045_subs_histories;