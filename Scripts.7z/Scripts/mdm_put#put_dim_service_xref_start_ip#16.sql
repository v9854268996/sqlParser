/*rev.10461 от 11.05.2018*/
delete from   edw_stg_mdm.put_dim_service_xref_start_ip where region_id='VOLGA' and src_id = 000016;

insert into edw_stg_mdm.put_dim_service_xref_start_ip (service_key,region_id,src_id) 
select distinct service_key,region_id,src_id 
from edw_stg_dds.t_000016_tfct_bba_consumption t
LEFT JOIN edw_stg_dds.t_dim_services_xref_start_ip xref
	ON t.service_key= xref.source_key AND region_id='VOLGA'
	where xref.source_key is null
;

commit;
analyse edw_stg_mdm.put_dim_service_xref_start_ip;
