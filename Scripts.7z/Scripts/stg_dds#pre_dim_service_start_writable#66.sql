-- rev. 31320 20.06.2019

INSERT INTO edw_stg_dds.t_000066_pre_dim_service_start_writable
(
 source_key,
 region_id,
 sub_make,
 type_move,
 service_key,
 rcode_asr,
 src_id,
 eff_dttm,
 exp_dttm
)
SELECT
  source_key,
  region_id,
  sub_make,
  type_move,
  service_key,
  rcode_asr,
  000066::smallint,
  eff_dttm,
  exp_dttm
FROM edw_stg_dds.t_dim_service_xref_start
WHERE region_id = 'CENTER'
  AND exp_dttm = '2999-12-31 00:00:00.000000' :: timestamp without time zone
  AND sub_make = 1;