-- rev. 55770 от 22.04.2020
-- этот скрипт грузит 152, 154, 155 и 156 СИ

SET optimizer = ON;
SET search_path  = edw_stg_dmcm;
COMMIT;
---------------------------------------------------------------------------------------------------pre_shpd_abn_south_tp
BEGIN;
  TRUNCATE TABLE edw_stg_dmcm.pre_shpd_abn_south_tp_1_prt_p000156;
COMMIT;
BEGIN;
INSERT INTO edw_stg_dmcm.pre_shpd_abn_south_tp_1_prt_p000156
(account, rtpl_name, tp_start, speed_tp, tech_name, src_id)
  SELECT
    account,
    rtpl_name,
    tp_start,
    speed_tp,
    tech_name,
    000156::smallint AS src_id
  FROM (
         SELECT
           stg1.dfaccount AS account,
           tl.tmname      AS rtpl_name,
           CASE WHEN tl.start_date < '2017-01-01 00:00:00'
             THEN '2017-01-01 00:00:00'
           ELSE tl.start_date
           END            AS tp_start,
           CASE WHEN position ( 'КБ' IN upper ( tl.tmname ) ) > 0
             THEN cast ( to_number ( replace ( substring ( substring ( upper ( tl.tmname )
                                                                       FROM
                                                                       '[[:digit:]]{1,5}[\,\.]{0,1}[[:digit:]]{0,5}[[:space:]]{0,3}КБ' )
                                                           FROM '[[:digit:]]{1,5}[\,\.]{0,1}[[:digit:]]{0,5}' ), ',',
                                               '.' ),
                                     '9999999999.9999' ) AS NUMERIC(10, 2) )
           WHEN position ( '2048К' IN upper ( tl.tmname ) ) > 0
             THEN cast ( substring ( upper ( tl.tmname ) FROM '2048' ) AS NUMERIC(10, 2) )
           WHEN position ( 'МБ' IN upper ( tl.tmname ) ) > 0
             THEN cast ( to_number ( replace ( substring ( substring ( upper ( tl.tmname )
                                                                       FROM
                                                                       '[[:digit:]]{1,5}[\,\.]{0,1}[[:digit:]]{0,5}[[:space:]]{0,3}МБ' )
                                                           FROM '[[:digit:]]{1,5}[\,\.]{0,1}[[:digit:]]{0,5}' ), ',',
                                               '.' ),
                                     '9999999999.9999' ) * 1024 AS NUMERIC(10, 2) )
           WHEN position ( 'MБ' IN upper ( tl.tmname ) ) > 0
             THEN cast ( to_number ( replace ( substring ( substring ( upper ( tl.tmname )
                                                                       FROM
                                                                       '[[:digit:]]{1,5}[\,\.]{0,1}[[:digit:]]{0,5}[[:space:]]{0,3}MБ' )
                                                           FROM '[[:digit:]]{1,5}[\,\.]{0,1}[[:digit:]]{0,5}' ), ',',
                                               '.' ),
                                     '9999999999.9999' ) * 1024 AS NUMERIC(10, 2) )
           WHEN position ( 'ГБ' IN upper ( tl.tmname ) ) > 0
             THEN cast ( to_number ( replace ( substring ( substring ( upper ( tl.tmname )
                                                                       FROM
                                                                       '[[:digit:]]{1,5}[\,\.]{0,1}[[:digit:]]{0,5}[[:space:]]{0,3}ГБ' )
                                                           FROM '[[:digit:]]{1,5}[\,\.]{0,1}[[:digit:]]{0,5}' ), ',',
                                               '.' ),
                                     '9999999999.9999' ) * 1024 * 1024 AS NUMERIC(10, 2) )
           WHEN cast ( substring ( upper ( tl.tmname ) FROM '[[:digit:]]{1,5}' ) AS NUMERIC(10, 2) ) >= 64.0
                AND
                ( log ( 2.0, cast ( substring ( upper ( tl.tmname ) FROM '[[:digit:]]{1,5}' ) AS NUMERIC(10, 2) ) ) -
                  ceil ( log ( 2.0, cast ( substring ( upper ( tl.tmname )
                                                       FROM '[[:digit:]]{1,5}' ) AS NUMERIC(10, 2) ) ) ) ) = 0.0
             THEN cast ( substring ( upper ( tl.tmname ) FROM '[[:digit:]]{1,5}' ) AS NUMERIC(10, 2) )
           ELSE NULL
           END            AS speed_tp,
           CASE WHEN position ( 'DSL' IN upper ( tl.tmname ) ) > 0
             THEN 'xDSL'
           WHEN position ( 'PON' IN upper ( tl.tmname ) ) > 0
             THEN 'PON'
           WHEN position ( 'FTTX' IN upper ( tl.tmname ) ) > 0
             THEN 'FTTx'
           WHEN position ( 'DOCSIS' IN upper ( tl.tmname ) ) > 0
             THEN 'DOCSIS'
           WHEN position ( 'ETTH' IN upper ( tl.tmname ) ) > 0
             THEN 'ETTH'
           WHEN position ( 'ETHERNET' IN upper ( tl.tmname ) ) > 0
             THEN 'ETTH'
           ELSE NULL
           END            AS tech_name,
           row_number ( )
           OVER (
             PARTITION BY stg1.dfaccount
             ORDER BY
               CASE WHEN tl.start_date < '2017-01-01 00:00:00'
                 THEN '2017-01-01 00:00:00'
               ELSE tl.start_date
               END )         rn
         FROM (
                SELECT
                  *,
                  row_number ( )
                  OVER (
                    PARTITION BY td.dfaccount, aoa.orgid ) rn_stg
                FROM (
                       SELECT
                         td.dfaccount,
                         cast ( tdl.dfdogovor_ref AS NUMERIC(38, 0) ) AS dfdogovor_ref
                       FROM edw_ods.t_000027_tdogovor td
                         JOIN edw_ods.t_000027_tels_dogovor_link tdl ON tdl.dfels_dogovor = td.dfdogovor
                       WHERE td.dfdogtype = 1234567
                       UNION
                       SELECT
                         td.dfaccount,
                         cast ( tdl.dfdogovor_ref AS NUMERIC(38, 0) ) AS dfdogovor_ref
                       FROM edw_ods.t_000028_tdogovor td
                         JOIN edw_ods.t_000028_tels_dogovor_link tdl ON tdl.dfels_dogovor = td.dfdogovor
                       WHERE td.dfdogtype = 1234567
                       UNION
                       SELECT
                         td.dfaccount,
                         cast ( tdl.dfdogovor_ref AS NUMERIC(38, 0) ) AS dfdogovor_ref
                       FROM edw_ods.t_000029_tdogovor td
                         JOIN edw_ods.t_000029_tels_dogovor_link tdl ON tdl.dfels_dogovor = td.dfdogovor
                       WHERE td.dfdogtype = 1234567
                       UNION
                       SELECT
                         td.dfaccount,
                         cast ( tdl.dfdogovor_ref AS NUMERIC(38, 0) ) AS dfdogovor_ref
                       FROM edw_ods.t_000030_tdogovor td
                         JOIN edw_ods.t_000030_tels_dogovor_link tdl ON tdl.dfels_dogovor = td.dfdogovor
                       WHERE td.dfdogtype = 1234567
                       UNION
                       SELECT
                         td.dfaccount,
                         cast ( tdl.dfdogovor_ref AS NUMERIC(38, 0) ) AS dfdogovor_ref
                       FROM edw_ods.t_000031_tdogovor td
                         JOIN edw_ods.t_000031_tels_dogovor_link tdl ON tdl.dfels_dogovor = td.dfdogovor
                       WHERE td.dfdogtype = 1234567
                       UNION
                       SELECT
                         td.dfaccount,
                         cast ( tdl.dfdogovor_ref AS NUMERIC(38, 0) ) AS dfdogovor_ref
                       FROM edw_ods.t_000032_tdogovor td
                         JOIN edw_ods.t_000032_tels_dogovor_link tdl ON tdl.dfels_dogovor = td.dfdogovor
                       WHERE td.dfdogtype = 1234567
                       UNION
                       SELECT
                         td.dfaccount,
                         cast ( tdl.dfdogovor_ref AS NUMERIC(38, 0) ) AS dfdogovor_ref
                       FROM edw_ods.t_000033_tdogovor td
                         JOIN edw_ods.t_000033_tels_dogovor_link tdl ON tdl.dfels_dogovor = td.dfdogovor
                       WHERE td.dfdogtype = 1234567
                       UNION
                       SELECT
                         td.dfaccount,
                         cast ( tdl.dfdogovor_ref AS NUMERIC(38, 0) ) AS dfdogovor_ref
                       FROM edw_ods.t_000034_tdogovor td
                         JOIN edw_ods.t_000034_tels_dogovor_link tdl ON tdl.dfels_dogovor = td.dfdogovor
                       WHERE td.dfdogtype = 1234567
                       UNION
                       SELECT
                         td.dfaccount,
                         cast ( tdl.dfdogovor_ref AS NUMERIC(38, 0) ) AS dfdogovor_ref
                       FROM edw_ods.t_000035_tdogovor td
                         JOIN edw_ods.t_000035_tels_dogovor_link tdl ON tdl.dfels_dogovor = td.dfdogovor
                       WHERE td.dfdogtype = 1234567
                       UNION
                       SELECT
                         td.dfaccount,
                         cast ( tdl.dfdogovor_ref AS NUMERIC(38, 0) ) AS dfdogovor_ref
                       FROM edw_ods.t_000036_tdogovor td
                         JOIN edw_ods.t_000036_tels_dogovor_link tdl ON tdl.dfels_dogovor = td.dfdogovor
                       WHERE td.dfdogtype = 1234567
                       UNION
                       SELECT
                         td.dfaccount,
                         cast ( tdl.dfdogovor_ref AS NUMERIC(38, 0) ) AS dfdogovor_ref
                       FROM edw_ods.t_000037_tdogovor td
                         JOIN edw_ods.t_000037_tels_dogovor_link tdl ON tdl.dfels_dogovor = td.dfdogovor
                       WHERE td.dfdogtype = 1234567
                       UNION
                       SELECT
                         td.dfaccount,
                         cast ( tdl.dfdogovor_ref AS NUMERIC(38, 0) ) AS dfdogovor_ref
                       FROM edw_ods.t_000038_tdogovor td
                         JOIN edw_ods.t_000038_tels_dogovor_link tdl ON tdl.dfels_dogovor = td.dfdogovor
                       WHERE td.dfdogtype = 1234567
                       UNION
                       SELECT
                         td.dfaccount,
                         cast ( tdl.dfdogovor_ref AS NUMERIC(38, 0) ) AS dfdogovor_ref
                       FROM edw_ods.t_000039_tdogovor td
                         JOIN edw_ods.t_000039_tels_dogovor_link tdl ON tdl.dfels_dogovor = td.dfdogovor
                       WHERE td.dfdogtype = 1234567
                     ) td --23 365 676
                  JOIN (
                               SELECT
                                 val,
                                 orgid,
                                 attrid,
                                 row_number ( )
                                 OVER (
                                   PARTITION BY val
                                   ORDER BY mdate DESC ) rn
                               FROM edw_ods.t_000026_add_org_attrib
                               WHERE attrid = 202
                             ) aoa
                    ON aoa.val = td.dfdogovor_ref :: text
                       AND aoa.rn = 1
              ) stg1
           JOIN edw_ods.t_000026_dog_list dl
             ON dl.orgid = stg1.orgid
           JOIN (
                        SELECT
                          dogid,
                          dmid,
                          row_number ( )
                          OVER (
                            PARTITION BY dogid
                            ORDER BY whenmake DESC ) rn
                        FROM edw_ods.t_000026_map_main_vw
                      ) mm
             ON mm.dogid = dl.dogid
                AND mm.rn = 1
           JOIN (
                        SELECT
                          t.dmid,
                          t.tmid,
                          row_number ( )
                          OVER (
                            PARTITION BY t.dmid
                            ORDER BY t.begdate DESC ) rn
                        FROM (
                               SELECT
                                 ds.dmid,
                                 ds.tmid,
                                 ds.begdate
                               FROM edw_ods.t_000026_dog_serv ds
                                 LEFT JOIN edw_dds.hub_dim_service hds
                                   ON '26;' || cast ( ceil ( ds.servid ) AS VARCHAR ) || ';' ||
                                      cast ( ceil ( ds.tmid ) AS VARCHAR ) = hds.source_key
                                      AND hds.exp_dttm = '2999-12-31 00:00:00'

                                 LEFT JOIN edw_dds.dim_service dimserv
                                   ON dimserv.service_key = hds.service_key
                                      AND dimserv.exp_dttm = '2999-12-31 00:00:00'
                               WHERE dimserv.business_service_key BETWEEN 10200 AND 10203
                                 AND ds.deleted_ind = 0
                             ) t
                      ) ds
             ON ds.dmid = mm.dmid
                AND ds.rn = 1
           JOIN (
                        SELECT
                          tmname,
                          tmid,
                          start_date
                        FROM edw_ods.t_000026_tm_list
                      ) tl
             ON tl.tmid = ds.tmid
         WHERE stg1.rn = 1
       ) stg2
  WHERE stg2.rn = 1
    AND 000156::smallint = 154;
COMMIT;

BEGIN;
  ANALYZE edw_stg_dmcm.pre_shpd_abn_south_tp_1_prt_p000156;
COMMIT;

---------------------------------------------------------------------------------------------------pre_shpd_abn_sibir_tp
BEGIN;
  TRUNCATE TABLE edw_stg_dmcm.pre_shpd_abn_sibir_tp_1_prt_p000156;
COMMIT;
BEGIN;
INSERT INTO edw_stg_dmcm.pre_shpd_abn_sibir_tp_1_prt_p000156
(account, speed_tp, rtpl_name, tech_name, tp_start, src_id)
  SELECT
    account,
    speed_tp,
    rtpl_name,
    tech_name,
    tp_start,
    000156::smallint AS src_id
  FROM (
         SELECT
           account,
           CASE WHEN usa_value IS NOT NULL
             THEN
               CASE WHEN position ( 'К' IN upper ( usa_value ) ) > 0
                 THEN cast ( to_number ( replace ( substring ( substring ( upper ( usa_value )
                                                                           FROM
                                                                           '[[:digit:]]{1,5}[\,\.]{0,1}[[:digit:]]{0,5}[[:space:]]{0,3}К' )
                                                               FROM '[[:digit:]]{1,5}[\,\.]{0,1}[[:digit:]]{0,5}' ),
                                                   ',',
                                                   '.' ), '9999999999.9999' ) AS NUMERIC(10, 2) )
               WHEN position ( 'K' IN upper ( usa_value ) ) > 0
                 THEN cast ( to_number ( replace ( substring ( substring ( upper ( usa_value )
                                                                           FROM
                                                                           '[[:digit:]]{1,5}[\,\.]{0,1}[[:digit:]]{0,5}[[:space:]]{0,3}K' )
                                                               FROM '[[:digit:]]{1,5}[\,\.]{0,1}[[:digit:]]{0,5}' ),
                                                   ',',
                                                   '.' ), '9999999999.9999' ) AS NUMERIC(10, 2) )
               WHEN position ( 'М' IN upper ( usa_value ) ) > 0
                 THEN cast ( to_number ( replace ( substring ( substring ( upper ( usa_value )
                                                                           FROM
                                                                           '[[:digit:]]{1,5}[\,\.]{0,1}[[:digit:]]{0,5}[[:space:]]{0,3}М' )
                                                               FROM '[[:digit:]]{1,5}[\,\.]{0,1}[[:digit:]]{0,5}' ),
                                                   ',',
                                                   '.' ), '9999999999.9999' ) * 1024 AS NUMERIC(10, 2) )
               WHEN position ( 'M' IN upper ( usa_value ) ) > 0
                 THEN cast ( to_number ( replace ( substring ( substring ( upper ( usa_value )
                                                                           FROM
                                                                           '[[:digit:]]{1,5}[\,\.]{0,1}[[:digit:]]{0,5}[[:space:]]{0,3}M' )
                                                               FROM '[[:digit:]]{1,5}[\,\.]{0,1}[[:digit:]]{0,5}' ),
                                                   ',',
                                                   '.' ), '9999999999.9999' ) * 1024 AS NUMERIC(10, 2) )
               WHEN position ( 'ГБ' IN upper ( usa_value ) ) > 0
                 THEN cast ( to_number ( replace ( substring ( substring ( upper ( usa_value )
                                                                           FROM
                                                                           '[[:digit:]]{1,5}[\,\.]{0,1}[[:digit:]]{0,5}[[:space:]]{0,3}ГБ' )
                                                               FROM '[[:digit:]]{1,5}[\,\.]{0,1}[[:digit:]]{0,5}' ),
                                                   ',',
                                                   '.' ), '9999999999.9999' ) * 1024 * 1024 AS NUMERIC(10, 2) )
               WHEN cast ( substring ( upper ( usa_value ) FROM '[[:digit:]]{1,5}' ) AS NUMERIC(10, 2) ) >= 64.0
                    AND
                    ( log ( 2.0, cast ( substring ( upper ( usa_value ) FROM '[[:digit:]]{1,5}' ) AS NUMERIC(10, 2) ) )
                      -
                      ceil ( log ( 2.0, cast ( substring ( upper ( usa_value )
                                                           FROM '[[:digit:]]{1,5}' ) AS NUMERIC(10, 2) ) ) ) ) = 0.0
                 THEN cast ( substring ( upper ( usa_value ) FROM '[[:digit:]]{1,5}' ) AS NUMERIC(10, 2) )
               WHEN upper ( usa_value ) LIKE '%U_11111_%'
                 THEN 11111 :: NUMERIC(10, 2)
               WHEN upper ( usa_value ) LIKE '%U_1111_%'
                 THEN 1111 :: NUMERIC(10, 2)
               WHEN upper ( usa_value ) LIKE '%U_15555%'
                 THEN 15555 :: NUMERIC(10, 2)
               WHEN upper ( usa_value ) LIKE '%U_22222%'
                 THEN 22222 :: NUMERIC(10, 2)
               WHEN upper ( usa_value ) LIKE '%U_2222_%'
                 THEN 2222 :: NUMERIC(10, 2)
               WHEN upper ( usa_value ) LIKE '%U_33333%'
                 THEN 33333 :: NUMERIC(10, 2)
               WHEN upper ( usa_value ) LIKE '%U_44444%'
                 THEN 44444 :: NUMERIC(10, 2)
               WHEN upper ( usa_value ) LIKE '%U_4444_%'
                 THEN 4444 :: NUMERIC(10, 2)
               WHEN upper ( usa_value ) LIKE '%U_5555_%'
                 THEN 5555 :: NUMERIC(10, 2)
               WHEN upper ( usa_value ) LIKE '%U_6666_%'
                 THEN 6666 :: NUMERIC(10, 2)
               WHEN upper ( usa_value ) LIKE '%U_77777%'
                 THEN 77777 :: NUMERIC(10, 2)
               WHEN upper ( usa_value ) LIKE '%U_8888_%'
                 THEN 8888 :: NUMERIC(10, 2)
               WHEN usa_value LIKE '%Juniper%384%'
                 THEN 384 :: NUMERIC(10, 2)
               WHEN usa_value LIKE '%Juniper%768%'
                 THEN 768 :: NUMERIC(10, 2)
               WHEN usa_value LIKE '%Juniper%1536%'
                 THEN 1536 :: NUMERIC(10, 2)
               WHEN usa_value LIKE '%Juniper%2200%'
                 THEN 2200 :: NUMERIC(10, 2)
               ELSE NULL
               END
           ELSE
             CASE WHEN position ( 'К' IN upper ( tfp_name ) ) > 0
               THEN cast ( to_number ( replace ( substring ( substring ( upper ( tfp_name )
                                                                         FROM
                                                                         '[[:digit:]]{1,5}[\,\.]{0,1}[[:digit:]]{0,5}[[:space:]]{0,3}К' )
                                                             FROM '[[:digit:]]{1,5}[\,\.]{0,1}[[:digit:]]{0,5}' ), ',',
                                                 '.' ), '9999999999.9999' ) AS NUMERIC(10, 2) )
             WHEN position ( 'K' IN upper ( tfp_name ) ) > 0
               THEN cast ( to_number ( replace ( substring ( substring ( upper ( tfp_name )
                                                                         FROM
                                                                         '[[:digit:]]{1,5}[\,\.]{0,1}[[:digit:]]{0,5}[[:space:]]{0,3}K' )
                                                             FROM '[[:digit:]]{1,5}[\,\.]{0,1}[[:digit:]]{0,5}' ), ',',
                                                 '.' ), '9999999999.9999' ) AS NUMERIC(10, 2) )
             WHEN position ( 'М' IN upper ( tfp_name ) ) > 0
               THEN cast ( to_number ( replace ( substring ( substring ( upper ( tfp_name )
                                                                         FROM
                                                                         '[[:digit:]]{1,5}[\,\.]{0,1}[[:digit:]]{0,5}[[:space:]]{0,3}М' )
                                                             FROM '[[:digit:]]{1,5}[\,\.]{0,1}[[:digit:]]{0,5}' ), ',',
                                                 '.' ), '9999999999.9999' ) * 1024 AS NUMERIC(10, 2) )
             WHEN position ( 'M' IN upper ( tfp_name ) ) > 0
               THEN cast ( to_number ( replace ( substring ( substring ( upper ( tfp_name )
                                                                         FROM
                                                                         '[[:digit:]]{1,5}[\,\.]{0,1}[[:digit:]]{0,5}[[:space:]]{0,3}M' )
                                                             FROM '[[:digit:]]{1,5}[\,\.]{0,1}[[:digit:]]{0,5}' ), ',',
                                                 '.' ), '9999999999.9999' ) * 1024 AS NUMERIC(10, 2) )
             WHEN position ( 'ГБ' IN upper ( tfp_name ) ) > 0
               THEN cast ( to_number ( replace ( substring ( substring ( upper ( tfp_name )
                                                                         FROM
                                                                         '[[:digit:]]{1,5}[\,\.]{0,1}[[:digit:]]{0,5}[[:space:]]{0,3}ГБ' )
                                                             FROM '[[:digit:]]{1,5}[\,\.]{0,1}[[:digit:]]{0,5}' ), ',',
                                                 '.' ), '9999999999.9999' ) * 1024 * 1024 AS NUMERIC(10, 2) )
             WHEN cast ( substring ( upper ( tfp_name ) FROM '[[:digit:]]{1,5}' ) AS NUMERIC(10, 2) ) >= 64.0
                  AND
                  ( log ( 2.0, cast ( substring ( upper ( tfp_name ) FROM '[[:digit:]]{1,5}' ) AS NUMERIC(10, 2) ) ) -
                    ceil ( log ( 2.0, cast ( substring ( upper ( tfp_name )
                                                         FROM '[[:digit:]]{1,5}' ) AS NUMERIC(10, 2) ) ) ) ) = 0.0
               THEN cast ( substring ( upper ( tfp_name ) FROM '[[:digit:]]{1,5}' ) AS NUMERIC(10, 2) )
             WHEN upper ( tfp_name ) LIKE '%U_11111_%'
               THEN 11111 :: NUMERIC(10, 2)
             WHEN upper ( tfp_name ) LIKE '%U_1111_%'
               THEN 1111 :: NUMERIC(10, 2)
             WHEN upper ( tfp_name ) LIKE '%U_15555%'
               THEN 15555 :: NUMERIC(10, 2)
             WHEN upper ( tfp_name ) LIKE '%U_22222%'
               THEN 22222 :: NUMERIC(10, 2)
             WHEN upper ( tfp_name ) LIKE '%U_2222_%'
               THEN 2222 :: NUMERIC(10, 2)
             WHEN upper ( tfp_name ) LIKE '%U_33333%'
               THEN 33333 :: NUMERIC(10, 2)
             WHEN upper ( tfp_name ) LIKE '%U_44444%'
               THEN 44444 :: NUMERIC(10, 2)
             WHEN upper ( tfp_name ) LIKE '%U_4444_%'
               THEN 4444 :: NUMERIC(10, 2)
             WHEN upper ( tfp_name ) LIKE '%U_5555_%'
               THEN 5555 :: NUMERIC(10, 2)
             WHEN upper ( tfp_name ) LIKE '%U_6666_%'
               THEN 6666 :: NUMERIC(10, 2)
             WHEN upper ( tfp_name ) LIKE '%U_77777%'
               THEN 77777 :: NUMERIC(10, 2)
             WHEN upper ( tfp_name ) LIKE '%U_8888_%'
               THEN 8888 :: NUMERIC(10, 2)
             WHEN tfp_name LIKE '%Juniper%384%'
               THEN 384 :: NUMERIC(10, 2)
             WHEN tfp_name LIKE '%Juniper%768%'
               THEN 768 :: NUMERIC(10, 2)
             WHEN tfp_name LIKE '%Juniper%1536%'
               THEN 1536 :: NUMERIC(10, 2)
             WHEN tfp_name LIKE '%Juniper%2200%'
               THEN 2200 :: NUMERIC(10, 2)
             ELSE NULL
             END
           END           AS           speed_tp,
           tfp_name      AS           rtpl_name,
           CASE WHEN position ( 'DSL' IN upper ( tfp_name ) ) > 0
             THEN 'xDSL'
           WHEN position ( 'PON' IN upper ( tfp_name ) ) > 0
             THEN 'PON'
           WHEN position ( 'FTTX' IN upper ( tfp_name ) ) > 0
             THEN 'FTTx'
           WHEN position ( 'DOCSIS' IN upper ( tfp_name ) ) > 0
             THEN 'DOCSIS'
           WHEN position ( 'ETTH' IN upper ( tfp_name ) ) > 0
             THEN 'ETTH'
           WHEN position ( 'ETHERNET' IN upper ( tfp_name ) ) > 0
             THEN 'ETTH'
           ELSE NULL
           END           AS           tech_name,
           us_tfp_change AS           tp_start,
           row_number ( )
           OVER (
             PARTITION BY account
             ORDER BY us_tfp_change ) rn
         FROM (
                SELECT
                  abn.ab_account AS account,
                  usr_srv_atr.usa_value,
                  pln.tfp_name,
                  usr.us_tfp_change
                FROM edw_ods.t_000090_abonent abn --(ab_account - лицевой счет)
                  JOIN (
                               SELECT
                                 t.us_ab_id,
                                 t.US_USER_NAME,
                                 t.US_TFP_CODE,
                                 t.us_tfp_change,
                                 row_number ( )
                                 OVER (
                                   PARTITION BY t.us_ab_id
                                   ORDER BY t.input_date DESC ) rn
                               FROM edw_ods.t_000090_ct_users t
                               WHERE t.us_close_date IS NULL
                             ) usr
                    ON usr.us_ab_id = abn.ab_id
                       AND usr.rn = 1
                  LEFT JOIN (
                              SELECT
                                t.USS_US_USER_NAME,
                                t.USS_LOGNAME,
                                row_number ( )
                                OVER (
                                  PARTITION BY USS_US_USER_NAME
                                  ORDER BY t.input_date DESC ) rn
                              FROM edw_ods.t_000090_ct_user_services t
                              WHERE t.USS_SL_TYPE = 'RADIUS'
                            ) usr_srv
                    ON usr_srv.USS_US_USER_NAME = usr.US_USER_NAME
                       AND usr_srv.rn = 1
                  LEFT JOIN edw_ods.t_000090_tb_user_serv_attrs usr_srv_atr
                    ON usr_srv_atr.USA_USS_LOGNAME = usr_srv.USS_LOGNAME
                       AND usr_srv_atr.USA_SAT_NAME = 'profile'
                  LEFT JOIN edw_ods.t_000090_tb_tariff_plans pln
                    ON usr.US_TFP_CODE = pln.TFP_CODE

                UNION

                SELECT
                  abn.ab_account AS account,
                  usr_srv_atr.usa_value,
                  pln.tfp_name,
                  usr.us_tfp_change
                FROM edw_ods.t_000091_abonent abn --(ab_account - лицевой счет)
                  JOIN (
                               SELECT
                                 t.us_ab_id,
                                 t.US_USER_NAME,
                                 t.US_TFP_CODE,
                                 t.us_tfp_change,
                                 row_number ( )
                                 OVER (
                                   PARTITION BY t.us_ab_id
                                   ORDER BY t.input_date DESC ) rn
                               FROM edw_ods.t_000091_ct_users t
                               WHERE t.us_close_date IS NULL
                             ) usr
                    ON usr.us_ab_id = abn.ab_id
                       AND usr.rn = 1
                  LEFT JOIN (
                              SELECT
                                t.USS_US_USER_NAME,
                                t.USS_LOGNAME,
                                row_number ( )
                                OVER (
                                  PARTITION BY USS_US_USER_NAME
                                  ORDER BY t.input_date DESC ) rn
                              FROM edw_ods.t_000091_ct_user_services t
                              WHERE t.USS_SL_TYPE = 'RADIUS'
                            ) usr_srv
                    ON usr_srv.USS_US_USER_NAME = usr.US_USER_NAME
                       AND usr_srv.rn = 1
                  LEFT JOIN edw_ods.t_000091_tb_user_serv_attrs usr_srv_atr
                    ON usr_srv_atr.USA_USS_LOGNAME = usr_srv.USS_LOGNAME
                       AND usr_srv_atr.USA_SAT_NAME = 'profile'
                  LEFT JOIN edw_ods.t_000091_tb_tariff_plans pln
                    ON usr.US_TFP_CODE = pln.TFP_CODE

                UNION

                SELECT
                  abn.ab_account AS account,
                  usr_srv_atr.usa_value,
                  pln.tfp_name,
                  usr.us_tfp_change
                FROM edw_ods.t_000092_abonent abn --(ab_account - лицевой счет)
                  JOIN (
                               SELECT
                                 t.us_ab_id,
                                 t.US_USER_NAME,
                                 t.US_TFP_CODE,
                                 t.us_tfp_change,
                                 row_number ( )
                                 OVER (
                                   PARTITION BY t.us_ab_id
                                   ORDER BY t.input_date DESC ) rn
                               FROM edw_ods.t_000092_ct_users t
                               WHERE t.us_close_date IS NULL
                             ) usr
                    ON usr.us_ab_id = abn.ab_id
                       AND usr.rn = 1
                  LEFT JOIN (
                              SELECT
                                t.USS_US_USER_NAME,
                                t.USS_LOGNAME,
                                row_number ( )
                                OVER (
                                  PARTITION BY USS_US_USER_NAME
                                  ORDER BY t.input_date DESC ) rn
                              FROM edw_ods.t_000092_ct_user_services t
                              WHERE t.USS_SL_TYPE = 'RADIUS'
                            ) usr_srv
                    ON usr_srv.USS_US_USER_NAME = usr.US_USER_NAME
                       AND usr_srv.rn = 1
                  LEFT JOIN edw_ods.t_000092_tb_user_serv_attrs usr_srv_atr
                    ON usr_srv_atr.USA_USS_LOGNAME = usr_srv.USS_LOGNAME
                       AND usr_srv_atr.USA_SAT_NAME = 'profile'
                  LEFT JOIN edw_ods.t_000092_tb_tariff_plans pln
                    ON usr.US_TFP_CODE = pln.TFP_CODE
              ) stg
        ) stg2
  WHERE stg2.rn = 1
    AND speed_tp IS NOT NULL
    AND 000156::smallint = 156;
COMMIT;

BEGIN;
  ANALYSE edw_stg_dmcm.pre_shpd_abn_sibir_tp_1_prt_p000156;
COMMIT;

----------------------------------------------------------------------------------------------------pre_shpd_abn_ural_tp
BEGIN;
  TRUNCATE TABLE edw_stg_dmcm.pre_shpd_abn_ural_tp_1_prt_p000156;
COMMIT;
BEGIN;
INSERT INTO edw_stg_dmcm.pre_shpd_abn_ural_tp_1_prt_p000156
(account, speed_tp, rtpl_name, tech_name, tp_start, src_id)
  SELECT
    account,
    speed_tp,
    rtpl_name,
    tech_name,
    tp_start,
    000156::smallint AS src_id
  FROM (
         SELECT
           tp.account,
           CASE WHEN position ( 'K' IN tp.j_base ) > 0
             THEN substring ( tp.j_base, '[[:digit:]]*' ) :: NUMERIC(10, 2)
           WHEN position ( 'M' IN tp.j_base ) > 0
             THEN substring ( tp.j_base, '[[:digit:]]*' ) :: NUMERIC(10, 2) * 1024
           ELSE NULL
           END                  AS speed_tp,
           tp.name_r            AS rtpl_name,
           tp.tech              AS tech_name,
           subs.activation_date AS tp_start,
           row_number ( )
           OVER (
             PARTITION BY tp.account
             ORDER BY subs.activation_date ) rn
         FROM edw_ods.t_000045_v_rtk_subs_current_shpd_speed tp
           LEFT JOIN edw_ods.t_000045_subscribers subs
             ON subs.subs_id = tp.subs_subs_id
       ) tp_speed
  WHERE tp_speed.rn = 1
    AND 000156::smallint = 155;
COMMIT;

BEGIN;
  ANALYZE edw_stg_dmcm.pre_shpd_abn_ural_tp_1_prt_p000156;
COMMIT;

------------------------------------------------------------------------------------------------pre_shpd_abn_traffic_stg
-- 156 сибирь
BEGIN;
  TRUNCATE TABLE edw_stg_dmcm.pre_shpd_abn_traffic_stg_1_prt_p000156;
COMMIT;
BEGIN;
INSERT
  INTO edw_stg_dmcm.pre_shpd_abn_traffic_stg_1_prt_p000156
(
  abn_id,
  period,
  rf_id,
  mrf_id,
  traffic,
  src_id,
  load_dttm
)
SELECT
  inet.abn_id,
  to_char(date_trunc('MONTH', inet.last_day), 'YYYYMM') AS period,
  inet.rf_id,
  inet.mrf_id,
  sum(inet.traf_in) AS traffic,
  000156::smallint AS src_id,
  now()
FROM edw_ods.t_000158_cx_iqm_agr_inet inet
WHERE inet.last_day BETWEEN to_date('20190601', 'YYYYMMDD') AND to_date('20190630', 'YYYYMMDD')
  AND inet.mrf_id = 16::numeric
  AND 000156::smallint = 156::smallint
GROUP BY inet.abn_id, to_char(date_trunc('MONTH', inet.last_day), 'YYYYMM'), inet.rf_id, inet.mrf_id;
COMMIT;

-- 154 155
BEGIN;
INSERT
  INTO edw_stg_dmcm.pre_shpd_abn_traffic_stg_1_prt_p000156
(
  abn_id,      -- NUMBER(10,0),
  period,      -- VARCHAR2(6),
  rf_id,       -- NUMBER(10,0),
  mrf_id,      -- NUMBER(10,0),
  traffic,     -- NUMBER,
  src_id,
  account,
  load_dttm
)
SELECT
  abn_id,
  to_char(period, 'yyyymm')    AS period,
  rf_id,
  mrf_id,
  sum(count_traffic)           AS traffic,
  000156::smallint      AS src_id,
  account,
  now()
FROM
(
  SELECT abn_id, period, serv_id_src, id_traffic_kind, traffic_type, count_traffic, rf_id, mrf_id, account,
      row_number() OVER (
          PARTITION BY abn_id, period, serv_id_src, id_traffic_kind, traffic_type, count_traffic, rf_id, mrf_id
          ORDER BY log_id DESC, login DESC, charge DESC, date_snap DESC, id_rtpl_name DESC, id_city_name DESC
      ) AS rn
  FROM edw_ods.t_000156_traffic_shpd_aggr_dwh
  WHERE period BETWEEN to_date('20190601', 'YYYYMMDD') AND to_date('20190630', 'YYYYMMDD')
    AND count_traffic > 0.0
    AND traffic_kind IN (5, -1)
    --AND mrf_id NOT IN (12, 16)
    --AND 000156::smallint NOT IN (152::smallint, 156::smallint)
    AND CASE 000156::smallint
          WHEN 154 THEN mrf_id = 14
          WHEN 155 THEN mrf_id = 15
        END

) stg
WHERE stg.rn = 1
GROUP BY abn_id, to_char(period, 'yyyymm'), rf_id, mrf_id, account;
COMMIT;

-- 152 СЗ
BEGIN;
INSERT
  INTO edw_stg_dmcm.pre_shpd_abn_traffic_stg_1_prt_p000156
(
  abn_id,      -- NUMBER(10,0),
  period,      -- VARCHAR2(6),
  rf_id,       -- NUMBER(10,0),
  mrf_id,      -- NUMBER(10,0),
  traffic,     -- NUMBER,
  src_id,
  load_dttm
)
SELECT
  abn_id,
  period,
  rf_id,
  mrf_id,
  sum(count_traffic) / 1024 / 1024 AS traffic,
  000156::smallint          AS src_id,
  now()
FROM
(
  SELECT
    abn_id,
    to_char(period, 'yyyymm') AS period,
    rf_id,
    mrf_id,
    traffic_type,
    count_traffic,
    rank() OVER (
      PARTITION BY abn_id, period, rf_id, mrf_id
      ORDER BY date_snap_src DESC) AS rnk
  FROM edw_ods.t_000158_cx_iqm_traffic_shpd
  WHERE period BETWEEN to_date('20190601', 'YYYYMMDD') AND to_date('20190630', 'YYYYMMDD')
    AND traffic_type = '1'
    AND mrf_id = 12::numeric
    AND 000156::smallint = 152::smallint
) stg
WHERE stg.rnk = 1::numeric
GROUP BY
  abn_id,
  period,
  rf_id,
  mrf_id;
COMMIT;

BEGIN;
INSERT
  INTO edw_stg_dmcm.pre_shpd_abn_traffic_stg_1_prt_p000156
(
  abn_id,      -- NUMBER(10,0),
  charge_code, -- VARCHAR2(50),
  period,      -- VARCHAR2(6),
  rf_id,       -- NUMBER(10,0),
  mrf_id,      -- NUMBER(10,0),
  traffic,     -- NUMBER,
  charge,      -- NUMBER(22,4)
  src_id,
  account,
  load_dttm
)
SELECT
  chrg.abn_id,
  chrg.charge_code,
  to_char(period, 'yyyymm')          AS period,
  chrg.rf_id,
  chrg.mrf_id,
  NULL AS traffic,
  sum(chrg.charge - chrg.vat_amount) AS charge,
  000156::smallint            AS src_id,
  chrg.account,
  now()
FROM edw_ods.t_000156_rprt_charges_dwh chrg
WHERE (chrg.charge_code LIKE 'R070101%'
    OR chrg.charge_code LIKE 'R07010297%'
    OR chrg.charge_code LIKE 'R07010298%'
    OR chrg.charge_code LIKE 'R070106%'
    OR chrg.charge_code LIKE 'R070107%'
    OR chrg.charge_code IN ('R07010201', 'R07010202', 'R07010203', 'R07010204', 'R07010205', 'R07010206', 'R07010209'))
    AND chrg.coef_r12 = 1
    AND chrg.period BETWEEN to_date('20190601', 'YYYYMMDD') AND to_date('20190630', 'YYYYMMDD')
GROUP BY chrg.abn_id, to_char(period, 'yyyymm'), chrg.charge_code, chrg.rf_id, chrg.mrf_id, chrg.account;
COMMIT;

BEGIN;
  ANALYZE edw_stg_dmcm.pre_shpd_abn_traffic_stg_1_prt_p000156;
COMMIT;
--------------------------------------------------------------------------------------------------pre_shpd_abn_port3_stg
BEGIN;
  TRUNCATE TABLE edw_stg_dmcm.pre_shpd_abn_port3_stg_1_prt_p000156;
COMMIT;
BEGIN;
INSERT
  INTO edw_stg_dmcm.pre_shpd_abn_port3_stg_1_prt_p000156
(
  abn_id,
  period,
  login,
  port_num,
  port_state,
  src_id,
  load_dttm
)
SELECT
  abn_id,
  period,
  login,
  port_num,
  port_state,
  000156::smallint AS src_id,
  now()
FROM
    (SELECT
       abn_id,
       cast(period AS VARCHAR(6)) AS period,
       login,
       port_num,
       port_state,
       row_number() OVER (
         PARTITION BY abn_id, period
         ORDER BY date_comm DESC
         ) AS rn
     FROM edw_ods.t_000156_rprt_tchncl_data_dwh
     WHERE period = to_char(to_date('20190630', 'YYYYMMDD'), 'YYYYMM')::numeric
       AND abn_id IS NOT NULL) aaa
WHERE rn = 1
ORDER BY period, port_state, port_num;
COMMIT;

BEGIN;
  ANALYZE edw_stg_dmcm.pre_shpd_abn_port3_stg_1_prt_p000156;
COMMIT;

-------------------------------------------------------------------------------------------------pre_shpd_abn_date_start
BEGIN;
  TRUNCATE TABLE edw_stg_dmcm.pre_shpd_abn_date_start_1_prt_p000156;
COMMIT;
BEGIN;
INSERT
  INTO edw_stg_dmcm.pre_shpd_abn_date_start_1_prt_p000156
(
  abn_id,
  mrf_id,
  date_start,
  src_id,
  load_dttm
)
SELECT
  abn_id,
  mrf_id,
  min(period)             AS date_start,
  000156::smallint AS src_id,
  now()
FROM
(
  SELECT abn_id, period, serv_id_src, id_traffic_kind, traffic_type, count_traffic, rf_id, mrf_id,
         row_number() OVER (
             PARTITION BY abn_id, period, serv_id_src, id_traffic_kind, traffic_type, count_traffic, rf_id, mrf_id
             ORDER BY log_id DESC, login DESC, charge DESC, date_snap DESC, id_rtpl_name DESC, id_city_name DESC
         ) AS rn
    FROM edw_ods.t_000156_traffic_shpd_aggr_dwh
   WHERE count_traffic > 0.0
     AND traffic_kind IN (5, -1)
     AND mrf_id NOT IN (12, 16)
     AND 000156::smallint NOT IN (152, 156)
) stg
WHERE stg.rn = 1
GROUP BY abn_id, mrf_id;
COMMIT;

BEGIN;
INSERT
  INTO edw_stg_dmcm.pre_shpd_abn_date_start_1_prt_p000156
(
  abn_id,
  mrf_id,
  date_start,
  src_id,
  load_dttm
)
SELECT
  abn_id,
  mrf_id,
  min(date_trunc('MONTH', inet.last_day)) AS date_start,
  000156::smallint AS src_id,
  now()
FROM edw_ods.t_000158_cx_iqm_agr_inet inet
WHERE inet.last_day <= to_date('20190630', 'YYYYMMDD') + 7
  AND inet.mrf_id = 16
  AND 000156::smallint = 156
GROUP BY abn_id, mrf_id;
COMMIT;

BEGIN;
INSERT
  INTO edw_stg_dmcm.pre_shpd_abn_date_start_1_prt_p000156
(
  abn_id,
  mrf_id,
  date_start,
  src_id,
  load_dttm
)
SELECT
  abn_id,
  mrf_id,
  min(period) AS date_start,
  000156::smallint AS src_id,
  now()
FROM
(
  SELECT
    abn_id,
    period,
    mrf_id,
    rank() OVER (PARTITION BY abn_id, period, rf_id, mrf_id
                     ORDER BY date_snap_src DESC) AS rnk
  FROM edw_ods.t_000158_cx_iqm_traffic_shpd
  WHERE traffic_type = '1'
    AND mrf_id = 12
    AND 000156::smallint = 152
) stg
WHERE stg.rnk = 1
GROUP BY
  abn_id,
  mrf_id;
COMMIT;

BEGIN;
INSERT
  INTO edw_stg_dmcm.pre_shpd_abn_date_start_1_prt_p000156
(
  abn_id,
  mrf_id,
  date_start,
  src_id,
  load_dttm
)
SELECT
  chrg.abn_id,
  chrg.mrf_id,
  min(chrg.period) AS date_start,
  000156::smallint AS src_id,
  now()
FROM edw_ods.t_000156_rprt_charges_dwh chrg
WHERE (chrg.charge_code LIKE 'R070101%'
    OR chrg.charge_code LIKE 'R07010297%'
    OR chrg.charge_code LIKE 'R07010298%'
    OR chrg.charge_code LIKE 'R070106%'
    OR chrg.charge_code LIKE 'R070107%'
    OR chrg.charge_code IN ('R07010201', 'R07010202', 'R07010203', 'R07010204', 'R07010205', 'R07010206', 'R07010209'))
    AND chrg.coef_r12 = 1
GROUP BY chrg.abn_id, chrg.mrf_id;
COMMIT;

BEGIN;
  ANALYZE edw_stg_dmcm.pre_shpd_abn_date_start_1_prt_p000156;
COMMIT;

---------------------------------------------------------------------------------------------pre_shpd_abn_date_start_min
BEGIN;
  TRUNCATE TABLE edw_stg_dmcm.pre_shpd_abn_date_start_min_1_prt_p000156;
COMMIT;
BEGIN;
INSERT
  INTO edw_stg_dmcm.pre_shpd_abn_date_start_min_1_prt_p000156
(
  abn_id,
  mrf_id,
  date_start,
  src_id,
  load_dttm
)
SELECT
  abn_id,
  mrf_id,
  min(date_start) AS date_start,
  000156::smallint AS src_id,
  now()
FROM edw_stg_dmcm.pre_shpd_abn_date_start_1_prt_p000156
GROUP BY
  abn_id,
  mrf_id;
COMMIT;

BEGIN;
  ANALYZE edw_stg_dmcm.pre_shpd_abn_date_start_min_1_prt_p000156;
COMMIT;

-----------------------------------------------------------------------------------------------------------tfct_shpd_abn
BEGIN;
  TRUNCATE TABLE edw_stg_dmcm.tfct_shpd_abn_1_prt_p000156;
COMMIT;
BEGIN;
INSERT INTO edw_stg_dmcm.tfct_shpd_abn_1_prt_p000156
(
  period,
  date_snap,
  mrf,
  rf,
  id_rf,
  locality_name,
  street_name,
  house_number,
  address,
  orpon_id,
  okn,
  okved,
  account,
  account_key,
  inn,
  client_name,
  k_code,
  segment,
  id_macro_segment,
  special_usr_attr,
  migration_attr,
  inv_project_code,
  login,
  port_num,
  date_start,
  port_state,
  speed_tp,
  rtpl_name,
  charge,
  traffic,
  dz_sum,
  dz_date,
  cfo,
  abn_id,
  charge_code,
  tech_name,
  speed_source,
  tp_start,
  src_id,
  load_dttm
)
WITH
w_vrate_plans_dwh AS
(
  SELECT
    tbl.rtpl_name,
    tbl.date_start                               AS tp_start,
    to_char(tbl.date_snap2, 'yyyymm')            AS period,
    coalesce(tbl.speed, tbl.speed_min)           AS speed,
    coalesce(tbl.tech_id, tbl.tech_id_min)       AS tech_id,
    coalesce(tbl.start_rtpl, tbl.start_rtpl_min) AS start_rtpl,
    tbl.abn_id
  FROM
  (
     SELECT
          v.rtpl_name,
          v.date_start,
          v.speed,
          v.tech_id,
          v.start_rtpl,
          v.abn_id,
       min(v.start_rtpl) OVER (PARTITION BY v.abn_id) AS start_rtpl_min,
       min(v.tech_id)  OVER (PARTITION BY v.abn_id)   AS tech_id_min,
       min(v.speed)  OVER (PARTITION BY v.abn_id)     AS speed_min,
       row_number() OVER (
             PARTITION BY v.abn_id
             ORDER BY CASE WHEN v.date_start <= to_date('20190630', 'YYYYMMDD') THEN 0 ELSE 1 END, v.date_start DESC
         ) AS rn,
       to_date('20190630', 'YYYYMMDD')           AS date_snap2
     FROM edw_ods.t_000156_rprt_vrate_plans_dwh v
     WHERE v.serv_id IN (2, 22, -1)
  ) tbl
  WHERE tbl.rn = 1
),
w_oo_address AS
(
  SELECT
    postoffice_id || CASE WHEN postoffice_id IS NOT NULL THEN ', ' ELSE '' END
      || terr_type || CASE WHEN terr_type IS NOT NULL THEN ' ' ELSE '' END
      || name_terr || CASE WHEN coalesce(terr_type, name_terr) IS NOT NULL THEN ', ' ELSE '' END
      || city || CASE WHEN city IS NOT NULL THEN ', ' ELSE '' END
      || name_street_type || CASE WHEN name_street_type IS NOT NULL THEN ' ' ELSE '' END
      || name_street || CASE WHEN coalesce(name_street_type, name_street) IS NOT NULL THEN ', ' ELSE '' END
      || house AS address,
    house_lid,
    house_gid,
    city,
    name_street,
    house,
    mrf_id
  FROM edw_ods.t_000156_rprt_oo_address
),
w_subscribersdetal AS
(
  SELECT
    abn_id, mrf_id, flag_mgr
  FROM
  (
    SELECT
      abn_id,
      mrf_id,
      flag_mgr,
      row_number() OVER (PARTITION BY abn_id, mrf_id
                             ORDER BY CASE WHEN dt_end   IS NULL THEN '2999-12-31 00:00:00' ELSE dt_end   END DESC,
                                      CASE WHEN dt_start IS NULL THEN '2999-12-31 00:00:00' ELSE dt_start END DESC) AS rn
    FROM edw_ods.t_000156_rprt_subscribersdetal
  ) r
  WHERE r.rn = 1
),
w_oo_addressabndwh AS
(
  SELECT abn_id, mrf_id, house_lid, flat
  FROM
  (
    SELECT
      abn_id,
      mrf_id,
      house_lid,
      flat,
      row_number() OVER (PARTITION BY abn_id, mrf_id ORDER BY CASE WHEN date_end IS NULL
      THEN '2999-12-31 00:00:00'
             ELSE date_end END DESC,
      CASE WHEN date_begin IS NULL
        THEN '2999-12-31 00:00:00'
      ELSE date_begin END DESC) rn
    FROM edw_ods.t_000156_rprt_oo_addressabndwh
 ) a
  WHERE a.rn = 1
),
w_inv_charges_abn_view_b2b AS
(
  SELECT abn_id, mrf_id, period, invest_pr, cfo
  FROM
  (
    SELECT
      abn_id, mrf_id, period, invest_pr, cfo,
      row_number() OVER (PARTITION BY abn_id, mrf_id, period
                             ORDER BY CASE WHEN invest_pr IS NULL THEN 1 ELSE 0 END,
                                      CASE WHEN cfo       IS NULL THEN 1 ELSE 0 END) AS rn
    FROM edw_ods.t_000156_inv_charges_abn_view_b2b
    WHERE charge_code LIKE 'R07%'
      AND period = to_char(to_date('20190630', 'YYYYMMDD'), 'YYYYMM')
 ) inv
  WHERE inv.rn = 1
),
w_clnt_dwh2 AS
(
  SELECT
    account,
    id_macro_segment_ud,
    contr_name,
    inn
  FROM
  (
    SELECT
      CASE WHEN c.mrf_id = 14 THEN sa.nls ELSE c.account END AS account,
      id_macro_segment_ud,
      contr_name,
      inn,
      row_number() OVER (PARTITION BY CASE WHEN c.mrf_id = 14 THEN sa.nls ELSE c.account END
                             ORDER BY CASE WHEN c.date_snap <= to_date('20190630', 'YYYYMMDD') THEN 0 ELSE 1 END, c.date_snap DESC) AS rn
    FROM edw_ods.t_000156_rprt_client_dwh c
         LEFT JOIN
         (
            SELECT
                   account, nls
              FROM (
                     SELECT
                            account, nls,
                            row_number() OVER (PARTITION BY account ORDER BY coalesce(date_end, to_date('29991231','yyyymmdd')) DESC, date_begin DESC) AS rn
                       FROM edw_ods.t_000158_efftp_south_nls_accnt
                   ) stg
             WHERE stg.rn = 1
         ) sa
           ON sa.account = c.account
  ) c
 WHERE c.rn = 1
),
pre_tmp AS
(
  SELECT
    bba_chrg.period                                        AS period,
    (to_date(bba_chrg.period, 'YYYYMM') + INTERVAL '1 month - 1 day') :: DATE AS date_snap,
    coalesce(bba_chrg.rf_id, -1)                           AS id_rf,
    max(coalesce(addr.city, ''))                           AS locality_name,
    max(coalesce(addr.name_street, ''))                    AS street_name,
    max(coalesce(addr.house, ''))                          AS house_number,
    max(coalesce(addr.address ||
              CASE
                  WHEN addr_abn.flat IS NULL THEN ''
                  ELSE ', '
              END || coalesce(addr_abn.flat, ''),
              subs.adress_dev,
              subs2.adress_dev, ''))                       AS address,
    max(coalesce(addr.house_gid, ''))                      AS orpon_id,
    coalesce(
        CASE WHEN coalesce(subs.mrf_id, subs2.mrf_id, bba_chrg.mrf_id) = 14
            THEN sa.nls
            ELSE coalesce(subs.account, subs2.account, bba_chrg.account)
        END, '')                                           AS account,
    sum(coalesce(bba_chrg.charge::numeric, 0))             AS charge,
    sum(coalesce(bba_chrg.traffic::numeric,0))             AS traffic,
    coalesce(bba_chrg.abn_id, -1)                          AS abn_id,
    coalesce(bba_chrg.charge_code, 'R07')                  AS charge_code,
    max(coalesce(subs.abn_id, subs2.abn_id))               AS abn_id_join,
    bba_chrg.mrf_id                                        AS mrf_id,
    max(coalesce(subs.mrf_id, subs2.mrf_id))               AS mrf_id_join,
    max(coalesce(subs.org_subs_id, subs2.org_subs_id))     AS org_subs_id_join,
    max(coalesce(subs.cl_id, subs2.cl_id))                 AS cl_id_join,
    max(coalesce(subs.tech_id, subs2.tech_id))             AS tech_id_join,
    max(addr_okn.okn_area)                                 AS okn,
    max(coalesce(subs.subs_id, subs2.subs_id))             AS subs_id_join

    FROM edw_stg_dmcm.pre_shpd_abn_traffic_stg_1_prt_p000156 bba_chrg
         LEFT JOIN
         (
           SELECT
                  sa.adress_dev,
                  sa.mrf_id,
                  sa.account,
                  sa.abn_id,
                  sa.subs_id,
                  sa.cl_id,
                  sa.tech_id,
                  sa.org_subs_id,
                  row_number() OVER (PARTITION BY subs_id, mrf_id ORDER BY date_snap DESC, log_id DESC) AS rn -- в WHERE coalesce(subs.rn, 1) = 1
             FROM edw_ods.t_000156_rprtsubscribersactual sa
         ) subs
           ON subs.subs_id = bba_chrg.abn_id::character varying(100)
          AND subs.mrf_id = bba_chrg.mrf_id
         LEFT JOIN
         edw_ods.t_000156_rprtsubscribersactual subs2
           ON subs2.abn_id = bba_chrg.abn_id
         LEFT JOIN
         (
           SELECT
             account,
             nls
           FROM
           (
             SELECT
               account,
               nls,
               row_number() OVER (PARTITION BY account ORDER BY coalesce(date_end, to_date('29991231','yyyymmdd')) DESC, date_begin DESC) AS rn
             FROM edw_ods.t_000158_efftp_south_nls_accnt
           ) stg
           WHERE stg.rn = 1
         ) sa
           ON sa.account = coalesce(subs.account, subs2.account, bba_chrg.account)
          AND coalesce(subs.mrf_id, subs2.mrf_id, bba_chrg.mrf_id) = 14
         LEFT JOIN
         w_oo_addressabndwh addr_abn
           ON addr_abn.abn_id = coalesce(subs.abn_id, subs2.abn_id)
           AND addr_abn.mrf_id = coalesce(subs.mrf_id, subs2.mrf_id)
         LEFT JOIN
         w_oo_address addr
           ON addr.house_lid = addr_abn.house_lid
           AND addr.mrf_id = addr_abn.mrf_id
         LEFT JOIN
         (
           SELECT
             house_lid,
             mrf_id,
             globalid,
             okn_area,
             row_number() OVER (PARTITION BY house_lid, mrf_id) rn
           FROM edw_ods.t_000158_address_okn addr_okn
           WHERE house_lid IS NOT NULL
         ) addr_okn
           ON (addr_okn.house_lid = addr_abn.house_lid
              OR (addr_okn.house_lid IS NULL AND addr_okn.globalid :: text = addr.house_gid))
          AND addr_okn.mrf_id = addr_abn.mrf_id
          AND addr_okn.rn = 1
   WHERE coalesce(subs.rn, 1) = 1
     AND bba_chrg.period = to_char(to_date('20190630', 'YYYYMMDD'), 'YYYYMM')
   GROUP BY coalesce(bba_chrg.abn_id, -1),
            bba_chrg.period,
            (to_date(bba_chrg.period, 'YYYYMM') + INTERVAL '1 month - 1 day') :: DATE,
            coalesce(bba_chrg.charge_code, 'R07'),
            coalesce(
              CASE WHEN coalesce(subs.mrf_id, subs2.mrf_id, bba_chrg.mrf_id) = 14
                  THEN sa.nls
                  ELSE coalesce(subs.account, subs2.account, bba_chrg.account)
              END, ''),
            coalesce(bba_chrg.rf_id, -1),
            bba_chrg.mrf_id
),
ruz_house AS
(
  SELECT house_gid, tech_name
    FROM (
          SELECT house_gid,
                 tech_name,
                 row_number() OVER (PARTITION BY house_gid ORDER BY period DESC) AS rn
            FROM edw_dm_ruz.tfct_ruz_bi_rep_arg_tech_1_prt_p000156
           WHERE period <= to_date('20190630', 'YYYYMMDD')
         ) t
   WHERE t.rn = 1
),
eip_subs AS
(
  SELECT localsystemid AS subs_id,
         title         AS tech
    FROM (
          SELECT s.localsystemid,
                 t.title,
                 row_number() OVER (PARTITION BY s.localsystemid ORDER BY s.currentversion DESC) AS rn
            FROM edw_ods.t_000129_subscriber s
                 JOIN
                 edw_ods.t_000129_technology t
                   ON t.localsystemid = s.technology_localsystemid
                  AND t.app_pkid = s.technology_app_pkid
         ) t
   WHERE t.rn = 1
),
fun_acc AS
(
  SELECT account,
         mrf_id,
         tech
    FROM (
          SELECT mrf_id,
                 account,
                 tech,
                 row_number() OVER (PARTITION BY account ORDER BY date_connect_fact DESC) AS rn
            FROM edw_ods.t_000156_eso_v_funne_sales_bi
         ) t
   WHERE t.rn = 1
)
SELECT
    unfk.period,
    unfk.date_snap,
    coalesce(CASE
               WHEN dbr.parent_branch_key = -1 THEN dbr.branch_name
               ELSE pdbr.branch_name
             END, '')                               AS mrf,
    coalesce(dbr.branch_name, '')                   AS rf,
    unfk.id_rf,
    unfk.locality_name,
    unfk.street_name,
    unfk.house_number,
    unfk.address,
    unfk.orpon_id,
    unfk.okn,
    org.okved                                       AS okved,
    unfk.account,
    coalesce(da.account_key::numeric(22, 0), -1)    AS account_key,
    coalesce(cl.inn, cl2.inn, '')                   AS inn,
    coalesce(cl.contr_name, cl2.contr_name, '')     AS client_name,
    coalesce(CASE
               WHEN coalesce(nm.macro_segment, 'не определено') IN ('К04', 'не определено')
                         AND (length(coalesce(cl.inn, cl2.inn)) = 10
                                OR lower(coalesce(cl.contr_name, cl2.contr_name)) LIKE 'ип %'
                                OR lower(coalesce(cl.contr_name, cl2.contr_name)) LIKE '%индивидуальный предприниматель%')
                    THEN 'К02'
               ELSE nm.macro_segment
             END, '')                               AS k_code,
    coalesce(nm.name_microsegment, '')              AS segment,
    coalesce(cl.id_macro_segment_ud::numeric, cl2.id_macro_segment_ud::numeric,  -1)     AS id_macro_segment,
    CASE WHEN nm.macro_segment IN ( 'K0102', 'K0104' )
        THEN 1
        ELSE 0
    END                                             AS special_usr_attr,
    coalesce(subs_det.flag_mgr::numeric, 0)         AS migration_attr,
    coalesce(inv.invest_pr, '')                     AS inv_project_code,
    coalesce(prt.login, '')                         AS login,
    coalesce(prt.port_num, '')                      AS port_num,
    dsm.date_start                                  AS date_start,
    prt.port_state                                  AS port_state,
    coalesce(
        CASE 000156::smallint
          WHEN 154 THEN south_tp.speed_tp
          WHEN 155 THEN ural_tp.speed_tp
          WHEN 156 THEN sibir_tp.speed_tp
        END,

        CASE WHEN (pln.speed = 0 OR pln.speed IS NULL OR speed = '9999999')
          THEN
            CASE WHEN position('КБ' IN upper(pln.rtpl_name )) > 0
              THEN cast(to_number(replace(substring(substring(upper(pln.rtpl_name)
                                                                       FROM
                                                                       '[[:digit:]]{1,5}[\,\.]{0,1}[[:digit:]]{0,5}[[:space:]]{0,3}КБ')
                                                           FROM '[[:digit:]]{1,5}[\,\.]{0,1}[[:digit:]]{0,5}'), ',',
                                               '.'),
                                     '9999999999.9999') AS NUMERIC(22, 5))
           WHEN position('2048К' IN upper(pln.rtpl_name)) > 0
             THEN cast(substring(upper(pln.rtpl_name) FROM '2048') AS NUMERIC(22, 5))
           WHEN position('МБ' IN upper(pln.rtpl_name)) > 0
             THEN cast(to_number(replace(substring(substring(upper(pln.rtpl_name)
                                                                       FROM
                                                                       '[[:digit:]]{1,5}[\,\.]{0,1}[[:digit:]]{0,5}[[:space:]]{0,3}МБ')
                                                           FROM '[[:digit:]]{1,5}[\,\.]{0,1}[[:digit:]]{0,5}'), ',',
                                               '.'),
                                     '9999999999.9999') * 1024 AS NUMERIC(22, 5))
           WHEN position('MБ' IN upper(pln.rtpl_name)) > 0
             THEN cast(to_number(replace(substring(substring(upper(pln.rtpl_name)
                                                                       FROM
                                                                       '[[:digit:]]{1,5}[\,\.]{0,1}[[:digit:]]{0,5}[[:space:]]{0,3}MБ')
                                                           FROM '[[:digit:]]{1,5}[\,\.]{0,1}[[:digit:]]{0,5}'), ',',
                                               '.'),
                                     '9999999999.9999') * 1024 AS NUMERIC(22, 5))
           WHEN position('ГБ' IN upper(pln.rtpl_name)) > 0
             THEN cast(to_number(replace(substring(substring(upper(pln.rtpl_name)
                                                                       FROM
                                                                       '[[:digit:]]{1,5}[\,\.]{0,1}[[:digit:]]{0,5}[[:space:]]{0,3}ГБ')
                                                           FROM '[[:digit:]]{1,5}[\,\.]{0,1}[[:digit:]]{0,5}'), ',',
                                              '.'),
                                     '9999999999.9999') * 1024 * 1024 AS NUMERIC(22, 5))
           WHEN cast(substring(upper(pln.rtpl_name) FROM '[[:digit:]]{1,5}') AS NUMERIC(22, 5)) >= 64.0
                AND
                (log(2.0, cast(substring(upper(pln.rtpl_name) FROM '[[:digit:]]{1,5}') AS NUMERIC(22, 5))) -
                  ceil(log(2.0, cast(substring(upper(pln.rtpl_name)
                                                       FROM '[[:digit:]]{1,5}') AS NUMERIC(22, 5))))) = 0.0
             THEN cast(substring(upper(pln.rtpl_name) FROM '[[:digit:]]{1,5}') AS NUMERIC(22, 5))
          ELSE 0
          END
      ELSE
        CASE WHEN pln.speed IN (1, 2, 3)
          THEN pln.speed * 1024.0
        ELSE pln.speed
        END
      END, 0
    )                                               AS speed_tp,
    coalesce(
          CASE 000156::smallint
            WHEN 154 THEN south_tp.rtpl_name
            WHEN 155 THEN ural_tp.rtpl_name
            WHEN 156 THEN sibir_tp.rtpl_name
          END,
          pln.rtpl_name, '')                        AS rtpl_name,
    unfk.charge,
    unfk.traffic,
    scor.dz_sum                                     AS dz_sum,
    scor.dz_date                                    AS dz_date,
    inv.cfo::numeric(22,0)                          AS cfo,
    unfk.abn_id,
    unfk.charge_code,
    coalesce(
          CASE 000156::smallint
            WHEN 154 THEN south_tp.tech_name
            WHEN 155 THEN ural_tp.tech_name
            WHEN 156 THEN sibir_tp.tech_name
          END,

          CASE
            WHEN coalesce(lower(tch.def), '') IN ('', 'не определено')
              THEN
                CASE
                  WHEN charge_code IN ('R07010101', 'R07010102', 'R07010103', 'R07010197', 'R0701019701',
                                       'R0701019702', 'R07010198', 'R0701019801', 'R0701019802', 'R0701019803', 'R0701019804')
                       THEN 'xDSL'
                  WHEN charge_code IN ('R0701069701', 'R0701069702', 'R0701069801', 'R0701069802', 'R0701069803', 'R0701069804')
                       THEN 'PON'
                  ELSE
                    CASE
                      WHEN position('DSL' IN upper(pln.rtpl_name)) > 0
                           THEN 'xDSL'
                      WHEN position('PON' IN upper(pln.rtpl_name)) > 0
                           THEN 'PON'
                      WHEN position('FTTX' IN upper(pln.rtpl_name)) > 0
                           THEN 'FTTx'
                      WHEN position('DOCSIS' IN upper(pln.rtpl_name)) > 0
                           THEN 'DOCSIS'
                      WHEN position('ETTH' IN upper(pln.rtpl_name)) > 0
                           THEN 'ETTH'
                      WHEN position('ETHERNET' IN upper(pln.rtpl_name)) > 0
                           THEN 'ETTH'
                    END
                END
            ELSE tch.def
          END,
        CASE WHEN coalesce(lower(ruz_house.tech_name), '') NOT IN ('', 'не определено') THEN ruz_house.tech_name END,
        eip_subs.tech,
        fun_acc.tech,
        '')                                                AS tech_name,
    CASE WHEN
            CASE 000156::smallint
                WHEN 154 THEN south_tp.speed_tp
                WHEN 155 THEN ural_tp.speed_tp
                WHEN 156 THEN sibir_tp.speed_tp
            END IS NOT NULL
           THEN 'Биллинг'
         ELSE
            CASE
              WHEN (pln.speed = 0 OR pln.speed IS NULL OR speed = '9999999')
                   THEN 'Название ТП'
              ELSE 'Биллинг'
            END
    END                                              AS speed_source,
    coalesce (
          CASE 000156::smallint
            WHEN 154 THEN south_tp.tp_start
            WHEN 155 THEN ural_tp.tp_start
            WHEN 156 THEN sibir_tp.tp_start
          END,
          pln.tp_start)                              AS tp_start,
    000156::smallint                          AS src_id,
    now()                                            AS load_dttm
    FROM pre_tmp unfk
         LEFT JOIN
         ruz_house
           ON ruz_house.house_gid = unfk.orpon_id
         LEFT JOIN
         eip_subs
           ON eip_subs.subs_id = unfk.subs_id_join
         LEFT JOIN
         fun_acc
           ON fun_acc.account = unfk.account
           AND fun_acc.mrf_id = unfk.mrf_id
         LEFT JOIN
         edw_stg_dmcm.pre_shpd_abn_port3_stg_1_prt_p000156 prt
           ON prt.abn_id = unfk.abn_id_join
          AND prt.period = unfk.period
         LEFT JOIN
         edw_dds.hub_dim_branch hdb
           ON hdb.source_key = unfk.id_rf :: text
          AND hdb.exp_dttm >= to_date('29991231', 'yyyymmdd')
          AND hdb.src_id = 158
         LEFT JOIN
         edw_dds.dim_branch dbr
           ON hdb.branch_key = dbr.branch_key
           AND dbr.exp_dttm >= to_date('29991231', 'yyyymmdd')
         LEFT JOIN
         edw_dds.dim_branch pdbr
           ON pdbr.branch_key = dbr.parent_branch_key
          AND pdbr.exp_dttm >= to_date('29991231', 'yyyymmdd')
         LEFT JOIN
         w_inv_charges_abn_view_b2b inv
           ON inv.abn_id = unfk.abn_id_join
          AND inv.period = unfk.period
          AND inv.mrf_id = unfk.mrf_id
         LEFT JOIN
         w_subscribersdetal subs_det
           ON subs_det.abn_id = unfk.abn_id_join
           AND subs_det.mrf_id = unfk.mrf_id_join
         LEFT JOIN
         (
            SELECT
              db.user_id::character varying(100) AS user_id,
              db.period::character varying(6)    AS period,
              sum(db.overdue_deb)                AS dz_sum,
              max(db.date_planed)                AS dz_date,
              db.mrf_id
            FROM edw_ods.t_000159_debt_dwh db
            WHERE db.overdue_deb > 0
              AND db.period = to_char(to_date('20190630', 'YYYYMMDD'), 'YYYYMM')::numeric -- 201812
            GROUP BY db.user_id, db.period, db.mrf_id
         ) scor
           ON scor.user_id = unfk.org_subs_id_join
          AND scor.mrf_id = unfk.mrf_id
          AND scor.period = unfk.period
         LEFT JOIN
         edw_ods.t_000156_rprt_client_dwh cl
           ON cl.cl_id = unfk.cl_id_join
         LEFT JOIN
         w_clnt_dwh2 cl2
           ON cl2.account = unfk.account
         LEFT JOIN
         w_vrate_plans_dwh pln
           ON pln.abn_id = unfk.abn_id_join
          AND pln.period = unfk.period
         LEFT JOIN
         edw_ods.t_000158_rprt_dird_macro_sgmnt nm
           ON nm.id_macro_segment = coalesce( cl.id_macro_segment_ud, cl2.id_macro_segment_ud )
         LEFT JOIN
         edw_ods.t_000158_rprt_dir_tech tch
           ON tch.tech_id = coalesce(unfk.tech_id_join, pln.tech_id)
         LEFT JOIN
         (
            SELECT
              inn,
              okved,
              row_number() OVER (PARTITION BY inn ORDER BY date_start DESC, update_snap DESC) AS rn
            FROM edw_ods.t_000158_budget_org_detail
            WHERE date_end = to_date('29991231', 'yyyymmdd')
         ) org
           ON org.inn = coalesce(cl.inn, cl2.inn)
          AND org.rn = 1
         LEFT JOIN
         edw_stg_dmcm.pre_shpd_abn_date_start_min_1_prt_p000156 dsm
           ON dsm.abn_id = unfk.abn_id
           AND dsm.mrf_id = unfk.mrf_id
         LEFT JOIN
         (
           SELECT
             account_key,
             parent_account_key,
             partner_key,
             branch_key,
             duty_num_key,
             center_num_key,
             agent_scheme_key,
             address_key,
             payment_type_key,
             account_name,
             start_date,
             end_date,
             row_number() OVER (PARTITION BY account_name ORDER BY exp_dttm DESC, eff_dttm DESC) AS rn
           FROM edw_dds.dim_account
           WHERE CASE
                   WHEN 000156::smallint = 151 THEN src_id BETWEEN  48 AND  62
                   WHEN 000156::smallint = 152 THEN src_id = 97
                   WHEN 000156::smallint = 153 THEN src_id BETWEEN   1 AND  12
                   WHEN 000156::smallint = 154 THEN src_id BETWEEN  27 AND  39
                   WHEN 000156::smallint = 155 THEN src_id = 45
                   WHEN 000156::smallint = 156 THEN src_id BETWEEN  80 AND  88
                   WHEN 000156::smallint = 157 THEN src_id BETWEEN 107 AND 113
                END
            AND deleted_ind = 0
         ) da
         ON da.account_name = unfk.account
         AND da.rn = 1

         LEFT JOIN
         edw_stg_dmcm.pre_shpd_abn_south_tp south_tp
           ON south_tp.account = unfk.account
          AND 000156::smallint = 154

         LEFT JOIN
         edw_stg_dmcm.pre_shpd_abn_ural_tp ural_tp
           ON ural_tp.account = unfk.account
          AND 000156::smallint = 155

         LEFT JOIN
         edw_stg_dmcm.pre_shpd_abn_sibir_tp sibir_tp
           ON sibir_tp.account = unfk.account
          AND 000156::smallint = 156

   WHERE (CASE
            WHEN coalesce(cl.id_macro_segment_ud, cl2.id_macro_segment_ud) IN (1, 292) THEN 'K04' -- в DHREP-26225
            WHEN coalesce(nm.macro_segment, 'не определено') IN ('К04', 'не определено')
                      AND (length(coalesce(cl.inn, cl2.inn)) = 10
                             OR lower(coalesce(cl.contr_name, cl2.contr_name)) LIKE 'ип %'
                             OR lower(coalesce(cl.contr_name, cl2.contr_name)) LIKE '%индивидуальный предприниматель%')
                 THEN 'К02'
            ELSE coalesce(nm.macro_segment, '')
          END) NOT LIKE 'K04%';
COMMIT;

BEGIN;
  ANALYZE edw_stg_dmcm.tfct_shpd_abn_1_prt_p000156;
COMMIT;
-- этот скрипт грузит 152, 154, 155 и 156 СИ