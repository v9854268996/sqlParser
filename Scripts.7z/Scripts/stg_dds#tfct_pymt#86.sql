/*Заполнить во время коммита в SVN RTK пример rev. 56122 от 24.04.2020*/


truncate table edw_stg_dds.t_000086_tfct_pymt;

SET optimizer=ON;

insert
	into
		edw_stg_dds.t_000086_tfct_pymt( pymt_key,
		svc_key,
		acc_key,
		PYMT_TYPE_KEY,
		PYMT_DOC_NUM,
		PYMT_DATE,
		PAY_DATE,
		PYMT_SUM,
		IS_PAY_TRGT,
		BILL_PRD_DTTM,
		PYMT_SRC,
		PYMT_VAT_SUM,
		FRC_KEY,
		PYMT_BILL) 
		select
			t.payment_id as pymt_key,
			coalesce(cpa.svc_id,-1) as svc_key,
			t.user_id as acc_key,
			pdr.name as PYMT_TYPE_KEY,
			t.DOC_NUM as PYMT_DOC_NUM,
			t.date_rec as PYMT_DATE,
			t.pay_date as PAY_DATE,
			t.summ::numeric(38,
			2) as PYMT_SUM,
			case
				when v.vndr_id is null then 0
				else 1
			end as IS_PAY_TRGT,
			TO_DATE(t.BILLING_ID::varchar,'YYYYMM') as BILL_PRD_DTTM,
			-1 PYMT_SRC,
			(t.summ*cpa.tax_rate)::numeric(38,
			5) as PYMT_VAT_SUM,
			-1 as FRC_KEY,
			-1 as PYMT_BILL
		from
			edw_ods.t_000086_t_payments t
		inner join edw_ods.t_000086_CPA_PAYMENT CPA on
			t.PAYMENT_ID = CPA.ext_pay_id
			and cpa.tech_dt = t.tech_dt
			and cpa.payment_kind = 'p'
		left join edw_ods.t_000086_t_pay_cross_vnd v on
			t.payment_id = v.payment_id
			and t.tech_dt = v.tech_dt
		left join edw_ods.t_000086_t_pay_doc_ref PDR on
			t.pay_doc_id = pdr.pay_doc_id
			and t.tech_dt + interval '1 MONTH - 1 second' between PDR.eff_dttm and PDR.exp_dttm
		where
			t.tech_dt =TO_DATE('20190601','YYYYMMDD');
commit;
analyze edw_stg_dds.t_000086_tfct_pymt;