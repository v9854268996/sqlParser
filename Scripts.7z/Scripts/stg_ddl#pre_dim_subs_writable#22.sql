SET mapreduce.job.queuename=EKHD;
SET hive.mapred.mode=unstrict;
SET hive.mapred.mode=nonstrict;
SET hive.exec.dynamic.partition.mode=nonstrict;

SET p_src_start_ip=000022;
SET p_edw_stg_ddl=edw_uat_stg_ddl;INSERT OVERWRITE TABLE edw_uat_stg_ddl.t_${hiveconf:p_src_start_ip}_pre_dim_subs_writable
SELECT * FROM edw_uat_stg_ddl.t_${hiveconf:p_src_start_ip}_pre_dim_subs_writable WHERE 1 = 0;
