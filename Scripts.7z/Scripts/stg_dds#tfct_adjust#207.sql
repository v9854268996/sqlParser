/*rev. 25.10.2019 Changed by: NAREK.ALAVERDYAN */
		TRUNCATE TABLE edw_stg_dds.T_000207_tfct_adjust;

		INSERT INTO edw_stg_dds.T_000207_tfct_adjust
			(
				  adjust_key
				, adjust_type_key
				, subs_key
				, account_key
				, service_key
				, payment_key
				, bill_detail_key
				, contract_key
				, vat_rub
				, adjust_amt
				, adjust_dttm
				, corr_billing_id
				, src_id
				, load_dttm
				, eff_dttm
				, exp_dttm
				, rc_key
			)
		select
			  adjust_key
			, adjust_type_key
			, subs_key
			, src_id||'#'||account_key as account_key
			, service_key
			, payment_key
			, bill_detail_key
			, contract_key
			, vat_rub
			, adjust_amt
			, adjust_dttm
			, corr_billing_id
			, src_id
			, load_dttm
			, eff_dttm
			, exp_dttm
			,rc_key
		from (
				select 
					  '1#'||round(tsc.corr_id) as adjust_key -- Идентификатор корректировки
					, coalesce(round(tsc.error_billing_id), to_char(cdate,'YYYYMM')::numeric, round(tsc.billing_id) ) as corr_billing_ID -- Идентификатор корректируемого периода
					, to_date(round(billing_id)::text, 'YYYYMM') as adjust_dttm -- Дата создания корректировки
					, round(tsc.user_id) as account_key -- Идентификатор лицевого счета
					, round(tsc.svc_id)::text as service_key
					, -1 as payment_key -- Идентификатор платежа
					, CAST(tsc.billing_id as varchar) ||'#'|| LPAD (TRIM (u.account), 12, '0') as bill_ke -- Идентификатор счета
					, coalesce('1'||'#'||round(tsc.reason_id),'1') as adjust_type_key -- Идентификатор типа корректировки
					, decode(tsc.svc_corr_type::int,1,-1,2,-1,1) * (tsc.summ - tsc.tax) as adjust_amt -- Сумма корректировки в рублях, без НДС
					, decode(tsc.svc_corr_type::int,1,-1,2,-1,1) * tsc.tax as vat_rub -- Сумма НДС, руб.
					, CASE
						WHEN ROW_NUMBER() OVER (PARTITION BY o_contract.user_id ORDER BY DECODE (t_sub_contract.vndr_contract_id, t_sub_contract.contract_id, 1, 2), t_sub_contract.vndr_contract_id) = 1
						THEN round(o_contract.contract_id)
						ELSE round(t_sub_contract.vndr_contract_id)
					  END as contract_key -- Идентификатор договора
					, round(cpa_charge.charge_id) as bill_detail_key --Идентификатор Детали счета
					, u.user_id||'#'||coalesce(tsc.phone,'0') as service_user_key
					, dim_subs.subs_key as subs_key
					, ROW_NUMBER() OVER (partition by tsc.corr_id order by  case
																				when (xref.sub_make=1
																						and tsc.service_id::text = dim_subs.service_id::text)
																				then 1
																				when (xref.sub_make=0
																						and (tsc.phone=dim_subs.dev_id)
																						and et.technology_type_key=dim_subs.technology_type_key)
																				then 2
																				when (xref.sub_make=0
																						and (tsc.phone=dim_subs.dev_id))
																				then 3
																				when (xref.sub_make=0)
																				then 4
																				else 99999
																			end asc)
						as key1 -- ключ уникальности начисления
					, tsc.src_id as src_id
					, now() as load_dttm
					, cast('19000101' as timestamp(0) without time zone) as eff_dttm
					, cast('29991231' as timestamp(0) without time zone) as exp_dttm
					, case
						when coalesce(tsc.vnd_id,1) in (1,2199239,525862019,525919986,200,4375276,3528867,3816572,70409327,70409345,70410991,1001580737825,195304686,2462878) 
						then 1 
						else 0
					  end as vnd
					, dim_segment.segment_name||'#'||xref.rcode_asr as rc_key
				from (
						select *
						from edw_ods.t_000207_t_svc_correction tsc
						where 1=1
							and round(tsc.billing_id) <> coalesce(round(tsc.error_billing_id), to_char(cdate,'YYYYMM')::numeric, round(tsc.billing_id) )
							and round(tsc.billing_id) between substr('20190601', 1, 6)::int and substr('20190630', 1, 6)::int
							and tsc.tech_dt between to_date(substr('20190601', 1, 8), 'YYYYMMDD') and to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second'
					) tsc
				JOIN edw_stg_dds.t_000207_dim_account dim_account ON 1=1
					AND tsc.src_id||'#'||trunc(tsc.user_id) = dim_account.account_key
					and tsc.src_id = dim_account.src_id
					and to_date(trunc(tsc.billing_id)::text,'YYYYMMDD') + INTERVAL '1 MONTH - 1 second' between dim_account.eff_dttm and dim_account.exp_dttm
				JOIN edw_stg_dds.t_000207_dim_partner dim_partner ON 1=1
					AND dim_account.partner_key = dim_partner.partner_key
					and dim_account.src_id = dim_partner.src_id
					and to_date(trunc(tsc.billing_id)::text,'YYYYMMDD') + INTERVAL '1 MONTH - 1 second' between dim_partner.eff_dttm and dim_partner.exp_dttm
				LEFT JOIN edw_dds.hub_dim_segment hub_dim_segment ON 1=1
					AND hub_dim_segment.source_key = dim_partner.segment_key
					and hub_dim_segment.src_id = dim_partner.src_id
					and to_date(trunc(tsc.billing_id)::text,'YYYYMMDD') + INTERVAL '1 MONTH - 1 second' between hub_dim_segment.eff_dttm and hub_dim_segment.exp_dttm
				LEFT JOIN edw_dds.dim_segment dim_segment ON 1=1
					AND dim_segment.segment_key = hub_dim_segment.segment_key
					and dim_segment.deleted_ind=0
					and to_date(trunc(tsc.billing_id)::text,'YYYYMMDD') + INTERVAL '1 MONTH - 1 second' between dim_segment.eff_dttm and dim_segment.exp_dttm
				LEFT JOIN edw_ods.t_000207_t_users u on 1=1
					AND u.user_id = tsc.user_id
					and u.DELETED_IND <> 1
					and to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second' between u.eff_dttm and u.exp_dttm
				left join edw_stg_dds.t_dim_service_xref_start xref	on 1=1
					AND xref.source_key =  round(tsc.svc_id)::text
					and to_date(substr('20190601', 1, 8), 'YYYYMMDD') + INTERVAL '1 MONTH - 1 second' between xref.eff_dttm and xref.exp_dttm
					and xref.region_id = 'BASH'
				left join edw_dds.dim_service et on 1=1
					AND et.service_key = xref.service_key
					and to_date(substr('20190601', 1, 8), 'YYYYMMDD') + INTERVAL '1 MONTH - 1 second' between et.eff_dttm and et.exp_dttm  
				left join (
						select cpa_charge.bid,
								cpa_charge.user_id,
								cpa_charge.svc_id,
								min(cpa_charge.charge_id) charge_id
						 from edw_ods.t_000207_cpa_charge cpa_charge
						 where cpa_charge.tech_dt between to_date(substr('20190601', 1, 8), 'YYYYMMDD') and to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second' -- because cpa_charge.bid = tsc.billing_id
						 group by cpa_charge.bid,
								  cpa_charge.user_id,
								  cpa_charge.svc_id
					) cpa_charge
				on 1=1
					AND cpa_charge.bid = tsc.billing_id
					and cpa_charge.user_id = tsc.user_id
					and cpa_charge.svc_id = tsc.svc_id
				left join edw_ods.t_000207_o_contract o_contract on 1=1
					AND o_contract.user_id = tsc.user_id
					and o_contract.DELETED_IND <> 1
					and to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second' between o_contract.eff_dttm and o_contract.exp_dttm
				left join edw_ods.t_000207_t_sub_contract t_sub_contract on 1=1
					AND t_sub_contract.contract_id = o_contract.contract_id
					and t_sub_contract.DELETED_IND <> 1
					and to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second' between t_sub_contract.eff_dttm and t_sub_contract.exp_dttm
				left join (
						select
							ts.service_id,
							dim_subs.subs_key,
							dim_subs.account_key,
							dim_subs.subs_code as dev_id,
							dim_subs.start_date,
							dim_subs.end_date,
							et.business_service_key,
							et.technology_type_key
						from edw_stg_dds.t_000207_dim_subs dim_subs
						left join edw_stg_dds.t_dim_service_xref_start xref	on 1=1
							AND xref.source_key =  dim_subs.service_key
							and to_date(substr('20190601', 1, 8), 'YYYYMMDD') + INTERVAL '1 MONTH - 1 second' between xref.eff_dttm and xref.exp_dttm
							and xref.region_id = 'BASH'
						left join edw_dds.dim_service et on 1=1
							AND et.service_key = xref.service_key
							and to_date(substr('20190601', 1, 8), 'YYYYMMDD') + INTERVAL '1 MONTH - 1 second' between et.eff_dttm and et.exp_dttm    	
						LEFT JOIN edw_ods.t_000207_t_services ts ON 1=1
							AND dim_subs.service_key = ROUND(ts.svc_id)::TEXT
							AND ts.DELETED_IND <> 1
							AND TO_DATE('20190630', 'YYYYMMDD') + INTERVAL '1 day - 1 second' BETWEEN ts.eff_dttm AND ts.exp_dttm 
					) dim_subs
				on 1=1
					AND tsc.src_id||'#'||tsc.user_id = dim_subs.account_key
					and et.business_service_key = dim_subs.business_service_key
					and to_date(coalesce(round(tsc.error_billing_id), round(tsc.billing_id))::text,'YYYYMM') 
								between date_trunc('month',dim_subs.start_date) and date_trunc('month',dim_subs.end_date)
			) s
		where 1=1
			AND s.key1=1
			and vnd = 1
		;
			
		ANALYZE edw_stg_dds.T_000207_tfct_adjust;
	