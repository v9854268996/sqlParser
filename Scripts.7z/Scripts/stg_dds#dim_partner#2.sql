/*rev.34279 29.07.2019*/

truncate table edw_stg_dds.t_000002_dim_partner;
insert into edw_stg_dds.t_000002_dim_partner
(
    partner_key
    , parent_tax_number_cval
    , tax_number_cval
    , branch_key
    , segment_key
    , tax_reg_reason_cval
    , partner_full_name
    , doc_number_cval
    , src_id
    , load_dttm
    , eff_dttm
    , exp_dttm
    , start_date
    , end_date
)
with ttr as
(
SELECT round(tu.user_type_id) AS user_type_id, round(tu.user_id) AS user_id, round(ttr.coef) AS coef, round(tu.dept_id) AS dept_id, hub.branch_key, round(tu.billing_id) AS billing_id
FROM edw_ods.t_000001_t_saldo tu
LEFT JOIN edw_ods.t_000001_t_user_type_ref ttr
ON round(ttr.user_type_id) = round(tu.user_type_id)
AND ttr.deleted_ind <> 1
AND to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second'
    between ttr.eff_dttm AND ttr.exp_dttm
LEFT JOIN edw_dds.hub_dim_branch hub
ON round(tu.dept_id)::text = hub.source_key::text
AND hub.src_id = 1
AND to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second'
    between hub.eff_dttm AND hub.exp_dttm
WHERE tu.billing_id <= substr('20190601', 1, 6)::int
and tu.tech_dt <=to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second'

UNION ALL

SELECT round(tu.user_type_id) AS user_type_id, round(tu.user_id) AS user_id, round(ttr.coef) AS coef, round(tu.dept_id) AS dept_id, hub.branch_key, round(tu.billing_id) AS billing_id
FROM edw_ods.t_000002_t_saldo tu
LEFT JOIN edw_ods.t_000002_t_user_type_ref ttr
ON round(ttr.user_type_id) = round(tu.user_type_id)
AND ttr.deleted_ind <> 1
AND to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second'
    between ttr.eff_dttm AND ttr.exp_dttm
LEFT JOIN edw_dds.hub_dim_branch hub
ON round(tu.dept_id)::text = hub.source_key::text
AND hub.src_id = 2
AND to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second'
    between hub.eff_dttm AND hub.exp_dttm
WHERE tu.billing_id <= substr('20190601', 1, 6)::int
and tu.tech_dt <=to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second'

UNION ALL

SELECT round(tu.user_type_id) AS user_type_id, round(tu.user_id) AS user_id, round(ttr.coef) AS coef, round(tu.dept_id) AS dept_id, hub.branch_key, round(tu.billing_id) AS billing_id
FROM edw_ods.t_000003_t_saldo tu
LEFT JOIN edw_ods.t_000003_t_user_type_ref ttr
ON round(ttr.user_type_id) = round(tu.user_type_id)
AND ttr.deleted_ind <> 1
AND to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second'
    between ttr.eff_dttm AND ttr.exp_dttm
LEFT JOIN edw_dds.hub_dim_branch hub
ON round(tu.dept_id)::text = hub.source_key::text
AND hub.src_id = 3
AND to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second'
    between hub.eff_dttm AND hub.exp_dttm
WHERE tu.billing_id <= substr('20190601', 1, 6)::int
and tu.tech_dt <=to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second'

UNION ALL

SELECT round(tu.user_type_id) AS user_type_id, round(tu.user_id) AS user_id, round(ttr.coef) AS coef, round(tu.dept_id) AS dept_id, hub.branch_key, round(tu.billing_id) AS billing_id
FROM edw_ods.t_000004_t_saldo tu
LEFT JOIN edw_ods.t_000004_t_user_type_ref ttr
ON round(ttr.user_type_id) = round(tu.user_type_id)
AND ttr.deleted_ind <> 1
AND to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second'
    between ttr.eff_dttm AND ttr.exp_dttm
LEFT JOIN edw_dds.hub_dim_branch hub
ON round(tu.dept_id)::text = hub.source_key::text
AND hub.src_id = 4
AND to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second'
    between hub.eff_dttm AND hub.exp_dttm
WHERE tu.billing_id <= substr('20190601', 1, 6)::int
and tu.tech_dt <=to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second'

UNION ALL

SELECT round(tu.user_type_id) AS user_type_id, round(tu.user_id) AS user_id, round(ttr.coef) AS coef, round(tu.dept_id) AS dept_id, hub.branch_key, round(tu.billing_id) AS billing_id
FROM edw_ods.t_000005_t_saldo tu
LEFT JOIN edw_ods.t_000005_t_user_type_ref ttr
ON round(ttr.user_type_id) = round(tu.user_type_id)
AND ttr.deleted_ind <> 1
AND to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second'
    between ttr.eff_dttm AND ttr.exp_dttm
LEFT JOIN edw_dds.hub_dim_branch hub
ON round(tu.dept_id)::text = hub.source_key::text
AND hub.src_id = 5
AND to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second'
    between hub.eff_dttm AND hub.exp_dttm
WHERE tu.billing_id <= substr('20190601', 1, 6)::int
and tu.tech_dt <=to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second'

UNION ALL

SELECT round(tu.user_type_id) AS user_type_id, round(tu.user_id) AS user_id, round(ttr.coef) AS coef, round(tu.dept_id) AS dept_id, hub.branch_key, round(tu.billing_id) AS billing_id
FROM edw_ods.t_000006_t_saldo tu
LEFT JOIN edw_ods.t_000006_t_user_type_ref ttr
ON round(ttr.user_type_id) = round(tu.user_type_id)
AND ttr.deleted_ind <> 1
AND to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second'
    between ttr.eff_dttm AND ttr.exp_dttm
LEFT JOIN edw_dds.hub_dim_branch hub
ON round(tu.dept_id)::text = hub.source_key::text
AND hub.src_id = 6
AND to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second'
    between hub.eff_dttm AND hub.exp_dttm
WHERE tu.billing_id <= substr('20190601', 1, 6)::int
and tu.tech_dt <=to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second'

UNION ALL

SELECT round(tu.user_type_id) AS user_type_id, round(tu.user_id) AS user_id, round(ttr.coef) AS coef, round(tu.dept_id) AS dept_id, hub.branch_key, round(tu.billing_id) AS billing_id
FROM edw_ods.t_000007_t_saldo tu
LEFT JOIN edw_ods.t_000007_t_user_type_ref ttr
ON round(ttr.user_type_id) = round(tu.user_type_id)
AND ttr.deleted_ind <> 1
AND to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second'
    between ttr.eff_dttm AND ttr.exp_dttm
LEFT JOIN edw_dds.hub_dim_branch hub
ON round(tu.dept_id)::text = hub.source_key::text
AND hub.src_id = 7
AND to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second'
    between hub.eff_dttm AND hub.exp_dttm
WHERE tu.billing_id <= substr('20190601', 1, 6)::int
and tu.tech_dt <=to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second'

UNION ALL

SELECT round(tu.user_type_id) AS user_type_id, round(tu.user_id) AS user_id, round(ttr.coef) AS coef, round(tu.dept_id) AS dept_id, hub.branch_key, round(tu.billing_id) AS billing_id
FROM edw_ods.t_000008_t_saldo tu
LEFT JOIN edw_ods.t_000008_t_user_type_ref ttr
ON round(ttr.user_type_id) = round(tu.user_type_id)
AND ttr.deleted_ind <> 1
AND to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second'
    between ttr.eff_dttm AND ttr.exp_dttm
LEFT JOIN edw_dds.hub_dim_branch hub
ON round(tu.dept_id)::text = hub.source_key::text
AND hub.src_id = 8
AND to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second'
    between hub.eff_dttm AND hub.exp_dttm
WHERE tu.billing_id <= substr('20190601', 1, 6)::int
and tu.tech_dt <=to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second'

UNION ALL

SELECT round(tu.user_type_id) AS user_type_id, round(tu.user_id) AS user_id, round(ttr.coef) AS coef, round(tu.dept_id) AS dept_id, hub.branch_key, round(tu.billing_id) AS billing_id
FROM edw_ods.t_000009_t_saldo tu
LEFT JOIN edw_ods.t_000009_t_user_type_ref ttr
ON round(ttr.user_type_id) = round(tu.user_type_id)
AND ttr.deleted_ind <> 1
AND to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second'
    between ttr.eff_dttm AND ttr.exp_dttm
LEFT JOIN edw_dds.hub_dim_branch hub
ON round(tu.dept_id)::text = hub.source_key::text
AND hub.src_id = 9
AND to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second'
    between hub.eff_dttm AND hub.exp_dttm
WHERE tu.billing_id <= substr('20190601', 1, 6)::int
and tu.tech_dt <=to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second'

UNION ALL

SELECT round(tu.user_type_id) AS user_type_id, round(tu.user_id) AS user_id, round(ttr.coef) AS coef, round(tu.dept_id) AS dept_id, hub.branch_key, round(tu.billing_id) AS billing_id
FROM edw_ods.t_000010_t_saldo tu
LEFT JOIN edw_ods.t_000010_t_user_type_ref ttr
ON round(ttr.user_type_id) = round(tu.user_type_id)
AND ttr.deleted_ind <> 1
AND to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second'
    between ttr.eff_dttm AND ttr.exp_dttm
LEFT JOIN edw_dds.hub_dim_branch hub
ON round(tu.dept_id)::text = hub.source_key::text
AND hub.src_id = 10
AND to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second'
    between hub.eff_dttm AND hub.exp_dttm
WHERE tu.billing_id <= substr('20190601', 1, 6)::int
and tu.tech_dt <=to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second'

UNION ALL

SELECT round(tu.user_type_id) AS user_type_id, round(tu.user_id) AS user_id, round(ttr.coef) AS coef, round(tu.dept_id) AS dept_id, hub.branch_key, round(tu.billing_id) AS billing_id
FROM edw_ods.t_000011_t_saldo tu
LEFT JOIN edw_ods.t_000011_t_user_type_ref ttr
ON round(ttr.user_type_id) = round(tu.user_type_id)
AND ttr.deleted_ind <> 1
AND to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second'
    between ttr.eff_dttm AND ttr.exp_dttm
LEFT JOIN edw_dds.hub_dim_branch hub
ON round(tu.dept_id)::text = hub.source_key::text
AND hub.src_id = 11
AND to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second'
    between hub.eff_dttm AND hub.exp_dttm
WHERE tu.billing_id <= substr('20190601', 1, 6)::int
and tu.tech_dt <=to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second'

UNION ALL

SELECT round(tu.user_type_id) AS user_type_id, round(tu.user_id) AS user_id, round(ttr.coef) AS coef, round(tu.dept_id) AS dept_id, hub.branch_key, round(tu.billing_id) AS billing_id
FROM edw_ods.t_000012_t_saldo tu
LEFT JOIN edw_ods.t_000012_t_user_type_ref ttr
ON round(ttr.user_type_id) = round(tu.user_type_id)
AND ttr.deleted_ind <> 1
AND to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second'
    between ttr.eff_dttm AND ttr.exp_dttm
LEFT JOIN edw_dds.hub_dim_branch hub
ON round(tu.dept_id)::text = hub.source_key::text
AND hub.src_id = 12
AND to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second'
    between hub.eff_dttm AND hub.exp_dttm
WHERE tu.billing_id <= substr('20190601', 1, 6)::int
and tu.tech_dt <=to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second'
)
select
    partner_key
    , parent_tax_number_cval
    , tax_number_cval
    , branch_key
    , segment_key
    , tax_reg_reason_cval
    , partner_full_name
    , doc_number_cval
    , src_id
    , load_dttm
    , eff_dttm
    , case
        when date_trunc('day',exp_dttm)::timestamp = to_date('29991231', 'YYYYMMDD')
            then date_trunc('day',exp_dttm)::timestamp
            else exp_dttm
        end as exp_dttm
    , eff_dttm as start_date
    , case
        when date_trunc('day',exp_dttm)::timestamp = to_date('29991231', 'YYYYMMDD')
            then date_trunc('day',exp_dttm)::timestamp
            else exp_dttm
        end as end_date
from
(
    select
    round(t_users.user_id) as partner_key
    , t_chief_users.inn as parent_tax_number_cval
    , t_users.inn as tax_number_cval
    , coalesce(round(t_saldo.dept_id),round(t_users.dept_id)) as branch_key
    , coalesce(round(ttr.user_type_id)::text, round(t_saldo.user_type_id)::text, (round(t_users.user_type_id))::text, 'ND_EKHD') as segment_key
    , t_users.kpp as tax_reg_reason_cval
    , trim(t_users.name) as partner_full_name
    , t_users.document_text as doc_number_cval
    , t_users.src_id as src_id
    , now() as load_dttm
    , coalesce(decode(t_saldo.billing_id, t_saldo.min_billing_id, to_date('19000101', 'YYYYMMDD')), to_date(round(t_saldo.billing_id)::text, 'YYYYMM'), to_date('19000101' , 'YYYYMMDD'))
        as eff_dttm
    , coalesce(decode(t_saldo.billing_id, t_saldo.max_billing_id, to_date('29991231', 'YYYYMMDD')),to_date(round(t_saldo.billing_id)::text, 'YYYYMM') + interval '1 month - 1 day',  to_date('29991231', 'YYYYMMDD')) + interval '1 day - 1 second'
        as exp_dttm
    from edw_ods.t_000002_t_users t_users
    left join
    (
        select
            dept_id
            , user_id
            , user_type_id
            , billing_id
            , max(billing_id) over (PARTITION BY user_id) as max_billing_id
            , min(billing_id) over (PARTITION BY user_id) as min_billing_id
        from edw_ods.t_000002_t_saldo
        where billing_id <= substr('20190601', 1, 6)::int
            and tech_dt <= to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second'
    ) t_saldo
        on  t_users.user_id = t_saldo.user_id
        and t_users.DELETED_IND = 0
    left join edw_ods.t_000002_t_users t_chief_users
        on  t_chief_users.user_id = t_users.chief_user_id
        and t_chief_users.DELETED_IND = 0
        and to_date(substr('20190630',1,8), 'YYYYMMDD') + INTERVAL '1 day - 1 second'
            between t_chief_users.eff_dttm and t_chief_users.exp_dttm
    left join
    (
        select
            round(sp.user_id_sp) as user_id_sp
            , vip.user_id_vip as user_id_vip
            , round(sp.dept_id_vip) as dept_id_vip
            , case
            when date_begin = min(date_begin) over (PARTITION BY vip.user_id_sp)
                then to_date('19000101', 'YYYYMMDD')
                else date_begin
            end as date_begin_v2
            , case
            when coalesce(date_end, to_date('29991231', 'YYYYMMDD')) = max(coalesce(date_end, to_date('29991231', 'YYYYMMDD'))) over (PARTITION BY vip.user_id_sp)
                then to_date('29991231', 'YYYYMMDD')
                else coalesce(date_end, to_date('29991231', 'YYYYMMDD'))
            end as date_end_v2
        from edw_ods.t_000002_t_vip_sp sp
        inner join
            edw_ods.t_000002_t_vip vip
            on sp.user_id_sp = vip.user_id_sp
            and to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second' + interval '6 days'
                between vip.eff_dttm and vip.exp_dttm
        where 1=1
            and to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second' + interval '6 days'
                between sp.eff_dttm and sp.exp_dttm
            and vip.deleted_ind = 0
            and sp.deleted_ind = 0
    ) t_vip_sp
        on  round(t_users.user_id) = t_vip_sp.user_id_sp
        and to_date(round(t_saldo.billing_id)::text, 'YYYYMM') between date_begin_v2 and date_end_v2
    LEFT JOIN edw_dds.hub_dim_branch hub
        on  round(t_vip_sp.dept_id_vip)::text = hub.source_key
        AND t_users.src_id = hub.src_id
        and to_date('20190630','YYYYMMDD') + INTERVAL '1 MONTH - 1 second' between hub.eff_dttm and hub.exp_dttm
    left join ttr
        on  ttr.user_id = round(t_vip_sp.user_id_vip)
        and hub.branch_key = ttr.branch_key
        and round(t_saldo.billing_id) = ttr.billing_id
    where
        to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second' + interval '6 days'
            between t_users.eff_dttm and t_users.exp_dttm
    )s;
  commit;
 analyse edw_stg_dds.t_000002_dim_partner;
