/*rev.23472 28.02.2019*/
  
truncate edw_stg_dds.t_000030_dim_subscribers;
insert into edw_stg_dds.t_000030_dim_subscribers
	( subs_key
	, src_id
	, subs_activation_dttm
	, subs_cancellation_dttm
	, eff_dttm
	, exp_dttm
	, load_dttm
	)
SELECT 
	subs_key,
	src_id,
	subs_activation_dt,
	date_trunc( 'DAY',subs_cancellation_dt) as subs_cancellation_dt,
	'19000101' as eff_dttm,
	'29991231' as exp_dttm,
	now()
FROM edw_stg_dds.t_000030_dim_subs
WHERE date_trunc( 'DAY',exp_dttm) = date_trunc( 'DAY',subs_cancellation_dt);
commit;
analyze edw_stg_dds.t_000030_dim_subscribers;