--rev. 55176 от 16.04.2020
-- 0.0 Первый собираемый объект
truncate table edw_stg_dmcm.san_cl_prf_1_prt_p000157;
commit;
insert into edw_stg_dmcm.san_cl_prf_1_prt_p000157 ( san
                                                      , account
                                                      , mrf_id
                                                      , src_id
                                                      )
select san,
       account,
       mrf_id,
	   src_id
  from 
(
select distinct
       s_t.account_number                                     as san
     , sad_2.account
     , decode(s_t.mrf_id,1,11,4,10,5,12,9,13,7,14,8,15,6,16,3,17)  as mrf_id
     , 000157 as src_id
 from  edw_ods.t_000195_v_iptv_dim_subscriber s_t
 join (
 select san,
        account
 from ( select san,
               account,
               row_number() over (partition by san order by rn) as san_rn
          from 
      (
        select
          san,
          account,
          2 as rn
        from
        (
          select
            uss_login     san     ,
            ab_account as account ,
            row_number() over (
                             partition by uss_login
                             order by
                               modify_date desc) rn
          from
            edw_ods.T_000151_sdpdv_SDP_MAP sd
          where
            ab_account is not null
        )
        u
        where
          rn = 1
        
        union all
        
        select  
          account_number as san,
          oss_account_number as account,
          1 as rn
        from
            edw_ods.t_000195_v_iptv_dim_subscriber
        where
          iptv_eff_dttm            <=to_date('20190601', 'YYYYMMDD') + interval '1 month - 1 second'
          and iptv_exp_dttm        >=to_date('20190601', 'YYYYMMDD')
          and subscriber_is_test   = 'Нет'
          and subcriber_state_name = 'Active'
          and subcriber_type_name  = 'Физ.лицо'
          and oss_account_number is not null
          and mrf_id in (1,4)
          
        union all

        select 
          san, 
          account ,
          3 as rn
        from edw_dds.dim_san_account
        where 
          eff_dttm                 <= to_date('20190601', 'YYYYMMDD') + interval '1 month - 1 second'
          and exp_dttm             >= to_date('20190601', 'YYYYMMDD')
          and sdp_mrf_id           in (1,4)
          and account              is not null    
      )sa
    ) sad where san_rn=1
	) sad_2 on sad_2.san = s_t.account_number
where  s_t.has_stb              = 'Да'
   and s_t.subscriber_is_test   = 'Нет'
   and s_t.is_deleted           = 0
   and s_t.mrf_id in (1,4)
   and 000157 = 151
   and s_t.subcriber_type_name  = 'Физ.лицо'
   and s_t.iptv_eff_dttm       <= to_date('20190601', 'YYYYMMDD') + interval '1 month - 1 second'
   and s_t.iptv_exp_dttm       >= to_date('20190601', 'YYYYMMDD')
) mrf_11
union
select san,
       account,
       mrf_id,
	   src_id
  from 
(
select distinct
       s_t.account_number                                     as san
     , sad_2.account
     , decode(s_t.mrf_id,1,11,4,10,5,12,9,13,7,14,8,15,6,16,3,17)  as mrf_id
     , 000157 as src_id
 from  edw_ods.t_000195_v_iptv_dim_subscriber s_t
 join (
 select san,
        account
 from ( select         
        san,
        account,
        row_number() over (partition by san order by rn) as san_rn
      from 
      (    
        select
          san,
          account,
          2 as rn
        from
          (
            select
              household as san,
              account         ,
              row_number() over (
                               partition by household
                               order by
                                 di desc) rn
            from
              edw_ods.T_000158_sdpdv_SDP_MAP_12
          )
          a
        where
          rn = 1
          
        union all
        
        select  
          account_number as san,
          oss_account_number as account,
          1 as rn
        from
            edw_ods.t_000195_v_iptv_dim_subscriber
        where
          iptv_eff_dttm            <=to_date('20190601', 'YYYYMMDD') + interval '1 month - 1 second'
          and iptv_exp_dttm        >=to_date('20190601', 'YYYYMMDD')
          and subscriber_is_test   = 'Нет'
          and subcriber_state_name = 'Active'
          and subcriber_type_name  = 'Физ.лицо'
          and oss_account_number is not null
          and mrf_id in (5)
          
        union all

        select 
          san, 
          account ,
          3 as rn
        from edw_dds.dim_san_account
        where 
          eff_dttm                 <= to_date('20190601', 'YYYYMMDD') + interval '1 month - 1 second'
          and exp_dttm             >= to_date('20190601', 'YYYYMMDD')
          and sdp_mrf_id           in (5)
          and account              is not null          
        
      ) sa
    ) sad where san_rn=1
	) sad_2 on sad_2.san = s_t.account_number
where  s_t.has_stb              = 'Да'
   and s_t.subscriber_is_test   = 'Нет'
   and s_t.is_deleted           = 0
   and s_t.mrf_id in (5)
   and 000157 = 152
   and s_t.subcriber_type_name  = 'Физ.лицо'
   and s_t.iptv_eff_dttm       <= to_date('20190601', 'YYYYMMDD') + interval '1 month - 1 second'
   and s_t.iptv_exp_dttm       >= to_date('20190601', 'YYYYMMDD')
) mrf_12
union
select san,
       account,
       mrf_id,
	   src_id
  from 
(
select distinct
       s_t.account_number                                     as san
     , sad_2.account
     , decode(s_t.mrf_id,1,11,4,10,5,12,9,13,7,14,8,15,6,16,3,17)  as mrf_id
     , 000157 as src_id
 from  edw_ods.t_000195_v_iptv_dim_subscriber s_t
 join (
 select san,
        account
 from ( select         
        san,
        account,
        row_number() over (partition by san order by rn) as san_rn
      from 
      (    
        select
          san,
          account,
          2 as rn
        from
          (
            select
              uss_login     san     ,
              ab_account as account ,
              row_number() over (
                               partition by uss_login
                               order by
                                 modify_date desc) rn
            from
              edw_ods.T_000153_sdpdv_SDP_MAP sd
            where
              ab_account is not null
          )
          u
        where
          rn = 1
          
        union all
        
        select  
          account_number as san,
          oss_account_number as account,
          1 as rn
        from
            edw_ods.t_000195_v_iptv_dim_subscriber
        where
          iptv_eff_dttm            <=to_date('20190601', 'YYYYMMDD') + interval '1 month - 1 second'
          and iptv_exp_dttm        >=to_date('20190601', 'YYYYMMDD')
          and subscriber_is_test   = 'Нет'
          and subcriber_state_name = 'Active'
          and subcriber_type_name  = 'Физ.лицо'
          and oss_account_number is not null
          and mrf_id in (9)
          
        union all

        select 
          san, 
          account ,
          3 as rn
        from edw_dds.dim_san_account
        where 
          eff_dttm                 <= to_date('20190601', 'YYYYMMDD') + interval '1 month - 1 second'
          and exp_dttm             >= to_date('20190601', 'YYYYMMDD')
          and sdp_mrf_id           in (9)
          and account              is not null    
        
      ) sa
    ) sad where san_rn=1
	) sad_2 on sad_2.san = s_t.account_number
where  s_t.has_stb              = 'Да'
   and s_t.subscriber_is_test   = 'Нет'
   and s_t.is_deleted           = 0
   and s_t.mrf_id in (9)
   and 000157 = 153
   and s_t.subcriber_type_name  = 'Физ.лицо'
   and s_t.iptv_eff_dttm       <= to_date('20190601', 'YYYYMMDD') + interval '1 month - 1 second'
   and s_t.iptv_exp_dttm       >= to_date('20190601', 'YYYYMMDD')
) mrf_13
union
select san,
       account,
       mrf_id,
	   src_id
  from 
(
select distinct
       s_t.account_number                                     as san
     , sad_2.account
     , decode(s_t.mrf_id,1,11,4,10,5,12,9,13,7,14,8,15,6,16,3,17)  as mrf_id
     , 000157 as src_id
 from  edw_ods.t_000195_v_iptv_dim_subscriber s_t
 join (
 select san,
        account
 from ( select         
        san,
        account,
        row_number() over (partition by san order by rn) as san_rn
      from 
      (     
        select
          san,
          account,
          2 as rn
        from
          (
            select
              san                ,
              account as account ,
              row_number() over (
                               partition by san
                               order by
                                 table_num,
                                 rn_low) as rn
            from
              (
                select
                  visual_code as san,
                  account,
                  2   as table_num,
                  row_number() over (
                                   partition by subscribers_dwh.visual_code
                                   order by
                                     subscribers_dwh.date_snap desc,
                                     subscribers_dwh.log_id desc) as rn_low
                from
                  edw_ods.t_000154_rprt_subscribers_dwh subscribers_dwh
                where
                  subscribers_dwh.mrf_id in (14)
                  and coalesce(format_version,'') not like 'VIRT%'
                  and account                  is not null
                union all
                select
                  visual_code,
                  account    ,
                  1          ,
                  row_number() over (
                                   partition by visual_code
                                   order by
                                     account desc)
                from
                  edw_ods.t_000154_rprtsubscribersactual
                where
                  mrf_id in (14)
                  and coalesce(format_version,'') not like 'VIRT%'
                  and account                  is not null
              )
              pre_sub
          )
          o
        where
          rn = 1

        union all
        
        select  
          account_number as san,
          oss_account_number as account,
          1 as rn
        from
            edw_ods.t_000195_v_iptv_dim_subscriber
        where
          iptv_eff_dttm            <=to_date('20190601', 'YYYYMMDD') + interval '1 month - 1 second'
          and iptv_exp_dttm        >=to_date('20190601', 'YYYYMMDD')
          and subscriber_is_test   = 'Нет'
          and subcriber_state_name = 'Active'
          and subcriber_type_name  = 'Физ.лицо'
          and oss_account_number is not null
          and mrf_id in (7)
          
        union all

        select 
          san, 
          account ,
          3 as rn
        from edw_dds.dim_san_account
        where 
          eff_dttm                 <= to_date('20190601', 'YYYYMMDD') + interval '1 month - 1 second'
          and exp_dttm             >= to_date('20190601', 'YYYYMMDD')
          and sdp_mrf_id           in (7)
          and account              is not null              
      ) sa
    ) sad where san_rn=1
	) sad_2 on sad_2.san = s_t.account_number
where  s_t.has_stb              = 'Да'
   and s_t.subscriber_is_test   = 'Нет'
   and s_t.is_deleted           = 0
   and s_t.mrf_id in (7)
   and 000157 = 154
   and s_t.subcriber_type_name  = 'Физ.лицо'
   and s_t.iptv_eff_dttm       <= to_date('20190601', 'YYYYMMDD') + interval '1 month - 1 second'
   and s_t.iptv_exp_dttm       >= to_date('20190601', 'YYYYMMDD')
) mrf_14

union
select san,
       account,
       mrf_id,
	   src_id
  from 
(
select distinct
       s_t.account_number                                     as san
     , sad_2.account
     , decode(s_t.mrf_id,1,11,4,10,5,12,9,13,7,14,8,15,6,16,3,17)  as mrf_id
     , 000157 as src_id
 from  edw_ods.t_000195_v_iptv_dim_subscriber s_t
 join (
 select san,
        account
 from ( select         
        san,
        account,
        row_number() over (partition by san order by rn) as san_rn
      from 
      (        
        select
          san,
          account,
          2 as rn
        from
          (
            select
              san                ,
              account as account ,
              row_number() over (
                               partition by san
                               order by
                                 table_num,
                                 rn_low) as rn
            from
              (
                select
                  login     as san,
                  account,
                  2 as table_num,
                  row_number() over (
                                   partition by subscribers_dwh.login
                                   order by
                                     subscribers_dwh.date_snap desc,
                                     subscribers_dwh.log_id desc) as rn_low
                from
                  edw_ods.t_000155_rprt_subscribers_dwh subscribers_dwh
                where
                  subscribers_dwh.mrf_id in (15)
                  and coalesce(format_version,'') not like 'VIRT%'
                  and account                  is not null
                  and login                           like '77%'
                  and serv_id                            =3
                union all
                select
                  login   ,
                  account ,
                  1       ,
                  row_number() over (
                                   partition by login
                                   order by
                                     account desc)
                from
                  edw_ods.t_000155_rprtsubscribersactual
                where
                  mrf_id in (15)
                  and coalesce(format_version,'') not like 'VIRT%'
                  and account                  is not null
                  and login                           like '77%'
                  and serv_id                            =33
              )
              pre_sub 
          )
          o
        where
          rn = 1
          
        union all
        
        select  
          account_number as san,
          oss_account_number as account,
          1 as rn
        from
            edw_ods.t_000195_v_iptv_dim_subscriber
        where
          iptv_eff_dttm            <=to_date('20190601', 'YYYYMMDD') + interval '1 month - 1 second'
          and iptv_exp_dttm        >=to_date('20190601', 'YYYYMMDD')
          and subscriber_is_test   = 'Нет'
          and subcriber_state_name = 'Active'
          and subcriber_type_name  = 'Физ.лицо'
          and oss_account_number is not null
          and mrf_id in (8)
          
        union all

        select 
          san, 
          account ,
          3 as rn
        from edw_dds.dim_san_account
        where 
          eff_dttm                 <= to_date('20190601', 'YYYYMMDD') + interval '1 month - 1 second'
          and exp_dttm             >= to_date('20190601', 'YYYYMMDD')
          and sdp_mrf_id           in (8)
          and account              is not null    
      ) sa
    ) sad where san_rn=1
	) sad_2 on sad_2.san = s_t.account_number
where  s_t.has_stb              = 'Да'
   and s_t.subscriber_is_test   = 'Нет'
   and s_t.is_deleted           = 0
   and s_t.mrf_id in (8)
   and 000157 = 155
   and s_t.subcriber_type_name  = 'Физ.лицо'
   and s_t.iptv_eff_dttm       <= to_date('20190601', 'YYYYMMDD') + interval '1 month - 1 second'
   and s_t.iptv_exp_dttm       >= to_date('20190601', 'YYYYMMDD')
) mrf_15
union
select san,
       account,
       mrf_id,
	   src_id
  from 
(
select distinct
       s_t.account_number                                     as san
     , sad_2.account
     , decode(s_t.mrf_id,1,11,4,10,5,12,9,13,7,14,8,15,6,16,3,17)  as mrf_id
     , 000157 as src_id
 from  edw_ods.t_000195_v_iptv_dim_subscriber s_t
 join (
 select san,
        account
 from ( select         
        san,
        account,
        row_number() over (partition by san order by rn) as san_rn
      from 
      (     
        select
          san,
          account,
          2 as rn
        from
          (
            select
              SRV_LOGIN_NAME as san,
              account         ,
              row_number() over (partition by srv_login_name order by srv_status_date desc) rn
            from
              edw_ods.T_000158_sdpdv_SDP_MAP_16
          )
          a
        where
          rn = 1
          
        union all
        
        select  
          account_number as san,
          oss_account_number as account,
          1 as rn
        from
            edw_ods.t_000195_v_iptv_dim_subscriber
        where
          iptv_eff_dttm            <=to_date('20190601', 'YYYYMMDD') + interval '1 month - 1 second'
          and iptv_exp_dttm        >=to_date('20190601', 'YYYYMMDD')
          and subscriber_is_test   = 'Нет'
          and subcriber_state_name = 'Active'
          and subcriber_type_name  = 'Физ.лицо'
          and oss_account_number is not null
          and mrf_id in (6)
          
        union all

        select 
          san, 
          account ,
          3 as rn
        from edw_dds.dim_san_account
        where 
          eff_dttm                 <= to_date('20190601', 'YYYYMMDD') + interval '1 month - 1 second'
          and exp_dttm             >= to_date('20190601', 'YYYYMMDD')
          and sdp_mrf_id           in (6)
          and account              is not null    
      ) sa
    ) sad where san_rn=1
	) sad_2 on sad_2.san = s_t.account_number
where  s_t.has_stb              = 'Да'
   and s_t.subscriber_is_test   = 'Нет'
   and s_t.is_deleted           = 0
   and s_t.mrf_id in (6)
   and 000157 = 156
   and s_t.subcriber_type_name  = 'Физ.лицо'
   and s_t.iptv_eff_dttm       <= to_date('20190601', 'YYYYMMDD') + interval '1 month - 1 second'
   and s_t.iptv_exp_dttm       >= to_date('20190601', 'YYYYMMDD')
) mrf_16
union
select san,
       account,
       mrf_id,
	   src_id
  from 
(
select distinct
       s_t.account_number                                     as san
     , sad_2.account
     , decode(s_t.mrf_id,1,11,4,10,5,12,9,13,7,14,8,15,6,16,3,17)  as mrf_id
     , 000157 as src_id
 from  edw_ods.t_000195_v_iptv_dim_subscriber s_t
 join (
 select san,
        account
 from ( select         
        san,
        account,
        row_number() over (partition by san order by rn) as san_rn
      from 
      (      
        select
          san,
          account,
          2 as rn
        from
          (
            select
              uss_login     san     ,
              ab_account as account ,
              row_number() over (
                               partition by uss_login
                               order by
                                 modify_date desc) rn
            from
              edw_ods.T_000157_sdpdv_SDP_MAP sd
            where
              ab_account is not null
          )
          u
        where
          rn = 1
          
        union all
        
        select  
          account_number as san,
          oss_account_number as account,
          1 as rn
        from
            edw_ods.t_000195_v_iptv_dim_subscriber
        where
          iptv_eff_dttm            <=to_date('20190601', 'YYYYMMDD') + interval '1 month - 1 second'
          and iptv_exp_dttm        >=to_date('20190601', 'YYYYMMDD')
          and subscriber_is_test   = 'Нет'
          and subcriber_state_name = 'Active'
          and subcriber_type_name  = 'Физ.лицо'
          and oss_account_number is not null
          and mrf_id in (3)
          
        union all

        select 
          san, 
          account ,
          3 as rn
        from edw_dds.dim_san_account
        where 
          eff_dttm                 <= to_date('20190601', 'YYYYMMDD') + interval '1 month - 1 second'
          and exp_dttm             >= to_date('20190601', 'YYYYMMDD')
          and sdp_mrf_id           in (3)
          and account              is not null    
      ) sa
    ) sad where san_rn=1
	) sad_2 on sad_2.san = s_t.account_number
where  s_t.has_stb              = 'Да'
   and s_t.subscriber_is_test   = 'Нет'
   and s_t.is_deleted           = 0
   and s_t.mrf_id in (3)
   and 000157 = 157
   and s_t.subcriber_type_name  = 'Физ.лицо'
   and s_t.iptv_eff_dttm       <= to_date('20190601', 'YYYYMMDD') + interval '1 month - 1 second'
   and s_t.iptv_exp_dttm       >= to_date('20190601', 'YYYYMMDD')
) mrf_17;
analyze edw_stg_dmcm.san_cl_prf_1_prt_p000157;

--0
truncate table edw_stg_dmcm.oo_eff_tp_cp_1_prt_p000157;
commit;
insert into edw_stg_dmcm.oo_eff_tp_cp_1_prt_p000157 ( p2_mrf_id
                                                         , p3_rf_id
                                                         , account
                                                         , hflat
                                                         , date_start
                                                         , date_close
                                                         , p1_period
                                                         , serv_id
                                                         , tech_id
                                                         , abn_id
                                                         , charge_only_flag
                                                         , p24_qnt_end_rp_shpd
                                                         , p81_qnt_end_rp_ota
                                                         , p83_qnt_end_rp_iptv
                                                         --, p??_qnt_end_rp_ktv -- 25.07.2019 КТВ
                                                         , tech_dt
                                                         , src_id
                                                         )
select case when oo_eff_tp.p3_rf_id in ('1151','1003') then 10 else oo_eff_tp.p2_mrf_id end as p2_mrf_id
     , case when oo_eff_tp.p3_rf_id in ('1316') then 1314 else oo_eff_tp.p3_rf_id end as p3_rf_id
     , oo_eff_tp.account
     , oo_eff_tp.hflat
     , oo_eff_tp.date_start
     , coalesce(oo_eff_tp.date_close, date '2999-12-31 00:00:00') date_close
     , oo_eff_tp.p1_period
     , oo_eff_tp.serv_id
     , coalesce(oo_eff_tp.tech_id, -1)
     , oo_eff_tp.abn_id
     , oo_eff_tp.charge_only_flag
     , oo_eff_tp.p24_qnt_end_rp_shpd
     , oo_eff_tp.p81_qnt_end_rp_ota
     , oo_eff_tp.p83_qnt_end_rp_iptv
     , oo_eff_tp.tech_dt
     , 000157
 from  edw_ods.t_000157_efftp_oo_eff_tp    oo_eff_tp
 inner join (select abn_id, serv_id, row_number() over (partition by abn_id order by serv_id desc) as rn
              from (select abn_id, serv_id
                     from  edw_ods.t_000157_efftp_oo_eff_tp    oo_eff_tp
                     where oo_eff_tp.tech_dt = to_date('20190601', 'YYYYMMDD')
                     group by abn_id, serv_id 
                   )s
            )t2 on oo_eff_tp.abn_id = t2.abn_id and oo_eff_tp.serv_id = t2.serv_id and t2.rn = 1
 where oo_eff_tp.tech_dt = to_date('20190601', 'YYYYMMDD')
   and oo_eff_tp.serv_id in (1,2,3,4) -- serv_id = 4 25.07.2019 КТВ
   and oo_eff_tp.abn_id is not null
   and oo_eff_tp.account is not null
union
select wink.p2_mrf_id
     , wink.p3_rf_id
     , wink.account
     , wink.hflat
     , wink.date_start
     , coalesce(wink.date_close, date '2999-12-31 00:00:00') date_close
     , wink.p1_period
     , wink.serv_id
     , coalesce(wink.tech_id, -1)
     , wink.abn_id
     , wink.charge_only_flag
     , wink.p24_qnt_end_rp_shpd
     , wink.p81_qnt_end_rp_ota
     , wink.p83_qnt_end_rp_iptv
     , wink.tech_dt
     , 000157 as src_id
 from (select distinct
              decode(wo_wink.mrf_id,1,11,4,10,5,12,9,13,7,14,8,15,6,16,3,17) as p2_mrf_id
            , -1 as p3_rf_id
            , wo_wink.san as account
            , coalesce('-'||wo_wink.san) as hflat
            , dt.date_start
            , date '2999-12-31 00:00:00' as date_close
            , to_char(to_date('20190601', 'YYYYMMDD'), 'YYYYMM')::numeric as p1_period
            , -1 as serv_id
            , -1 as tech_id
            , -1 as abn_id
            , 0 as charge_only_flag
            , 0 as p24_qnt_end_rp_shpd
            , 0 as p81_qnt_end_rp_ota
            , 1 as p83_qnt_end_rp_iptv
            , to_date('20190601', 'YYYYMMDD') as tech_dt
        from (select distinct
                     mrf_id
                   , san
               from (select san
                          , mrf_id
                      from (select distinct
                                   coalesce(s_t.account_number,s_p.account_number) as san
                                 , coalesce(s_t.mrf_id,s_p.mrf_id)                 as mrf_id
                                 , term_check
                                 , max(s_p.has_wink) over(partition by coalesce(s_t.mrf_id,s_p.mrf_id),coalesce(s_t.account_number,s_p.account_number)) as has_wink
                             from (select distinct
                                          s.account_number
                                        , s.mrf_id
                                        , t.id
                                        , coalesce(upper(t.mac),'-') mac
                                        , case when t.terminal_type = 'STB' and t.mac != '-' 
                                               then 1
                                               else 0
                                          end as term_check
                                    from  edw_ods.t_000195_v_iptv_dim_subscriber s
                                    left join edw_ods.t_000195_v_iptv_dim_terminal t on s.dim_subscriber_id = t.subscriber_id
                                                                                    and to_date('20190601', 'YYYYMMDD') + interval '1 month - 1 second' between t.iptv_eff_dttm 
                                                                                                                                                                     and t.iptv_exp_dttm
                                    left join (select hist2.subscriber_id
                                                    , s.account_number
                                                    , s.mrf_id
                                                from  edw_ods.t_000195_v_iptv_hfct_service_state_hist hist2
                                                inner join edw_ods.t_000195_v_iptv_dim_subscriber s on hist2.subscriber_id = s.dim_subscriber_id
                                                where to_date('20190601', 'YYYYMMDD') + interval '1 month - 1 second' between hist2.start_date_short 
                                                                                                                                   and coalesce(hist2.end_date_short, date '2999-12-31')
                                                                                                                                   and hist2.service_status_name    = 'Active'
                                                                                                                                   and lower(hist2.service_name) like '%правл%'
                                              ) hist on s.account_number = hist.account_number
                                                    and s.mrf_id         = hist.mrf_id
                                    where s.has_stb              = 'Да'
                                      and s.subscriber_is_test   = 'Нет'
                                      and s.is_deleted           = 0
                                      and s.subcriber_state_name = 'Active'
                                      and s.subcriber_type_name  = 'Физ.лицо'
                                      and s.iptv_eff_dttm        <=to_date('20190601', 'YYYYMMDD') + interval '1 month - 1 second'
                                      and s.iptv_exp_dttm        >=to_date('20190601', 'YYYYMMDD')
                                      and length(s.account_number)<32
                                  ) s_t
                             full join (select distinct
                                               s.account_number
                                             , s.mrf_id
                                             , coalesce(upper(p.device_mac),'-')  device_mac
                                             , coalesce(s.is_wink, '0') as has_wink
                                         from  edw_ods.t_000195_v_iptv_tfct_purchase   p
                                         join  edw_ods.t_000195_v_iptv_dim_subscriber  s  on p.subscriber_id   = s.dim_subscriber_id
                                         left join edw_ods.t_000195_v_iptv_dim_content dc on dc.dim_content_id = p.content_id
                                         where (  p.purchase_date_short between to_date('20190601', 'YYYYMMDD') and to_date('20190601', 'YYYYMMDD') + interval '1 month - 1 second'
                                               or (    p.start_date<=to_date('20190601', 'YYYYMMDD') + interval '1 month - 1 second'
                                                   and coalesce(p.stop_date,'2999-01-01')>=to_date('20190601', 'YYYYMMDD')
                                                   and is_wink = 1
                                                  )
                                               )
                                           and s.subscriber_is_test   = 'Нет'
                                           and s.is_deleted           = 0
                                           and s.subcriber_state_name = 'Active'
                                           and s.subcriber_type_name  = 'Физ.лицо'
                                           and length(s.account_number)<32
                                       ) s_p on s_t.account_number    = s_p.account_number
                                            and s_t.mac               = s_p.device_mac
                           ) grp
                      where term_check > 0 
                         or has_wink   > 0
                    )  p2 where
                      (        
                        (000157=151 and mrf_id in (1,4)) -- мрф центр -- 151
                        or
                        (000157=152 and mrf_id in (5)  ) -- мрф сз -- 152
                        or
                        (000157=153 and mrf_id in (9)  ) -- мрф волга -- 153
                        or
                        (000157=154 and mrf_id in (7)  ) -- мрф юг --154
                        or
                        (000157=155 and mrf_id in (8)  ) -- мрф урал -- 155
                        or
                        (000157=156 and mrf_id in (6)  ) -- мрф сибирь -- 156
                        or
                        (000157=157 and mrf_id in (3)  ) -- мрф дв -- 157
                      )                       
             ) wo_wink
        left join (select account_number
                        , mrf_id
                        , date_start
                    from (select s.account_number
                               , s.mrf_id
                               , coalesce(s.created_at,'1900-01-01') as date_start
                               , row_number() over( partition by s.account_number, s.mrf_id order by s.iptv_exp_dttm desc) rn
                           from edw_ods.t_000195_v_iptv_dim_subscriber s
                         ) ds
                    where rn = 1 
                  ) dt on wo_wink.san    = dt.account_number 
                      and wo_wink.mrf_id = dt.mrf_id
        where wo_wink.san not in (select oo_eff_tp.account
                                       from  edw_ods.t_000157_efftp_oo_eff_tp    oo_eff_tp
                                       inner join (select abn_id
                                                        , serv_id
                                                        , row_number() over (partition by abn_id order by serv_id desc) as rn
                                                    from (select abn_id
                                                               , serv_id
                                                           from  edw_ods.t_000157_efftp_oo_eff_tp    oo_eff_tp
                                                           where oo_eff_tp.tech_dt = to_date('20190601', 'YYYYMMDD')
                                                           group by abn_id, serv_id 
                                                         )s
                                                  )t2 on oo_eff_tp.abn_id = t2.abn_id 
                                                     and oo_eff_tp.serv_id = t2.serv_id 
                                                     and t2.rn = 1
                                        where oo_eff_tp.tech_dt = to_date('20190601', 'YYYYMMDD')
                                          and oo_eff_tp.serv_id in (1,2,3,4)
                                          and oo_eff_tp.abn_id is not null
                                          and oo_eff_tp.account is not null
                                      union
                                      select distinct m.account
                                        from edw_ods.t_000157_efftp_oo_eff_tp_mvno m 
                                       where m.account_ext is null 
                                         and m.tech_dt = to_date('20190601', 'YYYYMMDD')
                                      union
                                      select eff_tp_all.san as account
                                        from (select eff_tp.account
                                                   , eff_tp.mrf_id
                                                   , san_all.san
                                               from (select oo_eff_tp.account
                                                          , case when oo_eff_tp.p3_rf_id in ('1151','1003') then 10 else oo_eff_tp.p2_mrf_id end as mrf_id
                                                      from  edw_ods.t_000157_efftp_oo_eff_tp oo_eff_tp
                                                      inner join (select abn_id
                                                                       , serv_id
                                                                       , row_number() over (partition by abn_id order by serv_id desc) as rn
                                                                   from (select abn_id, serv_id
                                                                          from  edw_ods.t_000157_efftp_oo_eff_tp    oo_eff_tp
                                                                          where oo_eff_tp.tech_dt = to_date('20190601', 'YYYYMMDD')
                                                                             group by abn_id
                                                                                    , serv_id 
                                                                        )s
                                                                 )t2 on oo_eff_tp.abn_id  = t2.abn_id 
                                                                    and oo_eff_tp.serv_id = t2.serv_id 
                                                                    and t2.rn             = 1
                                                      where oo_eff_tp.tech_dt = to_date('20190601', 'YYYYMMDD')
                                                        and oo_eff_tp.serv_id in (1,2,3,4)
                                                        and oo_eff_tp.abn_id  is not null
                                                        and oo_eff_tp.account is not null
                                                    ) eff_tp
                                               join (select san.account as account
                                                          , san.san as san
                                                          , san.mrf_id
                                                      from  edw_stg_dmcm.san_cl_prf_1_prt_p000157 san -- необходимо собирать до сборки edw_stg_dmcm.oo_eff_tp_cp_1_prt_p000157
                                                    ) san_all on san_all.account = eff_tp.account 
                                                             and san_all.mrf_id = eff_tp.mrf_id
                                             ) eff_tp_all
                                     )
              

      ) wink;
analyze edw_stg_dmcm.oo_eff_tp_cp_1_prt_p000157;

--2
truncate table edw_stg_dmcm.mvno_cl_prf_1_prt_p000157;
commit;
insert into edw_stg_dmcm.mvno_cl_prf_1_prt_p000157 ( abn_id_soo
                                                       , period
                                                       , mrf_id
                                                       , count_mvno
                                                       , src_id
                                                       )
select c.abn_id_soo
     , c.period
     , case when c.rf_id in ('1151','1003') then 10 else c.mrf_id end as mrf_id
     , c.subs_id_mvno::numeric(38,0)  as count_mvno
     , 000157
 from  edw_ods.t_000157_efftp_ooefftpmvnocon  c
 inner join edw_ods.t_000157_efftp_oo_eff_tp_mvno m on m.subs_id = c.subs_id_mvno 
                                                       and m.tech_dt  = c.tech_dt
                                                       and m.mrf_id  = c.mrf_id
 where c.tech_dt = to_date('20190601', 'YYYYMMDD');
analyze edw_stg_dmcm.mvno_cl_prf_1_prt_p000157;

--3
truncate table edw_stg_dmcm.sth_nls_accnt_cl_prf_1_prt_p000157;
insert into edw_stg_dmcm.sth_nls_accnt_cl_prf_1_prt_p000157 ( account
                                                                , nls
                                                                , rf_id
                                                                , mrf_id
                                                                , date_begin 
                                                                , date_end
                                                                , src_id
                                                                )
select account
     , nls
     , rf_id
     , mrf_id
     , date_begin
     , coalesce(lead (date_begin,1) over (partition by account order by date_end)- interval '1 second' ,date_end, date '2999-12-31') as date_end 
     , 000157
 from  edw_ods.t_000158_efftp_south_nls_accnt
 where account is not null
   and date_begin <= to_date('20190601', 'YYYYMMDD') + interval '1 month - 1 second';
analyze edw_stg_dmcm.sth_nls_accnt_cl_prf_1_prt_p000157;

--7
truncate table edw_stg_dmcm.abon_attr_cl_prf_1_prt_p000157;
commit;
insert into edw_stg_dmcm.abon_attr_cl_prf_1_prt_p000157 ( accn_id
                                                            , id
                                                            , src_id
                                                            )
select tab.accn_id
     , tab.id
     , 000157
 from  (select accn_id
             , id
             , row_number() over (partition by accn_id order by mis_src_id asc, dt_load desc) rn 
         from  edw_ods.t_000134_abon_attr) tab
 where tab.rn = 1;
analyze edw_stg_dmcm.abon_attr_cl_prf_1_prt_p000157;

--8
truncate table edw_stg_dmcm.ban_cl_prf_1_prt_p000157;
commit;
insert into edw_stg_dmcm.ban_cl_prf_1_prt_p000157 ( accn_id
                                                      , ban_sms
                                                      , ban_call
                                                      , ban_email
                                                      , ban_red
                                                      , ban_com
                                                      , ban_mark
                                                      , vip_rank_name
                                                      , src_id
                                                      )
select accn_id
     , ban_sms
     , ban_call
     , ban_email
     , ban_red
     , ban_com
     , ban_mark
     , vip_rank_name
     , 000157
 from (select accn_id
            , ban_sms
            , ban_call
            , ban_email
            , ban_red
            , ban_com
            , ban_mark
            , vip_rank_name
            , row_number() over (partition by accn_id order by dt_load desc) rn 
        from  edw_ods.t_000134_ban
      ) tab
 where rn = 1;
analyze edw_stg_dmcm.ban_cl_prf_1_prt_p000157;

--9
truncate table edw_stg_dmcm.delry_method_cl_prf_1_prt_p000157;
commit;
insert into edw_stg_dmcm.delry_method_cl_prf_1_prt_p000157 ( accn_id
                                                               , id
                                                               , src_id
                                                               )
select accn_id
     , id
     , 000157
 from  (select accn_id
             , id
             , row_number() over (partition by accn_id order by mis_src_id asc, dt_load desc) rn 
         from  edw_ods.t_000134_delivery_method
       ) tab
 where rn = 1;
analyze edw_stg_dmcm.delry_method_cl_prf_1_prt_p000157;

--12
truncate table edw_stg_dmcm.email_cl_prf_1_prt_p000157;
commit;
insert into edw_stg_dmcm.email_cl_prf_1_prt_p000157 ( accn_id
                                                        , count_id
                                                        , src_id
                                                        )
select accn_id
     , count_id
     , 000157
 from  (select accn_id
             , row_number() over (partition by accn_id order by mis_src_id asc) rn 
             , count(distinct id) over (partition by accn_id) as count_id 
         from  edw_ods.t_000134_email
       ) tab
 where rn = 1;
analyze edw_stg_dmcm.email_cl_prf_1_prt_p000157;

--13
truncate table edw_stg_dmcm.blka_cl_prf_1_prt_p000157;
commit;
insert into edw_stg_dmcm.blka_cl_prf_1_prt_p000157 ( srvs_id
                                                       , mrf_id
                                                       , block_status_id
                                                       , src_id
                                                       )
select srvs_id
     , mrf_id
     , block_status_id
     , 000157
 from  (select blka.srvs_id,
               blka.mrf_id,
               blka.block_status_id,
               row_number() over (partition by blka.srvs_id order by blka.snapshot_dt desc) rn
         from edw_stg_dmcm.tfct_blka_1_prt_p000157 blka
         where date_trunc('month',blka.snapshot_dt) = to_date('20190601', 'YYYYMMDD')
       ) tab
 where rn = 1;
analyze edw_stg_dmcm.blka_cl_prf_1_prt_p000157;

--15
truncate table edw_stg_dmcm.cpe_m_docnt_cl_prf_1_prt_p000157;
commit;
insert into edw_stg_dmcm.cpe_m_docnt_cl_prf_1_prt_p000157 ( transaction_type
                                                              , equip_id
                                                              , nomenclature_code
                                                              , nomenclature_name
                                                              , amount
                                                              , account
                                                              , mrf_id
                                                              , rf_id
                                                              , date_transfer
                                                              , start_date
                                                              , end_date
                                                              , soo_src_id
                                                              , serv_id
                                                              , src_id
                                                              )
select transaction_type
     , equip_id
     , nomenclature_code
     , nomenclature_name
     , amount
     , account
     , mrf_id
     , rf_id
     , date_transfer
     , start_date
     , end_date
     , soo_src_id
     , serv_id
     , 000157
 from  (select document.transaction_type
             , document.equip_id
             , document.nomenclature_code
             , document.nomenclature_name
             , document.amount
             , case when document.mrf_id = '17' then document.account 
                    else coalesce(oo_eff_tp.account,document.account) 
               end as account
             , document.mrf_id
             , document.rf_id
             , document.date_transfer
             , document.date_create as start_date
             , coalesce(max(date_create) over (partition by document.equip_id, document.soo_src_id order by document.date_create, document.date_end rows between 1 following and 1 following)-interval '1 second', to_date('2999-12-31','YYYY-MM-DD')) as end_date
             , document.soo_src_id
             , case when dim_nomenclature.business_service_key = '10200' then 2
                    when dim_nomenclature.business_service_key = '10101' then 1
                    when dim_nomenclature.business_service_key = '11500' then 0
                    when dim_nomenclature.business_service_key = '10401' then 3
                    else 0 
               end as serv_id
         from (select distinct
                       document.transaction_type
                     , document.equip_id
                     , case when substr(document.account,2,1)='_' then split_part(document.account,'_',2) else document.account end as account
                     , document.nomenclature_code
                     , document.nomenclature_name
                     , document.amount
                     , document.abn_id
                     , document.mrf_id
                     , document.rf_id
                     , document.date_transfer
                     , document.date_create as date_create
                     , document.date_end as date_end
                     , document.soo_src_id
                 from  edw_ods.t_000157_cpe_cpe_m_document document
              ) document
         left join edw_dds.dim_nomenclature dim_nomenclature on document.nomenclature_code = dim_nomenclature.nomenclature_code
         left join (select distinct 
                           abn_id
                         , account 
                     from  edw_ods.t_000157_efftp_oo_eff_tp oo_eff_tp 
                     where coalesce (charge_only_flag, 0) != 1
                       and oo_eff_tp.serv_id in (1,2,3,4) -- serv_id = 4 25.07.2019 КТВ
                       and abn_id is not null 
                       and oo_eff_tp.tech_dt = to_date('20190601', 'YYYYMMDD')
                   ) oo_eff_tp on document.abn_id = oo_eff_tp.abn_id
         where document.date_transfer is not null  
       ) tab;
analyze edw_stg_dmcm.cpe_m_docnt_cl_prf_1_prt_p000157;

----18
truncate table edw_stg_dmcm.pre_cntr_1_prt_p000157;
commit;
insert into edw_stg_dmcm.pre_cntr_1_prt_p000157 ( account
                                                    , mrf_id
                                                    , rf_id
                                                    , cntrct_id
                                                    , src_id
                                                      )
select distinct
       account
     , mrf_id
     , rf_id
     , cntrct_id
     , 000157 as src_id
from
(
select distinct
      oo_eff_tp.account                                                                                           as account,
      case when oo_eff_tp.p3_rf_id in ('1151','1003') then 10 else oo_eff_tp.p2_mrf_id end                        as mrf_id,
      case when oo_eff_tp.p3_rf_id in ('1316') then 1314 else oo_eff_tp.p3_rf_id end                              as rf_id,
      oo_eff_tp.p2_mrf_id||'#'||coalesce(nls_acc.nls, oo_eff_tp.account)||'#'||coalesce(subscribers.clie_id, '')  as cntrct_id
    from
      (
        select distinct
          oo_eff_tp.p2_mrf_id ,
          case when oo_eff_tp.p3_rf_id in (1316) then 1314 else oo_eff_tp.p3_rf_id end as p3_rf_id,
          oo_eff_tp.account     
        from
          edw_ods.t_000157_efftp_oo_eff_tp oo_eff_tp
          inner join
            (
              select
                abn_id  ,
                serv_id ,
                row_number() over (partition by abn_id order by serv_id desc) as rn
              from
                (
                  select
                    abn_id ,
                    serv_id
                  from
                    edw_ods.t_000157_efftp_oo_eff_tp oo_eff_tp
                  where
                    oo_eff_tp.tech_dt =to_date('20190601', 'YYYYMMDD')
                  group by
                    abn_id,
                    serv_id
                )
                s
            )
            t2
            on
              oo_eff_tp.abn_id      = t2.abn_id
              and oo_eff_tp.serv_id = t2.serv_id
              and t2.rn             = 1
        where
          oo_eff_tp.tech_dt = to_date('20190601', 'YYYYMMDD')
          and oo_eff_tp.serv_id in (1,2,3)
          and oo_eff_tp.abn_id  is not null
          and oo_eff_tp.account is not null
          and
          (
            oo_eff_tp.date_close         >= date_trunc('month', to_date('20190601', 'YYYYMMDD'))
            or oo_eff_tp.date_close is null
          )
      )
      oo_eff_tp
      left join
        (
            select distinct
              account      ,
              clie_id
            from 
              edw_dmcm.tfct_cntr_hist_1_prt_p000157
            where 
              --cntr_dttm=to_date('20190601', 'yyyymmdd') --cntr_dttm=eff_dttm+ 1 месяц
              eff_dttm=to_date('20190601', 'YYYYMMDD')- interval '1 month'
        )
        subscribers
        on
          oo_eff_tp.account = subscribers.account
      left join edw_stg_dmcm.sth_nls_accnt_cl_prf_1_prt_p000157 nls_acc
        on
          nls_acc.rf_id       = oo_eff_tp.p3_rf_id
          and nls_acc.mrf_id  = oo_eff_tp.p2_mrf_id
          and nls_acc.account = oo_eff_tp.account
          and to_date('20190601', 'YYYYMMDD') + interval '1 month - 1 second' between nls_acc.date_begin and nls_acc.date_end
) cntr;
analyze edw_stg_dmcm.pre_cntr_1_prt_p000157;

--load tfct_client_prof
truncate table edw_stg_dmcm.tfct_client_prof_1_prt_p000157;
commit;
insert into edw_stg_dmcm.tfct_client_prof_1_prt_p000157 ( mrf_id
                                                            , rf_id
                                                            , accn_id
                                                            , cm_id
                                                            , cstm_id
                                                            , dt_start_accn
                                                            , m_region
                                                            , region
                                                            , accn_status
                                                            , block_status
                                                            , vip_rank
                                                            , dt_end_accn
                                                            , lt_cstm
                                                            , brthd
                                                            , gndr
                                                            , email_cnt
                                                            , mob_cnt
                                                            , fix_cnt
                                                            , cntct_email_bill
                                                            , cntrct_id
                                                            , cntct_address
                                                            , cntr_type_bill
                                                            , bonus_on
                                                            , elk_on
                                                            , fix_on
                                                            , bb_cprm_on
                                                            , bb_opt_on
                                                            , iptv_on
                                                            , iptv2_on
                                                            , mvno_on
                                                            , ktv_analog_on -- 25.07.2019 КТВ Аналоговое
                                                            , ktv_cifra_on -- 25.07.2019 КТВ Цифровое
                                                            , srvs_fix_cnt_cstm
                                                            , srvs_bb_cprm_cnt_cstm
                                                            , srvs_bb_opt_cnt_cstm
                                                            , srvs_iptv_cnt_cstm
                                                            , srvs_iptv_cnt_san
                                                            , srvs_iptv_2_cnt_cstm
                                                            , srvs_mvno_cnt_cstm
                                                            , srvs_analog_cnt_cstm -- 25.07.2019 КТВ Аналоговое
                                                            , srvs_cifra_cnt_cstm -- 25.07.2019 КТВ Цифровое
                                                            , ban_com
                                                            , is_wink -- 09.09.2019 Добавлен признак Wink
                                                            , eff_dttm
                                                            , exp_dttm
                                                            , load_dttm
                                                            , src_id
                                                            )
with eff_tp as (
  select coalesce(south_nls_account.nls, oo_eff_tp.account, '0') as account
      , min(coalesce(oo_eff_tp.date_start,'1900-01-01')) as  dt_start_accn
      , max(case when coalesce(oo_eff_tp.date_close, to_date('29991231', 'YYYYMMDD')) > to_date('29991231', 'YYYYMMDD') then to_date('29991231', 'YYYYMMDD') else coalesce(oo_eff_tp.date_close,to_date('29991231', 'YYYYMMDD')) end ) as  dt_end_accn
      , to_date('20190601', 'YYYYMMDD') + interval '1 month - 1 second' as exp_dttm
  from  edw_ods.t_000157_efftp_oo_eff_tp oo_eff_tp
  left join edw_stg_dmcm.sth_nls_accnt_cl_prf_1_prt_p000157 south_nls_account on  south_nls_account.rf_id   = oo_eff_tp.p3_rf_id
                                                                and south_nls_account.mrf_id  = oo_eff_tp.p2_mrf_id 
                                                                and south_nls_account.account = oo_eff_tp.account
                                                                and to_date('20190601', 'YYYYMMDD') + interval '1 month - 1 second' between south_nls_account.date_begin and south_nls_account.date_end
                                                                and south_nls_account.src_id = 000157
  where oo_eff_tp.tech_dt <= to_date('20190601', 'YYYYMMDD')
    and oo_eff_tp.serv_id <> 0
    and oo_eff_tp.date_start is not null
  group by coalesce(south_nls_account.nls, oo_eff_tp.account, '0')
),
life_time as (select pre_lt.account
                       , least(pre_lt.dt_start_accn, pre_lt_MVNO.dt_start_accn) AS dt_start_accn
                       , greatest(pre_lt.dt_end_accn, pre_lt_MVNO.dt_end_accn) AS dt_end_accn
                       , case when pre_lt.exp_dttm < pre_lt.dt_end_accn 
                              then date_part('day',pre_lt.exp_dttm + interval '1 second' - least(pre_lt.dt_start_accn, pre_lt_MVNO.dt_start_accn))
                              else date_part('day',date_trunc('DAY', greatest(pre_lt.dt_end_accn, pre_lt_MVNO.dt_end_accn)) - date_trunc('DAY', least(pre_lt.dt_start_accn, pre_lt_MVNO.dt_start_accn)))
                         end as lt_cstm
                   from (
            select account
								 , dt_start_accn
								 , dt_end_accn
								 , exp_dttm
							  from  eff_tp
							union
							select account
								 , dt_start_accn
								 , dt_end_accn
								 , exp_dttm
							  from
							(
							select coalesce(south_nls_account.nls, oo_eff_tp.account, '0') as account
								  , min(coalesce(oo_eff_tp.date_start,'1900-01-01')) as  dt_start_accn
								  , max(case when coalesce(oo_eff_tp.date_close, to_date('29991231', 'YYYYMMDD')) > to_date('29991231', 'YYYYMMDD') then to_date('29991231', 'YYYYMMDD') else coalesce(oo_eff_tp.date_close,to_date('29991231', 'YYYYMMDD')) end ) as  dt_end_accn
								  , to_date('20190601', 'YYYYMMDD') + interval '1 month - 1 second' as exp_dttm
							  from  edw_stg_dmcm.oo_eff_tp_cp_1_prt_p000157 oo_eff_tp
							  left join edw_stg_dmcm.sth_nls_accnt_cl_prf_1_prt_p000157 south_nls_account on  south_nls_account.rf_id   = oo_eff_tp.p3_rf_id
																							and south_nls_account.mrf_id  = oo_eff_tp.p2_mrf_id 
																							and south_nls_account.account = oo_eff_tp.account
																							and to_date('20190601', 'YYYYMMDD') + interval '1 month - 1 second' between south_nls_account.date_begin and south_nls_account.date_end
																							and south_nls_account.src_id = 000157
							  where oo_eff_tp.serv_id <> 0
								and oo_eff_tp.date_start is not null
								and coalesce(south_nls_account.nls, oo_eff_tp.account, '0') not in 
								(
								select account from eff_tp
								)
							  group by coalesce(south_nls_account.nls, oo_eff_tp.account, '0')
							) t_2
                                           
                        ) pre_lt
                   left join (select coalesce(south_nls_account.nls, m.account_ext, '0') as account
                                   , min(coalesce(m.data_activ,to_date('19000101','YYYYMMDD'))) as  dt_start_accn
                                   , max(case when coalesce(m.end_rtpl, to_date('29991231', 'YYYYMMDD')) > to_date('29991231', 'YYYYMMDD') then to_date('29991231', 'YYYYMMDD') else coalesce(m.end_rtpl,to_date('29991231', 'YYYYMMDD')) end ) as  dt_end_accn
                                   , to_date('20190601', 'YYYYMMDD') + interval '1 month - 1 second' as exp_dttm
                               from  edw_ods.t_000157_efftp_oo_eff_tp_mvno m 
                               left join edw_stg_dmcm.sth_nls_accnt_cl_prf_1_prt_p000157 south_nls_account on  south_nls_account.rf_id   = m.rf_id
                                                                                             and south_nls_account.mrf_id  = m.mrf_id 
                                                                                             and south_nls_account.account = m.account_ext
                                                                                             and to_date('20190601', 'YYYYMMDD') + interval '1 month - 1 second' between south_nls_account.date_begin and south_nls_account.date_end
                                                                                             and south_nls_account.src_id = 000157               
                               where m.account_ext is not null 
                                 and m.data_activ is not null 
                                 and m.tech_dt <= to_date('20190601', 'YYYYMMDD')
                               group by coalesce(south_nls_account.nls, m.account_ext, '0')
                             )  pre_lt_mvno on pre_lt.account = pre_lt_mvno.account
                  )
select tab2.mrf_id
     , tab2.rf_id
     , tab2.accn_id
     , tab2.cm_id
     , tab2.cstm_id
     , lt.dt_start_accn--tab2.dt_start_accn
     , tab2.m_region
     , coalesce(tab2.region,'') as region
     , case when lt.dt_end_accn > tab2.exp_dttm then 'активен' 
            else 'закрыт' 
       end  as  accn_status
     , tab2.block_status
     , coalesce(ban.vip_rank_name,'') as vip_rank --vip_rank
     , lt.dt_end_accn--tab2.dt_end_accn
     , lt.lt_cstm as lt_cstm
     , coalesce(abon_attr.id, 0) as brthd--brthd
     , coalesce(abon_attr.id, 0) as gndr--gndr
     , coalesce(email.count_id,0) as email_cnt--email_cnt
     , coalesce(mob.cntct_mob,0) as mob_cnt--mob_cnt
     , coalesce(fix.cntct_fix,0) as fix_cnt--fix_cnt
     , coalesce(email.accn_id,'0') as cntct_email_bill--cntct_email_bill
     , tab2.cntrct_id
     , coalesce(delivery_method.id,0) as cntct_address--, cntct_address
     , coalesce(delivery_method.id,0) as cntr_type_bill--, cntr_type_bill
     , coalesce(dim_supl_customer.bonus_on,0) as bonus_on
     , case when elk.accn_id is not null then 1 
            else 0 
       end as  elk_on--, elk_on
     , tab2.fix_on
     , tab2.bb_cprm_on
     , tab2.bb_opt_on
     , case when tab2.srvs_iptv_cnt_cstm >= coalesce(cpe_m_document.count_ip2,0) and coalesce(cpe_m_document.count_ip2,0) != 0 and tab2.srvs_iptv_cnt_cstm - coalesce(cpe_m_document.count_ip2,0) = 0 then 0 
            else iptv_on 
       end as iptv_on
     , case when tab2.srvs_iptv_cnt_cstm >= coalesce(cpe_m_document.count_ip2,0) and coalesce(cpe_m_document.count_ip2,0) != 0 then 1 
            else 0 
       end as iptv2_on
     , tab2.mvno_on
     , tab2.ktv_analog_on -- 25.07.2019 КТВ Аналоговое
     , tab2.ktv_cifra_on -- 25.07.2019 КТВ Цифровое
     , tab2.srvs_fix_cnt_cstm
     , tab2.srvs_bb_cprm_cnt_cstm
     , tab2.srvs_bb_opt_cnt_cstm
     , case when tab2.srvs_iptv_cnt_cstm >= coalesce(cpe_m_document.count_ip2,0) then tab2.srvs_iptv_cnt_cstm - coalesce(cpe_m_document.count_ip2,0) 
            else tab2.srvs_iptv_cnt_cstm 
       end as srvs_iptv_cnt_cstm
     , tab2.srvs_iptv_cnt_san
     , case when tab2.srvs_iptv_cnt_cstm >= coalesce(cpe_m_document.count_ip2,0) then coalesce(cpe_m_document.count_ip2,0) 
            else 0 
       end as srvs_iptv_2_cnt_cstm
     , tab2.srvs_mvno_cnt_cstm
     , tab2.srvs_analog_cnt_cstm -- 25.07.2019 КТВ Аналоговое
     , tab2.srvs_cifra_cnt_cstm -- 25.07.2019 КТВ Цифровое
     , case when coalesce(ban.ban_sms, 0)   != 0 
             and coalesce(ban.ban_call, 0)  != 0 
             and coalesce(ban.ban_email, 0) != 0 
             and coalesce(ban.ban_red, 0)   != 0 
             and coalesce(ban.ban_com, 0)   != 0 
             and coalesce(ban.ban_mark, 0)  != 0
             and coalesce(ban2.message_ban,0) != 0 --  09.09.2019 Добавлен признак Message_ban
            then 1 
            else 0 
       end as ban_com
     , coalesce(wink.is_wink, 'Нет') as is_wink -- 09.09.2019 Добавлен признак Wink
     , tab2.eff_dttm
     , tab2.exp_dttm
     , tab2.load_dttm
     , tab2.src_id
     
 from (select tab.mrf_id
            , tab.rf_id
            , tab.accn_id
            , tab.cm_id
            , tab.cstm_id
            , tab.m_region
            , tab.region
            , max(block_status) as block_status
            , tab.cntrct_id
            , tab.bonus_on
            , max(case when tab.serv_id = 1 then 1 
                       else 0 
                  end
                 )                                                                          as  fix_on
            , max(case when tab.serv_id = 2 and coalesce(tab.tech_id, -1) not in (1,2) then 1 
                       else 0 
                  end
                 )                                                                          as  bb_cprm_on
            , max(case when tab.serv_id = 2 and coalesce(tab.tech_id, -1) in (1,2) then 1 
                       else 0 
                  end
                  )                                                                          as  bb_opt_on
            , max(case when tab.serv_id = 3 then 1 
                       else 0 
                  end
                 )                                                                          as  iptv_on
            , max(case when tab.serv_id = 10 then 1 
                       else 0 
                  end
                 )                                                                          as  iptv2_on
            , max(case when mvno.count_mvno is not null then 1 
                       else 0 
                  end
                 )                                                                          as  mvno_on  
            , max(case when tab.serv_id = 4 and coalesce(tab.tech_id, -1) = 9 then 1 
                       else 0 
                  end
                 )                                                                          as  ktv_analog_on -- 25.07.2019 КТВ Аналоговое
            , max(case when tab.serv_id = 4 and coalesce(tab.tech_id, -1) = 10 then 1 
                       else 0 
                  end
                 )                                                                          as  ktv_cifra_on -- 25.07.2019 КТВ Цифровое
            , sum(case when tab.serv_id = 1 then 1 
                       else 0 
                  end
                  )                                                                          as  srvs_fix_cnt_cstm
            , sum(case when tab.serv_id = 2 and coalesce(tab.tech_id, -1) not in (1,2) then 1 
                       else 0 
                  end
                 )                                                                          as  srvs_bb_cprm_cnt_cstm
            , sum(case when tab.serv_id = 2 and coalesce(tab.tech_id, -1) in (1,2) then 1 
                       else 0 
                  end
                  )                                                                          as  srvs_bb_opt_cnt_cstm
            , sum(case when tab.serv_id = 3 
                             then 1 
                             else 0 
                  end
                  )                                                                          as  srvs_iptv_cnt_cstm
            , sum(srvs_iptv_cnt_san)                                                               as  srvs_iptv_cnt_san
            , sum(case when tab.serv_id = 10 then 1 
                       else 0 
                  end
                 )                                                                          as  srvs_iptv_2_cnt_cstm
            , coalesce(count(distinct mvno.count_mvno),0)                                          as  srvs_mvno_cnt_cstm
            , sum(case when tab.serv_id = 4 and coalesce(tab.tech_id, -1) = 9 then 1 
                       else 0 
                  end
                  )                                                                          as  srvs_analog_cnt_cstm -- 25.07.2019 КТВ Аналоговое
            , sum(case when tab.serv_id = 4 and coalesce(tab.tech_id, -1) = 10 then 1 
                       else 0 
                  end
                  )                                                                          as  srvs_cifra_cnt_cstm -- 25.07.2019 КТВ Цифровое
            , tab.eff_dttm
            , tab.exp_dttm
            , now()                                                                          as load_dttm
            , 000157                                                                     as src_id
       from  (select oo_eff_tp.abn_id, oo_eff_tp.serv_id, coalesce(oo_eff_tp.tech_id, -1) as tech_id
                   , oo_eff_tp.p2_mrf_id                                                           as  mrf_id
                   , oo_eff_tp.p3_rf_id                                                            as  rf_id
                   , coalesce(south_nls_account.nls, oo_eff_tp.account, '0')                       as  accn_id
                   , coalesce(oo_eff_tp.hflat, '-'||south_nls_account.nls, '-'||oo_eff_tp.account, '0') as  cm_id
                   , coalesce(south_nls_account.nls,oo_eff_tp.account, '0')                        as  cstm_id
                   , dir_branches_1.def                                                            as  m_region
                   , dir_branches_2.def_short                                                      as  region
                   , oo_eff_tp.p1_period                                                           as  p1_period
                   , max(coalesce(blka.block_status_id,0))                                         as  block_status
                   , coalesce(client_dwh.cntrct_id,'')                                             as  cntrct_id
                   , 0                                                                             as  bonus_on
                   , coalesce(count(distinct coalesce(san.san, san_2.san)),0)                      as  srvs_iptv_cnt_san
                   , to_date(oo_eff_tp.p1_period::varchar, 'YYYYMM')                                        as  eff_dttm
                   , to_date(oo_eff_tp.p1_period::varchar, 'YYYYMM') + interval '1 month - 1 second'        as  exp_dttm
               from  edw_stg_dmcm.oo_eff_tp_cp_1_prt_p000157                                 oo_eff_tp
               left join edw_stg_dmcm.sth_nls_accnt_cl_prf_1_prt_p000157 south_nls_account on south_nls_account.rf_id   = oo_eff_tp.p3_rf_id
                                                                                              and south_nls_account.mrf_id  = oo_eff_tp.p2_mrf_id 
                                                                                              and south_nls_account.account = oo_eff_tp.account
                                                                                              and to_date('20190601', 'YYYYMMDD') + interval '1 month - 1 second' 
                                                                                                  between south_nls_account.date_begin and south_nls_account.date_end
                                                                                              and south_nls_account.src_id = 000157
               left join edw_ods.t_000158_rprt_dir_branches dir_branches_1       on oo_eff_tp.p2_mrf_id       = dir_branches_1.brnc_id
               left join edw_ods.t_000158_rprt_dir_branches dir_branches_2       on oo_eff_tp.p3_rf_id        = dir_branches_2.brnc_id
               left join edw_stg_dmcm.blka_cl_prf_1_prt_p000157 blka         on blka.srvs_id = oo_eff_tp.abn_id::varchar and blka.mrf_id = oo_eff_tp.p2_mrf_id
                                                                                and blka.src_id  = 000157
               left join edw_stg_dmcm.pre_cntr_1_prt_p000157 client_dwh on oo_eff_tp.account = client_dwh.account 
                                                                           and client_dwh.mrf_id = oo_eff_tp.p2_mrf_id -- 09.09.2019 изменена логика протягивания contr_id
               left join edw_stg_dmcm.san_cl_prf_1_prt_p000157 san on san.account             = oo_eff_tp.account
                                                                      and san.src_id              = 000157
                                                                      and san.mrf_id              = oo_eff_tp.p2_mrf_id
               left join (select ddd.mrf_id
                               , ddd.san
                               , ddd.account
                           from (select fff.mrf_id
                                      , fff.sdp_mrf_id
                                      , fff.san
                                      , fff.nls account
                                      , row_number() over ( partition by fff.mrf_id,fff.san order by  fff.startdate desc ,fff.persistdate desc ,fff.nls desc) rn
                                  from (select case when a1.description like '%СЗ%'     then 12
                                                    when a1.description like '%Волга%'  then 13
                                                    when a1.description like '%ДВ%'     then 17
                                                    when a1.description like '%Юг%'     then 14
                                                    when a1.description like '%Сибирь%' then 16
                                                    when a1.description like '%Центр%'  then 11
                                                    when t.client_app_pkid=14           then 15
                                               else -1 end  mrf_id
                                             , case when a1.description like '%СЗ%'     then 5
                                                    when a1.description like '%Волга%'  then 9
                                                    when a1.description like '%ДВ%'     then 3
                                                    when a1.description like '%Юг%'     then 7
                                                    when a1.description like '%Сибирь%' then 6
                                                    when a1.description like '%Центр%'  then 1
                                                    when t.client_app_pkid=14           then 8
                                                    else -1 
                                               end  sdp_mrf_id
                                             , t.san
                                             , d.nls
                                             , t.startdate
                                             , t.enddate
                                             , t.persistdate
                                             , t.changedate
                                             , t.load_dttm
                                             , t.attribute_enddate
                                             , t.attribute_startdate
                                             , t.client_app_pkid
                                             , t.version 
                                         from edw_ods.t_000129_subscriber t
                                            , edw_ods.t_000129_client d
                                            , edw_ods.t_000129_applicationinstance a1
                                         where t.san is not null
                                           and d.nls is not null
                                           and t.client_app_pkid      = d.app_pkid 
                                           and t.client_version       = d.version 
                                           and t.client_localsystemid = d.localsystemid
                                           and d. deleted             = 0  
                                           and t.client_app_pkid      = a1.pkid 
                                           and a1.typeapplication_pkid= 2
                                           and t.startdate <= to_date('20190601', 'YYYYMMDD') + interval '1 month - 1 second' 
                                           and t.version              = 0
                                       ) fff
                                ) ddd
                           where ddd.rn = 1
                         ) san_2 on san_2.account = oo_eff_tp.account
                                and san_2.mrf_id  = oo_eff_tp.p2_mrf_id
               where coalesce(oo_eff_tp.charge_only_flag, 0)  != 1
                 and coalesce(oo_eff_tp.p24_qnt_end_rp_shpd,0) +
                     coalesce(oo_eff_tp.p81_qnt_end_rp_ota,0)  +
                     coalesce(oo_eff_tp.p83_qnt_end_rp_iptv,0) > 0
                 and oo_eff_tp.src_id = 000157
               group by oo_eff_tp.abn_id
                      , oo_eff_tp.serv_id
                      , coalesce(oo_eff_tp.tech_id, -1)
                      , oo_eff_tp.p2_mrf_id
                      , oo_eff_tp.p3_rf_id 
                      , coalesce(south_nls_account.nls, oo_eff_tp.account, '0')
                      , coalesce(oo_eff_tp.hflat, '-'||south_nls_account.nls, '-'||oo_eff_tp.account, '0')
                      , coalesce(client_dwh.cntrct_id,'')
                      , dir_branches_1.def
                      , dir_branches_2.def_short
                      , to_date(oo_eff_tp.p1_period::varchar, 'YYYYMM')
                      , to_date(oo_eff_tp.p1_period::varchar, 'YYYYMM') + interval '1 month - 1 second'
                      , oo_eff_tp.p1_period
             ) tab
       left join edw_stg_dmcm.mvno_cl_prf_1_prt_p000157 mvno on mvno.abn_id_soo = tab.abn_id 
                                                                and mvno.period     = tab.p1_period 
                                                                and mvno.mrf_id     = tab.mrf_id -- Нужно ли добавлять декодирование МРФ Москвы???
                                                                and mvno.src_id     = 000157
       group by tab.mrf_id
              , tab.rf_id
              , tab.accn_id
              , tab.cm_id
              , tab.cstm_id
              , tab.m_region
              , tab.region
              , cntrct_id
              , tab.bonus_on
              , tab.eff_dttm
              , tab.exp_dttm
      ) tab2
 left join life_time lt on tab2.accn_id = lt.account
 left join (select regexp_replace(account,'[0-9]+[_]','') as account, serv_id, count(distinct equip_id) as count_ip2
             from  edw_stg_dmcm.cpe_m_docnt_cl_prf_1_prt_p000157 cpe_m_document
             where serv_id = '3'
               and nomenclature_code in ('065.0002.0096', '065.0002.0088')
               and transaction_type != 51
               and to_date('20190601', 'YYYYMMDD') + interval '1 month - 1 second' between cpe_m_document.start_date and cpe_m_document.end_date
             group by regexp_replace(account,'[0-9]+[_]','')
                    , serv_id
           )cpe_m_document on tab2.accn_id = cpe_m_document.account
                          and tab2.src_id  = 000157
 left join (select account
                 , 1 as bonus_on
             from (select supl_servce_info.address_bill_key as account
                        , dim_supl_customer.mis_eff_dttm
                        , dim_supl_customer.mis_exp_dttm
                    from  edw_ods.t_000133_dwh_dim_supl_customer dim_supl_customer
                    inner join  edw_ods.t_000133_dwh_hfctsuplservceinf supl_servce_info on dim_supl_customer.customer_key = supl_servce_info.customer_key
                    where first_conection_date is not null 
                      and connection_status = 30
                      and dim_supl_customer.mis_eff_dttm < dim_supl_customer.mis_exp_dttm
                    group by supl_servce_info.address_bill_key
                           , dim_supl_customer.mis_eff_dttm
                           , dim_supl_customer.mis_exp_dttm
                  ) dim_supl_customer
             where to_date('20190601', 'YYYYMMDD') + interval '1 month - 1 second' between mis_eff_dttm and mis_exp_dttm  
             group by account
                    , bonus_on
           ) dim_supl_customer on tab2.accn_id = dim_supl_customer.account 
 left join (select distinct accn_id from edw_ods.t_000134_elk) elk on elk.accn_id = tab2.accn_id        
 left join edw_stg_dmcm.abon_attr_cl_prf_1_prt_p000157 abon_attr on abon_attr.accn_id = tab2.accn_id
                                                                    and abon_attr.src_id  = 000157
 left join edw_stg_dmcm.ban_cl_prf_1_prt_p000157 ban on ban.accn_id = tab2.accn_id
                                                        and ban.src_id  = 000157
 left join (select mban.account as accn_id
          , mban.message_ban as message_ban
       from (select coalesce(san.account, taban.account_number) as account
                  , taban.message_ban
                  , san.mrf_id
            , row_number() over(partition by san.account, taban.mrf_id order by taban.iptv_exp_dttm desc, taban.account_number desc) rn
              from (select  sub.account_number
                          , max(coalesce(message_ban,0)) as message_ban
            --              , coalesce(prof.mrf_id,sub.mrf_id) as mrf_id
						  , decode(coalesce(prof.mrf_id,sub.mrf_id),1,11,4,10,5,12,9,13,7,14,8,15,6,16,3,17) as mrf_id
                          , sub.iptv_exp_dttm
                     from  edw_ods.T_000195_V_IPTV_DIM_PROFILE prof
                     left join (select dsub.dim_subscriber_id
                                     , dsub.account_number
                                     , dsub.mrf_id
                                     , dsub.iptv_exp_dttm
                                 from  edw_ods.T_000195_V_IPTV_DIM_SUBSCRIBER dsub
                                 where dsub.iptv_eff_dttm < to_date('20190601', 'YYYYMMDD')+ INTERVAL '1 MONTH - 1 SECOND'
                                   and dsub.iptv_exp_dttm >= to_date('20190601', 'YYYYMMDD')
                                   and dsub.subcriber_state_name in ('Active', 'Blocked')
                                   and dsub.subcriber_type_name  = 'Физ.лицо'
                                   and dsub.subscriber_is_test != 'Да'
                                   and dsub.account_number is not null
                               ) sub on prof.subscriber_id = sub.dim_subscriber_id 
                                    and prof.mrf_id = sub.mrf_id
                     where prof.iptv_eff_dttm < to_date('20190601', 'YYYYMMDD')+ INTERVAL '1 MONTH - 1 SECOND'
                       and prof.iptv_exp_dttm >= to_date('20190601', 'YYYYMMDD')
                     group by sub.account_number, coalesce(prof.mrf_id,sub.mrf_id), sub.iptv_exp_dttm
                   ) taban
              left join (select san
                              , account
                              , mrf_id
                              , src_id
                          from  edw_stg_dmcm.san_cl_prf_1_prt_p000157
                        ) san on taban.mrf_id = san.mrf_id
                             and taban.account_number = san.san
            ) mban
       where mban.account is not null
         and rn = 1
      ) ban2 on ban2.accn_id = tab2.accn_id -- 09.09.2019 Добавлен признак Message_ban
  left join 
  ( 
    select 
      accn_id ,
      mrf_id  ,
      is_wink
    from
    (
      select 
          coalesce(san.account, t.account_number)  as accn_id 
        , coalesce(san.mrf_id,t.mrf_id) as mrf_id
        , t.is_wink is_wink
        ,row_number() over(partition by coalesce(san.account, t.account_number), coalesce(san.mrf_id,t.mrf_id) order by created_at desc) rn
        from
      (
      select
        account_number,
        decode(mrf_id,1,11,4,10,5,12,9,13,7,14,8,15,6,16,3,17) as mrf_id,
        is_wink,
        created_at
      from
        (
          select
            account_number,
            mrf_id        ,
            is_wink       ,
            created_at    ,
            row_number() over(partition by account_number, mrf_id order by iptv_eff_dttm) rn
          from
            (
              select
                account_number,
                mrf_id        ,
                case 
                  when coalesce(is_oss,0)=1
                    and coalesce(is_wink,0)=1
                    and coalesce(has_stb,'Нет')='Да'
                    then 'IPTV'
                  when coalesce(is_oss,0)=0
                    and coalesce(is_wink,0)=1
                    and coalesce(has_stb,'Нет')='Нет'
                    then 'OTT'	
                  else 'Нет'
                end as is_wink,
                iptv_eff_dttm,
                iptv_exp_dttm,
                created_at,
                case
                  when coalesce(lead(iptv_eff_dttm) over (partition by account_number, mrf_id order by iptv_eff_dttm),'2999-01-01')>to_date('20190601', 'YYYYMMDD')+ INTERVAL '1 MONTH - 1 SECOND'
                    then 1
                    else 0
                end chd
              from
                edw_ods.t_000195_v_iptv_dim_subscriber
              where
                iptv_exp_dttm       >= to_date('20190601', 'YYYYMMDD')
                and subscriber_is_test   = 'Нет'
                and subcriber_state_name = 'Active'
                and subcriber_type_name  = 'Физ.лицо'
                and (        
                      (000157=151 and mrf_id in (1,4)) -- мрф центр -- 151
                      or
                      (000157=152 and mrf_id in (5)  ) -- мрф сз -- 152
                      or
                      (000157=153 and mrf_id in (9)  ) -- мрф волга -- 153
                      or
                      (000157=154 and mrf_id in (7)  ) -- мрф юг --154
                      or
                      (000157=155 and mrf_id in (8)  ) -- мрф урал -- 155
                      or
                      (000157=156 and mrf_id in (6)  ) -- мрф сибирь -- 156
                      or
                      (000157=157 and mrf_id in (3)  ) -- мрф дв -- 157
                    )  
            ) subs
          where
            chd=1 
        ) subs2
      where
        rn=1
     )t
     left join (select san
            , account
            , mrf_id
            , src_id
           from  edw_stg_dmcm.san_cl_prf_1_prt_p000157
         ) san on t.mrf_id = san.mrf_id
           and t.account_number = san.san  
    )t2 
    where rn=1  
  ) wink on wink.accn_id = tab2.accn_id 
      and wink.mrf_id = tab2.mrf_id-- 09.09.2019 Добавлен признак Wink
 left join edw_stg_dmcm.delry_method_cl_prf_1_prt_p000157 delivery_method on delivery_method.accn_id = tab2.accn_id
                                                                             and delivery_method.src_id  = 000157
 left join (select accn_id
                 , count(distinct cntct_fix) as cntct_fix
             from  edw_ods.t_000134_fix
             group by accn_id
           ) fix on fix.accn_id = tab2.accn_id
 left join (select accn_id
                 , count(distinct cntct_mob) as cntct_mob
             from  edw_ods.t_000134_mob 
             group by accn_id
           ) mob on mob.accn_id = tab2.accn_id
 left join edw_stg_dmcm.email_cl_prf_1_prt_p000157  email on email.accn_id = tab2.accn_id;

insert into edw_stg_dmcm.tfct_client_prof_1_prt_p000157 ( mrf_id
                                                            , rf_id
                                                            , accn_id
                                                            , cm_id
                                                            , cstm_id
                                                            , dt_start_accn
                                                            , m_region
                                                            , region
                                                            , accn_status
                                                            , block_status
                                                            , vip_rank
                                                            , dt_end_accn
                                                            , lt_cstm
                                                            , brthd
                                                            , gndr
                                                            , email_cnt
                                                            , mob_cnt
                                                            , fix_cnt
                                                            , cntct_email_bill
                                                            , cntrct_id
                                                            , cntct_address
                                                            , cntr_type_bill
                                                            , bonus_on
                                                            , elk_on
                                                            , fix_on
                                                            , bb_cprm_on
                                                            , bb_opt_on
                                                            , iptv_on
                                                            , iptv2_on
                                                            , mvno_on
                                                            , ktv_analog_on -- 25.07.2019 КТВ Аналоговое
                                                            , ktv_cifra_on -- 25.07.2019 КТВ Цифровое
                                                            , srvs_fix_cnt_cstm
                                                            , srvs_bb_cprm_cnt_cstm
                                                            , srvs_bb_opt_cnt_cstm
                                                            , srvs_iptv_cnt_cstm
                                                            , srvs_iptv_cnt_san
                                                            , srvs_iptv_2_cnt_cstm
                                                            , srvs_mvno_cnt_cstm
                                                            , srvs_analog_cnt_cstm -- 25.07.2019 КТВ Аналоговое
                                                            , srvs_cifra_cnt_cstm -- 25.07.2019 КТВ Цифровое
                                                            , ban_com
                                                            , is_wink -- 09.09.2019 Добавлен признак Wink
                                                            , eff_dttm
                                                            , exp_dttm
                                                            , load_dttm
                                                            , src_id
                                                            )
with life_time as (select pre_lt.account as account
                        , pre_lt.dt_start_accn as dt_start_accn
                        , pre_lt.dt_end_accn as dt_end_accn
                        , case when pre_lt.exp_dttm < pre_lt.dt_end_accn 
                               then date_part('day',pre_lt.exp_dttm + interval '1 second' - pre_lt.dt_start_accn)
                               else date_part('day',date_trunc('DAY', pre_lt.dt_end_accn) - date_trunc('DAY', pre_lt.dt_start_accn))
                          end as lt_cstm
                    from (select m.account
                               , min(coalesce(m.data_activ,to_date('19000101','YYYYMMDD'))) as  dt_start_accn
                               , max(case when coalesce(m.end_rtpl, to_date('29991231', 'YYYYMMDD')) > to_date('29991231', 'YYYYMMDD') then to_date('29991231', 'YYYYMMDD') else coalesce(m.end_rtpl,to_date('29991231', 'YYYYMMDD')) end ) as  dt_end_accn
                               , to_date('20190601', 'YYYYMMDD') + interval '1 month - 1 second' as exp_dttm
                           from  edw_ods.t_000157_efftp_oo_eff_tp_mvno m 
                           where m.account_ext is null 
                             and m.tech_dt <= to_date('20190601', 'YYYYMMDD')
                           group by m.account
                         )  pre_lt
                  )
                  
select mvno.mrf_id as mrf_id -- идентификатор мрф клиента
     , mvno.rf_id as rf_id -- идентификатор рф клиента
     , coalesce(mvno.account,'') as accn_id -- идентификатор/номер лицевого счета (нлс) по единой классификации
     , coalesce('-'||mvno.account,'') as cm_id -- внутренний идентификатор клиента (id мрф+ уникальный id лс)
     , coalesce(mvno.account,'') as cstm_id
     , lt.dt_start_accn as dt_start_accn
     , mvno.m_region as m_region
     , coalesce(mvno.region,'') as region
     , case when mvno.max_end_rtpl > to_date(mvno.period::varchar, 'YYYYMM') + interval '1 month - 1 second' then 'активен' 
            else 'закрыт' 
       end as accn_status
     , mvno.block_status as block_status -- перепроверить
     , coalesce(ban.vip_rank_name,'') vip_rank
     , lt.dt_end_accn as dt_end_accn
     , lt.lt_cstm as lt_cstm
     , coalesce(abon_attr.id, 0) as  brthd
     , coalesce(abon_attr.id, 0) as gndr
     , sum(coalesce(email.count_id,0)) as email_cnt
     , sum(coalesce(mob.cntct_mob,0)) as mob_cnt
     , sum(coalesce(fix.cntct_fix,0)) as fix_cnt
     , coalesce(email.accn_id,'0') as cntct_email_bill
     , 'MVNO' as cntrct_id
     , coalesce(delivery_method.id,0) as cntct_address
     , coalesce(delivery_method.id,0) as cntr_type_bill
     , coalesce(dim_supl_customer.bonus_on,0) as bonus_on
     , 0 as elk_on
     , 0 as fix_on
     , 0 as bb_cprm_on
     , 0 as bb_opt_on
     , 0 as iptv_on
     , 0 as iptv2_on
     , 1 as mvno_on
     , 0 as ktv_analog_on -- 25.07.2019 КТВ Аналоговое
     , 0 as ktv_cifra_on -- 25.07.2019 КТВ Цифровое
     , 0 as srvs_fix_cnt_cstm
     , 0 as srvs_bb_cprm_cnt_cstm
     , 0 as srvs_bb_opt_cnt_cstm
     , 0 as srvs_iptv_cnt_cstm
     , 0 as srvs_iptv_cnt_san
     , 0 as srvs_iptv_2_cnt_cstm
     , mvno.srvs_mvno_cnt_cstm as srvs_mvno_cnt_cstm
     , 0 as srvs_analog_cnt_cstm -- 25.07.2019 КТВ Аналоговое
     , 0 as srvs_cifra_cnt_cstm -- 25.07.2019 КТВ Цифровое
     , case when coalesce(ban.ban_sms, 0)   != 0 
             and coalesce(ban.ban_call, 0)  != 0 
             and coalesce(ban.ban_email, 0) != 0 
             and coalesce(ban.ban_red, 0)   != 0 
             and coalesce(ban.ban_com, 0)   != 0 
             and coalesce(ban.ban_mark, 0)  != 0
             and coalesce(ban2.message_ban,0) != 0 --   09.09.2019 Добавлен признак Message_ban    
            then 1 
            else 0 
       end as ban_com
     , 'Нет' as is_wink -- 09.09.2019 Добавлен признак Wink
     , to_date(mvno.period::varchar, 'YYYYMM') as eff_dttm
     , to_date(mvno.period::varchar, 'YYYYMM') + interval '1 month - 1 second' as exp_dttm
     , now() as load_dttm
     , 000157 as src_id
 from (select m.account
            , count(distinct m.subs_id) as srvs_mvno_cnt_cstm
            , m.period
			, case when m.rf_id in ('1316') then 1314 else m.rf_id end as rf_id 
            , case when m.rf_id in ('1151','1003') then 10 else m.mrf_id end as mrf_id
            , dir_branches_2.def_short as region
            , dir_branches_1.def as m_region
            , max(coalesce(blka.block_status_id,0)) as block_status
            , row_number() over (partition by m.account order by  min(coalesce(m.data_activ,to_date('19000101','YYYYMMDD'))) desc) as rn
            , min(coalesce(m.data_activ,to_date('19000101','YYYYMMDD'))) min_data_activ
            , max(coalesce(m.end_rtpl,to_date('29991231','YYYYMMDD'))) max_end_rtpl
        from edw_ods.t_000157_efftp_oo_eff_tp_mvno m 
        left join edw_ods.t_000158_rprt_dir_branches dir_branches_1 on case when m.rf_id in ('1151','1003') then 10 else m.mrf_id end = dir_branches_1.brnc_id
        left join edw_ods.t_000158_rprt_dir_branches dir_branches_2 on case when m.rf_id in ('1316') then 1314 else m.rf_id end = dir_branches_2.brnc_id
        left join edw_stg_dmcm.blka_cl_prf_1_prt_p000157 blka   on blka.srvs_id = m.subs_id and blka.mrf_id = m.mrf_id
                                                                   and blka.src_id  = 000157
        where m.account_ext is null 
          and m.tech_dt = to_date('20190601', 'YYYYMMDD')
        group by m.account, m.period, m.rf_id, m.mrf_id, dir_branches_2.def_short, dir_branches_1.def
      ) mvno
 left join life_time lt on mvno.account = lt.account
 left join (select distinct accn_id from edw_ods.t_000134_elk) elk on elk.accn_id = mvno.account
 left join edw_stg_dmcm.abon_attr_cl_prf_1_prt_p000157 abon_attr on abon_attr.accn_id = mvno.account
                                                                    and abon_attr.src_id  = 000157
 left join edw_stg_dmcm.ban_cl_prf_1_prt_p000157 ban on ban.accn_id = mvno.account
                                                        and ban.src_id  = 000157
  left join (select mban.account as accn_id
          , mban.message_ban as message_ban
       from (select san.account
                  , taban.message_ban
                  , san.mrf_id
            , row_number() over(partition by san.account, taban.mrf_id order by taban.iptv_exp_dttm desc, taban.account_number desc) rn
              from (select  sub.account_number
                          , max(coalesce(message_ban,0)) as message_ban
            --              , coalesce(prof.mrf_id,sub.mrf_id) as mrf_id
						  , decode(coalesce(prof.mrf_id,sub.mrf_id),1,11,4,10,5,12,9,13,7,14,8,15,6,16,3,17) as mrf_id
                          , sub.iptv_exp_dttm
                     from  edw_ods.T_000195_V_IPTV_DIM_PROFILE prof
                     left join (select dsub.dim_subscriber_id
                                     , dsub.account_number
                                     , dsub.mrf_id
                                     , dsub.iptv_exp_dttm
                                 from  edw_ods.T_000195_V_IPTV_DIM_SUBSCRIBER dsub
                                 where dsub.iptv_eff_dttm < to_date('20190601', 'YYYYMMDD')+ INTERVAL '1 MONTH - 1 SECOND'
                                   and dsub.iptv_exp_dttm >= to_date('20190601', 'YYYYMMDD')
                                   and dsub.subcriber_state_name in ('Active', 'Blocked')
                                   and dsub.subcriber_type_name  = 'Физ.лицо'
                                   and dsub.subscriber_is_test != 'Да'
                                   and dsub.account_number is not null
                               ) sub on prof.subscriber_id = sub.dim_subscriber_id 
                                    and prof.mrf_id = sub.mrf_id
                     where prof.iptv_eff_dttm < to_date('20190601', 'YYYYMMDD')+ INTERVAL '1 MONTH - 1 SECOND'
                       and prof.iptv_exp_dttm >= to_date('20190601', 'YYYYMMDD')
                     group by sub.account_number, coalesce(prof.mrf_id,sub.mrf_id), sub.iptv_exp_dttm
                   ) taban
              left join (select san
                              , account
                              , mrf_id
                              , src_id
                          from  edw_stg_dmcm.san_cl_prf_1_prt_p000157
                        ) san on taban.mrf_id = san.mrf_id
                             and taban.account_number = san.san
            ) mban
       where mban.account is not null
         and rn = 1
      ) ban2 on ban2.accn_id = mvno.account -- 09.09.2019 Добавлен признак Message_ban
 left join edw_stg_dmcm.delry_method_cl_prf_1_prt_p000157 delivery_method on delivery_method.accn_id = mvno.account
                                                                             and delivery_method.src_id  = 000157
 left join (select accn_id
                 , count(distinct cntct_fix) as cntct_fix
             from  edw_ods.t_000134_fix
             group by accn_id
           ) fix on fix.accn_id = mvno.account
 left join  (select accn_id
                  , count(distinct cntct_mob) as cntct_mob
              from  edw_ods.t_000134_mob 
              group by accn_id
            ) mob on mob.accn_id = mvno.account
 left join edw_stg_dmcm.email_cl_prf_1_prt_p000157  email on email.accn_id = mvno.account
 left join (select account
                 , 1 as bonus_on
             from (select supl_servce_info.address_bill_key as account
                        , dim_supl_customer.mis_eff_dttm
                        , dim_supl_customer.mis_exp_dttm
                    from  edw_ods.t_000133_dwh_dim_supl_customer dim_supl_customer
                    inner join edw_ods.t_000133_dwh_hfctsuplservceinf supl_servce_info on dim_supl_customer.customer_key = supl_servce_info.customer_key
                    where first_conection_date is not null 
                      and connection_status = 30
                      and dim_supl_customer.mis_eff_dttm < dim_supl_customer.mis_exp_dttm
                    group by supl_servce_info.address_bill_key
                           , dim_supl_customer.mis_eff_dttm
                           , dim_supl_customer.mis_exp_dttm
                  ) dim_supl_customer
             where to_date('20190601', 'YYYYMMDD') + interval '1 month - 1 second' between mis_eff_dttm and mis_exp_dttm
             group by account
                    , bonus_on
           ) dim_supl_customer on mvno.account = dim_supl_customer.account
 where mvno.rn = 1
 group by mvno.mrf_id
     , mvno.rf_id
     , coalesce(mvno.account,'')
     , coalesce('-'||mvno.account,'')
     , coalesce(mvno.account,'')
     , dim_supl_customer.bonus_on
     , lt.dt_start_accn
     , mvno.m_region
     , mvno.region
     , mvno.block_status
     , case when mvno.max_end_rtpl > to_date(mvno.period::varchar, 'YYYYMM') + interval '1 month - 1 second' then 'активен' 
            else 'закрыт' 
       end
     , coalesce(ban.vip_rank_name,'')
     , lt.dt_end_accn
     , lt.lt_cstm
     , coalesce(abon_attr.id, 0)
     , coalesce(abon_attr.id, 0)
     , coalesce(email.accn_id,'0')
     , coalesce(delivery_method.id,0)
     , coalesce(delivery_method.id,0)
     , mvno.srvs_mvno_cnt_cstm
     , case when coalesce(ban.ban_sms, 0)   != 0 
             and coalesce(ban.ban_call, 0)  != 0 
             and coalesce(ban.ban_email, 0) != 0 
             and coalesce(ban.ban_red, 0)   != 0 
             and coalesce(ban.ban_com, 0)   != 0 
             and coalesce(ban.ban_mark, 0)  != 0
             and coalesce(ban2.message_ban,0) != 0 --   09.09.2019 Добавлен признак Message_ban 
            then 1 
            else 0 
       end
     , to_date(mvno.period::varchar, 'YYYYMM')
     , to_date(mvno.period::varchar, 'YYYYMM') + interval '1 month - 1 second';
analyze edw_stg_dmcm.tfct_client_prof_1_prt_p000157;