/*rev.34588 31.07.2019 Changed by: NAREK.ALAVERDYAN */
		--AGG_TELEPHONY_CONSUMPTION
		truncate table edw_stg_ads.agg_telephony_consumption_1_prt_p000013 ;
		insert into edw_stg_ads.agg_telephony_consumption_1_prt_p000013
			(
				calendar_key,
				year_month_key,
				adjust_period,
				center_num_key,
				duty_num_key,
				branch_key,
				region_key,
				segment_key,
				type_of_billing_services_key,
				technology_type_key,
				network_type_key,
				service_type_key,
				service_key,
				service_rtk_detail_key,
				rc_key,
				total_call_dur_rounded,
				total_call_dur_actually,
				total_call_dur_paid,
				src_id,
				load_dttm,
				md5
			)

		Select 
			calendar_key,
			year_month_key,
			adjust_period,
			center_num_key,
			duty_num_key,
			branch_key,
			region_key,
			segment_key,
			type_of_billing_services_key,
			technology_type_key,
			network_type_key,
			service_type_key,
			service_key,
			service_rtk_detail_key,
			rc_key,
			total_call_dur_rounded,
			total_call_dur_actually,
			total_call_dur_paid,
			src_id,
			CURRENT_TIMESTAMP as load_dttm,
			MD5
				(((((((((((((((((((
					COALESCE(calendar_key::text, ''::text)) || CHR(9)) || 
					COALESCE(branch_key::text, ''::text)) || CHR(9)) || 
					COALESCE(segment_key::text, ''::text)) || CHR(9)) || 
					COALESCE(type_of_billing_services_key::text, ''::text)) || CHR(9)) || 
					COALESCE(technology_type_key::text, ''::text)) || CHR(9)) || 
					COALESCE(network_type_key::text, ''::text)) || CHR(9)) || 
					COALESCE(service_type_key::text, ''::text)) || CHR(9)) || 
					COALESCE(service_key::text, ''::text)) || CHR(9)) || 
					COALESCE(service_rtk_detail_key::text, ''::text)) || CHR(9))
				)  as md5
		from 
			(
				Select
					date_trunc('month',calendar_key) as calendar_key,
					year_month_key,
					adjust_period,
					center_num_key,
					duty_num_key,
					branch_key,
					region_key,
					segment_key,
					type_of_billing_services_key,
					technology_type_key,
					network_type_key,
					service_type_key,
					service_key,
					service_rtk_detail_key,
					rc_key,
					sum(total_call_dur_rounded) as total_call_dur_rounded,
					sum(total_call_dur_actually) as total_call_dur_actually,
					sum(total_call_dur_paid) as total_call_dur_paid,
					src_id
				from edw_stg_ads.tfct_telephony_consumption_1_prt_p000013
				where src_id=13
					and calendar_key between date_trunc('month', to_date('20190601', 'YYYYMMDD'))
						and (date_trunc('month', to_date('20190630', 'YYYYMMDD')) + interval '1 month' + interval '-1 day')
				group by 
					date_trunc('month',calendar_key),
					year_month_key,
					adjust_period,
					center_num_key,
					duty_num_key,
					branch_key,
					region_key,
					segment_key,
					type_of_billing_services_key,
					technology_type_key,
					network_type_key,
					service_type_key,
					service_key,
					service_rtk_detail_key,
					rc_key,
					src_id
			) total;
			
		ANALYZE edw_stg_ads.agg_telephony_consumption_1_prt_p000013;
	