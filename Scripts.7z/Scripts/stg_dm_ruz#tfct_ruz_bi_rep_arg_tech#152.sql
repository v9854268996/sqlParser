/*rev.22549 от 15.02.2019*/


truncate table edw_stg_dm_ruz.tfct_ruz_bi_rep_arg_tech_1_prt_p000152;
insert into edw_stg_dm_ruz.tfct_ruz_bi_rep_arg_tech_1_prt_p000152
(
	period
	, mrf_id 
	, rf_id
	, region_type
	, city_name
	, house_gid
	, ltc
	, div_name
	, ltp
	, cnt
	, macro_segment
	, client_type
	, tech_name
	, serv_type
	, open_code
	, close_code
	, cfo
	, serv_b_type
	, id_be
	, name_be
	, id_subj
	, name_subj
	, load_dttm
	, src_id
)
SELECT 
	to_timestamp(period, 'YYYYMM') 
	, mrf_id 
	, rf_id
	, region_type
	, city_name
	, house_gid
	, ltc
	, div_name
	, ltp
	, sum(cnt)
	, macro_segment
	, client_type
	, tech_name
	, serv_type
	, open_code
	, close_code
	, cfo
	, serv_b_type
	, id_be
	, name_be
	, id_subj
	, name_subj
	, now()
	, 000152
FROM edw_ods.t_000152_tfct_ruz_bi_rep_arg_tech 
where 1 = 1
	and period >= to_char(to_date('20190601', 'YYYYMMDD'), 'YYYYMM')::numeric
	and period <= to_char(to_date('20190630', 'YYYYMMDD'), 'YYYYMM')::numeric
	and tech_dt >= to_date('20190601', 'YYYYMMDD')
	and tech_dt <= to_date('20190630', 'YYYYMMDD') 
group by
	period
	, mrf_id 
	, rf_id
	, region_type
	, city_name
	, house_gid
	, ltc
	, div_name
	, ltp
	, cnt
	, macro_segment
	, client_type
	, tech_name
	, serv_type
	, open_code
	, close_code
	, cfo
	, serv_b_type
	, id_be
	, name_be
	, id_subj
	, name_subj;
	commit;
	analyse edw_stg_dm_ruz.tfct_ruz_bi_rep_arg_tech_1_prt_p000152;