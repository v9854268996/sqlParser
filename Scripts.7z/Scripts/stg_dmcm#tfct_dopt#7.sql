/*rev. 60401 от 09.06.2020*/
truncate table edw_stg_dmcm.tfct_dopt_1_prt_p000007;
commit;
set gp_recursive_cte_prototype = ON;
insert into edw_stg_dmcm.tfct_dopt_1_prt_p000007
  ( 
    mrf_id             ,
    cm_id              ,
    accn_id            ,
    status             ,
    status_change_date ,
    dt_start_srvs      ,
    dt_end_srvs        ,
    srvs_type          ,
    srvs_id            ,
    optn_mrf_full_id   ,
    mrf_service_key    ,
    optn_type          ,
    optn_name          ,
    optn_name_full     ,
    cnt_pay_days       ,
    cnt_notpay_days    ,
    add_service_key    ,
    srvs_status        ,
    load_dttm          ,
    src_id             ,
    eff_dttm           ,
    exp_dttm
  )
WITH RECURSIVE RECUR AS (   
   SELECT
     bs.business_service_key       ,
     bs.parent_business_service_key,
     bs.business_service_name      ,
     bs.business_service_key as rbk,
     1                       AS level
   FROM
     edw_dds.dim_business_service bs
   WHERE
     1                            =1
     AND bs.business_service_key != bs.parent_business_service_key
     AND business_service_key             in (10100, 10200, 10400)
     AND to_date('20190630', 'YYYYMMDD') + INTERVAL '1 day - 1 second' between bs.eff_dttm and bs.exp_dttm
   UNION ALL
   SELECT
     bs.business_service_key       ,
     bs.parent_business_service_key,
     bs.business_service_name      ,
     r.rbk       as rbk            ,
     r.level + 1 AS level
   FROM
     edw_dds.dim_business_service bs
     JOIN
       RECUR r
       ON
         bs.parent_business_service_key = r.business_service_key
   WHERE
     1=1
     AND to_date('20190630', 'YYYYMMDD') + INTERVAL '1 day - 1 second' between bs.eff_dttm and bs.exp_dttm
), 
DIM_SERVICE as(
  select
    hds.src_id||'#'||hds.source_key as source_key ,
    ds.business_service_key                       ,
    rbk                                           ,
    case
      when rbk = 10100 then 1 -- ОТА
      when rbk = 10200 then 2 -- ШПД
      when rbk = 10400 then 3 -- IP-TV
      else -1
    end                                as serv_id ,
    case
      when rbk = 10100 then 'ОТА'
      when rbk = 10200 then 'ШПД'
      when rbk = 10400 then 'IP-TV'
      else 'Не определено'
    end                              as serv_name
  from
    edw_dds.hub_dim_service hds
    left join
      edw_dds.dim_service ds
      on
        hds.service_key = ds.service_key
        and to_date('20190630', 'YYYYMMDD') + interval '1 day - 1 second' between ds.eff_dttm and ds.exp_dttm
    left join
      RECUR r
      on
        ds.business_service_key = r.business_service_key
  where
    to_date('20190630', 'YYYYMMDD') + interval '1 day - 1 second' between hds.eff_dttm and hds.exp_dttm
), 
DIM_ADD_SERVICE as(
  select
    add_service.*                                        ,
    coalesce(ds.serv_id,-1)                 as serv_id   ,
    coalesce(ds.serv_name, 'Не определено') as serv_name ,
    row_number() over (partition by add_service_key order by eff_dttm DESC) as add_rn
  from
    edw_dds.dim_add_service add_service
    left join
      DIM_SERVICE ds
      on
        add_service.src_id||'#'||add_service.mrf_service_key = ds.source_key
  where
    1=1
    and to_date('20190630', 'YYYYMMDD') + interval '1 day - 1 second' between eff_dttm and exp_dttm
    and add_service.src_id      = 000007
    and add_service.deleted_ind = 0
), 
last_lvl as (
  select
    case
      when add_service.src_id in (48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,75,76,77,102) then 11 -- ЦЕНТР
      when add_service.src_id in (97)                                                                                            then 12 -- СЗ
      when add_service.src_id in (1,2,3,4,5,6,7,8,9,10,11,12)                                                                    then 13 -- Волга
      when add_service.src_id in (26,27,28,29,30,31,32,33,34,36,37,38,39)                                                        then 14 -- ЮГ
      when add_service.src_id in (45)                                                                                            then 15 -- Урал
      when add_service.src_id in (80,81,82,83,84,85,86,87,88)                                                                    then 16 -- Сибирь
      when add_service.src_id in (107,108,109,110,111,112,113)                                                                   then 17 -- ДВ
        else -1
    end                                                                                  as MRF_ID,
    coalesce(OO_EFF_TP.hflat, '-'||OO_EFF_TP.account, '-'||add_service.account_name)     as cm_id   ,
    add_service.account_name                                                             as accn_id ,
    case
      when oo_eff_tp.SERV_ID is null 
        then add_service.serv_name
        else coalesce(dir_services.DEF, add_service.serv_name)
    end                                                                                  as srvs_type ,
    coalesce(oo_eff_tp.SERV_ID, add_service.serv_id)                                     as srvs_id   ,
    add_service.src_id||'#'||add_service.mrf_service_key                                 as OPTN_MRF_FULL_ID ,
    add_service.mrf_service_key                                                          as MRF_SERVICE_KEY  ,
    coalesce(mas.FREQUENCY_TYPE_NAME ,dim_frequency_services.frequency_services_name,'') as optn_type        ,
    dim_service.service_name                                                             as optn_name        ,
    add_service.mrf_add_service_name                                                     as optn_name_full   ,
    dim_branch.branch_name                                                               as optn_region      ,
    dim_branch_parent.branch_name                                                        as optn_mr          ,
    add_service.start_date                                                               as start_date       ,
    add_service.end_date                                                                 as end_date         ,
    case
      when coalesce(mas.dop_usluga_promo_name,0) + coalesce(mas.dop_usluga_bonus_type_name, 0) = 0
        then greatest(ceil(EXTRACT(epoch from least(date_trunc('day',add_service.end_date) + interval '1 second' ,to_date('20190630', 'YYYYMMDD')+ interval '1 day') - greatest(date_trunc('day',add_service.start_date), date_trunc('month',to_date('20190601', 'YYYYMMDD'))))/86400),0)
        else 0
    end                                                                                  as cnt_pay_days ,
    case
      when coalesce(mas.dop_usluga_promo_name,0) + coalesce(mas.dop_usluga_bonus_type_name, 0) > 0
        then greatest(ceil(EXTRACT(epoch from least(date_trunc('day',add_service.end_date)+interval '1 second' ,to_date('20190630', 'YYYYMMDD')+ interval '1 day') - greatest(date_trunc('day',add_service.start_date),date_trunc('month',to_date('20190601', 'YYYYMMDD'))))/86400),0)
        else 0
    end                                                                                  as cnt_notpay_days ,
    add_service.add_service_key::numeric                                                 as add_service_key ,
    dim_service.service_type_key                                                         as srvs_status     ,
    now()                                                                                as load_dttm       ,
    add_service.src_id                                                                   as src_id          ,
    to_date('20190601', 'YYYYMMDD')                                                  as eff_dttm        ,
    to_date('20190630', 'YYYYMMDD') + INTERVAL '1 day - 1 second'                      as exp_dttm        ,
    row_number () over (partition by add_service.add_service_key
                      order by
                        case
                          when dim_business_service.business_service_key = oo_eff_tp.business_service_key
                            then 1
                            else 0
                        end desc,
                        oo_eff_tp.rn)                                                    as bs_rn
  from
    DIM_ADD_SERVICE add_service
    left join edw_dds.dim_service dim_service
      on dim_service.service_key = add_service.service_key
        and to_date('20190630', 'YYYYMMDD') + interval '1 day - 1 second' between dim_service.eff_dttm and dim_service.exp_dttm
    left join edw_dds.dim_business_service dim_business_service
      on dim_service.business_service_key = dim_business_service.business_service_key
        and to_date('20190630', 'YYYYMMDD') + interval '1 day - 1 second' between dim_business_service.eff_dttm and dim_business_service.exp_dttm
    left join edw_dds.dim_frequency_services dim_frequency_services
      on dim_service.frequency_services_key = dim_frequency_services.frequency_services_key
        and to_date('20190630', 'YYYYMMDD') + interval '1 day - 1 second' between dim_frequency_services.eff_dttm and dim_frequency_services.exp_dttm
    left join edw_dds.dim_branch dim_branch
      on add_service.branch_key = dim_branch.branch_key
        and to_date('20190630', 'YYYYMMDD') + interval '1 day - 1 second' between dim_branch.eff_dttm and dim_branch.exp_dttm
    left join edw_dds.dim_branch dim_branch_parent
      on dim_branch.parent_branch_key = dim_branch_parent.branch_key
        and to_date('20190630', 'YYYYMMDD') + interval '1 day - 1 second' between dim_branch_parent.eff_dttm and dim_branch_parent.exp_dttm
    left join edw_stg_dmcm.dim_dop_service mas
      on mas.mrf_service_key = add_service.mrf_service_key
        and mas.src_id      = add_service.src_id
        and to_date('20190630', 'YYYYMMDD') + interval '1 day - 1 second' between mas.eff_dttm and mas.exp_dttm
    left join
      (
        select
          coalesce(nls_acc.nls, oo_eff_tp_low.account) as account ,
          oo_eff_tp_low.serv_id                                   ,
          oo_eff_tp_low.P2_MRF_ID                                 ,
          oo_eff_tp_low.hflat                                     ,
          oo_eff_tp_low.p3_rf_id                                  ,
          oo_eff_tp_low.business_service_key                      ,
          row_number() over (partition by coalesce(nls_acc.nls, oo_eff_tp_low.account) order by date_start desc) rn
        from
          (
            select
              account                                           ,
              serv_id                                           ,
              P2_MRF_ID                                         ,
              hflat                                             ,
              p3_rf_id                                          ,
              xref.business_service_key as business_service_key ,
              date_start
            from
              edw_ods.t_000153_efftp_oo_eff_tp oo_eff_tp
              join edw_dds.hub_dim_business_service xref
                on oo_eff_tp.serv_id||'#'||oo_eff_tp.tech_id = xref.source_key
                  and to_date('20190630', 'YYYYMMDD') + interval '1 day - 1 second' between xref.eff_dttm and xref.exp_dttm
                  and xref.src_id=158
            where
              oo_eff_tp.tech_dt= (select max(oo_eff_tp.tech_dt) from edw_ods.t_000153_efftp_oo_eff_tp oo_eff_tp where oo_eff_tp.tech_dt<=to_date('20190601', 'yyyymmdd'))
              and serv_id in (1,2,3)
          ) oo_eff_tp_low
          left join
            (
              select
                account   ,
                nls       ,
                rf_id     ,
                mrf_id    ,
                date_begin,
                coalesce(LEAD (DATE_BEGIN,1) over ( partition by account ORDER BY DATE_END) - interval '1 second' , date '2999-12-31') as DATE_END
              from
                edw_ods.t_000158_efftp_south_nls_accnt
              where
                account is not null
                and date_begin   <= to_date('20190630', 'yyyymmdd') + interval '1 day - 1 second'
            )
            nls_acc
            on
              nls_acc.rf_id       = oo_eff_tp_low.p3_rf_id
              and nls_acc.mrf_id  = oo_eff_tp_low.p2_mrf_id
              and nls_acc.account = oo_eff_tp_low.account
              and to_date('20190630', 'yyyymmdd') + interval '1 day - 1 second' between nls_acc.date_begin and nls_acc.date_end
      )
      oo_eff_tp
      on
        oo_eff_tp.account = add_service.account_name::text
    left join edw_ods.t_000158_rprt_dir_services dir_services
      on
        coalesce(OO_EFF_TP.serv_id,-1) = dir_services.serv_id
  where
    add_rn = 1
)

select
  last_lvl.mrf_id           as MRF_ID             ,
  last_lvl.cm_id            as CM_ID              ,
  last_lvl.accn_id          as ACCN_ID            ,
  'Подключение'             as STATUS             ,
  last_lvl.start_date       as STATUS_CHANGE_DATE ,
  last_lvl.start_date       as DT_START_SRVS      ,
  last_lvl.end_date         as DT_END_SRVS        ,
  last_lvl.srvs_type        as SRVS_TYPE          ,
  last_lvl.srvs_id          as SRVS_ID            ,
  last_lvl.optn_mrf_full_id as OPTN_MRF_FULL_ID   ,
  last_lvl.mrf_service_key  as MRF_SERVICE_KEY    ,
  last_lvl.optn_type        as OPTN_TYPE          ,
  last_lvl.optn_name        as OPTN_NAME          ,
  last_lvl.optn_name_full   as OPTN_NAME_FULL     ,
  last_lvl.cnt_pay_days     as CNT_PAY_DAYS       ,
  last_lvl.cnt_notpay_days  as CNT_NOTPAY_DAYS    ,
  last_lvl.add_service_key  as ADD_SERVICE_KEY    ,
  last_lvl.srvs_status      as SRVS_STATUS        ,
  last_lvl.load_dttm        as LOAD_DTTM          ,
  last_lvl.src_id           as SRC_ID             ,
  last_lvl.eff_dttm         as EFF_DTTM           ,
  last_lvl.exp_dttm         as EXP_DTTM
from
  last_lvl
where
  last_lvl.start_date between to_date('20190601', 'YYYYMMDD') and to_date('20190630',  'YYYYMMDD') + interval '1 day - 1 second'
  and bs_rn=1
union
select
  last_lvl.mrf_id           as MRF_ID             ,
  last_lvl.cm_id            as CM_ID              ,
  last_lvl.accn_id          as ACCN_ID            ,
  'Отключение'              as STATUS             ,
  last_lvl.end_date         as STATUS_CHANGE_DATE ,
  last_lvl.start_date       as DT_START_SRVS      ,
  last_lvl.end_date         as DT_END_SRVS        ,
  last_lvl.srvs_type        as SRVS_TYPE          ,
  last_lvl.srvs_id          as SRVS_ID            ,
  last_lvl.optn_mrf_full_id as OPTN_MRF_FULL_ID   ,
  last_lvl.mrf_service_key  as MRF_SERVICE_KEY    ,
  last_lvl.optn_type        as OPTN_TYPE          ,
  last_lvl.optn_name        as OPTN_NAME          ,
  last_lvl.optn_name_full   as OPTN_NAME_FULL     ,
  last_lvl.cnt_pay_days     as CNT_PAY_DAYS       ,
  last_lvl.cnt_notpay_days  as CNT_NOTPAY_DAYS    ,
  last_lvl.add_service_key  as ADD_SERVICE_KEY    ,
  last_lvl.srvs_status      as SRVS_STATUS        ,
  last_lvl.load_dttm        as LOAD_DTTM          ,
  last_lvl.src_id           as SRC_ID             ,
  last_lvl.eff_dttm         as EFF_DTTM           ,
  last_lvl.exp_dttm         as EXP_DTTM
from
  last_lvl
where
  last_lvl.end_date between to_date('20190601', 'YYYYMMDD') and to_date('20190630',  'YYYYMMDD') + interval '1 day - 1 second'
  and bs_rn=1
;  

analyze edw_stg_dmcm.tfct_dopt_1_prt_p000007;
