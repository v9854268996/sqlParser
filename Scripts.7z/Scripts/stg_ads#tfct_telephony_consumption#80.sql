/*rev.34588 31.07.2019 Changed by: NAREK.ALAVERDYAN */
			set optimizer = on;
			--TFCT_TELEPHONY_CONSUMPTION
			truncate table edw_stg_ads.tfct_telephony_consumption_1_prt_p000080 ;
			insert into edw_stg_ads.tfct_telephony_consumption_1_prt_p000080
			(
				calendar_key,
				year_month_key,
				adjust_period,
				subs_key,
				num_a,
				call_start_dttm,
				partner_key,
				account_key,
				period_account_name,
				center_num_key,
				duty_num_key,
				branch_key,
				region_key,
				segment_key,
				type_of_billing_services_key,
				technology_type_key,
				network_type_key,
				service_type_key,
				service_key,
				service_rtk_detail_key,
				rc_key,
				total_call_dur_rounded,
				total_call_dur_actually,
				total_call_dur_paid,
				service_user_qnt,
				src_id,
				load_dttm,
				md5
			)

		select 
			calendar_key,
			to_char(calendar_key, 'YYYYMM') as year_month_key,
			adjust_period,
			subs_key,
			num_a,
			call_start_dttm,
			partner_key,
			account_key,
			account_name							as period_account_name,
			center_num_key,
			duty_num_key,
			branch_key,
			region_key,
			segment_key,
			type_of_billing_services_key,
			technology_type_key,
			network_type_key,
			service_type_key,
			service_key,
			service_rtk_detail_key,
			rc_key,
			sum(call_dur_rounded_nval) as total_call_dur_rounded,
			sum(call_dur_actually_nval) as total_call_dur_actually,
			sum(call_dur_paid_nval) as total_call_dur_paid,
			count(num_a) as service_user_qnt,
			src_id,
			CURRENT_TIMESTAMP as load_dttm,
			MD5 
				(((((((((((((((((((((((((((((
					COALESCE(subs_key::text, ''::text)) || CHR(9)) ||
					COALESCE(num_a::text, ''::text)) || CHR(9)) ||
					COALESCE(call_start_dttm::text, ''::text)) || CHR(9)) ||
					COALESCE(partner_key::text, ''::text)) || CHR(9)) ||
					COALESCE(account_key::text, ''::text)) || CHR(9)) ||
					COALESCE(account_name::text, ''::text)) || CHR(9)) ||
					COALESCE(branch_key::text, ''::text))|| CHR(9)) ||
					COALESCE(segment_key::text, ''::text)) || CHR(9)) ||
					COALESCE(type_of_billing_services_key::text, ''::text)) || CHR(9)) ||
					COALESCE(technology_type_key::text, ''::text)) || CHR(9)) ||
					COALESCE(network_type_key::text, ''::text)) || CHR(9)) ||
					COALESCE(service_type_key::text, ''::text)) || CHR(9)) ||
					COALESCE(service_key::text, ''::text)) || CHR(9)) ||
					COALESCE(service_rtk_detail_key::text, ''::text)) || CHR(9))
				) as md5
		from 
			(
				select 
					date_trunc('day', calendar_key) as calendar_key,
					ttc.adjust_period,
					coalesce(ttc.subs_key, -1) 			as subs_key,
					ttc.num_a,
					ttc.call_start_dttm,
					coalesce(dp.partner_key, -1) 		as partner_key,
					coalesce(da.account_key, -1) 				as account_key,
					da.account_name,
					coalesce(da.center_num_key, 0)				as center_num_key,
					coalesce(da.duty_num_key, 0)				as duty_num_key,
					coalesce(da.branch_key, -1) 				as branch_key,
					/*coalesce(dr.region_key, -1)*/-1 				as region_key,
					coalesce(dp.segment_key, -1)				as segment_key,
					srv.type_of_billing_services_key,
					coalesce(srv.technology_type_key, -1)		as technology_type_key,
					coalesce(ttc.network_type_key, -1)			as network_type_key,
					coalesce(srv.service_type_key, -1)			as service_type_key,
					coalesce(srv.service_key, -1)				as service_key,
					coalesce(srv.service_rtk_detail_key, -1)	as service_rtk_detail_key,
					case 
						when ttc.rc_key <> -1 then ttc.rc_key
						when ttc.rc_key = -1 and  mrc.matrix_rc_key is not null then mrc.rc_key
						else -1
					end	as rc_key,
					ttc.call_dur_rounded_nval,
					ttc.call_dur_actually_nval,
					ttc.call_dur_paid_nval,
					ttc.src_id
				from 
					(
							SELECT
								subs_key,
								num_a,
								date_trunc('hour', call_start_dttm) as call_start_dttm,
								account_key,
								service_key,
								network_type_key,
								rc_key,
								to_char(billing_id, 'YYYYMM') AS adjust_period,
								billing_id + INTERVAL '1 MONTH' + INTERVAL '-1 sec' AS calendar_key,
								SUM(call_dur_rounded_nval/60) as call_dur_rounded_nval,
								SUM(call_dur_actually_nval/60) as call_dur_actually_nval,
								SUM(call_dur_paid_nval/60) as call_dur_paid_nval,
								src_id
							FROM
								edw_dds.tfct_telephony_consumption_1_prt_p000080
							WHERE
								call_dur_paid_nval + call_dur_actually_nval > 0
								and src_id=000080
								and billing_id between to_date('20190601', 'YYYYMMDD')
								and (to_date('20190601', 'YYYYMMDD') + interval '1 day' + interval '-1 sec')
							GROUP BY 
								subs_key,
								num_a,
								date_trunc('hour', call_start_dttm),
								account_key,
								service_key,
								network_type_key,
								rc_key,
								billing_id,
								src_id
					) ttc
						JOIN edw_dds.dim_account_1_prt_p000080 da 
							ON ttc.account_key = da.account_key 
								and ttc.calendar_key between da.eff_dttm and da.exp_dttm
								and da.deleted_ind=0 
								and da.branch_key <> -2
						JOIN edw_dds.dim_partner_1_prt_p000080 dp 
							ON  da.partner_key = dp.partner_key 
								and ttc.calendar_key between dp.eff_dttm and dp.exp_dttm
								and dp.deleted_ind=0 
								and dp.segment_key <> -2
						LEFT JOIN edw_dds.dim_service srv 
							ON srv.service_key = ttc.service_key 
								and srv.deleted_ind=0 
								and srv.exp_dttm = '2999-12-31'	
						LEFT JOIN edw_dds.dim_matrix_rc AS mrc
							ON srv.service_rtk_detail_key = mrc.service_rtk_detail_key
								AND mrc.segment_key = dp.segment_key
								AND mrc.rc_default = 1
								AND mrc.deleted_ind = 0
								AND mrc.exp_dttm = '2999-12-31'
						/*left join edw_dds.dim_region as dr
							on da.branch_key = dr.branch_key
								and dr.exp_dttm = '2999-12-31'
								and dr.deleted_ind = 0*/
				WHERE srv.service_key <> -2
			) as telcons
		group by 
			calendar_key,
			to_char(calendar_key, 'YYYYMM'),
			adjust_period,
			subs_key,
			num_a,
			call_start_dttm,
			partner_key,
			account_key,
			account_name,
			center_num_key,
			duty_num_key,
			branch_key,
			region_key,
			segment_key,
			type_of_billing_services_key,
			technology_type_key,
			network_type_key,
			service_type_key,
			service_key,
			service_rtk_detail_key,
			rc_key,
			src_id;
			
		ANALYZE edw_stg_ads.tfct_telephony_consumption_1_prt_p000080;
	