/*rev.34588 31.07.2019 Changed by: NAREK.ALAVERDYAN */
		set optimizer = on;
		truncate table edw_stg_ads.tfct_active_sub_base_1_prt_p000028 ;
		insert into edw_stg_ads.tfct_active_sub_base_1_prt_p000028
		(
			calendar_key,
			year_month_key,
			account_key,
			period_account_name,
			center_num_key,
			duty_num_key,
			segment_key,
			service_key,
			frequency_services_key,
			technology_type_key,
			service_rtk_detail_key,
			rc_key,
			branch_key,
			region_key,
			subs_key,
			connected_service_key,
			sub_cnt,
			partner_key,
			period_tax_number,
			src_id,
			is_charge_active1m,
			is_charge_active3m,
			is_charge_active6m
		)
		WITH cal AS 
		(
			SELECT DISTINCT
				month_end_date + INTERVAL '1 day' + INTERVAL '-1 sec' as month_end_date,
				to_char(month_end_date, 'YYYYMM') as year_month_key
			FROM edw_dds.dim_calendar
			WHERE 
				month_end_date BETWEEN date_trunc('month', to_date('20190601', 'YYYYMMDD'))
					AND (date_trunc('month', to_date('20190630', 'YYYYMMDD')) + INTERVAL '1 month' + INTERVAL '-1 sec')
		),
			ttc_1m as
			(
			select ttc_1m.subs_key, 
				   max(ttc_1m.charge_date) as max_charge_date
			 from cal cal1
					inner join edw_dds.tfct_total_charge_1_prt_p000028 AS ttc_1m 
						on      ttc_1m.charge_date BETWEEN cal1.month_end_date + INTERVAL '1 sec' - INTERVAL '6 MONTH' 
													   and cal1.month_end_date
							and ttc_1m.charge_rub > 0
							and ttc_1m.charge_period_start_dttm  BETWEEN to_date('20190601', 'YYYYMMDD')
							AND  to_date('20190630', 'YYYYMMDD')					
							AND ttc_1m.deleted_ind = 0
							AND ttc_1m.src_id=000028
			group by ttc_1m.subs_key 
			)
			SELECT
				date_trunc('day', cal.month_end_date) AS calendar_key,
				cal.year_month_key,
				fsb.account_key,
				fsb.period_account_name,
				fsb.center_num_key,
				fsb.duty_num_key,
				fsb.segment_key,
				fsb.service_key,
				fsb.frequency_services_key,
				fsb.technology_type_key,				
				fsb.service_rtk_detail_key,
				fsb.rc_key,
				fsb.branch_key,
				fsb.region_key,
				fsb.subs_key,
				fsb.connected_service_key,
				1 AS sub_cnt,
				fsb.partner_key,
				fsb.period_tax_number,
				fsb.src_id,
				CASE WHEN ttc_1m.max_charge_date between cal.month_end_date + INTERVAL '1 sec' - INTERVAL '1 MONTH' and cal.month_end_date
							OR subs.subs_activation_dttm between cal.month_end_date + INTERVAL '1 sec'  - INTERVAL '1 MONTH' and cal.month_end_date
							THEN 1 
							ELSE 0 
				END AS is_charge_active1m,
				CASE WHEN ttc_1m.max_charge_date between cal.month_end_date + INTERVAL '1 sec' - INTERVAL '3 MONTH' and cal.month_end_date
							OR subs.subs_activation_dttm between cal.month_end_date + INTERVAL '1 sec'  - INTERVAL '3 MONTH' and cal.month_end_date
							THEN 1 
							ELSE 0 
				END AS is_charge_active3m,
				CASE WHEN ttc_1m.max_charge_date between cal.month_end_date + INTERVAL '1 sec' - INTERVAL '6 MONTH' and cal.month_end_date
							OR subs.subs_activation_dttm between cal.month_end_date + INTERVAL '1 sec'  - INTERVAL '6 MONTH' and cal.month_end_date
							THEN 1 
							ELSE 0 
				END AS is_charge_active6m
			FROM cal 
			INNER JOIN edw_stg_ads.tfct_sub_base_1_prt_p000028 AS fsb
				ON cal.year_month_key = fsb.year_month_key 
					AND fsb.src_id=000028 
				INNER JOIN edw_dds.dim_subscribers_1_prt_p000028 AS subs 
					ON fsb.subs_key = subs.subs_key
						AND cal.month_end_date >= subs.subs_activation_dttm 
						AND cal.month_end_date < subs.subs_cancellation_dttm 
						AND cal.month_end_date between subs.eff_dttm AND subs.exp_dttm
						AND date_trunc('day',subs.subs_cancellation_dttm) - INTERVAL '3 day' > date_trunc('day',subs.subs_activation_dttm)
						and subs.deleted_ind = 0
						AND subs.src_id = 000028
				inner join edw_dds.dim_connected_service_1_prt_p000028 as con_serv
					on 	   subs.subs_key = con_serv.subs_key
						and cal.month_end_date between con_serv.eff_dttm and con_serv.exp_dttm
						and cal.month_end_date between con_serv.start_date and con_serv.end_date
						and con_serv.deleted_ind = 0
						and con_serv.src_id=000028
				LEFT JOIN ttc_1m
					on ttc_1m.subs_key = subs.subs_key
		where
			ttc_1m.max_charge_date between cal.month_end_date + INTERVAL '1 sec' - INTERVAL '6 MONTH' and cal.month_end_date
			OR subs.subs_activation_dttm between cal.month_end_date + INTERVAL '1 sec'  - INTERVAL '6 MONTH' and cal.month_end_date
		;

		ANALYZE edw_stg_ads.tfct_active_sub_base_1_prt_p000028;
	