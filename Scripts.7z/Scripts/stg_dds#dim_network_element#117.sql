/*rev7557 (19.09.17)*/
truncate edw_stg_dds.t_000117_dim_network_element ;
insert into edw_stg_dds.t_000117_dim_network_element (
	network_element_key, 
	network_parent_device_key, 
	network_element_type_key, 
	install_dt,
	network_element_name,
	equipment_status_key,
	exp_dttm,
	network_type_key,
	eff_dttm,
	deinstall_dt,
	technology_type_key,
	branch_key,
	load_dttm,
	src_id
	)
	
	select 
	network_element_key, 
	network_parent_device_key, 
	network_element_type_key, 
	case when coalesce(install_dt,'1900-01-01 00:00:00')<'1900-01-01 00:00:00'
	then '1900-01-01 00:00:00'
	when coalesce(install_dt,'1900-01-01 00:00:00')>'2999-12-31 00:00:00'
	then '2999-12-31 00:00:00'
	else coalesce(install_dt,'1900-01-01 00:00:00') end
	as install_dt,
	network_element_name,
	equipment_status_key,
	'2999-12-31 00:00:00' as exp_dttm,
	network_type_key,
	'1900-01-01 00:00:00' as eff_dttm,
	case when  coalesce(deinstall_dt,'2999-12-31 00:00:00') > '2999-12-31 00:00:00' 
	then '2999-12-31 00:00:00'
	else coalesce(deinstall_dt,'2999-12-31 00:00:00') end
	as deinstall_dt,
	technology_type_key,
	branch_key,
	now() as load_dttm,
	'117' as src_id
	
	from (

with 
  t_tehnology as ( 
  select * from (
      select tech_kod,cnt,comm_id,row_number()over(partition by comm_id order by cnt desc) rn  from (   
      select case when pc.dsl_tech_kod > 0 then pc.dsl_tech_kod else pc.tech_kod end tech_kod
          ,count(*) as cnt
          ,p.comm_id
          from edw_ods.t_000117_EDWV_eth_port_atu p
inner join edw_ods.t_000117_EDWV_eth_portcateg pc 
	on pc.portcateg_kod = p.portcateg_kod and pc.tech_kod >= 0
inner join edw_ods.t_000117_EDWV_eth_comm_atu cm 
	on cm.comm_id=p.comm_id
     where p.priznakdel     = 0
      --and p.comm_id      = 698826
       -- p.typportuse_kod = 1
  group by case when pc.dsl_tech_kod > 0 then pc.dsl_tech_kod else pc.tech_kod end
  ,p.comm_id
  
  order by cnt
  )
t )t
where rn=1 
)

select (select ent_prefix from edw_ods.t_000117_edwv_edw_sltu_prefix where ent_name='eth_comm_atu')||cm.comm_id as network_element_key    -- ok
            ,coalesce (case when cm.comm_prnt_id   > 0 then (select ent_prefix from edw_ods.t_000117_edwv_edw_sltu_prefix where ent_name='eth_comm_atu')||cm.comm_prnt_id
                  when cm.adrobject_type = 1 then (select ent_prefix from edw_ods.t_000117_edwv_edw_sltu_prefix where ent_name='ats_atu')||cm.adrobject_id
                  when cm.adrobject_type = 2 then (select ent_prefix from edw_ods.t_000117_edwv_edw_sltu_prefix where ent_name='rh_atu')||cm.adrobject_id end,'-1') as network_parent_device_key -- ok
            ,(select ent_prefix from edw_ods.t_000117_edwv_edw_sltu_prefix where ent_name='eth_comm_atu')||mr.typdevice_kod ::VARCHAR as network_element_type_key  -- ok
            --,cm.invproj_id    as project_key
            ,cm.datev         as install_dt  -- ok
            ,case when cm.comm_prnt_id = 0 and rh.rh_id > 0 then rh.numb||' ' end|| cm.numb as network_element_name 
            ,coalesce((select ent_prefix from edw_ods.t_000117_edwv_edw_sltu_prefix where ent_name='eth_sostdev_log')||cm.sostlog_kod,'-1') as equipment_status_key  -- ok
            --,sn.invn          as inventory_num
            --,vn.vendor_name   as equipment_brand
            --,cm.address_id    as address_key
            --,case when cm.comm_prnt_id > 0 then 'Компонент' else 'Элемент' end component_element_network_p
            ,case when cm.priznakdel   > 0 then cm.datemodif end as exp_dttm -- ok
            --,cm.prinadl_kod   as network_level_key
            --,cm.numbdec       as sn_num
            --,inPrefixSW||to_char(cm.markacomm_kod) as device_brand_key
            ,nt.typnet_kod    as network_type_key
            --,null             as issue_date
            --,null             as department_key
            --,null             as type_object_key
            --,null             as network_link_key
            ,'01.01.1900' ::DATE     as eff_dttm -- ok
            --,null             as division_key
            ,case when cm.sostlog_kod = 5 then cm.datemodif end as deinstall_dt --ok
            --,cm.comm_id
            --,cm.markacomm_kod
            --,cm.street_kod
            --,cm.home
            --,cm.korp
            --,td.ISACTIVE
            ,case when td.isactive>0 then coalesce(teh.tech_kod,'-1') else '-1' end as technology_type_key
            ,z.filial_kod     as branch_key
            --,z.infouzel_kod   as uzel_id
            --,z.infouzel_sname as uzel_name
        from edw_ods.t_000117_EDWV_eth_comm_atu    cm
  left join edw_ods.t_000117_EDWV_eth_net_atu     nt on nt.net_id        = cm.net_id
  left join edw_ods.t_000117_EDWV_eth_markacomm   mr on mr.markacomm_kod = cm.markacomm_kod
  left join edw_ods.t_000117_EDWV_eth_typdev_comm td on td.typdevice_kod = mr.typdevice_kod
  left join edw_ods.t_000117_EDWV_eth_vendor      vn on vn.vendor_id     = mr.vendor_id
  left join edw_ods.t_000117_EDWV_infouzel        z  on z.infouzel_kod   = cm.uzel
   left join edw_ods.t_000117_EDWV_rh_atu          rh on rh.rh_id         = cm.adrobject_id and cm.adrobject_type = 2
   left join edw_ods.t_000117_EDWV_gis_sn          sn on sn.id_obj        = cm.comm_id      and sn.id_typ         = 20
   left join edw_ods.t_000117_EDWV_store_device_param pr on pr.comm_id = cm.comm_id
   left join t_tehnology teh on teh.comm_id=  cm.comm_id
       where pr.store_device_param_id is null
         and z.INFOUZEL_TYPE_KOD <> 4
	 
        
union all

 select (select ent_prefix from edw_ods.t_000117_edwv_edw_sltu_prefix where ent_name='rh_atu')||rh.RH_ID as network_el_key
            ,coalesce (case when rh.ATS_ID_PLACE    > 0 then (select ent_prefix from edw_ods.t_000117_edwv_edw_sltu_prefix where ent_name='ats_atu')||rh.ATS_ID_PLACE
                  when rh.ATSDEV_ID_PLACE > 0 then (select ent_prefix from edw_ods.t_000117_edwv_edw_sltu_prefix where ent_name='ats_device_atu')||rh.ATSDEV_ID_PLACE
                  when rh.ATS_ID          > 0 then (select ent_prefix from edw_ods.t_000117_edwv_edw_sltu_prefix where ent_name='ats_atu')||rh.ATS_ID end,'-1') as network_parent_device_key
            ,2 ::VARCHAR as network_el_type_key
            ,rh.datev         as install_dt
			,case when rh.ATS_ID_PLACE > 0 then kr.numb||' ' end|| rh.numb as network_element_name
            ,coalesce((select ent_prefix from edw_ods.t_000117_edwv_edw_sltu_prefix where ent_name='sostinterv')||sn.SOSTINTERV_KOD,'-1') as equipment_status_key
            ,case when rh.priznakdel   > 0 then rh.datemodif end as exp_dttm
			,'-1'             as network_type_key
            ,'01.01.1900' ::DATE     as eff_dttm
            ,case when sn.SOSTINTERV_KOD = 3 then rh.datemodif end as deinstall_dt
            ,'-1' as technology_type_key 
            ,z.filial_kod     as branch_key
        from edw_ods.t_000117_EDWV_rh_atu      rh
  left join edw_ods.t_000117_EDWV_infouzel    z  on z.infouzel_kod = rh.uzel
   left join edw_ods.t_000117_Edwv_Ats_Atu     kr on kr.ats_id      = rh.ATS_ID_PLACE and rh.ATS_ID_PLACE > 0
   left join edw_ods.t_000117_EDWV_gis_sn      sn on sn.id_obj      = rh.RH_ID        and sn.id_typ       = 2
       where z.INFOUZEL_TYPE_KOD <> 4

union all
--========================================================================================================== 


--получение списка коммутационных устройств
select (select ent_prefix from edw_ods.t_000117_edwv_edw_sltu_prefix where ent_name='eth_patchp_atu')||pp.PATCHP_ID as network_el_key
            ,coalesce(case when pp.RH_ID > 0 then (select ent_prefix from edw_ods.t_000117_edwv_edw_sltu_prefix where ent_name='rh_atu')||pp.RH_ID end,'-1') as network_parent_device_key
            ,21 ::VARCHAR as network_el_type_key
            ,pp.datev         as install_dt
			,case when pp.RH_ID > 0 then rh.numb||' ' end|| pp.PATCHP_NUMB as network_element_name
            ,coalesce((select ent_prefix from edw_ods.t_000117_edwv_edw_sltu_prefix where ent_name='sostinterv')||pp.SOSTINTERV_KOD,'-1') as equipment_status_key
            ,case when pp.priznakdel   > 0 then rh.datemodif end as exp_dttm
			,'-1'             as network_type_key
            ,'01.01.1900' ::DATE    as eff_dttm
            ,case when sn.SOSTINTERV_KOD = 3 then rh.datemodif end as deinstall_dt
            ,'-1' as technology_type_key 
            ,z.filial_kod     as branch_key
        from edw_ods.t_000117_EDWV_eth_patchp_atu pp
  left join edw_ods.t_000117_EDWV_infouzel    z  on z.infouzel_kod = pp.uzel
   left join edw_ods.t_000117_Edwv_rh_Atu      rh on rh.rh_id       = pp.RH_ID        and pp.RH_ID > 0
   left join edw_ods.t_000117_EDWV_gis_sn      sn on sn.id_obj      = pp.PATCHP_ID    and sn.id_typ       = 21
       where  z.INFOUZEL_TYPE_KOD <> 4

union all        
--===============================================================================================================
 --получение списка модулей АТС
 select  (select ent_prefix from edw_ods.t_000117_edwv_edw_sltu_prefix where ent_name='ats_modul_atu')||m.ats_modul_id as network_el_key
            ,coalesce(case when m.rh_id > 0 then (select ent_prefix from edw_ods.t_000117_edwv_edw_sltu_prefix where ent_name='rh_atu')||m.rh_id
                  else (select ent_prefix from edw_ods.t_000117_edwv_edw_sltu_prefix where ent_name='ats_device_atu')||m.atsdev_id end,'-1') as network_parent_device_key
              ,22 ::VARCHAR as network_el_type_key
            ,m.datev         as install_dt
			,case when m.RH_ID > 0 then rh.numb||' ' end|| m.st_modul as network_element_name
            ,coalesce((select ent_prefix from edw_ods.t_000117_edwv_edw_sltu_prefix where ent_name='eth_sostdev_log')||m.sostint_kod,'-1') as equipment_status_key
            ,case when m.PRIZNAKDEL > 0 then m.datemodif end as exp_dttm
			,'-1'             as network_type_key
            ,'01.01.1900' ::DATE     as eff_dttm
            ,case when m.sostint_kod = 5 then m.datemodif end as deinstall_dt
             ,'-1' as technology_type_key 
            ,z.filial_kod     as branch_key
        from edw_ods.t_000117_EDWV_ats_modul_atu  m
  left join edw_ods.t_000117_edwv_ats_device_atu d on d.ATSDEV_ID  = m.atsdev_id
  left join edw_ods.t_000117_EDWV_infouzel    z  on z.infouzel_kod = d.uzel
  left join edw_ods.t_000117_edwv_eth_markacomm  mr on mr.markacomm_kod = m.marka_kod
  left join edw_ods.t_000117_edwv_eth_vendor     v on v.vendor_id       = mr.vendor_id
   left join edw_ods.t_000117_Edwv_rh_Atu      rh on rh.rh_id         = m.RH_ID        and m.RH_ID > 0
   left join edw_ods.t_000117_EDWV_gis_sn      sn on sn.id_obj        = m.ats_modul_id and sn.id_typ  = 22
       where  z.INFOUZEL_TYPE_KOD <> 4   

union all       
--===========================================================================================================
--получение списка плат АТС
select (select ent_prefix from edw_ods.t_000117_edwv_edw_sltu_prefix where ent_name='ats_plata_atu')||p.plt_id    as network_el_key
            ,coalesce ((select ent_prefix from edw_ods.t_000117_edwv_edw_sltu_prefix where ent_name='ats_modul_atu')||p.modul_id,'-1') as network_parent_device_key
            ,23 ::VARCHAR as network_el_type_key
            --,p.invproj_id     as project_key
            ,p.datev          as install_dt
            ,p.nslot          as network_element_name
            ,coalesce((select ent_prefix from edw_ods.t_000117_edwv_edw_sltu_prefix where ent_name='eth_sostdev_log')||p.sostlog_kod,'-1') as equipment_status_key
            --,sn.invn          as inventory_num
            --,mr.vendorname    as equipment_brand
            --,d.address_id     as address_key
            --,inTypePrefix     as component_element_network_p
            ,case when p.PRIZNAKDEL > 0 then p.datemodif end as exp_dttm
            --,d.prinadl_kod   as network_level_key
            --,sn.SERNUM        as sn_num
            --,inPrefixPlata||to_char(p.MARKA_KOD) as device_brand_key
            ,'-1'             as network_type_key
            --,null             as issue_date
            --,null             as department_key
            --,null             as type_object_key
            ---,null             as network_link_key
            ,'01.01.1900' ::DATE      as eff_dttm
            --,null             as division_key
            ,case when p.sostlog_kod = 5 then p.datemodif end as deinstall_dt
            --,p.plt_id         as gis_object_id
            --,d.street_kod
            --,d.home
            --,d.korp
            --,z.infouzel_kod   as uzel_id
            --,z.infouzel_sname as uzel_name
             ,'-1' as technology_type_key 
            ,z.filial_kod     as branch_key
        from edw_ods.t_000117_EDWV_ats_plata_atu  p
  left join edw_ods.t_000117_edwv_ats_modul_atu  m on m.ats_modul_id = p.modul_id
  left join edw_ods.t_000117_edwv_ats_device_atu d on d.ATSDEV_ID    = m.atsdev_id
  left join edw_ods.t_000117_EDWV_infouzel       z on z.infouzel_kod = d.uzel
  left join edw_ods.t_000117_EDWV_RHTK_MARKAPLAT     mr on mr.marka_kod   = p.marka_kod
   left join edw_ods.t_000117_EDWV_gis_sn        sn on sn.id_obj      = p.plt_id and sn.id_typ  = 23
       where 
    z.INFOUZEL_TYPE_KOD <> 4

union all
--========================================================================================================

 --получение списка стоек
select (select ent_prefix from edw_ods.t_000117_edwv_edw_sltu_prefix where ent_name='atua_stoika')||st.stoika_id as network_el_key
            ,coalesce(case when st.RH_ID > 0 then (select ent_prefix from edw_ods.t_000117_edwv_edw_sltu_prefix where ent_name='rh_atu')||st.RH_ID end,'-1') as network_parent_device_key
            --,z.filial_kod     as branch_key
            ,137 ::VARCHAR as network_el_type_key
            --,sn.INV_PROJ_ID   as project_key
            ,st.datev         as install_dt
            ,case when st.RH_ID > 0 then rh.numb||' ' end|| st.numb as network_element_name
            ,coalesce((select ent_prefix from edw_ods.t_000117_edwv_edw_sltu_prefix where ent_name='sostinterv')||sn.SOSTINTERV_KOD,'-1') as equipment_status_key
            --,null             as inventory_num
            --,null             as equipment_brand
            --,rh.ADDRESS_ID    as address_key
            --,inTypePrefix     as component_element_network_p
            ,case when st.priznakdel > 0 then st.datemodif end as exp_dttm
            --,rh.prinadl_kod   as network_level_key
            --,null             as sn_num
            --,inPrefixST||to_char(st.typstoika_kod) as device_brand_key
            ,'-1'            as network_type_key
            --,null             as issue_date
            --,null             as department_key
            --,null             as type_object_key
            --,null             as network_link_key
            ,'01.01.1900' ::DATE     as eff_dttm
            --,null             as division_key
            ,case when sn.SOSTINTERV_KOD = 3 then rh.datemodif end as deinstall_dt
            --,st.stoika_id     as gis_object_id
            --,rh.street_kod
            --,rh.home
            --,rh.korp
            --,z.infouzel_kod   as uzel_id
            --,z.infouzel_sname as uzel_name
            ,'-1' as technology_type_key 
            ,z.filial_kod     as branch_key
        from edw_ods.t_000117_EDWV_atua_stoika st
  left join edw_ods.t_000117_EDWV_infouzel    z  on z.infouzel_kod = st.uzel
  left join edw_ods.t_000117_Edwv_rh_Atu      rh on rh.rh_id       = st.RH_ID
   left join edw_ods.t_000117_EDWV_gis_sn      sn on sn.id_obj      = st.rh_id and sn.id_typ = 2
       where  z.INFOUZEL_TYPE_KOD <> 4
 
 
 
 
 
 union all      
--================================================================================================
--получение списка кроссов

select (select ent_prefix from edw_ods.t_000117_edwv_edw_sltu_prefix where ent_name='ats_atu')||kr.ats_ID as network_el_key
            ,'-1' as network_parent_device_key
            ,1                 ::VARCHAR as network_el_type_key
            --,kr.inv_proj_id    as project_key
            ,kr.datev          as install_dt
            ,kr.numb           as network_element_name
            ,coalesce((select ent_prefix from edw_ods.t_000117_edwv_edw_sltu_prefix where ent_name='sostinterv')||sn.SOSTINTERV_KOD,'-1') as equipment_status_key
            --,sn.invn           as inventory_num
            --,null              as equipment_brand
            --,kr.address_id     as address_key
            --,inTypePrefix      as component_element_network_p
            ,case when kr.priznakdel   > 0 then kr.datemodif end as exp_dttm
            --,kr.prinadl_kod    as network_level_key
            --,sn.SERNUM         as sn_num
            --,null              as device_brand_key
            ,'-1'              as network_type_key
            --,null              as issue_date
            --,null              as department_key
            --,kr.cbr_no_service as type_object_key
            --,null              as network_link_key
            ,'01.01.1900' ::DATE      as eff_dttm
            --,null              as division_key
            ,case when sn.SOSTINTERV_KOD = 3 then kr.datemodif end as deinstall_dt
            --,kr.ats_id        as gis_object_id
            --,kr.street_kod
            --,kr.home
            --,kr.korp
            --,z.infouzel_kod   as uzel_id
            --,z.infouzel_sname as uzel_name
              ,'-1' as technology_type_key 
              ,z.filial_kod     as branch_key
        from edw_ods.t_000117_EDWV_ats_atu     kr
  left join edw_ods.t_000117_EDWV_infouzel    z  on z.infouzel_kod = kr.uzel
   left join edw_ods.t_000117_EDWV_gis_sn      sn on sn.id_obj      = kr.ats_id and sn.id_typ       = 1
       where  z.INFOUZEL_TYPE_KOD <> 4

union all       
--================================================================================================
--получение списка АТС
select (select ent_prefix from edw_ods.t_000117_edwv_edw_sltu_prefix where ent_name='ats_device_atu')||d.ATSDEV_ID as network_el_key
            ,'-1' as network_parent_device_key
            --,z.filial_kod      as branch_key
            ,50                ::VARCHAR as network_el_type_key
            --,d.inv_proj_id     as project_key
            ,d.datev           as install_dt
            ,d.numb            as network_element_name
            ,coalesce((select ent_prefix from edw_ods.t_000117_edwv_edw_sltu_prefix where ent_name='sostinterv')||sn.SOSTINTERV_KOD,'-1') as equipment_status_key
            --,sn.invn           as inventory_num
            --,null              as equipment_brand
            --,d.address_id     as address_key
            --,inTypePrefix      as component_element_network_p
            ,case when d.priznakdel   > 0 then d.datemodif end as exp_dttm
            --,d.prinadl_kod    as network_level_key
            --,sn.SERNUM         as sn_num
            --,inPrefixAts||to_char(d.MARKA_KOD) as device_brand_key
            ,'-1'              as network_type_key
            --,null              as issue_date
            --,null              as department_key
            --,d.CBR_NO_SERVICE  as type_object_key
            --,null              as network_link_key
            ,'01.01.1900' ::DATE      as eff_dttm
            --,null              as division_key
            ,case when sn.SOSTINTERV_KOD = 3 then d.datemodif end as deinstall_dt
            --,d.ATSDEV_ID       as gis_object_id
            --,d.street_kod
            --,d.home
            --,d.korp
            --,z.infouzel_kod   as uzel_id
            --,z.infouzel_sname as uzel_name
            ,'-1' as technology_type_key 
              ,z.filial_kod     as branch_key
        from edw_ods.t_000117_Edwv_Ats_Device_Atu d
  left join edw_ods.t_000117_EDWV_infouzel       z  on z.infouzel_kod = d.uzel
   left join edw_ods.t_000117_EDWV_gis_sn         sn on sn.id_obj      = d.ATSDEV_ID and sn.id_typ       = 50
       where  z.INFOUZEL_TYPE_KOD <> 4
 
 union all      
--================================================================================================
--получение списка магистральных боксов
select (select ent_prefix from edw_ods.t_000117_edwv_edw_sltu_prefix where ent_name='bboxm_atu')||bx.bbox_id  as network_el_key
            ,coalesce((select ent_prefix from edw_ods.t_000117_edwv_edw_sltu_prefix where ent_name='rh_atu')||bx.rh_id,'-1')  as network_parent_device_key
            ,101              ::VARCHAR as network_el_type_key
            --,sn.INV_PROJ_ID   as project_key
            ,bx.datev         as install_dt
            ,bx.bboxname      as network_element_name
            ,coalesce((select ent_prefix from edw_ods.t_000117_edwv_edw_sltu_prefix where ent_name='sostinterv')||bx.sostint_kod,'-1') as equipment_status_key
            --,sn.invn          as inventory_num
            --,null             as equipment_brand
            --,rh.address_id    as address_key
            --,inTypePrefix     as component_element_network_p
            ,case when bx.prdel > 0 then bx.datemodif end as exp_dttm
            --,bx.prinadl_kod   as network_level_key
            --,sn.SERNUM        as sn_num
            --,null             as device_brand_key
            ,'-1'            as network_type_key
            --,null             as issue_date
            --,null             as department_key
            --,null             as type_object_key
            --,null             as network_link_key
            ,'01.01.1900' ::DATE     as eff_dttm
            --,null             as division_key
            ,case when bx.sostint_kod = 3 then bx.datemodif end as deinstall_dt
            --,bx.bbox_id       as gis_object_id
            --,rh.street_kod
            --,rh.home
            --,rh.korp
            --,z.infouzel_kod   as uzel_id
            --,z.infouzel_sname as uzel_name
            ,'-1' as technology_type_key 
            ,z.filial_kod     as branch_key
        from edw_ods.t_000117_edwv_bboxm_atu   bx
  left join edw_ods.t_000117_EDWV_rh_atu      rh on rh.rh_id       = bx.rh_id
  left join edw_ods.t_000117_EDWV_infouzel    z  on z.infouzel_kod = rh.uzel
   left join edw_ods.t_000117_EDWV_gis_sn      sn on sn.id_obj      = bx.bbox_id and sn.id_typ   = 101
      where  z.INFOUZEL_TYPE_KOD <> 4

union all      
--================================================================================================
--получение списка магистральных боксов
select network_el_key, 
	network_parent_device_key, 
    network_el_type_key, 
    install_dt,
	network_element_name,
	equipment_status_key,
	 exp_dttm,
	network_type_key::NUMERIC,
	 eff_dttm,
     deinstall_dt,
	 technology_type_key::NUMERIC,
	 branch_key from (
select *, row_number() over (partition by network_el_key) as rn from (
  select (select ent_prefix from edw_ods.t_000117_edwv_edw_sltu_prefix where ent_name='bboxp_atu')||bx.bbox_id  as network_el_key
            ,coalesce((select ent_prefix from edw_ods.t_000117_edwv_edw_sltu_prefix where ent_name='rh_atu')||bx.rh_id,'-1')  as network_parent_device_key
            ,102              ::VARCHAR as network_el_type_key
            --,sn.INV_PROJ_ID   as project_key
            ,bx.datev         as install_dt
            ,bx.bboxname      as network_element_name
            ,coalesce((select ent_prefix from edw_ods.t_000117_edwv_edw_sltu_prefix where ent_name='sostinterv')||bx.sostint_kod,'-1') as equipment_status_key
            --,sn.invn          as inventory_num
            --,null             as equipment_brand
            --,rh.address_id    as address_key
            --,inTypePrefix     as component_element_network_p
            ,case when bx.prdel > 0 then bx.datemodif end as exp_dttm
            --,bx.prinadl_kod   as network_level_key
            --,sn.SERNUM        as sn_num
            --,null             as device_brand_key
            ,'-1'             as network_type_key
            --,null             as issue_date
            --,null             as department_key
            --,null             as type_object_key
            --,null             as network_link_key
            ,'01.01.1900' ::DATE      as eff_dttm
            --,null             as division_key
            ,case when bx.sostint_kod = 3 then bx.datemodif end as deinstall_dt
            --,bx.bbox_id       as gis_object_id
            --,rh.street_kod
            --,rh.home
            --,rh.korp
            --,bx.bboxname2                       as network_el_name2
            --,'bboxp_atu#'||to_char(bx.bbox_id2) as network_el_key2
            --,'rh_atu#'||to_char(bx.rh_id2)     as network_parent_device_key2
            --,z.infouzel_kod   as uzel_id
            --,z.infouzel_sname as uzel_name
            ,'-1' as technology_type_key 
            ,z.filial_kod     as branch_key
        from edw_ods.t_000117_edwv_bboxp_atu   bx
  left join edw_ods.t_000117_EDWV_rh_atu      rh on rh.rh_id       = bx.rh_id
  left join edw_ods.t_000117_EDWV_infouzel    z  on z.infouzel_kod = rh.uzel
   left join edw_ods.t_000117_EDWV_gis_sn      sn on sn.id_obj      = bx.bbox_id and sn.id_typ = 102
      where z.INFOUZEL_TYPE_KOD <> 4
  
	  
	  
	  
	  
union all
 select (select ent_prefix from edw_ods.t_000117_edwv_edw_sltu_prefix where ent_name='bboxp_atu')||bx.bbox_id2  as network_el_key
            ,coalesce((select ent_prefix from edw_ods.t_000117_edwv_edw_sltu_prefix where ent_name='rh_atu')||bx.rh_id2,'-1')  as network_parent_device_key
            ,102              ::VARCHAR as network_el_type_key
            --,sn.INV_PROJ_ID   as project_key
            ,bx.datev         as install_dt
            ,bx.bboxname      as network_element_name
            ,coalesce((select ent_prefix from edw_ods.t_000117_edwv_edw_sltu_prefix where ent_name='sostinterv')||bx.sostint_kod,'-1') as equipment_status_key
            --,sn.invn          as inventory_num
            --,null             as equipment_brand
            --,rh.address_id    as address_key
            --,inTypePrefix     as component_element_network_p
            ,case when bx.prdel > 0 then bx.datemodif end as exp_dttm
            --,bx.prinadl_kod   as network_level_key
            --,sn.SERNUM        as sn_num
            --,null             as device_brand_key
            ,'-1'             as network_type_key
            --,null             as issue_date
            --,null             as department_key
            --,null             as type_object_key
            --,null             as network_link_key
            ,'01.01.1900' ::DATE      as eff_dttm
            --,null             as division_key
            ,case when bx.sostint_kod = 3 then bx.datemodif end as deinstall_dt
            --,bx.bbox_id       as gis_object_id
            --,rh.street_kod
            --,rh.home
            --,rh.korp
            --,bx.bboxname2                       as network_el_name2
            --,'bboxp_atu#'||to_char(bx.bbox_id2) as network_el_key2
            --,'rh_atu#'||to_char(bx.rh_id2)     as network_parent_device_key2
            --,z.infouzel_kod   as uzel_id
            --,z.infouzel_sname as uzel_name
            ,'-1' as technology_type_key 
            ,z.filial_kod     as branch_key
        from edw_ods.t_000117_edwv_bboxp_atu   bx
  left join edw_ods.t_000117_EDWV_rh_atu      rh on rh.rh_id       = bx.rh_id
  left join edw_ods.t_000117_EDWV_infouzel    z  on z.infouzel_kod = rh.uzel
   left join edw_ods.t_000117_EDWV_gis_sn      sn on sn.id_obj      = bx.bbox_id and sn.id_typ = 102
      where z.INFOUZEL_TYPE_KOD <> 4
)t
)t
where rn=1

union all     
--================================================================================================

--получение списка распределительных боксов
select (select ent_prefix from edw_ods.t_000117_edwv_edw_sltu_prefix where ent_name='bboxr_atu')||bx.bbox_id  as network_el_key
            ,coalesce((select ent_prefix from edw_ods.t_000117_edwv_edw_sltu_prefix where ent_name='rh_atu')||bx.rh_id,'-1')  as network_parent_device_key
            --,z.filial_kod     as branch_key
            ,103              ::VARCHAR as network_el_type_key
            --,sn.INV_PROJ_ID   as project_key
            ,bx.datev         as install_dt
            ,bx.bboxname      as network_element_name
            ,coalesce((select ent_prefix from edw_ods.t_000117_edwv_edw_sltu_prefix where ent_name='sostinterv')||bx.sostint_kod,'-1') as equipment_status_key
            --,sn.invn          as inventory_num
            --,null             as equipment_brand
            --,rh.address_id    as address_key
            --,inTypePrefix     as component_element_network_p
            ,case when bx.prdel > 0 then bx.datemodif end as exp_dttm
            --,bx.prinadl_kod   as network_level_key
            --,sn.SERNUM        as sn_num
            --,null             as device_brand_key
            ,'-1'             as network_type_key
            --,null             as issue_date
            --,null             as department_key
            --,null             as type_object_key
            --,null             as network_link_key
            ,'01.01.1900' ::DATE     as eff_dttm
            --,null             as division_key
            ,case when bx.sostint_kod = 3 then bx.datemodif end as deinstall_dt
            --,bx.bbox_id       as gis_object_id
            --,rh.street_kod
            --,rh.home
            --,rh.korp
            --,z.infouzel_kod   as uzel_id
            --,z.infouzel_sname as uzel_name
            ,'-1' as technology_type_key 
            ,z.filial_kod     as branch_key
        from edw_ods.t_000117_edwv_bboxr_atu   bx
  left join edw_ods.t_000117_EDWV_rh_atu      rh on rh.rh_id       = bx.rh_id
  left join edw_ods.t_000117_EDWV_infouzel    z  on z.infouzel_kod = rh.uzel
   left join edw_ods.t_000117_EDWV_gis_sn      sn on sn.id_obj      = bx.bbox_id and sn.id_typ = 103
      where z.INFOUZEL_TYPE_KOD <> 4
  
 union all    
--==================================================================================== 
--получение списка боксов спец. оборудования
select network_el_key, 
	network_parent_device_key, 
    network_el_type_key, 
    install_dt,
	network_element_name,
	equipment_status_key,
	 exp_dttm,
	network_type_key::NUMERIC,
	 eff_dttm,
     deinstall_dt,
	 technology_type_key::NUMERIC,
	 branch_key
	from (
select *,row_number() over (partition by network_el_key)as rn from (
select (select ent_prefix from edw_ods.t_000117_edwv_edw_sltu_prefix where ent_name='bboxso_atu')||bx.bbox_id  as network_el_key
            ,coalesce((select ent_prefix from edw_ods.t_000117_edwv_edw_sltu_prefix where ent_name='rh_atu')||bx.rh_id,'-1')  as network_parent_device_key
            ,118              ::VARCHAR as network_el_type_key
            --,sn.INV_PROJ_ID   as project_key
            ,bx.datev         as install_dt
            ,bx.bboxname      as network_element_name
            ,coalesce((select ent_prefix from edw_ods.t_000117_edwv_edw_sltu_prefix where ent_name='sostinterv')||bx.sostint_kod,'-1') as equipment_status_key
            --,sn.invn          as inventory_num
            --,null             as equipment_brand
            --,rh.address_id    as address_key
            --,inTypePrefix     as component_element_network_p
            ,case when bx.priznakdel > 0 then bx.datemodif end as exp_dttm
            --,bx.prinadl_kod   as network_level_key
            --,sn.SERNUM        as sn_num
            --,null             as device_brand_key
            ,'-1'             as network_type_key
            --,null             as issue_date
            --,null             as department_key
            --,null             as type_object_key
            --,null             as network_link_key
            ,'01.01.1900' ::DATE    as eff_dttm
            --,null             as division_key
            ,case when bx.sostint_kod = 3 then bx.datemodif end as deinstall_dt
            --,bx.bbox_id       as gis_object_id
            --,rh.street_kod
            --,rh.home
            --,rh.korp
            --,z.infouzel_kod   as uzel_id
            --,z.infouzel_sname as uzel_name
            ,'-1' as technology_type_key 
            ,z.filial_kod     as branch_key
        from edw_ods.t_000117_edwv_bboxso_atu   bx
  join edw_ods.t_000117_EDWV_rh_atu      rh on rh.rh_id       = bx.rh_id
  join edw_ods.t_000117_EDWV_infouzel    z  on z.infouzel_kod = rh.uzel
   left join edw_ods.t_000117_EDWV_gis_sn      sn on sn.id_obj      = bx.bbox_id and sn.id_typ = 118
      where bx.kross_id   > 0 and z.INFOUZEL_TYPE_KOD <> 4
	
	  union all
  select (select ent_prefix from edw_ods.t_000117_edwv_edw_sltu_prefix where ent_name='bboxso_atu')||bx.bbox_id  as network_el_key
            ,coalesce((select ent_prefix from edw_ods.t_000117_edwv_edw_sltu_prefix where ent_name='ats_atu')||bx.kross_id,'-1')  as network_parent_device_key
            ,118              ::VARCHAR as network_el_type_key
            --,sn.INV_PROJ_ID   as project_key
            ,bx.datev         as install_dt
            ,bx.bboxname      as network_element_name
            ,coalesce((select ent_prefix from edw_ods.t_000117_edwv_edw_sltu_prefix where ent_name='sostinterv')||bx.sostint_kod,'-1') as equipment_status_key
            --,sn.invn          as inventory_num
            --,null             as equipment_brand
            --,kr.address_id    as address_key
            --,inTypePrefix     as component_element_network_p
            ,case when bx.priznakdel > 0 then bx.datemodif end as exp_dttm
            --,bx.prinadl_kod   as network_level_key
            --,sn.SERNUM        as sn_num
            --,null             as device_brand_key
            ,'-1'             as network_type_key
            --,null             as issue_date
            --,null             as department_key
            --,null             as type_object_key
            --,null             as network_link_key
            ,'01.01.1900' ::DATE     as eff_dttm
            --,null             as division_key
            ,case when bx.sostint_kod = 3 then bx.datemodif end as deinstall_dt
            --,bx.bbox_id       as gis_object_id
            --,kr.street_kod
            --,kr.home
            --,kr.korp
            --,z.infouzel_kod   as uzel_id
            --,z.infouzel_sname as uzel_name
            ,'-1' as technology_type_key 
            ,z.filial_kod     as branch_key
        from edw_ods.t_000117_edwv_bboxso_atu  bx
  join edw_ods.t_000117_EDWV_ats_atu     kr on kr.ats_id      = bx.kross_id
join edw_ods.t_000117_EDWV_infouzel    z  on z.infouzel_kod = kr.uzel
   left join edw_ods.t_000117_EDWV_gis_sn      sn on sn.id_obj      = bx.bbox_id and sn.id_typ = 118
      where bx.kross_id   > 0
        and z.INFOUZEL_TYPE_KOD <> 4
)t
)t
where rn=1

union all
--==================================================================================================





--получение списка параллельных магистральных боксов
select (select ent_prefix from edw_ods.t_000117_edwv_edw_sltu_prefix where ent_name='bboxmp_atu')||bx.bbox_id  as network_el_key
            ,coalesce((select ent_prefix from edw_ods.t_000117_edwv_edw_sltu_prefix where ent_name='rh_atu')||bx.rh_id,'-1')  as network_parent_device_key
            ,111              ::VARCHAR as network_el_type_key
            --,sn.INV_PROJ_ID   as project_key
            ,bx.datev         as install_dt
            ,bx.bboxname      as network_element_name
            ,coalesce((select ent_prefix from edw_ods.t_000117_edwv_edw_sltu_prefix where ent_name='sostinterv')||bx.sostint_kod,'-1') as equipment_status_key
            --,sn.invn          as inventory_num
            --,null             as equipment_brand
            --,rh.address_id    as address_key
            --,inTypePrefix     as component_element_network_p
            ,case when bx.prdel > 0 then bx.datemodif end as exp_dttm
            --,bx.prinadl_kod   as network_level_key
            --,sn.SERNUM        as sn_num
            --,null             as device_brand_key
            ,'-1'             as network_type_key
            --,null             as issue_date
            --,null             as department_key
            --,null             as type_object_key
            --,null             as network_link_key
            ,'01.01.1900' ::DATE     as eff_dttm
            --,null             as division_key
            ,case when bx.sostint_kod = 3 then bx.datemodif end as deinstall_dt
            --,bx.bbox_id       as gis_object_id
            --,rh.street_kod
            --,rh.home
            --,rh.korp
            --,z.infouzel_kod   as uzel_id
            --,z.infouzel_sname as uzel_name
             ,'-1' as technology_type_key 
            ,z.filial_kod     as branch_key
        from (select * from (
select *,row_number () over (partition by bbox_id order by datev) as rn from edw_ods.t_000117_edwv_bboxmp_atu 
)t
where rn=1 )  bx
  left join edw_ods.t_000117_EDWV_rh_atu      rh on rh.rh_id       = bx.rh_id
  left join edw_ods.t_000117_EDWV_infouzel    z  on z.infouzel_kod = rh.uzel
   left join edw_ods.t_000117_EDWV_gis_sn      sn on sn.id_obj      = bx.bbox_id and sn.id_typ   = 111
      where z.INFOUZEL_TYPE_KOD <> 4




union all
--==================================================================================================
--получение списка ЗПП

select (select ent_prefix from edw_ods.t_000117_edwv_edw_sltu_prefix where ent_name='zp_atu')||zp.zp_id  as network_el_key
            ,coalesce((select ent_prefix from edw_ods.t_000117_edwv_edw_sltu_prefix where ent_name='ats_atu')||zp.ats_id,'-1')  as network_parent_device_key
            ,104              ::VARCHAR as network_el_type_key
            --,sn.INV_PROJ_ID   as project_key
            ,zp.datev         as install_dt
            ,zp.nzp           as network_element_name
            ,coalesce((select ent_prefix from edw_ods.t_000117_edwv_edw_sltu_prefix where ent_name='sostinterv')||zp.sostint_kod,'-1') as equipment_status_key
            --,sn.invn          as inventory_num
            --,null             as equipment_brand
            --,kr.address_id    as address_key
            --,inTypePrefix     as component_element_network_p
            ,case when zp.prdel > 0 then zp.datemodif end as exp_dttm
            --,zp.prinadl_kod   as network_level_key
            --,sn.SERNUM        as sn_num
            --,null             as device_brand_key
            ,'-1'            as network_type_key
            --,null             as issue_date
            --,null             as department_key
            --,null             as type_object_key
            --,null             as network_link_key
            ,'01.01.1900' ::DATE    as eff_dttm
            --,null             as division_key
            ,case when zp.sostint_kod = 3 then zp.datemodif end as deinstall_dt
            --,zp.zp_id       as gis_object_id
            --,kr.street_kod
            --,kr.home
            --,kr.korp
            --,z.infouzel_kod   as uzel_id
            --,z.infouzel_sname as uzel_name
             ,'-1' as technology_type_key 
            ,z.filial_kod     as branch_key
        from edw_ods.t_000117_edwv_zp_atu      zp
  left join edw_ods.t_000117_EDWV_ats_atu     kr on kr.ats_id      = zp.ats_id
  left join edw_ods.t_000117_EDWV_infouzel    z  on z.infouzel_kod = kr.uzel
   left join edw_ods.t_000117_EDWV_gis_sn      sn on sn.id_obj      = zp.zp_id and sn.id_typ   = 104
      where z.INFOUZEL_TYPE_KOD <> 4


union all      
--==================================================================================================
--получение списка ЗПП

select network_el_key, 
	network_parent_device_key, 
    network_el_type_key, 
    install_dt,
	network_element_name,
	equipment_status_key,
	 exp_dttm,
	network_type_key::NUMERIC,
	 eff_dttm,
     deinstall_dt,
	 technology_type_key::NUMERIC,
	 branch_key
	from (
select *,row_number() over (partition by  network_el_key ) as rn from (
 select (select ent_prefix from edw_ods.t_000117_edwv_edw_sltu_prefix where ent_name='zpsl_atu')||zp.zp_id  as network_el_key
            ,coalesce((select ent_prefix from edw_ods.t_000117_edwv_edw_sltu_prefix where ent_name='ats_atu')||zp.ats_id,'-1')  as network_parent_device_key
            ,105             ::VARCHAR as network_el_type_key
            --,sn.INV_PROJ_ID   as project_key
            ,zp.datev         as install_dt
            ,zp.nzp           as network_element_name
            ,coalesce((select ent_prefix from edw_ods.t_000117_edwv_edw_sltu_prefix where ent_name='sostinterv')||zp.sostint_kod,'-1') as equipment_status_key
            --,sn.invn          as inventory_num
            --,null             as equipment_brand
            --,kr.address_id    as address_key
            --,inTypePrefix     as component_element_network_p
            ,case when zp.prdel > 0 then zp.datemodif end as exp_dttm
            --,zp.prinadl_kod   as network_level_key
            --,sn.SERNUM        as sn_num
            --,null             as device_brand_key
            ,'-1'             as network_type_key
            --,null             as issue_date
            --,null             as department_key
            --,null             as type_object_key
            --,null             as network_link_key
            ,'01.01.1900' ::DATE      as eff_dttm
            --,null             as division_key
            ,case when zp.sostint_kod = 3 then zp.datemodif end as deinstall_dt
            --,zp.zp_id       as gis_object_id
            --,kr.street_kod
            --,kr.home
            --,kr.korp
            --,zp.nzp2                            as network_el_name2
            --,inPrefixZp||to_char(zp.zp_id2)     as network_el_key2
            --,inPrefixKross||to_char(zp.ats_id2) as network_parent_device_key2
            --,z.infouzel_kod   as uzel_id
            --,z.infouzel_sname as uzel_name
               ,'-1' as technology_type_key 
            ,z.filial_kod     as branch_key
        from edw_ods.t_000117_edwv_zpsl_atu    zp
  left join edw_ods.t_000117_EDWV_ats_atu     kr on kr.ats_id      = zp.ats_id
  left join edw_ods.t_000117_EDWV_infouzel    z  on z.infouzel_kod = kr.uzel
   left join edw_ods.t_000117_EDWV_gis_sn      sn on sn.id_obj      = zp.zp_id and sn.id_typ   = 105
      where z.INFOUZEL_TYPE_KOD <> 4
      
	  
	  
	  
union all

 select (select ent_prefix from edw_ods.t_000117_edwv_edw_sltu_prefix where ent_name='zpsl_atu')||zp.zp_id2  as network_el_key
            ,coalesce((select ent_prefix from edw_ods.t_000117_edwv_edw_sltu_prefix where ent_name='ats_atu')||zp.ats_id2,'-1')  as network_parent_device_key
            ,105             ::VARCHAR as network_el_type_key
            --,sn.INV_PROJ_ID   as project_key
            ,zp.datev         as install_dt
            ,zp.nzp2           as network_el_name
            ,coalesce((select ent_prefix from edw_ods.t_000117_edwv_edw_sltu_prefix where ent_name='sostinterv')||zp.sostint_kod,'-1') as equipment_status_key
            --,sn.invn          as inventory_num
            --,null             as equipment_brand
            --,kr.address_id    as address_key
            --,inTypePrefix     as component_element_network_p
            ,case when zp.prdel > 0 then zp.datemodif end as exp_dttm
            --,zp.prinadl_kod   as network_level_key
            --,sn.SERNUM        as sn_num
            --,null             as device_brand_key
            ,'-1'             as network_type_key
            --,null             as issue_date
            --,null             as department_key
            --,null             as type_object_key
            --,null             as network_link_key
            ,'01.01.1900' ::DATE      as eff_dttm
            --,null             as division_key
            ,case when zp.sostint_kod = 3 then zp.datemodif end as deinstall_dt
            --,zp.zp_id       as gis_object_id
            --,kr.street_kod
            --,kr.home
            --,kr.korp
            --,zp.nzp2                            as network_el_name2
            --,inPrefixZp||to_char(zp.zp_id2)     as network_el_key2
            --,inPrefixKross||to_char(zp.ats_id2) as network_parent_device_key2
            --,z.infouzel_kod   as uzel_id
            --,z.infouzel_sname as uzel_name
               ,'-1' as technology_type_key 
            ,z.filial_kod     as branch_key
        from edw_ods.t_000117_edwv_zpsl_atu    zp
  left join edw_ods.t_000117_EDWV_ats_atu     kr on kr.ats_id      = zp.ats_id
  left join edw_ods.t_000117_EDWV_infouzel    z  on z.infouzel_kod = kr.uzel
   left join edw_ods.t_000117_EDWV_gis_sn      sn on sn.id_obj      = zp.zp_id and sn.id_typ   = 105
      where z.INFOUZEL_TYPE_KOD <> 4
) t

)t
where rn=1


 union all     
 --==================================================================================================
 --получение списка ЗПП
 select (select ent_prefix from edw_ods.t_000117_edwv_edw_sltu_prefix where ent_name='zpramki_atu')||zp.zp_id  as network_el_key
            ,coalesce((select ent_prefix from edw_ods.t_000117_edwv_edw_sltu_prefix where ent_name='ats_atu')||zp.ats_id,'-1')  as network_parent_device_key
            ,116              ::VARCHAR as network_el_type_key
            --,sn.INV_PROJ_ID   as project_key
            ,zp.datev         as install_dt
            ,zp.nzp           as network_el_name
            ,coalesce((select ent_prefix from edw_ods.t_000117_edwv_edw_sltu_prefix where ent_name='sostinterv')||zp.sostint_kod,'-1') as equipment_status_key
            --,sn.invn          as inventory_num
            --,null             as equipment_brand
            --,kr.address_id    as address_key
            --,inTypePrefix     as component_element_network_p
            ,case when zp.priznakdel > 0 then zp.datemodif end as exp_dttm
            --,zp.prinadl_kod   as network_level_key
            --,sn.SERNUM        as sn_num
            --,null             as device_brand_key
            ,'-1'             as network_type_key
            --,null             as issue_date
            --,null             as department_key
            --,null             as type_object_key
            --,null             as network_link_key
            ,'01.01.1900' ::DATE    as eff_dttm
            --,null             as division_key
            ,case when zp.sostint_kod = 3 then zp.datemodif end as deinstall_dt
            --,zp.zp_id       as gis_object_id
            --,kr.street_kod
            --,kr.home
            --,kr.korp
            --,z.infouzel_kod   as uzel_id
            --,z.infouzel_sname as uzel_name
             ,'-1' as technology_type_key 
            ,z.filial_kod     as branch_key
        from edw_ods.t_000117_edwv_zpramki_atu zp
  left join edw_ods.t_000117_EDWV_ats_atu     kr on kr.ats_id      = zp.ats_id
  left join edw_ods.t_000117_EDWV_infouzel    z  on z.infouzel_kod = kr.uzel
   left join edw_ods.t_000117_EDWV_gis_sn      sn on sn.id_obj      = zp.zp_id and sn.id_typ   = 116
      where z.INFOUZEL_TYPE_KOD <> 4

union all      
-- ==================================================================================================
 --что-то здесь не так :) 
 select (select ent_prefix from edw_ods.t_000117_edwv_edw_sltu_prefix where ent_name='zpramkisl_atu')||zp.zp_id  as network_el_key
            ,coalesce((select ent_prefix from edw_ods.t_000117_edwv_edw_sltu_prefix where ent_name='ats_atu')||zp.ats_id,'-1')  as network_parent_device_key
            ,117             ::VARCHAR as network_el_type_key
            --,sn.INV_PROJ_ID   as project_key
            ,zp.datev         as install_dt
            ,zp.nzp           as network_el_name
            ,coalesce((select ent_prefix from edw_ods.t_000117_edwv_edw_sltu_prefix where ent_name='sostinterv')||zp.sostint_kod,'-1') as equipment_status_key
            --,sn.invn          as inventory_num
            --,null             as equipment_brand
            --,kr.address_id    as address_key
            --,inTypePrefix     as component_element_network_p
            ,case when zp.priznakdel > 0 then zp.datemodif end as exp_dttm
            --,zp.prinadl_kod   as network_level_key
            --,sn.SERNUM        as sn_num
            --,null             as device_brand_key
            ,'-1'             as network_type_key
            --,null             as issue_date
            --,null             as department_key
            --,null             as type_object_key
            --,null             as network_link_key
            ,'01.01.1900' ::DATE      as eff_dttm
            --,null             as division_key
            ,case when zp.sostint_kod = 3 then zp.datemodif end as deinstall_dt
            --,zp.zp_id       as gis_object_id
            --,kr.street_kod
            --,kr.home
            --,kr.korp
            --,zp.nzp2                            as network_el_name2
            --,inPrefixZp||to_char(zp.zp_id)      as network_el_key2
            --,inPrefixKross||to_char(zp.ats_id2) as network_parent_device_key2
            --,z.infouzel_kod   as uzel_id
            --,z.infouzel_sname as uzel_name
             ,'-1' as technology_type_key 
            ,z.filial_kod     as branch_key
        from edw_ods.t_000117_edwv_zpramkisl_atu    zp
  left join edw_ods.t_000117_EDWV_ats_atu     kr on kr.ats_id      = zp.ats_id
  left join edw_ods.t_000117_EDWV_infouzel    z  on z.infouzel_kod = kr.uzel
   left join edw_ods.t_000117_EDWV_gis_sn      sn on sn.id_obj      = zp.zp_id and sn.id_typ   = 117
      where z.INFOUZEL_TYPE_KOD <> 4
 
 union all
 /*     
 union all
 
  select 'zpramkisl_atu#'||to_char(zp.zp_id)  as network_el_key
            ,'ats_atu#'||to_char(zp.ats_id2)  as network_parent_device_key
            ,117             ::VARCHAR as network_el_type_key
            --,sn.INV_PROJ_ID   as project_key
            ,zp.datev         as install_dt
            --,zp.nzp           as network_el_name
            ,'sostinterv#'||to_char(zp.sostint_kod) as equipment_status_key
            --,sn.invn          as inventory_num
            --,null             as equipment_brand
            --,kr.address_id    as address_key
            --,inTypePrefix     as component_element_network_p
            ,case when zp.priznakdel > 0 then zp.datemodif end as exp_dttm
            --,zp.prinadl_kod   as network_level_key
            --,sn.SERNUM        as sn_num
            --,null             as device_brand_key
            --,null             as network_type_key
            --,null             as issue_date
            --,null             as department_key
            --,null             as type_object_key
            --,null             as network_link_key
            ,'01.01.1900' ::DATE      as eff_dttm
            --,null             as division_key
            ,case when zp.sostint_kod = 3 then zp.datemodif end as deinstall_dt
            --,zp.zp_id       as gis_object_id
            --,kr.street_kod
            --,kr.home
            --,kr.korp
            --,zp.nzp2                            as network_el_name2
            --,inPrefixZp||to_char(zp.zp_id)      as network_el_key2
            --,inPrefixKross||to_char(zp.ats_id2) as network_parent_device_key2
            --,z.infouzel_kod   as uzel_id
            --,z.infouzel_sname as uzel_name
             ,'-1' as technology_type_key 
            ,z.filial_kod     as branch_key
        from edw_ods.t_000117_edwv_zpramkisl_atu    zp
  inner join edw_ods.t_000117_EDWV_ats_atu     kr on kr.ats_id      = zp.ats_id
  inner join edw_ods.t_000117_EDWV_infouzel    z  on z.infouzel_kod = kr.uzel
   left join edw_ods.t_000117_EDWV_gis_sn      sn on sn.id_obj      = zp.zp_id and sn.id_typ   = 117
      where z.INFOUZEL_TYPE_KOD <> 4
  */    
--==================================================================================================

--получение списка РК
select (select ent_prefix from edw_ods.t_000117_edwv_edw_sltu_prefix where ent_name='boxrh_atu')||b.box_id  as network_el_key
            ,coalesce((select ent_prefix from edw_ods.t_000117_edwv_edw_sltu_prefix where ent_name='boxrh_atu')||b.num_id,'-1') as network_parent_device_key
            ,3                ::VARCHAR as network_el_type_key
            --,sn.INV_PROJ_ID   as project_key
            ,b.datev          as install_dt
            ,b.numb||b.parall as network_element_name
            ,coalesce((select ent_prefix from edw_ods.t_000117_edwv_edw_sltu_prefix where ent_name='sostinterv')||b.sostint_kod,'-1') as equipment_status_key
            --,sn.invn          as inventory_num
            --,null             as equipment_brand
            --,b.address_id     as address_key
            --,inTypePrefix     as component_element_network_p
            ,case when b.prdel > 0 then b.datemodif end as exp_dttm
            --,b.prinadl_kod    as network_level_key
            --,sn.SERNUM        as sn_num
            --,inPrefixBrand||to_char(b.emkbox_kod) as device_brand_key
            ,'-1'                    as network_type_key
            --,null                     as issue_date
            --,null                     as department_key
            --,null                     as type_object_key
            --,null                     as network_link_key
            ,'01.01.1900' ::DATE              as eff_dttm
            --,null                     as division_key
            ,case when b.sostint_kod = 3 then b.datemodif end as deinstall_dt
            --,b.box_id       as gis_object_id
            --,b.street_kod
            --,b.home
            --,b.korp
            --,z.infouzel_kod   as uzel_id
            --,z.infouzel_sname as uzel_name
            ,'-1' as technology_type_key 
            ,z.filial_kod     as branch_key
        from edw_ods.t_000117_edwv_boxrh_atu   b
  left join edw_ods.t_000117_edwv_bboxr_atu   bx on bx.bbox_id     = b.num_id
  left join edw_ods.t_000117_EDWV_rh_atu      rh on rh.rh_id       = bx.rh_id
  left join edw_ods.t_000117_EDWV_infouzel    z  on z.infouzel_kod = rh.uzel
   left join edw_ods.t_000117_EDWV_gis_sn      sn on sn.id_obj      = b.box_id and sn.id_typ = 3
      where z.INFOUZEL_TYPE_KOD <> 4
     
 union all   
--======================================================================================
 --получение списка РК ПП

select (select ent_prefix from edw_ods.t_000117_edwv_edw_sltu_prefix where ent_name='boxats_atu')||b.box_id  as network_el_key
            ,coalesce((select ent_prefix from edw_ods.t_000117_edwv_edw_sltu_prefix where ent_name='zp_atu')||b.num_id,'-1') as network_parent_device_key
            ,4                ::VARCHAR as network_el_type_key
            --,sn.INV_PROJ_ID   as project_key
            ,b.datev          as install_dt
            ,b.numb||b.parall as network_element_name
            ,coalesce((select ent_prefix from edw_ods.t_000117_edwv_edw_sltu_prefix where ent_name='sostinterv')||b.sostint_kod,'-1') as equipment_status_key
            --,sn.invn          as inventory_num
            --,null             as equipment_brand
            --,b.address_id     as address_key
            --,inTypePrefix     as component_element_network_p
            ,case when b.prdel > 0 then b.datemodif end as exp_dttm
            --,b.prinadl_kod    as network_level_key
            --,sn.SERNUM        as sn_num
            --,inPrefixBrand||to_char(b.emkbox_kod) as device_brand_key
            ,'-1'                     as network_type_key
            --,null                     as issue_date
            --,null                     as department_key
            --,null                     as type_object_key
            --,null                     as network_link_key
            ,'01.01.1900' ::DATE             as eff_dttm
            --,null                     as division_key
            ,case when b.sostint_kod = 3 then b.datemodif end as deinstall_dt
            --,b.box_id       as gis_object_id
           -- ,b.street_kod
            --,b.home
            --,b.korp
            --,z.infouzel_kod   as uzel_id
            --,z.infouzel_sname as uzel_name
             ,'-1' as technology_type_key 
            ,z.filial_kod     as branch_key
        from edw_ods.t_000117_edwv_boxats_atu  b
  left join edw_ods.t_000117_edwv_zp_atu      zp on zp.zp_id       = b.num_id
  left join edw_ods.t_000117_EDWV_ats_atu     kr on kr.ats_id      = zp.ats_id
  left join edw_ods.t_000117_EDWV_infouzel    z  on z.infouzel_kod = kr.uzel
   left join edw_ods.t_000117_EDWV_gis_sn      sn on sn.id_obj      = b.box_id and sn.id_typ = 4
      where z.INFOUZEL_TYPE_KOD <> 4
union all      
--======================================================================================


select (select ent_prefix from edw_ods.t_000117_edwv_edw_sltu_prefix where ent_name='boxsph_atu')||b.box_id  as network_el_key
            ,coalesce((select ent_prefix from edw_ods.t_000117_edwv_edw_sltu_prefix where ent_name='ats_atu')||b.ats_id,'-1') as network_parent_device_key
            ,5                ::VARCHAR as network_el_type_key
            --,sn.INV_PROJ_ID   as project_key
            ,b.datev          as install_dt
            ,b.numb           as network_element_name
            ,coalesce((select ent_prefix from edw_ods.t_000117_edwv_edw_sltu_prefix where ent_name='sostinterv')||b.sostint_kod,'-1') as equipment_status_key
            --,sn.invn          as inventory_num
            --,null             as equipment_brand
            --,b.address_id     as address_key
            --,inTypePrefix     as component_element_network_p
            ,case when b.prdel > 0 then b.datemodif end as exp_dttm
            --,b.prinadl_kod    as network_level_key
            --,sn.SERNUM        as sn_num
            --,inPrefixBox||to_char(b.typboxsph_kod) as device_brand_key
            ,'-1'                     as network_type_key
            --,null                     as issue_date
            --,null                     as department_key
            --,null                     as type_object_key
            --,null                     as network_link_key
            ,'01.01.1900' ::DATE            as eff_dttm
            --,null                     as division_key
            ,case when b.sostint_kod = 3 then b.datemodif end as deinstall_dt
            --,b.box_id       as gis_object_id
            --,b.street_kod
            --,b.home
            --,b.korp
            --,z.infouzel_kod   as uzel_id
            --,z.infouzel_sname as uzel_name
             ,'-1' as technology_type_key 
            ,z.filial_kod     as branch_key
        from edw_ods.t_000117_edwv_boxsph_atu  b
  left join edw_ods.t_000117_EDWV_ats_atu     kr on kr.ats_id      = b.ats_id
  left join edw_ods.t_000117_EDWV_infouzel    z  on z.infouzel_kod = kr.uzel
   left join edw_ods.t_000117_EDWV_gis_sn      sn on sn.id_obj      = b.box_id and sn.id_typ = 5
      where z.INFOUZEL_TYPE_KOD <> 4
	  
	  )t;
	