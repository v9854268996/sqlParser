/*rev.55504 от 20.04.2020*/
                   truncate EDW_STG_DM_HEAT_MAP.AGG_BBA_CONSUMPTION_1_prt_p000019;
                   /*Commit помогает избежать блокировок таблицы при одновременной загрузке в несколько партиций*/
                   commit
                   ;
                   insert
                     into EDW_STG_DM_HEAT_MAP.AGG_BBA_CONSUMPTION_1_prt_p000019
                        ( 
                          billing_period
                        , account
                        , is_data_volume
                        , src_id
                        , period_dttm
                        , load_dttm
                        , eff_dttm
                        , exp_dttm
                        )
                   select
                          billing_period
                        , account
                        , is_data_volume
                        , 19 as src_id

                        , to_date('20190601', 'YYYYMMDD') as period_dttm
                        , now() as load_dttm
                        , to_date('20190601', 'YYYYMMDD') as eff_dttm
                        , to_date('20190601', 'YYYYMMDD') + INTERVAL '1 MONTH - 1 SECOND' as exp_dttm
                     from
                        (
                          select
                                 date_trunc('month', ts.srv_date) as billing_period
                               , ac.abs_external_code as account
                               , case when sum(coalesce(ts.srv_value, 0)) > 0 then 1 else 0 end as is_data_volume

                            from edw_ods.t_000019_abonent ab

                            JOIN edw_ods.t_000019_ct_users ct
                              ON ct.us_ab_id = ab.ab_id

                            JOIN edw_ods.t_000019_tb_services ts
                              ON ts.srv_user_name = ct.us_user_name

                            JOIN edw_ods.t_000019_ibs_abs_accounts ac
                              ON ac.abs_external_code = ab.ab_external_code

                           WHERE 1=1
                             AND ts.srv_srd_code = 'TRAF_ALL_AUTH'
                             AND ab.ab_ur_ustp IN ('PUBL', 'DUSA')
                             AND ts.tech_dt >= to_date('20190601', 'YYYYMMDD')
                             AND ts.tech_dt <= to_date('20190601', 'YYYYMMDD') + INTERVAL '1 MONTH - 1 SECOND'

                           group by date_trunc('month', ts.srv_date), ac.abs_external_code
                        ) v
                   ;
                   analyze EDW_STG_DM_HEAT_MAP.AGG_BBA_CONSUMPTION_1_prt_p000019
                   ;
                