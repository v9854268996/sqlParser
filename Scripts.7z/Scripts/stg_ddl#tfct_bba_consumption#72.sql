
  SET mapreduce.job.queuename=EKHD;
  SET hive.mapred.mode=unstrict;
  SET hive.mapred.supports.subdirectories=true;
  SET mapred.input.dir.recursive=true;

  SET mapreduce.job.reduces=300;
  SET mapreduce.input.fileinputformat.split.minsize=1500000000;
  SET mapreduce.input.fileinputformat.split.maxsize=3000000000;
  SET mapreduce.input.fileinputformat.split.minsize.per.node=1500000000;
  SET mapreduce.input.fileinputformat.split.minsize.per.rack=1500000000;

  SET p_start_date='20190601';
  SET p_end_date='20190630';
  SET p_src_start_ip=000072;
  SET p_src_start=000056;
  SET p_edw_odl=edw_prd_odl;
  SET p_edw_stg_ddl=edw_prd_stg_ddl;

INSERT OVERWRITE TABLE edw_prd_stg_ddl.t_${hiveconf:p_src_start_ip}_tfct_bba_consumption_stg
SELECT
  concat(${hiveconf:p_src_start}, '#', inv.srv_id) AS bba_consumption_key,
  concat(${hiveconf:p_src_start}, '#', ab.user_id) AS account_key,
  upper(concat(inv.srv_srd_code, '#', inv.srv_int_code, '#', coalesce(inv.srv_tfp_code,''))) AS service_key,
  '-1' AS service_user_key,
  inv.srv_user_name AS subs_key,
  '-1' AS price_plan_key,
  '-1' AS bill_detail_key,
  '-1' AS access_service_type_key,
  '-1' AS session_key,
  '-1' AS network_organization_key,
  '-1' AS rc_key,
  date_format (inv.srv_date, 'yyyyMM') AS billing_id,
  NULL AS ap_ip,
  inv.srv_date AS consumption_network_dttm,
  NULL AS session_start_dttm,
  NULL AS session_dur_nval,
  CASE WHEN sd.srd_traffic_in =  'Y' THEN ((inv.srv_value)/1024)/1024 else '0' END AS download_data_vol_nval,
  CASE WHEN sd.srd_traffic_in <> 'Y' THEN ((inv.srv_value)/1024)/1024 else '0' END AS upload_data_vol_nval,
  '-1' AS unit_of_measure_key,
  inv.srv_cost AS charge_rub,
  from_unixtime(unix_timestamp()) AS load_dttm,
  '1900-01-01 00:00:00' AS tech_dt,
  ${hiveconf:p_src_start_ip} AS src_id,
  '-1' AS wf_run_id,
  '0' AS deleted_ind,
  '0' AS mapping_code,
  '1900-01-01 00:00:00' AS eff_dttm,
  '2999-12-31 00:00:00' AS exp_dttm
FROM  edw_prd_odl.t_${hiveconf:p_src_start_ip}_tb_services inv
JOIN (
    SELECT
        sd.srd_code
      , sd.srd_int_code
      , sd.srd_traffic_in
    FROM  edw_prd_odl.T_${hiveconf:p_src_start_ip}_TB_SERV_DEFS SD 
    JOIN  edw_prd_odl.T_${hiveconf:p_src_start_ip}_TB_MEASUR_UNITS MU ON SD.SRD_MSR_CODE = MU.MSR_CODE
    WHERE 1=1
      AND sd.srd_srt_code = 'FLOW'
      AND INSTR(LOWER(SD.SRD_CODE), 'auth') = 0
      AND NVL(SD.SRD_NO_VIEW_STAT, 'N') = 'N'
      AND MU.MSR_BASE = 'BYTE'
  ) sd
ON 1=1
  AND inv.srv_srd_code = sd.srd_code
    AND inv.srv_int_code = sd.srd_int_code
JOIN (
    SELECT
        ab.ab_id
      , u.user_id
    FROM  edw_prd_odl.t_${hiveconf:p_src_start_ip}_abonent ab
    JOIN  edw_prd_odl.t_${hiveconf:p_src_start}_t_users u ON u.account = ab.ab_external_code
    JOIN  edw_prd_odl.t_${hiveconf:p_src_start}_t_user_type_ref ut ON u.user_type_id = ut.user_type_id
    WHERE 1=1
      AND ab.ab_ur_ustp <> 'TEST'
      AND (ut.coef = 1 OR ut.cod IN ('198','199'))
  ) ab
ON inv.srv_ab_id = ab.ab_id
WHERE 1=1
  AND inv.srv_value <> 0
  AND date_format(inv.tech_dt, 'yyyyMMdd') >= date_format(${hiveconf:p_start_date}, 'yyyyMMdd')
  AND date_format(inv.tech_dt, 'yyyyMMdd') <= date_format(${hiveconf:p_end_date}, 'yyyyMMdd')
  AND CASE
      WHEN UPPER(INV.SRV_TFP_CODE) LIKE '%TEST%'            THEN 1
      WHEN UPPER(INV.SRV_TFP_CODE) LIKE '%ТЕСТ%'            THEN 1
      WHEN UPPER(INV.SRV_TFP_CODE) LIKE '%1_BASE_ACCESS%'   THEN 1
      WHEN UPPER(INV.SRV_TFP_CODE) LIKE '%TVZ_FIRST%'       THEN 1
      WHEN UPPER(INV.SRV_TFP_CODE) LIKE '%TVS_WEB%'         THEN 1
      WHEN UPPER(INV.SRV_TFP_CODE) LIKE '%1A_UBASIC_IPTV%'  THEN 1
      WHEN UPPER(INV.SRV_TFP_CODE) LIKE '%1F_UBASIC_IPTV%'  THEN 1
      WHEN UPPER(INV.SRV_TFP_CODE) LIKE '%1F_UBASIC_IPTVU%' THEN 1
      WHEN UPPER(INV.SRV_TFP_CODE) LIKE '%1V_UBASIC_IPTV%'  THEN 1
      WHEN UPPER(INV.SRV_TFP_CODE) LIKE '%BASIC_IPTV%'      THEN 1
      WHEN UPPER(INV.SRV_TFP_CODE) LIKE '%TVS_DEMO%'        THEN 1
      WHEN UPPER(INV.SRV_TFP_CODE) LIKE '%TVS_TECH%'        THEN 1
      ELSE 0
      END = 0;
INSERT OVERWRITE TABLE edw_prd_stg_ddl.t_${hiveconf:p_src_start_ip}_tfct_bba_consumption_subs_stg
SELECT
  bba_consumption_key,
  subs_key,
  date_begin1,
  date_end1,
  date_begin2,
  date_end2,
  eff_dttm,
  exp_dttm
FROM
(
  SELECT
    ds.subs_key,
    ttbc.bba_consumption_key,
    coalesce(tbss.date_end, timestamp ('2999-12-31 00:00:00', 'yyyy-mm-dd hh24:mi:ss')) AS date_end2,
    tbss.date_begin                                           AS date_begin2,
    coalesce(ts.date_end, timestamp ('2999-12-31 00:00:00', 'yyyy-mm-dd hh24:mi:ss'))   AS date_end1,
    ts.date_begin                                             AS date_begin1,
    coalesce(ds.exp_dttm, timestamp ('2999-12-31 00:00:00', 'yyyy-mm-dd hh24:mi:ss'))   AS exp_dttm,
    ds.eff_dttm,
    CASE WHEN to_date(ttbc.consumption_network_dttm) BETWEEN to_date(tbss.date_begin) AND coalesce(to_date(tbss.date_end), to_date('2999-12-31')) THEN 1 ELSE 0 END AS flag1,
    CASE WHEN to_date(ttbc.consumption_network_dttm) BETWEEN to_date(ts.date_begin)   AND coalesce(to_date(ts.date_end),   to_date('2999-12-31')) THEN 1 ELSE 0 END AS flag2,
    CASE WHEN to_date(ttbc.consumption_network_dttm) BETWEEN to_date(ds.eff_dttm)     AND coalesce(to_date(ds.exp_dttm),   to_date('2999-12-31')) THEN 1 ELSE 0 END AS flag3
  FROM edw_prd_odl.t_${hiveconf:p_src_start_ip}_tb_start_servs tbss

       JOIN
       edw_prd_odl.t_${hiveconf:p_src_start}_t_services ts
         ON ts.service_id = tbss.service_id

       JOIN
       edw_prd_stg_ddl.t_${hiveconf:p_src_start_ip}_pre_dim_service_start_writable xref_start
         ON cast(ts.svc_id as varchar(256)) = xref_start.source_key
         --AND xref_start.region_id = 'CENTER' -- эти условия переехали в ETL_t_${hiveconf:p_src_start_ip}_pre_dim_service_start_writable.sql
         --AND to_date(xref_start.exp_dttm) = to_date('2999-12-31')
         --AND xref_start.sub_make = 1

       JOIN
       edw_prd_stg_ddl.t_${hiveconf:p_src_start_ip}_pre_dim_subs_writable ds
         ON ts.serv_first_id = ds.serv_first_id

       JOIN
        edw_prd_stg_ddl.t_${hiveconf:p_src_start_ip}_tfct_bba_consumption_stg ttbc
         ON tbss.sip_us_user_name = ttbc.subs_key
) a
WHERE a.flag1 = 1
  AND a.flag2 = 1
  AND a.flag3 = 1;
TRUNCATE TABLE edw_prd_stg_ddl.t_${hiveconf:p_src_start_ip}_tfct_bba_consumption;

INSERT INTO edw_prd_stg_ddl.t_${hiveconf:p_src_start_ip}_tfct_bba_consumption
SELECT
  tbc.bba_consumption_key,
  tbc.account_key,
  tbc.service_key,
  tbc.service_user_key,
  tbc.subs_key,
  tbc.price_plan_key,
  tbc.bill_detail_key,
  tbc.access_service_type_key,
  tbc.session_key,
  tbc.network_organization_key,
  tbc.rc_key,
  tbc.billing_id,
  tbc.ap_ip,
  tbc.consumption_network_dttm,
  tbc.session_start_dttm,
  tbc.session_dur_nval,
  tbc.download_data_vol_nval,
  tbc.upload_data_vol_nval,
  tbc.unit_of_measure_key,
  tbc.charge_rub,
  tbc.load_dttm,
  tbc.tech_dt,
  tbc.src_id,
  tbc.wf_run_id,
  tbc.deleted_ind,
  tbc.mapping_code,
  tbc.eff_dttm,
  tbc.exp_dttm
FROM
(
  SELECT
    tbc.bba_consumption_key,
    tbc.account_key,
    tbc.service_key,
    tbc.service_user_key,
    ds1.subs_key,
    tbc.price_plan_key,
    tbc.bill_detail_key,
    tbc.access_service_type_key,
    tbc.session_key,
    tbc.network_organization_key,
    tbc.rc_key,
    tbc.billing_id,
    tbc.ap_ip,
    tbc.consumption_network_dttm,
    tbc.session_start_dttm,
    tbc.session_dur_nval,
    tbc.download_data_vol_nval,
    tbc.upload_data_vol_nval,
    tbc.unit_of_measure_key,
    tbc.charge_rub,
    tbc.load_dttm,
    tbc.tech_dt,
    tbc.src_id,
    tbc.wf_run_id,
    tbc.deleted_ind,
    tbc.mapping_code,
    tbc.eff_dttm,
    tbc.exp_dttm,
    row_number() OVER (PARTITION BY tbc.bba_consumption_key
                           ORDER BY ds1.date_end1 DESC, ds1.exp_dttm DESC, ds1.date_end2 DESC, ds1.date_begin1 DESC,
                                    ds1.date_begin2 DESC, ds1.eff_dttm DESC) AS rn1
  FROM edw_prd_stg_ddl.t_${hiveconf:p_src_start_ip}_tfct_bba_consumption_stg tbc

       LEFT JOIN
       edw_prd_stg_ddl.t_${hiveconf:p_src_start_ip}_tfct_bba_consumption_subs_stg ds1
         ON ds1.bba_consumption_key = tbc.bba_consumption_key
) tbc
WHERE rn1 = 1;