/*rev. 17289*/
SET search_path = edw_stg_dmcm
;

TRUNCATE TABLE edw_stg_dmcm.tfct_charges_wifi_1_prt_p000132
;

INSERT INTO edw_stg_dmcm.tfct_charges_wifi_1_prt_p000132 (period
                                           , mrf_id
                                           , rf_id
                                           , rf_id_src
                                           , inn
                                           , segment
                                           , ap_count
                                           , charge_wifi
                                           , charge_adv
                                           , charge_filtr
                                           , charge_lease
                                           , charge_all
                                           , arpu_clnt
                                           , arpu_ap
                                           , calendar_key
                                           , charge_sale
                                           , charge_design
                                           , charge_connect
                                           , src_id)
SELECT tbl.period,
       tbl.mrf_id,
       coalesce(tbl.rf_id, 0),
       tbl.rf_id_src,
       coalesce(tbl.inn, ''),
       tbl.segment,
       tbl.ap_count,
       tbl.charge_wifi,
       tbl.charge_adv,
       tbl.charge_filtr,
       tbl.charge_lease,
       tbl.charge_all,
       tbl.charge_all AS arpu_clnt,
       CASE tbl.ap_count
         WHEN 0
                 THEN 0
         ELSE tbl.charge_all / tbl.ap_count
       END,
       to_char(period, 'YYYYMM'),
       charge_sale,
       charge_design,
       charge_connect,
       132 AS src_id
FROM (SELECT s.period,
             s.mrf_id,
             s.rf_id,
             s.rf_id_src,
             s.inn,
             s.segment,
             coalesce(s.ap_count, 0) AS ap_count,
             s.charge_wifi,
             s.charge_adv,
             s.charge_filtr,
             s.charge_lease,
             s.charge_wifi + s.charge_adv
               + s.charge_filtr + s.charge_lease + s.charge_sale
               + s.charge_design + s.charge_connect AS charge_all,
             s.charge_sale,
             s.charge_design,
             s.charge_connect
      FROM edw_stg_dmcm.pre_charges_wifi_stg s) tbl
WHERE tbl.charge_wifi <> 0
   OR tbl.charge_adv <> 0
   OR tbl.charge_filtr <> 0
   OR tbl.charge_lease <> 0
   OR tbl.charge_sale <> 0
   OR tbl.charge_design <> 0
   OR tbl.charge_connect <> 0
;

ANALYSE edw_stg_dmcm.tfct_charges_wifi_1_prt_p000132
;
