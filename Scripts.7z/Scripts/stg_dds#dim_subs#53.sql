/*rev.55847 от 23.04.2020*/

/*rev.55847 от 23.04.2020*/
truncate edw_stg_dds.t_000053_dim_subs_01;

insert into edw_stg_dds.t_000053_dim_subs_01
(
serv_first_id
, date_begin
, date_end
, business_service
, user_id
, house_id
, rn_child
, rn_parent
)
with ttt as (
select
round(ts1.serv_first_id) as serv_first_id
, min(ts1.date_begin) as date_begin
, max(coalesce(ts1.date_end, to_date('2999-12-31', 'YYYY-MM-DD'))) as date_end
, bs.business_service_name as business_service
, round(ts1.user_id) as user_id
, round(ts1.house_id) as house_id
from edw_ods.t_000053_t_services ts1
join edw_stg_dds.t_dim_service_xref_start xref
			on xref.source_key = ts1.svc_id::text
			and xref.sub_make = 1
			and to_date('20190601','YYYYMMDD') + INTERVAL '1 MONTH - 1 second' between xref.eff_dttm and xref.exp_dttm
			and xref.region_id = 'CENTER'
 join edw_dds.dim_service et
				on et.service_key = xref.service_key
				and to_date('20190601','YYYYMMDD') + INTERVAL '1 MONTH - 1 second' between et.eff_dttm and et.exp_dttm
 JOIN edw_dds.dim_business_service bs ON bs.business_service_key = et.business_service_key
			and to_date('20190601','YYYYMMDD') + INTERVAL '1 MONTH - 1 second' between bs.eff_dttm and bs.exp_dttm
where to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second' +  interval '7' between ts1.eff_dttm and ts1.exp_dttm
group by
serv_first_id
, bs.business_service_name
, round(ts1.user_id)
, ts1.house_id
)
select serv_first_id,date_begin,date_end,business_service,user_id,house_id
, row_number() over (partition by serv_first_id, business_service order by date_begin asc) as rn_child
, row_number() over (partition by serv_first_id, business_service order by coalesce(date_end, to_date('2999-12-31', 'YYYY-MM-DD')) desc) as rn_parent
from ttt;
commit;
analyse edw_stg_dds.t_000053_dim_subs_01;

truncate edw_stg_dds.t_000053_dim_subs_04;
insert into edw_stg_dds.t_000053_dim_subs_04
(
serv_first_id
, date_begin
, date_end
, business_service
, user_id
, inn
, rn_child
, rn_parent
)
select
	ts1.serv_first_id
	, min(ts1.date_begin) as date_begin
	, max(ts1.date_end) as date_end
	, business_service
	, ts1.user_id
	, tu1.inn as inn
	, row_number() over (partition by ts1.serv_first_id, ts1.business_service order by min(ts1.date_begin) asc) as rn_child
	, row_number() over (partition by ts1.serv_first_id, ts1.business_service order by max(ts1.date_end) desc) as rn_parent
from
(
	select
	round(serv_first_id) as serv_first_id
	, min(ts1.date_begin) as date_begin
	, max(coalesce(ts1.date_end, to_date('2999-12-31', 'YYYY-MM-DD'))) as date_end
	, bs.business_service_name as business_service
	, round(ts1.user_id) as user_id

	from edw_ods.t_000053_t_services ts1
	  join edw_stg_dds.t_dim_service_xref_start xref
				on xref.source_key = ts1.svc_id::text
				and xref.sub_make = 1
				and to_date('20190601','YYYYMMDD') + INTERVAL '1 MONTH - 1 second' between xref.eff_dttm and xref.exp_dttm
				and xref.region_id = 'CENTER'
	 join edw_dds.dim_service et
					on et.service_key = xref.service_key
					and to_date('20190601','YYYYMMDD') + INTERVAL '1 MONTH - 1 second' between et.eff_dttm and et.exp_dttm
	 JOIN edw_dds.dim_business_service bs ON bs.business_service_key = et.business_service_key
				and to_date('20190601','YYYYMMDD') + INTERVAL '1 MONTH - 1 second' between bs.eff_dttm and bs.exp_dttm
	where to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second' +  interval '7' between ts1.eff_dttm and ts1.exp_dttm
	group by
	round(serv_first_id)
	,bs.business_service_name
	, ts1.user_id

) ts1--таблица постоянной услуги, для последующей реализации абонента
join edw_ods.t_000053_t_users tu1
	on
	round(ts1.user_id) = round(tu1.user_id)
	and iscorp = 'Y'
	and (tu1.inn <> '' or tu1.inn is not Null)
	and tu1.deleted_ind=0
	and to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second' +  interval '7' between tu1.eff_dttm and tu1.exp_dttm
group by
serv_first_id
, ts1.business_service
, ts1.user_id
, tu1.inn;
commit;
analyze edw_stg_dds.t_000053_dim_subs_04;

truncate table edw_stg_dds.t_000053_dim_subs_11_nariad_test;
insert into edw_stg_dds.t_000053_dim_subs_11_nariad_test
(
service_first_id_parent
, service_first_id_child
, src_id
, eff_dttm
, exp_dttm
, day
)
select distinct
t2.serv_first_id as service_first_id_parent
, t1.serv_first_id as service_first_id_child
, 000053 as src_id
, t1.date_begin as eff_dttm --потомок
, t2.date_end as exp_dttm --родитель
, abs(to_date(t1.date_begin::text, 'YYYY-MM-DD') - to_date(t2.date_end::text, 'YYYY-MM-DD')) as day
from edw_stg_dds.t_000053_dim_subs_01 t1
inner join edw_stg_dds.t_000053_dim_subs_01 t2
	on 1=1
	and (t1.business_service  = t2.business_service ) --обе абонентообразующие услуги должны  относится к одной бизнес-услуге
	and (round(t1.user_id) = round(t2.user_id)) --постоянные услуги относятся к одному клиенту
	and (round(t1.serv_first_id) > round(t2.serv_first_id))
	and to_date(t1.date_begin::text, 'YYYY-MM-DD') - to_date(t2.date_end::text, 'YYYY-MM-DD') between -7 and 30
	and t2.house_id = t1.house_id
	and t2.rn_parent = 1
	and t1.rn_child = 1;

analyse edw_stg_dds.t_000053_dim_subs_11_nariad_test;

truncate table edw_stg_dds.t_000053_dim_subs_10_nariad;

------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
set optimizer = on;
select edw_stg_dds.f_000053_dim_subs_get_pairs();


	commit;
--удаление дублей после работы функции
delete from edw_stg_dds.t_000053_dim_subs_10_nariad nariad
using
(
	select nariad.service_first_id_parent,nariad.service_first_id_child,nariad.gp_segment_id,max(nariad.ctid) ctid
	from edw_stg_dds.t_000053_dim_subs_10_nariad nariad
	join
	(
	select service_first_id_parent,service_first_id_child from
	edw_stg_dds.t_000053_dim_subs_10_nariad
	group by service_first_id_parent,service_first_id_child
	having count (*) > 1
	) tmp
	on nariad.service_first_id_parent = tmp.service_first_id_parent and nariad.service_first_id_child = tmp.service_first_id_child
	group by nariad.service_first_id_parent,nariad.service_first_id_child,nariad.gp_segment_id
) del
where
nariad.service_first_id_parent = del.service_first_id_parent
and nariad.service_first_id_child = del.service_first_id_child
and nariad.gp_segment_id = del.gp_segment_id
and nariad.ctid = del.ctid;
commit;
analyse edw_stg_dds.t_000053_dim_subs_10_nariad;
set optimizer = off;
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
truncate table edw_stg_dds.t_000053_dim_subs_11_nariad_test;
insert into edw_stg_dds.t_000053_dim_subs_11_nariad_test
(
service_first_id_parent
, service_first_id_child
, src_id
, eff_dttm
, exp_dttm
, day
)
select distinct
t2.serv_first_id as service_first_id_parent
, t1.serv_first_id as service_first_id_child
, 000053 as src_id
, t1.date_begin as eff_dttm --потомок
, t2.date_end as exp_dttm --родитель
, abs(to_date(t1.date_begin::text, 'YYYY-MM-DD') - to_date(t2.date_end::text, 'YYYY-MM-DD')) as day

from edw_stg_dds.t_000053_dim_subs_01 t1
inner join edw_stg_dds.t_000053_dim_subs_01 t2
	on 1=1
	and (t1.business_service  = t2.business_service ) --обе абонентообразующие услуги должны  относится к одной бизнес-услуге
	and (round(t1.user_id) = round(t2.user_id)) --постоянные услуги относятся к одному клиенту
	and (round(t1.serv_first_id) > round(t2.serv_first_id))
	and to_date(t1.date_begin::text, 'YYYY-MM-DD') - to_date(t2.date_end::text, 'YYYY-MM-DD') between -7 and 30
	and t2.rn_parent = 1
	and t1.rn_child = 1;

analyse edw_stg_dds.t_000053_dim_subs_11_nariad_test;

-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
set optimizer = on;
select edw_stg_dds.f_000053_dim_subs_get_pairs();



commit;
--удаление дублей после работы функции
delete from edw_stg_dds.t_000053_dim_subs_10_nariad nariad
using
(
	select nariad.service_first_id_parent,nariad.service_first_id_child,nariad.gp_segment_id,max(nariad.ctid) ctid
	from edw_stg_dds.t_000053_dim_subs_10_nariad nariad
	join
	(
	select service_first_id_parent,service_first_id_child from
	edw_stg_dds.t_000053_dim_subs_10_nariad
	group by service_first_id_parent,service_first_id_child
	having count (*) > 1
	) tmp
	on nariad.service_first_id_parent = tmp.service_first_id_parent and nariad.service_first_id_child = tmp.service_first_id_child
	group by nariad.service_first_id_parent,nariad.service_first_id_child,nariad.gp_segment_id
) del
where
nariad.service_first_id_parent = del.service_first_id_parent
and nariad.service_first_id_child = del.service_first_id_child
and nariad.gp_segment_id = del.gp_segment_id
and nariad.ctid = del.ctid;
commit;
analyse edw_stg_dds.t_000053_dim_subs_10_nariad;
set optimizer = off;

truncate table edw_stg_dds.t_000053_dim_subs_11_nariad_test;
insert into edw_stg_dds.t_000053_dim_subs_11_nariad_test
(
service_first_id_parent
, service_first_id_child
, src_id
, eff_dttm
, exp_dttm
, day
)
select distinct
t2.serv_first_id as service_first_id_parent
, t1.serv_first_id as service_first_id_child
, 000053 as src_id
, t1.date_begin as eff_dttm --потомок
, t2.date_end as exp_dttm --родитель
, abs(to_date(t1.date_begin::text, 'YYYY-MM-DD') - to_date(t2.date_end::text, 'YYYY-MM-DD')) as day
from  edw_stg_dds.t_000053_dim_subs_04 t1
inner join edw_stg_dds.t_000053_dim_subs_04 t2
	on
	1=1
	and (t1.business_service  = t2.business_service) --обе абонентообразующие услуги должны  относится к одной бизнес-услуге
	and (t1.user_id <> t2.user_id)
	and t1.inn <> '' and t2.inn <> ''
	and (coalesce(t1.inn, 'inn1') = coalesce(t2.inn, 'inn2')) --постоянные услуги относятся к одному клиенту
	and (round(t1.serv_first_id) > round(t2.serv_first_id))
	and to_date(t1.date_begin::text, 'YYYY-MM-DD') - to_date(t2.date_end::text, 'YYYY-MM-DD') between -7 and 30
	and t2.rn_parent = 1
	and t1.rn_child = 1;

analyse edw_stg_dds.t_000053_dim_subs_11_nariad_test;

set optimizer = on;
select edw_stg_dds.f_000053_dim_subs_get_pairs();

commit;


--удаление дублей после работы функции
delete from edw_stg_dds.t_000053_dim_subs_10_nariad nariad
using
(
	select nariad.service_first_id_parent,nariad.service_first_id_child,nariad.gp_segment_id,max(nariad.ctid) ctid
	from edw_stg_dds.t_000053_dim_subs_10_nariad nariad
	join
	(
	select service_first_id_parent,service_first_id_child from
	edw_stg_dds.t_000053_dim_subs_10_nariad
	group by service_first_id_parent,service_first_id_child
	having count (*) > 1
	) tmp
	on nariad.service_first_id_parent = tmp.service_first_id_parent and nariad.service_first_id_child = tmp.service_first_id_child
	group by nariad.service_first_id_parent,nariad.service_first_id_child,nariad.gp_segment_id
) del
where
nariad.service_first_id_parent = del.service_first_id_parent
and nariad.service_first_id_child = del.service_first_id_child
and nariad.gp_segment_id = del.gp_segment_id
and nariad.ctid = del.ctid;
commit;

analyse edw_stg_dds.t_000053_dim_subs_10_nariad;
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
select edw_stg_dds.f_000053_dim_subs_get_parent_child();
analyze edw_stg_dds.t_000053_dim_subs_parent_child;
commit;
set optimizer = off;
truncate table edw_stg_dds.t_000053_dim_subs_12;
INSERT INTO edw_stg_dds.t_000053_dim_subs_12
(subs_key
, subs_activation_dt
, subs_cancellation_dt
, address_key
, service_key
, account_key
, subs_code
, src_id
, load_dttm
, start_date
, end_date
, duty_num_key
, center_num_key
, service_id
, serv_first_id
, eff_dttm
, exp_dttm
)
select
subs_key
, subs_activation_dt
, max(end_date) over (partition by subs_key order by end_date desc) + interval '1 day - 1 second' as subs_cancellation_dt
, address_key
, service_key
, src_id||'#'||account_key as account_key
, subs_code
, src_id
, load_dttm
, start_date
, end_date + interval '1 day - 1 second' as end_date
, duty_num_key
, center_num_key
, service_id
, serv_first_id
, start_date as eff_dttm
, end_date + interval '1 day - 1 second' as exp_dttm

from
(
	select
	subs_key
	, min(start_date) over (partition by subs_key order by start_date ) subs_activation_dt
	, address_key
	, service_key
	, account_key
	, subs_code
	, src_id
	, load_dttm
	, start_date
	, end_date
	, duty_num_key
	, center_num_key
	, service_id
	, serv_first_id

	from
	(
		select
		subs_key
		, address_key
		, service_key
		, account_key
		, subs_code
		, src_id
		, load_dttm
		, start_date
		, coalesce(max(start_date) over (partition by subs_key order by start_date, end_date, service_id asc rows between 1 following and 1 following)- interval '1 day',end_date,'2999-12-31 00:00:00'::date)  end_date
		, duty_num_key
		, center_num_key
		, service_id
		, serv_first_id

		from
		(
			select
			subs_key
			, subs_activation_dt
			, subs_cancellation_dt
			, address_key
			, service_key
			, account_key
			, subs_code
			, src_id
			, load_dttm
			, start_date
			, end_date
			, duty_num_key
			, center_num_key
			, service_id
			, serv_first_id
			, case when md5 = max(md5) over (partition by subs_key order by start_date, service_id asc rows between 1 following and 1 following) then 'Y' else 'N' end is_wrong_version

			from
			(
				select
				subs_key
				, subs_activation_dt
				, subs_cancellation_dt
				, address_key
				, service_key
				, account_key
				, subs_code
				, src_id
				, load_dttm
				, start_date
				, end_date
				, duty_num_key
				, center_num_key
				, service_id
				, serv_first_id
				, md5

				from
				(
					select
					subs_key
					, subs_activation_dt
					, subs_cancellation_dt
					, address_key
					, service_key
					, account_key
					, subs_code
					, src_id
					, load_dttm
					, start_date
					, end_date
					, duty_num_key
					, center_num_key
					, service_id
					, serv_first_id
					, md5
					, max(md5) over (partition by subs_key order by start_date, service_id asc rows between 1 following and 1 following) md5_next
					, case
						when md5 = md5_prev
						and md5_next is not null
							then 'Y'
							else 'N'
					end is_wrong_version

					from
					(
						select
						subs_key
						, subs_activation_dt
						, subs_cancellation_dt
						, address_key
						, service_key
						, account_key
						, subs_code
						, src_id
						, load_dttm
						, start_date
						, end_date
						, duty_num_key
						, center_num_key
						, service_id
						, serv_first_id
						, md5
						, max(md5) over (partition by subs_key order by start_date, service_id asc rows between 1 preceding and 1 preceding) md5_prev
						, max(md5) over (partition by subs_key order by start_date, service_id asc rows between 1 following and 1 following) md5_next

						from
						(
							select
							subs_key
							, subs_activation_dt
							, subs_cancellation_dt
							, address_key
							, service_key
							, account_key
							, subs_code
							, src_id
							, load_dttm
							, start_date
							, end_date
							, duty_num_key
							, center_num_key
							, service_id
							, serv_first_id
							, md5(cast(subs_key as varchar) ||'#'|| cast(subs_activation_dt as varchar) ||'#'|| cast(subs_cancellation_dt as varchar) ||'#'|| coalesce(subs_code,'') ||'#'|| cast(service_key as varchar) ||'#'|| coalesce(address_key,'') ||'#'|| cast(account_key as varchar) ||'#'|| cast(service_id as varchar)||'#'|| cast(serv_first_id as varchar) ) md5

							from
							(
								select
								subs_key
								, min(subs_activation_dt) over (partition by subs_key) subs_activation_dt
								, max(subs_cancellation_dt) over (partition by subs_key) subs_cancellation_dt
								, address_key
								, service_key
								, account_key
								, subs_code
								, src_id
								, load_dttm
								, start_date
								, end_date
								, duty_num_key
								, center_num_key
								, service_id
								, serv_first_id

								from
								(
									select
									subs_pr_30days.subs_key||'#'||sum(subs_pr_30days.pr_30_days) over (partition by subs_pr_30days.subs_key order by subs_pr_30days.start_date, subs_pr_30days.service_id asc )  as subs_key            -- id абонента
									, subs_pr_30days.subs_activation_dt  -- дата активации абонента
									, subs_pr_30days.subs_cancellation_dt-- дата закрытия абонента,
									, subs_pr_30days.address_key         -- id адреса оказания услуги
									, subs_pr_30days.service_key         -- id услуги
									, subs_pr_30days.account_key         -- id лицевого счета
									, subs_pr_30days.subs_code           -- код доступа к услуге
									, 000053 as src_id
									, now() as load_dttm
									, subs_pr_30days.start_date            -- дата начала действия записи
									, subs_pr_30days.end_date
									, subs_pr_30days.duty_num_key
									, subs_pr_30days.center_num_key
									, subs_pr_30days.service_id
									, subs_pr_30days.serv_first_id


									from
									(
										select
										s.subs_key            -- id абонента
										, s.subs_activation_dt  -- дата активации абонента,
										, s.subs_cancellation_dt-- дата закрытия абонента,
										, s.address_key        -- id адреса оказания услуги
										, s.service_key         -- id услуги
										, s.account_key         -- id лицевого счета
										, s.subs_code           -- код доступа к услуге
										, s.start_date            -- дата начала действия записи
										, s.end_date
										, s.duty_num_key
										, s.center_num_key
										, s.service_id
										, s.serv_first_id
										, case
											when extract(day from s.start_date - lag (s.end_date) over (partition by s.subs_key order by s.start_date asc,s.end_date asc, s.service_id asc) )::integer >30
												then 1
												else 0
										end as pr_30_days
										from
										(
											select
											sub_pr_bs.subs_key||'#'||sum(sub_pr_bs.pr_bs) over (partition by sub_pr_bs.subs_key order by sub_pr_bs.start_date, sub_pr_bs.service_id asc ) as subs_key            -- id абонента
											, sub_pr_bs.subs_activation_dt  -- дата активации абонента,
											, sub_pr_bs.subs_cancellation_dt-- дата закрытия абонента,
											, sub_pr_bs.address_key         -- id адреса оказания услуги
											, sub_pr_bs.service_key         -- id услуги
											, sub_pr_bs.account_key         -- id лицевого счета
											, sub_pr_bs.subs_code           -- код доступа к услуге
											, sub_pr_bs.start_date            -- дата начала действия записи
											, sub_pr_bs.end_date
											, sub_pr_bs.duty_num_key
											, sub_pr_bs.center_num_key
											, sub_pr_bs.service_id
											, sub_pr_bs.serv_first_id
											 --case when extract(day from sub_pr_bs.start_date - lag ( sub_pr_bs.end_date) over (partition by sub_pr_bs.subs_key||'#'||coalesce(sub_pr_bs.PR_bs,0) order by sub_pr_bs.start_date asc, sub_pr_bs.service_id asc) )::integer >30 then 1 else 0 end as pr_30_days
											from
											(
												select
												subs_pr_sub.subs_key as subs_key            -- id абонента
												, subs_pr_sub.subs_activation_dt  -- дата активации абонента,
												, subs_pr_sub.subs_cancellation_dt-- дата закрытия абонента,
												, subs_pr_sub.address_key         -- id адреса оказания услуги
												, subs_pr_sub.service_key         -- id услуги
												, subs_pr_sub.account_key         -- id лицевого счета
												, subs_pr_sub.subs_code           -- код доступа к услуге
												, subs_pr_sub.start_date          -- дата начала действия записи
												, subs_pr_sub.end_date
												, subs_pr_sub.duty_num_key
												, subs_pr_sub.center_num_key
												, subs_pr_sub.service_id
												, subs_pr_sub.serv_first_id
												, case
													when subs_pr_sub.business_service <> lag ( subs_pr_sub.business_service) over (partition by subs_pr_sub.subs_key order by subs_pr_sub.start_date asc, subs_pr_sub.service_id asc)
														then 1
														else 0
												end as PR_BS

												from
												(
-----------------------------------------------------------------------------------------------------------------------------------------------------------------

	select
	coalesce(ss.service_first_id_parent_root, round(t_services.serv_first_id)::text)||'#'|| round(t_users.user_id) as subs_key -- id абонента
	, coalesce(date_trunc('day',t_services.date_begin::timestamp), '1900-01-01 00:00:00'::date) as subs_activation_dt  -- дата активации абонента
	, coalesce(date_trunc('day',t_services.date_end::timestamp), '2999-12-31 00:00:00'::date) as subs_cancellation_dt-- дата закрытия абонента
	, round(t_services.house_id) ||'#'|| coalesce(t_services.flat, '0') as address_key         -- id адреса оказания услуги
	, coalesce(hkey.service_key, round(t_services.svc_id)::text) as service_key         -- id услуги
	, round(t_users.user_id) as account_key         -- id лицевого счета
	, case
		when t_services.svctype = '0'
			then round(t_services.dev_id)::text
			else NULL
	end as subs_code            -- код доступа к услуге
	, coalesce(date_trunc('day',t_services.date_begin::timestamp), '1900-01-01 00:00:00') as start_date           -- дата начала действия записи
	, coalesce(date_trunc('day',t_services.date_end::timestamp), '2999-12-31 00:00:00') as end_date             -- дата окончания действия записи
	, xref.sub_make
	, bs.business_service_name as business_service
	, round(t_services.service_id)    as service_id
	, round(t_services.serv_first_id)     as serv_first_id
	, case
		when t_user_type_ref.coef = 1
			then 0
		when t_users.user_type_id in (499920451, 540553906)
			then 0
		when t_vip_sp.user_id_sp is null
			then 1
		when ttr.coef = 1
			then 0
			else 1
		end as duty_num_key
	, case
		when t_users.user_type_id in (499920451, 540553906)
		and t_user_type_ref.coef = 0
			then 1
			else 0
	end as center_num_key

	from edw_ods.t_000053_t_services t_services
	join edw_stg_dds.t_dim_service_xref_start xref
			on xref.source_key = t_services.svc_id::text
			and to_date('20190601','YYYYMMDD') + INTERVAL '1 MONTH - 1 second' between xref.eff_dttm and xref.exp_dttm
			and xref.region_id = 'CENTER'
		 join edw_dds.dim_service et
				on et.service_key = xref.service_key
				and to_date('20190601','YYYYMMDD') + INTERVAL '1 MONTH - 1 second' between et.eff_dttm and et.exp_dttm
		 JOIN edw_dds.dim_business_service bs ON bs.business_service_key = et.business_service_key
			and to_date('20190601','YYYYMMDD') + INTERVAL '1 MONTH - 1 second' between bs.eff_dttm and bs.exp_dttm
	left join
	(
		select
		round(ts1.service_id) as service_id
		, round(ts1.svc_id)||'#'||round(ts2.svc_id) as service_key

		from edw_ods.t_000053_t_services ts1
		join edw_stg_dds.t_dim_service_xref_start xref
			on xref.source_key = ts1.svc_id::text
			and  xref.sub_make = 1
			and to_date('20190601','YYYYMMDD') + INTERVAL '1 MONTH - 1 second' between xref.eff_dttm and xref.exp_dttm
			and xref.region_id = 'CENTER'
		 join edw_dds.dim_service et
				on et.service_key = xref.service_key
				and to_date('20190601','YYYYMMDD') + INTERVAL '1 MONTH - 1 second' between et.eff_dttm and et.exp_dttm
		 JOIN edw_dds.dim_business_service bs ON bs.business_service_key = et.business_service_key
			and to_date('20190601','YYYYMMDD') + INTERVAL '1 MONTH - 1 second' between bs.eff_dttm and bs.exp_dttm
		and bs.business_service_key in (10401,10402,10403,10408)  --  (10401,10402,10403) 29.01.2020
		inner join edw_ods.t_000053_t_services ts2
			on
			round(ts1.main_serv_first_id) = round(ts2.service_id)
		where to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second' between ts1.eff_dttm and ts1.exp_dttm
			and to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second' between ts2.eff_dttm and ts2.exp_dttm
	) hkey
		on
		hkey.service_id = t_services.service_id
	LEFT JOIN edw_stg_dds.t_000053_dim_subs_parent_child ss
		ON
		(round(t_services.serv_first_id))::text = ss.service_first_id_child
	   /*Таблица переходов услуг parent-child для поиска ID услуги предка*/
	left join edw_ods.t_000053_t_users t_users
		on t_services.user_id=t_users.user_id
		and to_date(substr('20190630', 1, 8), 'YYYYMMDD')+ INTERVAL '1 day - 1 second' +  interval '7'
            between t_users.eff_dttm and t_users.exp_dttm
	inner join edw_ods.t_000053_t_user_type_ref t_user_type_ref
		on
		t_user_type_ref.user_type_id=t_users.user_type_id
		and to_date(substr('20190630', 1, 8), 'YYYYMMDD')+ INTERVAL '1 day - 1 second'
            between t_user_type_ref.eff_dttm and t_user_type_ref.exp_dttm
	inner join edw_ods.t_000053_t_user_type_ref ttr
		on
		ttr.user_type_id=t_users.user_type_id
		and ttr.DELETED_IND = 0
		and to_date(substr('20190630', 1, 8), 'YYYYMMDD')+ INTERVAL '1 day - 1 second'
            between ttr.eff_dttm and ttr.exp_dttm
	left join edw_ods.t_000053_t_vip_sp t_vip_sp
		on
		t_services.user_id=t_vip_sp.user_id_sp
		and to_date(substr('20190630', 1, 8), 'YYYYMMDD')+ INTERVAL '1 day - 1 second'
            between t_vip_sp.eff_dttm and t_vip_sp.exp_dttm
	where 1=1
	and to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second' +  interval '7' between t_services.eff_dttm and t_services.exp_dttm
	and t_services.date_begin<=coalesce(to_date(t_services.date_end::text,'YYYY-MM-DD H24-MI-SS'),to_date('2999-12-31 00:00:00','YYYY-MM-DD H24-MI-SS'))
	and to_date(coalesce(t_services.date_end::text, '2999-12-31'),'YYYY-MM-DD') - to_date(t_services.date_begin::text,'YYYY-MM-DD') <> 0

												) subs_pr_sub
												where 1=1
												and subs_pr_sub.sub_make = 1
											) sub_pr_bs
										) s
									) subs_pr_30days
								) core_logic
							) subs
						) v_calc_md5
					) v_calc_prev_next
				) v_calc_wrong_versions
				where 1=1
				and is_wrong_version = 'N'
			) v_skip_wrong_versions
		) v_calc_end_date
	) v_dttm
	where 1=1
	and start_date <= end_date
) v_subs_activation_dt;
commit;
analyze edw_stg_dds.t_000053_dim_subs_12;
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
truncate table edw_stg_dds.t_000053_sub_ip2;

insert into edw_stg_dds.t_000053_sub_ip2
(
us_user_name
, us_tfp_code
, start_date
, subs_cancellation_dt
, ver
)
SELECT
sub_ip1.us_user_name
, coalesce(sub_ip1.us_tfp_code,'-1') as us_tfp_code
, sub_ip1.start_date
, sub_ip1.subs_cancellation_dt
, row_number() over (partition by us_user_name order by start_date,jn_operation,sub_ip1.subs_cancellation_dt,coalesce(us_tfp_code,'-1')) as ver    -- для правильного отображения даты начала, даты окончания действия ТП

from
(
	SELECT
	us_user_name as us_user_name
	, us_tfp_code as us_tfp_code
	, coalesce(update_date,input_date)  as start_date
	, coalesce(us_close_date, to_date('2999-12-31','yyyy-mm-dd')) as subs_cancellation_dt
	, jn_operation as jn_operation  -- для правильного отображения даты начала, даты окончания действия ТП

	FROM
	(
		select distinct
		us_user_name
		, us_tfp_code
		, update_date
		, input_date
		, us_close_date
		, jn_operation

		from edw_ods.t_000068_ct_users_jn
		where tech_dt <=to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second'
	) ct_users_jn

UNION

	SELECT
	us_user_name as  us_user_name
	, us_tfp_code as us_tfp_code
	, coalesce(update_date,input_date)  as start_date
	, coalesce(us_close_date, to_date('2999-12-31','yyyy-mm-dd')) as subs_cancellation_dt
	, 'UPD' as jn_operation  -- для правильного отображения даты начала, даты окончания действия ТП

	FROM
	(
		select distinct
		us_user_name
		, us_tfp_code
		, update_date
		, input_date
		, us_close_date

		from edw_ods.t_000068_ct_users
		where tech_dt between date_trunc('month',to_date('20190601', 'YYYYMMDD')) and to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second'
	)ct_users
)sub_ip1
;

commit;
analyze edw_stg_dds.t_000053_sub_ip2;
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
truncate table edw_stg_dds.t_000053_sub_1;
insert into edw_stg_dds.t_000053_sub_1
(
subs_key
, service_id
, start_date
, end_date
, un_start_date
, un_end_date
)

SELECT
dim_subs.subs_key
, dim_subs.service_id::numeric
, dim_subs.start_date
, dim_subs.end_date

    --Если тестовый ТП попал в середину service_id, то игнорируем его
    --Если тестовый ТП перекрыл начало service_id, то service_id начинаем с конца тестового ТП
    --Если тестовый ТП перекрыл конец service_id, то service_id заканчивыаем с начала тестового ТП
    --Если тестовый ТП перекрыл полностью service_id, то длительнольность service_id будет отрицательной
, case
	when dim_subs.start_date>=coalesce(date_trunc('day', sub_ip6.start_date),'1900-01-01')
	and coalesce(sub_ip6.start_date,'1900-01-01') > '1900-01-01'
		then date_trunc('day', (sub_ip6.end_date + interval '1 day'))
		else dim_subs.start_date
end un_start_date
, case
	when dim_subs.end_date <= coalesce(date_trunc('day', sub_ip6.end_date),'1900-01-01')
	and coalesce(sub_ip6.end_date,'1900-01-01') > '1900-01-01'
		then date_trunc('day', sub_ip6.start_date) - interval '1 day'
		else dim_subs.end_date
end un_end_date

FROM  edw_stg_dds.t_000053_dim_subs_12 dim_subs
left join
(
	SELECT
	sub_ip5.service_id
	, min(sub_ip5.start_date) as start_date
	, max(sub_ip5.end_date) as end_date

	FROM
	(
		SELECT
		sub_ip4.us_user_name
		, sub_ip4.us_tfp_code
		, GREATEST(sub_ip4.start_date, tb_start_servs.date_begin) as start_date
		, LEAST(to_date(sub_ip4.end_date::text,'yyyy-mm-dd'), coalesce(to_date(tb_start_servs.date_end::text,'yyyy-mm-dd'), to_date('2999-12-31','yyyy-mm-dd'))) as end_date
		, round(tb_start_servs.service_id) as service_id

		FROM
		(
			SELECT
			*
			,case
				when upper(us_tfp_code) like '%TEST%'
					then 1
				when upper(us_tfp_code) like '%ТЕСТ%'
					then 1
				when upper(us_tfp_code) like '%1_BASE_ACCESS%'
					then 1
				when upper(us_tfp_code) like '%TVZ_FIRST%'
					then 1
				when upper(us_tfp_code) like '%TVS_WEB%'
					then 1
				when upper(us_tfp_code) like '%1A_UBASIC_IPTV%'
					then 1
				when upper(us_tfp_code) like '%1F_UBASIC_IPTV%'
					then 1
				when upper(us_tfp_code) like '%1F_UBASIC_IPTVu%'
					then 1
				when upper(us_tfp_code) like '%1V_UBASIC_IPTV%'
					then 1
				when upper(us_tfp_code) like '%BASIC_IPTV%'
					then 1
				when upper(us_tfp_code) like '%TVS_DEMO%'
					then 1
				when upper(us_tfp_code) like '%TVS_TECH%'
					then 1
					else 0
			end as tarif_plan

			FROM
			(
				SELECT
				t1.us_user_name
				, t1.us_tfp_code as us_tfp_code
				, t1.start_date
				, coalesce(t2.start_date - interval '1 second', t1.subs_cancellation_dt) as end_date

				FROM  edw_stg_dds.t_000053_sub_ip2 t1
				LEFT JOIN edw_stg_dds.t_000053_sub_ip2 t2
					ON
					t1.ver = t2.ver-1
					and t1.us_user_name = t2.us_user_name
			)sub_ip3
		)sub_ip4
		LEFT JOIN
		(
			select distinct
			sip_us_user_name
			, date_begin
			, date_end
			, service_id

			from edw_ods.t_000068_tb_start_servs
			where tech_dt between date_trunc('month',to_date('20190601', 'YYYYMMDD')) and to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second'
		) tb_start_servs
			ON
			tb_start_servs.sip_us_user_name = sub_ip4.us_user_name
			and
			(--учитываем разные способы пересечения историй тестовых ТП СТАРТ IP со связью со СТАРТ
			sub_ip4.start_date between tb_start_servs.date_begin and coalesce(tb_start_servs.date_end, to_date('2999-12-31','yyyy-mm-dd'))
			or sub_ip4.end_date between tb_start_servs.date_begin and coalesce(tb_start_servs.date_end, to_date('2999-12-31','yyyy-mm-dd'))
			or tb_start_servs.date_begin between sub_ip4.start_date and sub_ip4.end_date
			)

		where sub_ip4.tarif_plan = 1
	)sub_ip5

	GROUP BY
	service_id
) sub_ip6
	on
	 dim_subs.service_id = sub_ip6.service_id::text;

commit;
analyze edw_stg_dds.t_000053_sub_1;
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
truncate table edw_stg_dds.t_000053_sub_2;

insert into edw_stg_dds.t_000053_sub_2
(
subs_key
, service_id
, start_date
, end_date
, un_start_date
, un_end_date
, del
, change_start
)

SELECT
t1.subs_key
, t1.service_id
, t1.start_date
, t1.end_date
, t1.un_start_date
, t1.un_end_date
,    --Если все предыдущие версии были с отрицательной длительностью и эта версия тоже с отрицательной, то пометить на удаление.
case
	when count(t2.subs_key) = sum	(case
										when t2.un_start_date > t2.un_end_date
											then 1
											else 0
									end
									)
	and t1.un_start_date > t1.un_end_date
		then 1
		else 0
end del
,    --Если все предыдущие версии на удаление, то помечаем на изменение по началу.
case
	when count(t2.subs_key) = sum	(case
										when t2.un_start_date>t2.un_end_date
											then 1
											else 0
									end
									)
      and not
	  (
	  t1.un_start_date=t1.start_date
	  and t1.un_end_date=t1.end_date
	  )
      	then 1
		else 0
end change_start

FROM edw_stg_dds.t_000053_sub_1 t1
LEFT JOIN edw_stg_dds.t_000053_sub_1 t2
	ON
	t1.subs_key = t2.subs_key
	and t1.start_date>t2.end_date

GROUP BY
t1.subs_key
, t1.service_id
, t1.start_date
, t1.end_date
, t1.un_start_date
, t1.un_end_date;

commit;
analyze edw_stg_dds.t_000053_sub_2;
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
truncate table edw_stg_dds.t_000053_sub_4;

insert into edw_stg_dds.t_000053_sub_4
(
subs_key
, service_id
, start_date
, end_date
)

SELECT
subs_key
, service_id
, CASE
	WHEN change_start = 1
		then un_start_date
		else start_date
end as start_date
, CASE
	WHEN change_end = 1
		then un_end_date
		else end_date
end as end_date

from
(--Помечаем версия абонента на удаление и измененин конца версии
	SELECT
	t1.subs_key
	, t1.service_id
	, t1.start_date
	, t1.end_date
	, t1.un_start_date
	, t1.un_end_date
	, t1.change_start
	,    --Если все предыдущие версии были с отрицательной длительностью и эта версия тоже с отрицательной, то пометить на удаление.
	case
		when count(t2.subs_key) = sum	(case
											when t2.un_start_date>t2.un_end_date
												then 1
												else 0
										end
										)
		and t1.un_start_date>t1.un_end_date
			then 1
			else 0+t1.del
	end del
	, --Если все последующие версии на удаление, то помечаем на изменение по концу.
	case
		when count(t2.subs_key) = sum	(case
											when t2.un_start_date>t2.un_end_date
												then 1
												else 0
										end
										)
		and not
		(
		t1.un_start_date=t1.start_date
		and t1.un_end_date=t1.end_date
		)
        	then 1
			else 0
	end change_end

	FROM edw_stg_dds.t_000053_sub_2 t1
	LEFT JOIN edw_stg_dds.t_000053_sub_2 t2
		ON
		t1.subs_key = t2.subs_key
		and t2.start_date>t1.end_date

	GROUP BY
	t1.subs_key
	, t1.service_id
	, t1.start_date
	, t1.end_date
	, t1.un_start_date
	, t1.un_end_date
	, t1.del
	, t1.change_start

)sub3
WHERE del=0;

commit;
analyze edw_stg_dds.t_000053_sub_4;
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
truncate table edw_stg_dds.t_000053_sub_5;

insert into edw_stg_dds.t_000053_sub_5
(
subs_key
, service_id
, start_date
, end_date
, subs_activation_dt
, subs_cancellation_dt
)
--определяем новые даты активации и отключения
SELECT
t1.subs_key
, t1.service_id
, t1.start_date
, to_date(t1.end_date::text, 'YYYY-MM-DD') + interval '1 day - 1 second' as end_date
, t2.subs_activation_dt
, to_date(t2.subs_cancellation_dt::text, 'YYYY-MM-DD') + interval '1 day - 1 second' as subs_cancellation_dt

FROM edw_stg_dds.t_000053_sub_4 t1
inner JOIN
(
	SELECT
	subs_key
	, min(start_date) as subs_activation_dt
	, max(end_date) as subs_cancellation_dt

	FROM edw_stg_dds.t_000053_sub_4

	GROUP BY subs_key
) t2
	ON
	t1.subs_key = t2.subs_key;

commit;
analyze edw_stg_dds.t_000053_sub_5;
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
truncate edw_stg_dds.t_000053_dim_subs_13;

INSERT INTO edw_stg_dds.t_000053_dim_subs_13
(
subs_key
, subs_activation_dt
, subs_cancellation_dt
, address_key
, service_key
, account_key
, subs_code
, src_id
, load_dttm
, start_date
, end_date
, duty_num_key
, center_num_key
, service_id
, serv_first_id
, eff_dttm
, exp_dttm
)
SELECT
dim_subs.subs_key
, sub5.subs_activation_dt as subs_activation_dt
, sub5.subs_cancellation_dt as subs_cancellation_dt
, dim_subs.address_key
, dim_subs.service_key
, dim_subs.account_key
, dim_subs.subs_code
, dim_subs.src_id
, now() as load_dttm
, sub5.start_date as start_date
, sub5.end_date as end_date
, dim_subs.duty_num_key
, dim_subs.center_num_key
, dim_subs.service_id
, dim_subs.serv_first_id
, sub5.start_date as eff_dttm
, sub5.end_date as exp_dttm

FROM  edw_stg_dds.t_000053_dim_subs_12 dim_subs
JOIN edw_stg_dds.t_000053_sub_5 sub5
	ON
	dim_subs.service_id = sub5.service_id;

analyze edw_stg_dds.t_000053_dim_subs_13;
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

truncate table edw_stg_dds.t_000053_dim_subs;

INSERT INTO edw_stg_dds.t_000053_dim_subs
(
subs_key
, subs_activation_dt
, subs_cancellation_dt
, address_key
, service_key
, account_key
, subs_code
, src_id
, load_dttm
, start_date
, end_date
, duty_num_key
, center_num_key
, service_id
, serv_first_id
, eff_dttm
, exp_dttm
)


-------------------------------------------------WITH-------------------------------------------------
WITH sub1 as
(
SELECT
dim_subs.subs_key
, dim_subs.service_id
, dim_subs.start_date
, dim_subs.end_date
, bs.business_service_key as business_service
, coalesce(xref.test_subs, 0) as test_subs

FROM edw_stg_dds.t_000053_dim_subs_13 dim_subs
LEFT JOIN edw_ods.t_000053_t_services t_services
	ON
	dim_subs.service_id = round(t_services.service_id)::text
	and t_services.deleted_ind = 0
LEFT JOIN edw_stg_dds.t_dim_price_plan_xref_start xref
	ON
	round(t_services.id_plan)::text = xref.id_plan
	and to_date('20190601','YYYYMMDD') + INTERVAL '1 MONTH - 1 second' between xref.eff_dttm and xref.exp_dttm
join edw_stg_dds.t_dim_service_xref_start serv_xref
			on serv_xref.source_key = 	dim_subs.service_key
			and to_date('20190601','YYYYMMDD') + INTERVAL '1 MONTH - 1 second' between serv_xref.eff_dttm and serv_xref.exp_dttm
			and serv_xref.region_id = 'CENTER'
		left join edw_dds.dim_service et
				on et.service_key = serv_xref.service_key
				and to_date('20190601','YYYYMMDD') + INTERVAL '1 MONTH - 1 second' between et.eff_dttm and et.exp_dttm
		LEFT JOIN edw_dds.dim_business_service bs ON bs.business_service_key = et.business_service_key
			and to_date('20190601','YYYYMMDD') + INTERVAL '1 MONTH - 1 second' between bs.eff_dttm and bs.exp_dttm
where to_date('20190601','YYYYMMDD') + INTERVAL '1 MONTH - 1 second' +  interval '7' between t_services.eff_dttm and t_services.exp_dttm
) -- sub1

, sub2 as
(--Помечаем версия абонента на удаление и на изменение начала версии
SELECT
t1.subs_key
, t1.service_id
, t1.start_date
, t1.end_date
, t1.test_subs
, t1.business_service
, case
	when count(t2.subs_key) = coalesce(sum(t2.test_subs),0)
	and t1.test_subs = 1
	and t1.business_service = 10101
		then 1
		else 0
end del

FROM sub1 t1
LEFT JOIN sub1 t2
	ON
	t1.subs_key = t2.subs_key
	and t1.start_date>t2.end_date

GROUP BY
t1.subs_key
, t1.service_id
, t1.start_date
, t1.end_date
, t1.test_subs
, t1.business_service
) -- sub2

, sub3 as
(
SELECT
t1.subs_key
, t1.service_id
, t1.start_date
, t1.end_date
, case
	when count(t2.subs_key) = coalesce(sum(t2.test_subs),0)
	and t1.test_subs = 1
	and t1.business_service = 10101
		then 1
		else t1.del
end del

FROM sub2 t1
LEFT JOIN sub2 t2
	ON
	t1.subs_key = t2.subs_key
	and t2.start_date>t1.end_date

GROUP BY
t1.subs_key
, t1.service_id
, t1.start_date
, t1.end_date
, t1.test_subs
, t1.del
, t1.business_service
) -- sub3

, sub4 as
(
SELECT
subs_key
, service_id
, start_date
, end_date

FROM sub3

WHERE del=0
) -- sub4
, sub5 as
(
SELECT
t1.subs_key
, t1.service_id
, t1.start_date as start_date
, TO_DATE(t1.end_date::text, 'YYYY-MM-DD') + interval '1 day - 1 second' end_date
, t2.subs_activation_dt
, to_date(t2.subs_cancellation_dt::text, 'YYYY-MM-DD') + interval '1 day - 1 second' as subs_cancellation_dt

FROM sub4 t1
JOIN
(
	SELECT
	subs_key
	, min(start_date) as subs_activation_dt
	, max(end_date ) as subs_cancellation_dt

	FROM sub4

	GROUP BY
	subs_key
) t2
	ON
	t1.subs_key = t2.subs_key
)
-------------------------------------------------//WITH-------------------------------------------------

SELECT
dim_subs.src_id||'#'||dim_subs.subs_key as subs_key
, sub5.subs_activation_dt as subs_activation_dt
, sub5.subs_cancellation_dt as subs_cancellation_dt
, dim_subs.address_key
, dim_subs.service_key
, dim_subs.account_key
, dim_subs.subs_code
, dim_subs.src_id
, now() as load_dttm
, sub5.start_date as start_date
, sub5.end_date as end_date
, dim_subs.duty_num_key
, dim_subs.center_num_key
, dim_subs.service_id
, dim_subs.serv_first_id
, sub5.start_date as eff_dttm
, sub5.end_date as exp_dttm

FROM edw_stg_dds.t_000053_dim_subs_13 dim_subs
inner JOIN sub5
	ON
	dim_subs.service_id=sub5.service_id;

commit;
ANALYSE edw_stg_dds.t_000053_dim_subs;
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
truncate edw_stg_dds.t_000053_start_ip_subs;

insert into edw_stg_dds.t_000053_start_ip_subs
(
count
, ab_external_code
, business_service
, macro_segment
)


-------------------------------------------------WITH-------------------------------------------------
WITH start_ip_business_service AS
(
select distinct
case
	when upper(uss_sl_type) like '%RADIUS%'
		then 'ШПД в Интернет по проводным технологиям'
	when upper(uss_sl_type) like '%IPTV%'
		then 'IP-TV'
		else '0'
end as business_service
, uss_us_user_name as uss_us_user_name

from
(
	select distinct
	uss_sl_type
	, uss_us_user_name

	from edw_ods.t_000068_ct_user_services
	where to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second'
			between eff_dttm AND exp_dttm
) ct_user_services
) -- start_ip_business_service
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
, abonent AS
(
SELECT abonent.ab_id
, ab_external_code -- ЛС

FROM
(
	select distinct
	ab_id
	, ab_external_code

	from edw_ods.t_000068_abonent
	where to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second'
			between eff_dttm AND exp_dttm
) abonent

UNION

SELECT
abonent_jn.ab_id
, ab_external_code -- ЛС

FROM
(
	select distinct
	ab_id
	, ab_external_code

	from edw_ods.t_000068_abonent_jn
	where tech_dt <=to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second'
)abonent_jn
) -- abonent
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
, ct_users_0 AS
(--собираем версии абонента СТАРТ IP в один список, пока есть только начало каждой версии
SELECT
us_user_name as us_user_name
, us_tfp_code as us_tfp_code
, us_ab_id
, to_date(coalesce(update_date,input_date)::text,'yyyy-mm-dd') as start_date
, coalesce(us_close_date, to_date('2999-12-31','yyyy-mm-dd')) as subs_cancellation_dt
, jn_operation as jn_operation  -- для правильного отображения даты начала, даты окончания действия ТП
, case
	when upper(us_tfp_code) like '%TEST%'
		then 1
	when upper(us_tfp_code) like '%ТЕСТ%'
		then 1
	when upper(us_tfp_code) like '%1_BASE_ACCESS%'
		then 1
	when upper(us_tfp_code) like '%TVZ_FIRST%'
		then 1
	when upper(us_tfp_code) like '%TVS_WEB%'
		then 1
	when upper(us_tfp_code) like '%1A_UBASIC_IPTV%'
		then 1
	when upper(us_tfp_code) like '%1F_UBASIC_IPTV%'
		then 1
	when upper(us_tfp_code) like '%1F_UBASIC_IPTVu%'
		then 1
	when upper(us_tfp_code) like '%1V_UBASIC_IPTV%'
		then 1
	when upper(us_tfp_code) like '%BASIC_IPTV%'
		then 1
	when upper(us_tfp_code) like '%TVS_DEMO%'
		then 1
	when upper(us_tfp_code) like '%TVS_TECH%'
		then 1
		else 0
end as tarif_plan


FROM
(
	select distinct
	us_user_name
	, us_tfp_code
	, update_date
	, us_ab_id
	, input_date
	, us_close_date
	, jn_operation

	from edw_ods.t_000068_ct_users_jn
	where tech_dt <=to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second'
) ct_users_jn

UNION

SELECT
us_user_name as  us_user_name
, us_tfp_code as us_tfp_code
, us_ab_id
, to_date(coalesce(update_date,input_date)::text,'yyyy-mm-dd')  as start_date
, coalesce(us_close_date, to_date('2999-12-31','yyyy-mm-dd')) as subs_cancellation_dt
, 'UPD' as jn_operation  -- для правильного отображения даты начала, даты окончания действия ТП
,case
	when upper(us_tfp_code) like '%TEST%'
		then 1
	when upper(us_tfp_code) like '%ТЕСТ%'
		then 1
	when upper(us_tfp_code) like '%1_BASE_ACCESS%'
		then 1
	when upper(us_tfp_code) like '%TVZ_FIRST%'
		then 1
	when upper(us_tfp_code) like '%TVS_WEB%'
		then 1
	when upper(us_tfp_code) like '%1A_UBASIC_IPTV%'
		then 1
	when upper(us_tfp_code) like '%1F_UBASIC_IPTV%'
		then 1
	when upper(us_tfp_code) like '%1F_UBASIC_IPTVu%'
		then 1
	when upper(us_tfp_code) like '%1V_UBASIC_IPTV%'
		then 1
	when upper(us_tfp_code) like '%BASIC_IPTV%'
		then 1
	when upper(us_tfp_code) like '%TVS_DEMO%'
		then 1
	when upper(us_tfp_code) like '%TVS_TECH%'
		then 1
		else 0
end as tarif_plan

FROM
(
	select distinct
	us_user_name
	, us_tfp_code
	, update_date
	, us_ab_id
	, input_date
	, us_close_date

	from edw_ods.t_000068_ct_users
	where tech_dt between date_trunc('month',to_date('20190601', 'YYYYMMDD')) and to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second'
)ct_users
) -- ct_users_0
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
, ct_users as
(
select
us_user_name
, us_tfp_code
, us_ab_id
, min(to_date(start_date::text,'YYYY-MM-DD')) as start_date
, jn_operation
, max(to_date(subs_cancellation_dt::text,'YYYY-MM-DD')) as subs_cancellation_dt
, ab_external_code
, business_service

from ct_users_0 ct_users
left join abonent abonent
	on
	abonent.ab_id = ct_users.us_ab_id
left join start_ip_business_service ct_user_services
	on
	ct_user_services.uss_us_user_name = ct_users.us_user_name

where tarif_plan=0

GROUP BY
us_user_name
, us_tfp_code
, us_ab_id
, jn_operation
, ab_external_code
, business_service
) -- ct_users
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
, sub_ip2 AS
(
select
ab_external_code
, business_service
, min(start_date) as start_date
, max(subs_cancellation_dt) as subs_cancellation_dt

from ct_users ct_users

where business_service in ('IP-TV', 'ШПД в Интернет по проводным технологиям')

group by
ab_external_code
, business_service
) -- sub_ip2
-------------------------------------------------//WITH-------------------------------------------------



select
count(*)
, ab_external_code
, business_service
, 'B2C' as macro_segment

from sub_ip2 ct_users
join edw_stg_dds.t_000053_dim_account dim_account
	on
	dim_account.account_name = ct_users.ab_external_code
	and to_date(substr('20190630', 1, 8), 'YYYYMMDD')  + interval '1 month' - interval '1 second' between dim_account.eff_dttm and dim_account.exp_dttm
join edw_stg_dds.t_000053_dim_partner dim_partner
	on
	dim_account.partner_key = dim_partner.partner_key
	and dim_account.src_id = dim_partner.src_id
	and to_date(substr('20190630', 1, 8), 'YYYYMMDD')  + interval '1 month' - interval '1 second'  between dim_partner.eff_dttm and dim_partner.exp_dttm
left join edw_dds.hub_dim_segment hub_dim_segment
	on
	hub_dim_segment.source_key = dim_partner.segment_key
	and hub_dim_segment.src_id = dim_partner.src_id
	and to_date(substr('20190630', 1, 8), 'YYYYMMDD') + interval '1 month' - interval '1 second' between hub_dim_segment.eff_dttm and hub_dim_segment.exp_dttm
left join edw_dds.dim_segment dim_segment
	on
	dim_segment.segment_key = hub_dim_segment.segment_key
	and to_date(substr('20190630', 1, 8), 'YYYYMMDD')  + interval '1 month' - interval '1 second' between dim_segment.start_date and dim_segment.end_date
	and to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second'
			between dim_segment.eff_dttm AND dim_segment.exp_dttm
where 1=1
and subs_cancellation_dt > to_date(substr('20190630', 1, 8), 'YYYYMMDD') + interval '1 month' - interval '1 second'
and coalesce(dim_segment.segment_key,1) in ('11000','11004','22000','22402','22400','22401','20500','11004','22406','22407','7161424','9015486') -- 29.01.2020
and dim_account.duty_num_key = '0'
and dim_account.center_num_key = '0'

group by
ab_external_code
, business_service;

analyze edw_stg_dds.t_000053_start_ip_subs;
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
truncate table edw_stg_dds.t_000053_dim_subs_13;
INSERT INTO edw_stg_dds.t_000053_dim_subs_13
(
subs_key
, account_key
, service_key
, duty_num_key
, center_num_key
, address_key
, cpe_key
, port_key
, subs_code
, subs_activation_dt
, subs_cancellation_dt
, start_date
, end_date
, load_dttm
, tech_dt
, src_id
, wf_run_id
, deleted_ind
, mapping_code
, service_id
, serv_first_id
, eff_dttm
, exp_dttm
)


-------------------------------------------------WITH-------------------------------------------------
WITH tb_start1 as
(
SELECT distinct
round(service_id)||'' as service_id
, CASE
	WHEN  to_date(substr('20190630', 1, 8), 'YYYYMMDD')  + interval '1 month' - interval '1 sec' between date_begin and coalesce(date_end, '2999-12-31')
		THEN 3
		ELSE 2
END level

FROM
(
	select distinct
	service_id
	, date_begin
	, date_end

	from edw_ods.t_000068_tb_start_servs
	where tech_dt between date_trunc('month',to_date('20190601', 'YYYYMMDD')) and to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second'
)tb_start_servs
)
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
, tb_start as
(
SELECT
service_id
, max(level) as level

FROM tb_start1

GROUP BY
service_id
)
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
, sub as
(
SELECT
dim_subs.subs_key
, dim_subs.service_id
, dim_account.account_name
, dim_subs.subs_activation_dt
, dim_subs.subs_cancellation_dt
, coalesce(dim_business_service.business_service_key,'-1') as business_service_name
, coalesce(dim_technology_type.technology_type_name, '-1') as technology_type_name

FROM edw_stg_dds.t_000053_dim_subs dim_subs
join edw_stg_dds.t_000053_dim_account dim_account
	on
	dim_subs.account_key = dim_account.account_key
	and dim_subs.src_id = dim_account.src_id
	and  to_date(substr('20190630', 1, 8), 'YYYYMMDD')  + interval '1 month' - interval '1 sec' between dim_account.eff_dttm and dim_account.exp_dttm
join edw_stg_dds.t_000053_dim_partner dim_partner
	on
    dim_account.partner_key = dim_partner.partner_key
	and dim_account.src_id = dim_partner.src_id
	and  to_date(substr('20190630', 1, 8), 'YYYYMMDD')  + interval '1 month' - interval '1 sec' between dim_partner.eff_dttm and dim_partner.exp_dttm
left join edw_dds.hub_dim_service hub_dim_service
	on
	hub_dim_service.source_key = dim_subs.service_key
	and hub_dim_service.src_id = dim_subs.src_id
	and  to_date(substr('20190630', 1, 8), 'YYYYMMDD')   + interval '1 month' - interval '1 sec' between hub_dim_service.eff_dttm and hub_dim_service.exp_dttm
left join edw_dds.dim_service dim_service
	on dim_service.service_key = hub_dim_service.service_key
	and  to_date(substr('20190630', 1, 8), 'YYYYMMDD')   + interval '1 month' - interval '1 sec' between dim_service.start_date and dim_service.end_date
	AND to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second'
			between dim_service.eff_dttm AND dim_service.exp_dttm
left join edw_dds.dim_business_service dim_business_service
	on
	dim_business_service.business_service_key = dim_service.business_service_key
	and  to_date(substr('20190630', 1, 8), 'YYYYMMDD')   + interval '1 month' - interval '1 sec' between dim_business_service.start_date and dim_business_service.end_date
	AND to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second'
			between dim_business_service.eff_dttm AND dim_business_service.exp_dttm
left join edw_dds.dim_technology_type dim_technology_type
	on
	dim_technology_type.technology_type_key = dim_service.technology_type_key
	and  to_date(substr('20190630', 1, 8), 'YYYYMMDD')  + interval '1 month' - interval '1 sec' between dim_technology_type.start_date and dim_technology_type.end_date
	AND to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second'
			between dim_technology_type.eff_dttm AND dim_technology_type.exp_dttm
left join edw_dds.hub_dim_segment hub_dim_segment
	on
	hub_dim_segment.source_key = dim_partner.segment_key
	and hub_dim_segment.src_id = dim_partner.src_id
	and  to_date(substr('20190630', 1, 8), 'YYYYMMDD')   + interval '1 month' - interval '1 day' between hub_dim_segment.eff_dttm and hub_dim_segment.exp_dttm
left join edw_dds.dim_segment dim_segment
	on
	dim_segment.segment_key = hub_dim_segment.segment_key
	and  to_date(substr('20190630', 1, 8), 'YYYYMMDD')  + interval '1 month' - interval '1 sec' between dim_segment.start_date and dim_segment.end_date
	AND to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second'
			between dim_segment.eff_dttm AND dim_segment.exp_dttm
WHERE 1=1
and to_date(substr('20190630', 1, 8), 'YYYYMMDD') + interval '1 month' - interval '1 sec' >= dim_subs.subs_activation_dt
and to_date(substr('20190630', 1, 8), 'YYYYMMDD') + interval '1 month' - interval '1 sec' < dim_subs.subs_cancellation_dt
and to_date(substr('20190630', 1, 8), 'YYYYMMDD') + interval '1 month' - interval '1 sec'>= dim_subs.start_date
and to_date(substr('20190630', 1, 8), 'YYYYMMDD') + interval '1 month' - interval '1 sec'<= dim_subs.end_date
and dim_account.duty_num_key = '0'
and dim_account.center_num_key = '0'
and dim_segment.segment_key = 22401
and dim_business_service.business_service_key in (10202, 10203,10204, 10401, 10402, 10403,10408) -- 29.01.2020
)
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
, t AS
(
SELECT
ss.business_service
, ss.account
, sum(coalesce(ss.count, 0)) as count_start
, sum(coalesce(ips.count, 0)) as count_start_ip
, sum(coalesce(ss.count, 0) - coalesce(ips.count, 0)) as count_rem

FROM
(
	SELECT
	business_service_name as business_service
	, account_name as account
	, count(subs_key) as count

	FROM sub

	GROUP BY
	business_service_name
	, account_name
) as ss
LEFT JOIN edw_stg_dds.t_000053_start_ip_subs ips
	ON
	ss.account = ips.ab_external_code
	and	case
		when ss.business_service::text in ('10202', '10203','10204') -- 29.01.2020
			then 'ШПД в Интернет по проводным технологиям'
		when ss.business_service::text in ('10401', '10402', '10403','10408') -- 29.01.2020
			then 'IP-TV'
		else ss.business_service::text
		end = ips.business_service

WHERE 1=1
and ss.count - coalesce(ips.count, 0)>0

GROUP BY
ss.business_service
, ss.account
)
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
, t1 as
(
SELECT
sub.subs_key
, sub.service_id
, sub.account_name
, sub.subs_activation_dt
, sub.subs_cancellation_dt
, sub.business_service_name as business_service_name
, sub.technology_type_name as technology_type_name
, T.count_rem
, coalesce(tb_start.level, 1) as level
, rank() OVER (PARTITION BY sub.account_name, sub.business_service_name ORDER BY coalesce(tb_start.level, 1), sub.subs_activation_dt, sub.service_id) as rank

FROM sub
JOIN T
	ON
	sub.account_name = T.account
	and sub.business_service_name = T.business_service
LEFT JOIN tb_start
	ON
	sub.service_id = tb_start.service_id
)
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
, t2 as
(
SELECT
subs_key
, 1 as del

FROM t1

WHERE 1=1
and rank <= count_rem
and subs_activation_dt < to_date('20190630','YYYYMMDD')
)
-------------------------------------------------//WITH-------------------------------------------------

select
dim_subs.subs_key
, dim_subs.account_key
, dim_subs.service_key
, dim_subs.duty_num_key
, dim_subs.center_num_key
, dim_subs.address_key
, dim_subs.cpe_key
, dim_subs.port_key
, dim_subs.subs_code
, dim_subs.subs_activation_dt
, case
	when coalesce(del,0) = 0
		then max(end_date) over (partition by dim_subs.subs_key order by coalesce(del,0) asc, end_date desc)
		else dim_subs.subs_cancellation_dt
end as subs_cancellation_dt
, dim_subs.start_date
, dim_subs.end_date
, dim_subs.load_dttm
, dim_subs.tech_dt
, dim_subs.src_id
, dim_subs.wf_run_id
, dim_subs.deleted_ind
, dim_subs.mapping_code
, dim_subs.service_id
, dim_subs.serv_first_id
, dim_subs.eff_dttm
, dim_subs.exp_dttm

from edw_stg_dds.t_000053_dim_subs dim_subs
left join t2 t
	on
	t.subs_key = dim_subs.subs_key --t.service_id = dim_subs.service_id

where 1=1
and coalesce(del,0) = 0;

analyze edw_stg_dds.t_000053_dim_subs_13;
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
truncate edw_stg_dds.t_000053_sub_ip6_test_v2;

set optimizer = on; insert into edw_stg_dds.t_000053_sub_ip6_test_v2
(
ab_external_code
, business_service
, service_id
, start_date
, end_date
, input_date
)

-------------------------------------------------WITH-------------------------------------------------
WITH ct_users_0 AS
(
SELECT
us_user_name as  us_user_name
, us_tfp_code as us_tfp_code
, us_ab_id
, min(start_date) as start_date
, max(end_date) as end_date
, 'UPD' as jn_operation  -- для правильного отображения даты начала, даты окончания действия ТП
, case
	when upper(us_tfp_code) like '%TEST%'
		then 1
	when upper(us_tfp_code) like '%ТЕСТ%'
		then 1
	when upper(us_tfp_code) like '%1_BASE_ACCESS%'
		then 1
	when upper(us_tfp_code) like '%TVZ_FIRST%'
		then 1
	when upper(us_tfp_code) like '%TVS_WEB%'
		then 1
	when upper(us_tfp_code) like '%1A_UBASIC_IPTV%'
		then 1
	when upper(us_tfp_code) like '%1F_UBASIC_IPTV%'
		then 1
	when upper(us_tfp_code) like '%1F_UBASIC_IPTVu%'
		then 1
	when upper(us_tfp_code) like '%1V_UBASIC_IPTV%'
		then 1
	when upper(us_tfp_code) like '%BASIC_IPTV%'
		then 1
	when upper(us_tfp_code) like '%TVS_DEMO%'
		then 1
	when upper(us_tfp_code) like '%TVS_TECH%'
		then 1
		else 0
end as tarif_plan

FROM
(
	select distinct
	us_user_name
	, us_tfp_code
	, us_ab_id
	, us_close_date
	, date_trunc('day',coalesce(update_date, input_date))::timestamp as start_date
	, coalesce(us_close_date, to_date('2999-12-31','yyyy-mm-dd')) as end_date

	from edw_ods.t_000068_ct_users
	where tech_dt between date_trunc('month',to_date('20190601', 'YYYYMMDD')) and to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second'
)ct_users

group by
us_user_name
, us_tfp_code
, us_ab_id

UNION

--собираем версии абонента СТАРТ IP в один список, пока есть только начало каждой версии
SELECT
us_user_name as us_user_name
, us_tfp_code as us_tfp_code
, us_ab_id
, min(start_date) as start_date
, max(end_date) as end_date
, jn_operation as jn_operation  -- для правильного отображения даты начала, даты окончания действия ТП
, case
	when upper(us_tfp_code) like '%TEST%'
		then 1
	when upper(us_tfp_code) like '%ТЕСТ%'
		then 1
	when upper(us_tfp_code) like '%1_BASE_ACCESS%'
		then 1
	when upper(us_tfp_code) like '%TVZ_FIRST%'
		then 1
	when upper(us_tfp_code) like '%TVS_WEB%'
		then 1
	when upper(us_tfp_code) like '%1A_UBASIC_IPTV%'
		then 1
	when upper(us_tfp_code) like '%1F_UBASIC_IPTV%'
		then 1
	when upper(us_tfp_code) like '%1F_UBASIC_IPTVu%'
		then 1
	when upper(us_tfp_code) like '%1V_UBASIC_IPTV%'
		then 1
	when upper(us_tfp_code) like '%BASIC_IPTV%'
		then 1
	when upper(us_tfp_code) like '%TVS_DEMO%'
		then 1
	when upper(us_tfp_code) like '%TVS_TECH%'
		then 1
		else 0
end as tarif_plan

FROM
(
	select distinct
	us_user_name
	, us_tfp_code
	, us_ab_id
	, us_close_date
	, jn_operation
	, date_trunc('day',coalesce(update_date, input_date))::timestamp as start_date
	, coalesce(us_close_date,  to_date('2999-12-31','yyyy-mm-dd')) as end_date

	from edw_ods.t_000068_ct_users_jn
	where tech_dt <=to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second'
)ct_users_jn

group by
us_user_name
, us_tfp_code
, us_ab_id,jn_operation

)
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
, abonent_0 AS
(
SELECT
--'abonent' as t_name,
abonent.ab_id
, ab_external_code -- ЛС
, min(start_date) as start_date
, to_date('2999-12-31','YYYY-MM-DD') as end_date

FROM
(
	select distinct
	ab_id
	, ab_external_code
	, date_trunc('day',coalesce(update_date, input_date))::timestamp as start_date

	from edw_ods.t_000068_abonent
	where to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second'
			between eff_dttm AND exp_dttm
)abonent

group by
ab_id
, ab_external_code

UNION

SELECT
--'abonent_jn' as t_name,
abonent_jn.ab_id
, ab_external_code -- ЛС
, min(start_date) as start_date
, to_date('2999-12-31','YYYY-MM-DD') as end_date

FROM
(
	select distinct
	ab_id
	, ab_external_code
	, date_trunc('day',coalesce(update_date, input_date))::timestamp as start_date

	from edw_ods.t_000068_abonent_jn
	where tech_dt <=to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second'
)abonent_jn

group by
ab_id
, ab_external_code

),
------------------------------------
	tusa_ as 
(
	select 
		usa_uss_logname	
		,usa_sl_type	
		,usa_sat_name	
		,to_timestamp(atr.USA_VALUE::text,'DD.MM.YYYY HH24:MI:SS')::timestamp without time zone USA_VALUE	
		,load_dttm	
		,src_id	
		,package_id	
		,wf_run_id	
		,tech_dt
	from 
		edw_ods.t_000068_tb_user_serv_attrs atr
	where 1 = 1
		and substring(atr.USA_VALUE::text, '[a-zA-Z]') is null -- Нет букв в строке, тогда считаем что это TIMESTAMP
)
------------------------------------
, ct_user_services_0 AS
(
select distinct
case
	when upper(uss_sl_type) like '%RADIUS%'
		then 'ШПД в Интернет по проводным технологиям'
	when upper(uss_sl_type) like '%IPTV%'
		then 'IP-TV'
		else 'Не определено'
end as business_service
, uss_us_user_name as uss_us_user_name
, start_date
, end_date
, usa_value


from
(
	select distinct
	tusa.usa_value
	, bs.uss_us_user_name
	, bs.uss_sl_type
	, date_trunc('day',coalesce(bs.update_date, bs.input_date))::timestamp as start_date
	, to_date('2999-12-31','yyyy-mm-dd') as end_date

	from edw_ods.t_000068_ct_user_services bs
	left join tusa_ tusa
		on
		bs.uss_logname = tusa.usa_uss_logname
		and bs.uss_sl_type = tusa.usa_sl_type
		and tusa.tech_dt <=to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second'
	where to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second'
			between bs.eff_dttm AND bs.exp_dttm
)ct_user_services

union

select distinct
case
	when upper(uss_sl_type) like '%RADIUS%'
		then 'ШПД в Интернет по проводным технологиям'
	when upper(uss_sl_type) like '%IPTV%'
		then 'IP-TV'
		else 'Не определено'
end as business_service
, uss_us_user_name as uss_us_user_name
, start_date
, end_date
, usa_value

from
(
	select distinct
	tusa.usa_value
	, bs.uss_us_user_name
	, bs.uss_sl_type
	, date_trunc('day',coalesce(bs.update_date, bs.input_date,bs.jn_datetime))::timestamp as start_date
	, to_date('2999-12-31','yyyy-mm-dd') as end_date

	from edw_ods.t_000068_ct_user_services_jn bs
	left join tusa_ tusa
		on
		bs.uss_logname = tusa.usa_uss_logname
		and bs.uss_sl_type = tusa.usa_sl_type
		and tusa.tech_dt <=to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second'
	where bs.tech_dt <=to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second'
)ct_user_services
)
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
, TB_SERV_DEFS_0 AS
( --собираем версии абонента СТАРТ IP в один список, пока есть только начало каждой версии
SELECT
TB_SERV_DEFS.srd_code

FROM
(
	select distinct
	srd_code
	, srd_srt_code
	, srd_msr_code
	, srd_no_view_stat

	from edw_ods.t_000068_tb_serv_defs
	where to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second'
			between eff_dttm AND exp_dttm
)tb_serv_defs

where   1=1
and upper(TB_SERV_DEFS.srd_srt_code) = 'FLOW'
-- and upper(TB_SERV_DEFS.srd_msr_code) in ('MB','GB','KB')
and upper(TB_SERV_DEFS.srd_no_view_stat) = 'N'

UNION

SELECT
tb_serv_defs_jn.srd_code

FROM
(
	select distinct
	srd_code
	, srd_srt_code
	, srd_msr_code
	, srd_no_view_stat

	from edw_ods.t_000068_tb_serv_defs_jn
	where tech_dt <=to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second'
)tb_serv_defs_jn

where 1=1
and upper(tb_serv_defs_jn.srd_srt_code) = 'FLOW'
--and upper(tb_serv_defs_jn.srd_msr_code) in ('MB','GB','KB')
and upper(tb_serv_defs_jn.srd_no_view_stat) = 'N'
)
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
, tb_counters_0 AS
(
SELECT
cnt_us_user_name
, CNT_SRD_CODE
, date_trunc('day',min(start_date)) as start_date
, date_trunc('day',max(end_date)) as end_date

FROM
(
	select distinct
	cnt_us_user_name
	, CNT_SRD_CODE
	, coalesce(input_date, update_date,'1900-01-01 00:00:00') as start_date
	, coalesce(cnt_close_date,'2999-12-31 00:00:00') as end_date

	from edw_ods.t_000068_tb_counters tb
	where to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second' between tb.eff_dttm and tb.exp_dttm
)tb_counters

group by
cnt_us_user_name
, CNT_SRD_CODE
)
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
, tb_start_servs_0 AS
(
SELECT
sip_us_user_name
, date_begin
, coalesce(date_end, '2999-12-31 00:00:00') as date_end
, round(service_id) as service_id

FROM
(
	select distinct
	sip_us_user_name
	, date_begin
	, date_end
	, service_id

	from edw_ods.t_000068_tb_start_servs
	where tech_dt between date_trunc('month',to_date('20190601', 'YYYYMMDD')) and to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second'
)tb_start_servs
)
-------------------------------------------------//WITH-------------------------------------------------


select
ab_external_code
, business_service
, tb_start_servs.service_id
, min(ct_users.start_date) as start_date
, max(ct_users.end_date) as end_date
, min(coalesce(start_ip_business_service.usa_value, tb_counters.start_date)) as input_date

from
(
	select
	us_user_name
	, us_tfp_code
	, us_ab_id
	, jn_operation
	, tarif_plan
	, start_date
	, coalesce(max(start_date) over (partition by us_user_name order by start_date, jn_operation rows between 1 following and 1 following)- interval '1 second',end_date,'2999-12-31 00:00:00'::date) end_date

	from
	(
		select
		us_user_name
		, us_tfp_code
		, us_ab_id
		, jn_operation
		, tarif_plan
		, min(start_date) as start_date
		, max(end_date) as end_date

		from ct_users_0

		/*where us_user_name = '348295-1'*/

		group by
		us_user_name
		, us_tfp_code
		, us_ab_id
		, jn_operation
		, tarif_plan
	)ss
)ct_users
left join
(
	select
	ab_id
	, ab_external_code
	, start_date
	, coalesce(max(start_date) over (partition by ab_id order by start_date rows between 1 following and 1 following)- interval '1 second',end_date,'2999-12-31 00:00:00'::date) end_date

	from
	(
		select
		ab_id
		, ab_external_code
		, min(start_date) as start_date
		, max(end_date) as end_date

		from abonent_0

		group by
		ab_id
		, ab_external_code
	)ss
)abonent
	on
	ct_users.us_ab_id = abonent.ab_id
	and ct_users.end_date between abonent.start_date and abonent.end_date
left join
(
	select
	uss_us_user_name
	, business_service
	, usa_value
	, start_date
	, coalesce(max(start_date) over (partition by uss_us_user_name order by start_date rows between 1 following and 1 following)- interval '1 second',end_date,'2999-12-31 00:00:00'::date) end_date

	from
	(
		select
		uss_us_user_name
		, business_service
		, min(start_date) as start_date
		, max(end_date) as end_date
		, min(usa_value) as usa_value

		from ct_user_services_0

		group by
		uss_us_user_name
		, business_service
	)ss

	where 1=1
	and business_service <> 'Не определено'
) start_ip_business_service
	on
	ct_users.us_user_name = start_ip_business_service.uss_us_user_name
	and ct_users.start_date between start_ip_business_service.start_date and start_ip_business_service.end_date
left join
(
	select
	cnt_us_user_name
	, min(start_date) as start_date
	, max(end_date) as end_date

	from tb_counters_0
	join TB_SERV_DEFS_0
		on
		tb_counters_0.CNT_SRD_CODE = TB_SERV_DEFS_0.srd_code

	group by
	cnt_us_user_name

) tb_counters
	on
	tb_counters.cnt_us_user_name = ct_users.us_user_name
left join
(
	select
	sip_us_user_name
	, date_begin
	, date_end
	, service_id

	from tb_start_servs_0

)tb_start_servs
	on
	tb_start_servs.sip_us_user_name = ct_users.us_user_name
	and ct_users.end_date between tb_start_servs.date_begin and tb_start_servs.date_end

where 1=1
and ct_users.start_date < ct_users.end_date
and tarif_plan <> 1

group by
ab_external_code
, business_service
, tb_start_servs.service_id
--, coalesce(start_ip_business_service.usa_value, tb_counters.start_date)
;
analyze edw_stg_dds.t_000053_sub_ip6_test_v2;

------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
truncate table edw_stg_dds.t_000053_dim_subs;

INSERT INTO edw_stg_dds.t_000053_dim_subs
(
subs_key
, subs_activation_dt
, subs_cancellation_dt
, address_key
, service_key
, account_key
, subs_code
, src_id
, load_dttm
, start_date
, end_date
, duty_num_key
, center_num_key
, service_id
, serv_first_id
, eff_dttm
, exp_dttm
)

-------------------------------------------------WITH-------------------------------------------------
with
sub1 as
(--привязываем тестовые версии к абонентам и делаем оценку новых дат действий service_id
SELECT
dim_subs.subs_key
, dim_subs.service_id
, dim_subs.start_date
, dim_subs.end_date

    --Если тестовый ТП попал в середину service_id, то игнорируем его
    --Если тестовый ТП перекрыл начало service_id, то service_id начинаем с конца тестового ТП
    --Если тестовый ТП перекрыл конец service_id, то service_id заканчивыаем с начала тестового ТП
    --Если тестовый ТП перекрыл полностью service_id, то длительнольность service_id будет отрицательной
, case
	when dim_subs.start_date <= coalesce(date_trunc('day', coalesce(t.input_date,sss.input_date)),'1900-01-01')
	and coalesce(t.input_date, sss.input_date,'1900-01-01') > '1900-01-01'
		then to_date(coalesce(t.input_date,sss.input_date)::text,'YYYY-MM-DD')
	when coalesce(date_trunc('day', coalesce(t.input_date,sss.input_date)),'1900-01-01') = '1900-01-01'
	and coalesce(t.business_service,sss.business_service) in ('ШПД в Интернет по проводным технологиям', 'IP-TV')
		then to_date('9999-12-31', 'YYYY-MM-DD')
		else dim_subs.start_date
end un_start_date
, case
	when dim_subs.end_date >= coalesce(date_trunc('day', t.end_date),'1900-01-01')
	and coalesce(t.end_date,'1900-01-01') > '1900-01-01'
		then to_date(date_trunc('day', t.end_date)::text,'YYYY-MM-DD')+ interval '1 day - 1second'
		else dim_subs.end_date
end un_end_date
, t.start_date as t_start_date
, t.end_date as t_end_date

FROM edw_stg_dds.t_000053_dim_subs_13 dim_subs
	join edw_stg_dds.t_dim_service_xref_start xref
			on xref.source_key = dim_subs.service_key
			and xref.sub_make = 1
			and to_date('20190601','YYYYMMDD') + INTERVAL '1 MONTH - 1 second' between xref.eff_dttm and xref.exp_dttm
			and xref.region_id = 'CENTER'
		left join edw_dds.dim_service et
				on et.service_key = xref.service_key
				and to_date('20190601','YYYYMMDD') + INTERVAL '1 MONTH - 1 second' between et.eff_dttm and et.exp_dttm
		LEFT JOIN edw_dds.dim_business_service bs ON bs.business_service_key = et.business_service_key
			and to_date('20190601','YYYYMMDD') + INTERVAL '1 MONTH - 1 second' between bs.eff_dttm and bs.exp_dttm
join edw_ods.t_000053_t_users t_users
	on
	dim_subs.account_key = t_users.src_id||'#'||round(t_users.user_id)
	and t_users.deleted_ind = 0
	and to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second' +  interval '7'
			between t_users.eff_dttm AND t_users.exp_dttm
LEFT JOIN edw_stg_dds.t_000053_sub_ip6_test_v2 t
	ON
	dim_subs.service_id = t.service_id::text
	and t_users.account = t.ab_external_code
	and dim_subs.subs_activation_dt > to_date('20190601','YYYYMMDD')
LEFT JOIN
(
	select
	t.ab_external_code
	, t.business_service
	, min(t.start_date) as start_date
	, max(t.end_date) as end_date
	, min(input_date) as input_date

	from edw_stg_dds.t_000053_sub_ip6_test_v2 t

	where 1=1
	and t.service_id is null
	and business_service is not null

	group by
	t.ab_external_code
	, t.business_service
)sss
	on
	t_users.account = sss.ab_external_code
	and sss.business_service = 	case
									when bs.business_service_key::text in ('10202', '10203','10204') -- 29.01.2020
										then 'ШПД в Интернет по проводным технологиям'
									when bs.business_service_key::text in ('10401', '10402', '10403','10408')  -- 29.01.2020
										then 'IP-TV'
									else bs.business_service_key::text
								end
	and dim_subs.start_date = sss.start_date
	and dim_subs.end_date >= sss.end_date
)
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
, sub2 as
(--Помечаем версия абонента на удаление и на изменение начала версии
SELECT
t1.subs_key
, t1.service_id
, t1.start_date
, t1.end_date
, t1.un_start_date
, t1.un_end_date
, --Если все предыдущие версии были с отрицательной длительностью и эта версия тоже с отрицательной, то пометить на удаление.
case
	when count(t2.subs_key) = sum	(case
										when t2.un_start_date>t2.un_end_date
											then 1 else 0
									end
									)
      and t1.un_start_date>t1.un_end_date
	  	then 1
		else 0
end del
, --Если все предыдущие версии на удаление, то помечаем на изменение по началу.
case
	when count(t2.subs_key) = sum	(case
										when t2.un_start_date>t2.un_end_date
											then 1
											else 0
									end
									)
	and not
	(
	t1.un_start_date=t1.start_date
	and t1.un_end_date=t1.end_date
	)
		then 1
		else 0
end change_start

FROM sub1 t1
LEFT JOIN sub1 t2
	on
	t1.subs_key = t2.subs_key
	and t1.start_date>t2.end_date

GROUP BY
t1.subs_key
, t1.service_id
, t1.start_date
, t1.end_date
, t1.un_start_date
, t1.un_end_date
)
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
, sub3 as
(--Помечаем версия абонента на удаление и измененин конца версии
SELECT
t1.subs_key
, t1.service_id
, t1.start_date
, t1.end_date
, t1.un_start_date
, t1.un_end_date
, t1.change_start
, --Если все предыдущие версии были с отрицательной длительностью и эта версия тоже с отрицательной, то пометить на удаление.
case
	when count(t2.subs_key) = sum	(case
										when t2.un_start_date>t2.un_end_date
											then 1
											else 0
									end
									)
	and t1.un_start_date>t1.un_end_date
		then 1
		else 0+t1.del
end del
, --Если все последующие версии на удаление, то помечаем на изменение по концу.
case
	when count(t2.subs_key) = sum	(case
										when t2.un_start_date>t2.un_end_date
											then 1
											else 0
									end
									)
	and not
	(
	t1.un_start_date=t1.start_date
	and t1.un_end_date=t1.end_date
	)
		then 1
		else 0
end change_end

FROM sub2 t1
LEFT JOIN sub2 t2
	on
	t1.subs_key = t2.subs_key
	and t2.start_date>t1.end_date

GROUP BY
t1.subs_key
, t1.service_id
, t1.start_date
, t1.end_date
, t1.un_start_date
, t1.un_end_date
, t1.del
, t1.change_start
)
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
, sub4 as
(--применяем все изменения истории
SELECT
subs_key
, service_id
, CASE
	WHEN change_start = 1
		then un_start_date
		else start_date
end as start_date
, CASE
	WHEN change_end = 1
		then un_end_date
		else end_date
end as end_date

FROM sub3

WHERE 1=1
and del=0
and start_date < end_date
)
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
, sub5 as
(--определяем новые даты активации и отключения
SELECT
t1.subs_key
, t1.service_id
, t1.start_date
, t1.end_date
, t2.subs_activation_dt
, t2.subs_cancellation_dt

FROM sub4 t1
JOIN
(
	SELECT
	subs_key
	, min(start_date) as subs_activation_dt
	, max(end_date) as subs_cancellation_dt

	FROM sub4

	GROUP BY
	subs_key

) t2
	ON
	t1.subs_key = t2.subs_key
)
-------------------------------------------------WITH-------------------------------------------------

SELECT
dim_subs.subs_key
, sub5.subs_activation_dt as subs_activation_dt
, case
	when to_char(sub5.subs_cancellation_dt, 'YYYY-MM-DD') = '2999-12-31'
		then date_trunc('day',sub5.subs_cancellation_dt::timestamp)
		else sub5.subs_cancellation_dt
END as subs_cancellation_dt
, dim_subs.address_key
, dim_subs.service_key
, dim_subs.account_key
, dim_subs.subs_code
, dim_subs.src_id
, now() as load_dttm
, sub5.start_date as start_date
, case
	when to_char(sub5.end_date, 'YYYY-MM-DD')  = '2999-12-31'
		then date_trunc('day',sub5.end_date::timestamp)
		else sub5.end_date
END as end_date
, dim_subs.duty_num_key
, dim_subs.center_num_key
, dim_subs.service_id
, dim_subs.serv_first_id
, sub5.start_date as eff_dttm
, case
	when to_char(sub5.end_date, 'YYYY-MM-DD')  = '2999-12-31'
		then date_trunc('day',sub5.end_date::timestamp)
		else sub5.end_date
END as exp_dttm

FROM edw_stg_dds.t_000053_dim_subs_13 dim_subs
JOIN sub5
	ON
	dim_subs.service_id = sub5.service_id;
commit;
analyse edw_stg_dds.t_000053_dim_subs;