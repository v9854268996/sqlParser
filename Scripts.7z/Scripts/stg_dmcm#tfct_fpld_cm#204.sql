/*rev. -99 от 31.03.2020*/
truncate table edw_stg_dmcm.tfct_fpld_cm_1_prt_p000204;

insert into edw_stg_dmcm.tfct_fpld_cm_1_prt_p000204(
    evnt_dttm,    
    master_accn_id,
    accn_id,
    mrf_id,
    evnt_name,
    evnt_desc,
    bal_bns_sum,
    txn_type,
    wlt_type_id,
    cur_bal_bns_sum,
    cur_bal_st_sum,
    load_dttm,
    src_id,
    eff_dttm,
    exp_dttm
)
with main as (
select distinct
    ev_his.eventhistoryid,
    ev_his.masteraccountid,
    ev_his.lastupdatetime,
    ev_his.eventname,
    case
        when ev_his.eventname = 'PURCHASE_OTHER_POINTS' then ev_his.description
    end event_description,
    ser_info.personalaccountid,
    rf.mrf_id,
    ev_his.bonus_points,
    ev_his.status_points,
    bal.points bal_bonus_points,
    bal.status_points bal_status_points,
    ev_his.src_id
from
    edw_ods.t_000204_chd_rlx_event_history ev_his
left join edw_ods.t_000204_chd_rlx_service_info ser_info on
    ev_his.masteraccountid = ser_info.masteraccountid
    and to_date('20190630','YYYYMMDD') + INTERVAL '1 day' >= ser_info.startdate
    and to_date('20190630','YYYYMMDD') + INTERVAL '1 day' < coalesce(ser_info.enddate, to_date('29991231', 'YYYYMMDD'))
    and to_date('20190630','YYYYMMDD') + INTERVAL '1 day - 1 second' between ser_info.eff_dttm and ser_info.exp_dttm
left join edw_ods.t_000204_chd_rlx_subs_info sub_info on
    sub_info.masteraccountid = ev_his.masteraccountid
    and to_date('20190630','YYYYMMDD') + INTERVAL '1 day' >= sub_info.startdate
    and to_date('20190630','YYYYMMDD') + INTERVAL '1 day' < coalesce(sub_info.enddate, to_date('29991231', 'YYYYMMDD'))
    and to_date('20190630','YYYYMMDD') + INTERVAL '1 day - 1 second' between sub_info.eff_dttm and sub_info.exp_dttm
left join edw_ods.t_000204_chd_rlx_rf_master rf on
    sub_info.rf = rf.rf_id
    and to_date('20190630','YYYYMMDD') + INTERVAL '1 day - 1 second' between rf.eff_dttm and rf.exp_dttm
left join edw_ods.t_000204_chd_vw_rlx_subs_balance bal on 
    ev_his.masteraccountid=bal.masteraccountid
    and to_date('20190630','YYYYMMDD') + INTERVAL '1 day - 1 second' between bal.eff_dttm and bal.exp_dttm
where
    ev_his.lastupdatetime >= to_date('20190601', 'YYYYMMDD')
    and ev_his.lastupdatetime < to_date('20190630','YYYYMMDD') + INTERVAL '1 day'
    and to_date('20190630','YYYYMMDD') + INTERVAL '1 day - 1 second' between ev_his.eff_dttm and ev_his.exp_dttm) ,
main2 as (
    select distinct main.masteraccountid,
    main.lastupdatetime,
    main.personalaccountid,
    eff.account,
    case
        when eff.account is null
        and acc.account is null then 1
        when eff.account is not null
        and acc.account is not null then 1
        when min(eff.account) over(partition by main.personalaccountid) is null then 1
        else 0
    end takes
from
    main
left join edw_ods.t_000158_efftp_south_nls_accnt acc on
    main.personalaccountid = acc.nls
left join edw_ods.t_000154_efftp_oo_eff_tp eff on
    eff.p2_mrf_id = 14
    and acc.account = eff.account
    and acc.rf_id = eff.p3_rf_id
    and eff.p1_period = to_char(lastupdatetime-interval '1 months', 'YYYYMM')::numeric
where
    main.mrf_id = '2023') 
select
    event_date,    
    master_accn_id,
    accn_id,
    mrf_id,
    evnt_name,
    evnt_desc,
    bal_bns_sum,
    case
        when bal_bns_sum>0 then 'Начисление'
        else 'Списание'
    end txn_type,
    wlt_type_id,
    cur_bal_bns_sum,
    cur_bal_st_sum,
    current_timestamp load_dttm,
    src_id,
    to_date('20190601', 'YYYYMMDD')  as eff_dttm,
    to_date('20190630', 'YYYYMMDD') + INTERVAL'1 day - 1 second' as exp_dttm
from
    (select
    main.lastupdatetime event_date,    
    main.masteraccountid master_accn_id,
    case
        when main.mrf_id = '2023' then main2.account
        else main.personalaccountid
    end accn_id,
    main.mrf_id,
    maps.evnt_desc_cval evnt_name,
    main.event_description evnt_desc,
    unnest(array[main.bonus_points, main.status_points]) bal_bns_sum,
    unnest(array['Bonus', 'Status']) wlt_type_id,
    main.bal_bonus_points cur_bal_bns_sum,
    main.bal_status_points cur_bal_st_sum,
    main.src_id
from
    main
left join main2 on
    main.masteraccountid = main2.masteraccountid
    and main.personalaccountid = main2.personalaccountid
    and main.lastupdatetime = main2.lastupdatetime
    and main2.takes = 1
left join edw_dds.dim_supl_event_cm maps on 
    main.eventname=maps.evnt_name_cval
    and to_date('20190630','YYYYMMDD') + INTERVAL '1 day - 1 second' between maps.start_dttm and maps.end_dttm)  itog;
    
analyze edw_stg_dmcm.tfct_fpld_cm_1_prt_p000204;
