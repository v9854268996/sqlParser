--rev. 55847 от 23.04.2020 Changed by: MARIYA.PARAMEEVA

truncate edw_stg_dds.t_000059_tfct_telephony_consumption;

insert into edw_stg_dds.t_000059_tfct_telephony_consumption
(
	telephony_consumption_key
	, call_start_dttm
	, billing_id
	, subs_key
	, account_key
	, service_key
	, call_dur_actually_nval
	, call_dur_paid_nval
	, call_dur_rounded_nval
	, src_id
	, num_a
	, num_b
	, rc_key
	, mobile_flg
	, is_vims
)
with 
	t_apus as
(
	select 
		id_connect,
		round(billing_id)::varchar as billing_id,
		to_date(round(billing_id)::varchar,'YYYYMMDD') + INTERVAL '1 MONTH - 1 second' billing_date,
		user_id,
		dlit,
		tarif_dlit,
		phonea,
		phoneb,
		src_id,
		trunc(plan_id) plan_id,
		round(plan_id)::varchar plan_id_,
		service_id::varchar as service_id,
		talkdate
		--tech_dt
	from 
		edw_ods.t_000059_t_apus
	where 1 = 1
		and billing_id between substr('20190601', 1, 6)::int and substr('20190630', 1, 6)::int
	    and tech_dt between to_date(substr('20190601', 1, 8), 'YYYYMMDD') and to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second'
),
	ap as
(
	select
		trunc(ap.svc_id) as svc_id
		, trunc(ap.id_plan) as id_plan
		, xref.sub_make
		,case
			when bs.parent_business_service_key =  10100
				then 10101
				else bs.business_service_key
			end as business_service_key
		, xref.rcode_asr
	from 
		(
		select 
			* 
		from 
			edw_ods.t_000059_t_apus_plan
		where 1 = 1 
			and deleted_ind = 0
			and to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second' between eff_dttm and exp_dttm
		) ap
		left join edw_stg_dds.t_dim_service_xref_start xref
			on 1 = 1
			and xref.source_key = ap.svc_id::varchar
			and to_date(substr('20190601', 1, 8), 'YYYYMMDD') + INTERVAL '1 MONTH - 1 second' between xref.eff_dttm and xref.exp_dttm
			and xref.region_id = 'CENTER'
		left join edw_dds.dim_service et
			on 1 = 1
			and et.service_key = xref.service_key
			and to_date(substr('20190601', 1, 8), 'YYYYMMDD') + INTERVAL '1 MONTH - 1 second' between et.eff_dttm and et.exp_dttm
		LEFT JOIN edw_dds.dim_business_service bs 
			ON 1 = 1
			and bs.business_service_key = et.business_service_key
			and to_date(substr('20190601', 1, 8), 'YYYYMMDD') + INTERVAL '1 MONTH - 1 second' between bs.eff_dttm and bs.exp_dttm
),
	dim_subs as 
(
	select
		subs.serv_first_id
		, subs.subs_key
		, subs.start_date
		, subs.end_date
		, subs.account_key
	from  
		edw_stg_dds.t_000059_dim_subs subs
),
	dim_subs1 as
(
	select 
		*
	from 
		(
		select 
			distinct
			subs.serv_first_id
			, subs.subs_key
			, row_number() over (order by subs.serv_first_id desc, subs.end_date desc, subs.subs_key desc) as numm
		from  
			edw_stg_dds.t_000059_dim_subs subs
		)t
	where 1 = 1
		and numm = 1
),
	dim_subs2 as
(
	select 
		distinct
		subs.subs_key
		, bs.business_service_key as business_service_key
		, subs.start_date
		, subs.end_date
		, subs.account_key
		, t_services.dev_id::varchar as dev_id
	from 
		edw_stg_dds.t_000059_dim_subs subs
	join 
		edw_stg_dds.t_dim_service_xref_start xref
			on 1 = 1 
			and xref.source_key = subs.service_key
			and to_date(substr('20190601', 1, 8), 'YYYYMMDD') + INTERVAL '1 MONTH - 1 second' between xref.eff_dttm and xref.exp_dttm
			and xref.region_id = 'CENTER'
		join edw_dds.dim_service et
			on 1 = 1
			and et.service_key = xref.service_key
			and to_date(substr('20190601', 1, 8), 'YYYYMMDD') + INTERVAL '1 MONTH - 1 second' between et.eff_dttm and et.exp_dttm
		JOIN edw_dds.dim_business_service bs 
			ON 1 = 1
			and bs.business_service_key = et.business_service_key
			and to_date(substr('20190601', 1, 8), 'YYYYMMDD') + INTERVAL '1 MONTH - 1 second' between bs.eff_dttm and bs.exp_dttm
		inner join edw_ods.t_000059_t_services t_services
			on 1 = 1
			and round(t_services.service_id)::varchar = subs.service_id
			and to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second'  + interval '7 day'  between t_services.eff_dttm and t_services.exp_dttm
),
	t_apus_main as
(
	select
		'1'||'#'||round(t_apus.id_connect) as telephony_consumption_key
		, t_apus.talkdate as call_start_dttm                   -- Дата и время начала звонка
		, to_date(t_apus.billing_id,'YYYYMMDD') as billing_id               -- Биллинговый период
		, coalesce(dim_subs.subs_key ,dim_subs2.subs_key ,dim_subs1.subs_key) as subs_key                      -- Идентификатор Абонента
		, round(t_apus.user_id) as account_key                        -- Идентификатор лицевого счета
		, round(ap.svc_id) as service_key
		, t_apus.dlit as call_dur_actually_nval         -- Фактическая длительность звонка логическая
		, t_apus.tarif_dlit as call_dur_paid_nval -- Фактическая протарифицированная длительность звонка логическая
		, t_apus.dlit as call_dur_rounded_nval          -- Округленная Фактическая протарифицированная длительность звонка логическая
		, t_apus.src_id as src_id
		, t_apus.phonea as num_a  --Номер А
		, t_apus.phoneb as num_b  --Номер Б
		, dim_segment.segment_name||'#'||ap.rcode_asr as rc_key
		, case when t_apus.phoneb  like '79%' or  t_apus.phoneb like '89%' then 'Y' else 'N' end as mobile_flg
		, null is_vims
		, row_number() over (partition by t_apus.id_connect order by case when t_apus.src_id||'#'||round(t_apus.user_id) = dim_subs.account_key then 1 else 99 end) as key1
	from 
		t_apus
		join ap
			on 1 = 1
			and t_apus.plan_id = ap.id_plan
	join edw_stg_dds.t_dim_price_plan_xref_start  t_apus_plan_xref
		on 1 = 1
		and t_apus.plan_id_ = t_apus_plan_xref.id_plan
		and t_apus_plan_xref.test_telephony = 0	
	JOIN edw_stg_dds.t_000059_dim_account dim_account
		on 1 = 1
		and t_apus.src_id||'#'||trunc(t_apus.user_id) = dim_account.account_key
		and t_apus.src_id = dim_account.src_id
		and t_apus.billing_date between dim_account.eff_dttm and dim_account.exp_dttm
	JOIN edw_stg_dds.t_000059_dim_partner dim_partner
		on 1 = 1
		and dim_account.partner_key = dim_partner.partner_key
		and dim_account.src_id = dim_partner.src_id
		and t_apus.billing_date between dim_partner.eff_dttm and dim_partner.exp_dttm
	left join edw_dds.hub_dim_segment hub_dim_segment
		on 1 = 1
		and hub_dim_segment.source_key = dim_partner.segment_key
		and hub_dim_segment.src_id = dim_partner.src_id
		and t_apus.billing_date between hub_dim_segment.eff_dttm and hub_dim_segment.exp_dttm
	left join edw_dds.dim_segment dim_segment
		on 1 = 1 
		and dim_segment.segment_key = hub_dim_segment.segment_key
		and dim_segment.deleted_ind=0
		and t_apus.billing_date between dim_segment.eff_dttm and dim_segment.exp_dttm
	left join dim_subs
		on 1 = 1
		and dim_subs.serv_first_id = t_apus.service_id
		and t_apus.talkdate between dim_subs.start_date and dim_subs.end_date
	left join dim_subs1
		on 1 = 1
		and dim_subs1.serv_first_id = t_apus.service_id
	left join dim_subs2
		on 1 = 1
		and t_apus.src_id||'#'||round(t_apus.user_id) = dim_subs2.account_key
		and ap.business_service_key = dim_subs2.business_service_key
		and t_apus.talkdate between dim_subs2.start_date and dim_subs2.end_date
		and dim_subs2.dev_id = t_apus.phonea
)
select
	telephony_consumption_key,
	call_start_dttm,
	billing_id,
	subs_key,
	(src_id||'#'||account_key) as account_key,
	service_key,
	call_dur_actually_nval,
	call_dur_paid_nval,
	call_dur_rounded_nval,
	src_id,
	num_a,
	num_b,
	rc_key,
	mobile_flg,
	is_vims
from
	t_apus_main
WHERE 
	key1 = 1
;

--------------------------------------------------------------------------

insert into edw_stg_dds.t_000059_tfct_telephony_consumption
	(
	telephony_consumption_key
	, call_start_dttm
	, billing_id
	, subs_key
	, account_key
	, service_key
	, call_dur_actually_nval
	, call_dur_paid_nval
	, call_dur_rounded_nval
	, src_id
	, num_a
	, num_b
	, rc_key
	, mobile_flg
	, is_vims
	)
with 
	t_mts_sig as 
(
	select 
		mtr_id,
		talkdate,
		to_date(billing_id::varchar,'YYYYMMDD') as billing_id,
		avt,
		real_dlit,
		codetown,
		phonefrom,
		phoneto,
		src_id
	from 
		edw_ods.t_000059_t_mts_sig
	where 1 = 1  
		and trunc(billing_id) between substr('20190601', 1, 6)::int and substr('20190630', 1, 6)::int
	    and tech_dt between to_date(substr('20190601', 1, 8), 'YYYYMMDD') and to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second'
),
	t_mts_res as 
(
	select 
		user_id,
		dlit,
		src_id,
		MTR_ID,
		MTS_ZONE_ID,
		to_date(billing_id::varchar,'YYYYMMDD') + INTERVAL '1 MONTH - 1 second' as billing_data,
		service_id::varchar as service_id,
		src_id||'#'||user_id account_key
	from 
		edw_ods.t_000059_t_mts_res 
	where 1 = 1 
		and coalesce(real_vndr_id,1) in (1,195039493,496417573,485899633,538867560,1,2,453179910,544753179,550566590,722731353)
),
	dim_subs as
(
	select
		subs.serv_first_id
		, subs.subs_key
		, subs.start_date
		, subs.end_date
		, subs.account_key
	from 
		edw_stg_dds.t_000059_dim_subs subs
),
	dim_subs1 as 
(
	select 
		*
	from
		(
		select
			subs.serv_first_id
			, subs.subs_key
			, row_number() over (order by subs.serv_first_id desc, subs.end_date desc, subs.subs_key desc) as numm
		from 
			edw_stg_dds.t_000059_dim_subs subs
		)t
	where 1 = 1
		and numm = 1
),
	dim_subs2 as 
(
	select 
		distinct
		subs.subs_key
		, bs.business_service_key as business_service_key
		, subs.start_date
		, subs.end_date
		, subs.account_key
		, t_services.dev_id::varchar as dev_id_
	from 
		edw_stg_dds.t_000059_dim_subs subs
		join edw_stg_dds.t_dim_service_xref_start xref
			on 1 = 1
			and xref.source_key = subs.service_key
			and to_date(substr('20190601', 1, 8), 'YYYYMMDD') + INTERVAL '1 MONTH - 1 second' between xref.eff_dttm and xref.exp_dttm
			and xref.region_id = 'CENTER'
		left join edw_dds.dim_service et
			on 1 = 1
			and et.service_key = xref.service_key
			and to_date(substr('20190601', 1, 8), 'YYYYMMDD') + INTERVAL '1 MONTH - 1 second' between et.eff_dttm and et.exp_dttm
		LEFT JOIN edw_dds.dim_business_service bs 
			ON 1 = 1 
			and bs.business_service_key = et.business_service_key
			and to_date(substr('20190601', 1, 8), 'YYYYMMDD') + INTERVAL '1 MONTH - 1 second' between bs.eff_dttm and bs.exp_dttm
		inner join edw_ods.t_000059_t_services t_services
			on 1 = 1 
			and t_services.service_id::varchar = subs.service_id
			and to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second' + interval '7 day' between t_services.eff_dttm and t_services.exp_dttm
),
	t_mts_zone as
(
	select 
		* 
	from 
		edw_ods.t_000059_t_mts_zone t_mts_zone
	where 1 = 1
		and deleted_ind = 0
		and to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second' between eff_dttm and exp_dttm
),
	xref as 
(
	select 
		*
	from 
		edw_stg_dds.t_dim_service_xref_start
	where 1 = 1
		and to_date(substr('20190601', 1, 8), 'YYYYMMDD') + INTERVAL '1 MONTH - 1 second' between eff_dttm and exp_dttm
		and region_id = 'CENTER'  	   
),
	et as 
(
	select 
		*
	from 
		edw_dds.dim_service et
	where 1 = 1
		and to_date(substr('20190601', 1, 8), 'YYYYMMDD') + INTERVAL '1 MONTH - 1 second' between eff_dttm and exp_dttm
),
	bs as 
(
	select 
		case
			when parent_business_service_key = 10100
			then 10101
			else business_service_key
		end business_service_key_,
		s.*
	from
		edw_dds.dim_business_service s
	where 1 = 1
		and to_date(substr('20190601', 1, 8), 'YYYYMMDD') + INTERVAL '1 MONTH - 1 second' between s.eff_dttm and s.exp_dttm
),
	t_mts_sig_main as 
(
	select
		'2#'||t_mts_sig.mtr_id as telephony_consumption_key -- Идентификатор потребления услуг телефонии
		, t_mts_sig.talkdate as call_start_dttm                -- Дата и время начала звонка
		, t_mts_sig.billing_id                         -- Биллинговый период
		, coalesce(dim_subs.subs_key ,dim_subs2.subs_key ,dim_subs1.subs_key) as subs_key
		, t_mts_res.user_id as account_key                     -- Идентификатор лицевого счета
		, case 	when t_mts_sig.avt='Y'
			then t_mts_zone.A_SVC_ID
			else t_mts_zone.Z_SVC_ID
		end as service_key                                          -- Идентификатор услуги
		,(t_mts_sig.real_dlit * 60) as call_dur_actually_nval       -- Фактическая длительность звонка логическая
		, case when t_mts_sig.codetown like '800%' 			then 0 else	t_mts_res.dlit * 60 end  as call_dur_paid_nval
		, (t_mts_res.dlit * 60) as call_dur_rounded_nval             -- Округленная Фактическая протарифицированная длительность звонка логическая
		, t_mts_res.src_id
		, t_mts_sig.phonefrom as num_a --Номер А
		, t_mts_sig.codetown||t_mts_sig.phoneto as num_b --Номер Б
		, dim_segment.segment_name||'#'||xref.rcode_asr as rc_key
		, case when t_mts_zone.is_mobile = 'Y'  or  t_mts_sig.codetown||t_mts_sig.phoneto like '79%' or  t_mts_sig.codetown||t_mts_sig.phoneto like '89%' then 'Y' else 'N' end as mobile_flg
		, null is_vims
		, row_number() over (partition by t_mts_sig.mtr_id order by case when t_mts_res.src_id||'#'||t_mts_res.user_id = dim_subs.account_key  then 1 else 99 end) as key1
	from 
		t_mts_sig
		inner join t_mts_res
			on 1 = 1 
			and t_mts_sig.MTR_ID = t_mts_res.MTR_ID
		JOIN edw_stg_dds.t_000059_dim_account dim_account
			on 1 = 1
			and t_mts_res.account_key = dim_account.account_key
			and t_mts_res.src_id = dim_account.src_id
			and t_mts_res.billing_data between dim_account.eff_dttm and dim_account.exp_dttm
		JOIN edw_stg_dds.t_000059_dim_partner dim_partner
			on 1 = 1
			and dim_account.partner_key = dim_partner.partner_key
			and dim_account.src_id = dim_partner.src_id
			and t_mts_res.billing_data between dim_partner.eff_dttm and dim_partner.exp_dttm
		left join t_mts_zone
			on 1 = 1
			and t_mts_zone.MTS_ZONE_ID = t_mts_res.MTS_ZONE_ID
		join xref
			on 1 = 1
			and xref.source_key = (case when t_mts_sig.avt='y' then t_mts_zone.a_svc_id else t_mts_zone.z_svc_id end)::varchar
		left join et
			on 1 = 1
			and et.service_key = xref.service_key
		LEFT JOIN bs 
			ON 1 = 1
			and bs.business_service_key = et.business_service_key
		LEFT JOIN edw_dds.hub_dim_segment hub_dim_segment
			on 1 = 1
			and hub_dim_segment.source_key = dim_partner.segment_key
			and hub_dim_segment.src_id = dim_partner.src_id
			and t_mts_res.billing_data between hub_dim_segment.eff_dttm and hub_dim_segment.exp_dttm
		LEFT JOIN edw_dds.dim_segment dim_segment
			on 1 = 1
			and dim_segment.segment_key = hub_dim_segment.segment_key
			and dim_segment.deleted_ind=0
			and t_mts_res.billing_data between dim_segment.eff_dttm and dim_segment.exp_dttm
		left join dim_subs
			on 1 = 1
			and dim_subs.serv_first_id = t_mts_res.service_id
			and t_mts_sig.talkdate between dim_subs.start_date and dim_subs.end_date
		left join dim_subs1
			on 1 = 1
			and dim_subs1.serv_first_id = t_mts_res.service_id
		left join dim_subs2
			on 1 = 1
			and t_mts_res.account_key = dim_subs2.account_key
			and bs.business_service_key_ = dim_subs2.business_service_key
			and t_mts_sig.talkdate between dim_subs2.start_date and dim_subs2.end_date
			and dim_subs2.dev_id_ = t_mts_sig.phonefrom
)
--select 't_mts_sig' CTE_name,count(1)QNTY from	t_mts_sig union all
--select 't_mts_res' CTE_name,count(1)QNTY from	t_mts_res union all
--select 'dim_subs'  CTE_name,count(1)QNTY from	dim_subs  union all
--select 'dim_subs1' CTE_name,count(1)QNTY from	dim_subs1 union all
--select 'dim_subs2' CTE_name,count(1)QNTY from	dim_subs2
--select count(1)QNTY from t_mts_sig_main
select
	telephony_consumption_key
	, call_start_dttm
	, billing_id
	, subs_key
	, src_id||'#'||account_key as account_key
	, service_key
	, call_dur_actually_nval
	, call_dur_paid_nval
	, call_dur_rounded_nval
	, src_id
	, num_a
	, num_b
	, rc_key
	, mobile_flg
	, is_vims
from
	t_mts_sig_main
WHERE  
	key1 = 1
;

analyze edw_stg_dds.t_000059_tfct_telephony_consumption;
