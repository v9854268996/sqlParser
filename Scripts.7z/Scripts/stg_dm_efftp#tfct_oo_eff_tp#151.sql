/*rev. 29457*/
set optimizer = on;

--step 00 delete from table edw_stg_dm_efftp.tfct_oo_eff_tp;
--delete from edw_stg_dm_efftp.tfct_oo_eff_tp
--where p1_period = to_number(to_char(date_trunc('month', to_date('20190601', 'YYYYMMDD')), 'YYYYMM'), '999999')
truncate table edw_stg_dm_efftp.tfct_oo_eff_tp_1_prt_p000151;
;

-- step 0 initial fill table edw_stg_dm_efftp.tfct_oo_eff_tp SERV_ID = 0
-- + CRM_ID
INSERT INTO edw_stg_dm_efftp.tfct_oo_eff_tp_1_prt_p000151
(subs_id,
abn_id,
clie_id,
contr_status,
date_bill,
dt_contr,
date_start,
date_close,
is_ota,
serv_id,
soo_src_id,
rtpl_name,
start_rtpl,
end_rtpl,
speed,
tech_id,
change_tech_flag,
jr_type,
data_activ_prev,
ocn_sum,
dop_sum,
period_prev,
gv_dt_start_rp,
gv_dt_end_rp,
migr_prev_tp,
migr_next_tp,
rtpl_act_duration,
rtpl_act_cost,
rtpl_act_rest,
login,
rtpl_start_date,
rtpl_end_date,
is_arenda_subs,
use_in_calc,
p1_period,
p2_mrf_id,
p3_rf_id,
p4_city,
p5_pack,
p6_rtpl_ota,
p7_rtpl_shpd,
p8_rtpl_iptv,
p9_ym_conn_ota,
p10_ym_conn_shpd,
p11_ym_conn_iptv,
p12_ym_conn_rtpl,
p13_tech,
p13_tech_name,
p14_delr_id_ota,
p15_delr_name_ota,
p16_delr_id_iptv,
p17_delr_name_iptv,
p18_delr_id_shpd,
p19_delr_name_shpd,
p20_subs_active,
p21_type_rtpl,
p22_speed_shpd,
p22_speed_shpd_name,
p23_qnt_str_rp_shpd,
p24_qnt_end_rp_shpd,
p25_qnt_str_activ_shpd,
p26_qnt_end_activ_shpd,
p27_qnt_conn1_shpd,
p28_qnt_conn2_shpd,
p29_ottok_shpd,
p30_migr_tp_shpd,
p31_migr_tp_shpd,
p32_traf_in_shpd,
p33_amount_all_shpd,
p33_amount_wo_act,
p34_amount_dop_shpd,
p35_amount_others_shpd,
p36_amount_sale_shpd,
p37_amount_rent_shpd,
p38_qnt_str_rp_activ,
p39_qnt_end_rp_activ,
p40_qnt_conn1,
p41_qnt_conn2,
p42_ottok,
p43_migr1_tp,
p44_migr2_tp,
p45_ms_traf_volume,
p46_ms_traf_volume,
p47_ms_traf_volume,
p48_ms_traf_volume,
p49_zone_isx,
p50_mg_aco,
p51_mg_aco_any_sps,
p52_mn_aco_volume,
p53_mn_zco_volume,
p54_ms_traf_amount1,
p55_ms_traf_amount2,
p56_vz_traf_amount,
p57_mg_traf_amount,
p58_mn_traf_amount,
p59_other_amount,
p60_other_sale_amount,
p61_rent_amount,
p62_qnt_str_activ_iptv,
p63_qnt_end_activ_iptv,
p64_qnt_conn1_iptv,
p65_qnt_conn2_iptv,
p66_ottok_iptv,
p67_migr1_tp_iptv,
p68_migr2_tp_iptv,
p69_traf_in_iptv,
p70_amount_base_iptv,
p71_amount_dop_iptv,
p72_incomes_iptv,
p73_amount_sale_iptv,
p74_amount_rent_iptv,
p75_amount_others_iptv,
p76_ocn_pack,
p77_dop_pack,
p80_qnt_str_rp_ota,
p81_qnt_end_rp_ota,
p82_qnt_str_rp_iptv,
p83_qnt_end_rp_iptv,
p84_qnt_str_union,
p85_qnt_end_union,
p86_sale_channel,
addr_hash,
p5_pack_prev,
account,
p4_town_id,
addr_hash_prev,
p87_wc_conn_ota,
p88_wc_conn_shpd,
p89_wc_conn_iptv,
presence_ota,
p9_ym_conn_ota_wc,
p10_ym_conn_shpd_wc,
p11_ym_conn_iptv_wc,
charge_only_flag,
p90_tv_pack_by_qty_begin,
p91_tv_pack_by_qty_end,
new_abns,
churn_abns,
tech_id_old_migr,
abn_id_old_migr,
wc_date_create,
wc_date_start,
p76_ocn_pack_end,
p77_dop_pack_end,
p90_ocn_pack_begin,
p91_dop_pack_begin,
wc_only_flag,
daily_abns,
charge_type,
hlid,
hgid,
clid,
tier_id,
hflat,
pdz_block,
vol_block,
churn_abn_pdz,
churn_mom,
churn_mom_in_churn,
churn_mom_react,
debt,
pdz,
balance,
customer_id,
dt,
move_rf,
p92_inst_ota,
p92_inst_shpd,
p92_inst_iptv,
mvno_exist,
region_id,
macro_segment,
rtpl_gr_id,
--load_dttm,
src_id,
pay_ind
--eff_dttm,
--exp_dttm
)

with ugcrmuid as
(
select nls.account,
lv2.customer_id,
lv0.mrf_id,
--lv1.serv_id,
lv1.period
from edw_ods.t_000158_efftp_south_nls_accnt nls

join edw_ods.t_000159_client_dwh lv0
on 1 = 1
and lv0.user_id = to_number(nls.account, '9999999999999999999999999')
and lv0.account = nls.nls

join
(SELECT t.account_id,
t.mrf_id,
t.account_original,
--case
--when t.SERVICES_IND = '1' then 0
--when t.OTA_IND      = '1' then 1
--when t.BB_IND       = '1' then 2
--when t.IPTV_IND     = '1' then 3
--else null
--end as serv_id,
to_number(to_char(date_trunc('month', t.dt), 'YYYYMM'), '999999') as period
FROM
edw_ods.t_000159_rti_case_agg_client t
WHERE 1 = 1
and t.mrf_id = 14
and date_trunc('month', t.dt) = date_trunc('month', to_date('20190601', 'YYYYMMDD'))
and t.tech_dt  >= date_trunc('month', to_date('20190601', 'YYYYMMDD'))::timestamp
and t.tech_dt  <= (date_trunc('month', to_date('20190601', 'YYYYMMDD')) + interval '1 month - 1 second')::timestamp
--and (case
--when t.SERVICES_IND = '1' then 0
--when t.OTA_IND      = '1' then 1
--when t.BB_IND       = '1' then 2
--when t.IPTV_IND     = '1' then 3
--else null
--end) is not null
group by t.account_id,
t.mrf_id,
t.account_original,
--case
--when t.SERVICES_IND = '1' then 0
--when t.OTA_IND      = '1' then 1
--when t.BB_IND       = '1' then 2
--when t.IPTV_IND     = '1' then 3
--else null
--end,
to_number(to_char(date_trunc('month', t.dt), 'YYYYMM'), '999999')
) as lv1
on 1 = 1
and lv0.account = lv1.account_original

and 1 = case
          when to_date('20190601', 'YYYYMMDD') >= to_date('2018.09.01','YYYY.MM.DD') then 1 
          when to_date('20190601', 'YYYYMMDD') <  to_date('2018.09.01','YYYY.MM.DD')
           and trim(substr( trim(to_char(lv1.account_id, '999999999999999999999')), 7, 15)) = nls.account then 1
          else 0
        end

join edw_ods.t_000159_cs_transfer_uc_info lv2
on 1 = 1
and lv1.account_id = lv2.account_id
and lv1.period = to_number(to_char(date_trunc('month', lv2.dt), 'YYYYMM'), '999999')

where 1 = 1
and lv0.mrf_id = 14
and lv0.period = to_number(to_char(date_trunc('month', to_date('20190601', 'YYYYMMDD')), 'YYYYMM'), '999999')
and lv2.mrf_id = 14
and date_trunc('month', lv2.dt) = date_trunc('month', to_date('20190601', 'YYYYMMDD'))
and lv2.tech_dt  >= date_trunc('month', to_date('20190601', 'YYYYMMDD'))::timestamp
and lv2.tech_dt  <= (date_trunc('month', to_date('20190601', 'YYYYMMDD')) + interval '1 month - 1 second')::timestamp

group by nls.account,
lv2.customer_id,
lv0.mrf_id,
--lv1.serv_id,
lv1.period
)
select
tp.SUBS_ID,
tp.ABN_ID,
tp.CLIE_ID,
tp.CONTR_STATUS,
tp.DATE_BILL,
tp.DT_CONTR,
tp.DATE_START,
tp.DATE_CLOSE,
tp.IS_OTA,
tp.SERV_ID,
tp.SOO_SRC_ID,
tp.RTPL_NAME,
tp.START_RTPL,
tp.END_RTPL,
tp.SPEED,
tp.TECH_ID,
tp.CHANGE_TECH_FLAG,
tp.JR_TYPE,
tp.DATA_ACTIV_PREV,
tp.OCN_SUM,
tp.DOP_SUM,
tp.PERIOD_PREV,
tp.GV_DT_START_RP,
tp.GV_DT_END_RP,
tp.MIGR_PREV_TP,
tp.MIGR_NEXT_TP,
tp.RTPL_ACT_DURATION,
tp.RTPL_ACT_COST,
tp.RTPL_ACT_REST,
tp.LOGIN,
tp.RTPL_START_DATE,
tp.RTPL_END_DATE,
tp.IS_ARENDA_SUBS,
tp.USE_IN_CALC,
tp.P1_PERIOD,
tp.P2_MRF_ID,
tp.P3_RF_ID,
tp.P4_CITY,
tp.P5_PACK,
tp.P6_RTPL_OTA,
tp.P7_RTPL_SHPD,
tp.P8_RTPL_IPTV,
tp.P9_YM_CONN_OTA,
tp.P10_YM_CONN_SHPD,
tp.P11_YM_CONN_IPTV,
tp.P12_YM_CONN_RTPL,
tp.P13_TECH,
tp.P13_TECH_NAME,
tp.P14_DELR_ID_OTA,
tp.P15_DELR_NAME_OTA,
tp.P16_DELR_ID_IPTV,
tp.P17_DELR_NAME_IPTV,
tp.P18_DELR_ID_SHPD,
tp.P19_DELR_NAME_SHPD,
tp.P20_SUBS_ACTIVE,
tp.P21_TYPE_RTPL,
tp.P22_SPEED_SHPD,
tp.P22_SPEED_SHPD_NAME,
tp.P23_QNT_STR_RP_SHPD,
tp.P24_QNT_END_RP_SHPD,
tp.P25_QNT_STR_ACTIV_SHPD,
tp.P26_QNT_END_ACTIV_SHPD,
tp.P27_QNT_CONN1_SHPD,
tp.P28_QNT_CONN2_SHPD,
tp.P29_OTTOK_SHPD,
tp.P30_MIGR_TP_SHPD,
tp.P31_MIGR_TP_SHPD,
0.0 as P32_TRAF_IN_SHPD,
tp.P33_AMOUNT_ALL_SHPD,
tp.P33_AMOUNT_WO_ACT,
tp.P34_AMOUNT_DOP_SHPD,
tp.P35_AMOUNT_OTHERS_SHPD,
tp.P36_AMOUNT_SALE_SHPD,
tp.P37_AMOUNT_RENT_SHPD,
tp.P38_QNT_STR_RP_ACTIV,
tp.P39_QNT_END_RP_ACTIV,
tp.P40_QNT_CONN1,
tp.P41_QNT_CONN2,
tp.P42_OTTOK,
tp.P43_MIGR1_TP,
tp.P44_MIGR2_TP,
tp.P45_MS_TRAF_VOLUME,
tp.P46_MS_TRAF_VOLUME,
tp.P47_MS_TRAF_VOLUME,
tp.P48_MS_TRAF_VOLUME,
tp.P49_ZONE_ISX,
tp.P50_MG_ACO,
tp.P51_MG_ACO_ANY_SPS,
tp.P52_MN_ACO_VOLUME,
tp.P53_MN_ZCO_VOLUME,
tp.P54_MS_TRAF_AMOUNT1,
tp.P55_MS_TRAF_AMOUNT2,
tp.P56_VZ_TRAF_AMOUNT,
tp.P57_MG_TRAF_AMOUNT,
tp.P58_MN_TRAF_AMOUNT,
tp.P59_OTHER_AMOUNT,
tp.P60_OTHER_SALE_AMOUNT,
tp.P61_RENT_AMOUNT,
tp.P62_QNT_STR_ACTIV_IPTV,
tp.P63_QNT_END_ACTIV_IPTV,
tp.P64_QNT_CONN1_IPTV,
tp.P65_QNT_CONN2_IPTV,
tp.P66_OTTOK_IPTV,
tp.P67_MIGR1_TP_IPTV,
tp.P68_MIGR2_TP_IPTV,
0.0 as P69_TRAF_IN_IPTV,
tp.P70_AMOUNT_BASE_IPTV,
tp.P71_AMOUNT_DOP_IPTV,
tp.P72_INCOMES_IPTV,
tp.P73_AMOUNT_SALE_IPTV,
tp.P74_AMOUNT_RENT_IPTV,
tp.P75_AMOUNT_OTHERS_IPTV,
tp.P76_OCN_PACK,
tp.P77_DOP_PACK,
tp.P80_QNT_STR_RP_OTA,
tp.P81_QNT_END_RP_OTA,
tp.P82_QNT_STR_RP_IPTV,
tp.P83_QNT_END_RP_IPTV,
tp.P84_QNT_STR_UNION,
tp.P85_QNT_END_UNION,
tp.P86_SALE_CHANNEL,
tp.ADDR_HASH,
tp.P5_PACK_PREV,
tp.ACCOUNT,
tp.P4_TOWN_ID,
tp.ADDR_HASH_PREV,
tp.P87_WC_CONN_OTA,
tp.P88_WC_CONN_SHPD,
tp.P89_WC_CONN_IPTV,
tp.PRESENCE_OTA,
tp.P9_YM_CONN_OTA_WC,
tp.P10_YM_CONN_SHPD_WC,
tp.P11_YM_CONN_IPTV_WC,
tp.CHARGE_ONLY_FLAG,
tp.P90_TV_PACK_BY_QTY_BEGIN,
tp.P91_TV_PACK_BY_QTY_END,
tp.NEW_ABNS,
tp.CHURN_ABNS,
tp.TECH_ID_OLD_MIGR,
tp.ABN_ID_OLD_MIGR,
tp.WC_DATE_CREATE,
tp.WC_DATE_START,
tp.P76_OCN_PACK_END,
tp.P77_DOP_PACK_END,
tp.P90_OCN_PACK_BEGIN,
tp.P91_DOP_PACK_BEGIN,
tp.WC_ONLY_FLAG,
tp.DAILY_ABNS,
tp.CHARGE_TYPE,
tp.HLID,
tp.HGID,
tp.CLID,
tp.TIER_ID,
tp.HFLAT,
0 as PDZ_BLOCK,
0 as VOL_BLOCK,
0 as CHURN_ABN_PDZ,
0 as CHURN_MOM,
0 as CHURN_MOM_IN_CHURN,
0 as CHURN_MOM_REACT,
0.0 as DEBT,
0.0 as PDZ,
0.0 as BALANCE,
coalesce(to_char(lv0.customer_id, '9999999999999999999'), to_char(u.customer_id, '9999999999999999999'), tp.ACCOUNT) as customer_id,
date_trunc('month', to_date('20190601', 'YYYYMMDD')) as dt,
0 as move_rf,
tp.P92_INST_OTA,
tp.P92_INST_SHPD,
tp.P92_INST_IPTV,
tp.MVNO_EXIST,
tp.REGION_ID,
tp.MACRO_SEGMENT,
tp.RTPL_GR_ID,
--null as load_dttm,
tp.src_id as src_id,
-1 as pay_ind
--null as dttm,
--null as exp_dttm
from edw_ods.t_000151_efftp_oo_eff_tp tp

left join edw_ods.t_000159_cs_transfer_uc_info lv0
on 1 = 1
and lv0.account_id = to_number(tp.account, '9999999999999999999999999')
AND lv0.mrf_id = tp.p2_mrf_id
AND lv0.branch_key = tp.p3_rf_id
AND tp.p2_mrf_id <> 14
and lv0.mrf_id <> 14
and date_trunc('month', lv0.dt) = date_trunc('month', to_date('20190601', 'YYYYMMDD'))
and lv0.tech_dt  >= date_trunc('month', to_date('20190601', 'YYYYMMDD'))::timestamp
and lv0.tech_dt  <= (date_trunc('month', to_date('20190601', 'YYYYMMDD')) + interval '1 month - 1 second')::timestamp

left join ugcrmuid u
on 1 = 1
and tp.account = u.account
and tp.p1_period = u.period
--and tp.serv_id = u.serv_id
and tp.p2_mrf_id = 14

where tp.P1_PERIOD = to_number(to_char(date_trunc('month', to_date('20190601', 'YYYYMMDD')), 'YYYYMM'), '999999')
  and tp.tech_dt  >= date_trunc('month', to_date('20190601', 'YYYYMMDD'))::timestamp
  and tp.tech_dt  <= (date_trunc('month', to_date('20190601', 'YYYYMMDD')) + interval '1 month - 1 second')::timestamp
  and tp.serv_id = 0
;

-- step 0 initial fill table edw_stg_dm_efftp.tfct_oo_eff_tp SERV_ID <> 0
-- + CRM_ID
INSERT INTO edw_stg_dm_efftp.tfct_oo_eff_tp_1_prt_p000151
(subs_id,
abn_id,
clie_id,
contr_status,
date_bill,
dt_contr,
date_start,
date_close,
is_ota,
serv_id,
soo_src_id,
rtpl_name,
start_rtpl,
end_rtpl,
speed,
tech_id,
change_tech_flag,
jr_type,
data_activ_prev,
ocn_sum,
dop_sum,
period_prev,
gv_dt_start_rp,
gv_dt_end_rp,
migr_prev_tp,
migr_next_tp,
rtpl_act_duration,
rtpl_act_cost,
rtpl_act_rest,
login,
rtpl_start_date,
rtpl_end_date,
is_arenda_subs,
use_in_calc,
p1_period,
p2_mrf_id,
p3_rf_id,
p4_city,
p5_pack,
p6_rtpl_ota,
p7_rtpl_shpd,
p8_rtpl_iptv,
p9_ym_conn_ota,
p10_ym_conn_shpd,
p11_ym_conn_iptv,
p12_ym_conn_rtpl,
p13_tech,
p13_tech_name,
p14_delr_id_ota,
p15_delr_name_ota,
p16_delr_id_iptv,
p17_delr_name_iptv,
p18_delr_id_shpd,
p19_delr_name_shpd,
p20_subs_active,
p21_type_rtpl,
p22_speed_shpd,
p22_speed_shpd_name,
p23_qnt_str_rp_shpd,
p24_qnt_end_rp_shpd,
p25_qnt_str_activ_shpd,
p26_qnt_end_activ_shpd,
p27_qnt_conn1_shpd,
p28_qnt_conn2_shpd,
p29_ottok_shpd,
p30_migr_tp_shpd,
p31_migr_tp_shpd,
p32_traf_in_shpd,
p33_amount_all_shpd,
p33_amount_wo_act,
p34_amount_dop_shpd,
p35_amount_others_shpd,
p36_amount_sale_shpd,
p37_amount_rent_shpd,
p38_qnt_str_rp_activ,
p39_qnt_end_rp_activ,
p40_qnt_conn1,
p41_qnt_conn2,
p42_ottok,
p43_migr1_tp,
p44_migr2_tp,
p45_ms_traf_volume,
p46_ms_traf_volume,
p47_ms_traf_volume,
p48_ms_traf_volume,
p49_zone_isx,
p50_mg_aco,
p51_mg_aco_any_sps,
p52_mn_aco_volume,
p53_mn_zco_volume,
p54_ms_traf_amount1,
p55_ms_traf_amount2,
p56_vz_traf_amount,
p57_mg_traf_amount,
p58_mn_traf_amount,
p59_other_amount,
p60_other_sale_amount,
p61_rent_amount,
p62_qnt_str_activ_iptv,
p63_qnt_end_activ_iptv,
p64_qnt_conn1_iptv,
p65_qnt_conn2_iptv,
p66_ottok_iptv,
p67_migr1_tp_iptv,
p68_migr2_tp_iptv,
p69_traf_in_iptv,
p70_amount_base_iptv,
p71_amount_dop_iptv,
p72_incomes_iptv,
p73_amount_sale_iptv,
p74_amount_rent_iptv,
p75_amount_others_iptv,
p76_ocn_pack,
p77_dop_pack,
p80_qnt_str_rp_ota,
p81_qnt_end_rp_ota,
p82_qnt_str_rp_iptv,
p83_qnt_end_rp_iptv,
p84_qnt_str_union,
p85_qnt_end_union,
p86_sale_channel,
addr_hash,
p5_pack_prev,
account,
p4_town_id,
addr_hash_prev,
p87_wc_conn_ota,
p88_wc_conn_shpd,
p89_wc_conn_iptv,
presence_ota,
p9_ym_conn_ota_wc,
p10_ym_conn_shpd_wc,
p11_ym_conn_iptv_wc,
charge_only_flag,
p90_tv_pack_by_qty_begin,
p91_tv_pack_by_qty_end,
new_abns,
churn_abns,
tech_id_old_migr,
abn_id_old_migr,
wc_date_create,
wc_date_start,
p76_ocn_pack_end,
p77_dop_pack_end,
p90_ocn_pack_begin,
p91_dop_pack_begin,
wc_only_flag,
daily_abns,
charge_type,
hlid,
hgid,
clid,
tier_id,
hflat,
pdz_block,
vol_block,
churn_abn_pdz,
churn_mom,
churn_mom_in_churn,
churn_mom_react,
debt,
pdz,
balance,
customer_id,
dt,
move_rf,
p92_inst_ota,
p92_inst_shpd,
p92_inst_iptv,
mvno_exist,
region_id,
macro_segment,
rtpl_gr_id,
--load_dttm,
src_id,
pay_ind
--eff_dttm,
--exp_dttm
)

with ugcrmuid as
(
select nls.account,
lv2.customer_id,
lv0.mrf_id,
--lv1.serv_id,
lv1.period
from edw_ods.t_000158_efftp_south_nls_accnt nls

join edw_ods.t_000159_client_dwh lv0
on 1 = 1
and lv0.user_id = to_number(nls.account, '9999999999999999999999999')
and lv0.account = nls.nls

join
(SELECT t.account_id,
t.mrf_id,
t.account_original,
--case
--when t.SERVICES_IND = '1' then 0
--when t.OTA_IND      = '1' then 1
--when t.BB_IND       = '1' then 2
--when t.IPTV_IND     = '1' then 3
--else null
--end as serv_id,
to_number(to_char(date_trunc('month', t.dt), 'YYYYMM'), '999999') as period
FROM
edw_ods.t_000159_rti_case_agg_client t
WHERE 1 = 1
and t.mrf_id = 14
and date_trunc('month', t.dt) = date_trunc('month', to_date('20190601', 'YYYYMMDD'))
and t.tech_dt  >= date_trunc('month', to_date('20190601', 'YYYYMMDD'))::timestamp
and t.tech_dt  <= (date_trunc('month', to_date('20190601', 'YYYYMMDD')) + interval '1 month - 1 second')::timestamp
--and (case
--when t.SERVICES_IND = '1' then 0
--when t.OTA_IND      = '1' then 1
--when t.BB_IND       = '1' then 2
--when t.IPTV_IND     = '1' then 3
--else null
--end) is not null
group by t.account_id,
t.mrf_id,
t.account_original,
--case
--when t.SERVICES_IND = '1' then 0
--when t.OTA_IND      = '1' then 1
--when t.BB_IND       = '1' then 2
--when t.IPTV_IND     = '1' then 3
--else null
--end,
to_number(to_char(date_trunc('month', t.dt), 'YYYYMM'), '999999')
) as lv1
on 1 = 1
and lv0.account = lv1.account_original

and 1 = case
          when to_date('20190601', 'YYYYMMDD') >= to_date('2018.09.01','YYYY.MM.DD') then 1 
          when to_date('20190601', 'YYYYMMDD') <  to_date('2018.09.01','YYYY.MM.DD')
           and trim(substr( trim(to_char(lv1.account_id, '999999999999999999999')), 7, 15)) = nls.account then 1
          else 0
        end

join edw_ods.t_000159_cs_transfer_uc_info lv2
on 1 = 1
and lv1.account_id = lv2.account_id
and lv1.period = to_number(to_char(date_trunc('month', lv2.dt), 'YYYYMM'), '999999')

where 1 = 1
and lv0.mrf_id = 14
and lv0.period = to_number(to_char(date_trunc('month', to_date('20190601', 'YYYYMMDD')), 'YYYYMM'), '999999')
and lv2.mrf_id = 14
and date_trunc('month', lv2.dt) = date_trunc('month', to_date('20190601', 'YYYYMMDD'))
and lv2.tech_dt  >= date_trunc('month', to_date('20190601', 'YYYYMMDD'))::timestamp
and lv2.tech_dt  <= (date_trunc('month', to_date('20190601', 'YYYYMMDD')) + interval '1 month - 1 second')::timestamp

group by nls.account,
lv2.customer_id,
lv0.mrf_id,
--lv1.serv_id,
lv1.period
)
select 
subs_id,
abn_id,
clie_id,
contr_status,
date_bill,
dt_contr,
date_start,
date_close,
is_ota,
serv_id,
soo_src_id,
rtpl_name,
start_rtpl,
end_rtpl,
speed,
tech_id,
change_tech_flag,
jr_type,
data_activ_prev,
ocn_sum,
dop_sum,
period_prev,
gv_dt_start_rp,
gv_dt_end_rp,
migr_prev_tp,
migr_next_tp,
rtpl_act_duration,
rtpl_act_cost,
rtpl_act_rest,
login,
rtpl_start_date,
rtpl_end_date,
is_arenda_subs,
use_in_calc,
p1_period,
p2_mrf_id,
p3_rf_id,
p4_city,
p5_pack,
p6_rtpl_ota,
p7_rtpl_shpd,
p8_rtpl_iptv,
p9_ym_conn_ota,
p10_ym_conn_shpd,
p11_ym_conn_iptv,
p12_ym_conn_rtpl,
p13_tech,
p13_tech_name,
p14_delr_id_ota,
p15_delr_name_ota,
p16_delr_id_iptv,
p17_delr_name_iptv,
p18_delr_id_shpd,
p19_delr_name_shpd,
p20_subs_active,
p21_type_rtpl,
p22_speed_shpd,
p22_speed_shpd_name,
p23_qnt_str_rp_shpd,
p24_qnt_end_rp_shpd,
p25_qnt_str_activ_shpd,
p26_qnt_end_activ_shpd,
p27_qnt_conn1_shpd,
p28_qnt_conn2_shpd,
p29_ottok_shpd,
p30_migr_tp_shpd,
p31_migr_tp_shpd,
p32_traf_in_shpd,
p33_amount_all_shpd,
p33_amount_wo_act,
p34_amount_dop_shpd,
p35_amount_others_shpd,
p36_amount_sale_shpd,
p37_amount_rent_shpd,
p38_qnt_str_rp_activ,
p39_qnt_end_rp_activ,
p40_qnt_conn1,
p41_qnt_conn2,
p42_ottok,
p43_migr1_tp,
p44_migr2_tp,
p45_ms_traf_volume,
p46_ms_traf_volume,
p47_ms_traf_volume,
p48_ms_traf_volume,
p49_zone_isx,
p50_mg_aco,
p51_mg_aco_any_sps,
p52_mn_aco_volume,
p53_mn_zco_volume,
p54_ms_traf_amount1,
p55_ms_traf_amount2,
p56_vz_traf_amount,
p57_mg_traf_amount,
p58_mn_traf_amount,
p59_other_amount,
p60_other_sale_amount,
p61_rent_amount,
p62_qnt_str_activ_iptv,
p63_qnt_end_activ_iptv,
p64_qnt_conn1_iptv,
p65_qnt_conn2_iptv,
p66_ottok_iptv,
p67_migr1_tp_iptv,
p68_migr2_tp_iptv,
p69_traf_in_iptv,
p70_amount_base_iptv,
p71_amount_dop_iptv,
p72_incomes_iptv,
p73_amount_sale_iptv,
p74_amount_rent_iptv,
p75_amount_others_iptv,
p76_ocn_pack,
p77_dop_pack,
p80_qnt_str_rp_ota,
p81_qnt_end_rp_ota,
p82_qnt_str_rp_iptv,
p83_qnt_end_rp_iptv,
p84_qnt_str_union,
p85_qnt_end_union,
p86_sale_channel,
addr_hash,
p5_pack_prev,
account,
p4_town_id,
addr_hash_prev,
p87_wc_conn_ota,
p88_wc_conn_shpd,
p89_wc_conn_iptv,
presence_ota,
p9_ym_conn_ota_wc,
p10_ym_conn_shpd_wc,
p11_ym_conn_iptv_wc,
charge_only_flag,
p90_tv_pack_by_qty_begin,
p91_tv_pack_by_qty_end,
new_abns,
churn_abns,
tech_id_old_migr,
abn_id_old_migr,
wc_date_create,
wc_date_start,
p76_ocn_pack_end,
p77_dop_pack_end,
p90_ocn_pack_begin,
p91_dop_pack_begin,
wc_only_flag,
daily_abns,
charge_type,
hlid,
hgid,
clid,
tier_id,
hflat,
pdz_block,
vol_block,
churn_abn_pdz,
churn_mom,
churn_mom_in_churn,
churn_mom_react,
debt,
pdz,
balance,
customer_id,
dt,
move_rf,
p92_inst_ota,
p92_inst_shpd,
p92_inst_iptv,
mvno_exist,
region_id,
macro_segment,
rtpl_gr_id,
--load_dttm,
src_id,
pay_ind
--eff_dttm,
--exp_dttm
from (
select
tp.SUBS_ID,
tp.ABN_ID,
tp.CLIE_ID,
tp.CONTR_STATUS,
tp.DATE_BILL,
tp.DT_CONTR,
tp.DATE_START,
tp.DATE_CLOSE,
tp.IS_OTA,
tp.SERV_ID,
tp.SOO_SRC_ID,
tp.RTPL_NAME,
tp.START_RTPL,
tp.END_RTPL,
tp.SPEED,
tp.TECH_ID,
tp.CHANGE_TECH_FLAG,
tp.JR_TYPE,
tp.DATA_ACTIV_PREV,
tp.OCN_SUM,
tp.DOP_SUM,
tp.PERIOD_PREV,
tp.GV_DT_START_RP,
tp.GV_DT_END_RP,
tp.MIGR_PREV_TP,
tp.MIGR_NEXT_TP,
tp.RTPL_ACT_DURATION,
tp.RTPL_ACT_COST,
tp.RTPL_ACT_REST,
tp.LOGIN,
tp.RTPL_START_DATE,
tp.RTPL_END_DATE,
tp.IS_ARENDA_SUBS,
tp.USE_IN_CALC,
tp.P1_PERIOD,
tp.P2_MRF_ID,
tp.P3_RF_ID,
tp.P4_CITY,
tp.P5_PACK,
tp.P6_RTPL_OTA,
tp.P7_RTPL_SHPD,
tp.P8_RTPL_IPTV,
tp.P9_YM_CONN_OTA,
tp.P10_YM_CONN_SHPD,
tp.P11_YM_CONN_IPTV,
tp.P12_YM_CONN_RTPL,
tp.P13_TECH,
tp.P13_TECH_NAME,
tp.P14_DELR_ID_OTA,
tp.P15_DELR_NAME_OTA,
tp.P16_DELR_ID_IPTV,
tp.P17_DELR_NAME_IPTV,
tp.P18_DELR_ID_SHPD,
tp.P19_DELR_NAME_SHPD,
tp.P20_SUBS_ACTIVE,
tp.P21_TYPE_RTPL,
tp.P22_SPEED_SHPD,
tp.P22_SPEED_SHPD_NAME,
tp.P23_QNT_STR_RP_SHPD,
tp.P24_QNT_END_RP_SHPD,
tp.P25_QNT_STR_ACTIV_SHPD,
tp.P26_QNT_END_ACTIV_SHPD,
tp.P27_QNT_CONN1_SHPD,
tp.P28_QNT_CONN2_SHPD,
tp.P29_OTTOK_SHPD,
tp.P30_MIGR_TP_SHPD,
tp.P31_MIGR_TP_SHPD,
0.0 as P32_TRAF_IN_SHPD,
tp.P33_AMOUNT_ALL_SHPD,
tp.P33_AMOUNT_WO_ACT,
tp.P34_AMOUNT_DOP_SHPD,
tp.P35_AMOUNT_OTHERS_SHPD,
tp.P36_AMOUNT_SALE_SHPD,
tp.P37_AMOUNT_RENT_SHPD,
tp.P38_QNT_STR_RP_ACTIV,
tp.P39_QNT_END_RP_ACTIV,
tp.P40_QNT_CONN1,
tp.P41_QNT_CONN2,
tp.P42_OTTOK,
tp.P43_MIGR1_TP,
tp.P44_MIGR2_TP,
tp.P45_MS_TRAF_VOLUME,
tp.P46_MS_TRAF_VOLUME,
tp.P47_MS_TRAF_VOLUME,
tp.P48_MS_TRAF_VOLUME,
tp.P49_ZONE_ISX,
tp.P50_MG_ACO,
tp.P51_MG_ACO_ANY_SPS,
tp.P52_MN_ACO_VOLUME,
tp.P53_MN_ZCO_VOLUME,
tp.P54_MS_TRAF_AMOUNT1,
tp.P55_MS_TRAF_AMOUNT2,
tp.P56_VZ_TRAF_AMOUNT,
tp.P57_MG_TRAF_AMOUNT,
tp.P58_MN_TRAF_AMOUNT,
tp.P59_OTHER_AMOUNT,
tp.P60_OTHER_SALE_AMOUNT,
tp.P61_RENT_AMOUNT,
tp.P62_QNT_STR_ACTIV_IPTV,
tp.P63_QNT_END_ACTIV_IPTV,
tp.P64_QNT_CONN1_IPTV,
tp.P65_QNT_CONN2_IPTV,
tp.P66_OTTOK_IPTV,
tp.P67_MIGR1_TP_IPTV,
tp.P68_MIGR2_TP_IPTV,
0.0 as P69_TRAF_IN_IPTV,
tp.P70_AMOUNT_BASE_IPTV,
tp.P71_AMOUNT_DOP_IPTV,
tp.P72_INCOMES_IPTV,
tp.P73_AMOUNT_SALE_IPTV,
tp.P74_AMOUNT_RENT_IPTV,
tp.P75_AMOUNT_OTHERS_IPTV,
tp.P76_OCN_PACK,
tp.P77_DOP_PACK,
tp.P80_QNT_STR_RP_OTA,
tp.P81_QNT_END_RP_OTA,
tp.P82_QNT_STR_RP_IPTV,
tp.P83_QNT_END_RP_IPTV,
tp.P84_QNT_STR_UNION,
tp.P85_QNT_END_UNION,
tp.P86_SALE_CHANNEL,
tp.ADDR_HASH,
tp.P5_PACK_PREV,
tp.ACCOUNT,
tp.P4_TOWN_ID,
tp.ADDR_HASH_PREV,
tp.P87_WC_CONN_OTA,
tp.P88_WC_CONN_SHPD,
tp.P89_WC_CONN_IPTV,
tp.PRESENCE_OTA,
tp.P9_YM_CONN_OTA_WC,
tp.P10_YM_CONN_SHPD_WC,
tp.P11_YM_CONN_IPTV_WC,
tp.CHARGE_ONLY_FLAG,
tp.P90_TV_PACK_BY_QTY_BEGIN,
tp.P91_TV_PACK_BY_QTY_END,
tp.NEW_ABNS,
tp.CHURN_ABNS,
tp.TECH_ID_OLD_MIGR,
tp.ABN_ID_OLD_MIGR,
tp.WC_DATE_CREATE,
tp.WC_DATE_START,
tp.P76_OCN_PACK_END,
tp.P77_DOP_PACK_END,
tp.P90_OCN_PACK_BEGIN,
tp.P91_DOP_PACK_BEGIN,
tp.WC_ONLY_FLAG,
tp.DAILY_ABNS,
tp.CHARGE_TYPE,
tp.HLID,
tp.HGID,
tp.CLID,
tp.TIER_ID,
tp.HFLAT,
0 as PDZ_BLOCK,
0 as VOL_BLOCK,
0 as CHURN_ABN_PDZ,
0 as CHURN_MOM,
0 as CHURN_MOM_IN_CHURN,
0 as CHURN_MOM_REACT,
0.0 as DEBT,
0.0 as PDZ,
0.0 as BALANCE,
coalesce(to_char(lv0.customer_id, '9999999999999999999'), to_char(u.customer_id, '9999999999999999999'), tp.ACCOUNT) as customer_id,
date_trunc('month', to_date('20190601', 'YYYYMMDD')) as dt,
0 as move_rf,
tp.P92_INST_OTA,
tp.P92_INST_SHPD,
tp.P92_INST_IPTV,
tp.MVNO_EXIST,
tp.REGION_ID,
tp.MACRO_SEGMENT,
tp.RTPL_GR_ID,
--null as load_dttm,
tp.src_id as src_id,
-1 as pay_ind,
--null as dttm,
--null as exp_dttm
row_number() over(partition by tp.ABN_ID, tp.P1_PERIOD
                   order by case when coalesce(tp.p24_qnt_end_rp_shpd,0)+coalesce(tp.p81_qnt_end_rp_ota,0)+coalesce(tp.p83_qnt_end_rp_iptv,0) > 0 then 0 else 1 end) rn
from edw_ods.t_000151_efftp_oo_eff_tp tp

left join edw_ods.t_000159_cs_transfer_uc_info lv0
on 1 = 1
and lv0.account_id = to_number(tp.account, '9999999999999999999999999')
AND lv0.mrf_id = tp.p2_mrf_id
AND lv0.branch_key = tp.p3_rf_id
AND tp.p2_mrf_id <> 14
and lv0.mrf_id <> 14
and date_trunc('month', lv0.dt) = date_trunc('month', to_date('20190601', 'YYYYMMDD'))
and lv0.tech_dt  >= date_trunc('month', to_date('20190601', 'YYYYMMDD'))::timestamp
and lv0.tech_dt  <= (date_trunc('month', to_date('20190601', 'YYYYMMDD')) + interval '1 month - 1 second')::timestamp

left join ugcrmuid u
on 1 = 1
and tp.account = u.account
and tp.p1_period = u.period
--and tp.serv_id = u.serv_id
and tp.p2_mrf_id = 14

where tp.P1_PERIOD = to_number(to_char(date_trunc('month', to_date('20190601', 'YYYYMMDD')), 'YYYYMM'), '999999')
  and tp.tech_dt  >= date_trunc('month', to_date('20190601', 'YYYYMMDD'))::timestamp
  and tp.tech_dt  <= (date_trunc('month', to_date('20190601', 'YYYYMMDD')) + interval '1 month - 1 second')::timestamp
  and tp.serv_id > 0
) xx where xx.rn = 1  
;

-- step 1 ANALYZE
analyze edw_dm_efftp.tfct_oo_eff_tp_1_prt_p000151
--select edw_utl.analyze_etl_tables('edw_dm_efftp.tfct_oo_eff_tp')
;

analyze edw_stg_dm_efftp.tfct_oo_eff_tp_1_prt_p000151
--select edw_utl.analyze_etl_tables('edw_stg_dm_efftp.tfct_oo_eff_tp')
;

-- step 2 PDZ_BLOCK
update edw_stg_dm_efftp.TFCT_OO_EFF_TP_1_prt_p000151 as tp
set pdz_block = 1
where 1 = 1
and tp.p1_period = to_number(to_char(date_trunc('month', to_date('20190601', 'YYYYMMDD')), 'YYYYMM'), '999999')
and tp.serv_id in (1, 2, 3)
and coalesce(tp.charge_only_flag, 0) = 0
and tp.account is not null
and exists
(select 1 from (select cl.account,
case
when cl.mrf_id = 14 then trim(to_char(cl.user_id, '9999999999999999999'))
else cl.account
end as cast_account,
cl.mrf_id,
cl.rf_id,
cl.base_src_id,
cl.period
from edw_ods.t_000159_CLIENT_DWH cl,
edw_ods.t_000159_DEBt_DWH   d
where 1 = 1
and cl.period = to_number(to_char(date_trunc('month', to_date('20190601', 'YYYYMMDD')), 'YYYYMM'), '999999')
and d.period =  to_number(to_char(date_trunc('month', to_date('20190601', 'YYYYMMDD')), 'YYYYMM'), '999999')
and cl.tech_dt  >= date_trunc('month', to_date('20190601', 'YYYYMMDD'))::timestamp
and cl.tech_dt  <= (date_trunc('month', to_date('20190601', 'YYYYMMDD')) + interval '1 month - 1 second')::timestamp
and d.tech_dt  >= date_trunc('month', to_date('20190601', 'YYYYMMDD'))::timestamp
and d.tech_dt  <= (date_trunc('month', to_date('20190601', 'YYYYMMDD')) + interval '1 month - 1 second')::timestamp
and cl.period = d.period
and cl.mrf_id = d.mrf_id
and cl.user_id = d.user_id
--and d.src_id = cl.src_id
and d.crs_src_id = cl.crs_src_id -- меняем на ид источника в самом скоринге
--and cl.rf_id = d.rf_id
and d.serv_id <= (case when d.mrf_id!=14 then 8 else  11 end)
and d.overdue_deb > 0
and date_part('day', to_date(to_char(d.period, '999999'), 'YYYYMM') + interval '1 month - 1 day' - d.date_begin) > 51
group by cl.account,
cl.mrf_id,
cl.rf_id,
cl.base_src_id,
cl.period,
case
when cl.mrf_id = 14 then trim(to_char(cl.user_id, '9999999999999999999'))
else cl.account
end) d
where 1 = 1
and tp.p1_period = d.period
and tp.p2_mrf_id = d.mrf_id
and tp.p3_rf_id = d.rf_id
and tp.account = d.cast_account)
;

-- step 3 VOL_BLOCK
--update edw_stg_dm_efftp.TFCT_OO_EFF_TP tp
--set vol_block = 1
--where 1 = 1
--and tp.P1_PERIOD = to_number(to_char(date_trunc('month', to_date('20190601', 'YYYYMMDD')), 'YYYYMM'), '999999')
--and tp.serv_id in (1, 2, 3)
--and  coalesce(tp.charge_only_flag, 0) = 0
--and tp.abn_id is not null
--and exists
--(select  1
--from
--(SELECT *
--,row_number() over (partition by abon_id order by block_chng_dt desc) as rn
--FROM edw_dmcm.tfct_blka t
--where 1 = 1
----and t.mrf_id = $mrf
--and (t.block_chng_dt  between  date_trunc('month', to_date('20190601', 'YYYYMMDD')) and  date_trunc('month', to_date('20190601', 'YYYYMMDD')) + interval '1 month - 1 day'
--or t.snapshot_dt between  date_trunc('month', to_date('20190601', 'YYYYMMDD')) and  date_trunc('month', to_date('20190601', 'YYYYMMDD')) + interval '1 month - 1 day')
--)  TFCT_SUBS_BLOCK
--where 1 = 1
--and TFCT_SUBS_BLOCK.rn = 1
--and TFCT_SUBS_BLOCK.block_type_id = 1
--and TFCT_SUBS_BLOCK.block_status_id = 1
--and TFCT_SUBS_BLOCK.mrf_id = tp.p2_mrf_id
--and TFCT_SUBS_BLOCK.abon_id = tp.abn_id
--and tp.serv_id = case when TFCT_SUBS_BLOCK.srvs_name='ОТА' then 1
--when TFCT_SUBS_BLOCK.srvs_name='ШПД' then 2
--when TFCT_SUBS_BLOCK.srvs_name='IP-TV' then 3
--else -1
--end
--)
--;

-- step 4  CHURN_ABN_PDZ
update edw_stg_dm_efftp.TFCT_OO_EFF_TP_1_prt_p000151 tp
set CHURN_ABN_PDZ = 1
where 1 = 1
and tp.P1_PERIOD = to_number(to_char(date_trunc('month', to_date('20190601', 'YYYYMMDD')), 'YYYYMM'), '999999')
and tp.serv_id in (1, 2, 3)
and  coalesce(tp.charge_only_flag,0) = 0
and tp.account is not null
and coalesce(tp.churn_abns,0) != 0
and  exists
(select
1 --cl.account, cl.mrf_id, cl.rf_id,cl.base_src_id,cl.period
from edw_ods.t_000159_CLIENT_DWH cl
,edw_ods.t_000159_DEBt_DWH d
where 1=1
and cl.period = to_number(to_char(date_trunc('month', to_date('20190601', 'YYYYMMDD')), 'YYYYMM'), '999999')
and d.period =  to_number(to_char(date_trunc('month', to_date('20190601', 'YYYYMMDD')), 'YYYYMM'), '999999')
and cl.tech_dt  >= date_trunc('month', to_date('20190601', 'YYYYMMDD'))::timestamp
and cl.tech_dt  <= (date_trunc('month', to_date('20190601', 'YYYYMMDD')) + interval '1 month - 1 second')::timestamp
and d.tech_dt  >= date_trunc('month', to_date('20190601', 'YYYYMMDD'))::timestamp
and d.tech_dt  <= (date_trunc('month', to_date('20190601', 'YYYYMMDD')) + interval '1 month - 1 second')::timestamp
and d.serv_id <= (case when d.mrf_id != 14 then 8 else  11 end)
and cl.period = tp.p1_period
and cl.mrf_id = tp.p2_mrf_id
and cl.rf_id = tp.p3_rf_id
and tp.account = case
when cl.mrf_id=14  then trim(to_char(cl.user_id, '9999999999999999999'))
else cl.account
end
and cl.period = d.period
and cl.mrf_id = d.mrf_id
and cl.user_id = d.user_id
--and d.src_id = cl.src_id
and d.crs_src_id = cl.crs_src_id -- меняем на ид источника в самом скоринге
--and cl.rf_id = d.rf_id
and d.overdue_deb > 0
and date_part('day', to_date(to_char(d.period, '999999'), 'YYYYMM') + interval '1 month - 1 day' - d.date_begin) > 150)
;

-- step 5 CHURN_MOM - 1, 2
update edw_stg_dm_efftp.TFCT_OO_EFF_TP_1_prt_p000151 tp
set churn_mom = case
when tp.churn_abn_pdz = 0 then 1 -- отток по своей воле
when tp.churn_abn_pdz = 1 then 2 --отток по ПДЗ
else 0
end
where 1 = 1
and tp.P1_PERIOD = to_number(to_char(date_trunc('month', to_date('20190601', 'YYYYMMDD')), 'YYYYMM'), '999999')
and tp.serv_id in (1, 2, 3)
and coalesce(tp.charge_only_flag, 0) = 0
and coalesce(tp.churn_abns, 0) != 0
;

-- step 6 CHURN_MOM - 3, 4
update edw_stg_dm_efftp.TFCT_OO_EFF_TP_1_prt_p000151 tp
set churn_mom = case
when tp.pdz_block=0 and tp.vol_block=1 then 3 --момент. отток по добров блокир.
when tp.pdz_block=1 then 4
else 0
end
where 1 = 1
and tp.P1_PERIOD = to_number(to_char(date_trunc('month', to_date('20190601', 'YYYYMMDD')), 'YYYYMM'), '999999')
and tp.serv_id in (1, 2, 3)
and coalesce(tp.charge_only_flag, 0) = 0
and coalesce(tp.churn_abns, 0) = 0
and exists (select 1 from edw_dm_efftp.TFCT_OO_EFF_TP_1_prt_p000151 ltp
where ltp.p1_period = to_number(to_char(to_date(to_char(tp.p1_period, '999999'), 'YYYYMM') - interval '1 month ', 'YYYYMM'), '999999')
and ltp.dt = (date_trunc('month', to_date('20190601', 'YYYYMMDD')) - interval '1 month ')::timestamp
and ltp.serv_id in (1, 2, 3)
and coalesce(ltp.charge_only_flag, 0) = 0
and coalesce(ltp.vol_block, 0) = 0
and coalesce(ltp.pdz_block, 0) = 0
and coalesce(ltp.p24_qnt_end_rp_shpd, 0) + coalesce(ltp.p81_qnt_end_rp_ota, 0) + coalesce(ltp.p83_qnt_end_rp_iptv, 0) > 0
and ltp.p2_mrf_id=tp.p2_mrf_id
and ltp.p3_rf_id=tp.p3_rf_id
and ltp.abn_id=tp.abn_id
and ltp.serv_id=tp.serv_id)
;

-- step 7 CHURN_MOM_REACT, CHURN_MOM_IN_CHURN
update edw_stg_dm_efftp.TFCT_OO_EFF_TP_1_prt_p000151 tp

set churn_mom_in_churn = case
when coalesce(tp.churn_abns, 0) > 0 and ltp.vol_block = 1 and ltp.pdz_block = 0 then 3
when coalesce(tp.churn_abns, 0) > 0 and ltp.pdz_block = 1 then 4
else 0
end,
churn_mom_react = case
when coalesce(tp.churn_abns, 0) = 0 and tp.vol_block = 0 and tp.pdz_block = 0 and ltp.vol_block = 1 and ltp.PDZ_BLOCK = 0 then 3
when coalesce(tp.churn_abns, 0) = 0 and tp.vol_block = 0 and tp.pdz_block = 0 and ltp.PDZ_BLOCK = 1 then 4
else 0
end

from edw_dm_efftp.TFCT_OO_EFF_TP_1_prt_p000151 ltp

where 1 = 1
and tp.p1_period = to_number(to_char(date_trunc('month', to_date('20190601', 'YYYYMMDD')), 'YYYYMM'), '999999')
and ltp.p2_mrf_id = tp.p2_mrf_id
and ltp.p3_rf_id = tp.p3_rf_id
and ltp.abn_id = tp.abn_id
and ltp.serv_id = tp.serv_id
and ltp.p1_period = to_number(to_char(to_date(to_char(tp.p1_period, '999999'), 'YYYYMM') - interval '1 month ', 'YYYYMM'), '999999')
and ltp.dt = (date_trunc('month', to_date('20190601', 'YYYYMMDD')) - interval '1 month ')::timestamp
and tp.serv_id in (1, 2, 3)
and ltp.serv_id in (1, 2, 3)
and coalesce(tp.charge_only_flag, 0) = 0
and coalesce(ltp.p24_qnt_end_rp_shpd, 0) + coalesce(ltp.p81_qnt_end_rp_ota, 0) + coalesce(ltp.p83_qnt_end_rp_iptv, 0) > 0
;

--step 8 RTI_BAL
truncate table EDW_STG_DM_EFFTP.PRE_RTI_CASE_AGG_CLIENT_1_prt_p000151;

---- Ветка для МРФ 11, 12, 13, 15, 16, 17 все периоды и МРФ 14 до 201808 (включительно) 
insert into EDW_STG_DM_EFFTP.PRE_RTI_CASE_AGG_CLIENT_1_prt_p000151
(
mrf_id,
rf_id,
account_id,
period,
balance,
pay_ind,
cast_account,
src_id
)
select g.mrf_id,
g.rf_id,
account_id,
to_number(to_char(date_trunc('month', g.dt), 'YYYYMM'), '999999') period,
(PREPAY_SUM - balance_sum) balance,
g.pay_ind,
case
when g.mrf_id = 14 then trim(substr(trim(to_char(g.account_id, '999999999999999999999')), 7, 15))
else trim(to_char(g.account_id, '999999999999999999999'))
end cast_account,
to_number('000151', '999999') src_id
from edw_ods.t_000159_rti_case_agg_client g
where 1 = 1
and g.mrf_id = decode('000151', '000151', 11, '000152', 12, '000153', 13, '000154', 14, '000155', 15, '000156', 16, '000157', 17)
and date_trunc('month', g.dt) = date_trunc('month', to_date('20190601', 'YYYYMMDD'))
and g.tech_dt >= date_trunc('month', to_date('20190601', 'YYYYMMDD'))::timestamp
and g.tech_dt <= (date_trunc('month', to_date('20190601', 'YYYYMMDD')) + interval '1 month - 1 second')::timestamp
and ('000151' in ('000151', '000152', '000153', '000155', '000156', '000157')
 or ('000151' = '000154' and date_trunc('month', to_date('20190601', 'YYYYMMDD')) < to_date('20180901', 'YYYYMMDD'))
    )
;

---- Ветка для МРФ 14 начиная с 201809 (включительно) 
insert into EDW_STG_DM_EFFTP.PRE_RTI_CASE_AGG_CLIENT_1_prt_p000151
(
mrf_id,
rf_id,
account_id,
period,
balance,
pay_ind,
cast_account,
src_id
)
select g.mrf_id,
g.rf_id,
account_id,
to_number(to_char(date_trunc('month', g.dt), 'YYYYMM'), '999999') period,
(PREPAY_SUM - balance_sum) balance,
g.pay_ind,
snls.account cast_account,
to_number('000151', '999999') src_id
from edw_ods.t_000159_rti_case_agg_client g
join
(select rrr.account, rrr.nls
  from (select account, nls, row_number() over (partition by account order by date_begin desc) as rn
        from edw_ods.t_000158_efftp_south_nls_accnt sn
        where coalesce(sn.date_end, current_date) >= date_trunc('month', to_date('20190601', 'YYYYMMDD')) --Первый день отчетного периода
        and sn.date_begin <= date_trunc('month', to_date('20190601', 'YYYYMMDD')) + interval '1 month - 1 second' --Последний день отчетного периода
       ) rrr 
where rrr.rn = 1
) snls
on g.account_id = to_number(snls.nls, '9999999999999999999999999') -- or g.account_id = snls.account
where 1 = 1
and g.mrf_id = decode('000151', '000151', 11, '000152', 12, '000153', 13, '000154', 14, '000155', 15, '000156', 16, '000157', 17)
and date_trunc('month', g.dt) = date_trunc('month', to_date('20190601', 'YYYYMMDD'))
and g.tech_dt >= date_trunc('month', to_date('20190601', 'YYYYMMDD'))::timestamp
and g.tech_dt <= (date_trunc('month', to_date('20190601', 'YYYYMMDD')) + interval '1 month - 1 second')::timestamp
and ('000151' = '000154' and date_trunc('month', to_date('20190601', 'YYYYMMDD')) >= to_date('20180901', 'YYYYMMDD'))
;

---- Ветка для МРФ 14 начиная с 201809 (включительно) 
insert into EDW_STG_DM_EFFTP.PRE_RTI_CASE_AGG_CLIENT_1_prt_p000151
(
mrf_id,
rf_id,
account_id,
period,
balance,
pay_ind,
cast_account,
src_id
)
select g.mrf_id,
g.rf_id,
account_id,
to_number(to_char(date_trunc('month', g.dt), 'YYYYMM'), '999999') period,
(PREPAY_SUM - balance_sum) balance,
g.pay_ind,
snls.account cast_account,
to_number('000151', '999999') src_id
from edw_ods.t_000159_rti_case_agg_client g
join
(select rrr.account, rrr.nls
  from (select account, nls, row_number() over (partition by account order by date_begin desc) as rn
        from edw_ods.t_000158_efftp_south_nls_accnt sn
        where coalesce(sn.date_end, current_date) >= date_trunc('month', to_date('20190601', 'YYYYMMDD')) --Первый день отчетного периода
        and sn.date_begin <= date_trunc('month', to_date('20190601', 'YYYYMMDD')) + interval '1 month - 1 second' --Последний день отчетного периода
       ) rrr 
where rrr.rn = 1
) snls
on /*g.account_id = snls.nls or*/ g.account_id = to_number(snls.account, '9999999999999999999999999')
where 1 = 1
and g.mrf_id = decode('000151', '000151', 11, '000152', 12, '000153', 13, '000154', 14, '000155', 15, '000156', 16, '000157', 17)
and date_trunc('month', g.dt) = date_trunc('month', to_date('20190601', 'YYYYMMDD'))
and g.tech_dt >= date_trunc('month', to_date('20190601', 'YYYYMMDD'))::timestamp
and g.tech_dt <= (date_trunc('month', to_date('20190601', 'YYYYMMDD')) + interval '1 month - 1 second')::timestamp
and ('000151' = '000154' and date_trunc('month', to_date('20190601', 'YYYYMMDD')) >= to_date('20180901', 'YYYYMMDD'))
;

analyze EDW_STG_DM_EFFTP.PRE_RTI_CASE_AGG_CLIENT_1_prt_p000151;
--select edw_utl.analyze_etl_tables('edw_stg_dm_efftp.pre_rti_case_agg_client');

UPDATE edw_stg_dm_efftp.TFCT_OO_EFF_TP_1_prt_p000151 tp
SET balance = t.balance,
    pay_ind = t.pay_ind
from
( select *
from EDW_STG_DM_EFFTP.PRE_RTI_CASE_AGG_CLIENT_1_prt_p000151 g
where g.period = to_number(to_char(to_date('20190601', 'YYYYMMDD'), 'YYYYMM'), '999999')
) t
WHERE 1 = 1
and tp.p1_period = to_number(to_char(to_date('20190601', 'YYYYMMDD'), 'YYYYMM'), '999999')
and tp.p1_period = t.period
and tp.p2_mrf_id = t.mrf_id
and tp.p3_rf_id = t.rf_id
and tp.serv_id in (1, 2, 3, 4, 5)
and  coalesce(tp.charge_only_flag, 0) = 0
and tp.account is not null
and tp.account = t.cast_account
and '000151' <> '000154'
;

UPDATE edw_stg_dm_efftp.TFCT_OO_EFF_TP_1_prt_p000151 tp
SET balance = t.balance,
    pay_ind = t.pay_ind
from
( select g.*,
         row_number() over (partition by g.mrf_id,
                                         g.rf_id,
                                         g.period,
                                         g.cast_account,
                                         g.src_id
                            order by decode(length(account_id), 12, 0, 100) asc, g.load_dttm desc) rn
from EDW_STG_DM_EFFTP.PRE_RTI_CASE_AGG_CLIENT_1_prt_p000154 g
where g.period = to_number(to_char(to_date('20190601', 'YYYYMMDD'), 'YYYYMM'), '999999')
) t
WHERE 1 = 1
and tp.p1_period = to_number(to_char(to_date('20190601', 'YYYYMMDD'), 'YYYYMM'), '999999')
and tp.p1_period = t.period
and tp.p2_mrf_id = t.mrf_id
and tp.p3_rf_id = t.rf_id
and tp.serv_id in (1, 2, 3, 4, 5)
and  coalesce(tp.charge_only_flag, 0) = 0
and tp.account is not null
and tp.account = t.cast_account
and t.rn = 1
and '000151' = '000154'
;

UPDATE edw_stg_dm_efftp.TFCT_OO_EFF_TP_1_prt_p000151 tp
SET balance = t.balance,
    pay_ind = t.pay_ind
from
(
select g.mrf_id, g.rf_id, g.account_id, g.period, g.balance, g.pay_ind, g.src_id, count(*)
from (
select g.mrf_id, g.rf_id, g.account_id, g.period, g.balance, g.pay_ind, g.src_id
from EDW_STG_DM_EFFTP.PRE_RTI_CASE_AGG_CLIENT_1_prt_p000154 g
where g.period = to_number(to_char(to_date('20190601', 'YYYYMMDD'), 'YYYYMM'), '999999')
group by g.mrf_id, g.rf_id, g.account_id, g.period, g.balance, g.pay_ind, g.src_id
) g
group by g.mrf_id, g.rf_id, g.account_id, g.period, g.balance, g.pay_ind, g.src_id
having count(*) = 1
) t
WHERE 1 = 1
and tp.p1_period = to_number(to_char(to_date('20190601', 'YYYYMMDD'), 'YYYYMM'), '999999')
and tp.p1_period = t.period
and tp.p2_mrf_id = t.mrf_id
and tp.p3_rf_id = t.rf_id
and tp.serv_id in (1, 2, 3, 4, 5)
and  coalesce(tp.charge_only_flag, 0) = 0
and tp.account is not null
and tp.account = t.account_id
and '000151' = '000154' and date_trunc('month', to_date('20190601', 'YYYYMMDD')) >= to_date('20180901', 'YYYYMMDD')
;

-- step 9 DEBT_PDZ
-- -- step 9.1 truncate PRE_DEBT_OVERDEBT
truncate table edw_stg_dm_efftp.PRE_DEBT_OVERDEBT_1_prt_p000151 --TODO change schema to STG_DM_EFFTP
;

-- -- step 9.2 insert PRE_DEBT_OVERDEBT
insert into edw_stg_dm_efftp.PRE_DEBT_OVERDEBT_1_prt_p000151     --TODO change schema to STG_DM_EFFTP
(
mrf_id,
rf_id,
period,
account,
cast_account,
user_id,
serv_id,
period_data,
date_begin,
day_debt,
debt,
overdue_debt,
src_id
)
SELECT
cast(dd.mrf_id as numeric(10, 0)) as mrf_id,
cast(dd.rf_id  as numeric(10, 0)) as rf_id,
cast(dd.period as numeric(10, 0)) as period,
cast(cd.account as varchar(50)) as account,
cast(
case
when cd.mrf_id != 14 then cd.account
else trim(to_char(cd.user_id, '9999999999999999999'))
end
as varchar(50)) as cast_account,
cast(dd.user_id as varchar(50)) as user_id,
cast(x.serv_id as numeric(10, 0)) as serv_id,
to_date(to_char(dd.period, '999999'), 'YYYYMM') + interval '1 month - 1 day' as period_data,
min(dd.date_begin) as date_begin,
cast(date_part('day', to_date(to_char(dd.period, '999999'), 'YYYYMM') + interval '1 month - 1 day' - min(dd.date_begin)) as numeric(10, 0)) as day_debt,
cast(sum(dd.debt) as numeric(38, 10)) as debt,
cast(sum(dd.overdue_deb) as numeric(38, 10)) as overdue_debt,
to_number('000151', '999999') src_id
FROM edw_ods.t_000159_debt_dwh dd
JOIN edw_ods.t_000159_client_dwh cd
ON 1 = 1
and dd.period = cd.period
and dd.user_id = cd.user_id
and dd.mrf_id = cd.mrf_id
--and dd.src_id = cd.src_id
and dd.crs_src_id = cd.crs_src_id -- меняем на ид источника в самом скоринге
LEFT JOIN (
SELECT 1 as serv_gr_id, 1 as serv_id UNION ALL
SELECT 2 as serv_gr_id, 1 as serv_id UNION ALL
SELECT 3 as serv_gr_id, 1 as serv_id UNION ALL
SELECT 4 as serv_gr_id, 1 as serv_id UNION ALL
SELECT 5 as serv_gr_id, 0 as serv_id UNION ALL
SELECT 6 as serv_gr_id, 0 as serv_id UNION ALL
SELECT 7 as serv_gr_id, 2 as serv_id UNION ALL
SELECT 8 as serv_gr_id, 3 as serv_id UNION ALL
SELECT 9 as serv_gr_id, 0 as serv_id UNION ALL
SELECT 10 as serv_gr_id, 0 as serv_id UNION ALL
SELECT 11 as serv_gr_id, 0 as serv_id
) x ON x.serv_gr_id = dd.serv_id
WHERE 1 = 1
and dd.period = to_number(to_char(date_trunc('month', to_date('20190601', 'YYYYMMDD')), 'YYYYMM'), '999999')   --201804
and cd.period = to_number(to_char(date_trunc('month', to_date('20190601', 'YYYYMMDD')), 'YYYYMM'), '999999')
and dd.tech_dt = date_trunc('month', to_date('20190601', 'YYYYMMDD'))::date
and cd.tech_dt = date_trunc('month', to_date('20190601', 'YYYYMMDD'))::date
GROUP BY
dd.mrf_id,
dd.rf_id,
dd.period,
cd.account,
case
when cd.mrf_id != 14 then cd.account
else trim(to_char(cd.user_id, '9999999999999999999'))
end,
dd.user_id,
x.serv_id
;

analyze edw_stg_dm_efftp.pre_debt_overdebt_1_prt_p000151;
--select edw_utl.analyze_etl_tables('edw_stg_dm_efftp.pre_debt_overdebt');

-- -- step 9.3 update TFCT_OO_EFF_TP by PRE_DEBT_OVERDEBT
UPDATE edw_stg_dm_efftp.TFCT_OO_EFF_TP_1_prt_p000151 tp
SET debt = t.debt,
pdz = coalesce(t.overdue_debt, 0)
from
(
SELECT * from edw_stg_dm_efftp.PRE_DEBT_OVERDEBT_1_prt_p000151 dd  --TODO change schema to STG_DM_EFFTP
WHERE 1 = 1
and dd.period = to_number(to_char(date_trunc('month', to_date('20190601', 'YYYYMMDD')), 'YYYYMM'), '999999')
) t
WHERE 1 = 1
and tp.p1_period = to_number(to_char(date_trunc('month', to_date('20190601', 'YYYYMMDD')), 'YYYYMM'), '999999')
and tp.p1_period = t.period
and tp.p2_mrf_id = t.mrf_id
and tp.p3_rf_id = t.rf_id
and tp.serv_id in (1, 2, 3)
and t.serv_id >= (case when t.mrf_id !=14 then 1 else 0 end)
and coalesce(tp.charge_only_flag, 0) = 0
and tp.account = t.cast_account
and tp.serv_id = t.serv_id
;

-- -- step 9.4 truncate PRE_DEBT_OVERDEBT
truncate table edw_stg_dm_efftp.PRE_DEBT_OVERDEBT_1_prt_p000151  --TODO change schema to STG_DM_EFFTP
;

--step 10 pereezd RF

----step 10.1 truncate PRE_MOVE_RF
truncate table edw_stg_dm_efftp.pre_move_rf_1_prt_p000151; -- TODO change schema to STG_DM_EFFTP

----step 10.2 insert PRE_MOVE_RF
insert into edw_stg_dm_efftp.pre_move_rf_1_prt_p000151  -- TODO change schema to STG_DM_EFFTP
(
current_abn_id,
current_period,
current_account,
current_serv_id,
current_hflat,
current_rf_id,
pereezd_rf,
src_id
)
WITH poisk_move as (
with lv_cur as
(select
cur_eff.abn_id as current_abn_id,
cur_eff.account as current_account,
cur_eff.p1_period as current_period,
coalesce(cur_eff.new_abns, 0) as current_new,
cur_eff.hflat as current_hflat,
cur_eff.serv_id as current_serv_id,
cur_eff.p3_rf_id as current_rf_id,
cur_eff.hlid as current_hlid,
count(distinct cur_eff.subs_id) as count_current_subs_id,
max(P24_QNT_END_RP_SHPD) as current_actual_shpd,
max(P81_QNT_END_RP_OTA) as current_actual_ota,
max(P83_QNT_END_RP_IPTV) as current_actual_iptv
from
edw_ods.t_000151_efftp_oo_eff_tp as cur_eff
where 1 = 1
  and cur_eff.P1_PERIOD = to_number(to_char(date_trunc('month', to_date('20190601', 'YYYYMMDD')), 'YYYYMM'), '999999')
  and cur_eff.tech_dt >= date_trunc('month', to_date('20190601', 'YYYYMMDD'))::timestamp
  and cur_eff.tech_dt <= (date_trunc('month', to_date('20190601', 'YYYYMMDD')) + interval '1 month - 1 second')::timestamp
group by
cur_eff.abn_id,
cur_eff.account,
cur_eff.p1_period,
coalesce(cur_eff.new_abns, 0),
cur_eff.hflat,
cur_eff.serv_id,
cur_eff.p3_rf_id,
cur_eff.hlid
),
lv_prev as
(select
prev_eff.account as previous_account,
prev_eff.p1_period as previous_period,
coalesce(prev_eff.new_abns, 0) as previous_new,
prev_eff.hflat as previous_hflat,
prev_eff.serv_id as previous_serv_id,
prev_eff.p3_rf_id as previous_rf_id,
prev_eff.hlid as previous_hlid,
count(distinct prev_eff.subs_id) as count_previous_subs_id,
max(P24_QNT_END_RP_SHPD) as previous_actual_shpd,
max(P81_QNT_END_RP_OTA) as previous_actual_ota,
max(P83_QNT_END_RP_IPTV) as previous_actual_iptv
from
edw_ods.t_000151_efftp_oo_eff_tp as prev_eff
where 1 = 1
  and prev_eff.P1_PERIOD = to_number(to_char(date_trunc('month', to_date('20190601', 'YYYYMMDD')) + interval '-1 month', 'YYYYMM'), '999999')
  and prev_eff.tech_dt  >= (date_trunc('month', to_date('20190601', 'YYYYMMDD')) + interval'-1 month')::timestamp
  and prev_eff.tech_dt  <= (date_trunc('month', to_date('20190601', 'YYYYMMDD')) + interval '-1 second')::timestamp
group by
prev_eff.account,
prev_eff.p1_period,
coalesce(prev_eff.new_abns, 0),
prev_eff.hflat,
prev_eff.serv_id,
prev_eff.p3_rf_id,
prev_eff.hlid
)
SELECT
current_abn_id,
current_period,
current_account,
current_serv_id,
current_hflat,
current_rf_id,
case
when current_serv_id='1' then (case when current_actual_ota=(case when (lag(current_actual_ota) OVER(partition by current_account, current_serv_id ORDER BY current_account, current_serv_id, current_period)) is null then current_actual_ota else (lag(current_actual_ota) OVER(partition by current_account, current_serv_id ORDER BY current_account, current_serv_id, current_period)) end) then 1 else 0 end)
when current_serv_id='2' then (case when current_actual_shpd=(case when (lag(current_actual_shpd) OVER(partition by current_account, current_serv_id ORDER BY current_account, current_serv_id, current_period)) is null then current_actual_shpd else (lag(current_actual_shpd) OVER(partition by current_account, current_serv_id ORDER BY current_account, current_serv_id, current_period)) end) then 1 else 0 end)
when current_serv_id='3' then (case when current_actual_iptv=(case when (lag(current_actual_iptv) OVER(partition by current_account, current_serv_id ORDER BY current_account, current_serv_id, current_period)) is null then current_actual_iptv else (lag(current_actual_iptv) OVER(partition by current_account, current_serv_id ORDER BY current_account, current_serv_id, current_period)) end) then 1 else 0 end)
else 0
end as punkt_1 /*По условиям ниже есть действующие абоненты в текущем и предыдущем периодах|1 = есть действующие в предыдущем и в настоящем; 0 = иначе|*/,
current_new as punkt_2 /*|В текущем периоде абонент не является новым.|*/,
case when current_rf_id=(case when previous_rf_id is null then current_rf_id else previous_rf_id end) then 1 /*'один рф'*/ else 0 /*'разный рф'*/ end as punkt_3, /*Рассматриваются абоненты в одном РФ*/
case
when current_hflat<>previous_hflat then 1
when current_hflat is not null and previous_hflat is null then 1
else 0
end as punkt_4_5 /*|В предыдущем месяце на данных Л/С и Услуге и HFLAT НЕ было абонентов.+В предыдущем месяце на данных Л/С и Услуге, но по другому HFLAT были абоненты|*/
FROM
lv_cur
left join lv_prev on 1=1
and lv_cur.current_account=lv_prev.previous_account
and lv_cur.current_serv_id=lv_prev.previous_serv_id
--and lv_cur.current_period=(lv_prev.previous_period+1)
and lv_cur.current_hflat=lv_prev.previous_hflat
where 1=1
--order by current_account, current_serv_id, current_period
)
SELECT
distinct
current_abn_id,
current_period,
current_account,
current_serv_id,
current_hflat,
current_rf_id,
case when poisk_move.punkt_1='1' and poisk_move.punkt_2='0' and poisk_move.punkt_3='1' and poisk_move.punkt_4_5='1' then 1 else 0 end as pereezd_rf,
to_number('000151', '999999') src_id
FROM
poisk_move
where current_account is not null
;

analyze edw_stg_dm_efftp.pre_move_rf_1_prt_p000151;  -- TODO change schema to STG_DM_EFFTP
--select edw_utl.analyze_etl_tables('edw_stg_dm_efftp.pre_move_rf');  -- TODO change schema to STG_DM_EFFTP

----step 10.3 update pereezd RF
update edw_stg_dm_efftp.TFCT_OO_EFF_TP_1_prt_p000151 tp
set move_rf = xx.pereezd_rf
from edw_stg_dm_efftp.pre_move_rf_1_prt_p000151 xx   -- TODO change schema to STG_DM_EFFTP
where 1 = 1
and tp.P1_PERIOD = to_number(to_char(date_trunc('month', to_date('20190601', 'YYYYMMDD')), 'YYYYMM'), '999999')
and xx.current_period = tp.p1_period
and xx.current_account = tp.account
and xx.current_abn_id = tp.abn_id
and xx.current_serv_id = tp.serv_id
and xx.current_hflat = tp.hflat
and xx.current_rf_id = tp.p3_rf_id
and xx.src_id = tp.src_id
;

----step 10.4 truncate pereezd RF
truncate table edw_stg_dm_efftp.pre_move_rf_1_prt_p000151; -- TODO change schema to STG_DM_EFFTP

--step 11 pereezd MRF

---- step 11.1 truncate PRE_MOVE_MRF
truncate table edw_stg_dm_efftp.pre_move_mrf_1_prt_p000151;  -- TODO change schema to STG_DM_EFFTP

---- step 11.2 insert PRE_MOVE_MRF
insert into edw_stg_dm_efftp.pre_move_mrf_1_prt_p000151  -- TODO change schema to STG_DM_EFFTP
(
move_mrf,
current_customer_id,
current_period,
current_mrf,
current_serv,
current_cd_abn,
src_id
)
with pereezd_mrf as (
with lv_cur as
(
select
case when cur_eff.customer_id is not null then cur_eff.customer_id else cur_eff.account end as current_customer_id,
cur_eff.p1_period as current_period,
cur_eff.p2_mrf_id as current_mrf,
cur_eff.p3_rf_id as current_rf,
cur_eff.serv_id as current_serv,
(case when cur_eff.new_abns='1' then 1 else 0 end) as current_new_abns,
(case when (cur_eff.churn_abns in ('1','2')) then 1 else 0 end) as current_churn_abns,
cur_eff.abn_id as current_cd_abn
from
edw_stg_dm_efftp.tfct_oo_eff_tp_1_prt_p000151 as cur_eff
where cur_eff.p1_period = to_number(to_char(date_trunc('month', to_date('20190601', 'YYYYMMDD')), 'YYYYMM'), '999999')
and cur_eff.dt = (date_trunc('month', to_date('20190601', 'YYYYMMDD')))::timestamp
group by
case when cur_eff.customer_id is not null then cur_eff.customer_id else cur_eff.account end,
cur_eff.p1_period,
cur_eff.p2_mrf_id,
cur_eff.p3_rf_id,
cur_eff.serv_id,
(case when cur_eff.new_abns='1' then 1 else 0 end),
(case when (cur_eff.churn_abns in ('1','2')) then 1 else 0 end),
cur_eff.abn_id
),
lv_prev as
(
select
case when cur_eff.customer_id is not null then cur_eff.customer_id else cur_eff.account end as prev_customer_id,
cur_eff.p1_period as prev_period,
cur_eff.p2_mrf_id as prev_mrf,
cur_eff.p3_rf_id as prev_rf,
cur_eff.serv_id as prev_serv,
(case when cur_eff.new_abns='1' then 1 else 0 end) as prev_new_abns,
(case when (cur_eff.churn_abns in ('1','2')) then 1 else 0 end) as prev_churn_abns,
cur_eff.abn_id as prev_cd_abn
from
edw_dm_efftp.tfct_oo_eff_tp_1_prt_p000151 as cur_eff
where cur_eff.p1_period = to_number(to_char(date_trunc('month', to_date('20190601', 'YYYYMMDD')) + interval '-1 month', 'YYYYMM'), '999999')
and cur_eff.dt = (date_trunc('month', to_date('20190601', 'YYYYMMDD')) + interval '-1 month')::timestamp
group by
case when cur_eff.customer_id is not null then cur_eff.customer_id else cur_eff.account end,
cur_eff.p1_period,
cur_eff.p2_mrf_id,
cur_eff.p3_rf_id,
cur_eff.serv_id,
(case when cur_eff.new_abns='1' then 1 else 0 end),
(case when (cur_eff.churn_abns in ('1','2')) then 1 else 0 end),
cur_eff.abn_id
)
select
case when current_customer_id=prev_customer_id then '1' else '0' end as p1 /*Совпадают customer_id*/
,case when current_mrf=prev_mrf then '1' else '0' end as p2 /*Совпадают p2_mrf_id*/
,case when current_serv=prev_serv then '1' else '0' end as p3 /*Совпадают serv_id*/
,case when current_rf<>prev_rf then '1' else '0' end as p4 /*Разные p3_rf_id*/
,case when prev_churn_abns='1' then '1' else '0' end as p5 /*Один абонент ушел в отток в предыдущем периоде*/
,case when current_new_abns='1' then '1' else '0' end as p6 /*Второй абонент подключился в текущем периоде (для него проставляем признак move_mrf)*/
,current_customer_id ,prev_customer_id
,current_period ,prev_period
,current_mrf ,prev_mrf
,current_rf ,prev_rf
,current_serv ,prev_serv
,current_new_abns ,prev_new_abns
,current_churn_abns ,prev_churn_abns
,current_cd_abn ,prev_cd_abn
from
lv_cur
left outer join lv_prev
on 1 = 1
and lv_cur.current_customer_id=lv_prev.prev_customer_id
--and lv_cur.current_period=to_char(to_timestamp(lv_prev.prev_period, 'YYYYMM')+interval '1 month', 'YYYYMM')
and lv_cur.current_serv=lv_prev.prev_serv
and lv_cur.current_cd_abn=lv_prev.prev_cd_abn
where 1 = 1
)
select
case when p_mrf.p1='1' and p_mrf.p2='1' and p_mrf.p3='1' and p_mrf.p4='1' and p_mrf.p5='1' and p_mrf.p6='1' then 1 else 0 end as move_mrf,
p_mrf.current_customer_id,
p_mrf.current_period,
p_mrf.current_mrf,
p_mrf.current_serv,
p_mrf.current_cd_abn,
to_number('000151', '999999') src_id
from
pereezd_mrf as p_mrf
where 1 = 1
order by
p_mrf.current_customer_id,
p_mrf.current_period,
p_mrf.current_serv,
p_mrf.current_cd_abn
;

analyze edw_stg_dm_efftp.pre_move_mrf_1_prt_p000151;  -- TODO change schema to STG_DM_EFFTP
--select edw_utl.analyze_etl_tables('edw_b2c.pre_move_mrf');

---- step 11.3 update by PRE_MOVE_MRF
update edw_stg_dm_efftp.TFCT_OO_EFF_TP_1_prt_p000151 tp
set move_mrf = xx.move_mrf
from
edw_stg_dm_efftp.pre_move_mrf_1_prt_p000151 xx  -- TODO change schema to STG_DM_EFFTP
where 1 = 1
and tp.p1_period = to_number(to_char(date_trunc('month', to_date('20190601', 'YYYYMMDD')), 'YYYYMM'), '999999')
and xx.current_customer_id=(case when tp.customer_id is not null then tp.customer_id else tp.account end)
and xx.current_period=tp.p1_period
and xx.current_mrf=tp.p2_mrf_id
and xx.current_serv=tp.serv_id
and xx.current_cd_abn=tp.abn_id
and xx.src_id=tp.src_id
;

---- step 11.2 truncate PRE_MOVE_MRF
truncate table edw_stg_dm_efftp.pre_move_mrf_1_prt_p000151  -- TODO change schema to STG_DM_EFFTP
;

-- step 12 traff SHPD 12
update edw_stg_dm_efftp.TFCT_OO_EFF_TP_1_prt_p000151 tp
set P32_TRAF_IN_SHPD = t12.SHPD_COUNT_TRAFFIC
from
(
select ABN_ID,
mrf_id,
to_number(to_char(date_trunc('month', t.period), 'YYYYMM'), '999999') period,
ROUND(((sum(t.COUNT_TRAFFIC))/1024/1024), 2)  as SHPD_COUNT_TRAFFIC
from edw_ods.t_000158_cx_iqm_traffic_shpd t
where 1 = 1
and t.mrf_id = 12
and t.TRAFFIC_TYPE = '0'
and date_trunc('month', t.period) = date_trunc('month', to_date('20190601', 'YYYYMMDD'))
and t.tech_dt = (date_trunc('month', to_date('20190601', 'YYYYMMDD')))::timestamp
group by ABN_ID,
mrf_id,
to_number(to_char(date_trunc('month', t.period), 'YYYYMM'), '999999')
) t12
where 1 = 1
and tp.p1_period = to_number(to_char(date_trunc('month', to_date('20190601', 'YYYYMMDD')), 'YYYYMM'), '999999')
and t12.PERIOD = tp.p1_period
and tp.p2_MRF_ID = 12
and t12.MRF_ID = tp.p2_MRF_ID
and tp.serv_id = 2
and t12.ABN_ID = to_number(tp.subs_ID, '9999999999999999999999999')
;

--step 13 traff shpd/iptv ALL

----step 13.1 truncate pre_traff_shpd_iptv
truncate table edw_stg_dm_efftp.pre_traff_shpd_iptv_1_prt_p000151 -- TODO change schema to STG_DM_EFFTP
;

----step 13.2 insert pre_traff_shpd_iptv  
insert into edw_stg_dm_efftp.pre_traff_shpd_iptv_1_prt_p000151  -- TODO change schema to STG_DM_EFFTP
(
abn_id,
p1_period,
p2_mrf_id,
p32_traf_in_shpd,
p69_traf_in_iptv,
src_id
)
select abn_id, p1_period, p2_mrf_id, sum(p32_traf_in_shpd) p32_traf_in_shpd, sum(p69_traf_in_iptv) p69_traf_in_iptv, src_id
from (
with shpd as /*Расчёт ШПД*/
(SELECT /*bba.account_key,*/ -- убираем из-за замножения строк
bba.year_month_key,
dac.account_name,
SUM(bba.total_download_data_volume) as shpd_sum
FROM edw_ads.tfct_bba_consumption as bba
INNER JOIN (SELECT service_key
FROM edw_ads.dim_service
WHERE business_service_key IN ('10201', '10202', '10203')
GROUP BY service_key) as t1
ON bba.service_key = t1.service_key
INNER JOIN edw_ads.dim_account as dac
ON dac.account_key = bba.account_key
AND dac.branch_key = bba.branch_key
where 1 = 1
and bba.year_month_key = to_char(date_trunc('month', to_date('20190601', 'YYYYMMDD')), 'YYYYMM')
GROUP BY /*bba.account_key,*/ bba.year_month_key, dac.account_name),

iptv as /*Расчёт IPTV*/
(SELECT /*bba.account_key,*/ -- убираем из-за замножения строк
bba.year_month_key,
dac.account_name,
SUM(bba.total_download_data_volume) as iptv_sum
FROM edw_ads.tfct_bba_consumption bba
INNER JOIN (SELECT service_key
FROM edw_ads.dim_service
WHERE business_service_key = '10401'
GROUP BY service_key) as t1
ON bba.service_key = t1.service_key
INNER JOIN edw_ads.dim_account as dac
ON dac.account_key = bba.account_key
AND dac.branch_key = bba.branch_key
where 1 = 1
and bba.year_month_key = to_char(date_trunc('month', to_date('20190601', 'YYYYMMDD')), 'YYYYMM')
GROUP BY /*bba.account_key,*/ bba.year_month_key, dac.account_name)

select
distinct
tp.abn_id,
tp.p1_period,
tp.p2_mrf_id,
case
when count(subs_id) over(partition by tp.account, tp.p1_period, tp.p3_rf_id, tp.serv_id) > 0 then
case
when round(shpd.shpd_sum / count(subs_id) over(partition by tp.account, tp.p1_period, tp.p3_rf_id, tp.serv_id), 5) is null then 0
else round(shpd.shpd_sum / count(subs_id) over(partition by tp.account, tp.p1_period, tp.p3_rf_id, tp.serv_id), 5)
end
else 0
end as P32_TRAF_IN_SHPD,
case
when count(subs_id) over(partition by tp.account, tp.p1_period, tp.p3_rf_id, tp.serv_id) > 0 then
case
when round(iptv.iptv_sum / count(subs_id) over(partition by tp.account, tp.p1_period, tp.p3_rf_id, tp.serv_id), 5) is null then 0
else round(iptv.iptv_sum / count(subs_id) over(partition by tp.account, tp.p1_period, tp.p3_rf_id, tp.serv_id), 5)
end
else 0
end P69_TRAF_IN_IPTV,
to_number('000151', '999999') src_id

from edw_stg_dm_efftp.TFCT_OO_EFF_TP_1_prt_p000151 tp

left join --edw_ods.t_000132_south_nls_account snls
(select account, nls, row_number() over (partition by account order by date_begin desc) as rn
           from edw_ods.t_000158_efftp_south_nls_accnt snls
		   where 1=1
		   and snls.mrf_id=14
		   and snls.date_begin<= date_trunc('month', to_date('20190601', 'YYYYMMDD')::timestamp) + interval '1 month -1 day' ---Последний день отчетного периода
           and coalesce(snls.date_end,current_date::timestamp)>= date_trunc('month', to_date('20190601', 'YYYYMMDD')::timestamp) ---Первый день отчетного периода
          )snls 
on 1 = 1
and snls.account = tp.account
--and snls.mrf_id = tp.p2_mrf_id
and tp.p2_mrf_id = 14
and tp.serv_id in (2, 3)
and snls.rn=1

left join shpd
on 1 = 1
and case when tp.p2_mrf_id = 14 then snls.nls else tp.account end = shpd.account_name
and tp.p1_period = to_number(shpd.year_month_key, '999999')
and tp.serv_id = 2

left join iptv
on 1 = 1
and case when tp.p2_mrf_id = 14 then snls.nls else tp.account end = iptv.account_name
and tp.p1_period = to_number(iptv.year_month_key, '999999')
and tp.serv_id = 3

where tp.P1_PERIOD = to_number(to_char(date_trunc('month', to_date('20190601', 'YYYYMMDD')), 'YYYYMM'), '999999')
and tp.p2_mrf_id <> 12
) xxx 
group by abn_id, p1_period, p2_mrf_id, src_id
;

analyze edw_stg_dm_efftp.pre_traff_shpd_iptv_1_prt_p000151;  -- TODO change schema to STG_DM_EFFTP
--select edw_utl.analyze_etl_tables('edw_b2c.pre_traff_shpd_iptv');

----step 13.3 update by pre_traff_shpd_iptv
update edw_stg_dm_efftp.TFCT_OO_EFF_TP_1_prt_p000151 tp
set
P32_TRAF_IN_SHPD = tr.P32_TRAF_IN_SHPD,
P69_TRAF_IN_IPTV = tr.P69_TRAF_IN_IPTV
from edw_stg_dm_efftp.pre_traff_shpd_iptv_1_prt_p000151 tr  -- TODO change schema to STG_DM_EFFTP
where 1 = 1
and tp.abn_id = tr.abn_id
and tp.p1_period = tr.p1_period
and tp.p2_mrf_id = tr.p2_mrf_id
and tp.src_id = tr.src_id
and tp.P1_PERIOD = to_number(to_char(date_trunc('month', to_date('20190601', 'YYYYMMDD')), 'YYYYMM'), '999999')
and tp.p2_mrf_id <> 12
; 

----step 13.4 truncate pre_traff_shpd_iptv
truncate table edw_stg_dm_efftp.pre_traff_shpd_iptv_1_prt_p000151 -- TODO change schema to STG_DM_EFFTP
;
