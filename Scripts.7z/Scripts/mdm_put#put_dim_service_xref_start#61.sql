/*rev. 22.04.2020*/
delete from edw_stg_mdm.put_dim_service_xref_start where region_id = 'CENTER' and src_id = 000061;
--48-62
insert into edw_stg_mdm.put_dim_service_xref_start 
(
	service_key
	,service_name
	,service_rtk_detail_key
	,technology_type_key
	,region_id
	,src_id
)
 with svr as
(
	select 
		tslb.svc_id,
		ors.oebs_charge_code,
		substr(split_part(ors.oebs_charge_code, ' ',1),strpos(ors.oebs_charge_code,'R'),100) r12,
		row_number() over(partition by tslb.svc_id order by tslb.date_change desc) as key
	from edw_ods.t_000061_ors_charge_code   ors
	join	edw_ods.t_000061_t_svc_layer_bunch  tslb 
		on  tslb.id_Cell_svc = ors.id_Cell_svc
		and to_date(substr('20190630', 1, 8),'YYYYMMDD') + INTERVAL '1 day - 1 second'  + interval '7 days'  between tslb.eff_dttm and tslb.exp_dttm
		and tslb.deleted_ind = 0
)
select  
	t_svc_ref.svc_id::numeric(30) code,
	substr( t_svc_ref.full_name,0,1100) service_name,
	svr.r12 service_rtk_detail_key,
	case when upper(t_svc_ref.full_name) like '%TTH%' then 'ETTH'
            when upper(t_svc_ref.full_name) like '%PON%' then 'GPON'
		    when upper(t_svc_ref.full_name) like '%FTT%' then 'FTTb'
		    when upper(t_svc_ref.full_name) like '%MMDS%' then 'MMDS'
		    when upper(t_svc_ref.full_name) like '%CDMA%' then 'CDMA/GSM/3G/LTE'
		    when upper(t_svc_ref.full_name) like '%GSM%' then 'CDMA/GSM/3G/LTE'
			  --when upper(t_svc_ref.name) like '%3G%' then 'CDMA/GSM/3G/LTE'
		    when upper(t_svc_ref.full_name) like '%LTE%' then 'CDMA/GSM/3G/LTE'
		    when upper(t_svc_ref.full_name) like '%ETHERNET%' then 'ETHERNET'
		    when upper(t_svc_ref.full_name) like '%ISDN%' then 'Dial+ISDN'
		    when upper(t_svc_ref.full_name) like '%DIAL%' then 'Dial+ISDN'
		    when upper(t_svc_ref.full_name) like '%SHDSL%' then 'SHDSL'
            when upper(t_svc_ref.full_name) like '%DSL%' then 'XDSL'
		    when upper(t_svc_ref.full_name) like '%WI-FI%' then 'WiFi/WiMax'
		    when upper(t_svc_ref.full_name) like '%WIFI%' then 'WiFi/WiMax'
            when upper(t_svc_ref.full_name) like '%БШПД%' then 'БШПД'
		    when upper(t_svc_ref.full_name) like '%ШПД%' then 'ШПД'
			  --when upper(t_svc_ref.name) like '%РАДИО%' then 'Радиодоступ'
		    when upper(t_svc_ref.full_name) like '% ПРОВОД%' then 'Проводная'
        end technology_type_key	,
	'CENTER' as region_id,
	src_id
from edw_ods.t_000061_t_svc_ref t_svc_ref
left join svr 
    on t_svc_ref.svc_id = svr.svc_id and svr.key = 1 
where t_svc_ref.deleted_ind = 0
	and to_date(substr('20190630', 1, 8),'YYYYMMDD') + INTERVAL '1 day - 1 second'  + interval '7 days'  between t_svc_ref.eff_dttm and t_svc_ref.exp_dttm	
;
commit;
analyse edw_stg_mdm.put_dim_service_xref_start;  
