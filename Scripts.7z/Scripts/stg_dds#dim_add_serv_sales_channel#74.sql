/*rev.48952 от 08.02.2020*/
set optimizer=on;  

truncate table edw_stg_dds.t_000074_dim_add_serv_sales_channel;
insert into edw_stg_dds.t_000074_dim_add_serv_sales_channel
(
    add_serv_sc_key
  , start_date
  , oper_id
  , oper_name
  , mrf_service_key
  , product_name
  , mrf_add_service_name
  , account_name
  , service_key
  , dop_service_key
  , sales_channel_key
  , sales_channel
  , init_system
  , branch_key
  , src_id
)
with av_startip as
  (
    select
        sq4.ab_id||'#'||sq4.uss_logname||'#'||to_char(sq4.jn_datetime,'YYYYMMDDHH24MISS')||'#'||sq4.user_name||'#'||sq4.service_key as add_serv_sc_key
      , ab_account
      , uss_logname
      , sq4.service_key
      , srd_name
      , opt_id
      , sq4.jn_datetime
      , sq4.src_id
      , tu1.dept_id
    from
      (
        select
            sq3.*
          , elk_or.eor_srd_code
          , upper(tsd.srd_code||'#'||tsd.srd_int_code||'#') as service_key
          , abon.ab_account
          , tsd.srd_name
        from
          edw_ods.t_000074_elk_user_serv_opt_log sq3
          left join
            (
              select
                  eor_srd_code
                , elk_opt_id
                , eor_int_code
                , row_number() over (partition by elk_opt_id order by tech_dt desc) as or_rn
              from
                edw_ods.t_000074_elk_opt_ref
            ) elk_or
              on elk_or.elk_opt_id=sq3.opt_id
              and elk_or.or_rn=1
          left join
            edw_ods.t_000074_TB_SERV_DEFS tsd
              on tsd.srd_code=elk_or.eor_srd_code
              and tsd.srd_int_code=elk_or.eor_int_code
              and tsd.exp_dttm=to_date('29991231', 'YYYYMMDD')
          left join
            edw_ods.t_000074_abonent abon
              on abon.ab_id=sq3.ab_id
              and abon.exp_dttm=to_date('29991231', 'YYYYMMDD')
              and abon.ab_account NOT SIMILAR TO '%[^0-9]%' --исключаем некорректные лицевые счета
        where
          sq3.src_id=000074
          and sq3.opt_status='ON'
      ) sq4 
      left join
        edw_ods.t_000058_t_users tu1
          on tu1.account=sq4.ab_account
          and tu1.exp_dttm=to_date('29991231', 'YYYYMMDD')
    where
      tu1.iscorp='N'
  ),
sal_ch as
  (
    select
        account
      , id_number
      , optname
      , optid
      , creation_time
      , dat_podkl
      , order_id
      , status
      , resh
      , kanal
      , login_operator
      , fio_operator
    from
      (
        select 
            ktpo.account
          , a.id_number
          , ktpo.optname
          , ktpo.optid
          , a.creation_time
          , case
              when casests2gbst_elm=31
                then
                  case
                    when a.CASE_TYPE_LVL1 = 'Продажа'
                      then a.modify_stmp
                    else
                      case
                        when a.CASE_TYPE_LVL1 = 'Управление опциями' and coalesce(g1.title,' ')<>'Отказ.Дубликат' and ktpo.Acttype = 'ON'
                          then a.modify_stmp
                        else null
                      end
                  end 
              else null
            end dat_podkl
          , case
              when ktpo.opt2order is not null
                then a.id_number
              else null
            end order_id
          , ktpo.status
          , case
              when ktpo.opt2order is not null
                then g1.title
              else null
            end resh
          , h1.title kanal
          , upper(coalesce(ktp2.login,ktp.login,u0.login_name,'')) as login_operator
          , coalesce(e.last_name,'')||' '||coalesce(e.first_name,'')||' '||coalesce(e.x_middle_name,'') fio_operator
          , row_number() over (partition by ktpo.account,ktpo.optid
                                          , date_trunc('day',case
                                                               when casests2gbst_elm=31
                                                                 then
                                                                   case
                                                                     when a.CASE_TYPE_LVL1 = 'Продажа'
                                                                       then a.modify_stmp
                                                                     else
                                                                       case
                                                                         when a.CASE_TYPE_LVL1 = 'Управление опциями' and coalesce(g1.title,' ')<>'Отказ.Дубликат' and ktpo.Acttype = 'ON'
                                                                           then a.modify_stmp
                                                                         else null
                                                                       end
                                                                   end 
                                                               else null
                                                             end)
                               order by ktpo.id desc) as rn
        from
          edw_ods.t_000044_ktp_order_option ktpo
          join
            edw_ods.t_000044_table_case a
              on a.objid=ktpo.opt2case
          left outer join
            edw_ods.t_000044_table_close_case tcc
              on tcc. last_close2case=a.objid
          left outer join
            edw_ods.t_000044_table_gbst_elm g1
              on g1.objid=tcc.close_rsolut2gbst_elm
          left outer join
            edw_ods.t_000044_table_customer cu
              on cu.x_bankbook_id=ktpo.account
          left outer join
            edw_ods.t_000044_table_hgbst_elm h1
              on coalesce(ktpo.opt2channel,a.x_case_type2hgbst_elm)=h1.objid

          left outer join
            edw_ods.t_000044_table_ktp_order ktp
              on ktp.id=ktpo.opt2order
          left outer join
            edw_ods.t_000044_ktp_order  ktp2
              on ktp2.id=ktpo.OPT2ORDER_EPC
          left outer join
            edw_ods.t_000044_table_user u0
              on u0.objid=a.case_originator2user
          left outer join
            edw_ods.t_000044_table_user u
              on u.s_login_name=upper(coalesce(ktp2.login,ktp.login,u0.login_name,''))
          left outer join
            edw_ods.t_000044_table_employee e
              on e.employee2user=u.objid
        where
          ktpo.status is not null
          and
            (
              a.CASE_TYPE_LVL1 = 'Продажа'
              or
              ( a.CASE_TYPE_LVL1 <> 'Продажа' and coalesce(g1.title,' ')<>'Отказ.Дубликат' and ktpo.Acttype = 'ON')
            )
      ) t
    where rn=1
  )
select
    av.add_serv_sc_key
  , ch.dat_podkl as start_date
  , ch.login_operator as oper_id
  , fio_operator as oper_name
  , av.service_key as mrf_service_key
  , substring(av.opt_id,'.{6}$') as product_name
  , av.srd_name as mrf_add_service_name
  , av.ab_account::numeric as account_name
  , av.service_key as service_key
  , av.service_key as dop_service_key 
  , regexp_replace(trim(upper(ch.kanal)),'[ ]+',' ','g') as sales_channel_key 
  , ch.kanal as sales_channel
  , 'CRM' as init_system
  , av.dept_id as branch_key
  , 000074 as src_id
from
  av_startip av
join
  sal_ch ch
    on av.ab_account=ch.account
    and av.opt_id=ch.optid
    and date_trunc('day',av.jn_datetime) = date_trunc('day',ch.dat_podkl)
;

analyze edw_stg_dds.t_000074_dim_add_serv_sales_channel;

