/*rev. 09.12.2019*/

truncate table edw_stg_dds.t_000038_tfct_total_charge;
insert into edw_stg_dds.t_000038_tfct_total_charge
(
  total_charge_key,    -- Идентификатор начисления, учитывающие общую сумму начислений
  subs_key,       -- Ссылка на справочник t_000038_dim_SUBSCRIBER (""""""""Абонент"""""""").
  charge_period_start_dttm,  -- Дата начала периода действия начисления
  charge_period_end_dttm,
  charge_rub,     -- Сумма начисления в рублях (без НДС), с учетом всех скидок по данному начислению
  vat_rub,     -- НДС
  service_key,     -- Идентификатор услуги
  account_key,
  src_id,
  charge_date,    -- Дата начисления
  rc_key,
  EFF_DTTM,
  EXP_DTTM
)
  select
    t.total_charge_key,
    decode(t.subs_key26,'-1',t.subs_key,t.subs_key26) as subs_key,
    t.charge_period_start_dttm,
    t.charge_period_end_dttm,
    t.charge_rub,
    t.vat_rub,
    t.service_key,
    t.account_key,
    t.src_id,
    t.charge_date,--дата определения инкремента по начислениями
    t.rc_key,
    '19000101'::timestamp as EFF_DTTM,
    '29991231'::timestamp as EXP_DTTM

  FROM (
         select
           charge_period_start_dttm,
           charge_period_end_dttm,
           src_id||';'||subs_key::text as subs_key,
           total_charge_key,
           service_key,
           account_key,
           charge_date,
           charge_rub,
           vat_rub,
           src_id,
           rc_key,
           subs_key26::text
         from(

               select
                 tperiod.DFDATEBEGIN as charge_period_start_dttm,
                 tperiod.dfdateend as charge_period_end_dttm,

                 case
                 when tservconst.DFSERVCONSTMASTER is null then tservconst.DFSERVCONST
                 when tservconst2.DFSERVCONSTMASTER is null then tservconst2.DFSERVCONST
                 else -1
                 end  as subs_key,
                 tservnach.src_id||';'||tservnach.DFSERVNACH::numeric(38,0)  as total_charge_key,
                 tservnach.src_id||';'||tservnach.DFSERVICE::numeric(38,0) as service_key,
                 tservnach.src_id||';'||tservnach.dfdogovor::numeric(38,0) account_key,
                 tservnach.DFDATEBEGIN as charge_date,
                 DECODE( tservnach.DFNDSINOUT ,'T', tservnach.DFSUMMA-tservnach.DFNDSSUMMA,tservnach.DFSUMMA) as charge_rub,
                 tservnach.DFNDSSUMMA as vat_rub,
                 tservnach.src_id,
                 coalesce(subs26.subs_key,'-1') as subs_key26,
                 coalesce(tdopcs.dfcfo_segment::numeric(38),'-1') as rc_key,
                 row_number() over(partition by tservnach.DFSERVNACH order by coalesce(subs26.subs_key,'-1')) as rn
               from
                 edw_ods.t_000038_tservnach tservnach
                 inner join edw_ods.t_000038_tperiod tperiod on tperiod.dfperiod = tservnach.dfperiod

                 -- Для исключения начисления из Онимы !!!ИСКЛЮЧЕНИЯ ПОКА ОКОНЧАТЕЛЬНО НЕ УТВЕРЖДЕНЫ!!!
                 --left join edw_ods.t_000038_tonenach tonenach on tservnach.dfonenach = tonenach.dfonenach

                 -- """"""""Для определения абонента нужно получать идентификатор основной услуги (где DFSERVCONSTMASTER is null)
                 left join edw_ods.t_000038_tservconst tservconst 
     on tservnach.DFSERVCONST = tservconst.DFSERVCONST
                    and (coalesce(tservconst.DFDELETE,'')<>'T') and (coalesce(tservconst.DFCONDITION,'')<>'T') and (coalesce(tservconst.DFCONDITION,'')<>'Т') and tservconst.deleted_ind=0
                 left join edw_ods.t_000038_tservconst tservconst2  
     on tservconst.DFSERVCONSTMASTER = tservconst2.DFSERVCONST
                     and (coalesce(tservconst2.DFDELETE,'')<>'T') and (coalesce(tservconst2.DFCONDITION,'')<>'T') and (coalesce(tservconst2.DFCONDITION,'')<>'Т') and tservconst2.deleted_ind=0
                 left join edw_ods.t_000038_tdogovor tdogovor 
     on tdogovor.DFDOGOVOR = tservnach.DFDOGOVOR and tdogovor.deleted_ind=0
                 left join edw_stg_dds.t_000026_dim_subs subs26 
     on subs26.account_key=tservnach.src_id||';'||tservnach.DFDOGOVOR::numeric(38)
                   and date_trunc('DAY',tservnach.DFDATEBEGIN) between subs26.start_date and subs26.end_date
                 left join edw_ods.t_000038_TDOG_CFO_SEGMENT tdogcs 
     on tdogcs.DFDOGOVOR=tservnach.DFDOGOVOR
                   and tservnach.DFDATEBEGIN between tdogcs.dfdatebegin and coalesce(tdogcs.dfdateend,'29991231')
                 left join edw_ods.t_000038_TDOP_CFO_SEGMENT tdopcs 
     on tdogcs.DFDOP_CFO_SEGMENT = tdopcs.DFDOP_CFO_SEGMENT
               where
                 tservnach.dfdebetcredit <> 1 -- исключение оплат
                 and tservnach.DFOPLATA IS NULL
                 and tservnach.dfdatebegin between tperiod.dfdatebegin and tperiod.dfdateend -- исключение корректировок
                 and (tservnach.DFNDSSUMMA <> 0  or tservnach.DFSUMMA <> 0)
                 and tservnach.deleted_ind=0
                 and tperiod.deleted_ind=0
                 and date_trunc('DAY',tservnach.DFDATEBEGIN)  between to_date('20190601', 'YYYYMMDD') and to_date('20190630', 'YYYYMMDD')
               --and trim(coalesce(tonenach.dfonyma_name,''))='' -- исключаем начисления из Онимы !!!ИСКЛЮЧЕНИЯ ПОКА ОКОНЧАТЕЛЬНО НЕ УТВЕРЖДЕНЫ!!!
               --and lnk.dflpg_type in (1,7,8,9,10,11,12,64,14,15,83,184,204,205)
             )t
         where rn=1
       )t
    left join edw_ods.t_000038_tdogovor tdogovor on tdogovor.src_id||';'||tdogovor.dfdogovor::numeric(38)=t.account_key
    left join edw_stg_dds.t_kurs_group_filter_lts lts on lts.dflinepartgroup=tdogovor.dflinepartgroup
  where coalesce(lts.exept,0)=0;
commit;
analyze edw_stg_dds.t_000038_tfct_total_charge;