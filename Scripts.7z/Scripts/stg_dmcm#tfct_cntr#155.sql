--rev. 59381 от 29.05.2020
truncate table edw_stg_dmcm.tfct_cntr_1_prt_p000155;
commit;
insert into edw_stg_dmcm.tfct_cntr_1_prt_p000155
  ( 
    cm_id         ,
    mrf_id        ,
    rf_id         ,
    cntrct_id     ,
    cntrct_n      ,
    dt_start_cntr ,
    cntr_status   ,
    dt_end_cntr   ,
    accn_cnt      ,
    eff_dttm      ,
    exp_dttm      ,
    load_dttm     ,
    src_id
  )
-- Если при недельном рассчете начало и конец находятся в разных месяцах необходимо, чтобы данные продублировались с разыми eff_dttm и  exp_dttm
with eff_exp_dates as ( 
  select 
    date_trunc('month', to_date('20190601', 'yyyymmdd')) as eff_dttm,
    date_trunc('month', to_date('20190601', 'yyyymmdd'))+ interval '1 month - 1 second'  as exp_dttm
  union
  select 
    date_trunc('month', to_date('20190630', 'yyyymmdd')) as eff_dttm,
    date_trunc('month', to_date('20190630', 'yyyymmdd'))+ interval '1 month - 1 second'  as exp_dttm
)  
select distinct
  coalesce(cntr.cm_id,          cntr_prev.cm_id)         as cm_id,
  coalesce(cntr.mrf_id,         cntr_prev.mrf_id)        as mrf_id,
  coalesce(cntr.rf_id,          cntr_prev.rf_id)         as rf_id,
  coalesce(cntr.cntrct_id,      cntr_prev.cntrct_id)     as cntrct_id,
  coalesce(cntr.cntrct_n,       cntr_prev.cntrct_n)      as cntrct_n,
  coalesce(cntr.dt_start_cntr,  cntr_prev.dt_start_cntr) as dt_start_cntr,
  coalesce(cntr.cntr_status,    0)                       as cntr_status,
  coalesce(cntr.dt_end_cntr,    cntr_prev.dt_end_cntr)   as dt_end_cntr,
  1                                                      as accn_cnt,
  d.eff_dttm    ,
  d.exp_dttm    ,
  now()         as load_dttm       ,
  000155  as src_id
from
  (
    select
      cm_id         ,
      mrf_id        ,
      rf_id         ,
      cntrct_id     ,
      cntrct_n      ,
      dt_start_cntr ,
      cntr_status   , 
      dt_end_cntr   ,
      row_number() over (partition by cntrct_id order by cntrct_n desc) rn
    from 
      (
        select distinct
          coalesce(oo_eff_tp.hflat, '-'||nls_acc.nls, '-'||oo_eff_tp.account)                                         as cm_id  ,
          oo_eff_tp.p2_mrf_id                                                                                         as mrf_id ,
          oo_eff_tp.p3_rf_id                                                                                          as rf_id  ,
          oo_eff_tp.p2_mrf_id||'#'||coalesce(nls_acc.nls, oo_eff_tp.account)||'#'||coalesce(subscribers.clie_id, '')  as cntrct_id     ,
          coalesce(subscribers.contr_num, '')                                                                         as cntrct_n      ,
          coalesce(subscribers.data_contr, date '1900-01-01')                                                         as dt_start_cntr ,
          case
            when max(subscribers.account) over (partition by coalesce(nls_acc.nls, oo_eff_tp.account)) is not null
              then 1
              else 0
          end                                                                                                         as cntr_status , 
          max(coalesce(subscribers.data_close, date '2999-12-31')) over (partition by subscribers.contr_id)           as dt_end_cntr
        from
          (
            select distinct
              oo_eff_tp.p2_mrf_id ,
              case when oo_eff_tp.p3_rf_id in (1316) then 1314 else oo_eff_tp.p3_rf_id end as p3_rf_id,
              oo_eff_tp.account   ,
              oo_eff_tp.hflat     
            from
              edw_ods.t_000155_efftp_oo_eff_tp oo_eff_tp
              inner join
                (
                  select
                    abn_id  ,
                    serv_id ,
                    row_number() over (partition by abn_id order by serv_id desc) as rn
                  from
                    (
                      select
                        abn_id ,
                        serv_id
                      from
                        edw_ods.t_000155_efftp_oo_eff_tp oo_eff_tp
                      where
                        oo_eff_tp.tech_dt =(select max(oo_eff_tp.tech_dt) from edw_ods.t_000155_efftp_oo_eff_tp oo_eff_tp where oo_eff_tp.tech_dt<=to_date('20190601', 'yyyymmdd'))
                      group by
                        abn_id,
                        serv_id
                    )
                    s
                )
                t2
                on
                  oo_eff_tp.abn_id      = t2.abn_id
                  and oo_eff_tp.serv_id = t2.serv_id
                  and t2.rn             = 1
            where
              oo_eff_tp.tech_dt = (select max(oo_eff_tp.tech_dt) from edw_ods.t_000155_efftp_oo_eff_tp oo_eff_tp  where oo_eff_tp.tech_dt<=to_date('20190601', 'yyyymmdd'))
              and oo_eff_tp.serv_id in (1,2,3)
              and oo_eff_tp.abn_id  is not null
              and oo_eff_tp.account is not null
              and
              (
                oo_eff_tp.date_close         >= date_trunc('month', to_date('20190601', 'yyyymmdd'))
                or oo_eff_tp.date_close is null
              )
          )
          oo_eff_tp
          left join
            (
              select distinct
                client.account      ,
                client.contr_id     ,
                client.contr_num    ,
                client.data_contr   ,
                client.contr_status ,
                client.data_close   ,
                client.clie_id        
                from
                (
                  select
                    client_dwh.account      ,
                    client_dwh.contr_id     ,
                    client_dwh.rf_id        ,
                    client_dwh.contr_num    ,
                    client_dwh.data_contr   ,
                    client_dwh.contr_status ,
                    client_dwh.data_close   ,
                    client_dwh.clie_id      ,
                    row_number() over (partition by account,clie_id order by coalesce(data_contr, '1900-01-01'::date) desc) as rn
                  from
                    edw_ods.t_000155_rprt_client_dwh client_dwh
                  where
                    client_dwh.account is not null
                    and client_dwh.clie_id is not null
                    and rf_id is not null
                )
                client
                inner join 
                (
                  select distinct 
                    clnt_id as clnt_clie_id,
                    account,
                    rf_id
                  from
                    edw_ods.t_000155_RPRTSUBSCRIBERSACTUAL sub
                  where
                    serv_id in (1,2,3)
                    and coalesce(data_close_serv, to_date('29991231', 'yyyymmdd')) >= to_date('20190601', 'yyyymmdd') + interval '1 month'
                    and data_connect <= to_date('20190601', 'yyyymmdd') + interval '2 month - 1 second'
                    and abn_id is not null
                    and clnt_id is not null
                    and account is not null
                    and rf_id is not null
                    and 000155 != 154
                  union all
                  select distinct 
                    clie_id as clnt_clie_id,
                    account,
                    rf_id
                  from
                    edw_ods.t_000155_RPRTSUBSCRIBERSACTUAL sub
                  where
                    serv_id in (1,2,3)
                    and coalesce(data_close_serv, to_date('29991231', 'yyyymmdd')) >= to_date('20190601', 'yyyymmdd') + interval '1 month'
                    and data_connect <= to_date('20190601', 'yyyymmdd') + interval '2 month - 1 second'
                    and abn_id is not null
                    and clie_id is not null
                    and account is not null
                    and rf_id is not null
                    and 000155 = 154 
                ) sub 
                on 
                  sub.clnt_clie_id = client.clie_id 
                  and sub.account = client.account
                  and sub.rf_id = client.rf_id
                where 
                  rn=1
                  and to_date('20190630', 'yyyymmdd')>now() -- Загрузка за текущий месяц
                
                union all
                
                select distinct
                  account      ,
                  contr_id     ,
                  contr_num    ,
                  data_contr   ,
                  contr_status ,
                  data_close   ,
                  clie_id
                from 
                  edw_dmcm.tfct_cntr_hist_1_prt_p000155
                where 
                  --cntr_dttm=to_date('20190601', 'yyyymmdd') --cntr_dttm=eff_dttm+ 1 месяц
                  eff_dttm=to_date('20190601', 'yyyymmdd')- interval '1 month'
                  and to_date('20190630', 'yyyymmdd')<now() -- Загрузка за предыдущий месяц. берется история из tfct_cntr_hist
            )
            subscribers
            on
              oo_eff_tp.account = subscribers.account
          left join
            (
              select
                account    ,
                nls        ,
                rf_id      ,
                mrf_id     ,
                date_begin ,
                coalesce(lead (date_begin,1) over (
                                                 partition by account
                                                 order by
                                                   date_end)- interval '1 second' ,date_end, date '2999-12-31') as date_end
              from
                edw_ods.t_000158_efftp_south_nls_accnt
              where
                account is not null
                and date_begin   <= to_date('20190601', 'yyyymmdd') + interval '1 month - 1 second'
                and 000155 = 154
            )
            nls_acc
            on
              nls_acc.rf_id       = oo_eff_tp.p3_rf_id
              and nls_acc.mrf_id  = oo_eff_tp.p2_mrf_id
              and nls_acc.account = oo_eff_tp.account
              and to_date('20190601', 'yyyymmdd') + interval '1 month - 1 second' between nls_acc.date_begin and nls_acc.date_end
      ) x
  )
  cntr
  full join
    (
      select
        cm_id,
        mrf_id,
        rf_id,
        cntrct_id,
        cntrct_n,
        dt_start_cntr,
        dt_end_cntr
      from 
        edw_dmcm.tfct_cntr_1_prt_p000155
      where 
        to_date('20190630', 'yyyymmdd')>now() --Только для еженедельных загрузок
        and eff_dttm =(select max(ch.eff_dttm) from edw_dmcm.tfct_cntr_hist_1_prt_p000155 ch where ch.eff_dttm<=to_date('20190601', 'yyyymmdd')) -- Берем последний CNTR, который был загружен месячным датасетом. Определяем его по cntr_hist
    )
    cntr_prev
    on 
      cntr_prev.cm_id=cntr.cm_id
      and cntr_prev.rf_id=cntr.rf_id
      and cntr_prev.cntrct_id=cntr.cntrct_id
  inner join eff_exp_dates d on 1=1
  where coalesce (cntr.rn,1)=1
;
analyse edw_stg_dmcm.tfct_cntr_1_prt_p000155;  
 
