/*rev. от 27.04.2020*/

SET optimizer=on;
set gp_recursive_cte_prototype = on;

TRUNCATE TABLE EDW_STG_DDS.T_000127_PRE_MV_CRM_TERRITORY;

insert into EDW_STG_DDS.T_000127_PRE_MV_CRM_TERRITORY 
(ter_ext_id, type_name, ter_code, ter_name, lvl, rf_ter_ext_id, hier_type_nval, root_name, mrf_ter_ext_id, mrf_name, parent_ter_ext_id,rf_name, x_cpo_r12_code,src_id)

WITH
---- В следующем подзапросе реализована рекурсия
 RECURSIVE 
 tm (objid, name, type, par_objid, par_name, lvl, root_name, root_objid, mrf_name, mrf_objid, affiliate_name, affiliate_objid,x_cpo_r12_code, terr_id,src_id) as
(
select objid, name, type
     , par_objid
  , par_name
     , 1 as lvl
     , decode(type,'Root',name ,null) as root_name
     , decode(type,'Root',objid,null) as root_objid
     , decode(type,'Main',name ,null) as mrf_name
     , decode(type,'Main',objid,null) as mrf_objid
     , decode(type,'Affiliate',name ,null) as affiliate_name
     , decode(type,'Affiliate',objid,null) as affiliate_objid
  , x_cpo_r12_code
  , terr_id
  ,127 as src_id
from (select distinct ter.objid, ter.terr_id::text, ter.name, ter.type, tri.rol_parent2territory as par_objid, tr.name as par_name , ter.x_cpo_r12_code
from edw_ods.t_000127_SA_TABLE_TERRITORY ter
left join  edw_ods.t_000127_SA_TABLE_TER_ROL_ITM_VW tri on
     (ter.objid = tri.rol_child2territory and tri.path_type = 0 and tri.ter_itm2rollup = 2000)
  and tri.deleted_ind = 0
left join edw_ods.t_000127_SA_TABLE_TERRITORY tr on tr.objid = tri.rol_parent2territory 
and tr.deleted_ind = 0 
where ter.deleted_ind = 0 
) tmain 
where 1=1
  and par_objid is null
  and tmain.TYPE = 'Root'
union all
select tmain.objid, tmain.name, tmain.type
 , tmain.par_objid, tmain.par_name, tm.lvl+1
 , coalesce(tm.root_name ,decode(tmain.type,'Root',tmain.name))
 , coalesce(tm.root_objid,decode(tmain.type,'Root',tmain.objid))
 , coalesce(tm.mrf_name ,decode(tmain.type,'Main',tmain.name))
 , coalesce(tm.mrf_objid,decode(tmain.type,'Main',tmain.objid))
 , coalesce(tm.affiliate_name ,decode(tmain.type,'Affiliate',tmain.name))
 , coalesce(tm.affiliate_objid,decode(tmain.type,'Affiliate',tmain.objid))
 , tmain.x_cpo_r12_code
 , tmain.terr_id
 ,127 as src_id
from tm, (select distinct ter.objid, ter.terr_id::text, ter.name, ter.type, tri.rol_parent2territory as par_objid, tr.name as par_name , ter.x_cpo_r12_code
from edw_ods.t_000127_SA_TABLE_TERRITORY ter
left join  edw_ods.t_000127_SA_TABLE_TER_ROL_ITM_VW tri on
     (ter.objid = tri.rol_child2territory and tri.path_type = 0 and tri.ter_itm2rollup = 2000)
  and ter.deleted_ind = 0 
left join edw_ods.t_000127_SA_TABLE_TERRITORY tr on tr.objid = tri.rol_parent2territory
and tr.deleted_ind = 0
where ter.deleted_ind = 0 
) tmain 
where tm.objid = tmain.par_objid)

select 
objid as ter_ext_id,
type as type_name,
terr_id as ter_code,
regexp_replace(name, '[[:space:]]', ' ') as ter_name,
lvl, 
par_objid::numeric(38,0) as rf_ter_ext_id, 
root_objid as hier_type_nval, 
regexp_replace(root_name, '[[:space:]]', ' ') as root_name, 
mrf_objid as mrf_ter_ext_id, 
regexp_replace(coalesce(mrf_name, par_name), '[[:space:]]', ' ') as mrf_name, 
affiliate_objid as parent_ter_ext_id, 
regexp_replace(coalesce(affiliate_name, name), '[[:space:]]', ' ') as rf_name,
x_cpo_r12_code,
127 as src_id
from tm;
analyze EDW_STG_DDS.T_000127_PRE_MV_CRM_TERRITORY;




truncate table edw_stg_dds.t_000127_tfct_crm_fcr_topic;
insert into edw_stg_dds.t_000127_tfct_crm_fcr_topic
(
TOPIC_FCR_KEY
, INTR_OBJID
, HAS_CASE  
, HAS_SECONDARY
, IS_PRIMARY_FOR_CALL_CENTER
, HAS_DUPLICATING_CASE
, START_TIME
, END_TIME
, CLOSE_DATE
, X_INTRXN2FIN_ACCNT
, FAMILY
, REASON_1
, REASON_2
, IS_CALL_CENTER
, HASH_TOPIC_TYPE
, MRF_OBJID
, CURR_X_NUM
, PREV_X_NUM
, CURR_INTR_USER_KEY
, PREV_INTR_USER_KEY
, CASE_ID_NUMBER
, DUPLICATING_CASE_ID_NUMBER
, SRC_ID
)

WITH
PREP_INTRXN_TOPIC as
(
SELECT
             TOP.OBJID                                           AS TOPIC_OBJID,
             I.OBJID                                             AS INTRXN_OBJID,
             SP.OBJID                                            AS SP_OBJID,
             COALESCE(SP.X_SITE_PART2FIN_ACCNT, I.X_INTRXN2FIN_ACCNT) AS FA_OBJID,
             I.X_NUM,
             I.X_INTRXN2PART_NUM,
             I.X_INTRXN2FIN_ACCNT,
             I.START_TIME,
             I.END_TIME,
             I.TYPE,
             --I.DML_DTTM,
             I.DIRECTION,
             I.INTRXN2CONTACT,
             I.INTRXN2BUS_ORG,
             TOP.REASON_1,
             TOP.RESULT,
             SP.X_SITE_PART2FIN_ACCNT,
             SP.X_SITE_PART2X_LIST_SVC,
             SP.SERIAL_NO,
             SP.X_USSLOGIN,
             SP.INSTALL_DATE,
             SP.SERVICE_END_DT,
             SP.PART_STATUS,
             SP.SITE_PART2PART_INFO,
             SP.SITE_PART2CUSTOMER,
             I.X_INTRXN2TERRITORY,
             I.TITLE,
             NULLIF(CASE WHEN position(':' in TOP.X_SITE_PART_NAME) = 0
                           THEN TOP.X_SITE_PART_NAME
                         ELSE SUBSTR(TOP.X_SITE_PART_NAME, 
                         position(':' in TOP.X_SITE_PART_NAME) + 2)
                     end, 'Не определена') PART_NUMBER
         FROM EDW_ODS.T_000127_SA_TABLE_INTRXN I
         JOIN EDW_ODS.T_000127_SA_TABLE_TOPIC TOP
           ON I.OBJID = TOP.TOPIC2INTRXN
     AND TOP.DELETED_IND = 0
   LEFT JOIN EDW_ODS.T_000127_SA_TABLE_SITE_PART SP
           ON SP.OBJID = COALESCE(TOP.X_TOPIC2SITE_PART, I.X_INTRXN2SITE_PART)
     AND SP.DELETED_IND = 0
        WHERE I.DELETED_IND = 0 
  AND I.START_TIME >= TO_DATE('20190601', 'YYYYMMDD')
  AND I.START_TIME <  TO_DATE('20190630', 'YYYYMMDD') + INTERVAL'1 DAY - 1 SECOND'
    --AND I.DML_DTTM >= P_BEGIN_DT
    --AND I.DML_DTTM < P_END_DT) S
),

PREP_DELTA_FA AS (
  SELECT /*+ materialize */
    FA_OBJID
  FROM PREP_INTRXN_TOPIC
 WHERE UPPER(REASON_1) IN 
          ('АКЦИИ',
           'ЗАПРОС ИНФОРМАЦИИ',
           'ПРЕТЕНЗИЯ',
           'РАСЧЕТНОЕ ОБСЛУЖИВАНИЕ',
           'УПРАВЛЕНИЕ ДОГОВОРАМИ',
           'УПРАВЛЕНИЕ ОТТОКОМ',
           'УПРАВЛЕНИЕ УСЛУГАМИ',
           'КОНФИГУРАЦИЯ УСЛУГ',
           'ПОЛОЖИЛ ТРУБКУ ДО ОТВЕТА',
           'ТЕХПОДДЕРЖКА')
     AND UPPER(RESULT) <> 'СВЯЗАНО С ГП'
     AND DIRECTION = 1
     AND COALESCE(INTRXN2CONTACT, -2) NOT IN (1, -2)
     AND COALESCE(INTRXN2BUS_ORG, -2) IN     (0, -2)
     AND FA_OBJID IS NOT NULL 
     --AND DML_DTTM >= TO_DATE('#P_BEGIN_DATE#', '#$G_ORA_FORMAT_DTTM#')
     --AND DML_DTTM < TO_DATE('#P_END_DATE#', '#$G_ORA_FORMAT_DTTM#')
GROUP BY FA_OBJID

),

DELTA_FA as 
(
SELECT
     I.INTRXN_OBJID AS OBJID,  
     I.X_INTRXN2PART_NUM,
     I.FA_OBJID     AS X_INTRXN2FIN_ACCNT,
     I.START_TIME,
     I.END_TIME,
     I.TYPE,
     I.X_NUM,
     I.TOPIC_OBJID
   FROM PREP_DELTA_FA DELTA_FA
   JOIN PREP_INTRXN_TOPIC I
     ON DELTA_FA.FA_OBJID = I.FA_OBJID
  WHERE I.DIRECTION = 1
    AND I.FA_OBJID IS NOT NULL
    AND COALESCE(I.INTRXN2CONTACT, -2) NOT IN (1, -2)
    AND COALESCE(I.INTRXN2BUS_ORG, -2) IN     (0, -2)

    ),


PREP_TABLE_SESSION AS
(SELECT
 SESSION2INTRXN,
 --MIN(SESSION2USER) KEEP (DENSE_RANK FIRST ORDER BY END_TIME, OBJID) AS FIRST_USER_ID,--было
 (array_agg(SESSION2USER ORDER BY END_TIME, OBJID))[1] AS FIRST_USER_ID,--переписано для GP так
 --MAX(SESSION2USER) KEEP (DENSE_RANK LAST  ORDER BY END_TIME, OBJID) AS LAST_USER_ID --было
 (array_agg(SESSION2USER ORDER BY END_TIME desc, OBJID desc))[1] AS LAST_USER_ID --переписано для GP так
FROM edw_ods.t_000127_sa_table_session  
WHERE deleted_ind = 0         
GROUP BY SESSION2INTRXN

),

PREP_CHANNEL_INST AS
(select CHANNEL_INST2CHANNEL, CHANNEL_INST2INTRXN
          from (select CHANNEL_INST2CHANNEL,
                       CHANNEL_INST2INTRXN,
                       ROW_NUMBER() OVER(partition by CHANNEL_INST2INTRXN order by END_TIME desc, OBJID desc) RN
                  from EDW_ODS.T_000127_SA_TABLE_CHANNEL_INST_VW chan
                   where chan.deleted_ind = 0) T
         where RN = 1
),


PREP_TABLE_CLOSE_CASE as
(  
 select
              REF_TO_CS,
              CLOSE_RSOLUT2GBST_ELM,
              CASE_SOURCE_IND,
              CLOSE_DATE,
              CLOSER2EMPLOYEE,
              SUMMARY,
              ACCOUNT_CHANGED_ID_CVAL
    from (select COALESCE(CLS.LAST_CLOSE2CASE, CLS.CLOSE_CASE2SUBCASE) REF_TO_CS,
                 CLS.CLOSE_RSOLUT2GBST_ELM,
                 CASE
                   WHEN GL_STS.OBJID = 10 THEN
                     CLS.CLOSE_DATE
                   ELSE NULL
                 END CLOSE_DATE,
                 CASE
                   WHEN COALESCE(CLS.CLOSE_CASE2SUBCASE, SCS.X_CASE_SUBCASE2X_CASE) IS NULL THEN
                     1
                   ELSE
                     2
                 END CASE_SOURCE_IND,
                 CLS.CLOSER2EMPLOYEE,
                 CLS.SUMMARY,
                 SUBSTR(AE.ADDNL_INFO, 0, 32) ACCOUNT_CHANGED_ID_CVAL,
                 ROW_NUMBER() OVER(PARTITION BY (CASE WHEN COALESCE(CLS.CLOSE_CASE2SUBCASE, SCS.X_CASE_SUBCASE2X_CASE) IS NULL THEN 1 ELSE 2 END),
                           COALESCE(CLS.LAST_CLOSE2CASE, CLS.CLOSE_CASE2SUBCASE) order by CLS.CLOSE_DATE desc, CLS.OBJID desc) RN
            FROM EDW_ODS.T_000127_SA_TABLE_CLOSE_CASE CLS
            LEFT JOIN EDW_ODS.t_000127_sa_table_x_case_subcase_vw SCS
              ON SCS.X_CASE_SUBCASE2X_CASE = CLS.LAST_CLOSE2CASE
     AND SCS.DELETED_IND = 0
            JOIN EDW_ODS.T_000127_SA_TABLE_CASE CAS
              ON COALESCE(CLS.LAST_CLOSE2CASE, CLS.CLOSE_CASE2SUBCASE) = CAS.OBJID
              AND CAS.DELETED_IND = 0
            LEFT JOIN EDW_ODS.T_000127_SA_TABLE_GBST_ELM GE_STS
              ON GE_STS.OBJID         = CAS.CASESTS2GBST_ELM
              AND GE_STS.DELETED_IND = 0
            LEFT JOIN EDW_ODS.T_000127_SA_TABLE_GBST_LST GL_STS
              ON GE_STS.GBST_ELM2GBST_LST = GL_STS.OBJID
              AND GL_STS.DELETED_IND = 0
            LEFT JOIN EDW_ODS.T_000127_SA_TABLE_ACT_ENTRY AE
              ON AE.ACT_CODE               = 16019
             AND AE.ACT_ENTRY2CASE         = CLS.LAST_CLOSE2CASE
             AND CLS.CLOSE_RSOLUT2GBST_ELM = 1289
             AND AE.DELETED_IND = 0
           WHERE COALESCE(CLS.LAST_CLOSE2CASE, CLS.CLOSE_CASE2SUBCASE) is not null
    AND CLS.DELETED_IND = 0 
              )T
     where RN = 1


),

FCR_TOPIC as (
-- подготовка данных, фильтрация, расчёт IS_CALL_CENTER и HASH_TOPIC_TYPE
SELECT
  min(TOPIC_FCR_KEY)              as TOPIC_FCR_KEY,
  INTR_OBJID,
  max(HAS_CASE)                   as HAS_CASE,
  max(START_TIME)                 as START_TIME,
  max(END_TIME)                   as END_TIME,
  max(CS_CREATION_TIME)           as CS_CREATION_TIME,
  max(CLOSE_DATE)                 as CLOSE_DATE,
  max(X_INTRXN2FIN_ACCNT)         as X_INTRXN2FIN_ACCNT,
  max(FAMILY)                     as FAMILY,
  REASON_1,
  REASON_2,

  /*max(IS_CALL_CENTER) 
  keep (dense_rank first order by
                decode(UPPER(S_ROLE_NAME), 'TСОТРУДНИК ПОДРАЗДЕЛЕНИЯ', 1, 'TУЧАСТНИК ГРУППЫ', 2, 3) asc,

                               decode(TER_TYPE, 'Branch_CRM', 1, 'Branch', 2, 'Affiliate', 3, 'Main', 4, 5) asc,
                                decode(instr(TER_NAME, 'MVNO'), 0, 1, 2) asc,
                                --ROL_DML_DTTM desc,
                                MRF.OBJID    desc) as IS_CALL_CENTER,*/

  max(HASH_TOPIC_TYPE)          as HASH_TOPIC_TYPE,

  (array_agg(IS_CALL_CENTER order by
                decode(UPPER(S_ROLE_NAME), 'TСОТРУДНИК ПОДРАЗДЕЛЕНИЯ', 1, 'TУЧАСТНИК ГРУППЫ', 2, 3) asc,

                               decode(MRF_TYPE, 'Branch_CRM', 1, 'Branch', 2, 'Affiliate', 3, 'Main', 4, 5) asc,
                                decode(position('MVNO' in MRF_TER_NAME), 0, 1, 2) asc,
                                --ROL_DML_DTTM desc,
                                MRF_OBJID   desc))[1] as IS_CALL_CENTER,

  /*max(MRF.OBJID) keep (dense_rank first order by 
                decode(UPPER(S_ROLE_NAME), 'TСОТРУДНИК ПОДРАЗДЕЛЕНИЯ', 1, 'TУЧАСТНИК ГРУППЫ', 2, 3) asc,

                                decode(TER_TYPE, 'Branch_CRM', 1, 'Branch', 2, 'Affiliate', 3, 'Main', 4, 5) asc,
                                decode(instr(TER_NAME, 'MVNO'), 0, 1, 2) asc,
                                ROL_DML_DTTM desc,
                                MRF.OBJID    desc) as MRF_OBJID,*/

 (array_agg(MRF_OBJID order by 
                decode(UPPER(S_ROLE_NAME), 'TСОТРУДНИК ПОДРАЗДЕЛЕНИЯ', 1, 'TУЧАСТНИК ГРУППЫ', 2, 3) asc,

                                decode(MRF_TYPE, 'Branch_CRM', 1, 'Branch', 2, 'Affiliate', 3, 'Main', 4, 5) asc,
                                decode(position('MVNO' in MRF_TER_NAME), 0, 1, 2) asc,
                                --ROL_DML_DTTM desc,
                                MRF_OBJID    desc))[1] as MRF_OBJID,

  max(X_NUM)      as X_NUM,
  max(CASE_ID_NUMBER) as CASE_ID_NUMBER,
  max(USER_KEYN)    as USER_KEYN
FROM (
SELECT /*+ORDERED FULL(SP) USE_HASH(SP, TOP) */ 
     TOP.OBJID AS TOPIC_FCR_KEY,
     I.OBJID   AS INTR_OBJID,
     CASE
     WHEN CAS.OBJID IS NOT NULL THEN 1
     ELSE 0
     END HAS_CASE,
     CASE 
         WHEN I.START_TIME < to_date('01.01.1900','dd.mm.yyyy') THEN I.END_TIME
     ELSE I.START_TIME
     END START_TIME,
     I.END_TIME,
     CAS.CREATION_TIME AS CS_CREATION_TIME,
     CCAS.CLOSE_DATE,   
     I.X_INTRXN2FIN_ACCNT,
   COALESCE(NULLIF(PN_SP.FAMILY, 'Не определено'), NULLIF(PN.FAMILY, 'Не определено')) as FAMILY,
     CASE
       WHEN UPPER(TOP.REASON_1) in ('УПРАВЛЕНИЕ УСЛУГАМИ', 'КОНФИГУРАЦИЯ УСЛУГ')
          THEN 'УПРАВЛЕНИЕ УСЛУГАМИ / КОНФИГУРАЦИЯ УСЛУГ'
       ELSE UPPER(TOP.REASON_1)
     END REASON_1,
     UPPER(TOP.REASON_2) as REASON_2,
     CASE
         WHEN ROL.USER_ROLE2TERRITORY IN 
               (37682  -- 1ЛТП ЕКЦ (МЦ НТТ)
              , 17325  -- ЕКЦ.КСС (Саранск)
              , 17327  -- ЕКЦ.ТП ШПД (Саранск)
              , 37683  -- ИСО ЕКЦ (МЦ НТТ)
              , 53747  -- КЦ МЦ НТТ 1ЛТП ОТА ЦБР - Краснодар, ул. Красная, 59
              , 53618  -- КЦ МЦ НТТ ИСО РСО - Волжский, ул. Дружбы, 42
              , 53617  -- КЦ МЦ НТТ ИСО РСО 1ЛТП ШПД - Волгоград, ул. Мира, 16
              , 31977  -- ЦПОК (ФЛ) - г. Барнаул, ул. Димитрова , д. 62
              , 31978  -- ЦПОК (ФЛ) - г. Барнаул, ул. Исакова, д. 247
              , 27343  -- Центр обработки обращений (ФЛ)
              , 52176  -- Центр обработки обращений Вологодский ЛТП
              , 52179  -- Центр обработки обращений РСО
              , 52181  -- КЦ Группа обработки web-обращений
              , 53610  -- Центр обработки обращений MVNO (ФЛ)
              ---------------------------------------------------------------------
              , 97657  -- Центр обработки обращений РП Череповец 1ЛТП SZT.021
              , 97658  -- Центр обработки обращений РП Санкт-Петербург 1ЛТП SZT.022
              , 99914  -- Центр обработки обращений РП Череповец РСО SZT.023
              , 99915) -- Центр обработки обращений РП Санкт-Петербур РСО SZT.024 
                                             -- AND UPPER(I.TYPE) = UPPER('Телефон') 
          AND CHN_I.CHANNEL_INST2CHANNEL = 9 -- UPPER(MED.TITLE) = ('ЦОО')
         THEN 1
         ELSE 0
     END IS_CALL_CENTER,
   -- захэшируем условие сравнения. для ускорения работы и предотвращения nested loop  

     (CASE
         WHEN UPPER(TOP.REASON_1) IN ('УПРАВЛЕНИЕ УСЛУГАМИ', 'КОНФИГУРАЦИЯ УСЛУГ')
            THEN 'УПРАВЛЕНИЕ УСЛУГАМИ / КОНФИГУРАЦИЯ УСЛУГ'
         ELSE UPPER(TOP.REASON_1)
       END 
       || ' ' ||
       CASE
          WHEN UPPER(TOP.REASON_1) IN ('ЗАПРОС ИНФОРМАЦИИ', 'ПРЕТЕНЗИЯ', 'УПРАВЛЕНИЕ УСЛУГАМИ', 'КОНФИГУРАЦИЯ УСЛУГ')
               THEN UPPER(TOP.REASON_2)
          WHEN UPPER(TOP.REASON_1) IN ('АКЦИИ', 'РАСЧЕТНОЕ ОБСЛУЖИВАНИЕ', 'УПРАВЛЕНИЕ ДОГОВОРАМИ', 'УПРАВЛЕНИЕ ОТТОКОМ', 'ПОЛОЖИЛ ТРУБКУ ДО ОТВЕТА')
               THEN ''
          WHEN UPPER(TOP.REASON_1) IN ('ТЕХПОДДЕРЖКА') 
               THEN UPPER(COALESCE(
                COALESCE(NULLIF(PN_SP.FAMILY, 'Не определено'), NULLIF(PN.FAMILY, 'Не определено')), -- определим продукт
                to_char(TOP.OBJID,'9999999') ))                                    -- если не определился, то подставим OBJID
     end
     ) HASH_TOPIC_TYPE,
   --- необходимо для удаления дублей тематик
   COALESCE(CAS.OBJID, -1) AS CAS_OBJID,
   UPPER(TOP.RESULT)  AS TOP_RESULT,
   -- для расчёта mrf
   MRF.MRF_TER_EXT_ID as MRF_OBJID,
   MRF.TER_NAME as MRF_TER_NAME,
   MRF.type_name as MRF_TYPE,
   ROL.S_ROLE_NAME,
   --ROL.DML_DTTM ROL_DML_DTTM,
   --- новые показатели RTK-7811
   I.X_NUM          AS X_NUM,
   CAS.ID_NUMBER    AS CASE_ID_NUMBER,
   SES.LAST_USER_ID AS USER_KEYN
   FROM DELTA_FA I--добавил выше DELTA_FA
   JOIN edw_ods.T_000127_SA_TABLE_TOPIC TOP 
     ON I.TOPIC_OBJID = TOP.OBJID 
  AND TOP.DELETED_IND = 0 
   LEFT JOIN edw_ods.T_000127_SA_TABLE_CASE CAS
     ON CAS.OBJID = TOP.FOCUS_LOWID
    AND TOP.FOCUS_TYPE = 0
 AND CAS.DELETED_IND = 0
   LEFT JOIN edw_ods.T_000127_SA_TABLE_X_CASE_SUBCASE_VW SCS
     ON SCS.X_CASE_SUBCASE2X_CASE = CAS.OBJID
  AND SCS.DELETED_IND = 0 
   LEFT JOIN PREP_TABLE_CLOSE_CASE CCAS--добавил выше PREP_TABLE_CLOSE_CASE
     ON CCAS.REF_TO_CS = CAS.OBJID
    AND (CCAS.CASE_SOURCE_IND = 1 OR 
         CCAS.CASE_SOURCE_IND = 2 AND SCS.OBJID IS NOT NULL)
   -- берём только последнюю сессию
   LEFT JOIN PREP_TABLE_SESSION SES--добавил выше PREP_TABLE_SESSION 
     ON SES.SESSION2INTRXN = I.OBJID
   LEFT JOIN edw_ods.T_000127_SA_TABLE_USR_TER_ROLE ROL
     ON ROL.USR_TER_ROLE2USER = SES.LAST_USER_ID
    --AND ROL.VALID_TO_DTTM = to_date('31.12.2999','dd.mm.yyyy') 
    AND ROL.S_ROLE_NAME IN ('TСОТРУДНИК ПОДРАЗДЕЛЕНИЯ', 'TУЧАСТНИК ГРУППЫ')
 AND ROL.DELETED_IND = 0
--    AND ROL.DML_IND <> 'D'  
   LEFT JOIN EDW_STG_DDS.T_000127_PRE_MV_CRM_TERRITORY MRF
     ON MRF.TER_EXT_ID = ROL.USER_ROLE2TERRITORY    
   LEFT JOIN PREP_CHANNEL_INST CHN_I--добавил выше PREP_CHANNEL_INST 
     ON CHN_I.CHANNEL_INST2INTRXN = I.OBJID  
   LEFT JOIN edw_ods.T_000127_SA_TABLE_SITE_PART SP 
     ON SP.OBJID = TOP.X_TOPIC2SITE_PART 
  AND SP.DELETED_IND = 0
   LEFT JOIN edw_ods.T_000127_SA_TABLE_MOD_LEVEL_VW ML 
     ON ML.OBJID = SP.SITE_PART2PART_INFO
  AND ML.DELETED_IND = 0 
    --AND ML.VALID_TO_DTTM = to_date('31.12.2999','dd.mm.yyyy')
   LEFT JOIN edw_ods.T_000127_SA_TABLE_PART_NUM PN_SP
     ON PN_SP.OBJID = ML.PART_INFO2PART_NUM
  AND PN_SP.DELETED_IND = 0
    --AND PN_SP.VALID_TO_DTTM = to_date('31.12.2999','dd.mm.yyyy')   
   LEFT JOIN edw_ods.T_000127_SA_TABLE_PART_NUM PN
     ON PN.OBJID = I.X_INTRXN2PART_NUM
  AND PN.DELETED_IND = 0 
    --AND PN.VALID_TO_DTTM = to_date('31.12.2999','dd.mm.yyyy')  
  WHERE UPPER(TOP.REASON_1) IN 
    ('АКЦИИ',
     'ЗАПРОС ИНФОРМАЦИИ',
     'ПРЕТЕНЗИЯ',
     'РАСЧЕТНОЕ ОБСЛУЖИВАНИЕ',
     'УПРАВЛЕНИЕ ДОГОВОРАМИ',
     'УПРАВЛЕНИЕ ОТТОКОМ',
     'УПРАВЛЕНИЕ УСЛУГАМИ',
     'КОНФИГУРАЦИЯ УСЛУГ',
     'ПОЛОЖИЛ ТРУБКУ ДО ОТВЕТА',
     'ТЕХПОДДЕРЖКА')
   AND UPPER(TOP.RESULT) <> 'СВЯЗАНО С ГП' 
   AND UPPER(COALESCE(CAS.CASE_TYPE_LVL1, 'x')) NOT IN ('ТЕХНИЧЕСКАЯ ПРОБЛЕМА', 'БИЗНЕС-ПРОБЛЕМА', 'ИТ-ПРОБЛЕМА')) T1

 GROUP BY INTR_OBJID, REASON_1, REASON_2, TOP_RESULT, CAS_OBJID
 -- group by используем для корректного определения IS_CALL_CENTER и удаления дублей тематик.
 -- т.к. роль двоит строки и искажает расчёт


 )


 -- расчёт итоговых показателей
SELECT 
      tot.TOPIC_FCR_KEY,
      tot.INTR_OBJID,
      tot.HAS_CASE,  

-- для HAS_SECONDARY
      CASE
        WHEN HAS_CASE = 1 
           THEN GREATEST(coalesce(CLOSE_DATE, current_timestamp), END_TIME + interval '2 DAY')
        ELSE 
            END_TIME + interval '2 DAY'
      END HAS_SECONDARY,--END_HAS_SEC_INTERVAL,

      -- для IS_PRIMARY_FOR_CALL_CENTER
      START_TIME - interval '2 DAY' AS IS_PRIMARY_FOR_CALL_CENTER, --START_PRIMARY_INTERVAL,

      -- для HAS_DUPLICATING_CASE
      CASE
          WHEN HAS_CASE = 0 
             THEN to_date('01.01.1900','dd.mm.yyyy')
          ELSE coalesce(CLOSE_DATE, current_date)
      END HAS_DUPLICATING_CASE ,--NVL_CLOSE_DATE, 

      tot.START_TIME,
      --least(coalesce(tot.CS_CREATION_TIME, to_date('31.12.2999','dd.mm.yyyy')), tot.START_TIME) as MIN_CAS_INTR_START_TIME,
      --tot.CS_CREATION_TIME,
      tot.END_TIME,
      tot.CLOSE_DATE,
      tot.X_INTRXN2FIN_ACCNT,
      tot.FAMILY,
      tot.REASON_1,
      tot.REASON_2,
      tot.IS_CALL_CENTER,
      tot.HASH_TOPIC_TYPE,
      MRF_OBJID,   
   X_NUM as CURR_X_NUM,  
   '-1' as PREV_X_NUM,
      USER_KEYN as CURR_INTR_USER_KEY, --провести через CRM_USER_HUB 
   '-1' as PREV_INTR_USER_KEY, -- провести через CRM_USER_HUB
      CASE_ID_NUMBER,   
   '-1' as DUPLICATING_CASE_ID_NUMBER, 
   127::int as SRC_ID

FROM FCR_TOPIC tot
where 1=1 
  AND tot.START_TIME >= TO_DATE('20190601', 'YYYYMMDD')
  AND tot.START_TIME <  TO_DATE('20190630', 'YYYYMMDD') + INTERVAL '1 DAY - 1 SECOND'
;
analyze edw_stg_dds.t_000127_tfct_crm_fcr_topic;

