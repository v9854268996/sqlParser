/*rev.51418 от 05.03.2020*/
truncate table edw_stg_dds.t_000011_dim_add_service;

/* 
  Выборка всех постоянных B2С услуг
  Зашиты данные для фильтрации самых последних XREF и с учетом последних версий для  SCD2
*/

insert into edw_stg_dds.t_000011_dim_add_service
(
    add_service_key,
    add_service_parent_key,
    service_key,
    branch_key,
    city_key,
    account_name,
    subs_name,
    mrf_service_key,
    mrf_add_service_name,
    start_date,
    end_date,
    service_cost,
    dop_service_key,
    add_serv_sc_key,
    src_id
)
select
    '1#'||ts1.service_id                              as add_service_key,
    '1#'||coalesce(ts2.service_id,ts1.serv_first_id)  as add_service_parent_key,
    ts1.svc_id                                        as service_key,
    tu1.dept_id                                       as branch_key,
    null                                              as city_key,
    tu1.account::numeric                              as account_name,
    ts1.dev_id                                        as subs_name,
    ts1.svc_id                                        as mrf_service_key,
    tsr1.name                                         as mrf_add_service_name,
    ts1.date_begin                                    as start_date,
    coalesce(ts1.date_end,'2999-12-31 00:00:00')      as end_date,
    null                                              as service_cost,
    ts1.svc_id                                        as dop_service_key,
    '1#'||vca.service_id                              as add_serv_sc_key,
    ts1.src_id
from edw_ods.t_000011_t_services ts1
join edw_ods.t_000011_t_users tu1 on tu1.user_id = ts1.user_id
    and tu1.exp_dttm = to_date('29991231', 'YYYYMMDD')
join edw_ods.t_000011_t_svc_ref tsr1 on tsr1.svc_id = ts1.svc_id
    and tsr1.exp_dttm = to_date('29991231', 'YYYYMMDD')
left join (
            select vca.service_id, vca.tech_dt, vca.date_sys, row_number() over (partition by service_id order by tech_dt desc) as rn
            from edw_ods.t_000011_mrf_antivir_connect vca
          ) vca on vca.rn = 1
    and vca.service_id = ts1.service_id
left join edw_ods.t_000011_t_services ts2 on ts2.service_id = ts1.serv_first_id
    and ts1.serv_first_id != ts1.service_id
    and ts2.exp_dttm = to_date('29991231', 'YYYYMMDD')
left join edw_ods.t_000011_t_svc_ref tsr2 on tsr2.svc_id = ts2.svc_id
    and tsr2.exp_dttm = to_date('29991231', 'YYYYMMDD')
    and tsr2.deleted_ind = 0
where ts1.exp_dttm = to_date('29991231', 'YYYYMMDD')
  and tu1.deleted_ind = 0
  and tsr1.deleted_ind = 0 
  and tu1.iscorp = 'N'
;
commit;

------------------------------------------------------------------------------------
/*
  Выборка разовых B2C услуг
*/
insert into edw_stg_dds.t_000011_dim_add_service
(
    add_service_key,
    add_service_parent_key,
    service_key,
    branch_key,
    city_key,
    account_name,
    subs_name,
    mrf_service_key,
    mrf_add_service_name,
    start_date,
    end_date,
    service_cost,
    dop_service_key,
    add_serv_sc_key,
    src_id
)
select
    '2#'||tos.oth_svc_id                       as add_service_key,
    '2#'||tos.oth_svc_id                       as add_service_parent_key,
    tos.svc_id                                 as service_key,
    tu1.dept_id                                as branch_key,
    null                                       as city_key,
    tu1.account::numeric                       as account_name,
    null                                       as subs_name,
    tos.svc_id                                 as mrf_service_key,
    tsr1.name                                  as mrf_add_service_name,
    tos.svc_date                               as start_date,
    tos.svc_date                               as end_date,
    null                                       as service_cost,
    tos.svc_id                                 as dop_service_key,
    vca.service_id                             as add_serv_sc_key,
    tos.src_id
from edw_ods.t_000011_t_other_svc tos
join edw_ods.t_000011_t_users tu1 on tu1.user_id = tos.user_id
    and tu1.exp_dttm = to_date('29991231', 'YYYYMMDD')
join edw_ods.t_000011_t_svc_ref tsr1 on tsr1.svc_id = tos.svc_id
    and tsr1.exp_dttm = to_date('29991231', 'YYYYMMDD')
left join (
            select vca.service_id, vca.tech_dt, vca.date_sys, row_number() over (partition by service_id order by tech_dt desc) as rn
            from edw_ods.t_000011_mrf_antivir_connect vca
          ) vca on vca.rn = 1
    and vca.service_id = tos.oth_svc_id
where tu1.deleted_ind = 0
  and tsr1.deleted_ind = 0
  and tu1.iscorp = 'N'
;
commit;
 
analyse edw_stg_dds.t_000011_dim_add_service;
