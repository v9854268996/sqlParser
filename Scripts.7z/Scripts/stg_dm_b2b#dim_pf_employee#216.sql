-- rev. 50748 от 28.02.2020

SET search_path = edw_stg_dm_b2b;
SET optimizer = 'on';

TRUNCATE TABLE edw_stg_dm_b2b.dim_pf_employee;

INSERT INTO edw_stg_dm_b2b.dim_pf_employee
(employee_id, position_id, department_id, branch_key, tab_code, full_name, src_id)
SELECT
       ce.employee_id,
       ce.position_id,         -- идентификатор должности
       NULL AS department_id,  -- идентификатор подразделения, нужно расширение на 216 СИ: COMSTR.COMSTR_EMPLOYEE_GROUPS, COMSTR.COMSTR_GROUPS для его заполнения
       hd.branch_key,          -- ID РФ
       ce.tab_code,            -- на СИ данное поле не заполняется, брать из ЦХД после реализации соответствующей dds витрины
       ce.last_name || ' ' || ce.first_name || ' ' || ce.patronymic AS full_name,
       216 :: smallint AS src_id
  FROM edw_ods.t_000216_comstr_employees ce
       JOIN edw_dds.hub_dim_branch hd
         ON ce.region_id::text = hd.source_key
        AND hd.exp_dttm = to_date('29991231', 'YYYYMMDD')
        AND hd.src_id = 158 -- ce.src_id
 WHERE ce.exp_dttm = to_date('29991231', 'YYYYMMDD')
   AND ce.deleted_ind = 0;

ANALYSE edw_stg_dm_b2b.dim_pf_employee;