/*rev.34588 31.07.2019 Changed by: NAREK.ALAVERDYAN */
		--DIM_ACCOUNT
		truncate table edw_stg_ads.dim_account_1_prt_p000001 ;
		insert into edw_stg_ads.dim_account_1_prt_p000001
		(  account_key,  parent_account_key,  partner_key,  branch_key,  duty_num_key,  center_num_key,  agent_scheme_key,  address_key,
		  payment_type_key,  account_name,  parent_account_name,  start_date,  end_date, src_id,  md5)
		SELECT
		  da.account_key,  da.parent_account_key,  da.partner_key,  da.branch_key,  da.duty_num_key,  da.center_num_key,  da.agent_scheme_key,  da.address_key,
		  da.payment_type_key,  da.account_name,  da_par.account_name as parent_account_name,  da.start_date,  da.end_date,  da.src_id,
		  md5((((((((((((((((((((((((((coalesce(da.account_key::text, ''::text)) || chr(9)) || coalesce(da.parent_account_key::text, ''::text)) || chr(9)) || coalesce(da.partner_key::text, ''::text)) || chr(9)) || coalesce(da.branch_key::text, ''::text)) || chr(9)) || coalesce(da.duty_num_key::text, ''::text)) || chr(9)) || coalesce(da.center_num_key::text, ''::text)) || chr(9)) || coalesce(da.agent_scheme_key::text, ''::text)) || chr(9)) || coalesce(da.address_key::text, ''::text)) || chr(9)) || coalesce(da.payment_type_key::text, ''::text)) || chr(9))  || coalesce(da.account_name::text, ''::text)) || chr(9)) || coalesce(da_par.account_name::text, ''::text)) || chr(9)) || coalesce(da.start_date::text, ''::text)) || chr(9)) || coalesce(da.end_date::text, ''::text)) || chr(9)) as md5
		from
		  edw_dds.dim_account_1_prt_p000001 da
		left join edw_dds.dim_account_1_prt_p000001 da_par on
		  da_par.account_key = da.parent_account_key
		  and date_trunc('day', da_par.exp_dttm) = to_date('29991231', 'yyyymmdd')
		where
		  date_trunc('day', da.exp_dttm) = to_date('29991231', 'yyyymmdd')
		  and da.src_id=000001 ;
		  
		ANALYZE edw_stg_ads.dim_account_1_prt_p000001;
	