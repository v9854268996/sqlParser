/*rev.46170 10.01.2020*/
truncate edw_stg_dds.t_000011_tfct_payments;
insert into edw_stg_dds.t_000011_tfct_payments
(payment_key,
 account_key,
 payment_amt,
 comments,
 payment_dttm,
 billing_dttm,
 src_id,
 load_dttm,
 eff_dttm,
 exp_dttm
)
select
 payment_key,
 src_id||'#'||account_key as account_key,
 payment_amt,
 comments,
 payment_dttm,
 billing_dttm,
 src_id,
 load_dttm,
 eff_dttm,
 exp_dttm
from(
select
		round(t_payments.payment_id) as payment_key -- Идентификатор платежа
		,round(t_payments.user_id) as account_key -- Идентификатор лицевого счета
		,t_payments.summ as payment_amt -- Сумма платежа
		,pay_date as payment_dttm -- Дата платежа
		,pdr.NAME comments
		,to_date(round(billing_id)::text, 'YYYYMM') billing_dttm
		,000011 as src_id
		,now() as load_dttm
		,cast('19000101' as timestamp(0) without time zone) as eff_dttm
		,cast('29991231' as timestamp(0) without time zone) as exp_dttm
from edw_ods.t_000011_t_payments t_payments
	left join edw_ods.t_000011_t_pay_doc_ref pdr 
		on pdr.pay_doc_id = t_payments.pay_doc_id
		and pdr.deleted_ind = 0
		and to_date(round(t_payments.billing_id)::text, 'YYYYMM') between pdr.eff_dttm and pdr.exp_dttm
where	tech_dt  between to_date(substr('20190601', 1, 8), 'YYYYMMDD') and to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second'
		and billing_id between substr('20190601', 1, 6)::int and substr('20190630', 1, 6)::int
)sss;

analyze edw_stg_dds.t_000011_tfct_payments;

