/*rev.34588 31.07.2019 Changed by: NAREK.ALAVERDYAN */
		--General Subscriber Base Monthly Aggregate
		truncate table edw_stg_ads.agg_sub_base_1_prt_p000104 ;
		insert into edw_stg_ads.agg_sub_base_1_prt_p000104 (
			calendar_key,
			year_month_key,
			center_num_key,
			duty_num_key,
			segment_key,
			service_key,
			frequency_services_key,
			technology_type_key,
			service_rtk_detail_key,
			rc_key,
			branch_key,
			region_key,
			sub_cnt,
			src_id
		)

		Select
			calendar_key,
			year_month_key,
			center_num_key,
			duty_num_key,
			segment_key,
			service_key,
			frequency_services_key,
			technology_type_key,
			service_rtk_detail_key,
			rc_key,
			branch_key,
			region_key,
			count(distinct subs_key) as sub_cnt,
			src_id
		From edw_stg_ads.tfct_sub_base_1_prt_p000104
		where src_id=104
				and calendar_key between date_trunc('month', to_date('20190601', 'YYYYMMDD'))
				and (date_trunc('month', to_date('20190630', 'YYYYMMDD')) + interval '1 month' + interval '-1 day')
		group by 
			calendar_key,
			year_month_key,
			center_num_key,
			duty_num_key,
			segment_key,
			service_key,
			frequency_services_key,
			technology_type_key,
			service_rtk_detail_key,
			rc_key,
			branch_key,
			region_key,
			src_id;
			
		ANALYZE edw_stg_ads.agg_sub_base_1_prt_p000104;
	