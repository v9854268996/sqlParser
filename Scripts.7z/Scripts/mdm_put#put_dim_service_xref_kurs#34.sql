/*rev. 24.12.2019*/  
delete from  edw_stg_mdm.put_dim_service_xref_kurs_stg_1 where src_id = 000034;
/*27-34 36-39*/
insert into edw_stg_mdm.put_dim_service_xref_kurs_stg_1 (src_id,dfservice,na_me,service_rtk_detail_key,dfdatebegin,dfdateend,rn)
select tservice.src_id,  -- ADG
       tservice.dfservice,
    tservice.dfname||' # '||tservice.dfnamesmall||' # '||tservice.dfnamerep na_me,
    tg.dfbuh_shet service_rtk_detail_key,
    tgl.dfdatebegin,
    tgl.dfdateend,
    row_number() over(partition by tservice.dfservice order by tgl.dfdatebegin desc,
    coalesce(tgl.dfdateend,to_date('29991231','YYYYMMDD')) desc) as rn
  from edw_ods.t_000034_tservice tservice
       join edw_ods.t_000034_tservice_glob_link tgl on tgl.dfservice=tservice.dfservice
       join edw_ods.t_000034_tservice_glob tg on tg.dfservice_glob=tgl.dfservice_glob
;

commit;
analyse edw_stg_mdm.put_dim_service_xref_kurs_stg_1 ;

delete from  edw_stg_mdm.put_dim_service_xref_kurs where src_id = 000034;

insert into edw_stg_mdm.put_dim_service_xref_kurs 
(
 service_key
 ,service_name
 ,service_rtk_detail_key
 ,technology_type_key
 ,src_id
)
select src_id||';'||ltrim(to_char(trunc(dfservice,0), '999999999999999999999999999999D'),' ') service_key,
    na_me service_name, 
    service_rtk_detail_key,
 --2 do убрать хардкод 
    case when upper(na_me) like '%TTH%' then 'ETTH'
            when upper(na_me) like '%PON%' then 'GPON'
      when upper(na_me) like '%FTT%' then 'FTTb'
      when upper(na_me) like '%MMDS%' then 'MMDS'
      when upper(na_me) like '%CDMA%' then 'CDMA/GSM/3G/LTE'
      when upper(na_me) like '%GSM%' then 'CDMA/GSM/3G/LTE'
      when upper(na_me) like '%LTE%' then 'CDMA/GSM/3G/LTE'
      when upper(na_me) like '%ETHERNET%' then 'ETHERNET'
      when upper(na_me) like '%ISDN%' then 'Dial+ISDN'
      when upper(na_me) like '%DIAL%' then 'Dial+ISDN'
      when upper(na_me) like '%SHDSL%' then 'SHDSL'
            when upper(na_me) like '%DSL%' then 'XDSL'
      when upper(na_me) like '%WI-FI%' then 'WiFi/WiMax'
      when upper(na_me) like '%WIFI%' then 'WiFi/WiMax'
            when upper(na_me) like '%БШПД%' then 'БШПД'
      when upper(na_me) like '%ШПД%' then 'ШПД'
      when upper(na_me) like '% ПРОВОД%' then 'Проводная'
        end technology_type_key 
 ,src_id 
from edw_stg_mdm.put_dim_service_xref_kurs_stg_1     
where rn=1    
;
commit;
analyse edw_stg_mdm.put_dim_service_xref_kurs;