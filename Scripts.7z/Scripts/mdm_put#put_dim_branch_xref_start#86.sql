/*rev. 26.03.2020*/
select edw_stg_dds.get_filial_start_name(000086);
delete from edw_stg_mdm.put_dim_branch_xref_start where src_id =000086;
insert into edw_stg_mdm.put_dim_branch_xref_start (branch_key,branch_name,branch_filial_name,src_id)
select dept_id, name,  case when trim(filial_name) like 'ПАО "Ростелеком"%' then name else filial_name end ,src_id
from edw_stg_dds.t_000086_pre_dim_start_filials c;
analyse edw_stg_mdm.put_dim_branch_xref_start ;
