/*rev.22104 от 12.02.2019*/
truncate table edw_stg_dm_feb.dim_edo_inn_dictionary_1_prt_p000020;
insert into edw_stg_dm_feb.dim_edo_inn_dictionary_1_prt_p000020
(
	src_id,
	partner_full_name,
	partner_inn,
	load_dttm
)
select 
	src_id,
	partner_full_name,
	partner_inn,
	min(load_dttm) as load_dttm
from(	
	select 
		src_id,
		partner_full_name,
		partner_inn,
		now() as load_dttm
	from edw_stg_dm_feb.tfct_edo_statistic_detail_1_prt_p000020
	union all
	select 
		src_id,
		partner_full_name,
		partner_inn,
		load_dttm
	from edw_dm_feb.dim_edo_inn_dictionary_1_prt_p000020
) t
group by
	src_id,
	partner_full_name,
	partner_inn;
commit;
analyze edw_stg_dm_feb.dim_edo_inn_dictionary_1_prt_p000020;