/*rev.33056 от 11.07.2019*/
	--set optimizer = on;
truncate table edw_stg_dm_ruz.pre_fct_ip_mpls_traffic_teoco_v_1_prt_p000156;
insert into edw_stg_dm_ruz.pre_fct_ip_mpls_traffic_teoco_v_1_prt_p000156
(
	period,
	oebs_r12_branch_key,
	source,
	business_segment_key,
	client_name,
	rc_key,
	cms_order_point2address,
	vrf,
	rt_import,
	segment_key,
	cms_cleint_inn,
	business_service_ruz_key,
	has_region_lastmile,
	in_traf,
	out_traf,
	total_traf,
	cms_order,
	fldincomeitem,
	fldincomeitemnumber,
	fldincomeitemyear,
	cms_service,
	ruz_src_id,
	src_id
)
select
	s.period,
	s.oebs_r12_branch_key,
	'TEOCO VOIP' source,
	d_bs.business_segment_key,
	s.client_name,
	d_c.rc_key,
	s.cms_order_point2address,
	s.vrf,
	s.rt_import,
	s.segment_key,
	s.cms_cleint_inn,
	19 business_service_ruz_key,
	s.has_region_lastmile,
	s.in_traf*0.02 in_traf,
	s.out_traf*0.02 out_traf,
	s.total_traf*0.02 total_traf,
	s.cms_order,
	s.fldincomeitem,
	s.fldincomeitemnumber,
	s.fldincomeitemyear,
	s.cms_service,
	000156 ruz_src_id,
	000156 src_id
from edw_stg_dm_ruz.pre_fct_ip_mpls_traffic_teoco_1_prt_p000156 s
	left join edw_dds.dim_matrix_ruz_rc d_mr /*Коммерческая матрица*/
		on ( 1 = 1
			and d_mr.business_service_ruz_key = 19
			and d_mr.segment_key  = s.segment_key  
			and to_date('20190601','YYYYMMDD') between d_mr.eff_dttm and  d_mr.exp_dttm   
			and d_mr.deleted_ind='0'
		)
	left join edw_dds.dim_rc d_c
		on ( 1 = 1
			and d_mr.rc_key = d_c.rc_key 
			and to_date('20190601','YYYYMMDD') between d_c.eff_dttm and d_c.exp_dttm
			and d_c.deleted_ind = '0'
		)

		left join edw_dds.dim_business_segment d_bs
		on ( 1 =1 
			and d_c.business_segment_key = d_bs.business_segment_key 
			and to_date('20190601','YYYYMMDD') between d_bs.eff_dttm and d_bs.exp_dttm
			and d_bs.deleted_ind='0'
		)
where 1 = 1 
	and s.business_service_ruz_key in (1,2,3,4) /*услуга относится к интернету*/
	and s.period = to_date('20190601','YYYYMMDD');
commit;
analyse edw_stg_dm_ruz.pre_fct_ip_mpls_traffic_teoco_v_1_prt_p000156;