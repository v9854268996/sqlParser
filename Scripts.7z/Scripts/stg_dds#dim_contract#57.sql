/*rev.33814 22.07.2019*/
TRUNCATE edw_stg_dds.t_000057_dim_contract;
INSERT INTO edw_stg_dds.t_000057_dim_contract
(
	account_key,
	contract_key,
	parent_contract_key,
	partner_key,
	contract_cancellation_dt,
	contract_cval,
	eff_dttm,
	exp_dttm,
	src_id,
	load_dttm
)
with main as 
(
	select 
		src_id || '#' || user_id as account_key,
		contract_id,
		null as parent_contract_key,
		user_id as partner_key,
		dateend as contract_cancellation_dt,
		nmb as contract_cval,
		to_date('20190601', 'YYYYMMDD') eff_dttm,
		to_date('20190630', 'YYYYMMDD') exp_dttm
	from edw_ods.t_000057_o_contract
	where to_date('20190601', 'YYYYMMDD') between eff_dttm and exp_dttm
		and deleted_ind = '0'
) 
select 
	c.account_key,
	c.contract_id,
	c.parent_contract_key,
	c.partner_key,
	c.contract_cancellation_dt,
	c.contract_cval,
	c.eff_dttm,
	c.exp_dttm,
	000057 as src_id,
	now() as load_dttm
from main c /*т.к. номер договора уникален для каждого лицевого счета, то достаточно поджониться на актуальный срез dim_account*/
	inner join edw_stg_dds.t_000057_dim_account a
		on (1 = 1
			and a.account_key = c.account_key
			and to_date('29991231','YYYYMMDD')::timestamp between a.eff_dttm and a.exp_dttm
			and a.deleted_ind = '0')

;
commit;
analyze edw_stg_dds.t_000057_dim_contract;