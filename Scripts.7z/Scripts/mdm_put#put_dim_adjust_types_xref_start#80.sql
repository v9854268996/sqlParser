/*rev.x20523 x17.01.2019*/
-- 80-89
delete from edw_stg_mdm.put_dim_adjust_types_xref_start where region_id = 'SIBIR' and src_id = 000080;

insert into edw_stg_mdm.put_dim_adjust_types_xref_start (ajtp_key,adjust_type_name,comment,region_id,src_id)
select 
case when IS_CHARGE = '1' then '1'||'#'||REASON_ID 
    when IS_PAYMENT = '1' then '2'||'#'||REASON_ID 
    else REASON_ID::text 
end as adjust_type_key 
,NAME as adjust_type_name 
,substr( ANNOTATION,0,255) as comments
,'SIBIR' as region_id 
,src_id
from edw_ods.t_000080_T_REASON_RECALCULATION t_R
where to_date('20190630' , 'YYYYMMDD') + INTERVAL '1 day - 1 second' between t_R.eff_dttm 
    and t_R.exp_dttm and t_R.deleted_ind = 0
;

commit;
analyse edw_stg_mdm.put_dim_adjust_types_xref_start;
