-- rev. 59387 от 29.05.2020
SET search_path = edw_stg_dm_b2b;
SET optimizer = ON;
COMMIT;

BEGIN;
  TRUNCATE TABLE edw_stg_dm_b2b.tfct_serv_sales_charges_1_prt_p000214;
COMMIT;
-- По всем новым подключениям VATS (c 2020.01.01 периода) ищем начисления в указанном числе
BEGIN;
INSERT INTO edw_stg_dm_b2b.tfct_serv_sales_charges_1_prt_p000214
  (period, ch_dt, sale_serv_id, charges_plat, charges_bill, src_id)
-- Находим начисления по новым подключениям
SELECT
       date_trunc('month', v.period) AS period,
       v.period AS ch_dt,
       v.account || '#' || v.nt_domain AS sale_serv_id,
       v.ch_all AS charges_plat,
       0 AS charges_bill,
       214 AS src_id
  FROM edw_dmcm.tfct_vats v
       JOIN -- фильтр по sale_serv_id
       (
         SELECT
                b.sale_serv_id, b.order_dt,
                row_number() OVER (PARTITION BY b.sale_serv_id ORDER BY order_dt) AS rn
           FROM (
                   SELECT
                          sale_serv_id, to_date('20190601', 'YYYYMMDD') AS order_dt
                     FROM edw_dm_b2b.tfct_serv_sales_1_prt_p000214
                    WHERE order_dt < to_date('20190601', 'YYYYMMDD')
                    UNION ALL
                   SELECT
                          sale_serv_id, order_dt
                     FROM edw_stg_dm_b2b.tfct_serv_sales_1_prt_p000214
                ) b
       ) ss
         ON v.account || '#' || v.nt_domain = ss.sale_serv_id
        AND ss.rn = 1
        AND ss.order_dt <= v.period
 WHERE v.src_id = 214
   AND v.period >= '2020-01-01'
   AND v.period BETWEEN to_date('20190601', 'YYYYMMDD') AND to_date('20190630', 'YYYYMMDD')
   AND v.ch_all > 0;
COMMIT;

BEGIN;
  ANALYZE edw_stg_dm_b2b.tfct_serv_sales_charges_1_prt_p000214;
COMMIT;

