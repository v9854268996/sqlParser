/*rev.57401 от 12.05.2020*/

truncate table edw_stg_dm_ruz.tfct_ruz_port_vpn_sip_1_prt_p000157;
insert into edw_stg_dm_ruz.tfct_ruz_port_vpn_sip_1_prt_p000157
 ( period
 , mrf_id
 , mrf_name
 , rf_id
 , rf_name
 , client_type
 , macro_segment
 , tech_name
 , capacity_use_od
 , used_port_serv
 , used_port_spd
 , used_port_iptv
 , used_port_sip
 , used_port_vpn
 , used_port_ota
 , rc_code
 , rc_short_name
 , subject_key
 , region_name
 , load_dttm
 , src_id

 )
with 
--иерархия сегментов для ЮЛ
segm as
  (
	SELECT 
		s.segment_key
		, to_date('20190630','YYYYMMDD') + interval '1 day  - 1 second'
	FROM edw_dds.dim_segment s 
	INNER JOIN edw_dds.dim_segment p
	   on ( 1 = 1 
	  and s.parent_segment_key=p.segment_key
	  and p.deleted_ind = 0
	  and to_date('20190630','YYYYMMDD')+ interval '1 day  - 1 second' between p.eff_dttm and p.exp_dttm )
	INNER JOIN edw_dds.dim_segment g
	   on ( 1 = 1 
	  and p.parent_segment_key=g.segment_key
	  and g.parent_segment_key=21000
	  and g.deleted_ind = 0
	  and to_date('20190630','YYYYMMDD')+ interval '1 day  - 1 second' between g.eff_dttm and g.exp_dttm )
	WHERE 1 = 1 
	  and s.deleted_ind = 0
	  and to_date('20190630','YYYYMMDD')+ interval '1 day  - 1 second' between s.eff_dttm and s.exp_dttm 

UNION ALL 
	SELECT 
		s.segment_key 
		, to_date('20190630','YYYYMMDD')+ interval '1 day  - 1 second'
	FROM edw_dds.dim_segment s 
	INNER JOIN edw_dds.dim_segment p
	   ON ( 1 = 1
	  and s.parent_segment_key=p.segment_key 
	  and p.parent_segment_key=21000 
	  and p.deleted_ind = 0
	  and to_date('20190630','YYYYMMDD')+ interval '1 day  - 1 second' between p.eff_dttm and p.exp_dttm)
	WHERE 1 = 1
	  and s.deleted_ind = 0
	  and to_date('20190630','YYYYMMDD')+ interval '1 day  - 1 second' between s.eff_dttm and s.exp_dttm

UNION ALL
	SELECT 
		s.segment_key 
		, to_date('20190630','YYYYMMDD')+ interval '1 day  - 1 second'
	 FROM edw_dds.dim_segment s 
	WHERE 1 = 1
	  and s.parent_segment_key=21000
	  and s.deleted_ind = 0
	  and to_date('20190630','YYYYMMDD')+ interval '1 day  - 1 second'  between s.eff_dttm and s.exp_dttm 

UNION ALL
	SELECT 
		s.segment_key 
		, to_date('20190630','YYYYMMDD')+ interval '1 day  - 1 second'
	FROM edw_dds.dim_segment s 
	WHERE 1 = 1
      and s.segment_key=21000
  	  and s.deleted_ind = 0
	  and to_date('20190630','YYYYMMDD')+ interval '1 day  - 1 second' between s.eff_dttm and s.exp_dttm
  ),
Subscribers_Charges as 
	(
	SELECT * 
	FROM 
	    (SELECT Row_Number() Over(PARTITION BY Abn_Id, Serv_Id ORDER BY Guid DESC) Nn
	         , t.*
	FROM edw_ods.t_000157_rprt_Subscribers_Charges t
	WHERE t.Period between to_date('20190601', 'YYYYMMDD') and to_date('20190630', 'YYYYMMDD')
	  and coalesce(T.soo_src_id, 0) NOT IN (140,1014)
	) sss where nn = 1)
----------------------------------------------------------------------
	SELECT  
        subs_ch.period as period
		, dim_reg_mrf.branch_code::numeric mrf_id
        , dim_reg_mrf.branch_name mrf_name
        , dim_reg.branch_code::numeric rf_id
        , dim_reg.branch_name rf_name
        , case when bs.business_segment_short_name like 'B2G%'
                   then 'B2G'
                 else bs.business_segment_short_name 
              end   client_type
        , dim_segment.segment_name macro_segment
        , dir_tech.def tech_name
        , count(distinct satp.PORT_NUM)+sum(case when satp.PORT_NUM is null then 1 else 0 end) capacity_use_od 
        , sum(case when subs_dwh.serv_id in (1,2,3) 
		           then 1 
				   else 0 end) USED_PORT_SERV 
        , sum(case when subs_dwh.serv_id=2 	       
		           then 1 
				   else 0 end) USED_PORT_SPD
        , sum(case when subs_dwh.serv_id=3          
		           then 1 
				   else 0 end) USED_PORT_IPTV
		, 0 USED_PORT_SIP --считаем логические порты SIP
		, 0 USED_PORT_VPN --считаем логические порты VPN
		, sum(case when subs_dwh.serv_id=1          
		           then 1 
				   else 0 end) USED_PORT_OTA 
		, rc.rc_code rc_code
		, rc.rc_short_name rc_short_name
		, dim_reg.oebs_r12_code subject_key	
		, dim_reg.oebs_r12_name region_name 
		, now() load_dttm
		, 000157 src_id 
	FROM Subscribers_Charges subs_ch
	INNER JOIN edw_ods.t_000157_rprt_Subscribers_Dwh subs_dwh 
	   on 1=1
	  and subs_ch.Guid = subs_dwh.Guid
      and subs_dwh.abn_id = subs_ch.abn_id
	 LEFT JOIN edw_ods.t_000157_rprt_SUBS_ACTUAL_TECH_PERIOD satp 
	   on 1=1
	  and subs_dwh.abn_id = satp.abn_id
	  and subs_dwh.mrf_id = satp.mrf_id
	  and subs_dwh.rf_id  = satp.rf_id
	  and satp.tech_dt between to_date('20190601','YYYYMMDD') and  to_date('20190630','YYYYMMDD')+ interval '1 day  - 1 second'
	INNER JOIN 	edw_ods.t_000157_rprt_client_dwh client_dwh 
	   on 1=1
	  and subs_dwh.CL_ID  = client_dwh.CL_ID
	  and subs_dwh.MRF_ID = client_dwh.MRF_ID
	  and subs_dwh.RF_ID  = client_dwh.RF_ID
	 LEFT JOIN edw_dds.hub_dim_segment hub_dim_segment 
	   on 1=1
	  and hub_dim_segment.source_key = client_dwh.id_macro_segment_ud::text
	  and to_date('20190630','YYYYMMDD')+ interval '1 day  - 1 second' between hub_dim_segment.eff_dttm and hub_dim_segment.exp_dttm
	  and hub_dim_segment.src_id = 158
	 LEFT JOIN edw_dds.dim_segment dim_segment 
	   on 1=1
	  and dim_segment.segment_key = hub_dim_segment.segment_key
	  and to_date('20190630','YYYYMMDD')+ interval '1 day  - 1 second' between dim_segment.eff_dttm and dim_segment.exp_dttm
	  and dim_segment.deleted_ind = 0
	 LEFT JOIN segm 
	   on 1=1 
      and hub_dim_segment.segment_key = segm.segment_key
	 LEFT JOIN edw_ods.t_000158_rprt_dir_tech dir_tech 
	   on 1=1
	  and decode(subs_dwh.tech_id,6,3,subs_dwh.tech_id) = dir_tech.tech_id
	 LEFT JOIN edw_ods.t_000158_rprt_dir_services dir_serv 
	   on 1=1
	  and subs_dwh.serv_id = dir_serv.serv_id
	--бранчи
	 LEFT JOIN edw_dds.hub_dim_oebs_r12_branch_ruz hdim_reg 
	   on 1=1
	  and hdim_reg.source_key = client_dwh.rf_id::text
	  and hdim_reg.src_id     = 158
	  and to_date('20190630','YYYYMMDD')+ interval '1 day  - 1 second' between hdim_reg.eff_dttm and hdim_reg.exp_dttm
	 LEFT JOIN edw_dds.dim_oebs_r12_branch_ruz dim_reg 
	   on 1=1 --Регион и РФ
	  and dim_reg.oebs_r12_branch_ruz_key = hdim_reg.oebs_r12_branch_ruz_key
	  and to_date('20190630','YYYYMMDD')+ interval '1 day  - 1 second' between dim_reg.eff_dttm and dim_reg.exp_dttm
	  and dim_reg.deleted_ind = 0
	 LEFT JOIN edw_dds.dim_oebs_r12_branch_ruz dim_reg_mrf
	   on 1=1 --Регион и РФ
	  and dim_reg_mrf.oebs_r12_code =  case when dim_reg.oebs_r12_code = '010030' then '011000'
	  									  else '0' || substring(dim_reg.branch_code,1,2)||'000'
	  									  end
	  and to_date('20190630','YYYYMMDD')+ interval '1 day  - 1 second' between dim_reg_mrf.eff_dttm and dim_reg_mrf.exp_dttm
	  and dim_reg_mrf.deleted_ind = 0	
	--ЦФО
	 LEFT JOIN edw_dds.hub_dim_business_service_ruz hd_business_service_ruz 
	   on 1=1
	  and hd_business_service_ruz.source_key = subs_dwh.serv_id::text
	  and hd_business_service_ruz.src_id = 158
	  and to_date('20190630','YYYYMMDD')+ interval '1 day  - 1 second' between hd_business_service_ruz.eff_dttm and hd_business_service_ruz.exp_dttm	
	 LEFT JOIN edw_dds.dim_matrix_ruz_rc dim_matrix_ruz_rc 
	   on 1=1
	  and dim_matrix_ruz_rc.business_service_ruz_key = hd_business_service_ruz.business_service_ruz_key
	  and dim_matrix_ruz_rc.segment_key = hub_dim_segment.segment_key
	  and to_date('20190630','YYYYMMDD')+ interval '1 day  - 1 second' between dim_matrix_ruz_rc.eff_dttm and dim_matrix_ruz_rc.exp_dttm
	  and dim_matrix_ruz_rc.deleted_ind = 0	
	 LEFT JOIN edw_dds.dim_rc rc  
	   on 1=1
	  and rc.rc_key = dim_matrix_ruz_rc.rc_key
	  and to_date('20190630','YYYYMMDD')+ interval '1 day  - 1 second' between rc.eff_dttm and rc.exp_dttm
	  and rc.deleted_ind = 0	
	 LEFT JOIN edw_dds.dim_business_segment bs 
	   on bs.business_segment_key = rc.business_segment_key
	  and to_date('20190630','YYYYMMDD')+ interval '1 day  - 1 second' between bs.eff_dttm and bs.exp_dttm
	  and bs.deleted_ind = 0	
	WHERE 	1=1 
	  and coalesce(subs_dwh.soo_src_id) NOT IN (140,1014)
	  and ((coalesce(subs_dwh.Data_Close_Serv, subs_dwh.Data_Close)) IS NULL
          	OR coalesce(subs_dwh.Data_Close_Serv, subs_dwh.Data_Close) > to_date('20190630','YYYYMMDD') + interval'1 month - 1 second' )
     	and coalesce(subs_dwh.Data_Connect, subs_dwh.Data_Contr) <= to_date('20190630','YYYYMMDD') + interval'1 month - 1 second'
	  and case when segm.segment_key is not null
	    	   then date_trunc('month', greatest(coalesce(subs_dwh.DATE_BILL, TO_DATE('19000101', 'YYYYMMDD')), subs_dwh.DATE_SNAP)) >= to_date('20190601','YYYYMMDD') - interval'7 months'
			   else true end
		and subs_dwh.serv_id in (1,2,3) --OTA, SHPD, IPTV		
		and   (subs_dwh.soo_src_id =  141 and subs_dwh.tech_id in (1,2,3,6,0) --PON, FTTX, XDSL, copper, other
			   or subs_dwh.soo_src_id != 141 and subs_dwh.tech_id in (1,2,3,6)) --PON, FTTX, XDSL, copper
		and dim_segment.segment_key is not null
		and dim_segment.segment_key not in (-1,-2)
	GROUP BY
          subs_ch.period      
            , dir_tech.def
    	    , dim_reg_mrf.branch_code 
	        , dim_reg_mrf.branch_name 
	        , dim_reg.branch_code 
	        , dim_reg.branch_name 
            , rc.rc_short_name
            , dim_segment.segment_name
            , dim_reg.oebs_r12_code     
            , dim_reg.oebs_r12_name
            , case when bs.business_segment_short_name like 'B2G%' 
                   then 'B2G'
                   else bs.business_segment_short_name end 
            , rc.rc_code;

COMMIT;

ANALYSE edw_stg_dm_ruz.tfct_ruz_port_vpn_sip_1_prt_p000157;
