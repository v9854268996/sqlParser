/*rev.18794 от 04.12.2018*/
set optimizer = on;
truncate table edw_stg_dds.t_000033_tfct_account_delivery_state;
insert into edw_stg_dds.t_000033_tfct_account_delivery_state 
(
 account_key,
 snap_dt,
 delivery_type_key,
 manager_fio,
 src_id
)
with 
dlvr as (
	select 
		 dfdogovor
		,dfbill_meth_delivary
	from edw_ods.t_000033_tfpd_edo_meth em
	where 1 = 1 
		and to_date('20190630', 'YYYYMMDD') between em.dfdatebegin and coalesce(em.dfdateend,to_date('29991231', 'YYYYMMDD'))
		and deleted_ind='0'
	),
mngr as (
	select 
		sc.dfdogovor
		,first_value(tc.dfname) OVER (PARTITION BY sc.dfdogovor 
							ORDER BY sc.dfdatebegin DESC, sc.dfdog_sales_chanel desc
							rows between unbounded preceding and unbounded following) manager_fio
	from edw_ods.t_000033_tdog_sales_chanel  sc
	inner join edw_ods.t_000033_tsubsales_channels tc 
		on 1 = 1 
	  	and tc.dfsubsales_channels = sc.DFSUBSALES_CHANNELS
	  	and tc.dfsales_channels = sc.dfsales_channels
	  	and to_date('20190630', 'YYYYMMDD') between tc.dfdateinbegin and coalesce(tc.dfdateinend, to_date('29991231', 'YYYYMMDD'))
		and tc.deleted_ind='0'
	where 1 = 1
		and to_date('20190630', 'YYYYMMDD') between sc.dfdatebegin and coalesce(sc.dfdateend, to_date('29991231', 'YYYYMMDD'))
		and sc.deleted_ind='0'
	)
select 
src_id||';'||user_id account_key
, date_trunc('month',to_date('20190630', 'YYYYMMDD')) snap_dt  
, case 
 when sum(case when  t.cod = 10 then 1 else 0 end) > 0 then 0
 when sum(case when  t.cod = 1  then 1 else 0 end) > 0 then 19
 when sum(case when  t.cod = 2  then 1 else 0 end) > 0 then 18
 when sum(case when  t.cod = 3  then 1 else 0 end) > 0 then 6
 when sum(case when  t.cod = 11 then 1 else 0 end) > 0 then 6
 when sum(case when  t.cod = 6  then 1 else 0 end) > 0 then 6
 when sum(case when  t.cod = 8  then 1 else 0 end) > 0 then 14
 when sum(case when  t.cod = 12 then 1 else 0 end) > 0 then 14
 when sum(case when  t.cod = 4  then 1 else 0 end) > 0 then 3
 when sum(case when  t.cod = 9  then 1 else 0 end) > 0 then 1  
 when sum(case when  t.cod = 7  then 1 else 0 end) > 0 then 1
 when sum(case when  t.cod = 5  then 1 else 0 end) > 0 then 2
 else 1 
end delivery_type_key
, max(manager_fio) manager_fio
, src_id
from 
(
 select 
    dog.src_id
  , cast(dog.dfdogovor as numeric(38, 0)) as user_id
  , dlvr.dfbill_meth_delivary cod
  , mngr.manager_fio
 from edw_ods.t_000033_tdogovor dog 
 	left join dlvr on 1=1 
 		and dog.dfdogovor = dlvr.dfdogovor
	left join mngr on 1=1 
 		and dog.dfdogovor = mngr.dfdogovor	
 where 1 = 1
 and to_date('20190630', 'YYYYMMDD') between dog.dfdatebegin and coalesce(dog.dfdateend,to_date('29991231', 'YYYYMMDD')) 
 and dog.deleted_ind='0'
 and dog.dfdogtype <> 1234567
 and (dog.src_id = 39 OR (dog.dfdelete <> 'T' OR dog.dfdelete IS NULL))
) t
group by src_id, account_key;
commit;
analyse edw_stg_dds.t_000033_tfct_account_delivery_state;