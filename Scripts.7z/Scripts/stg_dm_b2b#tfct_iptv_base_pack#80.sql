-- rev. 54314 от 08.04.2020
SET search_path = edw_stg_dm_b2b;
SET optimizer = ON;
COMMIT;

BEGIN;
  TRUNCATE TABLE edw_stg_dm_b2b.tfct_iptv_base_pack_1_prt_p000080;
COMMIT;

BEGIN;
INSERT INTO edw_stg_dm_b2b.tfct_iptv_base_pack_1_prt_p000080
(
  period,            -- Период
  mrf_id,            -- Идентификатор МРФ
  rf_id,             -- Идентификатор РФ
  inn,               -- ИНН
  okved,             -- Код ОКВЭД
  name_okved,        -- ОКВЭД
  segment_code,      -- Код сегмента
  segment_name,      -- Наимененование сегмента
  contr_name,        -- Наименование контрагента
  adress_dev,        -- Адрес объекта предоставления услу
  account,           -- ЛС
  san,               -- САН
  data_contr,        -- Дата подключения
  pack_name,         -- Наименование основного ТВ-пакета
  base_pack_charges, -- Сервисная выручка
  rtk_detail_code,   -- Код дохода
  sub_product,       -- Подпродукт
  src_id
)
WITH
charges AS
(
  SELECT
         chgd.period,
         vdb.branch_mrf_key AS mrf_id,
         vdb.branch_key AS rf_id,
         cl.inn,
         t.okved,
         t1.name_okved,
         dms.macro_segment AS segment_code,
         dms.name_microsegment AS segment_name,
         cl.contr_name,
         sa.adress_dev,
         chgd.account,
         sip.srv_login_name,
         ts.date_begin,
         CASE
           WHEN position('""' IN svc.name) > 0 THEN split_part(svc.name, '""', 2)
           ELSE svc.name
         END AS pack_name,
         chgd.charge-chgd.vat_amount AS charges,
         dis.rtk_detail_code,
         dis.sub_product,
         coalesce(sip.src_id, ts.src_id, CASE
                                             WHEN chgd.soo_src_id = 602 THEN 85 -- Новосибирский филиал ПАО "Ростелеком"
                                             WHEN chgd.soo_src_id = 603 THEN 86 -- Омский филиал ПАО "Ростелеком"
                                             WHEN chgd.soo_src_id = 604 THEN 81 -- Алтайский филиал ПАО "Ростелеком"
                                             WHEN chgd.soo_src_id = 605 THEN 82 -- Красноярский филиал ПАО "Ростелеком"
                                             WHEN chgd.soo_src_id = 606 THEN 87 -- Томский филиал ПАО "Ростелеком"
                                             WHEN chgd.soo_src_id = 607 THEN 80 -- Бурятский филиал ПАО "Ростелеком"
                                             WHEN chgd.soo_src_id = 610 THEN 83 -- Иркутский филиал ПАО "Ростелеком"
                                             WHEN chgd.soo_src_id = 611 THEN 84 -- Кемеровский филиал ПАО "Ростелеком"
                                             WHEN chgd.soo_src_id = 612 THEN 88 -- Забайкальский филиал ПАО "Ростелеком"
                                             WHEN chgd.soo_src_id = 616 THEN 89 -- ВИП Сибирь
                                         END) AS src_id
    FROM edw_ods.t_000156_rprt_charges_dwh chgd
         JOIN
         edw_ods.t_000156_rprt_client_dwh cl
           ON chgd.cl_id = cl.cl_id
          AND chgd.mrf_id = cl.mrf_id
          AND coalesce(cl.data_close, '2999-12-31 00:00:00') >= to_date('20190630', 'YYYYMMDD')
         LEFT JOIN
         edw_dds.hub_dim_branch vdb1
           ON coalesce(cl.rf_id, chgd.rf_id)::text = vdb1.source_key
          AND vdb1.exp_dttm = '2999-12-31 00:00:00'
          AND vdb1.src_id = 158
         -- Определяем МРФ по РФ
         LEFT JOIN
         edw_ads.dim_branch vdb
           ON vdb1.branch_key = vdb.branch_key
          AND vdb.exp_dttm = '2999-12-31 00:00:00'
          AND vdb.deleted_ind = 0
         -- Выбираем определенные сегменты клиентов
         JOIN
         edw_ods.t_000158_rprt_dird_macro_sgmnt dms
           ON cl.id_macro_segment_ud = dms.id_macro_segment
          AND dms.macro_segment NOT LIKE 'K04%' --  приведено в соответствие с дашбордами по новым продуктам
          AND dms.deleted_ind = 0
         JOIN
         edw_dm_b2b.dim_iptv_services dis
           ON dis.rtk_detail_code = chgd.charge_code
          AND dis.category = 'Основные пакеты'
          AND dis.exp_dttm = '2999-12-31 00:00:00'
         LEFT JOIN
         (
           SELECT row_number() OVER (PARTITION BY user_id, serv_first_id ORDER BY service_id DESC) AS rn,
                  *
             FROM edw_ods.t_000080_t_services ts
            WHERE ts.deleted_ind = 0
              AND ts.date_begin <= to_date('20190630', 'YYYYMMDD')
              AND coalesce(ts.date_end, '2099-01-01') > date_trunc('month', to_date('20190630', 'YYYYMMDD'))
              AND to_date('20190630', 'YYYYMMDD') + interval '1 day - 1 second'  BETWEEN ts.eff_dttm AND ts.exp_dttm
         ) ts
           ON ts.serv_first_id::text = split_part(chgd.org_login,'#',2)
          AND ts.user_id::text = chgd.subs_id
          AND ts.rn=1
         LEFT JOIN
         (
            SELECT *
              FROM edw_ods.t_000080_t_svc_ref svc
             WHERE svc.deleted_ind = 0
               AND to_date('20190630', 'YYYYMMDD') + interval '1 day - 1 second' BETWEEN svc.eff_dttm AND svc.exp_dttm
         ) svc
           ON svc.svc_id::text = chgd.serv_id_src
          AND ts.src_id = svc.src_id
         LEFT JOIN
         (
           SELECT
                  row_number() OVER (PARTITION BY abn_id ORDER BY date_snap DESC, log_id DESC) AS rn,
                  cl_id,
                  abn_id,
                  subs_id,
                  serv_id,
                  data_contr,
                  coalesce(adress_dev, adress) AS adress_dev
             FROM edw_ods.t_000156_rprtsubscribersactual s
         ) sa
           ON chgd.abn_id = sa.abn_id
          AND chgd.cl_id = sa.cl_id
         LEFT JOIN
         (
             SELECT row_number() OVER (PARTITION BY inn, rf_id ORDER BY date_calc DESC) AS rn,
                    *
               FROM edw_ods.t_000158_budget_org_detail t
         ) t
           ON t.rf_id::text = chgd.rf_id::text
          AND t.inn::text = cl.inn::text
          AND t.rn = 1
         LEFT JOIN
         (
           SELECT row_number() OVER (PARTITION BY code_okved ORDER BY date_snap DESC) AS rn,
                  *
             FROM edw_ods.t_000158_bd_org_dir_okved
            WHERE date_start <= to_date('20190630', 'YYYYMMDD')
              AND deleted_ind = 0
         ) t1
           ON t1.code_okved = t.okved
          AND t1.rn = 1
         LEFT JOIN
         (
           SELECT
                  ss.srv_login_name,
                  ss.srv_service_id,
                  src_id
             FROM (
                    SELECT
                           row_number() OVER (PARTITION BY srv_login_name, srv_service_id ORDER BY srv_status_date DESC) AS rn,
                           CASE
                               WHEN srv_status = 'ACTIVE' OR (srv_status != 'ACTIVE' AND srv_status_date >= date_trunc('month', to_date('20190630', 'YYYYMMDD')))
                                  THEN 1
                               ELSE 0
                           END AS status,
                           srv_login_name,
                           srv_service_id,
                           src_id
                      FROM edw_ods.t_000080_stc_tdo_servs ss
                     WHERE to_date('20190630', 'YYYYMMDD') + interval '1 day - 1 second' BETWEEN ss.eff_dttm AND ss.exp_dttm
                       AND ss.deleted_ind = 0
                       AND srv_status_date <= to_date('20190630', 'YYYYMMDD')
                  ) ss
            WHERE ss.rn = 1
              AND ss.status = 1
         ) sip
           ON ts.service_id = sip.srv_service_id
          AND ts.src_id = sip.src_id
   WHERE chgd.period = date_trunc('month', to_date('20190630', 'YYYYMMDD'))
     AND chgd.coef_r12 = 1
     AND chgd.charge != 0
     AND coalesce(sip.src_id, ts.src_id, CASE
                                           WHEN chgd.soo_src_id = 602 THEN 85 -- Новосибирский филиал ПАО "Ростелеком"
                                           WHEN chgd.soo_src_id = 603 THEN 86 -- Омский филиал ПАО "Ростелеком"
                                           WHEN chgd.soo_src_id = 604 THEN 81 -- Алтайский филиал ПАО "Ростелеком"
                                           WHEN chgd.soo_src_id = 605 THEN 82 -- Красноярский филиал ПАО "Ростелеком"
                                           WHEN chgd.soo_src_id = 606 THEN 87 -- Томский филиал ПАО "Ростелеком"
                                           WHEN chgd.soo_src_id = 607 THEN 80 -- Бурятский филиал ПАО "Ростелеком"
                                           WHEN chgd.soo_src_id = 610 THEN 83 -- Иркутский филиал ПАО "Ростелеком"
                                           WHEN chgd.soo_src_id = 611 THEN 84 -- Кемеровский филиал ПАО "Ростелеком"
                                           WHEN chgd.soo_src_id = 612 THEN 88 -- Забайкальский филиал ПАО "Ростелеком"
                                           WHEN chgd.soo_src_id = 616 THEN 89 -- ВИП Сибирь
                                         END) = 000080::smallint --BETWEEN 80 AND 89
)
SELECT
       period,                            -- Период
       mrf_id,                            -- Идентификатор МРФ
       rf_id,                             -- Идентификатор РФ
       inn,                               -- ИНН
       okved,                             -- Код ОКВЭД
       name_okved,                        -- ОКВЭД
       segment_code,                      -- Код сегмента
       segment_name,                      -- Наимененование сегмента
       contr_name,                        -- Наименование контрагента
       adress_dev,                        -- Адрес объекта предоставления услу
       account,                           -- ЛС
       srv_login_name AS san,             -- САН
       date_begin AS date_contr,          -- Дата подключения
       pack_name,                         -- Наименование основного ТВ-пакета
       sum(charges) AS base_pack_charges, -- Сервисная выручка
       rtk_detail_code,                   -- Код дохода
       sub_product,                       -- Подпродукт
       000080::smallint AS src_id
  FROM charges
 GROUP BY period,
          mrf_id,
          rf_id,
          inn,
          okved,
          name_okved,
          segment_code,
          segment_name,
          contr_name,
          adress_dev,
          account,
          srv_login_name,
          date_begin,
          pack_name,
          rtk_detail_code,
          sub_product;
COMMIT;

BEGIN;
  ANALYZE edw_stg_dm_b2b.tfct_iptv_base_pack_1_prt_p000080;
END;
