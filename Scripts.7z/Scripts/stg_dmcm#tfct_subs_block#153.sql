--rev. 49517 от 13.02.2020
truncate table edw_stg_dmcm.tfct_subs_block_1_prt_p000153;
commit;
--------------------------------------------------------------------------000001 - 000016
--ОТА
insert into edw_stg_dmcm.tfct_subs_block_1_prt_p000153
  (
      subs_key
    , SUB_ID
    , ACCOUNT_NAME
    , BUSINESS_SERVICE_KEY
    , block_type_id
    , block_status_id
    , status_change_date
    , src_id
    , rf_src_id
  )
with period as
  (
    select
        to_date('20190601',  'YYYYMMDD') as start_date
      , to_date('20190630',  'YYYYMMDD') + interval '1 day - 1 second' as end_date
  )
, xref as
  (
    select
        xref.source_key
      , bs.business_service_key
      , bs.business_service_name
      , xref.sub_make
        
    from edw_stg_dds.t_dim_service_xref_start xref
        
    inner join edw_dds.dim_service et
            on xref.service_key = et.service_key
            and et.active_ind    = 'Y'
            and xref.exp_dttm between et.eff_dttm and et.exp_dttm

    inner join edw_dds.dim_business_service bs
            on bs.business_service_key = et.business_service_key
            and et.exp_dttm between bs.eff_dttm and bs.exp_dttm
            and bs.active_ind = 'Y'
    where
      to_date(substr('20190630',1,6),'YYYYMM') + INTERVAL '1 MONTH - 1 second' between xref.eff_dttm and xref.exp_dttm
      and upper(xref.region_id) = 'VOLGA'
  )
, svc_db as
  (
    select 
        sv.serv_first_id
      , sv.date_begin
      , coalesce(sv.date_end, to_date('29991231', 'YYYYMMDD')) as date_end
      , sv.dev_id
      , sv.sv_reason_id

    from edw_ods.t_000001_T_SV_STATUS sv    

    where
      now() between sv.eff_dttm and sv.exp_dttm
      and sv.date_begin <= to_date('20190630',  'YYYYMMDD')  + interval '1 day - 1 second'
      and coalesce(sv.date_end, to_date('29991231', 'YYYYMMDD')) >= to_date('20190601',  'YYYYMMDD')
  )
, t_services as
  (
    select
      ts.*
    from
      (
        select
            xref.business_service_key
          , xref.business_service_name
          , ts.serv_first_id||'#'|| coalesce(ts.dev_id::text, '')||'#'||ts.svctype||'#'|| coalesce(ts.main_serv_first_id::text, '') as sub_id
          , case
              when ts.svctype = '0'
               and ts.src_id <> 102
              then coalesce(ts.dev_id::text, '') || '##'
              when ts.svctype <> '0'
              then ts.serv_first_id::text
            end as subs_id
          , ts.* 

        from edw_ods.t_000001_t_services ts

        left join xref
               on xref.source_key = ts.svc_id::text

        where
          now() between ts.eff_dttm and ts.exp_dttm 
          and ts.deleted_ind = 0
          AND ts.svctype = '0' 
      )ts

    inner join
      (
        select
          subs_id
        from
          (
            select
                row_number() over (partition by subs_id order by p1_period DESC) as rn
              , subs_id
              , p1_period 
            from
              (
                  select distinct
                      oo_eff_tp.subs_id
                    , oo_eff_tp.p1_period 
                  from edw_ods.t_000153_efftp_oo_eff_tp oo_eff_tp
                  where
                    oo_eff_tp.tech_dt between date_trunc('month',to_date('20190630', 'YYYYMMDD'))::date - interval '1 month' and date_trunc('month',to_date('20190630', 'YYYYMMDD'))::date
                    and oo_eff_tp.serv_id = '1' -- ОТА
              ) oo_eff_tp
        ) oo_eff_tp
        where
          rn = 1
      ) oo_eff_tp
      on oo_eff_tp.subs_id = ts.subs_id

  )
, subs_block as
  (
    select
        substr('20190630',1,6) as bid
      , u.account
      , coalesce(svc.sv_reason_id, '-2') as block_type
      , svc.date_begin
      , coalesce(svc.date_end, to_date('29991231', 'YYYYMMDD') ) as date_end
      , s.dev_id ph
      , s.service_id
      , s.serv_first_id
      , u.user_id
      , s.business_service_key
      , s.business_service_name
      , s.sub_id
      , s.src_id

    from t_services s

    join svc_db svc
      on s.serv_first_id = svc.serv_first_id

    left join edw_ods.t_000001_t_users u
           on s.user_id = u.user_id
          and now() between u.eff_dttm and u.exp_dttm and u.deleted_ind = 0

    where
      to_date('20190630',  'YYYYMMDD') between date_trunc('day',s.date_begin) and coalesce(s.date_end, to_date('20190630',  'YYYYMMDD'))
        
    order by u.account, s.dev_id
  )

select distinct
    -1                                as subs_key
  , subs_block.sub_id
  , subs_block.account                as account_name
  , subs_block.business_service_key
  , coalesce(dbt.block_type_id, -1)   as block_type_id
  , coalesce(dbs.block_status_id, -1) as block_status_id -- блокировка установлена
  , subs_block.date_begin             as status_change_date
  , 000153                      as src_id
  , subs_block.src_id                 as rf_src_id

from subs_block

inner join period
        on subs_block.date_begin between period.start_date and period.end_date
                        
left join edw_dds.hub_dim_block_type dbt
       on subs_block.src_id::text = dbt.src_id::text
      and dbt.source_key::text = subs_block.block_type::text

left join edw_dds.hub_dim_block_status dbs
       on subs_block.src_id::text = dbs.src_id::text
      and dbs.source_key::text = '1'

union

select distinct
    -1                                as subs_key
  , subs_block.sub_id
  , subs_block.account                as account_name
  , subs_block.business_service_key
  , coalesce(dbt.block_type_id, -1)   as block_type_id
  , coalesce(dbs.block_status_id, -1) as block_status_id -- блокировка снята
  , subs_block.date_end               as status_change_date
  , 000153                      as src_id
  , subs_block.src_id                 as rf_src_id
        
from subs_block

inner join period
        on subs_block.date_end between period.start_date and period.end_date

left join edw_dds.hub_dim_block_type dbt
       on subs_block.src_id::text = dbt.src_id::text
      and dbt.source_key::text = subs_block.block_type::text

left join edw_dds.hub_dim_block_status dbs
       on subs_block.src_id::text = dbs.src_id::text
      and dbs.source_key::text = '2'
;

-- ШПД, IPTV
insert into edw_stg_dmcm.tfct_subs_block_1_prt_p000153
  (
      subs_key
    , sub_id
    , account_name
    , business_service_key
    , block_type_id
    , block_status_id
    , status_change_date
    , src_id
    , rf_src_id
  )

with period as
  (
    select
        to_date('20190601', 'YYYYMMDD') as start_date
      , to_date('20190630', 'YYYYMMDD') + interval '1 day - 1 second' as end_date
  )
, xref as
  (
    select
        xref.source_key
      , bs.business_service_key
      , bs.business_service_name
      , xref.sub_make
        
    from edw_stg_dds.t_dim_service_xref_start xref
        
    inner join edw_dds.dim_service et
            on xref.service_key = et.service_key
           and et.active_ind    = 'Y'
           and xref.exp_dttm between et.eff_dttm and et.exp_dttm

    inner join edw_dds.dim_business_service bs
            on bs.business_service_key = et.business_service_key
           and et.exp_dttm between bs.eff_dttm and bs.exp_dttm
           and bs.active_ind = 'Y'
    where
      to_date(substr('20190630',1,6),'YYYYMM') + interval '1 MONTH - 1 second' between xref.eff_dttm and xref.exp_dttm
      and upper(xref.region_id) = 'VOLGA'
  )
, t_services as
  (
    select
      ts.*
    from
      (
        select
            xref.business_service_key
          , xref.business_service_name
          , ts.serv_first_id||'#'|| coalesce(ts.dev_id::text, '')||'#'||ts.svctype||'#'|| coalesce(ts.main_serv_first_id::text, '') as sub_id
          , case
              when ts.svctype = '0'
               and ts.src_id <> 102
              then coalesce(ts.dev_id::text, '') || '##'
              when ts.svctype <> '0'
              then ts.serv_first_id::text
            end as subs_id
          , ts.* 

        from edw_ods.t_000001_t_services ts

        left join xref
               on xref.source_key = ts.svc_id::text

        where
          now() between ts.eff_dttm and ts.exp_dttm 
          and ts.deleted_ind = 0
          and ts.svctype != '0' 
      ) ts

    inner join
      (
        select
          subs_id
        from
          (
            select
                row_number() over (partition by subs_id order by p1_period DESC) as rn
              , subs_id
              , p1_period 
            from
              (
                select distinct
                    oo_eff_tp.subs_id
                  , oo_eff_tp.p1_period

                from edw_ods.t_000153_efftp_oo_eff_tp oo_eff_tp

                where
                  oo_eff_tp.tech_dt between date_trunc('month',to_date('20190630', 'YYYYMMDD'))::date - interval '1 month' and date_trunc('month',to_date('20190630', 'YYYYMMDD'))::date
                  and oo_eff_tp.serv_id in ('2', '3') -- ШПД, IPTV
              ) oo_eff_tp
          ) oo_eff_tp
        where
          rn = 1
      ) oo_eff_tp
      on oo_eff_tp.subs_id = ts.subs_id
  )
, all_blocking as
  (
    select
        bl_id
      , bl_from
      , bl_ab_id
      , bl_to
      , bl_us_user_name
      , bl_uss_sl_type
      , bl_uss_logname
      , bl_cpu_id
      , bl_desc
      , inputer
      , input_date
      , updater
      , update_date
      , bl_repayment_fl
      , bl_from_used_fl
      , bl_to_used_fl
      , bl_bc_code
      , bl_status
      , row_number() over (partition by bl_id order by bl_status DESC) as rn
    from
    (
      select
          bl_id
        , bl_from
        , bl_ab_id
        , bl_to
        , bl_us_user_name
        , bl_uss_sl_type
        , bl_uss_logname
        , bl_cpu_id
        , bl_desc
        , inputer
        , input_date
        , updater
        , update_date
        , bl_repayment_fl
        , bl_from_used_fl
        , bl_to_used_fl
        , bl_bc_code
        , bl_status
      from edw_ods.t_000016_ct_blocking ct
      where
        ct.bl_status != 'F' 
        and NOW() between ct.eff_dttm and ct.exp_dttm
        and ct.bl_id not in (select bl_id from edw_ods.t_000016_tb_blocking_archive where now() between eff_dttm and exp_dttm)

      union all

      select
          bl_id
        , bl_from
        , bl_ab_id
        , bl_to
        , bl_us_user_name
        , bl_uss_sl_type
        , bl_uss_logname
        , bl_cpu_id
        , bl_desc
        , inputer
        , input_date
        , updater
        , update_date
        , bl_repayment_fl
        , bl_from_used_fl
        , bl_to_used_fl
        , bl_bc_code
        , bl_status
            
      from edw_ods.t_000016_tb_blocking_archive 
      where
        bl_status != 'F'
        and now() between eff_dttm and exp_dttm
    )tab
  )
, svc_db as
  (
    select distinct
        round(ab_id)                                          as ab_id -- "Код абонента"
      , ab.ab_external_code                                   as account
      , us.us_user_name -- "Подключение"
      , blk.bl_from                                           as start_block
      , coalesce(blk.bl_to, to_date('29991231', 'YYYYMMDD'))  as end_block
      , bl_bc_code -- тип блокировки
      , ssip.serv_first_id
        
    from all_blocking blk

    inner join edw_ods.t_000016_abonent ab
            on ab.ab_id = blk.BL_AB_ID 
           and now() between ab.eff_dttm and ab.exp_dttm 
                          
    inner join edw_ods.t_000016_ct_users us
            on ab.ab_id = us.US_AB_ID 
           and coalesce(blk.bl_us_user_name, us.us_user_name) = us.us_user_name
           and us.tech_dt between to_date('20190601', 'YYYYMMDD') and to_date('20190630', 'YYYYMMDD') + interval '1 day - 1 second'
           and us.US_REGDATE <= to_date('20190630', 'YYYYMMDD') + interval '1 day - 1 second'
           and coalesce(us.us_close_date,now()) >= to_date('20190601', 'YYYYMMDD')          
                          
    inner join edw_ods.t_000016_ibs_abs_accounts i
            on i.abs_external_code = ab.ab_external_code 
           and now() between i.eff_dttm and i.exp_dttm
                              
    inner join edw_ods.t_000016_ct_user_services uss
            on uss.uss_us_user_name = us.US_USER_NAME 
           and to_date('20190630', 'YYYYMMDD') + interval '1 day - 1 second' between uss.eff_dttm and uss.exp_dttm

    inner join edw_ods.t_000001_t_service_sip ssip
            on uss.uss_login = ssip.sip_id 
           and ssip.version_state = 'ACTIVE'
           and to_date('20190630', 'YYYYMMDD') + interval '1 day - 1 second' between ssip.eff_dttm and ssip.exp_dttm
           and to_date('20190630', 'YYYYMMDD') + interval '1 day - 1 second' between ssip.date_begin and ssip.date_end
    where
      blk.rn = 1
      and
        (
          blk.BL_FROM <= to_date('20190630', 'YYYYMMDD') + interval '1 day - 1 second'
          and
            (
              blk.BL_TO >= to_date('20190601', 'YYYYMMDD')
              or blk.BL_TO is null
            )
        )
  )
, subs_block as
  (
    select
        substr('20190630',1,6) as bid
      , u.account
      , svc.BL_BC_CODE
      , svc.start_block         as date_begin
      , svc.end_block           as date_end
      , s.dev_id ph
      , s.service_id
      , s.serv_first_id
      , u.user_id
      , s.src_id
      , s.business_service_key
      , s.business_service_name
      , s.sub_id
    from t_services s
    left join edw_ods.t_000001_t_users u
           on s.user_id = u.user_id
          and now() between u.eff_dttm and u.exp_dttm
          and u.deleted_ind = 0
    inner join svc_db svc
            on s.serv_first_id = svc.serv_first_id
           and svc.account = u.account
    where
      date_trunc('day',s.date_begin) <= to_date('20190630', 'YYYYMMDD') + interval '1 day - 1 second'
      and coalesce(s.date_end, to_date('20190630', 'YYYYMMDD')) >= to_date('20190601', 'YYYYMMDD')    
    order by u.account, s.dev_id
  )
, subs_block_period as
  (
    select distinct
        -1                                  as subs_key
      , subs_block.sub_id
      , subs_block.account                  as account_name
      , subs_block.business_service_key
      , bl_bc_code                          as block_type_id
      , 1                                   as block_status_id    -- блокировка установлена
      , subs_block.date_begin               as status_change_date
      , subs_block.src_id

    from subs_block

    inner join period
      on subs_block.date_begin between period.start_date and period.end_date

    union

    select distinct
          -1                                as subs_key
        , subs_block.sub_id
        , subs_block.account                as account_name
        , subs_block.business_service_key
        , bl_bc_code                        as block_type_id
        , 2                                 as block_status_id    -- блокировка снята
        , subs_block.date_end               as status_change_date
      , subs_block.src_id 

    from subs_block

    inner join period
      on subs_block.date_end between period.start_date and period.end_date
  )
, subs_block_type as
  (
    select
        sb.subs_key
      , sb.sub_id
      , sb.account_name
      , sb.business_service_key
      , coalesce(dbt.block_type_id, -1)   as block_type_id
      , coalesce(dbs.block_status_id, -1) as block_status_id
      , sb.status_change_date
      , row_number() over(partition by sb.sub_id, sb.business_service_key, coalesce(dbt.block_type_id, '-1'), sb.block_status_id, sb.status_change_date order by sb.block_type_id) as rn
      , sb.src_id

    from subs_block_period sb

    left join edw_dds.hub_dim_block_type dbt
           on sb.src_id::text = dbt.src_id::text
          and dbt.source_key::text = sb.block_type_id::text
                          
    left join edw_dds.hub_dim_block_status dbs
           on sb.src_id::text = dbs.src_id::text
          and dbs.source_key::text = sb.block_status_id::text
  )

select
    subs_key
  , sub_id
  , account_name
  , business_service_key
  , block_type_id
  , block_status_id
  , status_change_date
  , 000153    as src_id
  , src_id          as rf_src_id

from subs_block_type

where
  rn = 1;

--------------------------------------------------------------------------000002 - 000017
--ОТА
insert into edw_stg_dmcm.tfct_subs_block_1_prt_p000153
  (
      subs_key
    , SUB_ID
    , ACCOUNT_NAME
    , BUSINESS_SERVICE_KEY
    , block_type_id
    , block_status_id
    , status_change_date
    , src_id
    , rf_src_id
  )
with period as
  (
    select
        to_date('20190601',  'YYYYMMDD') as start_date
      , to_date('20190630',  'YYYYMMDD') + interval '1 day - 1 second' as end_date
  )
, xref as
  (
    select
        xref.source_key
      , bs.business_service_key
      , bs.business_service_name
      , xref.sub_make
        
    from edw_stg_dds.t_dim_service_xref_start xref
        
    inner join edw_dds.dim_service et
            on xref.service_key = et.service_key
            and et.active_ind    = 'Y'
            and xref.exp_dttm between et.eff_dttm and et.exp_dttm

    inner join edw_dds.dim_business_service bs
            on bs.business_service_key = et.business_service_key
            and et.exp_dttm between bs.eff_dttm and bs.exp_dttm
            and bs.active_ind = 'Y'
    where
      to_date(substr('20190630',1,6),'YYYYMM') + INTERVAL '1 MONTH - 1 second' between xref.eff_dttm and xref.exp_dttm
      and upper(xref.region_id) = 'VOLGA'
  )
, svc_db as
  (
    select 
        sv.serv_first_id
      , sv.date_begin
      , coalesce(sv.date_end, to_date('29991231', 'YYYYMMDD')) as date_end
      , sv.dev_id
      , sv.sv_reason_id

    from edw_ods.t_000002_T_SV_STATUS sv    

    where
      now() between sv.eff_dttm and sv.exp_dttm
      and sv.date_begin <= to_date('20190630',  'YYYYMMDD')  + interval '1 day - 1 second'
      and coalesce(sv.date_end, to_date('29991231', 'YYYYMMDD')) >= to_date('20190601',  'YYYYMMDD')
  )
, t_services as
  (
    select
      ts.*
    from
      (
        select
            xref.business_service_key
          , xref.business_service_name
          , ts.serv_first_id||'#'|| coalesce(ts.dev_id::text, '')||'#'||ts.svctype||'#'|| coalesce(ts.main_serv_first_id::text, '') as sub_id
          , case
              when ts.svctype = '0'
               and ts.src_id <> 102
              then coalesce(ts.dev_id::text, '') || '##'
              when ts.svctype <> '0'
              then ts.serv_first_id::text
            end as subs_id
          , ts.* 

        from edw_ods.t_000002_t_services ts

        left join xref
               on xref.source_key = ts.svc_id::text

        where
          now() between ts.eff_dttm and ts.exp_dttm 
          and ts.deleted_ind = 0
          AND ts.svctype = '0' 
      )ts

    inner join
      (
        select
          subs_id
        from
          (
            select
                row_number() over (partition by subs_id order by p1_period DESC) as rn
              , subs_id
              , p1_period 
            from
              (
                  select distinct
                      oo_eff_tp.subs_id
                    , oo_eff_tp.p1_period 
                  from edw_ods.t_000153_efftp_oo_eff_tp oo_eff_tp
                  where
                    oo_eff_tp.tech_dt between date_trunc('month',to_date('20190630', 'YYYYMMDD'))::date - interval '1 month' and date_trunc('month',to_date('20190630', 'YYYYMMDD'))::date
                    and oo_eff_tp.serv_id = '1' -- ОТА
              ) oo_eff_tp
        ) oo_eff_tp
        where
          rn = 1
      ) oo_eff_tp
      on oo_eff_tp.subs_id = ts.subs_id

  )
, subs_block as
  (
    select
        substr('20190630',1,6) as bid
      , u.account
      , coalesce(svc.sv_reason_id, '-2') as block_type
      , svc.date_begin
      , coalesce(svc.date_end, to_date('29991231', 'YYYYMMDD') ) as date_end
      , s.dev_id ph
      , s.service_id
      , s.serv_first_id
      , u.user_id
      , s.business_service_key
      , s.business_service_name
      , s.sub_id
      , s.src_id

    from t_services s

    join svc_db svc
      on s.serv_first_id = svc.serv_first_id

    left join edw_ods.t_000002_t_users u
           on s.user_id = u.user_id
          and now() between u.eff_dttm and u.exp_dttm and u.deleted_ind = 0

    where
      to_date('20190630',  'YYYYMMDD') between date_trunc('day',s.date_begin) and coalesce(s.date_end, to_date('20190630',  'YYYYMMDD'))
        
    order by u.account, s.dev_id
  )

select distinct
    -1                                as subs_key
  , subs_block.sub_id
  , subs_block.account                as account_name
  , subs_block.business_service_key
  , coalesce(dbt.block_type_id, -1)   as block_type_id
  , coalesce(dbs.block_status_id, -1) as block_status_id -- блокировка установлена
  , subs_block.date_begin             as status_change_date
  , 000153                      as src_id
  , subs_block.src_id                 as rf_src_id

from subs_block

inner join period
        on subs_block.date_begin between period.start_date and period.end_date
                        
left join edw_dds.hub_dim_block_type dbt
       on subs_block.src_id::text = dbt.src_id::text
      and dbt.source_key::text = subs_block.block_type::text

left join edw_dds.hub_dim_block_status dbs
       on subs_block.src_id::text = dbs.src_id::text
      and dbs.source_key::text = '1'

union

select distinct
    -1                                as subs_key
  , subs_block.sub_id
  , subs_block.account                as account_name
  , subs_block.business_service_key
  , coalesce(dbt.block_type_id, -1)   as block_type_id
  , coalesce(dbs.block_status_id, -1) as block_status_id -- блокировка снята
  , subs_block.date_end               as status_change_date
  , 000153                      as src_id
  , subs_block.src_id                 as rf_src_id
        
from subs_block

inner join period
        on subs_block.date_end between period.start_date and period.end_date

left join edw_dds.hub_dim_block_type dbt
       on subs_block.src_id::text = dbt.src_id::text
      and dbt.source_key::text = subs_block.block_type::text

left join edw_dds.hub_dim_block_status dbs
       on subs_block.src_id::text = dbs.src_id::text
      and dbs.source_key::text = '2'
;

-- ШПД, IPTV
insert into edw_stg_dmcm.tfct_subs_block_1_prt_p000153
  (
      subs_key
    , sub_id
    , account_name
    , business_service_key
    , block_type_id
    , block_status_id
    , status_change_date
    , src_id
    , rf_src_id
  )

with period as
  (
    select
        to_date('20190601', 'YYYYMMDD') as start_date
      , to_date('20190630', 'YYYYMMDD') + interval '1 day - 1 second' as end_date
  )
, xref as
  (
    select
        xref.source_key
      , bs.business_service_key
      , bs.business_service_name
      , xref.sub_make
        
    from edw_stg_dds.t_dim_service_xref_start xref
        
    inner join edw_dds.dim_service et
            on xref.service_key = et.service_key
           and et.active_ind    = 'Y'
           and xref.exp_dttm between et.eff_dttm and et.exp_dttm

    inner join edw_dds.dim_business_service bs
            on bs.business_service_key = et.business_service_key
           and et.exp_dttm between bs.eff_dttm and bs.exp_dttm
           and bs.active_ind = 'Y'
    where
      to_date(substr('20190630',1,6),'YYYYMM') + interval '1 MONTH - 1 second' between xref.eff_dttm and xref.exp_dttm
      and upper(xref.region_id) = 'VOLGA'
  )
, t_services as
  (
    select
      ts.*
    from
      (
        select
            xref.business_service_key
          , xref.business_service_name
          , ts.serv_first_id||'#'|| coalesce(ts.dev_id::text, '')||'#'||ts.svctype||'#'|| coalesce(ts.main_serv_first_id::text, '') as sub_id
          , case
              when ts.svctype = '0'
               and ts.src_id <> 102
              then coalesce(ts.dev_id::text, '') || '##'
              when ts.svctype <> '0'
              then ts.serv_first_id::text
            end as subs_id
          , ts.* 

        from edw_ods.t_000002_t_services ts

        left join xref
               on xref.source_key = ts.svc_id::text

        where
          now() between ts.eff_dttm and ts.exp_dttm 
          and ts.deleted_ind = 0
          and ts.svctype != '0' 
      ) ts

    inner join
      (
        select
          subs_id
        from
          (
            select
                row_number() over (partition by subs_id order by p1_period DESC) as rn
              , subs_id
              , p1_period 
            from
              (
                select distinct
                    oo_eff_tp.subs_id
                  , oo_eff_tp.p1_period

                from edw_ods.t_000153_efftp_oo_eff_tp oo_eff_tp

                where
                  oo_eff_tp.tech_dt between date_trunc('month',to_date('20190630', 'YYYYMMDD'))::date - interval '1 month' and date_trunc('month',to_date('20190630', 'YYYYMMDD'))::date
                  and oo_eff_tp.serv_id in ('2', '3') -- ШПД, IPTV
              ) oo_eff_tp
          ) oo_eff_tp
        where
          rn = 1
      ) oo_eff_tp
      on oo_eff_tp.subs_id = ts.subs_id
  )
, all_blocking as
  (
    select
        bl_id
      , bl_from
      , bl_ab_id
      , bl_to
      , bl_us_user_name
      , bl_uss_sl_type
      , bl_uss_logname
      , bl_cpu_id
      , bl_desc
      , inputer
      , input_date
      , updater
      , update_date
      , bl_repayment_fl
      , bl_from_used_fl
      , bl_to_used_fl
      , bl_bc_code
      , bl_status
      , row_number() over (partition by bl_id order by bl_status DESC) as rn
    from
    (
      select
          bl_id
        , bl_from
        , bl_ab_id
        , bl_to
        , bl_us_user_name
        , bl_uss_sl_type
        , bl_uss_logname
        , bl_cpu_id
        , bl_desc
        , inputer
        , input_date
        , updater
        , update_date
        , bl_repayment_fl
        , bl_from_used_fl
        , bl_to_used_fl
        , bl_bc_code
        , bl_status
      from edw_ods.t_000017_ct_blocking ct
      where
        ct.bl_status != 'F' 
        and NOW() between ct.eff_dttm and ct.exp_dttm
        and ct.bl_id not in (select bl_id from edw_ods.t_000017_tb_blocking_archive where now() between eff_dttm and exp_dttm)

      union all

      select
          bl_id
        , bl_from
        , bl_ab_id
        , bl_to
        , bl_us_user_name
        , bl_uss_sl_type
        , bl_uss_logname
        , bl_cpu_id
        , bl_desc
        , inputer
        , input_date
        , updater
        , update_date
        , bl_repayment_fl
        , bl_from_used_fl
        , bl_to_used_fl
        , bl_bc_code
        , bl_status
            
      from edw_ods.t_000017_tb_blocking_archive 
      where
        bl_status != 'F'
        and now() between eff_dttm and exp_dttm
    )tab
  )
, svc_db as
  (
    select distinct
        round(ab_id)                                          as ab_id -- "Код абонента"
      , ab.ab_external_code                                   as account
      , us.us_user_name -- "Подключение"
      , blk.bl_from                                           as start_block
      , coalesce(blk.bl_to, to_date('29991231', 'YYYYMMDD'))  as end_block
      , bl_bc_code -- тип блокировки
      , ssip.serv_first_id
        
    from all_blocking blk

    inner join edw_ods.t_000017_abonent ab
            on ab.ab_id = blk.BL_AB_ID 
           and now() between ab.eff_dttm and ab.exp_dttm 
                          
    inner join edw_ods.t_000017_ct_users us
            on ab.ab_id = us.US_AB_ID 
           and coalesce(blk.bl_us_user_name, us.us_user_name) = us.us_user_name
           and us.tech_dt between to_date('20190601', 'YYYYMMDD') and to_date('20190630', 'YYYYMMDD') + interval '1 day - 1 second'
           and us.US_REGDATE <= to_date('20190630', 'YYYYMMDD') + interval '1 day - 1 second'
           and coalesce(us.us_close_date,now()) >= to_date('20190601', 'YYYYMMDD')          
                          
    inner join edw_ods.t_000017_ibs_abs_accounts i
            on i.abs_external_code = ab.ab_external_code 
           and now() between i.eff_dttm and i.exp_dttm
                              
    inner join edw_ods.t_000017_ct_user_services uss
            on uss.uss_us_user_name = us.US_USER_NAME 
           and to_date('20190630', 'YYYYMMDD') + interval '1 day - 1 second' between uss.eff_dttm and uss.exp_dttm

    inner join edw_ods.t_000002_t_service_sip ssip
            on uss.uss_login = ssip.sip_id 
           and ssip.version_state = 'ACTIVE'
           and to_date('20190630', 'YYYYMMDD') + interval '1 day - 1 second' between ssip.eff_dttm and ssip.exp_dttm
           and to_date('20190630', 'YYYYMMDD') + interval '1 day - 1 second' between ssip.date_begin and ssip.date_end
    where
      blk.rn = 1
      and
        (
          blk.BL_FROM <= to_date('20190630', 'YYYYMMDD') + interval '1 day - 1 second'
          and
            (
              blk.BL_TO >= to_date('20190601', 'YYYYMMDD')
              or blk.BL_TO is null
            )
        )
  )
, subs_block as
  (
    select
        substr('20190630',1,6) as bid
      , u.account
      , svc.BL_BC_CODE
      , svc.start_block         as date_begin
      , svc.end_block           as date_end
      , s.dev_id ph
      , s.service_id
      , s.serv_first_id
      , u.user_id
      , s.src_id
      , s.business_service_key
      , s.business_service_name
      , s.sub_id
    from t_services s
    left join edw_ods.t_000002_t_users u
           on s.user_id = u.user_id
          and now() between u.eff_dttm and u.exp_dttm
          and u.deleted_ind = 0
    inner join svc_db svc
            on s.serv_first_id = svc.serv_first_id
           and svc.account = u.account
    where
      date_trunc('day',s.date_begin) <= to_date('20190630', 'YYYYMMDD') + interval '1 day - 1 second'
      and coalesce(s.date_end, to_date('20190630', 'YYYYMMDD')) >= to_date('20190601', 'YYYYMMDD')    
    order by u.account, s.dev_id
  )
, subs_block_period as
  (
    select distinct
        -1                                  as subs_key
      , subs_block.sub_id
      , subs_block.account                  as account_name
      , subs_block.business_service_key
      , bl_bc_code                          as block_type_id
      , 1                                   as block_status_id    -- блокировка установлена
      , subs_block.date_begin               as status_change_date
      , subs_block.src_id

    from subs_block

    inner join period
      on subs_block.date_begin between period.start_date and period.end_date

    union

    select distinct
          -1                                as subs_key
        , subs_block.sub_id
        , subs_block.account                as account_name
        , subs_block.business_service_key
        , bl_bc_code                        as block_type_id
        , 2                                 as block_status_id    -- блокировка снята
        , subs_block.date_end               as status_change_date
      , subs_block.src_id 

    from subs_block

    inner join period
      on subs_block.date_end between period.start_date and period.end_date
  )
, subs_block_type as
  (
    select
        sb.subs_key
      , sb.sub_id
      , sb.account_name
      , sb.business_service_key
      , coalesce(dbt.block_type_id, -1)   as block_type_id
      , coalesce(dbs.block_status_id, -1) as block_status_id
      , sb.status_change_date
      , row_number() over(partition by sb.sub_id, sb.business_service_key, coalesce(dbt.block_type_id, '-1'), sb.block_status_id, sb.status_change_date order by sb.block_type_id) as rn
      , sb.src_id

    from subs_block_period sb

    left join edw_dds.hub_dim_block_type dbt
           on sb.src_id::text = dbt.src_id::text
          and dbt.source_key::text = sb.block_type_id::text
                          
    left join edw_dds.hub_dim_block_status dbs
           on sb.src_id::text = dbs.src_id::text
          and dbs.source_key::text = sb.block_status_id::text
  )

select
    subs_key
  , sub_id
  , account_name
  , business_service_key
  , block_type_id
  , block_status_id
  , status_change_date
  , 000153    as src_id
  , src_id          as rf_src_id

from subs_block_type

where
  rn = 1;

--------------------------------------------------------------------------000003 - 000015
--ОТА
insert into edw_stg_dmcm.tfct_subs_block_1_prt_p000153
  (
      subs_key
    , SUB_ID
    , ACCOUNT_NAME
    , BUSINESS_SERVICE_KEY
    , block_type_id
    , block_status_id
    , status_change_date
    , src_id
    , rf_src_id
  )
with period as
  (
    select
        to_date('20190601',  'YYYYMMDD') as start_date
      , to_date('20190630',  'YYYYMMDD') + interval '1 day - 1 second' as end_date
  )
, xref as
  (
    select
        xref.source_key
      , bs.business_service_key
      , bs.business_service_name
      , xref.sub_make
        
    from edw_stg_dds.t_dim_service_xref_start xref
        
    inner join edw_dds.dim_service et
            on xref.service_key = et.service_key
            and et.active_ind    = 'Y'
            and xref.exp_dttm between et.eff_dttm and et.exp_dttm

    inner join edw_dds.dim_business_service bs
            on bs.business_service_key = et.business_service_key
            and et.exp_dttm between bs.eff_dttm and bs.exp_dttm
            and bs.active_ind = 'Y'
    where
      to_date(substr('20190630',1,6),'YYYYMM') + INTERVAL '1 MONTH - 1 second' between xref.eff_dttm and xref.exp_dttm
      and upper(xref.region_id) = 'VOLGA'
  )
, svc_db as
  (
    select 
        sv.serv_first_id
      , sv.date_begin
      , coalesce(sv.date_end, to_date('29991231', 'YYYYMMDD')) as date_end
      , sv.dev_id
      , sv.sv_reason_id

    from edw_ods.t_000003_T_SV_STATUS sv    

    where
      now() between sv.eff_dttm and sv.exp_dttm
      and sv.date_begin <= to_date('20190630',  'YYYYMMDD')  + interval '1 day - 1 second'
      and coalesce(sv.date_end, to_date('29991231', 'YYYYMMDD')) >= to_date('20190601',  'YYYYMMDD')
  )
, t_services as
  (
    select
      ts.*
    from
      (
        select
            xref.business_service_key
          , xref.business_service_name
          , ts.serv_first_id||'#'|| coalesce(ts.dev_id::text, '')||'#'||ts.svctype||'#'|| coalesce(ts.main_serv_first_id::text, '') as sub_id
          , case
              when ts.svctype = '0'
               and ts.src_id <> 102
              then coalesce(ts.dev_id::text, '') || '##'
              when ts.svctype <> '0'
              then ts.serv_first_id::text
            end as subs_id
          , ts.* 

        from edw_ods.t_000003_t_services ts

        left join xref
               on xref.source_key = ts.svc_id::text

        where
          now() between ts.eff_dttm and ts.exp_dttm 
          and ts.deleted_ind = 0
          AND ts.svctype = '0' 
      )ts

    inner join
      (
        select
          subs_id
        from
          (
            select
                row_number() over (partition by subs_id order by p1_period DESC) as rn
              , subs_id
              , p1_period 
            from
              (
                  select distinct
                      oo_eff_tp.subs_id
                    , oo_eff_tp.p1_period 
                  from edw_ods.t_000153_efftp_oo_eff_tp oo_eff_tp
                  where
                    oo_eff_tp.tech_dt between date_trunc('month',to_date('20190630', 'YYYYMMDD'))::date - interval '1 month' and date_trunc('month',to_date('20190630', 'YYYYMMDD'))::date
                    and oo_eff_tp.serv_id = '1' -- ОТА
              ) oo_eff_tp
        ) oo_eff_tp
        where
          rn = 1
      ) oo_eff_tp
      on oo_eff_tp.subs_id = ts.subs_id

  )
, subs_block as
  (
    select
        substr('20190630',1,6) as bid
      , u.account
      , coalesce(svc.sv_reason_id, '-2') as block_type
      , svc.date_begin
      , coalesce(svc.date_end, to_date('29991231', 'YYYYMMDD') ) as date_end
      , s.dev_id ph
      , s.service_id
      , s.serv_first_id
      , u.user_id
      , s.business_service_key
      , s.business_service_name
      , s.sub_id
      , s.src_id

    from t_services s

    join svc_db svc
      on s.serv_first_id = svc.serv_first_id

    left join edw_ods.t_000003_t_users u
           on s.user_id = u.user_id
          and now() between u.eff_dttm and u.exp_dttm and u.deleted_ind = 0

    where
      to_date('20190630',  'YYYYMMDD') between date_trunc('day',s.date_begin) and coalesce(s.date_end, to_date('20190630',  'YYYYMMDD'))
        
    order by u.account, s.dev_id
  )

select distinct
    -1                                as subs_key
  , subs_block.sub_id
  , subs_block.account                as account_name
  , subs_block.business_service_key
  , coalesce(dbt.block_type_id, -1)   as block_type_id
  , coalesce(dbs.block_status_id, -1) as block_status_id -- блокировка установлена
  , subs_block.date_begin             as status_change_date
  , 000153                      as src_id
  , subs_block.src_id                 as rf_src_id

from subs_block

inner join period
        on subs_block.date_begin between period.start_date and period.end_date
                        
left join edw_dds.hub_dim_block_type dbt
       on subs_block.src_id::text = dbt.src_id::text
      and dbt.source_key::text = subs_block.block_type::text

left join edw_dds.hub_dim_block_status dbs
       on subs_block.src_id::text = dbs.src_id::text
      and dbs.source_key::text = '1'

union

select distinct
    -1                                as subs_key
  , subs_block.sub_id
  , subs_block.account                as account_name
  , subs_block.business_service_key
  , coalesce(dbt.block_type_id, -1)   as block_type_id
  , coalesce(dbs.block_status_id, -1) as block_status_id -- блокировка снята
  , subs_block.date_end               as status_change_date
  , 000153                      as src_id
  , subs_block.src_id                 as rf_src_id
        
from subs_block

inner join period
        on subs_block.date_end between period.start_date and period.end_date

left join edw_dds.hub_dim_block_type dbt
       on subs_block.src_id::text = dbt.src_id::text
      and dbt.source_key::text = subs_block.block_type::text

left join edw_dds.hub_dim_block_status dbs
       on subs_block.src_id::text = dbs.src_id::text
      and dbs.source_key::text = '2'
;

-- ШПД, IPTV
insert into edw_stg_dmcm.tfct_subs_block_1_prt_p000153
  (
      subs_key
    , sub_id
    , account_name
    , business_service_key
    , block_type_id
    , block_status_id
    , status_change_date
    , src_id
    , rf_src_id
  )

with period as
  (
    select
        to_date('20190601', 'YYYYMMDD') as start_date
      , to_date('20190630', 'YYYYMMDD') + interval '1 day - 1 second' as end_date
  )
, xref as
  (
    select
        xref.source_key
      , bs.business_service_key
      , bs.business_service_name
      , xref.sub_make
        
    from edw_stg_dds.t_dim_service_xref_start xref
        
    inner join edw_dds.dim_service et
            on xref.service_key = et.service_key
           and et.active_ind    = 'Y'
           and xref.exp_dttm between et.eff_dttm and et.exp_dttm

    inner join edw_dds.dim_business_service bs
            on bs.business_service_key = et.business_service_key
           and et.exp_dttm between bs.eff_dttm and bs.exp_dttm
           and bs.active_ind = 'Y'
    where
      to_date(substr('20190630',1,6),'YYYYMM') + interval '1 MONTH - 1 second' between xref.eff_dttm and xref.exp_dttm
      and upper(xref.region_id) = 'VOLGA'
  )
, t_services as
  (
    select
      ts.*
    from
      (
        select
            xref.business_service_key
          , xref.business_service_name
          , ts.serv_first_id||'#'|| coalesce(ts.dev_id::text, '')||'#'||ts.svctype||'#'|| coalesce(ts.main_serv_first_id::text, '') as sub_id
          , case
              when ts.svctype = '0'
               and ts.src_id <> 102
              then coalesce(ts.dev_id::text, '') || '##'
              when ts.svctype <> '0'
              then ts.serv_first_id::text
            end as subs_id
          , ts.* 

        from edw_ods.t_000003_t_services ts

        left join xref
               on xref.source_key = ts.svc_id::text

        where
          now() between ts.eff_dttm and ts.exp_dttm 
          and ts.deleted_ind = 0
          and ts.svctype != '0' 
      ) ts

    inner join
      (
        select
          subs_id
        from
          (
            select
                row_number() over (partition by subs_id order by p1_period DESC) as rn
              , subs_id
              , p1_period 
            from
              (
                select distinct
                    oo_eff_tp.subs_id
                  , oo_eff_tp.p1_period

                from edw_ods.t_000153_efftp_oo_eff_tp oo_eff_tp

                where
                  oo_eff_tp.tech_dt between date_trunc('month',to_date('20190630', 'YYYYMMDD'))::date - interval '1 month' and date_trunc('month',to_date('20190630', 'YYYYMMDD'))::date
                  and oo_eff_tp.serv_id in ('2', '3') -- ШПД, IPTV
              ) oo_eff_tp
          ) oo_eff_tp
        where
          rn = 1
      ) oo_eff_tp
      on oo_eff_tp.subs_id = ts.subs_id
  )
, all_blocking as
  (
    select
        bl_id
      , bl_from
      , bl_ab_id
      , bl_to
      , bl_us_user_name
      , bl_uss_sl_type
      , bl_uss_logname
      , bl_cpu_id
      , bl_desc
      , inputer
      , input_date
      , updater
      , update_date
      , bl_repayment_fl
      , bl_from_used_fl
      , bl_to_used_fl
      , bl_bc_code
      , bl_status
      , row_number() over (partition by bl_id order by bl_status DESC) as rn
    from
    (
      select
          bl_id
        , bl_from
        , bl_ab_id
        , bl_to
        , bl_us_user_name
        , bl_uss_sl_type
        , bl_uss_logname
        , bl_cpu_id
        , bl_desc
        , inputer
        , input_date
        , updater
        , update_date
        , bl_repayment_fl
        , bl_from_used_fl
        , bl_to_used_fl
        , bl_bc_code
        , bl_status
      from edw_ods.t_000015_ct_blocking ct
      where
        ct.bl_status != 'F' 
        and NOW() between ct.eff_dttm and ct.exp_dttm
        and ct.bl_id not in (select bl_id from edw_ods.t_000015_tb_blocking_archive where now() between eff_dttm and exp_dttm)

      union all

      select
          bl_id
        , bl_from
        , bl_ab_id
        , bl_to
        , bl_us_user_name
        , bl_uss_sl_type
        , bl_uss_logname
        , bl_cpu_id
        , bl_desc
        , inputer
        , input_date
        , updater
        , update_date
        , bl_repayment_fl
        , bl_from_used_fl
        , bl_to_used_fl
        , bl_bc_code
        , bl_status
            
      from edw_ods.t_000015_tb_blocking_archive 
      where
        bl_status != 'F'
        and now() between eff_dttm and exp_dttm
    )tab
  )
, svc_db as
  (
    select distinct
        round(ab_id)                                          as ab_id -- "Код абонента"
      , ab.ab_external_code                                   as account
      , us.us_user_name -- "Подключение"
      , blk.bl_from                                           as start_block
      , coalesce(blk.bl_to, to_date('29991231', 'YYYYMMDD'))  as end_block
      , bl_bc_code -- тип блокировки
      , ssip.serv_first_id
        
    from all_blocking blk

    inner join edw_ods.t_000015_abonent ab
            on ab.ab_id = blk.BL_AB_ID 
           and now() between ab.eff_dttm and ab.exp_dttm 
                          
    inner join edw_ods.t_000015_ct_users us
            on ab.ab_id = us.US_AB_ID 
           and coalesce(blk.bl_us_user_name, us.us_user_name) = us.us_user_name
           and us.tech_dt between to_date('20190601', 'YYYYMMDD') and to_date('20190630', 'YYYYMMDD') + interval '1 day - 1 second'
           and us.US_REGDATE <= to_date('20190630', 'YYYYMMDD') + interval '1 day - 1 second'
           and coalesce(us.us_close_date,now()) >= to_date('20190601', 'YYYYMMDD')          
                          
    inner join edw_ods.t_000015_ibs_abs_accounts i
            on i.abs_external_code = ab.ab_external_code 
           and now() between i.eff_dttm and i.exp_dttm
                              
    inner join edw_ods.t_000015_ct_user_services uss
            on uss.uss_us_user_name = us.US_USER_NAME 
           and to_date('20190630', 'YYYYMMDD') + interval '1 day - 1 second' between uss.eff_dttm and uss.exp_dttm

    inner join edw_ods.t_000003_t_service_sip ssip
            on uss.uss_login = ssip.sip_id 
           and ssip.version_state = 'ACTIVE'
           and to_date('20190630', 'YYYYMMDD') + interval '1 day - 1 second' between ssip.eff_dttm and ssip.exp_dttm
           and to_date('20190630', 'YYYYMMDD') + interval '1 day - 1 second' between ssip.date_begin and ssip.date_end
    where
      blk.rn = 1
      and
        (
          blk.BL_FROM <= to_date('20190630', 'YYYYMMDD') + interval '1 day - 1 second'
          and
            (
              blk.BL_TO >= to_date('20190601', 'YYYYMMDD')
              or blk.BL_TO is null
            )
        )
  )
, subs_block as
  (
    select
        substr('20190630',1,6) as bid
      , u.account
      , svc.BL_BC_CODE
      , svc.start_block         as date_begin
      , svc.end_block           as date_end
      , s.dev_id ph
      , s.service_id
      , s.serv_first_id
      , u.user_id
      , s.src_id
      , s.business_service_key
      , s.business_service_name
      , s.sub_id
    from t_services s
    left join edw_ods.t_000003_t_users u
           on s.user_id = u.user_id
          and now() between u.eff_dttm and u.exp_dttm
          and u.deleted_ind = 0
    inner join svc_db svc
            on s.serv_first_id = svc.serv_first_id
           and svc.account = u.account
    where
      date_trunc('day',s.date_begin) <= to_date('20190630', 'YYYYMMDD') + interval '1 day - 1 second'
      and coalesce(s.date_end, to_date('20190630', 'YYYYMMDD')) >= to_date('20190601', 'YYYYMMDD')    
    order by u.account, s.dev_id
  )
, subs_block_period as
  (
    select distinct
        -1                                  as subs_key
      , subs_block.sub_id
      , subs_block.account                  as account_name
      , subs_block.business_service_key
      , bl_bc_code                          as block_type_id
      , 1                                   as block_status_id    -- блокировка установлена
      , subs_block.date_begin               as status_change_date
      , subs_block.src_id

    from subs_block

    inner join period
      on subs_block.date_begin between period.start_date and period.end_date

    union

    select distinct
          -1                                as subs_key
        , subs_block.sub_id
        , subs_block.account                as account_name
        , subs_block.business_service_key
        , bl_bc_code                        as block_type_id
        , 2                                 as block_status_id    -- блокировка снята
        , subs_block.date_end               as status_change_date
      , subs_block.src_id 

    from subs_block

    inner join period
      on subs_block.date_end between period.start_date and period.end_date
  )
, subs_block_type as
  (
    select
        sb.subs_key
      , sb.sub_id
      , sb.account_name
      , sb.business_service_key
      , coalesce(dbt.block_type_id, -1)   as block_type_id
      , coalesce(dbs.block_status_id, -1) as block_status_id
      , sb.status_change_date
      , row_number() over(partition by sb.sub_id, sb.business_service_key, coalesce(dbt.block_type_id, '-1'), sb.block_status_id, sb.status_change_date order by sb.block_type_id) as rn
      , sb.src_id

    from subs_block_period sb

    left join edw_dds.hub_dim_block_type dbt
           on sb.src_id::text = dbt.src_id::text
          and dbt.source_key::text = sb.block_type_id::text
                          
    left join edw_dds.hub_dim_block_status dbs
           on sb.src_id::text = dbs.src_id::text
          and dbs.source_key::text = sb.block_status_id::text
  )

select
    subs_key
  , sub_id
  , account_name
  , business_service_key
  , block_type_id
  , block_status_id
  , status_change_date
  , 000153    as src_id
  , src_id          as rf_src_id

from subs_block_type

where
  rn = 1;

--------------------------------------------------------------------------000004 - 000018
--ОТА
insert into edw_stg_dmcm.tfct_subs_block_1_prt_p000153
  (
      subs_key
    , SUB_ID
    , ACCOUNT_NAME
    , BUSINESS_SERVICE_KEY
    , block_type_id
    , block_status_id
    , status_change_date
    , src_id
    , rf_src_id
  )
with period as
  (
    select
        to_date('20190601',  'YYYYMMDD') as start_date
      , to_date('20190630',  'YYYYMMDD') + interval '1 day - 1 second' as end_date
  )
, xref as
  (
    select
        xref.source_key
      , bs.business_service_key
      , bs.business_service_name
      , xref.sub_make
        
    from edw_stg_dds.t_dim_service_xref_start xref
        
    inner join edw_dds.dim_service et
            on xref.service_key = et.service_key
            and et.active_ind    = 'Y'
            and xref.exp_dttm between et.eff_dttm and et.exp_dttm

    inner join edw_dds.dim_business_service bs
            on bs.business_service_key = et.business_service_key
            and et.exp_dttm between bs.eff_dttm and bs.exp_dttm
            and bs.active_ind = 'Y'
    where
      to_date(substr('20190630',1,6),'YYYYMM') + INTERVAL '1 MONTH - 1 second' between xref.eff_dttm and xref.exp_dttm
      and upper(xref.region_id) = 'VOLGA'
  )
, svc_db as
  (
    select 
        sv.serv_first_id
      , sv.date_begin
      , coalesce(sv.date_end, to_date('29991231', 'YYYYMMDD')) as date_end
      , sv.dev_id
      , sv.sv_reason_id

    from edw_ods.t_000004_T_SV_STATUS sv    

    where
      now() between sv.eff_dttm and sv.exp_dttm
      and sv.date_begin <= to_date('20190630',  'YYYYMMDD')  + interval '1 day - 1 second'
      and coalesce(sv.date_end, to_date('29991231', 'YYYYMMDD')) >= to_date('20190601',  'YYYYMMDD')
  )
, t_services as
  (
    select
      ts.*
    from
      (
        select
            xref.business_service_key
          , xref.business_service_name
          , ts.serv_first_id||'#'|| coalesce(ts.dev_id::text, '')||'#'||ts.svctype||'#'|| coalesce(ts.main_serv_first_id::text, '') as sub_id
          , case
              when ts.svctype = '0'
               and ts.src_id <> 102
              then coalesce(ts.dev_id::text, '') || '##'
              when ts.svctype <> '0'
              then ts.serv_first_id::text
            end as subs_id
          , ts.* 

        from edw_ods.t_000004_t_services ts

        left join xref
               on xref.source_key = ts.svc_id::text

        where
          now() between ts.eff_dttm and ts.exp_dttm 
          and ts.deleted_ind = 0
          AND ts.svctype = '0' 
      )ts

    inner join
      (
        select
          subs_id
        from
          (
            select
                row_number() over (partition by subs_id order by p1_period DESC) as rn
              , subs_id
              , p1_period 
            from
              (
                  select distinct
                      oo_eff_tp.subs_id
                    , oo_eff_tp.p1_period 
                  from edw_ods.t_000153_efftp_oo_eff_tp oo_eff_tp
                  where
                    oo_eff_tp.tech_dt between date_trunc('month',to_date('20190630', 'YYYYMMDD'))::date - interval '1 month' and date_trunc('month',to_date('20190630', 'YYYYMMDD'))::date
                    and oo_eff_tp.serv_id = '1' -- ОТА
              ) oo_eff_tp
        ) oo_eff_tp
        where
          rn = 1
      ) oo_eff_tp
      on oo_eff_tp.subs_id = ts.subs_id

  )
, subs_block as
  (
    select
        substr('20190630',1,6) as bid
      , u.account
      , coalesce(svc.sv_reason_id, '-2') as block_type
      , svc.date_begin
      , coalesce(svc.date_end, to_date('29991231', 'YYYYMMDD') ) as date_end
      , s.dev_id ph
      , s.service_id
      , s.serv_first_id
      , u.user_id
      , s.business_service_key
      , s.business_service_name
      , s.sub_id
      , s.src_id

    from t_services s

    join svc_db svc
      on s.serv_first_id = svc.serv_first_id

    left join edw_ods.t_000004_t_users u
           on s.user_id = u.user_id
          and now() between u.eff_dttm and u.exp_dttm and u.deleted_ind = 0

    where
      to_date('20190630',  'YYYYMMDD') between date_trunc('day',s.date_begin) and coalesce(s.date_end, to_date('20190630',  'YYYYMMDD'))
        
    order by u.account, s.dev_id
  )

select distinct
    -1                                as subs_key
  , subs_block.sub_id
  , subs_block.account                as account_name
  , subs_block.business_service_key
  , coalesce(dbt.block_type_id, -1)   as block_type_id
  , coalesce(dbs.block_status_id, -1) as block_status_id -- блокировка установлена
  , subs_block.date_begin             as status_change_date
  , 000153                      as src_id
  , subs_block.src_id                 as rf_src_id

from subs_block

inner join period
        on subs_block.date_begin between period.start_date and period.end_date
                        
left join edw_dds.hub_dim_block_type dbt
       on subs_block.src_id::text = dbt.src_id::text
      and dbt.source_key::text = subs_block.block_type::text

left join edw_dds.hub_dim_block_status dbs
       on subs_block.src_id::text = dbs.src_id::text
      and dbs.source_key::text = '1'

union

select distinct
    -1                                as subs_key
  , subs_block.sub_id
  , subs_block.account                as account_name
  , subs_block.business_service_key
  , coalesce(dbt.block_type_id, -1)   as block_type_id
  , coalesce(dbs.block_status_id, -1) as block_status_id -- блокировка снята
  , subs_block.date_end               as status_change_date
  , 000153                      as src_id
  , subs_block.src_id                 as rf_src_id
        
from subs_block

inner join period
        on subs_block.date_end between period.start_date and period.end_date

left join edw_dds.hub_dim_block_type dbt
       on subs_block.src_id::text = dbt.src_id::text
      and dbt.source_key::text = subs_block.block_type::text

left join edw_dds.hub_dim_block_status dbs
       on subs_block.src_id::text = dbs.src_id::text
      and dbs.source_key::text = '2'
;

-- ШПД, IPTV
insert into edw_stg_dmcm.tfct_subs_block_1_prt_p000153
  (
      subs_key
    , sub_id
    , account_name
    , business_service_key
    , block_type_id
    , block_status_id
    , status_change_date
    , src_id
    , rf_src_id
  )

with period as
  (
    select
        to_date('20190601', 'YYYYMMDD') as start_date
      , to_date('20190630', 'YYYYMMDD') + interval '1 day - 1 second' as end_date
  )
, xref as
  (
    select
        xref.source_key
      , bs.business_service_key
      , bs.business_service_name
      , xref.sub_make
        
    from edw_stg_dds.t_dim_service_xref_start xref
        
    inner join edw_dds.dim_service et
            on xref.service_key = et.service_key
           and et.active_ind    = 'Y'
           and xref.exp_dttm between et.eff_dttm and et.exp_dttm

    inner join edw_dds.dim_business_service bs
            on bs.business_service_key = et.business_service_key
           and et.exp_dttm between bs.eff_dttm and bs.exp_dttm
           and bs.active_ind = 'Y'
    where
      to_date(substr('20190630',1,6),'YYYYMM') + interval '1 MONTH - 1 second' between xref.eff_dttm and xref.exp_dttm
      and upper(xref.region_id) = 'VOLGA'
  )
, t_services as
  (
    select
      ts.*
    from
      (
        select
            xref.business_service_key
          , xref.business_service_name
          , ts.serv_first_id||'#'|| coalesce(ts.dev_id::text, '')||'#'||ts.svctype||'#'|| coalesce(ts.main_serv_first_id::text, '') as sub_id
          , case
              when ts.svctype = '0'
               and ts.src_id <> 102
              then coalesce(ts.dev_id::text, '') || '##'
              when ts.svctype <> '0'
              then ts.serv_first_id::text
            end as subs_id
          , ts.* 

        from edw_ods.t_000004_t_services ts

        left join xref
               on xref.source_key = ts.svc_id::text

        where
          now() between ts.eff_dttm and ts.exp_dttm 
          and ts.deleted_ind = 0
          and ts.svctype != '0' 
      ) ts

    inner join
      (
        select
          subs_id
        from
          (
            select
                row_number() over (partition by subs_id order by p1_period DESC) as rn
              , subs_id
              , p1_period 
            from
              (
                select distinct
                    oo_eff_tp.subs_id
                  , oo_eff_tp.p1_period

                from edw_ods.t_000153_efftp_oo_eff_tp oo_eff_tp

                where
                  oo_eff_tp.tech_dt between date_trunc('month',to_date('20190630', 'YYYYMMDD'))::date - interval '1 month' and date_trunc('month',to_date('20190630', 'YYYYMMDD'))::date
                  and oo_eff_tp.serv_id in ('2', '3') -- ШПД, IPTV
              ) oo_eff_tp
          ) oo_eff_tp
        where
          rn = 1
      ) oo_eff_tp
      on oo_eff_tp.subs_id = ts.subs_id
  )
, all_blocking as
  (
    select
        bl_id
      , bl_from
      , bl_ab_id
      , bl_to
      , bl_us_user_name
      , bl_uss_sl_type
      , bl_uss_logname
      , bl_cpu_id
      , bl_desc
      , inputer
      , input_date
      , updater
      , update_date
      , bl_repayment_fl
      , bl_from_used_fl
      , bl_to_used_fl
      , bl_bc_code
      , bl_status
      , row_number() over (partition by bl_id order by bl_status DESC) as rn
    from
    (
      select
          bl_id
        , bl_from
        , bl_ab_id
        , bl_to
        , bl_us_user_name
        , bl_uss_sl_type
        , bl_uss_logname
        , bl_cpu_id
        , bl_desc
        , inputer
        , input_date
        , updater
        , update_date
        , bl_repayment_fl
        , bl_from_used_fl
        , bl_to_used_fl
        , bl_bc_code
        , bl_status
      from edw_ods.t_000018_ct_blocking ct
      where
        ct.bl_status != 'F' 
        and NOW() between ct.eff_dttm and ct.exp_dttm
        and ct.bl_id not in (select bl_id from edw_ods.t_000018_tb_blocking_archive where now() between eff_dttm and exp_dttm)

      union all

      select
          bl_id
        , bl_from
        , bl_ab_id
        , bl_to
        , bl_us_user_name
        , bl_uss_sl_type
        , bl_uss_logname
        , bl_cpu_id
        , bl_desc
        , inputer
        , input_date
        , updater
        , update_date
        , bl_repayment_fl
        , bl_from_used_fl
        , bl_to_used_fl
        , bl_bc_code
        , bl_status
            
      from edw_ods.t_000018_tb_blocking_archive 
      where
        bl_status != 'F'
        and now() between eff_dttm and exp_dttm
    )tab
  )
, svc_db as
  (
    select distinct
        round(ab_id)                                          as ab_id -- "Код абонента"
      , ab.ab_external_code                                   as account
      , us.us_user_name -- "Подключение"
      , blk.bl_from                                           as start_block
      , coalesce(blk.bl_to, to_date('29991231', 'YYYYMMDD'))  as end_block
      , bl_bc_code -- тип блокировки
      , ssip.serv_first_id
        
    from all_blocking blk

    inner join edw_ods.t_000018_abonent ab
            on ab.ab_id = blk.BL_AB_ID 
           and now() between ab.eff_dttm and ab.exp_dttm 
                          
    inner join edw_ods.t_000018_ct_users us
            on ab.ab_id = us.US_AB_ID 
           and coalesce(blk.bl_us_user_name, us.us_user_name) = us.us_user_name
           and us.tech_dt between to_date('20190601', 'YYYYMMDD') and to_date('20190630', 'YYYYMMDD') + interval '1 day - 1 second'
           and us.US_REGDATE <= to_date('20190630', 'YYYYMMDD') + interval '1 day - 1 second'
           and coalesce(us.us_close_date,now()) >= to_date('20190601', 'YYYYMMDD')          
                          
    inner join edw_ods.t_000018_ibs_abs_accounts i
            on i.abs_external_code = ab.ab_external_code 
           and now() between i.eff_dttm and i.exp_dttm
                              
    inner join edw_ods.t_000018_ct_user_services uss
            on uss.uss_us_user_name = us.US_USER_NAME 
           and to_date('20190630', 'YYYYMMDD') + interval '1 day - 1 second' between uss.eff_dttm and uss.exp_dttm

    inner join edw_ods.t_000004_t_service_sip ssip
            on uss.uss_login = ssip.sip_id 
           and ssip.version_state = 'ACTIVE'
           and to_date('20190630', 'YYYYMMDD') + interval '1 day - 1 second' between ssip.eff_dttm and ssip.exp_dttm
           and to_date('20190630', 'YYYYMMDD') + interval '1 day - 1 second' between ssip.date_begin and ssip.date_end
    where
      blk.rn = 1
      and
        (
          blk.BL_FROM <= to_date('20190630', 'YYYYMMDD') + interval '1 day - 1 second'
          and
            (
              blk.BL_TO >= to_date('20190601', 'YYYYMMDD')
              or blk.BL_TO is null
            )
        )
  )
, subs_block as
  (
    select
        substr('20190630',1,6) as bid
      , u.account
      , svc.BL_BC_CODE
      , svc.start_block         as date_begin
      , svc.end_block           as date_end
      , s.dev_id ph
      , s.service_id
      , s.serv_first_id
      , u.user_id
      , s.src_id
      , s.business_service_key
      , s.business_service_name
      , s.sub_id
    from t_services s
    left join edw_ods.t_000004_t_users u
           on s.user_id = u.user_id
          and now() between u.eff_dttm and u.exp_dttm
          and u.deleted_ind = 0
    inner join svc_db svc
            on s.serv_first_id = svc.serv_first_id
           and svc.account = u.account
    where
      date_trunc('day',s.date_begin) <= to_date('20190630', 'YYYYMMDD') + interval '1 day - 1 second'
      and coalesce(s.date_end, to_date('20190630', 'YYYYMMDD')) >= to_date('20190601', 'YYYYMMDD')    
    order by u.account, s.dev_id
  )
, subs_block_period as
  (
    select distinct
        -1                                  as subs_key
      , subs_block.sub_id
      , subs_block.account                  as account_name
      , subs_block.business_service_key
      , bl_bc_code                          as block_type_id
      , 1                                   as block_status_id    -- блокировка установлена
      , subs_block.date_begin               as status_change_date
      , subs_block.src_id

    from subs_block

    inner join period
      on subs_block.date_begin between period.start_date and period.end_date

    union

    select distinct
          -1                                as subs_key
        , subs_block.sub_id
        , subs_block.account                as account_name
        , subs_block.business_service_key
        , bl_bc_code                        as block_type_id
        , 2                                 as block_status_id    -- блокировка снята
        , subs_block.date_end               as status_change_date
      , subs_block.src_id 

    from subs_block

    inner join period
      on subs_block.date_end between period.start_date and period.end_date
  )
, subs_block_type as
  (
    select
        sb.subs_key
      , sb.sub_id
      , sb.account_name
      , sb.business_service_key
      , coalesce(dbt.block_type_id, -1)   as block_type_id
      , coalesce(dbs.block_status_id, -1) as block_status_id
      , sb.status_change_date
      , row_number() over(partition by sb.sub_id, sb.business_service_key, coalesce(dbt.block_type_id, '-1'), sb.block_status_id, sb.status_change_date order by sb.block_type_id) as rn
      , sb.src_id

    from subs_block_period sb

    left join edw_dds.hub_dim_block_type dbt
           on sb.src_id::text = dbt.src_id::text
          and dbt.source_key::text = sb.block_type_id::text
                          
    left join edw_dds.hub_dim_block_status dbs
           on sb.src_id::text = dbs.src_id::text
          and dbs.source_key::text = sb.block_status_id::text
  )

select
    subs_key
  , sub_id
  , account_name
  , business_service_key
  , block_type_id
  , block_status_id
  , status_change_date
  , 000153    as src_id
  , src_id          as rf_src_id

from subs_block_type

where
  rn = 1;

--------------------------------------------------------------------------000005 - 000019
--ОТА
insert into edw_stg_dmcm.tfct_subs_block_1_prt_p000153
  (
      subs_key
    , SUB_ID
    , ACCOUNT_NAME
    , BUSINESS_SERVICE_KEY
    , block_type_id
    , block_status_id
    , status_change_date
    , src_id
    , rf_src_id
  )
with period as
  (
    select
        to_date('20190601',  'YYYYMMDD') as start_date
      , to_date('20190630',  'YYYYMMDD') + interval '1 day - 1 second' as end_date
  )
, xref as
  (
    select
        xref.source_key
      , bs.business_service_key
      , bs.business_service_name
      , xref.sub_make
        
    from edw_stg_dds.t_dim_service_xref_start xref
        
    inner join edw_dds.dim_service et
            on xref.service_key = et.service_key
            and et.active_ind    = 'Y'
            and xref.exp_dttm between et.eff_dttm and et.exp_dttm

    inner join edw_dds.dim_business_service bs
            on bs.business_service_key = et.business_service_key
            and et.exp_dttm between bs.eff_dttm and bs.exp_dttm
            and bs.active_ind = 'Y'
    where
      to_date(substr('20190630',1,6),'YYYYMM') + INTERVAL '1 MONTH - 1 second' between xref.eff_dttm and xref.exp_dttm
      and upper(xref.region_id) = 'VOLGA'
  )
, svc_db as
  (
    select 
        sv.serv_first_id
      , sv.date_begin
      , coalesce(sv.date_end, to_date('29991231', 'YYYYMMDD')) as date_end
      , sv.dev_id
      , sv.sv_reason_id

    from edw_ods.t_000005_T_SV_STATUS sv    

    where
      now() between sv.eff_dttm and sv.exp_dttm
      and sv.date_begin <= to_date('20190630',  'YYYYMMDD')  + interval '1 day - 1 second'
      and coalesce(sv.date_end, to_date('29991231', 'YYYYMMDD')) >= to_date('20190601',  'YYYYMMDD')
  )
, t_services as
  (
    select
      ts.*
    from
      (
        select
            xref.business_service_key
          , xref.business_service_name
          , ts.serv_first_id||'#'|| coalesce(ts.dev_id::text, '')||'#'||ts.svctype||'#'|| coalesce(ts.main_serv_first_id::text, '') as sub_id
          , case
              when ts.svctype = '0'
               and ts.src_id <> 102
              then coalesce(ts.dev_id::text, '') || '##'
              when ts.svctype <> '0'
              then ts.serv_first_id::text
            end as subs_id
          , ts.* 

        from edw_ods.t_000005_t_services ts

        left join xref
               on xref.source_key = ts.svc_id::text

        where
          now() between ts.eff_dttm and ts.exp_dttm 
          and ts.deleted_ind = 0
          AND ts.svctype = '0' 
      )ts

    inner join
      (
        select
          subs_id
        from
          (
            select
                row_number() over (partition by subs_id order by p1_period DESC) as rn
              , subs_id
              , p1_period 
            from
              (
                  select distinct
                      oo_eff_tp.subs_id
                    , oo_eff_tp.p1_period 
                  from edw_ods.t_000153_efftp_oo_eff_tp oo_eff_tp
                  where
                    oo_eff_tp.tech_dt between date_trunc('month',to_date('20190630', 'YYYYMMDD'))::date - interval '1 month' and date_trunc('month',to_date('20190630', 'YYYYMMDD'))::date
                    and oo_eff_tp.serv_id = '1' -- ОТА
              ) oo_eff_tp
        ) oo_eff_tp
        where
          rn = 1
      ) oo_eff_tp
      on oo_eff_tp.subs_id = ts.subs_id

  )
, subs_block as
  (
    select
        substr('20190630',1,6) as bid
      , u.account
      , coalesce(svc.sv_reason_id, '-2') as block_type
      , svc.date_begin
      , coalesce(svc.date_end, to_date('29991231', 'YYYYMMDD') ) as date_end
      , s.dev_id ph
      , s.service_id
      , s.serv_first_id
      , u.user_id
      , s.business_service_key
      , s.business_service_name
      , s.sub_id
      , s.src_id

    from t_services s

    join svc_db svc
      on s.serv_first_id = svc.serv_first_id

    left join edw_ods.t_000005_t_users u
           on s.user_id = u.user_id
          and now() between u.eff_dttm and u.exp_dttm and u.deleted_ind = 0

    where
      to_date('20190630',  'YYYYMMDD') between date_trunc('day',s.date_begin) and coalesce(s.date_end, to_date('20190630',  'YYYYMMDD'))
        
    order by u.account, s.dev_id
  )

select distinct
    -1                                as subs_key
  , subs_block.sub_id
  , subs_block.account                as account_name
  , subs_block.business_service_key
  , coalesce(dbt.block_type_id, -1)   as block_type_id
  , coalesce(dbs.block_status_id, -1) as block_status_id -- блокировка установлена
  , subs_block.date_begin             as status_change_date
  , 000153                      as src_id
  , subs_block.src_id                 as rf_src_id

from subs_block

inner join period
        on subs_block.date_begin between period.start_date and period.end_date
                        
left join edw_dds.hub_dim_block_type dbt
       on subs_block.src_id::text = dbt.src_id::text
      and dbt.source_key::text = subs_block.block_type::text

left join edw_dds.hub_dim_block_status dbs
       on subs_block.src_id::text = dbs.src_id::text
      and dbs.source_key::text = '1'

union

select distinct
    -1                                as subs_key
  , subs_block.sub_id
  , subs_block.account                as account_name
  , subs_block.business_service_key
  , coalesce(dbt.block_type_id, -1)   as block_type_id
  , coalesce(dbs.block_status_id, -1) as block_status_id -- блокировка снята
  , subs_block.date_end               as status_change_date
  , 000153                      as src_id
  , subs_block.src_id                 as rf_src_id
        
from subs_block

inner join period
        on subs_block.date_end between period.start_date and period.end_date

left join edw_dds.hub_dim_block_type dbt
       on subs_block.src_id::text = dbt.src_id::text
      and dbt.source_key::text = subs_block.block_type::text

left join edw_dds.hub_dim_block_status dbs
       on subs_block.src_id::text = dbs.src_id::text
      and dbs.source_key::text = '2'
;

-- ШПД, IPTV
insert into edw_stg_dmcm.tfct_subs_block_1_prt_p000153
  (
      subs_key
    , sub_id
    , account_name
    , business_service_key
    , block_type_id
    , block_status_id
    , status_change_date
    , src_id
    , rf_src_id
  )

with period as
  (
    select
        to_date('20190601', 'YYYYMMDD') as start_date
      , to_date('20190630', 'YYYYMMDD') + interval '1 day - 1 second' as end_date
  )
, xref as
  (
    select
        xref.source_key
      , bs.business_service_key
      , bs.business_service_name
      , xref.sub_make
        
    from edw_stg_dds.t_dim_service_xref_start xref
        
    inner join edw_dds.dim_service et
            on xref.service_key = et.service_key
           and et.active_ind    = 'Y'
           and xref.exp_dttm between et.eff_dttm and et.exp_dttm

    inner join edw_dds.dim_business_service bs
            on bs.business_service_key = et.business_service_key
           and et.exp_dttm between bs.eff_dttm and bs.exp_dttm
           and bs.active_ind = 'Y'
    where
      to_date(substr('20190630',1,6),'YYYYMM') + interval '1 MONTH - 1 second' between xref.eff_dttm and xref.exp_dttm
      and upper(xref.region_id) = 'VOLGA'
  )
, t_services as
  (
    select
      ts.*
    from
      (
        select
            xref.business_service_key
          , xref.business_service_name
          , ts.serv_first_id||'#'|| coalesce(ts.dev_id::text, '')||'#'||ts.svctype||'#'|| coalesce(ts.main_serv_first_id::text, '') as sub_id
          , case
              when ts.svctype = '0'
               and ts.src_id <> 102
              then coalesce(ts.dev_id::text, '') || '##'
              when ts.svctype <> '0'
              then ts.serv_first_id::text
            end as subs_id
          , ts.* 

        from edw_ods.t_000005_t_services ts

        left join xref
               on xref.source_key = ts.svc_id::text

        where
          now() between ts.eff_dttm and ts.exp_dttm 
          and ts.deleted_ind = 0
          and ts.svctype != '0' 
      ) ts

    inner join
      (
        select
          subs_id
        from
          (
            select
                row_number() over (partition by subs_id order by p1_period DESC) as rn
              , subs_id
              , p1_period 
            from
              (
                select distinct
                    oo_eff_tp.subs_id
                  , oo_eff_tp.p1_period

                from edw_ods.t_000153_efftp_oo_eff_tp oo_eff_tp

                where
                  oo_eff_tp.tech_dt between date_trunc('month',to_date('20190630', 'YYYYMMDD'))::date - interval '1 month' and date_trunc('month',to_date('20190630', 'YYYYMMDD'))::date
                  and oo_eff_tp.serv_id in ('2', '3') -- ШПД, IPTV
              ) oo_eff_tp
          ) oo_eff_tp
        where
          rn = 1
      ) oo_eff_tp
      on oo_eff_tp.subs_id = ts.subs_id
  )
, all_blocking as
  (
    select
        bl_id
      , bl_from
      , bl_ab_id
      , bl_to
      , bl_us_user_name
      , bl_uss_sl_type
      , bl_uss_logname
      , bl_cpu_id
      , bl_desc
      , inputer
      , input_date
      , updater
      , update_date
      , bl_repayment_fl
      , bl_from_used_fl
      , bl_to_used_fl
      , bl_bc_code
      , bl_status
      , row_number() over (partition by bl_id order by bl_status DESC) as rn
    from
    (
      select
          bl_id
        , bl_from
        , bl_ab_id
        , bl_to
        , bl_us_user_name
        , bl_uss_sl_type
        , bl_uss_logname
        , bl_cpu_id
        , bl_desc
        , inputer
        , input_date
        , updater
        , update_date
        , bl_repayment_fl
        , bl_from_used_fl
        , bl_to_used_fl
        , bl_bc_code
        , bl_status
      from edw_ods.t_000019_ct_blocking ct
      where
        ct.bl_status != 'F' 
        and NOW() between ct.eff_dttm and ct.exp_dttm
        and ct.bl_id not in (select bl_id from edw_ods.t_000019_tb_blocking_archive where now() between eff_dttm and exp_dttm)

      union all

      select
          bl_id
        , bl_from
        , bl_ab_id
        , bl_to
        , bl_us_user_name
        , bl_uss_sl_type
        , bl_uss_logname
        , bl_cpu_id
        , bl_desc
        , inputer
        , input_date
        , updater
        , update_date
        , bl_repayment_fl
        , bl_from_used_fl
        , bl_to_used_fl
        , bl_bc_code
        , bl_status
            
      from edw_ods.t_000019_tb_blocking_archive 
      where
        bl_status != 'F'
        and now() between eff_dttm and exp_dttm
    )tab
  )
, svc_db as
  (
    select distinct
        round(ab_id)                                          as ab_id -- "Код абонента"
      , ab.ab_external_code                                   as account
      , us.us_user_name -- "Подключение"
      , blk.bl_from                                           as start_block
      , coalesce(blk.bl_to, to_date('29991231', 'YYYYMMDD'))  as end_block
      , bl_bc_code -- тип блокировки
      , ssip.serv_first_id
        
    from all_blocking blk

    inner join edw_ods.t_000019_abonent ab
            on ab.ab_id = blk.BL_AB_ID 
           and now() between ab.eff_dttm and ab.exp_dttm 
                          
    inner join edw_ods.t_000019_ct_users us
            on ab.ab_id = us.US_AB_ID 
           and coalesce(blk.bl_us_user_name, us.us_user_name) = us.us_user_name
           and us.tech_dt between to_date('20190601', 'YYYYMMDD') and to_date('20190630', 'YYYYMMDD') + interval '1 day - 1 second'
           and us.US_REGDATE <= to_date('20190630', 'YYYYMMDD') + interval '1 day - 1 second'
           and coalesce(us.us_close_date,now()) >= to_date('20190601', 'YYYYMMDD')          
                          
    inner join edw_ods.t_000019_ibs_abs_accounts i
            on i.abs_external_code = ab.ab_external_code 
           and now() between i.eff_dttm and i.exp_dttm
                              
    inner join edw_ods.t_000019_ct_user_services uss
            on uss.uss_us_user_name = us.US_USER_NAME 
           and to_date('20190630', 'YYYYMMDD') + interval '1 day - 1 second' between uss.eff_dttm and uss.exp_dttm

    inner join edw_ods.t_000005_t_service_sip ssip
            on uss.uss_login = ssip.sip_id 
           and ssip.version_state = 'ACTIVE'
           and to_date('20190630', 'YYYYMMDD') + interval '1 day - 1 second' between ssip.eff_dttm and ssip.exp_dttm
           and to_date('20190630', 'YYYYMMDD') + interval '1 day - 1 second' between ssip.date_begin and ssip.date_end
    where
      blk.rn = 1
      and
        (
          blk.BL_FROM <= to_date('20190630', 'YYYYMMDD') + interval '1 day - 1 second'
          and
            (
              blk.BL_TO >= to_date('20190601', 'YYYYMMDD')
              or blk.BL_TO is null
            )
        )
  )
, subs_block as
  (
    select
        substr('20190630',1,6) as bid
      , u.account
      , svc.BL_BC_CODE
      , svc.start_block         as date_begin
      , svc.end_block           as date_end
      , s.dev_id ph
      , s.service_id
      , s.serv_first_id
      , u.user_id
      , s.src_id
      , s.business_service_key
      , s.business_service_name
      , s.sub_id
    from t_services s
    left join edw_ods.t_000005_t_users u
           on s.user_id = u.user_id
          and now() between u.eff_dttm and u.exp_dttm
          and u.deleted_ind = 0
    inner join svc_db svc
            on s.serv_first_id = svc.serv_first_id
           and svc.account = u.account
    where
      date_trunc('day',s.date_begin) <= to_date('20190630', 'YYYYMMDD') + interval '1 day - 1 second'
      and coalesce(s.date_end, to_date('20190630', 'YYYYMMDD')) >= to_date('20190601', 'YYYYMMDD')    
    order by u.account, s.dev_id
  )
, subs_block_period as
  (
    select distinct
        -1                                  as subs_key
      , subs_block.sub_id
      , subs_block.account                  as account_name
      , subs_block.business_service_key
      , bl_bc_code                          as block_type_id
      , 1                                   as block_status_id    -- блокировка установлена
      , subs_block.date_begin               as status_change_date
      , subs_block.src_id

    from subs_block

    inner join period
      on subs_block.date_begin between period.start_date and period.end_date

    union

    select distinct
          -1                                as subs_key
        , subs_block.sub_id
        , subs_block.account                as account_name
        , subs_block.business_service_key
        , bl_bc_code                        as block_type_id
        , 2                                 as block_status_id    -- блокировка снята
        , subs_block.date_end               as status_change_date
      , subs_block.src_id 

    from subs_block

    inner join period
      on subs_block.date_end between period.start_date and period.end_date
  )
, subs_block_type as
  (
    select
        sb.subs_key
      , sb.sub_id
      , sb.account_name
      , sb.business_service_key
      , coalesce(dbt.block_type_id, -1)   as block_type_id
      , coalesce(dbs.block_status_id, -1) as block_status_id
      , sb.status_change_date
      , row_number() over(partition by sb.sub_id, sb.business_service_key, coalesce(dbt.block_type_id, '-1'), sb.block_status_id, sb.status_change_date order by sb.block_type_id) as rn
      , sb.src_id

    from subs_block_period sb

    left join edw_dds.hub_dim_block_type dbt
           on sb.src_id::text = dbt.src_id::text
          and dbt.source_key::text = sb.block_type_id::text
                          
    left join edw_dds.hub_dim_block_status dbs
           on sb.src_id::text = dbs.src_id::text
          and dbs.source_key::text = sb.block_status_id::text
  )

select
    subs_key
  , sub_id
  , account_name
  , business_service_key
  , block_type_id
  , block_status_id
  , status_change_date
  , 000153    as src_id
  , src_id          as rf_src_id

from subs_block_type

where
  rn = 1;

--------------------------------------------------------------------------000006 - 000013
--ОТА
insert into edw_stg_dmcm.tfct_subs_block_1_prt_p000153
  (
      subs_key
    , SUB_ID
    , ACCOUNT_NAME
    , BUSINESS_SERVICE_KEY
    , block_type_id
    , block_status_id
    , status_change_date
    , src_id
    , rf_src_id
  )
with period as
  (
    select
        to_date('20190601',  'YYYYMMDD') as start_date
      , to_date('20190630',  'YYYYMMDD') + interval '1 day - 1 second' as end_date
  )
, xref as
  (
    select
        xref.source_key
      , bs.business_service_key
      , bs.business_service_name
      , xref.sub_make
        
    from edw_stg_dds.t_dim_service_xref_start xref
        
    inner join edw_dds.dim_service et
            on xref.service_key = et.service_key
            and et.active_ind    = 'Y'
            and xref.exp_dttm between et.eff_dttm and et.exp_dttm

    inner join edw_dds.dim_business_service bs
            on bs.business_service_key = et.business_service_key
            and et.exp_dttm between bs.eff_dttm and bs.exp_dttm
            and bs.active_ind = 'Y'
    where
      to_date(substr('20190630',1,6),'YYYYMM') + INTERVAL '1 MONTH - 1 second' between xref.eff_dttm and xref.exp_dttm
      and upper(xref.region_id) = 'VOLGA'
  )
, svc_db as
  (
    select 
        sv.serv_first_id
      , sv.date_begin
      , coalesce(sv.date_end, to_date('29991231', 'YYYYMMDD')) as date_end
      , sv.dev_id
      , sv.sv_reason_id

    from edw_ods.t_000006_T_SV_STATUS sv    

    where
      now() between sv.eff_dttm and sv.exp_dttm
      and sv.date_begin <= to_date('20190630',  'YYYYMMDD')  + interval '1 day - 1 second'
      and coalesce(sv.date_end, to_date('29991231', 'YYYYMMDD')) >= to_date('20190601',  'YYYYMMDD')
  )
, t_services as
  (
    select
      ts.*
    from
      (
        select
            xref.business_service_key
          , xref.business_service_name
          , ts.serv_first_id||'#'|| coalesce(ts.dev_id::text, '')||'#'||ts.svctype||'#'|| coalesce(ts.main_serv_first_id::text, '') as sub_id
          , case
              when ts.svctype = '0'
               and ts.src_id <> 102
              then coalesce(ts.dev_id::text, '') || '##'
              when ts.svctype <> '0'
              then ts.serv_first_id::text
            end as subs_id
          , ts.* 

        from edw_ods.t_000006_t_services ts

        left join xref
               on xref.source_key = ts.svc_id::text

        where
          now() between ts.eff_dttm and ts.exp_dttm 
          and ts.deleted_ind = 0
          AND ts.svctype = '0' 
      )ts

    inner join
      (
        select
          subs_id
        from
          (
            select
                row_number() over (partition by subs_id order by p1_period DESC) as rn
              , subs_id
              , p1_period 
            from
              (
                  select distinct
                      oo_eff_tp.subs_id
                    , oo_eff_tp.p1_period 
                  from edw_ods.t_000153_efftp_oo_eff_tp oo_eff_tp
                  where
                    oo_eff_tp.tech_dt between date_trunc('month',to_date('20190630', 'YYYYMMDD'))::date - interval '1 month' and date_trunc('month',to_date('20190630', 'YYYYMMDD'))::date
                    and oo_eff_tp.serv_id = '1' -- ОТА
              ) oo_eff_tp
        ) oo_eff_tp
        where
          rn = 1
      ) oo_eff_tp
      on oo_eff_tp.subs_id = ts.subs_id

  )
, subs_block as
  (
    select
        substr('20190630',1,6) as bid
      , u.account
      , coalesce(svc.sv_reason_id, '-2') as block_type
      , svc.date_begin
      , coalesce(svc.date_end, to_date('29991231', 'YYYYMMDD') ) as date_end
      , s.dev_id ph
      , s.service_id
      , s.serv_first_id
      , u.user_id
      , s.business_service_key
      , s.business_service_name
      , s.sub_id
      , s.src_id

    from t_services s

    join svc_db svc
      on s.serv_first_id = svc.serv_first_id

    left join edw_ods.t_000006_t_users u
           on s.user_id = u.user_id
          and now() between u.eff_dttm and u.exp_dttm and u.deleted_ind = 0

    where
      to_date('20190630',  'YYYYMMDD') between date_trunc('day',s.date_begin) and coalesce(s.date_end, to_date('20190630',  'YYYYMMDD'))
        
    order by u.account, s.dev_id
  )

select distinct
    -1                                as subs_key
  , subs_block.sub_id
  , subs_block.account                as account_name
  , subs_block.business_service_key
  , coalesce(dbt.block_type_id, -1)   as block_type_id
  , coalesce(dbs.block_status_id, -1) as block_status_id -- блокировка установлена
  , subs_block.date_begin             as status_change_date
  , 000153                      as src_id
  , subs_block.src_id                 as rf_src_id

from subs_block

inner join period
        on subs_block.date_begin between period.start_date and period.end_date
                        
left join edw_dds.hub_dim_block_type dbt
       on subs_block.src_id::text = dbt.src_id::text
      and dbt.source_key::text = subs_block.block_type::text

left join edw_dds.hub_dim_block_status dbs
       on subs_block.src_id::text = dbs.src_id::text
      and dbs.source_key::text = '1'

union

select distinct
    -1                                as subs_key
  , subs_block.sub_id
  , subs_block.account                as account_name
  , subs_block.business_service_key
  , coalesce(dbt.block_type_id, -1)   as block_type_id
  , coalesce(dbs.block_status_id, -1) as block_status_id -- блокировка снята
  , subs_block.date_end               as status_change_date
  , 000153                      as src_id
  , subs_block.src_id                 as rf_src_id
        
from subs_block

inner join period
        on subs_block.date_end between period.start_date and period.end_date

left join edw_dds.hub_dim_block_type dbt
       on subs_block.src_id::text = dbt.src_id::text
      and dbt.source_key::text = subs_block.block_type::text

left join edw_dds.hub_dim_block_status dbs
       on subs_block.src_id::text = dbs.src_id::text
      and dbs.source_key::text = '2'
;

-- ШПД, IPTV
insert into edw_stg_dmcm.tfct_subs_block_1_prt_p000153
  (
      subs_key
    , sub_id
    , account_name
    , business_service_key
    , block_type_id
    , block_status_id
    , status_change_date
    , src_id
    , rf_src_id
  )

with period as
  (
    select
        to_date('20190601', 'YYYYMMDD') as start_date
      , to_date('20190630', 'YYYYMMDD') + interval '1 day - 1 second' as end_date
  )
, xref as
  (
    select
        xref.source_key
      , bs.business_service_key
      , bs.business_service_name
      , xref.sub_make
        
    from edw_stg_dds.t_dim_service_xref_start xref
        
    inner join edw_dds.dim_service et
            on xref.service_key = et.service_key
           and et.active_ind    = 'Y'
           and xref.exp_dttm between et.eff_dttm and et.exp_dttm

    inner join edw_dds.dim_business_service bs
            on bs.business_service_key = et.business_service_key
           and et.exp_dttm between bs.eff_dttm and bs.exp_dttm
           and bs.active_ind = 'Y'
    where
      to_date(substr('20190630',1,6),'YYYYMM') + interval '1 MONTH - 1 second' between xref.eff_dttm and xref.exp_dttm
      and upper(xref.region_id) = 'VOLGA'
  )
, t_services as
  (
    select
      ts.*
    from
      (
        select
            xref.business_service_key
          , xref.business_service_name
          , ts.serv_first_id||'#'|| coalesce(ts.dev_id::text, '')||'#'||ts.svctype||'#'|| coalesce(ts.main_serv_first_id::text, '') as sub_id
          , case
              when ts.svctype = '0'
               and ts.src_id <> 102
              then coalesce(ts.dev_id::text, '') || '##'
              when ts.svctype <> '0'
              then ts.serv_first_id::text
            end as subs_id
          , ts.* 

        from edw_ods.t_000006_t_services ts

        left join xref
               on xref.source_key = ts.svc_id::text

        where
          now() between ts.eff_dttm and ts.exp_dttm 
          and ts.deleted_ind = 0
          and ts.svctype != '0' 
      ) ts

    inner join
      (
        select
          subs_id
        from
          (
            select
                row_number() over (partition by subs_id order by p1_period DESC) as rn
              , subs_id
              , p1_period 
            from
              (
                select distinct
                    oo_eff_tp.subs_id
                  , oo_eff_tp.p1_period

                from edw_ods.t_000153_efftp_oo_eff_tp oo_eff_tp

                where
                  oo_eff_tp.tech_dt between date_trunc('month',to_date('20190630', 'YYYYMMDD'))::date - interval '1 month' and date_trunc('month',to_date('20190630', 'YYYYMMDD'))::date
                  and oo_eff_tp.serv_id in ('2', '3') -- ШПД, IPTV
              ) oo_eff_tp
          ) oo_eff_tp
        where
          rn = 1
      ) oo_eff_tp
      on oo_eff_tp.subs_id = ts.subs_id
  )
, all_blocking as
  (
    select
        bl_id
      , bl_from
      , bl_ab_id
      , bl_to
      , bl_us_user_name
      , bl_uss_sl_type
      , bl_uss_logname
      , bl_cpu_id
      , bl_desc
      , inputer
      , input_date
      , updater
      , update_date
      , bl_repayment_fl
      , bl_from_used_fl
      , bl_to_used_fl
      , bl_bc_code
      , bl_status
      , row_number() over (partition by bl_id order by bl_status DESC) as rn
    from
    (
      select
          bl_id
        , bl_from
        , bl_ab_id
        , bl_to
        , bl_us_user_name
        , bl_uss_sl_type
        , bl_uss_logname
        , bl_cpu_id
        , bl_desc
        , inputer
        , input_date
        , updater
        , update_date
        , bl_repayment_fl
        , bl_from_used_fl
        , bl_to_used_fl
        , bl_bc_code
        , bl_status
      from edw_ods.t_000013_ct_blocking ct
      where
        ct.bl_status != 'F' 
        and NOW() between ct.eff_dttm and ct.exp_dttm
        and ct.bl_id not in (select bl_id from edw_ods.t_000013_tb_blocking_archive where now() between eff_dttm and exp_dttm)

      union all

      select
          bl_id
        , bl_from
        , bl_ab_id
        , bl_to
        , bl_us_user_name
        , bl_uss_sl_type
        , bl_uss_logname
        , bl_cpu_id
        , bl_desc
        , inputer
        , input_date
        , updater
        , update_date
        , bl_repayment_fl
        , bl_from_used_fl
        , bl_to_used_fl
        , bl_bc_code
        , bl_status
            
      from edw_ods.t_000013_tb_blocking_archive 
      where
        bl_status != 'F'
        and now() between eff_dttm and exp_dttm
    )tab
  )
, svc_db as
  (
    select distinct
        round(ab_id)                                          as ab_id -- "Код абонента"
      , ab.ab_external_code                                   as account
      , us.us_user_name -- "Подключение"
      , blk.bl_from                                           as start_block
      , coalesce(blk.bl_to, to_date('29991231', 'YYYYMMDD'))  as end_block
      , bl_bc_code -- тип блокировки
      , ssip.serv_first_id
        
    from all_blocking blk

    inner join edw_ods.t_000013_abonent ab
            on ab.ab_id = blk.BL_AB_ID 
           and now() between ab.eff_dttm and ab.exp_dttm 
                          
    inner join edw_ods.t_000013_ct_users us
            on ab.ab_id = us.US_AB_ID 
           and coalesce(blk.bl_us_user_name, us.us_user_name) = us.us_user_name
           and us.tech_dt between to_date('20190601', 'YYYYMMDD') and to_date('20190630', 'YYYYMMDD') + interval '1 day - 1 second'
           and us.US_REGDATE <= to_date('20190630', 'YYYYMMDD') + interval '1 day - 1 second'
           and coalesce(us.us_close_date,now()) >= to_date('20190601', 'YYYYMMDD')          
                          
    inner join edw_ods.t_000013_ibs_abs_accounts i
            on i.abs_external_code = ab.ab_external_code 
           and now() between i.eff_dttm and i.exp_dttm
                              
    inner join edw_ods.t_000013_ct_user_services uss
            on uss.uss_us_user_name = us.US_USER_NAME 
           and to_date('20190630', 'YYYYMMDD') + interval '1 day - 1 second' between uss.eff_dttm and uss.exp_dttm

    inner join edw_ods.t_000006_t_service_sip ssip
            on uss.uss_login = ssip.sip_id 
           and ssip.version_state = 'ACTIVE'
           and to_date('20190630', 'YYYYMMDD') + interval '1 day - 1 second' between ssip.eff_dttm and ssip.exp_dttm
           and to_date('20190630', 'YYYYMMDD') + interval '1 day - 1 second' between ssip.date_begin and ssip.date_end
    where
      blk.rn = 1
      and
        (
          blk.BL_FROM <= to_date('20190630', 'YYYYMMDD') + interval '1 day - 1 second'
          and
            (
              blk.BL_TO >= to_date('20190601', 'YYYYMMDD')
              or blk.BL_TO is null
            )
        )
  )
, subs_block as
  (
    select
        substr('20190630',1,6) as bid
      , u.account
      , svc.BL_BC_CODE
      , svc.start_block         as date_begin
      , svc.end_block           as date_end
      , s.dev_id ph
      , s.service_id
      , s.serv_first_id
      , u.user_id
      , s.src_id
      , s.business_service_key
      , s.business_service_name
      , s.sub_id
    from t_services s
    left join edw_ods.t_000006_t_users u
           on s.user_id = u.user_id
          and now() between u.eff_dttm and u.exp_dttm
          and u.deleted_ind = 0
    inner join svc_db svc
            on s.serv_first_id = svc.serv_first_id
           and svc.account = u.account
    where
      date_trunc('day',s.date_begin) <= to_date('20190630', 'YYYYMMDD') + interval '1 day - 1 second'
      and coalesce(s.date_end, to_date('20190630', 'YYYYMMDD')) >= to_date('20190601', 'YYYYMMDD')    
    order by u.account, s.dev_id
  )
, subs_block_period as
  (
    select distinct
        -1                                  as subs_key
      , subs_block.sub_id
      , subs_block.account                  as account_name
      , subs_block.business_service_key
      , bl_bc_code                          as block_type_id
      , 1                                   as block_status_id    -- блокировка установлена
      , subs_block.date_begin               as status_change_date
      , subs_block.src_id

    from subs_block

    inner join period
      on subs_block.date_begin between period.start_date and period.end_date

    union

    select distinct
          -1                                as subs_key
        , subs_block.sub_id
        , subs_block.account                as account_name
        , subs_block.business_service_key
        , bl_bc_code                        as block_type_id
        , 2                                 as block_status_id    -- блокировка снята
        , subs_block.date_end               as status_change_date
      , subs_block.src_id 

    from subs_block

    inner join period
      on subs_block.date_end between period.start_date and period.end_date
  )
, subs_block_type as
  (
    select
        sb.subs_key
      , sb.sub_id
      , sb.account_name
      , sb.business_service_key
      , coalesce(dbt.block_type_id, -1)   as block_type_id
      , coalesce(dbs.block_status_id, -1) as block_status_id
      , sb.status_change_date
      , row_number() over(partition by sb.sub_id, sb.business_service_key, coalesce(dbt.block_type_id, '-1'), sb.block_status_id, sb.status_change_date order by sb.block_type_id) as rn
      , sb.src_id

    from subs_block_period sb

    left join edw_dds.hub_dim_block_type dbt
           on sb.src_id::text = dbt.src_id::text
          and dbt.source_key::text = sb.block_type_id::text
                          
    left join edw_dds.hub_dim_block_status dbs
           on sb.src_id::text = dbs.src_id::text
          and dbs.source_key::text = sb.block_status_id::text
  )

select
    subs_key
  , sub_id
  , account_name
  , business_service_key
  , block_type_id
  , block_status_id
  , status_change_date
  , 000153    as src_id
  , src_id          as rf_src_id

from subs_block_type

where
  rn = 1;

--------------------------------------------------------------------------000007 - 000020
--ОТА
insert into edw_stg_dmcm.tfct_subs_block_1_prt_p000153
  (
      subs_key
    , SUB_ID
    , ACCOUNT_NAME
    , BUSINESS_SERVICE_KEY
    , block_type_id
    , block_status_id
    , status_change_date
    , src_id
    , rf_src_id
  )
with period as
  (
    select
        to_date('20190601',  'YYYYMMDD') as start_date
      , to_date('20190630',  'YYYYMMDD') + interval '1 day - 1 second' as end_date
  )
, xref as
  (
    select
        xref.source_key
      , bs.business_service_key
      , bs.business_service_name
      , xref.sub_make
        
    from edw_stg_dds.t_dim_service_xref_start xref
        
    inner join edw_dds.dim_service et
            on xref.service_key = et.service_key
            and et.active_ind    = 'Y'
            and xref.exp_dttm between et.eff_dttm and et.exp_dttm

    inner join edw_dds.dim_business_service bs
            on bs.business_service_key = et.business_service_key
            and et.exp_dttm between bs.eff_dttm and bs.exp_dttm
            and bs.active_ind = 'Y'
    where
      to_date(substr('20190630',1,6),'YYYYMM') + INTERVAL '1 MONTH - 1 second' between xref.eff_dttm and xref.exp_dttm
      and upper(xref.region_id) = 'VOLGA'
  )
, svc_db as
  (
    select 
        sv.serv_first_id
      , sv.date_begin
      , coalesce(sv.date_end, to_date('29991231', 'YYYYMMDD')) as date_end
      , sv.dev_id
      , sv.sv_reason_id

    from edw_ods.t_000007_T_SV_STATUS sv    

    where
      now() between sv.eff_dttm and sv.exp_dttm
      and sv.date_begin <= to_date('20190630',  'YYYYMMDD')  + interval '1 day - 1 second'
      and coalesce(sv.date_end, to_date('29991231', 'YYYYMMDD')) >= to_date('20190601',  'YYYYMMDD')
  )
, t_services as
  (
    select
      ts.*
    from
      (
        select
            xref.business_service_key
          , xref.business_service_name
          , ts.serv_first_id||'#'|| coalesce(ts.dev_id::text, '')||'#'||ts.svctype||'#'|| coalesce(ts.main_serv_first_id::text, '') as sub_id
          , case
              when ts.svctype = '0'
               and ts.src_id <> 102
              then coalesce(ts.dev_id::text, '') || '##'
              when ts.svctype <> '0'
              then ts.serv_first_id::text
            end as subs_id
          , ts.* 

        from edw_ods.t_000007_t_services ts

        left join xref
               on xref.source_key = ts.svc_id::text

        where
          now() between ts.eff_dttm and ts.exp_dttm 
          and ts.deleted_ind = 0
          AND ts.svctype = '0' 
      )ts

    inner join
      (
        select
          subs_id
        from
          (
            select
                row_number() over (partition by subs_id order by p1_period DESC) as rn
              , subs_id
              , p1_period 
            from
              (
                  select distinct
                      oo_eff_tp.subs_id
                    , oo_eff_tp.p1_period 
                  from edw_ods.t_000153_efftp_oo_eff_tp oo_eff_tp
                  where
                    oo_eff_tp.tech_dt between date_trunc('month',to_date('20190630', 'YYYYMMDD'))::date - interval '1 month' and date_trunc('month',to_date('20190630', 'YYYYMMDD'))::date
                    and oo_eff_tp.serv_id = '1' -- ОТА
              ) oo_eff_tp
        ) oo_eff_tp
        where
          rn = 1
      ) oo_eff_tp
      on oo_eff_tp.subs_id = ts.subs_id

  )
, subs_block as
  (
    select
        substr('20190630',1,6) as bid
      , u.account
      , coalesce(svc.sv_reason_id, '-2') as block_type
      , svc.date_begin
      , coalesce(svc.date_end, to_date('29991231', 'YYYYMMDD') ) as date_end
      , s.dev_id ph
      , s.service_id
      , s.serv_first_id
      , u.user_id
      , s.business_service_key
      , s.business_service_name
      , s.sub_id
      , s.src_id

    from t_services s

    join svc_db svc
      on s.serv_first_id = svc.serv_first_id

    left join edw_ods.t_000007_t_users u
           on s.user_id = u.user_id
          and now() between u.eff_dttm and u.exp_dttm and u.deleted_ind = 0

    where
      to_date('20190630',  'YYYYMMDD') between date_trunc('day',s.date_begin) and coalesce(s.date_end, to_date('20190630',  'YYYYMMDD'))
        
    order by u.account, s.dev_id
  )

select distinct
    -1                                as subs_key
  , subs_block.sub_id
  , subs_block.account                as account_name
  , subs_block.business_service_key
  , coalesce(dbt.block_type_id, -1)   as block_type_id
  , coalesce(dbs.block_status_id, -1) as block_status_id -- блокировка установлена
  , subs_block.date_begin             as status_change_date
  , 000153                      as src_id
  , subs_block.src_id                 as rf_src_id

from subs_block

inner join period
        on subs_block.date_begin between period.start_date and period.end_date
                        
left join edw_dds.hub_dim_block_type dbt
       on subs_block.src_id::text = dbt.src_id::text
      and dbt.source_key::text = subs_block.block_type::text

left join edw_dds.hub_dim_block_status dbs
       on subs_block.src_id::text = dbs.src_id::text
      and dbs.source_key::text = '1'

union

select distinct
    -1                                as subs_key
  , subs_block.sub_id
  , subs_block.account                as account_name
  , subs_block.business_service_key
  , coalesce(dbt.block_type_id, -1)   as block_type_id
  , coalesce(dbs.block_status_id, -1) as block_status_id -- блокировка снята
  , subs_block.date_end               as status_change_date
  , 000153                      as src_id
  , subs_block.src_id                 as rf_src_id
        
from subs_block

inner join period
        on subs_block.date_end between period.start_date and period.end_date

left join edw_dds.hub_dim_block_type dbt
       on subs_block.src_id::text = dbt.src_id::text
      and dbt.source_key::text = subs_block.block_type::text

left join edw_dds.hub_dim_block_status dbs
       on subs_block.src_id::text = dbs.src_id::text
      and dbs.source_key::text = '2'
;

-- ШПД, IPTV
insert into edw_stg_dmcm.tfct_subs_block_1_prt_p000153
  (
      subs_key
    , sub_id
    , account_name
    , business_service_key
    , block_type_id
    , block_status_id
    , status_change_date
    , src_id
    , rf_src_id
  )

with period as
  (
    select
        to_date('20190601', 'YYYYMMDD') as start_date
      , to_date('20190630', 'YYYYMMDD') + interval '1 day - 1 second' as end_date
  )
, xref as
  (
    select
        xref.source_key
      , bs.business_service_key
      , bs.business_service_name
      , xref.sub_make
        
    from edw_stg_dds.t_dim_service_xref_start xref
        
    inner join edw_dds.dim_service et
            on xref.service_key = et.service_key
           and et.active_ind    = 'Y'
           and xref.exp_dttm between et.eff_dttm and et.exp_dttm

    inner join edw_dds.dim_business_service bs
            on bs.business_service_key = et.business_service_key
           and et.exp_dttm between bs.eff_dttm and bs.exp_dttm
           and bs.active_ind = 'Y'
    where
      to_date(substr('20190630',1,6),'YYYYMM') + interval '1 MONTH - 1 second' between xref.eff_dttm and xref.exp_dttm
      and upper(xref.region_id) = 'VOLGA'
  )
, t_services as
  (
    select
      ts.*
    from
      (
        select
            xref.business_service_key
          , xref.business_service_name
          , ts.serv_first_id||'#'|| coalesce(ts.dev_id::text, '')||'#'||ts.svctype||'#'|| coalesce(ts.main_serv_first_id::text, '') as sub_id
          , case
              when ts.svctype = '0'
               and ts.src_id <> 102
              then coalesce(ts.dev_id::text, '') || '##'
              when ts.svctype <> '0'
              then ts.serv_first_id::text
            end as subs_id
          , ts.* 

        from edw_ods.t_000007_t_services ts

        left join xref
               on xref.source_key = ts.svc_id::text

        where
          now() between ts.eff_dttm and ts.exp_dttm 
          and ts.deleted_ind = 0
          and ts.svctype != '0' 
      ) ts

    inner join
      (
        select
          subs_id
        from
          (
            select
                row_number() over (partition by subs_id order by p1_period DESC) as rn
              , subs_id
              , p1_period 
            from
              (
                select distinct
                    oo_eff_tp.subs_id
                  , oo_eff_tp.p1_period

                from edw_ods.t_000153_efftp_oo_eff_tp oo_eff_tp

                where
                  oo_eff_tp.tech_dt between date_trunc('month',to_date('20190630', 'YYYYMMDD'))::date - interval '1 month' and date_trunc('month',to_date('20190630', 'YYYYMMDD'))::date
                  and oo_eff_tp.serv_id in ('2', '3') -- ШПД, IPTV
              ) oo_eff_tp
          ) oo_eff_tp
        where
          rn = 1
      ) oo_eff_tp
      on oo_eff_tp.subs_id = ts.subs_id
  )
, all_blocking as
  (
    select
        bl_id
      , bl_from
      , bl_ab_id
      , bl_to
      , bl_us_user_name
      , bl_uss_sl_type
      , bl_uss_logname
      , bl_cpu_id
      , bl_desc
      , inputer
      , input_date
      , updater
      , update_date
      , bl_repayment_fl
      , bl_from_used_fl
      , bl_to_used_fl
      , bl_bc_code
      , bl_status
      , row_number() over (partition by bl_id order by bl_status DESC) as rn
    from
    (
      select
          bl_id
        , bl_from
        , bl_ab_id
        , bl_to
        , bl_us_user_name
        , bl_uss_sl_type
        , bl_uss_logname
        , bl_cpu_id
        , bl_desc
        , inputer
        , input_date
        , updater
        , update_date
        , bl_repayment_fl
        , bl_from_used_fl
        , bl_to_used_fl
        , bl_bc_code
        , bl_status
      from edw_ods.t_000020_ct_blocking ct
      where
        ct.bl_status != 'F' 
        and NOW() between ct.eff_dttm and ct.exp_dttm
        and ct.bl_id not in (select bl_id from edw_ods.t_000020_tb_blocking_archive where now() between eff_dttm and exp_dttm)

      union all

      select
          bl_id
        , bl_from
        , bl_ab_id
        , bl_to
        , bl_us_user_name
        , bl_uss_sl_type
        , bl_uss_logname
        , bl_cpu_id
        , bl_desc
        , inputer
        , input_date
        , updater
        , update_date
        , bl_repayment_fl
        , bl_from_used_fl
        , bl_to_used_fl
        , bl_bc_code
        , bl_status
            
      from edw_ods.t_000020_tb_blocking_archive 
      where
        bl_status != 'F'
        and now() between eff_dttm and exp_dttm
    )tab
  )
, svc_db as
  (
    select distinct
        round(ab_id)                                          as ab_id -- "Код абонента"
      , ab.ab_external_code                                   as account
      , us.us_user_name -- "Подключение"
      , blk.bl_from                                           as start_block
      , coalesce(blk.bl_to, to_date('29991231', 'YYYYMMDD'))  as end_block
      , bl_bc_code -- тип блокировки
      , ssip.serv_first_id
        
    from all_blocking blk

    inner join edw_ods.t_000020_abonent ab
            on ab.ab_id = blk.BL_AB_ID 
           and now() between ab.eff_dttm and ab.exp_dttm 
                          
    inner join edw_ods.t_000020_ct_users us
            on ab.ab_id = us.US_AB_ID 
           and coalesce(blk.bl_us_user_name, us.us_user_name) = us.us_user_name
           and us.tech_dt between to_date('20190601', 'YYYYMMDD') and to_date('20190630', 'YYYYMMDD') + interval '1 day - 1 second'
           and us.US_REGDATE <= to_date('20190630', 'YYYYMMDD') + interval '1 day - 1 second'
           and coalesce(us.us_close_date,now()) >= to_date('20190601', 'YYYYMMDD')          
                          
    inner join edw_ods.t_000020_ibs_abs_accounts i
            on i.abs_external_code = ab.ab_external_code 
           and now() between i.eff_dttm and i.exp_dttm
                              
    inner join edw_ods.t_000020_ct_user_services uss
            on uss.uss_us_user_name = us.US_USER_NAME 
           and to_date('20190630', 'YYYYMMDD') + interval '1 day - 1 second' between uss.eff_dttm and uss.exp_dttm

    inner join edw_ods.t_000007_t_service_sip ssip
            on uss.uss_login = ssip.sip_id 
           and ssip.version_state = 'ACTIVE'
           and to_date('20190630', 'YYYYMMDD') + interval '1 day - 1 second' between ssip.eff_dttm and ssip.exp_dttm
           and to_date('20190630', 'YYYYMMDD') + interval '1 day - 1 second' between ssip.date_begin and ssip.date_end
    where
      blk.rn = 1
      and
        (
          blk.BL_FROM <= to_date('20190630', 'YYYYMMDD') + interval '1 day - 1 second'
          and
            (
              blk.BL_TO >= to_date('20190601', 'YYYYMMDD')
              or blk.BL_TO is null
            )
        )
  )
, subs_block as
  (
    select
        substr('20190630',1,6) as bid
      , u.account
      , svc.BL_BC_CODE
      , svc.start_block         as date_begin
      , svc.end_block           as date_end
      , s.dev_id ph
      , s.service_id
      , s.serv_first_id
      , u.user_id
      , s.src_id
      , s.business_service_key
      , s.business_service_name
      , s.sub_id
    from t_services s
    left join edw_ods.t_000007_t_users u
           on s.user_id = u.user_id
          and now() between u.eff_dttm and u.exp_dttm
          and u.deleted_ind = 0
    inner join svc_db svc
            on s.serv_first_id = svc.serv_first_id
           and svc.account = u.account
    where
      date_trunc('day',s.date_begin) <= to_date('20190630', 'YYYYMMDD') + interval '1 day - 1 second'
      and coalesce(s.date_end, to_date('20190630', 'YYYYMMDD')) >= to_date('20190601', 'YYYYMMDD')    
    order by u.account, s.dev_id
  )
, subs_block_period as
  (
    select distinct
        -1                                  as subs_key
      , subs_block.sub_id
      , subs_block.account                  as account_name
      , subs_block.business_service_key
      , bl_bc_code                          as block_type_id
      , 1                                   as block_status_id    -- блокировка установлена
      , subs_block.date_begin               as status_change_date
      , subs_block.src_id

    from subs_block

    inner join period
      on subs_block.date_begin between period.start_date and period.end_date

    union

    select distinct
          -1                                as subs_key
        , subs_block.sub_id
        , subs_block.account                as account_name
        , subs_block.business_service_key
        , bl_bc_code                        as block_type_id
        , 2                                 as block_status_id    -- блокировка снята
        , subs_block.date_end               as status_change_date
      , subs_block.src_id 

    from subs_block

    inner join period
      on subs_block.date_end between period.start_date and period.end_date
  )
, subs_block_type as
  (
    select
        sb.subs_key
      , sb.sub_id
      , sb.account_name
      , sb.business_service_key
      , coalesce(dbt.block_type_id, -1)   as block_type_id
      , coalesce(dbs.block_status_id, -1) as block_status_id
      , sb.status_change_date
      , row_number() over(partition by sb.sub_id, sb.business_service_key, coalesce(dbt.block_type_id, '-1'), sb.block_status_id, sb.status_change_date order by sb.block_type_id) as rn
      , sb.src_id

    from subs_block_period sb

    left join edw_dds.hub_dim_block_type dbt
           on sb.src_id::text = dbt.src_id::text
          and dbt.source_key::text = sb.block_type_id::text
                          
    left join edw_dds.hub_dim_block_status dbs
           on sb.src_id::text = dbs.src_id::text
          and dbs.source_key::text = sb.block_status_id::text
  )

select
    subs_key
  , sub_id
  , account_name
  , business_service_key
  , block_type_id
  , block_status_id
  , status_change_date
  , 000153    as src_id
  , src_id          as rf_src_id

from subs_block_type

where
  rn = 1;

--------------------------------------------------------------------------000008 - 000021
--ОТА
insert into edw_stg_dmcm.tfct_subs_block_1_prt_p000153
  (
      subs_key
    , SUB_ID
    , ACCOUNT_NAME
    , BUSINESS_SERVICE_KEY
    , block_type_id
    , block_status_id
    , status_change_date
    , src_id
    , rf_src_id
  )
with period as
  (
    select
        to_date('20190601',  'YYYYMMDD') as start_date
      , to_date('20190630',  'YYYYMMDD') + interval '1 day - 1 second' as end_date
  )
, xref as
  (
    select
        xref.source_key
      , bs.business_service_key
      , bs.business_service_name
      , xref.sub_make
        
    from edw_stg_dds.t_dim_service_xref_start xref
        
    inner join edw_dds.dim_service et
            on xref.service_key = et.service_key
            and et.active_ind    = 'Y'
            and xref.exp_dttm between et.eff_dttm and et.exp_dttm

    inner join edw_dds.dim_business_service bs
            on bs.business_service_key = et.business_service_key
            and et.exp_dttm between bs.eff_dttm and bs.exp_dttm
            and bs.active_ind = 'Y'
    where
      to_date(substr('20190630',1,6),'YYYYMM') + INTERVAL '1 MONTH - 1 second' between xref.eff_dttm and xref.exp_dttm
      and upper(xref.region_id) = 'VOLGA'
  )
, svc_db as
  (
    select 
        sv.serv_first_id
      , sv.date_begin
      , coalesce(sv.date_end, to_date('29991231', 'YYYYMMDD')) as date_end
      , sv.dev_id
      , sv.sv_reason_id

    from edw_ods.t_000008_T_SV_STATUS sv    

    where
      now() between sv.eff_dttm and sv.exp_dttm
      and sv.date_begin <= to_date('20190630',  'YYYYMMDD')  + interval '1 day - 1 second'
      and coalesce(sv.date_end, to_date('29991231', 'YYYYMMDD')) >= to_date('20190601',  'YYYYMMDD')
  )
, t_services as
  (
    select
      ts.*
    from
      (
        select
            xref.business_service_key
          , xref.business_service_name
          , ts.serv_first_id||'#'|| coalesce(ts.dev_id::text, '')||'#'||ts.svctype||'#'|| coalesce(ts.main_serv_first_id::text, '') as sub_id
          , case
              when ts.svctype = '0'
               and ts.src_id <> 102
              then coalesce(ts.dev_id::text, '') || '##'
              when ts.svctype <> '0'
              then ts.serv_first_id::text
            end as subs_id
          , ts.* 

        from edw_ods.t_000008_t_services ts

        left join xref
               on xref.source_key = ts.svc_id::text

        where
          now() between ts.eff_dttm and ts.exp_dttm 
          and ts.deleted_ind = 0
          AND ts.svctype = '0' 
      )ts

    inner join
      (
        select
          subs_id
        from
          (
            select
                row_number() over (partition by subs_id order by p1_period DESC) as rn
              , subs_id
              , p1_period 
            from
              (
                  select distinct
                      oo_eff_tp.subs_id
                    , oo_eff_tp.p1_period 
                  from edw_ods.t_000153_efftp_oo_eff_tp oo_eff_tp
                  where
                    oo_eff_tp.tech_dt between date_trunc('month',to_date('20190630', 'YYYYMMDD'))::date - interval '1 month' and date_trunc('month',to_date('20190630', 'YYYYMMDD'))::date
                    and oo_eff_tp.serv_id = '1' -- ОТА
              ) oo_eff_tp
        ) oo_eff_tp
        where
          rn = 1
      ) oo_eff_tp
      on oo_eff_tp.subs_id = ts.subs_id

  )
, subs_block as
  (
    select
        substr('20190630',1,6) as bid
      , u.account
      , coalesce(svc.sv_reason_id, '-2') as block_type
      , svc.date_begin
      , coalesce(svc.date_end, to_date('29991231', 'YYYYMMDD') ) as date_end
      , s.dev_id ph
      , s.service_id
      , s.serv_first_id
      , u.user_id
      , s.business_service_key
      , s.business_service_name
      , s.sub_id
      , s.src_id

    from t_services s

    join svc_db svc
      on s.serv_first_id = svc.serv_first_id

    left join edw_ods.t_000008_t_users u
           on s.user_id = u.user_id
          and now() between u.eff_dttm and u.exp_dttm and u.deleted_ind = 0

    where
      to_date('20190630',  'YYYYMMDD') between date_trunc('day',s.date_begin) and coalesce(s.date_end, to_date('20190630',  'YYYYMMDD'))
        
    order by u.account, s.dev_id
  )

select distinct
    -1                                as subs_key
  , subs_block.sub_id
  , subs_block.account                as account_name
  , subs_block.business_service_key
  , coalesce(dbt.block_type_id, -1)   as block_type_id
  , coalesce(dbs.block_status_id, -1) as block_status_id -- блокировка установлена
  , subs_block.date_begin             as status_change_date
  , 000153                      as src_id
  , subs_block.src_id                 as rf_src_id

from subs_block

inner join period
        on subs_block.date_begin between period.start_date and period.end_date
                        
left join edw_dds.hub_dim_block_type dbt
       on subs_block.src_id::text = dbt.src_id::text
      and dbt.source_key::text = subs_block.block_type::text

left join edw_dds.hub_dim_block_status dbs
       on subs_block.src_id::text = dbs.src_id::text
      and dbs.source_key::text = '1'

union

select distinct
    -1                                as subs_key
  , subs_block.sub_id
  , subs_block.account                as account_name
  , subs_block.business_service_key
  , coalesce(dbt.block_type_id, -1)   as block_type_id
  , coalesce(dbs.block_status_id, -1) as block_status_id -- блокировка снята
  , subs_block.date_end               as status_change_date
  , 000153                      as src_id
  , subs_block.src_id                 as rf_src_id
        
from subs_block

inner join period
        on subs_block.date_end between period.start_date and period.end_date

left join edw_dds.hub_dim_block_type dbt
       on subs_block.src_id::text = dbt.src_id::text
      and dbt.source_key::text = subs_block.block_type::text

left join edw_dds.hub_dim_block_status dbs
       on subs_block.src_id::text = dbs.src_id::text
      and dbs.source_key::text = '2'
;

-- ШПД, IPTV
insert into edw_stg_dmcm.tfct_subs_block_1_prt_p000153
  (
      subs_key
    , sub_id
    , account_name
    , business_service_key
    , block_type_id
    , block_status_id
    , status_change_date
    , src_id
    , rf_src_id
  )

with period as
  (
    select
        to_date('20190601', 'YYYYMMDD') as start_date
      , to_date('20190630', 'YYYYMMDD') + interval '1 day - 1 second' as end_date
  )
, xref as
  (
    select
        xref.source_key
      , bs.business_service_key
      , bs.business_service_name
      , xref.sub_make
        
    from edw_stg_dds.t_dim_service_xref_start xref
        
    inner join edw_dds.dim_service et
            on xref.service_key = et.service_key
           and et.active_ind    = 'Y'
           and xref.exp_dttm between et.eff_dttm and et.exp_dttm

    inner join edw_dds.dim_business_service bs
            on bs.business_service_key = et.business_service_key
           and et.exp_dttm between bs.eff_dttm and bs.exp_dttm
           and bs.active_ind = 'Y'
    where
      to_date(substr('20190630',1,6),'YYYYMM') + interval '1 MONTH - 1 second' between xref.eff_dttm and xref.exp_dttm
      and upper(xref.region_id) = 'VOLGA'
  )
, t_services as
  (
    select
      ts.*
    from
      (
        select
            xref.business_service_key
          , xref.business_service_name
          , ts.serv_first_id||'#'|| coalesce(ts.dev_id::text, '')||'#'||ts.svctype||'#'|| coalesce(ts.main_serv_first_id::text, '') as sub_id
          , case
              when ts.svctype = '0'
               and ts.src_id <> 102
              then coalesce(ts.dev_id::text, '') || '##'
              when ts.svctype <> '0'
              then ts.serv_first_id::text
            end as subs_id
          , ts.* 

        from edw_ods.t_000008_t_services ts

        left join xref
               on xref.source_key = ts.svc_id::text

        where
          now() between ts.eff_dttm and ts.exp_dttm 
          and ts.deleted_ind = 0
          and ts.svctype != '0' 
      ) ts

    inner join
      (
        select
          subs_id
        from
          (
            select
                row_number() over (partition by subs_id order by p1_period DESC) as rn
              , subs_id
              , p1_period 
            from
              (
                select distinct
                    oo_eff_tp.subs_id
                  , oo_eff_tp.p1_period

                from edw_ods.t_000153_efftp_oo_eff_tp oo_eff_tp

                where
                  oo_eff_tp.tech_dt between date_trunc('month',to_date('20190630', 'YYYYMMDD'))::date - interval '1 month' and date_trunc('month',to_date('20190630', 'YYYYMMDD'))::date
                  and oo_eff_tp.serv_id in ('2', '3') -- ШПД, IPTV
              ) oo_eff_tp
          ) oo_eff_tp
        where
          rn = 1
      ) oo_eff_tp
      on oo_eff_tp.subs_id = ts.subs_id
  )
, all_blocking as
  (
    select
        bl_id
      , bl_from
      , bl_ab_id
      , bl_to
      , bl_us_user_name
      , bl_uss_sl_type
      , bl_uss_logname
      , bl_cpu_id
      , bl_desc
      , inputer
      , input_date
      , updater
      , update_date
      , bl_repayment_fl
      , bl_from_used_fl
      , bl_to_used_fl
      , bl_bc_code
      , bl_status
      , row_number() over (partition by bl_id order by bl_status DESC) as rn
    from
    (
      select
          bl_id
        , bl_from
        , bl_ab_id
        , bl_to
        , bl_us_user_name
        , bl_uss_sl_type
        , bl_uss_logname
        , bl_cpu_id
        , bl_desc
        , inputer
        , input_date
        , updater
        , update_date
        , bl_repayment_fl
        , bl_from_used_fl
        , bl_to_used_fl
        , bl_bc_code
        , bl_status
      from edw_ods.t_000021_ct_blocking ct
      where
        ct.bl_status != 'F' 
        and NOW() between ct.eff_dttm and ct.exp_dttm
        and ct.bl_id not in (select bl_id from edw_ods.t_000021_tb_blocking_archive where now() between eff_dttm and exp_dttm)

      union all

      select
          bl_id
        , bl_from
        , bl_ab_id
        , bl_to
        , bl_us_user_name
        , bl_uss_sl_type
        , bl_uss_logname
        , bl_cpu_id
        , bl_desc
        , inputer
        , input_date
        , updater
        , update_date
        , bl_repayment_fl
        , bl_from_used_fl
        , bl_to_used_fl
        , bl_bc_code
        , bl_status
            
      from edw_ods.t_000021_tb_blocking_archive 
      where
        bl_status != 'F'
        and now() between eff_dttm and exp_dttm
    )tab
  )
, svc_db as
  (
    select distinct
        round(ab_id)                                          as ab_id -- "Код абонента"
      , ab.ab_external_code                                   as account
      , us.us_user_name -- "Подключение"
      , blk.bl_from                                           as start_block
      , coalesce(blk.bl_to, to_date('29991231', 'YYYYMMDD'))  as end_block
      , bl_bc_code -- тип блокировки
      , ssip.serv_first_id
        
    from all_blocking blk

    inner join edw_ods.t_000021_abonent ab
            on ab.ab_id = blk.BL_AB_ID 
           and now() between ab.eff_dttm and ab.exp_dttm 
                          
    inner join edw_ods.t_000021_ct_users us
            on ab.ab_id = us.US_AB_ID 
           and coalesce(blk.bl_us_user_name, us.us_user_name) = us.us_user_name
           and us.tech_dt between to_date('20190601', 'YYYYMMDD') and to_date('20190630', 'YYYYMMDD') + interval '1 day - 1 second'
           and us.US_REGDATE <= to_date('20190630', 'YYYYMMDD') + interval '1 day - 1 second'
           and coalesce(us.us_close_date,now()) >= to_date('20190601', 'YYYYMMDD')          
                          
    inner join edw_ods.t_000021_ibs_abs_accounts i
            on i.abs_external_code = ab.ab_external_code 
           and now() between i.eff_dttm and i.exp_dttm
                              
    inner join edw_ods.t_000021_ct_user_services uss
            on uss.uss_us_user_name = us.US_USER_NAME 
           and to_date('20190630', 'YYYYMMDD') + interval '1 day - 1 second' between uss.eff_dttm and uss.exp_dttm

    inner join edw_ods.t_000008_t_service_sip ssip
            on uss.uss_login = ssip.sip_id 
           and ssip.version_state = 'ACTIVE'
           and to_date('20190630', 'YYYYMMDD') + interval '1 day - 1 second' between ssip.eff_dttm and ssip.exp_dttm
           and to_date('20190630', 'YYYYMMDD') + interval '1 day - 1 second' between ssip.date_begin and ssip.date_end
    where
      blk.rn = 1
      and
        (
          blk.BL_FROM <= to_date('20190630', 'YYYYMMDD') + interval '1 day - 1 second'
          and
            (
              blk.BL_TO >= to_date('20190601', 'YYYYMMDD')
              or blk.BL_TO is null
            )
        )
  )
, subs_block as
  (
    select
        substr('20190630',1,6) as bid
      , u.account
      , svc.BL_BC_CODE
      , svc.start_block         as date_begin
      , svc.end_block           as date_end
      , s.dev_id ph
      , s.service_id
      , s.serv_first_id
      , u.user_id
      , s.src_id
      , s.business_service_key
      , s.business_service_name
      , s.sub_id
    from t_services s
    left join edw_ods.t_000008_t_users u
           on s.user_id = u.user_id
          and now() between u.eff_dttm and u.exp_dttm
          and u.deleted_ind = 0
    inner join svc_db svc
            on s.serv_first_id = svc.serv_first_id
           and svc.account = u.account
    where
      date_trunc('day',s.date_begin) <= to_date('20190630', 'YYYYMMDD') + interval '1 day - 1 second'
      and coalesce(s.date_end, to_date('20190630', 'YYYYMMDD')) >= to_date('20190601', 'YYYYMMDD')    
    order by u.account, s.dev_id
  )
, subs_block_period as
  (
    select distinct
        -1                                  as subs_key
      , subs_block.sub_id
      , subs_block.account                  as account_name
      , subs_block.business_service_key
      , bl_bc_code                          as block_type_id
      , 1                                   as block_status_id    -- блокировка установлена
      , subs_block.date_begin               as status_change_date
      , subs_block.src_id

    from subs_block

    inner join period
      on subs_block.date_begin between period.start_date and period.end_date

    union

    select distinct
          -1                                as subs_key
        , subs_block.sub_id
        , subs_block.account                as account_name
        , subs_block.business_service_key
        , bl_bc_code                        as block_type_id
        , 2                                 as block_status_id    -- блокировка снята
        , subs_block.date_end               as status_change_date
      , subs_block.src_id 

    from subs_block

    inner join period
      on subs_block.date_end between period.start_date and period.end_date
  )
, subs_block_type as
  (
    select
        sb.subs_key
      , sb.sub_id
      , sb.account_name
      , sb.business_service_key
      , coalesce(dbt.block_type_id, -1)   as block_type_id
      , coalesce(dbs.block_status_id, -1) as block_status_id
      , sb.status_change_date
      , row_number() over(partition by sb.sub_id, sb.business_service_key, coalesce(dbt.block_type_id, '-1'), sb.block_status_id, sb.status_change_date order by sb.block_type_id) as rn
      , sb.src_id

    from subs_block_period sb

    left join edw_dds.hub_dim_block_type dbt
           on sb.src_id::text = dbt.src_id::text
          and dbt.source_key::text = sb.block_type_id::text
                          
    left join edw_dds.hub_dim_block_status dbs
           on sb.src_id::text = dbs.src_id::text
          and dbs.source_key::text = sb.block_status_id::text
  )

select
    subs_key
  , sub_id
  , account_name
  , business_service_key
  , block_type_id
  , block_status_id
  , status_change_date
  , 000153    as src_id
  , src_id          as rf_src_id

from subs_block_type

where
  rn = 1;

--------------------------------------------------------------------------000009 - 000014
--ОТА
insert into edw_stg_dmcm.tfct_subs_block_1_prt_p000153
  (
      subs_key
    , SUB_ID
    , ACCOUNT_NAME
    , BUSINESS_SERVICE_KEY
    , block_type_id
    , block_status_id
    , status_change_date
    , src_id
    , rf_src_id
  )
with period as
  (
    select
        to_date('20190601',  'YYYYMMDD') as start_date
      , to_date('20190630',  'YYYYMMDD') + interval '1 day - 1 second' as end_date
  )
, xref as
  (
    select
        xref.source_key
      , bs.business_service_key
      , bs.business_service_name
      , xref.sub_make
        
    from edw_stg_dds.t_dim_service_xref_start xref
        
    inner join edw_dds.dim_service et
            on xref.service_key = et.service_key
            and et.active_ind    = 'Y'
            and xref.exp_dttm between et.eff_dttm and et.exp_dttm

    inner join edw_dds.dim_business_service bs
            on bs.business_service_key = et.business_service_key
            and et.exp_dttm between bs.eff_dttm and bs.exp_dttm
            and bs.active_ind = 'Y'
    where
      to_date(substr('20190630',1,6),'YYYYMM') + INTERVAL '1 MONTH - 1 second' between xref.eff_dttm and xref.exp_dttm
      and upper(xref.region_id) = 'VOLGA'
  )
, svc_db as
  (
    select 
        sv.serv_first_id
      , sv.date_begin
      , coalesce(sv.date_end, to_date('29991231', 'YYYYMMDD')) as date_end
      , sv.dev_id
      , sv.sv_reason_id

    from edw_ods.t_000009_T_SV_STATUS sv    

    where
      now() between sv.eff_dttm and sv.exp_dttm
      and sv.date_begin <= to_date('20190630',  'YYYYMMDD')  + interval '1 day - 1 second'
      and coalesce(sv.date_end, to_date('29991231', 'YYYYMMDD')) >= to_date('20190601',  'YYYYMMDD')
  )
, t_services as
  (
    select
      ts.*
    from
      (
        select
            xref.business_service_key
          , xref.business_service_name
          , ts.serv_first_id||'#'|| coalesce(ts.dev_id::text, '')||'#'||ts.svctype||'#'|| coalesce(ts.main_serv_first_id::text, '') as sub_id
          , case
              when ts.svctype = '0'
               and ts.src_id <> 102
              then coalesce(ts.dev_id::text, '') || '##'
              when ts.svctype <> '0'
              then ts.serv_first_id::text
            end as subs_id
          , ts.* 

        from edw_ods.t_000009_t_services ts

        left join xref
               on xref.source_key = ts.svc_id::text

        where
          now() between ts.eff_dttm and ts.exp_dttm 
          and ts.deleted_ind = 0
          AND ts.svctype = '0' 
      )ts

    inner join
      (
        select
          subs_id
        from
          (
            select
                row_number() over (partition by subs_id order by p1_period DESC) as rn
              , subs_id
              , p1_period 
            from
              (
                  select distinct
                      oo_eff_tp.subs_id
                    , oo_eff_tp.p1_period 
                  from edw_ods.t_000153_efftp_oo_eff_tp oo_eff_tp
                  where
                    oo_eff_tp.tech_dt between date_trunc('month',to_date('20190630', 'YYYYMMDD'))::date - interval '1 month' and date_trunc('month',to_date('20190630', 'YYYYMMDD'))::date
                    and oo_eff_tp.serv_id = '1' -- ОТА
              ) oo_eff_tp
        ) oo_eff_tp
        where
          rn = 1
      ) oo_eff_tp
      on oo_eff_tp.subs_id = ts.subs_id

  )
, subs_block as
  (
    select
        substr('20190630',1,6) as bid
      , u.account
      , coalesce(svc.sv_reason_id, '-2') as block_type
      , svc.date_begin
      , coalesce(svc.date_end, to_date('29991231', 'YYYYMMDD') ) as date_end
      , s.dev_id ph
      , s.service_id
      , s.serv_first_id
      , u.user_id
      , s.business_service_key
      , s.business_service_name
      , s.sub_id
      , s.src_id

    from t_services s

    join svc_db svc
      on s.serv_first_id = svc.serv_first_id

    left join edw_ods.t_000009_t_users u
           on s.user_id = u.user_id
          and now() between u.eff_dttm and u.exp_dttm and u.deleted_ind = 0

    where
      to_date('20190630',  'YYYYMMDD') between date_trunc('day',s.date_begin) and coalesce(s.date_end, to_date('20190630',  'YYYYMMDD'))
        
    order by u.account, s.dev_id
  )

select distinct
    -1                                as subs_key
  , subs_block.sub_id
  , subs_block.account                as account_name
  , subs_block.business_service_key
  , coalesce(dbt.block_type_id, -1)   as block_type_id
  , coalesce(dbs.block_status_id, -1) as block_status_id -- блокировка установлена
  , subs_block.date_begin             as status_change_date
  , 000153                      as src_id
  , subs_block.src_id                 as rf_src_id

from subs_block

inner join period
        on subs_block.date_begin between period.start_date and period.end_date
                        
left join edw_dds.hub_dim_block_type dbt
       on subs_block.src_id::text = dbt.src_id::text
      and dbt.source_key::text = subs_block.block_type::text

left join edw_dds.hub_dim_block_status dbs
       on subs_block.src_id::text = dbs.src_id::text
      and dbs.source_key::text = '1'

union

select distinct
    -1                                as subs_key
  , subs_block.sub_id
  , subs_block.account                as account_name
  , subs_block.business_service_key
  , coalesce(dbt.block_type_id, -1)   as block_type_id
  , coalesce(dbs.block_status_id, -1) as block_status_id -- блокировка снята
  , subs_block.date_end               as status_change_date
  , 000153                      as src_id
  , subs_block.src_id                 as rf_src_id
        
from subs_block

inner join period
        on subs_block.date_end between period.start_date and period.end_date

left join edw_dds.hub_dim_block_type dbt
       on subs_block.src_id::text = dbt.src_id::text
      and dbt.source_key::text = subs_block.block_type::text

left join edw_dds.hub_dim_block_status dbs
       on subs_block.src_id::text = dbs.src_id::text
      and dbs.source_key::text = '2'
;

-- ШПД, IPTV
insert into edw_stg_dmcm.tfct_subs_block_1_prt_p000153
  (
      subs_key
    , sub_id
    , account_name
    , business_service_key
    , block_type_id
    , block_status_id
    , status_change_date
    , src_id
    , rf_src_id
  )

with period as
  (
    select
        to_date('20190601', 'YYYYMMDD') as start_date
      , to_date('20190630', 'YYYYMMDD') + interval '1 day - 1 second' as end_date
  )
, xref as
  (
    select
        xref.source_key
      , bs.business_service_key
      , bs.business_service_name
      , xref.sub_make
        
    from edw_stg_dds.t_dim_service_xref_start xref
        
    inner join edw_dds.dim_service et
            on xref.service_key = et.service_key
           and et.active_ind    = 'Y'
           and xref.exp_dttm between et.eff_dttm and et.exp_dttm

    inner join edw_dds.dim_business_service bs
            on bs.business_service_key = et.business_service_key
           and et.exp_dttm between bs.eff_dttm and bs.exp_dttm
           and bs.active_ind = 'Y'
    where
      to_date(substr('20190630',1,6),'YYYYMM') + interval '1 MONTH - 1 second' between xref.eff_dttm and xref.exp_dttm
      and upper(xref.region_id) = 'VOLGA'
  )
, t_services as
  (
    select
      ts.*
    from
      (
        select
            xref.business_service_key
          , xref.business_service_name
          , ts.serv_first_id||'#'|| coalesce(ts.dev_id::text, '')||'#'||ts.svctype||'#'|| coalesce(ts.main_serv_first_id::text, '') as sub_id
          , case
              when ts.svctype = '0'
               and ts.src_id <> 102
              then coalesce(ts.dev_id::text, '') || '##'
              when ts.svctype <> '0'
              then ts.serv_first_id::text
            end as subs_id
          , ts.* 

        from edw_ods.t_000009_t_services ts

        left join xref
               on xref.source_key = ts.svc_id::text

        where
          now() between ts.eff_dttm and ts.exp_dttm 
          and ts.deleted_ind = 0
          and ts.svctype != '0' 
      ) ts

    inner join
      (
        select
          subs_id
        from
          (
            select
                row_number() over (partition by subs_id order by p1_period DESC) as rn
              , subs_id
              , p1_period 
            from
              (
                select distinct
                    oo_eff_tp.subs_id
                  , oo_eff_tp.p1_period

                from edw_ods.t_000153_efftp_oo_eff_tp oo_eff_tp

                where
                  oo_eff_tp.tech_dt between date_trunc('month',to_date('20190630', 'YYYYMMDD'))::date - interval '1 month' and date_trunc('month',to_date('20190630', 'YYYYMMDD'))::date
                  and oo_eff_tp.serv_id in ('2', '3') -- ШПД, IPTV
              ) oo_eff_tp
          ) oo_eff_tp
        where
          rn = 1
      ) oo_eff_tp
      on oo_eff_tp.subs_id = ts.subs_id
  )
, all_blocking as
  (
    select
        bl_id
      , bl_from
      , bl_ab_id
      , bl_to
      , bl_us_user_name
      , bl_uss_sl_type
      , bl_uss_logname
      , bl_cpu_id
      , bl_desc
      , inputer
      , input_date
      , updater
      , update_date
      , bl_repayment_fl
      , bl_from_used_fl
      , bl_to_used_fl
      , bl_bc_code
      , bl_status
      , row_number() over (partition by bl_id order by bl_status DESC) as rn
    from
    (
      select
          bl_id
        , bl_from
        , bl_ab_id
        , bl_to
        , bl_us_user_name
        , bl_uss_sl_type
        , bl_uss_logname
        , bl_cpu_id
        , bl_desc
        , inputer
        , input_date
        , updater
        , update_date
        , bl_repayment_fl
        , bl_from_used_fl
        , bl_to_used_fl
        , bl_bc_code
        , bl_status
      from edw_ods.t_000014_ct_blocking ct
      where
        ct.bl_status != 'F' 
        and NOW() between ct.eff_dttm and ct.exp_dttm
        and ct.bl_id not in (select bl_id from edw_ods.t_000014_tb_blocking_archive where now() between eff_dttm and exp_dttm)

      union all

      select
          bl_id
        , bl_from
        , bl_ab_id
        , bl_to
        , bl_us_user_name
        , bl_uss_sl_type
        , bl_uss_logname
        , bl_cpu_id
        , bl_desc
        , inputer
        , input_date
        , updater
        , update_date
        , bl_repayment_fl
        , bl_from_used_fl
        , bl_to_used_fl
        , bl_bc_code
        , bl_status
            
      from edw_ods.t_000014_tb_blocking_archive 
      where
        bl_status != 'F'
        and now() between eff_dttm and exp_dttm
    )tab
  )
, svc_db as
  (
    select distinct
        round(ab_id)                                          as ab_id -- "Код абонента"
      , ab.ab_external_code                                   as account
      , us.us_user_name -- "Подключение"
      , blk.bl_from                                           as start_block
      , coalesce(blk.bl_to, to_date('29991231', 'YYYYMMDD'))  as end_block
      , bl_bc_code -- тип блокировки
      , ssip.serv_first_id
        
    from all_blocking blk

    inner join edw_ods.t_000014_abonent ab
            on ab.ab_id = blk.BL_AB_ID 
           and now() between ab.eff_dttm and ab.exp_dttm 
                          
    inner join edw_ods.t_000014_ct_users us
            on ab.ab_id = us.US_AB_ID 
           and coalesce(blk.bl_us_user_name, us.us_user_name) = us.us_user_name
           and us.tech_dt between to_date('20190601', 'YYYYMMDD') and to_date('20190630', 'YYYYMMDD') + interval '1 day - 1 second'
           and us.US_REGDATE <= to_date('20190630', 'YYYYMMDD') + interval '1 day - 1 second'
           and coalesce(us.us_close_date,now()) >= to_date('20190601', 'YYYYMMDD')          
                          
    inner join edw_ods.t_000014_ibs_abs_accounts i
            on i.abs_external_code = ab.ab_external_code 
           and now() between i.eff_dttm and i.exp_dttm
                              
    inner join edw_ods.t_000014_ct_user_services uss
            on uss.uss_us_user_name = us.US_USER_NAME 
           and to_date('20190630', 'YYYYMMDD') + interval '1 day - 1 second' between uss.eff_dttm and uss.exp_dttm

    inner join edw_ods.t_000009_t_service_sip ssip
            on uss.uss_login = ssip.sip_id 
           and ssip.version_state = 'ACTIVE'
           and to_date('20190630', 'YYYYMMDD') + interval '1 day - 1 second' between ssip.eff_dttm and ssip.exp_dttm
           and to_date('20190630', 'YYYYMMDD') + interval '1 day - 1 second' between ssip.date_begin and ssip.date_end
    where
      blk.rn = 1
      and
        (
          blk.BL_FROM <= to_date('20190630', 'YYYYMMDD') + interval '1 day - 1 second'
          and
            (
              blk.BL_TO >= to_date('20190601', 'YYYYMMDD')
              or blk.BL_TO is null
            )
        )
  )
, subs_block as
  (
    select
        substr('20190630',1,6) as bid
      , u.account
      , svc.BL_BC_CODE
      , svc.start_block         as date_begin
      , svc.end_block           as date_end
      , s.dev_id ph
      , s.service_id
      , s.serv_first_id
      , u.user_id
      , s.src_id
      , s.business_service_key
      , s.business_service_name
      , s.sub_id
    from t_services s
    left join edw_ods.t_000009_t_users u
           on s.user_id = u.user_id
          and now() between u.eff_dttm and u.exp_dttm
          and u.deleted_ind = 0
    inner join svc_db svc
            on s.serv_first_id = svc.serv_first_id
           and svc.account = u.account
    where
      date_trunc('day',s.date_begin) <= to_date('20190630', 'YYYYMMDD') + interval '1 day - 1 second'
      and coalesce(s.date_end, to_date('20190630', 'YYYYMMDD')) >= to_date('20190601', 'YYYYMMDD')    
    order by u.account, s.dev_id
  )
, subs_block_period as
  (
    select distinct
        -1                                  as subs_key
      , subs_block.sub_id
      , subs_block.account                  as account_name
      , subs_block.business_service_key
      , bl_bc_code                          as block_type_id
      , 1                                   as block_status_id    -- блокировка установлена
      , subs_block.date_begin               as status_change_date
      , subs_block.src_id

    from subs_block

    inner join period
      on subs_block.date_begin between period.start_date and period.end_date

    union

    select distinct
          -1                                as subs_key
        , subs_block.sub_id
        , subs_block.account                as account_name
        , subs_block.business_service_key
        , bl_bc_code                        as block_type_id
        , 2                                 as block_status_id    -- блокировка снята
        , subs_block.date_end               as status_change_date
      , subs_block.src_id 

    from subs_block

    inner join period
      on subs_block.date_end between period.start_date and period.end_date
  )
, subs_block_type as
  (
    select
        sb.subs_key
      , sb.sub_id
      , sb.account_name
      , sb.business_service_key
      , coalesce(dbt.block_type_id, -1)   as block_type_id
      , coalesce(dbs.block_status_id, -1) as block_status_id
      , sb.status_change_date
      , row_number() over(partition by sb.sub_id, sb.business_service_key, coalesce(dbt.block_type_id, '-1'), sb.block_status_id, sb.status_change_date order by sb.block_type_id) as rn
      , sb.src_id

    from subs_block_period sb

    left join edw_dds.hub_dim_block_type dbt
           on sb.src_id::text = dbt.src_id::text
          and dbt.source_key::text = sb.block_type_id::text
                          
    left join edw_dds.hub_dim_block_status dbs
           on sb.src_id::text = dbs.src_id::text
          and dbs.source_key::text = sb.block_status_id::text
  )

select
    subs_key
  , sub_id
  , account_name
  , business_service_key
  , block_type_id
  , block_status_id
  , status_change_date
  , 000153    as src_id
  , src_id          as rf_src_id

from subs_block_type

where
  rn = 1;

--------------------------------------------------------------------------000010 - 000022
--ОТА
insert into edw_stg_dmcm.tfct_subs_block_1_prt_p000153
  (
      subs_key
    , SUB_ID
    , ACCOUNT_NAME
    , BUSINESS_SERVICE_KEY
    , block_type_id
    , block_status_id
    , status_change_date
    , src_id
    , rf_src_id
  )
with period as
  (
    select
        to_date('20190601',  'YYYYMMDD') as start_date
      , to_date('20190630',  'YYYYMMDD') + interval '1 day - 1 second' as end_date
  )
, xref as
  (
    select
        xref.source_key
      , bs.business_service_key
      , bs.business_service_name
      , xref.sub_make
        
    from edw_stg_dds.t_dim_service_xref_start xref
        
    inner join edw_dds.dim_service et
            on xref.service_key = et.service_key
            and et.active_ind    = 'Y'
            and xref.exp_dttm between et.eff_dttm and et.exp_dttm

    inner join edw_dds.dim_business_service bs
            on bs.business_service_key = et.business_service_key
            and et.exp_dttm between bs.eff_dttm and bs.exp_dttm
            and bs.active_ind = 'Y'
    where
      to_date(substr('20190630',1,6),'YYYYMM') + INTERVAL '1 MONTH - 1 second' between xref.eff_dttm and xref.exp_dttm
      and upper(xref.region_id) = 'VOLGA'
  )
, svc_db as
  (
    select 
        sv.serv_first_id
      , sv.date_begin
      , coalesce(sv.date_end, to_date('29991231', 'YYYYMMDD')) as date_end
      , sv.dev_id
      , sv.sv_reason_id

    from edw_ods.t_000010_T_SV_STATUS sv    

    where
      now() between sv.eff_dttm and sv.exp_dttm
      and sv.date_begin <= to_date('20190630',  'YYYYMMDD')  + interval '1 day - 1 second'
      and coalesce(sv.date_end, to_date('29991231', 'YYYYMMDD')) >= to_date('20190601',  'YYYYMMDD')
  )
, t_services as
  (
    select
      ts.*
    from
      (
        select
            xref.business_service_key
          , xref.business_service_name
          , ts.serv_first_id||'#'|| coalesce(ts.dev_id::text, '')||'#'||ts.svctype||'#'|| coalesce(ts.main_serv_first_id::text, '') as sub_id
          , case
              when ts.svctype = '0'
               and ts.src_id <> 102
              then coalesce(ts.dev_id::text, '') || '##'
              when ts.svctype <> '0'
              then ts.serv_first_id::text
            end as subs_id
          , ts.* 

        from edw_ods.t_000010_t_services ts

        left join xref
               on xref.source_key = ts.svc_id::text

        where
          now() between ts.eff_dttm and ts.exp_dttm 
          and ts.deleted_ind = 0
          AND ts.svctype = '0' 
      )ts

    inner join
      (
        select
          subs_id
        from
          (
            select
                row_number() over (partition by subs_id order by p1_period DESC) as rn
              , subs_id
              , p1_period 
            from
              (
                  select distinct
                      oo_eff_tp.subs_id
                    , oo_eff_tp.p1_period 
                  from edw_ods.t_000153_efftp_oo_eff_tp oo_eff_tp
                  where
                    oo_eff_tp.tech_dt between date_trunc('month',to_date('20190630', 'YYYYMMDD'))::date - interval '1 month' and date_trunc('month',to_date('20190630', 'YYYYMMDD'))::date
                    and oo_eff_tp.serv_id = '1' -- ОТА
              ) oo_eff_tp
        ) oo_eff_tp
        where
          rn = 1
      ) oo_eff_tp
      on oo_eff_tp.subs_id = ts.subs_id

  )
, subs_block as
  (
    select
        substr('20190630',1,6) as bid
      , u.account
      , coalesce(svc.sv_reason_id, '-2') as block_type
      , svc.date_begin
      , coalesce(svc.date_end, to_date('29991231', 'YYYYMMDD') ) as date_end
      , s.dev_id ph
      , s.service_id
      , s.serv_first_id
      , u.user_id
      , s.business_service_key
      , s.business_service_name
      , s.sub_id
      , s.src_id

    from t_services s

    join svc_db svc
      on s.serv_first_id = svc.serv_first_id

    left join edw_ods.t_000010_t_users u
           on s.user_id = u.user_id
          and now() between u.eff_dttm and u.exp_dttm and u.deleted_ind = 0

    where
      to_date('20190630',  'YYYYMMDD') between date_trunc('day',s.date_begin) and coalesce(s.date_end, to_date('20190630',  'YYYYMMDD'))
        
    order by u.account, s.dev_id
  )

select distinct
    -1                                as subs_key
  , subs_block.sub_id
  , subs_block.account                as account_name
  , subs_block.business_service_key
  , coalesce(dbt.block_type_id, -1)   as block_type_id
  , coalesce(dbs.block_status_id, -1) as block_status_id -- блокировка установлена
  , subs_block.date_begin             as status_change_date
  , 000153                      as src_id
  , subs_block.src_id                 as rf_src_id

from subs_block

inner join period
        on subs_block.date_begin between period.start_date and period.end_date
                        
left join edw_dds.hub_dim_block_type dbt
       on subs_block.src_id::text = dbt.src_id::text
      and dbt.source_key::text = subs_block.block_type::text

left join edw_dds.hub_dim_block_status dbs
       on subs_block.src_id::text = dbs.src_id::text
      and dbs.source_key::text = '1'

union

select distinct
    -1                                as subs_key
  , subs_block.sub_id
  , subs_block.account                as account_name
  , subs_block.business_service_key
  , coalesce(dbt.block_type_id, -1)   as block_type_id
  , coalesce(dbs.block_status_id, -1) as block_status_id -- блокировка снята
  , subs_block.date_end               as status_change_date
  , 000153                      as src_id
  , subs_block.src_id                 as rf_src_id
        
from subs_block

inner join period
        on subs_block.date_end between period.start_date and period.end_date

left join edw_dds.hub_dim_block_type dbt
       on subs_block.src_id::text = dbt.src_id::text
      and dbt.source_key::text = subs_block.block_type::text

left join edw_dds.hub_dim_block_status dbs
       on subs_block.src_id::text = dbs.src_id::text
      and dbs.source_key::text = '2'
;

-- ШПД, IPTV
insert into edw_stg_dmcm.tfct_subs_block_1_prt_p000153
  (
      subs_key
    , sub_id
    , account_name
    , business_service_key
    , block_type_id
    , block_status_id
    , status_change_date
    , src_id
    , rf_src_id
  )

with period as
  (
    select
        to_date('20190601', 'YYYYMMDD') as start_date
      , to_date('20190630', 'YYYYMMDD') + interval '1 day - 1 second' as end_date
  )
, xref as
  (
    select
        xref.source_key
      , bs.business_service_key
      , bs.business_service_name
      , xref.sub_make
        
    from edw_stg_dds.t_dim_service_xref_start xref
        
    inner join edw_dds.dim_service et
            on xref.service_key = et.service_key
           and et.active_ind    = 'Y'
           and xref.exp_dttm between et.eff_dttm and et.exp_dttm

    inner join edw_dds.dim_business_service bs
            on bs.business_service_key = et.business_service_key
           and et.exp_dttm between bs.eff_dttm and bs.exp_dttm
           and bs.active_ind = 'Y'
    where
      to_date(substr('20190630',1,6),'YYYYMM') + interval '1 MONTH - 1 second' between xref.eff_dttm and xref.exp_dttm
      and upper(xref.region_id) = 'VOLGA'
  )
, t_services as
  (
    select
      ts.*
    from
      (
        select
            xref.business_service_key
          , xref.business_service_name
          , ts.serv_first_id||'#'|| coalesce(ts.dev_id::text, '')||'#'||ts.svctype||'#'|| coalesce(ts.main_serv_first_id::text, '') as sub_id
          , case
              when ts.svctype = '0'
               and ts.src_id <> 102
              then coalesce(ts.dev_id::text, '') || '##'
              when ts.svctype <> '0'
              then ts.serv_first_id::text
            end as subs_id
          , ts.* 

        from edw_ods.t_000010_t_services ts

        left join xref
               on xref.source_key = ts.svc_id::text

        where
          now() between ts.eff_dttm and ts.exp_dttm 
          and ts.deleted_ind = 0
          and ts.svctype != '0' 
      ) ts

    inner join
      (
        select
          subs_id
        from
          (
            select
                row_number() over (partition by subs_id order by p1_period DESC) as rn
              , subs_id
              , p1_period 
            from
              (
                select distinct
                    oo_eff_tp.subs_id
                  , oo_eff_tp.p1_period

                from edw_ods.t_000153_efftp_oo_eff_tp oo_eff_tp

                where
                  oo_eff_tp.tech_dt between date_trunc('month',to_date('20190630', 'YYYYMMDD'))::date - interval '1 month' and date_trunc('month',to_date('20190630', 'YYYYMMDD'))::date
                  and oo_eff_tp.serv_id in ('2', '3') -- ШПД, IPTV
              ) oo_eff_tp
          ) oo_eff_tp
        where
          rn = 1
      ) oo_eff_tp
      on oo_eff_tp.subs_id = ts.subs_id
  )
, all_blocking as
  (
    select
        bl_id
      , bl_from
      , bl_ab_id
      , bl_to
      , bl_us_user_name
      , bl_uss_sl_type
      , bl_uss_logname
      , bl_cpu_id
      , bl_desc
      , inputer
      , input_date
      , updater
      , update_date
      , bl_repayment_fl
      , bl_from_used_fl
      , bl_to_used_fl
      , bl_bc_code
      , bl_status
      , row_number() over (partition by bl_id order by bl_status DESC) as rn
    from
    (
      select
          bl_id
        , bl_from
        , bl_ab_id
        , bl_to
        , bl_us_user_name
        , bl_uss_sl_type
        , bl_uss_logname
        , bl_cpu_id
        , bl_desc
        , inputer
        , input_date
        , updater
        , update_date
        , bl_repayment_fl
        , bl_from_used_fl
        , bl_to_used_fl
        , bl_bc_code
        , bl_status
      from edw_ods.t_000022_ct_blocking ct
      where
        ct.bl_status != 'F' 
        and NOW() between ct.eff_dttm and ct.exp_dttm
        and ct.bl_id not in (select bl_id from edw_ods.t_000022_tb_blocking_archive where now() between eff_dttm and exp_dttm)

      union all

      select
          bl_id
        , bl_from
        , bl_ab_id
        , bl_to
        , bl_us_user_name
        , bl_uss_sl_type
        , bl_uss_logname
        , bl_cpu_id
        , bl_desc
        , inputer
        , input_date
        , updater
        , update_date
        , bl_repayment_fl
        , bl_from_used_fl
        , bl_to_used_fl
        , bl_bc_code
        , bl_status
            
      from edw_ods.t_000022_tb_blocking_archive 
      where
        bl_status != 'F'
        and now() between eff_dttm and exp_dttm
    )tab
  )
, svc_db as
  (
    select distinct
        round(ab_id)                                          as ab_id -- "Код абонента"
      , ab.ab_external_code                                   as account
      , us.us_user_name -- "Подключение"
      , blk.bl_from                                           as start_block
      , coalesce(blk.bl_to, to_date('29991231', 'YYYYMMDD'))  as end_block
      , bl_bc_code -- тип блокировки
      , ssip.serv_first_id
        
    from all_blocking blk

    inner join edw_ods.t_000022_abonent ab
            on ab.ab_id = blk.BL_AB_ID 
           and now() between ab.eff_dttm and ab.exp_dttm 
                          
    inner join edw_ods.t_000022_ct_users us
            on ab.ab_id = us.US_AB_ID 
           and coalesce(blk.bl_us_user_name, us.us_user_name) = us.us_user_name
           and us.tech_dt between to_date('20190601', 'YYYYMMDD') and to_date('20190630', 'YYYYMMDD') + interval '1 day - 1 second'
           and us.US_REGDATE <= to_date('20190630', 'YYYYMMDD') + interval '1 day - 1 second'
           and coalesce(us.us_close_date,now()) >= to_date('20190601', 'YYYYMMDD')          
                          
    inner join edw_ods.t_000022_ibs_abs_accounts i
            on i.abs_external_code = ab.ab_external_code 
           and now() between i.eff_dttm and i.exp_dttm
                              
    inner join edw_ods.t_000022_ct_user_services uss
            on uss.uss_us_user_name = us.US_USER_NAME 
           and to_date('20190630', 'YYYYMMDD') + interval '1 day - 1 second' between uss.eff_dttm and uss.exp_dttm

    inner join edw_ods.t_000010_t_service_sip ssip
            on uss.uss_login = ssip.sip_id 
           and ssip.version_state = 'ACTIVE'
           and to_date('20190630', 'YYYYMMDD') + interval '1 day - 1 second' between ssip.eff_dttm and ssip.exp_dttm
           and to_date('20190630', 'YYYYMMDD') + interval '1 day - 1 second' between ssip.date_begin and ssip.date_end
    where
      blk.rn = 1
      and
        (
          blk.BL_FROM <= to_date('20190630', 'YYYYMMDD') + interval '1 day - 1 second'
          and
            (
              blk.BL_TO >= to_date('20190601', 'YYYYMMDD')
              or blk.BL_TO is null
            )
        )
  )
, subs_block as
  (
    select
        substr('20190630',1,6) as bid
      , u.account
      , svc.BL_BC_CODE
      , svc.start_block         as date_begin
      , svc.end_block           as date_end
      , s.dev_id ph
      , s.service_id
      , s.serv_first_id
      , u.user_id
      , s.src_id
      , s.business_service_key
      , s.business_service_name
      , s.sub_id
    from t_services s
    left join edw_ods.t_000010_t_users u
           on s.user_id = u.user_id
          and now() between u.eff_dttm and u.exp_dttm
          and u.deleted_ind = 0
    inner join svc_db svc
            on s.serv_first_id = svc.serv_first_id
           and svc.account = u.account
    where
      date_trunc('day',s.date_begin) <= to_date('20190630', 'YYYYMMDD') + interval '1 day - 1 second'
      and coalesce(s.date_end, to_date('20190630', 'YYYYMMDD')) >= to_date('20190601', 'YYYYMMDD')    
    order by u.account, s.dev_id
  )
, subs_block_period as
  (
    select distinct
        -1                                  as subs_key
      , subs_block.sub_id
      , subs_block.account                  as account_name
      , subs_block.business_service_key
      , bl_bc_code                          as block_type_id
      , 1                                   as block_status_id    -- блокировка установлена
      , subs_block.date_begin               as status_change_date
      , subs_block.src_id

    from subs_block

    inner join period
      on subs_block.date_begin between period.start_date and period.end_date

    union

    select distinct
          -1                                as subs_key
        , subs_block.sub_id
        , subs_block.account                as account_name
        , subs_block.business_service_key
        , bl_bc_code                        as block_type_id
        , 2                                 as block_status_id    -- блокировка снята
        , subs_block.date_end               as status_change_date
      , subs_block.src_id 

    from subs_block

    inner join period
      on subs_block.date_end between period.start_date and period.end_date
  )
, subs_block_type as
  (
    select
        sb.subs_key
      , sb.sub_id
      , sb.account_name
      , sb.business_service_key
      , coalesce(dbt.block_type_id, -1)   as block_type_id
      , coalesce(dbs.block_status_id, -1) as block_status_id
      , sb.status_change_date
      , row_number() over(partition by sb.sub_id, sb.business_service_key, coalesce(dbt.block_type_id, '-1'), sb.block_status_id, sb.status_change_date order by sb.block_type_id) as rn
      , sb.src_id

    from subs_block_period sb

    left join edw_dds.hub_dim_block_type dbt
           on sb.src_id::text = dbt.src_id::text
          and dbt.source_key::text = sb.block_type_id::text
                          
    left join edw_dds.hub_dim_block_status dbs
           on sb.src_id::text = dbs.src_id::text
          and dbs.source_key::text = sb.block_status_id::text
  )

select
    subs_key
  , sub_id
  , account_name
  , business_service_key
  , block_type_id
  , block_status_id
  , status_change_date
  , 000153    as src_id
  , src_id          as rf_src_id

from subs_block_type

where
  rn = 1;

--------------------------------------------------------------------------000011 - 000023
--ОТА
insert into edw_stg_dmcm.tfct_subs_block_1_prt_p000153
  (
      subs_key
    , SUB_ID
    , ACCOUNT_NAME
    , BUSINESS_SERVICE_KEY
    , block_type_id
    , block_status_id
    , status_change_date
    , src_id
    , rf_src_id
  )
with period as
  (
    select
        to_date('20190601',  'YYYYMMDD') as start_date
      , to_date('20190630',  'YYYYMMDD') + interval '1 day - 1 second' as end_date
  )
, xref as
  (
    select
        xref.source_key
      , bs.business_service_key
      , bs.business_service_name
      , xref.sub_make
        
    from edw_stg_dds.t_dim_service_xref_start xref
        
    inner join edw_dds.dim_service et
            on xref.service_key = et.service_key
            and et.active_ind    = 'Y'
            and xref.exp_dttm between et.eff_dttm and et.exp_dttm

    inner join edw_dds.dim_business_service bs
            on bs.business_service_key = et.business_service_key
            and et.exp_dttm between bs.eff_dttm and bs.exp_dttm
            and bs.active_ind = 'Y'
    where
      to_date(substr('20190630',1,6),'YYYYMM') + INTERVAL '1 MONTH - 1 second' between xref.eff_dttm and xref.exp_dttm
      and upper(xref.region_id) = 'VOLGA'
  )
, svc_db as
  (
    select 
        sv.serv_first_id
      , sv.date_begin
      , coalesce(sv.date_end, to_date('29991231', 'YYYYMMDD')) as date_end
      , sv.dev_id
      , sv.sv_reason_id

    from edw_ods.t_000011_T_SV_STATUS sv    

    where
      now() between sv.eff_dttm and sv.exp_dttm
      and sv.date_begin <= to_date('20190630',  'YYYYMMDD')  + interval '1 day - 1 second'
      and coalesce(sv.date_end, to_date('29991231', 'YYYYMMDD')) >= to_date('20190601',  'YYYYMMDD')
  )
, t_services as
  (
    select
      ts.*
    from
      (
        select
            xref.business_service_key
          , xref.business_service_name
          , ts.serv_first_id||'#'|| coalesce(ts.dev_id::text, '')||'#'||ts.svctype||'#'|| coalesce(ts.main_serv_first_id::text, '') as sub_id
          , case
              when ts.svctype = '0'
               and ts.src_id <> 102
              then coalesce(ts.dev_id::text, '') || '##'
              when ts.svctype <> '0'
              then ts.serv_first_id::text
            end as subs_id
          , ts.* 

        from edw_ods.t_000011_t_services ts

        left join xref
               on xref.source_key = ts.svc_id::text

        where
          now() between ts.eff_dttm and ts.exp_dttm 
          and ts.deleted_ind = 0
          AND ts.svctype = '0' 
      )ts

    inner join
      (
        select
          subs_id
        from
          (
            select
                row_number() over (partition by subs_id order by p1_period DESC) as rn
              , subs_id
              , p1_period 
            from
              (
                  select distinct
                      oo_eff_tp.subs_id
                    , oo_eff_tp.p1_period 
                  from edw_ods.t_000153_efftp_oo_eff_tp oo_eff_tp
                  where
                    oo_eff_tp.tech_dt between date_trunc('month',to_date('20190630', 'YYYYMMDD'))::date - interval '1 month' and date_trunc('month',to_date('20190630', 'YYYYMMDD'))::date
                    and oo_eff_tp.serv_id = '1' -- ОТА
              ) oo_eff_tp
        ) oo_eff_tp
        where
          rn = 1
      ) oo_eff_tp
      on oo_eff_tp.subs_id = ts.subs_id

  )
, subs_block as
  (
    select
        substr('20190630',1,6) as bid
      , u.account
      , coalesce(svc.sv_reason_id, '-2') as block_type
      , svc.date_begin
      , coalesce(svc.date_end, to_date('29991231', 'YYYYMMDD') ) as date_end
      , s.dev_id ph
      , s.service_id
      , s.serv_first_id
      , u.user_id
      , s.business_service_key
      , s.business_service_name
      , s.sub_id
      , s.src_id

    from t_services s

    join svc_db svc
      on s.serv_first_id = svc.serv_first_id

    left join edw_ods.t_000011_t_users u
           on s.user_id = u.user_id
          and now() between u.eff_dttm and u.exp_dttm and u.deleted_ind = 0

    where
      to_date('20190630',  'YYYYMMDD') between date_trunc('day',s.date_begin) and coalesce(s.date_end, to_date('20190630',  'YYYYMMDD'))
        
    order by u.account, s.dev_id
  )

select distinct
    -1                                as subs_key
  , subs_block.sub_id
  , subs_block.account                as account_name
  , subs_block.business_service_key
  , coalesce(dbt.block_type_id, -1)   as block_type_id
  , coalesce(dbs.block_status_id, -1) as block_status_id -- блокировка установлена
  , subs_block.date_begin             as status_change_date
  , 000153                      as src_id
  , subs_block.src_id                 as rf_src_id

from subs_block

inner join period
        on subs_block.date_begin between period.start_date and period.end_date
                        
left join edw_dds.hub_dim_block_type dbt
       on subs_block.src_id::text = dbt.src_id::text
      and dbt.source_key::text = subs_block.block_type::text

left join edw_dds.hub_dim_block_status dbs
       on subs_block.src_id::text = dbs.src_id::text
      and dbs.source_key::text = '1'

union

select distinct
    -1                                as subs_key
  , subs_block.sub_id
  , subs_block.account                as account_name
  , subs_block.business_service_key
  , coalesce(dbt.block_type_id, -1)   as block_type_id
  , coalesce(dbs.block_status_id, -1) as block_status_id -- блокировка снята
  , subs_block.date_end               as status_change_date
  , 000153                      as src_id
  , subs_block.src_id                 as rf_src_id
        
from subs_block

inner join period
        on subs_block.date_end between period.start_date and period.end_date

left join edw_dds.hub_dim_block_type dbt
       on subs_block.src_id::text = dbt.src_id::text
      and dbt.source_key::text = subs_block.block_type::text

left join edw_dds.hub_dim_block_status dbs
       on subs_block.src_id::text = dbs.src_id::text
      and dbs.source_key::text = '2'
;

-- ШПД, IPTV
insert into edw_stg_dmcm.tfct_subs_block_1_prt_p000153
  (
      subs_key
    , sub_id
    , account_name
    , business_service_key
    , block_type_id
    , block_status_id
    , status_change_date
    , src_id
    , rf_src_id
  )

with period as
  (
    select
        to_date('20190601', 'YYYYMMDD') as start_date
      , to_date('20190630', 'YYYYMMDD') + interval '1 day - 1 second' as end_date
  )
, xref as
  (
    select
        xref.source_key
      , bs.business_service_key
      , bs.business_service_name
      , xref.sub_make
        
    from edw_stg_dds.t_dim_service_xref_start xref
        
    inner join edw_dds.dim_service et
            on xref.service_key = et.service_key
           and et.active_ind    = 'Y'
           and xref.exp_dttm between et.eff_dttm and et.exp_dttm

    inner join edw_dds.dim_business_service bs
            on bs.business_service_key = et.business_service_key
           and et.exp_dttm between bs.eff_dttm and bs.exp_dttm
           and bs.active_ind = 'Y'
    where
      to_date(substr('20190630',1,6),'YYYYMM') + interval '1 MONTH - 1 second' between xref.eff_dttm and xref.exp_dttm
      and upper(xref.region_id) = 'VOLGA'
  )
, t_services as
  (
    select
      ts.*
    from
      (
        select
            xref.business_service_key
          , xref.business_service_name
          , ts.serv_first_id||'#'|| coalesce(ts.dev_id::text, '')||'#'||ts.svctype||'#'|| coalesce(ts.main_serv_first_id::text, '') as sub_id
          , case
              when ts.svctype = '0'
               and ts.src_id <> 102
              then coalesce(ts.dev_id::text, '') || '##'
              when ts.svctype <> '0'
              then ts.serv_first_id::text
            end as subs_id
          , ts.* 

        from edw_ods.t_000011_t_services ts

        left join xref
               on xref.source_key = ts.svc_id::text

        where
          now() between ts.eff_dttm and ts.exp_dttm 
          and ts.deleted_ind = 0
          and ts.svctype != '0' 
      ) ts

    inner join
      (
        select
          subs_id
        from
          (
            select
                row_number() over (partition by subs_id order by p1_period DESC) as rn
              , subs_id
              , p1_period 
            from
              (
                select distinct
                    oo_eff_tp.subs_id
                  , oo_eff_tp.p1_period

                from edw_ods.t_000153_efftp_oo_eff_tp oo_eff_tp

                where
                  oo_eff_tp.tech_dt between date_trunc('month',to_date('20190630', 'YYYYMMDD'))::date - interval '1 month' and date_trunc('month',to_date('20190630', 'YYYYMMDD'))::date
                  and oo_eff_tp.serv_id in ('2', '3') -- ШПД, IPTV
              ) oo_eff_tp
          ) oo_eff_tp
        where
          rn = 1
      ) oo_eff_tp
      on oo_eff_tp.subs_id = ts.subs_id
  )
, all_blocking as
  (
    select
        bl_id
      , bl_from
      , bl_ab_id
      , bl_to
      , bl_us_user_name
      , bl_uss_sl_type
      , bl_uss_logname
      , bl_cpu_id
      , bl_desc
      , inputer
      , input_date
      , updater
      , update_date
      , bl_repayment_fl
      , bl_from_used_fl
      , bl_to_used_fl
      , bl_bc_code
      , bl_status
      , row_number() over (partition by bl_id order by bl_status DESC) as rn
    from
    (
      select
          bl_id
        , bl_from
        , bl_ab_id
        , bl_to
        , bl_us_user_name
        , bl_uss_sl_type
        , bl_uss_logname
        , bl_cpu_id
        , bl_desc
        , inputer
        , input_date
        , updater
        , update_date
        , bl_repayment_fl
        , bl_from_used_fl
        , bl_to_used_fl
        , bl_bc_code
        , bl_status
      from edw_ods.t_000023_ct_blocking ct
      where
        ct.bl_status != 'F' 
        and NOW() between ct.eff_dttm and ct.exp_dttm
        and ct.bl_id not in (select bl_id from edw_ods.t_000023_tb_blocking_archive where now() between eff_dttm and exp_dttm)

      union all

      select
          bl_id
        , bl_from
        , bl_ab_id
        , bl_to
        , bl_us_user_name
        , bl_uss_sl_type
        , bl_uss_logname
        , bl_cpu_id
        , bl_desc
        , inputer
        , input_date
        , updater
        , update_date
        , bl_repayment_fl
        , bl_from_used_fl
        , bl_to_used_fl
        , bl_bc_code
        , bl_status
            
      from edw_ods.t_000023_tb_blocking_archive 
      where
        bl_status != 'F'
        and now() between eff_dttm and exp_dttm
    )tab
  )
, svc_db as
  (
    select distinct
        round(ab_id)                                          as ab_id -- "Код абонента"
      , ab.ab_external_code                                   as account
      , us.us_user_name -- "Подключение"
      , blk.bl_from                                           as start_block
      , coalesce(blk.bl_to, to_date('29991231', 'YYYYMMDD'))  as end_block
      , bl_bc_code -- тип блокировки
      , ssip.serv_first_id
        
    from all_blocking blk

    inner join edw_ods.t_000023_abonent ab
            on ab.ab_id = blk.BL_AB_ID 
           and now() between ab.eff_dttm and ab.exp_dttm 
                          
    inner join edw_ods.t_000023_ct_users us
            on ab.ab_id = us.US_AB_ID 
           and coalesce(blk.bl_us_user_name, us.us_user_name) = us.us_user_name
           and us.tech_dt between to_date('20190601', 'YYYYMMDD') and to_date('20190630', 'YYYYMMDD') + interval '1 day - 1 second'
           and us.US_REGDATE <= to_date('20190630', 'YYYYMMDD') + interval '1 day - 1 second'
           and coalesce(us.us_close_date,now()) >= to_date('20190601', 'YYYYMMDD')          
                          
    inner join edw_ods.t_000023_ibs_abs_accounts i
            on i.abs_external_code = ab.ab_external_code 
           and now() between i.eff_dttm and i.exp_dttm
                              
    inner join edw_ods.t_000023_ct_user_services uss
            on uss.uss_us_user_name = us.US_USER_NAME 
           and to_date('20190630', 'YYYYMMDD') + interval '1 day - 1 second' between uss.eff_dttm and uss.exp_dttm

    inner join edw_ods.t_000011_t_service_sip ssip
            on uss.uss_login = ssip.sip_id 
           and ssip.version_state = 'ACTIVE'
           and to_date('20190630', 'YYYYMMDD') + interval '1 day - 1 second' between ssip.eff_dttm and ssip.exp_dttm
           and to_date('20190630', 'YYYYMMDD') + interval '1 day - 1 second' between ssip.date_begin and ssip.date_end
    where
      blk.rn = 1
      and
        (
          blk.BL_FROM <= to_date('20190630', 'YYYYMMDD') + interval '1 day - 1 second'
          and
            (
              blk.BL_TO >= to_date('20190601', 'YYYYMMDD')
              or blk.BL_TO is null
            )
        )
  )
, subs_block as
  (
    select
        substr('20190630',1,6) as bid
      , u.account
      , svc.BL_BC_CODE
      , svc.start_block         as date_begin
      , svc.end_block           as date_end
      , s.dev_id ph
      , s.service_id
      , s.serv_first_id
      , u.user_id
      , s.src_id
      , s.business_service_key
      , s.business_service_name
      , s.sub_id
    from t_services s
    left join edw_ods.t_000011_t_users u
           on s.user_id = u.user_id
          and now() between u.eff_dttm and u.exp_dttm
          and u.deleted_ind = 0
    inner join svc_db svc
            on s.serv_first_id = svc.serv_first_id
           and svc.account = u.account
    where
      date_trunc('day',s.date_begin) <= to_date('20190630', 'YYYYMMDD') + interval '1 day - 1 second'
      and coalesce(s.date_end, to_date('20190630', 'YYYYMMDD')) >= to_date('20190601', 'YYYYMMDD')    
    order by u.account, s.dev_id
  )
, subs_block_period as
  (
    select distinct
        -1                                  as subs_key
      , subs_block.sub_id
      , subs_block.account                  as account_name
      , subs_block.business_service_key
      , bl_bc_code                          as block_type_id
      , 1                                   as block_status_id    -- блокировка установлена
      , subs_block.date_begin               as status_change_date
      , subs_block.src_id

    from subs_block

    inner join period
      on subs_block.date_begin between period.start_date and period.end_date

    union

    select distinct
          -1                                as subs_key
        , subs_block.sub_id
        , subs_block.account                as account_name
        , subs_block.business_service_key
        , bl_bc_code                        as block_type_id
        , 2                                 as block_status_id    -- блокировка снята
        , subs_block.date_end               as status_change_date
      , subs_block.src_id 

    from subs_block

    inner join period
      on subs_block.date_end between period.start_date and period.end_date
  )
, subs_block_type as
  (
    select
        sb.subs_key
      , sb.sub_id
      , sb.account_name
      , sb.business_service_key
      , coalesce(dbt.block_type_id, -1)   as block_type_id
      , coalesce(dbs.block_status_id, -1) as block_status_id
      , sb.status_change_date
      , row_number() over(partition by sb.sub_id, sb.business_service_key, coalesce(dbt.block_type_id, '-1'), sb.block_status_id, sb.status_change_date order by sb.block_type_id) as rn
      , sb.src_id

    from subs_block_period sb

    left join edw_dds.hub_dim_block_type dbt
           on sb.src_id::text = dbt.src_id::text
          and dbt.source_key::text = sb.block_type_id::text
                          
    left join edw_dds.hub_dim_block_status dbs
           on sb.src_id::text = dbs.src_id::text
          and dbs.source_key::text = sb.block_status_id::text
  )

select
    subs_key
  , sub_id
  , account_name
  , business_service_key
  , block_type_id
  , block_status_id
  , status_change_date
  , 000153    as src_id
  , src_id          as rf_src_id

from subs_block_type

where
  rn = 1;

--------------------------------------------------------------------------000012 - 000024
--ОТА
insert into edw_stg_dmcm.tfct_subs_block_1_prt_p000153
  (
      subs_key
    , SUB_ID
    , ACCOUNT_NAME
    , BUSINESS_SERVICE_KEY
    , block_type_id
    , block_status_id
    , status_change_date
    , src_id
    , rf_src_id
  )
with period as
  (
    select
        to_date('20190601',  'YYYYMMDD') as start_date
      , to_date('20190630',  'YYYYMMDD') + interval '1 day - 1 second' as end_date
  )
, xref as
  (
    select
        xref.source_key
      , bs.business_service_key
      , bs.business_service_name
      , xref.sub_make
        
    from edw_stg_dds.t_dim_service_xref_start xref
        
    inner join edw_dds.dim_service et
            on xref.service_key = et.service_key
            and et.active_ind    = 'Y'
            and xref.exp_dttm between et.eff_dttm and et.exp_dttm

    inner join edw_dds.dim_business_service bs
            on bs.business_service_key = et.business_service_key
            and et.exp_dttm between bs.eff_dttm and bs.exp_dttm
            and bs.active_ind = 'Y'
    where
      to_date(substr('20190630',1,6),'YYYYMM') + INTERVAL '1 MONTH - 1 second' between xref.eff_dttm and xref.exp_dttm
      and upper(xref.region_id) = 'VOLGA'
  )
, svc_db as
  (
    select 
        sv.serv_first_id
      , sv.date_begin
      , coalesce(sv.date_end, to_date('29991231', 'YYYYMMDD')) as date_end
      , sv.dev_id
      , sv.sv_reason_id

    from edw_ods.t_000012_T_SV_STATUS sv    

    where
      now() between sv.eff_dttm and sv.exp_dttm
      and sv.date_begin <= to_date('20190630',  'YYYYMMDD')  + interval '1 day - 1 second'
      and coalesce(sv.date_end, to_date('29991231', 'YYYYMMDD')) >= to_date('20190601',  'YYYYMMDD')
  )
, t_services as
  (
    select
      ts.*
    from
      (
        select
            xref.business_service_key
          , xref.business_service_name
          , ts.serv_first_id||'#'|| coalesce(ts.dev_id::text, '')||'#'||ts.svctype||'#'|| coalesce(ts.main_serv_first_id::text, '') as sub_id
          , case
              when ts.svctype = '0'
               and ts.src_id <> 102
              then coalesce(ts.dev_id::text, '') || '##'
              when ts.svctype <> '0'
              then ts.serv_first_id::text
            end as subs_id
          , ts.* 

        from edw_ods.t_000012_t_services ts

        left join xref
               on xref.source_key = ts.svc_id::text

        where
          now() between ts.eff_dttm and ts.exp_dttm 
          and ts.deleted_ind = 0
          AND ts.svctype = '0' 
      )ts

    inner join
      (
        select
          subs_id
        from
          (
            select
                row_number() over (partition by subs_id order by p1_period DESC) as rn
              , subs_id
              , p1_period 
            from
              (
                  select distinct
                      oo_eff_tp.subs_id
                    , oo_eff_tp.p1_period 
                  from edw_ods.t_000153_efftp_oo_eff_tp oo_eff_tp
                  where
                    oo_eff_tp.tech_dt between date_trunc('month',to_date('20190630', 'YYYYMMDD'))::date - interval '1 month' and date_trunc('month',to_date('20190630', 'YYYYMMDD'))::date
                    and oo_eff_tp.serv_id = '1' -- ОТА
              ) oo_eff_tp
        ) oo_eff_tp
        where
          rn = 1
      ) oo_eff_tp
      on oo_eff_tp.subs_id = ts.subs_id

  )
, subs_block as
  (
    select
        substr('20190630',1,6) as bid
      , u.account
      , coalesce(svc.sv_reason_id, '-2') as block_type
      , svc.date_begin
      , coalesce(svc.date_end, to_date('29991231', 'YYYYMMDD') ) as date_end
      , s.dev_id ph
      , s.service_id
      , s.serv_first_id
      , u.user_id
      , s.business_service_key
      , s.business_service_name
      , s.sub_id
      , s.src_id

    from t_services s

    join svc_db svc
      on s.serv_first_id = svc.serv_first_id

    left join edw_ods.t_000012_t_users u
           on s.user_id = u.user_id
          and now() between u.eff_dttm and u.exp_dttm and u.deleted_ind = 0

    where
      to_date('20190630',  'YYYYMMDD') between date_trunc('day',s.date_begin) and coalesce(s.date_end, to_date('20190630',  'YYYYMMDD'))
        
    order by u.account, s.dev_id
  )

select distinct
    -1                                as subs_key
  , subs_block.sub_id
  , subs_block.account                as account_name
  , subs_block.business_service_key
  , coalesce(dbt.block_type_id, -1)   as block_type_id
  , coalesce(dbs.block_status_id, -1) as block_status_id -- блокировка установлена
  , subs_block.date_begin             as status_change_date
  , 000153                      as src_id
  , subs_block.src_id                 as rf_src_id

from subs_block

inner join period
        on subs_block.date_begin between period.start_date and period.end_date
                        
left join edw_dds.hub_dim_block_type dbt
       on subs_block.src_id::text = dbt.src_id::text
      and dbt.source_key::text = subs_block.block_type::text

left join edw_dds.hub_dim_block_status dbs
       on subs_block.src_id::text = dbs.src_id::text
      and dbs.source_key::text = '1'

union

select distinct
    -1                                as subs_key
  , subs_block.sub_id
  , subs_block.account                as account_name
  , subs_block.business_service_key
  , coalesce(dbt.block_type_id, -1)   as block_type_id
  , coalesce(dbs.block_status_id, -1) as block_status_id -- блокировка снята
  , subs_block.date_end               as status_change_date
  , 000153                      as src_id
  , subs_block.src_id                 as rf_src_id
        
from subs_block

inner join period
        on subs_block.date_end between period.start_date and period.end_date

left join edw_dds.hub_dim_block_type dbt
       on subs_block.src_id::text = dbt.src_id::text
      and dbt.source_key::text = subs_block.block_type::text

left join edw_dds.hub_dim_block_status dbs
       on subs_block.src_id::text = dbs.src_id::text
      and dbs.source_key::text = '2'
;

-- ШПД, IPTV
insert into edw_stg_dmcm.tfct_subs_block_1_prt_p000153
  (
      subs_key
    , sub_id
    , account_name
    , business_service_key
    , block_type_id
    , block_status_id
    , status_change_date
    , src_id
    , rf_src_id
  )

with period as
  (
    select
        to_date('20190601', 'YYYYMMDD') as start_date
      , to_date('20190630', 'YYYYMMDD') + interval '1 day - 1 second' as end_date
  )
, xref as
  (
    select
        xref.source_key
      , bs.business_service_key
      , bs.business_service_name
      , xref.sub_make
        
    from edw_stg_dds.t_dim_service_xref_start xref
        
    inner join edw_dds.dim_service et
            on xref.service_key = et.service_key
           and et.active_ind    = 'Y'
           and xref.exp_dttm between et.eff_dttm and et.exp_dttm

    inner join edw_dds.dim_business_service bs
            on bs.business_service_key = et.business_service_key
           and et.exp_dttm between bs.eff_dttm and bs.exp_dttm
           and bs.active_ind = 'Y'
    where
      to_date(substr('20190630',1,6),'YYYYMM') + interval '1 MONTH - 1 second' between xref.eff_dttm and xref.exp_dttm
      and upper(xref.region_id) = 'VOLGA'
  )
, t_services as
  (
    select
      ts.*
    from
      (
        select
            xref.business_service_key
          , xref.business_service_name
          , ts.serv_first_id||'#'|| coalesce(ts.dev_id::text, '')||'#'||ts.svctype||'#'|| coalesce(ts.main_serv_first_id::text, '') as sub_id
          , case
              when ts.svctype = '0'
               and ts.src_id <> 102
              then coalesce(ts.dev_id::text, '') || '##'
              when ts.svctype <> '0'
              then ts.serv_first_id::text
            end as subs_id
          , ts.* 

        from edw_ods.t_000012_t_services ts

        left join xref
               on xref.source_key = ts.svc_id::text

        where
          now() between ts.eff_dttm and ts.exp_dttm 
          and ts.deleted_ind = 0
          and ts.svctype != '0' 
      ) ts

    inner join
      (
        select
          subs_id
        from
          (
            select
                row_number() over (partition by subs_id order by p1_period DESC) as rn
              , subs_id
              , p1_period 
            from
              (
                select distinct
                    oo_eff_tp.subs_id
                  , oo_eff_tp.p1_period

                from edw_ods.t_000153_efftp_oo_eff_tp oo_eff_tp

                where
                  oo_eff_tp.tech_dt between date_trunc('month',to_date('20190630', 'YYYYMMDD'))::date - interval '1 month' and date_trunc('month',to_date('20190630', 'YYYYMMDD'))::date
                  and oo_eff_tp.serv_id in ('2', '3') -- ШПД, IPTV
              ) oo_eff_tp
          ) oo_eff_tp
        where
          rn = 1
      ) oo_eff_tp
      on oo_eff_tp.subs_id = ts.subs_id
  )
, all_blocking as
  (
    select
        bl_id
      , bl_from
      , bl_ab_id
      , bl_to
      , bl_us_user_name
      , bl_uss_sl_type
      , bl_uss_logname
      , bl_cpu_id
      , bl_desc
      , inputer
      , input_date
      , updater
      , update_date
      , bl_repayment_fl
      , bl_from_used_fl
      , bl_to_used_fl
      , bl_bc_code
      , bl_status
      , row_number() over (partition by bl_id order by bl_status DESC) as rn
    from
    (
      select
          bl_id
        , bl_from
        , bl_ab_id
        , bl_to
        , bl_us_user_name
        , bl_uss_sl_type
        , bl_uss_logname
        , bl_cpu_id
        , bl_desc
        , inputer
        , input_date
        , updater
        , update_date
        , bl_repayment_fl
        , bl_from_used_fl
        , bl_to_used_fl
        , bl_bc_code
        , bl_status
      from edw_ods.t_000024_ct_blocking ct
      where
        ct.bl_status != 'F' 
        and NOW() between ct.eff_dttm and ct.exp_dttm
        and ct.bl_id not in (select bl_id from edw_ods.t_000024_tb_blocking_archive where now() between eff_dttm and exp_dttm)

      union all

      select
          bl_id
        , bl_from
        , bl_ab_id
        , bl_to
        , bl_us_user_name
        , bl_uss_sl_type
        , bl_uss_logname
        , bl_cpu_id
        , bl_desc
        , inputer
        , input_date
        , updater
        , update_date
        , bl_repayment_fl
        , bl_from_used_fl
        , bl_to_used_fl
        , bl_bc_code
        , bl_status
            
      from edw_ods.t_000024_tb_blocking_archive 
      where
        bl_status != 'F'
        and now() between eff_dttm and exp_dttm
    )tab
  )
, svc_db as
  (
    select distinct
        round(ab_id)                                          as ab_id -- "Код абонента"
      , ab.ab_external_code                                   as account
      , us.us_user_name -- "Подключение"
      , blk.bl_from                                           as start_block
      , coalesce(blk.bl_to, to_date('29991231', 'YYYYMMDD'))  as end_block
      , bl_bc_code -- тип блокировки
      , ssip.serv_first_id
        
    from all_blocking blk

    inner join edw_ods.t_000024_abonent ab
            on ab.ab_id = blk.BL_AB_ID 
           and now() between ab.eff_dttm and ab.exp_dttm 
                          
    inner join edw_ods.t_000024_ct_users us
            on ab.ab_id = us.US_AB_ID 
           and coalesce(blk.bl_us_user_name, us.us_user_name) = us.us_user_name
           and us.tech_dt between to_date('20190601', 'YYYYMMDD') and to_date('20190630', 'YYYYMMDD') + interval '1 day - 1 second'
           and us.US_REGDATE <= to_date('20190630', 'YYYYMMDD') + interval '1 day - 1 second'
           and coalesce(us.us_close_date,now()) >= to_date('20190601', 'YYYYMMDD')          
                          
    inner join edw_ods.t_000024_ibs_abs_accounts i
            on i.abs_external_code = ab.ab_external_code 
           and now() between i.eff_dttm and i.exp_dttm
                              
    inner join edw_ods.t_000024_ct_user_services uss
            on uss.uss_us_user_name = us.US_USER_NAME 
           and to_date('20190630', 'YYYYMMDD') + interval '1 day - 1 second' between uss.eff_dttm and uss.exp_dttm

    inner join edw_ods.t_000012_t_service_sip ssip
            on uss.uss_login = ssip.sip_id 
           and ssip.version_state = 'ACTIVE'
           and to_date('20190630', 'YYYYMMDD') + interval '1 day - 1 second' between ssip.eff_dttm and ssip.exp_dttm
           and to_date('20190630', 'YYYYMMDD') + interval '1 day - 1 second' between ssip.date_begin and ssip.date_end
    where
      blk.rn = 1
      and
        (
          blk.BL_FROM <= to_date('20190630', 'YYYYMMDD') + interval '1 day - 1 second'
          and
            (
              blk.BL_TO >= to_date('20190601', 'YYYYMMDD')
              or blk.BL_TO is null
            )
        )
  )
, subs_block as
  (
    select
        substr('20190630',1,6) as bid
      , u.account
      , svc.BL_BC_CODE
      , svc.start_block         as date_begin
      , svc.end_block           as date_end
      , s.dev_id ph
      , s.service_id
      , s.serv_first_id
      , u.user_id
      , s.src_id
      , s.business_service_key
      , s.business_service_name
      , s.sub_id
    from t_services s
    left join edw_ods.t_000012_t_users u
           on s.user_id = u.user_id
          and now() between u.eff_dttm and u.exp_dttm
          and u.deleted_ind = 0
    inner join svc_db svc
            on s.serv_first_id = svc.serv_first_id
           and svc.account = u.account
    where
      date_trunc('day',s.date_begin) <= to_date('20190630', 'YYYYMMDD') + interval '1 day - 1 second'
      and coalesce(s.date_end, to_date('20190630', 'YYYYMMDD')) >= to_date('20190601', 'YYYYMMDD')    
    order by u.account, s.dev_id
  )
, subs_block_period as
  (
    select distinct
        -1                                  as subs_key
      , subs_block.sub_id
      , subs_block.account                  as account_name
      , subs_block.business_service_key
      , bl_bc_code                          as block_type_id
      , 1                                   as block_status_id    -- блокировка установлена
      , subs_block.date_begin               as status_change_date
      , subs_block.src_id

    from subs_block

    inner join period
      on subs_block.date_begin between period.start_date and period.end_date

    union

    select distinct
          -1                                as subs_key
        , subs_block.sub_id
        , subs_block.account                as account_name
        , subs_block.business_service_key
        , bl_bc_code                        as block_type_id
        , 2                                 as block_status_id    -- блокировка снята
        , subs_block.date_end               as status_change_date
      , subs_block.src_id 

    from subs_block

    inner join period
      on subs_block.date_end between period.start_date and period.end_date
  )
, subs_block_type as
  (
    select
        sb.subs_key
      , sb.sub_id
      , sb.account_name
      , sb.business_service_key
      , coalesce(dbt.block_type_id, -1)   as block_type_id
      , coalesce(dbs.block_status_id, -1) as block_status_id
      , sb.status_change_date
      , row_number() over(partition by sb.sub_id, sb.business_service_key, coalesce(dbt.block_type_id, '-1'), sb.block_status_id, sb.status_change_date order by sb.block_type_id) as rn
      , sb.src_id

    from subs_block_period sb

    left join edw_dds.hub_dim_block_type dbt
           on sb.src_id::text = dbt.src_id::text
          and dbt.source_key::text = sb.block_type_id::text
                          
    left join edw_dds.hub_dim_block_status dbs
           on sb.src_id::text = dbs.src_id::text
          and dbs.source_key::text = sb.block_status_id::text
  )

select
    subs_key
  , sub_id
  , account_name
  , business_service_key
  , block_type_id
  , block_status_id
  , status_change_date
  , 000153    as src_id
  , src_id          as rf_src_id

from subs_block_type

where
  rn = 1;

commit;
analyze edw_stg_dmcm.tfct_subs_block_1_prt_p000153;
