/*rev.34588 31.07.2019 Changed by: NAREK.ALAVERDYAN */
		--AGG_BBA_CONSUMPTION
		truncate table edw_stg_ads.agg_bba_consumption_1_prt_p000081;
		INSERT INTO edw_stg_ads.agg_bba_consumption_1_prt_p000081
			(
				calendar_key,
				year_month_key,
				adjust_period,
				segment_key,
				center_num_key,
				duty_num_key,
				branch_key,
				region_key,
				type_of_billing_services_key,
				service_rtk_detail_key,
				rc_key,
				technology_type_key,
				service_type_key,
				service_key,
				total_download_data_volume,
				total_upload_data_volume,
				src_id,
				load_dttm,
				md5
			)

		SELECT 
			total.calendar_key,
			total.year_month_key,
			total.adjust_period,
			total.segment_key,
			total.center_num_key,
			total.duty_num_key,
			total.branch_key,
			total.region_key,
			total.type_of_billing_services_key,
			total.service_rtk_detail_key,
			total.rc_key,
			total.technology_type_key,
			total.service_type_key,
			total.service_key,
			total.total_download_data_volume,
			total.total_upload_data_volume,
			total.src_id,
			CURRENT_TIMESTAMP AS load_dttm,
			MD5
				(((((((((((((((((
					COALESCE(total.calendar_key::text, ''::text)) || CHR(9)) ||
					COALESCE(total.segment_key::text, ''::text)) || CHR(9)) ||
					COALESCE(total.branch_key::text, ''::text)) || CHR(9)) ||
					COALESCE(total.type_of_billing_services_key::text, ''::text)) || CHR(9)) ||
					COALESCE(total.service_rtk_detail_key::text, ''::text)) || CHR(9)) ||
					COALESCE(total.technology_type_key::text, ''::text)) || CHR(9)) ||
					COALESCE(total.service_type_key::text, ''::text)) || CHR(9)) ||
					COALESCE(total.service_key::text, ''::text)) || CHR(9))
				) AS md5
		FROM 
			(
					SELECT
						calendar_key,
						year_month_key,
						adjust_period,
						segment_key,
						center_num_key,
						duty_num_key,
						branch_key,
						region_key,
						type_of_billing_services_key,
						service_rtk_detail_key,
						rc_key,
						technology_type_key,
						service_type_key,
						service_key,
						SUM(total_download_data_volume) AS total_download_data_volume,
						SUM(total_upload_data_volume) AS total_upload_data_volume,
						src_id
					FROM edw_stg_ads.tfct_bba_consumption_1_prt_p000081
					WHERE 
						src_id=81
						AND calendar_key BETWEEN date_trunc('month', to_date('20190601', 'YYYYMMDD'))
							AND (date_trunc('month', to_date('20190630', 'YYYYMMDD')) + INTERVAL '1 month' + INTERVAL '-1 day')
					GROUP BY 
						calendar_key,
						year_month_key,
						adjust_period,
						segment_key,
						center_num_key,
						duty_num_key,
						branch_key,
						region_key,
						type_of_billing_services_key,
						service_rtk_detail_key,
						rc_key,
						technology_type_key,
						service_type_key,
						service_key,
						src_id
			) AS total;
			
		ANALYZE edw_stg_ads.agg_bba_consumption_1_prt_p000081;
	