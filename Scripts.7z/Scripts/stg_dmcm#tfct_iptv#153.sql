/*rev. 22139*/SET search_path = edw_stg_dmcm;
SET optimizer = OFF;



TRUNCATE TABLE edw_stg_dmcm.pre_iptv_dim_address_stg_1_PRT_P000153;
INSERT INTO edw_stg_dmcm.pre_iptv_dim_address_stg_1_PRT_P000153 (
  mrf_id,
  rf_id,
  account,
  city,
  address,
  src_id
)
  SELECT
    coalesce ( adr.mrf_id, subs.mrf_id )   AS mrf_id,
    coalesce ( adr.rf_id, subs.rf_id )     AS rf_id,
    coalesce ( adr.account, subs.account ) AS account,
    coalesce ( subs.city, adr.city )       AS city,
    CASE WHEN subs.city IS NOT NULL
      THEN subs.address
    ELSE adr.address
    END                                    AS address,
    153 as src_id
  FROM (
         SELECT
           /*+ NoNestLoop(q, ad1, sa)*/
           q.mrf_id,
           q.rf_id,
           CASE WHEN q.mrf_id = 14
             THEN sa.nls
           ELSE q.account
           END                                                     AS account,
           ad1.city                                                AS city,
           ad1.address || CASE WHEN q.flat IS NULL
             THEN ''
                          ELSE ', ' END || coalesce ( q.flat, '' ) AS address,
           row_number ( )
           OVER (
             PARTITION BY
               CASE WHEN q.mrf_id = 14
                 THEN sa.nls
               ELSE q.account
               END,
               q.mrf_id,
               q.rf_id
             ORDER BY ad1.city, ad1.address || CASE WHEN q.flat IS NULL
               THEN ''
                                               ELSE ', ' END || coalesce ( q.flat, '' )
             )                                                        rn
         FROM (
                SELECT
                  ad1.mrf_id,
                  ad1.rf_id,
                  ad1.account,
                  ad1.house_lid,
                  ad1.flat
                FROM edw_ods.T_000153_RPRT_OO_ADDRESSABNDWH ad1
              ) q
           LEFT JOIN (
                       SELECT
                         ad1.city,
                         ad1.mrf_id,
                         ad1.house_lid,
                         ad1.POSTOFFICE_ID || CASE WHEN ad1.POSTOFFICE_ID IS NOT NULL
                           THEN ', '
                                              ELSE '' END
                         || ad1.TERR_TYPE || CASE WHEN ad1.TERR_TYPE IS NOT NULL
                           THEN ' '
                                             ELSE '' END
                         || ad1.NAME_TERR || CASE WHEN coalesce ( ad1.TERR_TYPE, ad1.NAME_TERR ) IS NOT NULL
                           THEN ', '
                                             ELSE '' END
                         || ad1.CITY || CASE WHEN CITY IS NOT NULL
                           THEN ', '
                                        ELSE '' END
                         || ad1.NAME_STREET_TYPE || CASE WHEN ad1.NAME_STREET_TYPE IS NOT NULL
                           THEN ' '
                                                    ELSE '' END
                         || ad1.NAME_STREET || CASE WHEN coalesce ( ad1.NAME_STREET_TYPE, ad1.NAME_STREET ) IS NOT NULL
                           THEN ', '
                                               ELSE '' END
                         || ad1.HOUSE AS address
                       FROM edw_ods.T_000153_RPRT_OO_ADDRESS ad1
                     ) ad1
             ON q.mrf_id = ad1.mrf_id
                AND q.house_lid = ad1.house_lid
           LEFT JOIN edw_ods.T_000158_EFFTP_SOUTH_NLS_ACCNT sa
             ON sa.mrf_id = 14
                AND sa.account = q.account
                AND ( sa.date_end IS NULL
                      OR sa.date_end = to_date ( '2999-12-31', 'yyyy-mm-dd' ) )
       ) adr
    FULL JOIN (
                SELECT
                  /*+ NoNestLoop(subs_act, sa)*/
                  subs_act.mrf_id,
                  subs_act.rf_id,
                  CASE WHEN subs_act.mrf_id = 14
                    THEN sa.nls
                  ELSE subs_act.account
                  END                AS account,
                  subs_act.city_name AS city,
                  subs_act.adress    AS address,
                  row_number ( )
                  OVER (
                    PARTITION BY
                      CASE WHEN subs_act.mrf_id = 14
                        THEN sa.nls
                      ELSE subs_act.account
                      END,
                      subs_act.mrf_id,
                      subs_act.rf_id
                    ORDER BY subs_act.city_name, subs_act.adress
                    )                   rn
                FROM edw_ods.T_000153_RPRTSUBSCRIBERSACTUAL subs_act
                  LEFT JOIN edw_ods.T_000158_EFFTP_SOUTH_NLS_ACCNT sa
                    ON sa.mrf_id = 14
                       AND sa.account = subs_act.account
                       AND coalesce ( sa.date_end, to_date ( '2999-12-31', 'yyyy-mm-dd' ) ) =
                           to_date ( '2999-12-31', 'yyyy-mm-dd' )
                WHERE coalesce ( subs_act.data_close_serv, to_date ( '2999-12-31', 'yyyy-mm-dd' ) ) =
                      to_date ( '2999-12-31', 'yyyy-mm-dd' )
                      AND
                      coalesce ( subs_act.data_close, to_date ( '2999-12-31', 'yyyy-mm-dd' ) ) =
                      to_date ( '2999-12-31', 'yyyy-mm-dd' )
                      AND city_name != '6666666666666666'
              ) subs
      ON subs.account = adr.account
         AND subs.mrf_id = adr.mrf_id
         AND subs.rf_id = adr.rf_id
  WHERE adr.rn = 1
        AND subs.rn = 1;
ANALYSE edw_stg_dmcm.pre_iptv_dim_address_stg_1_PRT_P000153;


SET optimizer = ON;
TRUNCATE TABLE edw_stg_dmcm.PRE_IPTV_CHARGES_STG_1_PRT_P000153;
INSERT INTO edw_stg_dmcm.PRE_IPTV_CHARGES_STG_1_PRT_P000153
(account_key, account_name, rf_id, date_snap, abn_id, charge_iptv_all, charge_iptv_main, charge_iptv_add, charge_iptv_sale, charge_iptv_lease, min_date_iptv, max_date_iptv,
 charge_code, src_id)
  SELECT
    coalesce ( account_key, 0 )              AS account_key,
    coalesce ( CASE WHEN sa.mrf_id = 14
      THEN sa.nls
               ELSE chrg.account END, '' )   AS account_name,
    coalesce ( chrg.rf_id, 0 )               AS rf_id,
    ( date_trunc ( 'MONTH', period :: DATE )
      + INTERVAL '1 MONTH - 1 day' ) :: DATE AS date_snap,
    coalesce ( abn_id, 0 )                   AS abn_id,


    sum (
      CASE WHEN CHARGE_CODE LIKE 'R08010102%'
                OR CHARGE_CODE LIKE 'R08010103%'
        THEN charge - chrg.vat_amount
      ELSE 0
      END
    )                                        AS charge_iptv_all,
    sum (
      CASE WHEN CHARGE_CODE IN ( 'R0801010322', 'R0801010232', 'R0801010242', 'R0801010252' )
        THEN charge - chrg.vat_amount
      ELSE 0
      END
    )                                        AS charge_iptv_main,
    sum (
      CASE WHEN CHARGE_CODE IN ( 'R0801010324', 'R0801010234', 'R0801010244', 'R0801010254' )
        THEN charge - chrg.vat_amount
      ELSE 0
      END
    )                                        AS charge_iptv_add,
    sum (
      CASE WHEN CHARGE_CODE IN ( 'R0801010292', 'R0801010296', 'R0801010297', 'R0801010298' )
        THEN charge - chrg.vat_amount
      ELSE 0
      END
    )                                        AS charge_iptv_sale,
    sum (
      CASE WHEN CHARGE_CODE IN ( 'R0801010291', 'R0801010293', 'R0801010294', 'R0801010295' )
        THEN charge - chrg.vat_amount
      ELSE 0
      END
    )                                        AS charge_iptv_lease,
    min (
      CASE WHEN CHARGE_CODE IN
                ( 'R0801010322', 'R0801010232', 'R0801010242', 'R0801010252', 'R0801010324', 'R0801010234', 'R0801010244', 'R0801010254',
                                 'R0801010292', 'R0801010296', 'R0801010297', 'R0801010298', 'R0801010291', 'R0801010293', 'R0801010294', 'R0801010295' )
        THEN DATE_CHARGE
      ELSE NULL
      END
    )                                        AS min_date_iptv,
    max (
      CASE WHEN CHARGE_CODE IN
                ( 'R0801010322', 'R0801010232', 'R0801010242', 'R0801010252', 'R0801010324', 'R0801010234', 'R0801010244', 'R0801010254',
                                 'R0801010322', 'R0801010232', 'R0801010242', 'R0801010252', 'R0801010324', 'R0801010234', 'R0801010244', 'R0801010254',
                                                                              'R0801010292', 'R0801010296', 'R0801010297', 'R0801010298', 'R0801010291', 'R0801010293', 'R0801010294', 'R0801010295' )
        THEN DATE_CHARGE
      ELSE NULL
      END
    )                                        AS max_date_iptv,

    coalesce ( charge_code, '' )             AS charge_code,
    153                              AS src_id
  FROM edw_ods.T_000153_RPRT_CHARGES_DWH  chrg

    LEFT JOIN edw_ods.T_000158_EFFTP_SOUTH_NLS_ACCNT sa ON sa.mrf_id = 14
                                                           AND sa.account = chrg.account
                                                           AND sa.date_end IS NULL

LEFT JOIN
    (
      SELECT
        account_name,
        account_key,
        ROW_NUMBER ( )
        OVER (
          PARTITION BY account_name
          ORDER BY start_date DESC, end_date DESC ) AS actual_account_key
      FROM edw_dds.dim_account
    ) acc ON
           (CASE WHEN sa.mrf_id = 14
              THEN sa.nls
            ELSE chrg.account END) = acc.account_name
            AND acc.actual_account_key = 1

  WHERE ( date_trunc ( 'MONTH', period :: DATE )
          + INTERVAL '1 MONTH - 1 day' ) :: DATE >= to_date ( '20190601', 'YYYYMMDD' ) AND
        ( date_trunc ( 'MONTH', period :: DATE )
          + INTERVAL '1 MONTH - 1 day' ) :: DATE <= to_date ( '20190630', 'YYYYMMDD' )
        AND chrg.coef_r12 = 1

  GROUP BY acc.account_key,
    COALESCE ( CASE WHEN sa.mrf_id = 14
      THEN sa.nls
               ELSE chrg.account END, '' ),
    chrg.rf_id,
    chrg.abn_id,
    to_char ( period :: DATE, 'YYYYMM' ),
    ( date_trunc ( 'MONTH', period :: DATE )
      + INTERVAL '1 MONTH - 1 day' ) :: DATE,
    chrg.charge_code,
    chrg.period;

ANALYSE edw_stg_dmcm.PRE_IPTV_CHARGES_STG_1_PRT_P000153;


SET optimizer = ON;
TRUNCATE TABLE edw_stg_dmcm.TFCT_IPTV_1_PRT_P000153;
INSERT INTO edw_stg_dmcm.TFCT_IPTV_1_PRT_P000153 (inn, account_key, period, date_snap, account, client_name, rtpl_name, tp_start, charge_iptv_all, charge_iptv_main,
                                                          charge_iptv_add, charge_iptv_sale, charge_iptv_lease, arpu_iptv, min_date_iptv, max_date_iptv, id_macro_segment,
                                                          k_code, addr_city, cnt_ch_iptv, rf, mrf, name_microsegment, id_rf, serv_status, date_start, src_id)
  SELECT
    coalesce (
      CASE
      WHEN cl.inn IN
           ( '-', '0', '00', '000', '0000', '-000', '-0000', '00000', '-00000', '000000', '0000000', '000000000', '0000000000' )
        THEN NULL
      ELSE cl.inn
      END, '' )                                                        AS inn,
    ch.account_key,
    to_char ( ch.date_snap,
              'YYYYMM' )                                               AS period,
    ch.date_snap,
    ch.account_name                                                    AS account,
    cl.contr_name                                                      AS client_name,
    coalesce ( vpd.rtpl_name,'' )                                      AS rtpl_name,
    coalesce ( vpd.tp_start, '2017-01-01 00:00:00' )                   AS tp_start,
    sum (
      ch.charge_iptv_all )                                             AS charge_iptv_all,
    sum (
      ch.charge_iptv_main )                                            AS charge_iptv_main,
    sum (
      ch.charge_iptv_add )                                             AS charge_iptv_add,
    sum (
      ch.charge_iptv_sale )                                            AS charge_iptv_sale,
    sum (
      ch.charge_iptv_lease )                                           AS charge_iptv_lease,
    sum ( charge_iptv_main +
          charge_iptv_add +
          charge_iptv_sale +
          charge_iptv_lease )                                          AS arpu_iptv,
    min ( coalesce ( ch.min_date_iptv,
                     '2017-01-01 00:00:00' ) ) :: TIMESTAMP            AS min_date_iptv,
    '1000-01-01 00:00:00' :: TIMESTAMP                                 AS max_date_iptv,
    cl.id_macro_segment_ud                                             AS id_macro_segment,
    nm.macro_segment                                                   AS k_code,
    adr.city                                                           AS addr_city,
    NULL                                                               AS cnt_ch_iptv,
    coalesce ( br.branch_name, br2.branch_name, '' )                   AS rf,
    coalesce ( CASE WHEN br.parent_branch_key = -1
      THEN br.branch_name
               ELSE br_par.branch_name
               END,
               CASE WHEN br2.parent_branch_key = -1
                 THEN br2.branch_name
               ELSE br_par2.branch_name
               END, '' )                                               AS mrf,
    nm.name_microsegment,
    coalesce ( br.branch_key, br2.branch_key )                         AS id_rf,
    0                                                                  AS serv_status,
    min ( coalesce ( sa.data_connect, sa.data_contr, sa.data_activ ) ) AS date_start,
    153                                                        AS src_id
  FROM edw_stg_dmcm.PRE_IPTV_CHARGES_STG_1_PRT_P000153 ch

    LEFT JOIN (
                SELECT
                  account_                                                       AS account,
                  coalesce ( sss.rf_id, sss.rf_id_ )                             AS rf_id,
                  coalesce ( sss.id_macro_segment_ud, sss.id_macro_segment_ud_ ) AS id_macro_segment_ud,
                  coalesce ( sss.inn, sss.inn_ )                                 AS inn,
                  coalesce ( sss.contr_name, sss.contr_name_ )                   AS contr_name

                FROM (
                       SELECT
                         c.rf_id,
                         c.id_macro_segment_ud,
                         c.inn,
                         c.contr_name,
                         CASE WHEN sa.mrf_id = 14
                           THEN sa.nls
                         ELSE c.account END                        AS account_,
                         min ( c.rf_id )
                         OVER (
                           PARTITION BY CASE WHEN sa.mrf_id = 14
                             THEN sa.nls
                                        ELSE c.account END )       AS rf_id_,
                         min ( id_macro_segment_ud )
                         OVER (
                           PARTITION BY CASE WHEN sa.mrf_id = 14
                             THEN sa.nls
                                        ELSE c.account END )       AS id_macro_segment_ud_,
                         min ( inn )
                         OVER (
                           PARTITION BY CASE WHEN sa.mrf_id = 14
                             THEN sa.nls
                                        ELSE c.account END )       AS inn_,
                         min ( contr_name )
                         OVER (
                           PARTITION BY CASE WHEN sa.mrf_id = 14
                             THEN sa.nls
                                        ELSE c.account END )       AS contr_name_,
                         row_number ( )
                         OVER (
                           PARTITION BY CASE WHEN sa.mrf_id = 14
                             THEN sa.nls
                                        ELSE c.account END
                           ORDER BY CASE WHEN C.date_snap <= to_date ( '20190630', 'YYYYMMDD' )
                             THEN 0
                                    ELSE 1 END, C.date_snap DESC ) AS rn
                       FROM edw_ods.T_000153_RPRT_CLIENT_DWH C
                       LEFT JOIN (
                       SELECT
                       mrf_id,
                       nls,
                       account,
                       row_number ( )
                       OVER (
                       PARTITION BY account
                       ORDER BY date_begin DESC ) rn
                                                  FROM edw_ods.T_000158_EFFTP_SOUTH_NLS_ACCNT
                                 ) sa
                                   ON sa.mrf_id = 14
                                   AND sa.account = C.account
                                          AND sa.rn = 1
                     ) sss
                WHERE sss.rn = 1 ) cl

      ON ch.account_name = cl.account

    LEFT JOIN edw_ods.T_000153_RPRTSUBSCRIBERSACTUAL sa ON sa.abn_id = ch.abn_id
                                                AND sa.rf_id = cl.rf_id

    LEFT JOIN edw_dds.hub_dim_branch b ON b.src_id = 158
                                          AND cl.rf_id :: text = b.source_key
                                          AND date_trunc('day',b.exp_dttm) = to_date('2999-12-31','yyyy-mm-dd')

    LEFT JOIN edw_dds.dim_branch br ON b.branch_key = br.branch_key
                                       AND br.deleted_ind = 0
                                       AND date_trunc('day',br.exp_dttm) = to_date('2999-12-31','yyyy-mm-dd')

    LEFT JOIN edw_dds.dim_branch br_par ON br.parent_branch_key = br_par.branch_key
                                           AND br_par.deleted_ind = 0
                                           AND date_trunc('day',br_par.exp_dttm) = to_date('2999-12-31','yyyy-mm-dd')

    /* попытка посадить бранчи на rf_id из чарджа, а не клиента*/
    LEFT JOIN edw_dds.hub_dim_branch b2 ON b2.src_id = 158
                                           AND ch.rf_id :: text = b2.source_key
                                           AND date_trunc('day',b2.exp_dttm) = to_date('2999-12-31','yyyy-mm-dd')

    LEFT JOIN edw_dds.dim_branch br2 ON b2.branch_key = br2.branch_key
                                        AND br2.deleted_ind = 0
                                        AND date_trunc('day',br2.exp_dttm) = to_date('2999-12-31','yyyy-mm-dd')


    LEFT JOIN edw_dds.dim_branch br_par2 ON br2.parent_branch_key = br_par2.branch_key
                                            AND br_par2.deleted_ind = 0
                                            AND date_trunc('day',br_par2.exp_dttm) = to_date('2999-12-31','yyyy-mm-dd')


    LEFT JOIN (
                SELECT
                  account_                                     AS ACCOUNT,
                  COALESCE ( tbl.SPEED, tbl.SPEED_ )           AS SPEED,
                  COALESCE ( tbl.tech_id, tbl.tech_id_ )       AS TECH_ID,
                  COALESCE ( tbl.START_RTPL, tbl.START_RTPL_ ) AS tp_start,
				          COALESCE ( tbl.rtpl_name, tbl.rtpl_name_ )   AS rtpl_name,
                  COALESCE ( BASE_SRC_ID, 0 )                  AS base_src_id,
                  COALESCE ( LOG_ID, 0 )                       AS log_id
                FROM
                  (
                    SELECT
                      v.START_RTPL,
                      v.tech_id,
                      v.SPEED,
					            v.rtpl_name,
                      v.BASE_SRC_ID,
                      v.LOG_ID,
                      CASE WHEN sa.mrf_id = 14
                        THEN sa.nls
                      ELSE v.account END         AS account_,
                      MIN ( START_RTPL )
                      OVER (
                        PARTITION BY v.account ) AS START_RTPL_,
                      MIN ( tech_id )
                      OVER (
                        PARTITION BY v.account ) AS tech_id_,
                      MIN ( SPEED )
                      OVER (
                        PARTITION BY v.account ) AS SPEED_,
					          	MIN ( rtpl_name )
                      OVER (
                        PARTITION BY v.account ) AS rtpl_name_,
                      row_number ( )
                      OVER (
                        PARTITION BY CASE WHEN sa.mrf_id = 14
                          THEN sa.nls
                                     ELSE v.account END
                        ORDER BY CASE WHEN v.date_start <= to_date ( '20190630', 'YYYYMMDD' )
                    THEN 0
                    ELSE 1 END, v.date_start DESC ) AS rn
                FROM edw_ods.T_000153_RPRT_VRATE_PLANS_DWH v
                     LEFT JOIN (
                                          SELECT
                                            mrf_id,
                                            account,
                                            nls,
                                            date_end,
                                            row_number ( )
                                            OVER (
                                            PARTITION BY account
                                            ORDER BY load_dttm DESC ) rn
                                          FROM edw_ods.T_000158_EFFTP_SOUTH_NLS_ACCNT
                                            WHERE date_end IS NULL
                                            AND mrf_id = 14
                               ) sa
                                 ON sa.mrf_id = 14
                                 AND sa.account = v.account
                                        AND sa.rn = 1
                                                    WHERE v.serv_id IN ( -1, 3, 31, 32, 33, 34, 35, 36 )
              ) tbl

  WHERE tbl.rn = 1 ) vpd ON ch.account_name = vpd.account

    LEFT JOIN edw_ods.T_000158_RPRT_DIRD_MACRO_SGMNT nm
    ON nm.id_macro_segment = cl.id_macro_segment_ud

    LEFT JOIN edw_stg_dmcm.pre_iptv_dim_address_stg_1_PRT_P000153 adr
    ON adr.account = ch.account_name

    WHERE ch.date_snap >= to_date ( '20190601', 'YYYYMMDD' ) AND ch.date_snap <= to_date ( '20190630', 'YYYYMMDD' )
    AND ch.charge_iptv_all > 0
    GROUP BY inn
    , ch.account_key
    , ch.date_snap
    , ch.account_name
    , cl.contr_name
    , vpd.rtpl_name
    , tp_start
    , COALESCE ( br.branch_name, br2.branch_name, '' )
    , COALESCE ( CASE WHEN br.parent_branch_key = -1
    THEN br.branch_name
    ELSE br_par.branch_name
    END,
    CASE WHEN br2.parent_branch_key = -1
    THEN br2.branch_name
    ELSE br_par2.branch_name
    END, '' )
    , cl.id_macro_segment_ud
    , nm.macro_segment
    , adr.city
    , nm.name_microsegment
    , COALESCE ( br.branch_key, br2.branch_key );


ANALYSE edw_stg_dmcm.TFCT_IPTV_1_PRT_P000153;
