/*rev.44802 от 13.12.2019*/;
delete from edw_stg_mdm.put_xref_dim_service_list where src_id = 000171;

insert into edw_stg_mdm.put_xref_dim_service_list 
(
  source_key,
  source_name,
  src_id
)
select distinct
	src_id||'_'||coalesce(req_pack,'null') as source_key
	,req_pack as source_name
	,src_id as src_id
from
	edw_ods.t_000171_dwh_mpz;

  analyze edw_stg_mdm.put_xref_dim_service_list;