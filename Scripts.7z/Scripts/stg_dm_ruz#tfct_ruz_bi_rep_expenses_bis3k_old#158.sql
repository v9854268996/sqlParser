/*rev.44180 от 06.12.2019*/


TRUNCATE TABLE EDW_STG_DM_RUZ.TFCT_RUZ_BI_REP_EXPENSES_BIS3K_OLD_1_prt_p000158;


INSERT INTO EDW_STG_DM_RUZ.TFCT_RUZ_BI_REP_EXPENSES_BIS3K_OLD_1_prt_p000158 
		(period
	   , mrf_id
       , mrf_name
       , rf_id
       , rf_name
       , subs_count
       , cfo   
       , segment_id
	   , service
	   , id_be
	   , name_be
	   , id_subj
	   , name_subj
	   , dt_act
	   , sap_code
       , load_dttm
       , src_id
) 
SELECT 
         to_date(period::text, 'YYYYMM')
	   , mrf_id
       , mrf_name
       , rf_id
       , rf_name
       , subs_count
       , cfo   
       , segment_id
	   , service
	   , id_be
	   , name_be
	   , id_subj
	   , name_subj
	   , dt_act
	   , zbizserv
       , load_dttm
       , src_id
	from edw_ods.T_000158_RUZ_BI_REP_EXPENSES_BIS3K
	where tech_dt between to_date('20190601', 'YYYYMMDD') and  to_date('20190630', 'YYYYMMDD');

ANALYSE EDW_STG_DM_RUZ.TFCT_RUZ_BI_REP_EXPENSES_BIS3K_OLD_1_prt_p000158;