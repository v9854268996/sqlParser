/*rev.14667 18.09.2018*/
delete from edw_stg_mdm.put_dim_adjust_types_xref_start where region_id = 'VOLGA' and src_id = 000001;

insert into edw_stg_mdm.put_dim_adjust_types_xref_start (ajtp_key,adjust_type_name,comment,region_id,src_id)
select
	case when IS_CHARGE = 1 then '1'||'#'||REASON_ID when IS_PAYMENT = 1 then '3'||'#'||REASON_ID else REASON_ID::text end as adjust_type_key ,
	NAME as adjust_type_name ,
	substr(ANNOTATION,0,255) as comment,
	'VOLGA' as region_id,
	src_id
from edw_ods.t_000001_T_REASON_RECALCULATION
where to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second' between eff_dttm and exp_dttm;

commit;
analyse edw_stg_mdm.put_dim_adjust_types_xref_start;
