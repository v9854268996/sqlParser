-- rev. 59605 от 02.06.2020
SET optimizer = ON;
SET search_path = edw_stg_dm_b2b;
--SET client_min_messages = error; -- только wrk скрипт
SET gp_recursive_cte_prototype = 'true';
COMMIT;

-- справочник сегментов
BEGIN;
  TRUNCATE TABLE edw_stg_dm_b2b.pre_serv_sales_trad_segment_1_prt_p000107;
COMMIT;

BEGIN;
INSERT INTO edw_stg_dm_b2b.pre_serv_sales_trad_segment_1_prt_p000107
  (source_key, segment_key, macro_segment_key, src_id)
WITH
recursive r(source, root, segment_key, parent_segment_key, path, level, cycle) AS
(
  SELECT 'CHILD' AS source,
         vdcs.source_key AS root,
         edcs.segment_key,
         edcs.parent_segment_key,
         ARRAY [ edcs.segment_key ],
         1,
         FALSE
    FROM edw_dds.hub_dim_segment vdcs
         JOIN
         edw_dds.dim_segment edcs
           ON edcs.segment_key = vdcs.segment_key
          AND date_trunc('day', edcs.exp_dttm) = to_date('2999-12-31', 'yyyy-mm-dd')
          AND edcs.deleted_ind = 0
   WHERE vdcs.src_id = 000107
     AND date_trunc('day', vdcs.exp_dttm) = to_date('2999-12-31', 'yyyy-mm-dd')
   UNION ALL
  SELECT 'PARENT' AS source,
         r.root AS root,
         edcs.segment_key,
         edcs.parent_segment_key,
         r.path || edcs.segment_key,
         r.level + 1 AS level,
         edcs.segment_key = ANY(r.path)
    FROM edw_dds.dim_segment edcs
         JOIN
         r
           ON edcs.segment_key = r.parent_segment_key
          AND date_trunc('day', edcs.exp_dttm) = to_date('2999-12-31', 'yyyy-mm-dd')
          AND edcs.deleted_ind = 0
          AND edcs.parent_segment_key <> '-1'
          AND NOT cycle
)
SELECT r.root AS source_key,
       r.segment_key,
       r2.segment_key AS macro_segment_key,
       000107::smallint AS src_id
  FROM r
       JOIN
       r r2
         ON r2.root = r.root
        AND r2.level = (SELECT MAX(level) FROM r rr WHERE rr.root = r.root)
 WHERE r.source = 'CHILD';
COMMIT;

BEGIN;
  ANALYZE edw_stg_dm_b2b.pre_serv_sales_trad_segment_1_prt_p000107;
COMMIT;

BEGIN;
  TRUNCATE TABLE edw_stg_dm_b2b.tfct_serv_sales_1_prt_p000107;
COMMIT;

BEGIN;
INSERT INTO edw_stg_dm_b2b.tfct_serv_sales_1_prt_p000107
(
  period,
  service_key,
  business_service_key,
  branch_key,
  segment_key,
  macro_segment_key,
  client_name,
  inn,
  account,
  subs_src_id,
  subs_login,
  subs_activation_dt,
  order_num,
  order_dt,
  sales_channel_key,
  sales_channel,
  seller_name,
  iptv_type_id,
  shpd_migration_flg,
  serv_qnty,
  sale_serv_id,
  load_dttm,
  src_id
)
WITH
-- справочник услуг
dim_service AS
(
  SELECT hub.source_key,
         svc.service_key,
         bs.business_service_key
    FROM edw_dds.hub_dim_service hub
         JOIN
         edw_dds.dim_service svc
           ON svc.service_key = hub.service_key
          AND svc.deleted_ind = 0
          AND date_trunc('day', svc.exp_dttm) = to_date('2999-12-31', 'yyyy-mm-dd')
         LEFT JOIN
         edw_dds.dim_business_service bs
           ON svc.business_service_key = bs.business_service_key
          AND bs.deleted_ind = 0
          AND date_trunc('day', bs.exp_dttm) = to_date('2999-12-31', 'yyyy-mm-dd')
   WHERE date_trunc('day', hub.exp_dttm) = to_date('2999-12-31', 'yyyy-mm-dd')
     AND hub.src_id = 000107
)
SELECT ts.period,
       dim_service.service_key,
       dim_service.business_service_key,
       decode(ts.branch_key, '01701', 1701,
                             '01706', 1706,
                             '01704', 1704,
                             '01705', 1705,
                             '01703', 1703,
                             '01702', 1702,
                             '01708', 1708) AS branch_key,
       dim_segment.segment_key,
       dim_segment.macro_segment_key,
       ts.inn_name AS client_name,
       ts.inn,
       ts.account_key AS account,
       ts.subs_key AS subs_src_id,
       ts.subs_login,
       ts.subs_activation_dt,
       ts.number_activate AS order_num,
       ts.number_close_dt AS order_dt,
       NULL AS sales_channel_key,
       ts.channel AS sales_channel,
       substring(ts.manager, 1, 100) AS seller_name,
       coalesce(ts.iptv_type, 0) AS iptv_type_id,
       ts.action_type AS shpd_migration_flg,
       ts.count_serv AS serv_qnty,
       ts.account_key || '#' || ts.subs_login AS sale_serv_id,
       now() AS load_dttm,
       ts.src_id
  FROM edw_ods.t_000107_t_case_new_abonent ts
       JOIN
       dim_service
         ON dim_service.source_key = ts.service_key
       JOIN
       edw_stg_dm_b2b.pre_serv_sales_trad_segment_1_prt_p000107 dim_segment
         ON dim_segment.source_key = ts.segment_key
 WHERE ts.iscorp = 1
   AND ts.period >= date_trunc('month', to_date('20190601', 'YYYYMMDD'))
   AND ts.period <= date_trunc('month', to_date('20190630', 'YYYYMMDD'));
COMMIT;

BEGIN;
  ANALYZE edw_stg_dm_b2b.tfct_serv_sales_1_prt_p000107;
COMMIT;