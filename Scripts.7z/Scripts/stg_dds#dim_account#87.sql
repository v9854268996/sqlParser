/*rev.56722 28.10.2019*/

TRUNCATE TABLE edw_stg_dds.t_000087_dim_account;

INSERT INTO edw_stg_dds.t_000087_dim_account
(
	account_key,
	account_name,
	partner_key,
	agent_scheme_key,
	parent_account_key,
	duty_num_key,
	center_num_key,
	branch_key,
	region_key,
	src_id,
	cession_date,
	load_dttm,
	eff_dttm,
	exp_dttm,
	start_date,
	end_date
)
SELECT
	account_key,
	account_name,
	partner_key,
	agent_scheme_key,
	parent_account_key,
	duty_num_key,
	center_num_key,
	branch_key,
	region_key,
	src_id,
	cession_date,
	load_dttm,
	eff_dttm,
	CASE
		WHEN date_trunc('DAY', exp_dttm)::TIMESTAMP = '2999-12-31'
		THEN date_trunc('DAY', exp_dttm)::TIMESTAMP
		ELSE exp_dttm
	END AS exp_dttm,
	eff_dttm AS start_date,
	CASE
		WHEN date_trunc('DAY', exp_dttm)::TIMESTAMP = '2999-12-31'
		THEN date_trunc('DAY', exp_dttm)::TIMESTAMP
		ELSE exp_dttm
	END AS end_date
FROM (
	SELECT
		t_users.src_id || '#' || ROUND(t_users.user_id) AS account_key,
		t_users.account AS account_name,
		ROUND(t_users.user_id) AS partner_key,
		1 AS agent_scheme_key,
		t_vip_sp.user_id_vip AS parent_account_key,
		CASE
			WHEN ROUND(t_user_type_ref.user_type_id) IN(80000,80100)
			THEN 0
			WHEN COALESCE(ROUND(ttr.coef), ROUND(t_user_type_ref.coef)) = 1
			THEN 0
			WHEN COALESCE(ROUND(ttr.coef), ROUND(t_user_type_ref.coef)) = 0
				AND COALESCE(ROUND(ttr.user_type_id), ROUND(t_saldo.user_type_id), ROUND(t_users.user_type_id)) IN(80000,80100)
			THEN 0
			ELSE 1
		END AS duty_num_key,
		CASE
			WHEN ROUND(t_user_type_ref.user_type_id) IN(80000,80100)
			THEN 1
			WHEN COALESCE(ROUND(ttr.coef), ROUND(t_user_type_ref.coef)) = 1
			THEN 0
			WHEN COALESCE(ROUND(ttr.coef), ROUND(t_user_type_ref.coef)) = 0
				AND COALESCE(ROUND(ttr.user_type_id), ROUND(t_saldo.user_type_id), ROUND(t_users.user_type_id)) IN(80000,80100)
			THEN 1
			ELSE 0
		END AS center_num_key,
		COALESCE(ROUND(t_saldo.dept_id), ROUND(t_users.dept_id)) AS branch_key,
		COALESCE(ROUND(t_saldo.dept_id), ROUND(t_users.dept_id)) AS region_key,
		t_users.src_id AS src_id,
		cession.cession_date,
		NOW() AS load_dttm,
		COALESCE(DECODE(t_saldo.billing_id, t_saldo.min_billing_id, TO_DATE('19000101', 'YYYYMMDD')), TO_DATE((ROUND(t_saldo.billing_id))::VARCHAR, 'YYYYMM'), TO_DATE('19000101', 'YYYYMMDD')) AS eff_dttm,
		COALESCE(DECODE(t_saldo.billing_id, t_saldo.max_billing_id, TO_DATE('29991231', 'YYYYMMDD')), TO_DATE((ROUND(t_saldo.billing_id))::VARCHAR, 'YYYYMM') + INTERVAL '1 MONTH - 1 DAY', TO_DATE('29991231', 'YYYYMMDD')) + INTERVAL '1 DAY - 1 SECOND' AS exp_dttm
	FROM edw_ods.t_000087_t_users t_users
	LEFT JOIN (
		SELECT
			billing_id,
			user_id,
			dept_id,
			user_type_id,
			MAX(billing_id) OVER (PARTITION BY user_id) AS max_billing_id,
			MIN(billing_id) OVER (PARTITION BY user_id) AS min_billing_id
		FROM edw_ods.t_000087_t_saldo
		WHERE billing_id <= (SUBSTR('20190630', 1, 6)::NUMERIC(38,0))
			AND tech_dt <= TO_DATE(SUBSTR('20190630', 1, 8), 'YYYYMMDD')
	) t_saldo
		ON t_users.user_id = t_saldo.user_id
	LEFT JOIN (
		SELECT
			user_id,
			MIN(pay_date) AS cession_date
		FROM edw_ods.t_000087_t_payments
		WHERE pay_doc_id = 1075
			AND tech_dt >= DATE_TRUNC('YEAR', TO_DATE(SUBSTR('20190630', 1, 8), 'YYYYMMDD')) - INTERVAL '12 MONTHS'
		GROUP BY user_id
	) cession
		ON t_users.user_id = cession.user_id
	INNER JOIN edw_ods.t_000087_t_user_type_ref t_user_type_ref
		ON ROUND(t_user_type_ref.user_type_id) = ROUND(t_users.user_type_id)
		AND t_user_type_ref.deleted_ind = 0
		AND t_user_type_ref.eff_dttm <= TO_DATE('20190630', 'YYYYMMDD')
	    AND t_user_type_ref.exp_dttm >= TO_DATE('20190630', 'YYYYMMDD')
	LEFT JOIN (
		SELECT
			ROUND(sp.user_id_sp) AS user_id_sp,
			ROUND(v.user_id_vip) AS user_id_vip,
			(ROUND(sp.dept_id_vip))::VARCHAR AS dept_id_vip,
			CASE
				WHEN COALESCE(date_begin, TO_DATE('19000101', 'YYYYMMDD')) = MIN(COALESCE(date_begin, TO_DATE('19000101', 'YYYYMMDD'))) OVER (PARTITION BY v.user_id_sp)
				THEN TO_DATE('19000101', 'YYYYMMDD')
				ELSE COALESCE(date_begin, TO_DATE('19000101', 'YYYYMMDD'))
			END AS date_begin_v2,
			CASE
				WHEN COALESCE(date_end, TO_DATE('29991231', 'YYYYMMDD')) = MAX(COALESCE(date_end, TO_DATE('29991231', 'YYYYMMDD'))) OVER (PARTITION BY v.user_id_sp)
				THEN TO_DATE('29991231', 'YYYYMMDD')
				ELSE COALESCE(date_end, TO_DATE('29991231', 'YYYYMMDD'))
			END AS date_end_v2
		FROM edw_ods.t_000087_t_vip_sp sp
		INNER JOIN edw_ods.t_000087_t_vip v
			ON sp.user_id_sp = v.user_id_sp
			AND v.deleted_ind = 0
			AND v.eff_dttm <= TO_DATE('20190630', 'YYYYMMDD')
	        AND v.exp_dttm >= TO_DATE('20190630', 'YYYYMMDD')
		WHERE sp.deleted_ind = 0
			AND sp.eff_dttm <= TO_DATE('20190630', 'YYYYMMDD')
			AND sp.exp_dttm >= TO_DATE('20190630', 'YYYYMMDD')
	) t_vip_sp
		ON ROUND(t_users.user_id) = t_vip_sp.user_id_sp
		AND TO_DATE((ROUND(t_saldo.billing_id))::VARCHAR, 'YYYYMM') BETWEEN date_begin_v2 AND date_end_v2
	LEFT JOIN edw_dds.hub_dim_branch hub
		ON t_vip_sp.dept_id_vip = hub.source_key
		AND t_users.src_id = hub.src_id
		AND hub.eff_dttm <= TO_DATE('20190630', 'YYYYMMDD')
	    AND hub.exp_dttm >= TO_DATE('20190630', 'YYYYMMDD')
	LEFT JOIN edw_stg_dds.T_000087_PRE_TTR_SIBIR_START ttr
		ON ttr.user_id = t_vip_sp.user_id_vip
		AND ttr.branch_key = hub.branch_key::TEXT
		AND ttr.billing_id = t_saldo.billing_id
	WHERE t_users.eff_dttm <= TO_DATE('20190630', 'YYYYMMDD')
		AND t_users.exp_dttm >= TO_DATE('20190630', 'YYYYMMDD')
		AND t_users.deleted_ind = 0
) s;
COMMIT;

ANALYSE edw_stg_dds.t_000087_dim_account;

TRUNCATE TABLE edw_stg_dds.T_000087_PRE_TTR_SIBIR_START;
