/*rev. 23089*/SET search_path = edw_stg_dmcm;
SET optimizer = OFF;


TRUNCATE TABLE edw_stg_dmcm.pre_ota_dim_address_stg_1_PRT_P000153;
INSERT INTO edw_stg_dmcm.pre_ota_dim_address_stg_1_PRT_P000153 (
  mrf_id,
  rf_id,
  account,
  city,
  address,
  src_id
)
  SELECT
    coalesce ( adr.mrf_id, subs.mrf_id )   AS mrf_id,
    coalesce ( adr.rf_id, subs.rf_id )     AS rf_id,
    coalesce ( adr.account, subs.account ) AS account,
    coalesce ( subs.city, adr.city )       AS city,
    CASE WHEN subs.city IS NOT NULL
      THEN subs.address
    ELSE adr.address
    END                                    AS address,
    153 as src_id
  FROM (
         SELECT
           /*+ NoNestLoop(q, ad1, sa)*/
           q.mrf_id,
           q.rf_id,
           CASE WHEN q.mrf_id = 14
             THEN sa.nls
           ELSE q.account
           END                                                     AS account,
           ad1.city                                                AS city,
           ad1.address || CASE WHEN q.flat IS NULL
             THEN ''
                          ELSE ', ' END || coalesce ( q.flat, '' ) AS address,
           row_number ( )
           OVER (
             PARTITION BY
               CASE WHEN q.mrf_id = 14
                 THEN sa.nls
               ELSE q.account
               END,
               q.mrf_id,
               q.rf_id
             ORDER BY ad1.city, ad1.address || CASE WHEN q.flat IS NULL
               THEN ''
                                               ELSE ', ' END || coalesce ( q.flat, '' )
             )                                                        rn
         FROM (
                SELECT
                  ad1.mrf_id,
                  ad1.rf_id,
                  ad1.account,
                  ad1.house_lid,
                  ad1.flat
                FROM edw_ods.T_000153_RPRT_OO_ADDRESSABNDWH ad1
              ) q
           LEFT JOIN (
                       SELECT
                         ad1.city,
                         ad1.mrf_id,
                         ad1.house_lid,
                         ad1.POSTOFFICE_ID || CASE WHEN ad1.POSTOFFICE_ID IS NOT NULL
                           THEN ', '
                                              ELSE '' END
                         || ad1.TERR_TYPE || CASE WHEN ad1.TERR_TYPE IS NOT NULL
                           THEN ' '
                                             ELSE '' END
                         || ad1.NAME_TERR || CASE WHEN coalesce ( ad1.TERR_TYPE, ad1.NAME_TERR ) IS NOT NULL
                           THEN ', '
                                             ELSE '' END
                         || ad1.CITY || CASE WHEN CITY IS NOT NULL
                           THEN ', '
                                        ELSE '' END
                         || ad1.NAME_STREET_TYPE || CASE WHEN ad1.NAME_STREET_TYPE IS NOT NULL
                           THEN ' '
                                                    ELSE '' END
                         || ad1.NAME_STREET || CASE WHEN coalesce ( ad1.NAME_STREET_TYPE, ad1.NAME_STREET ) IS NOT NULL
                           THEN ', '
                                               ELSE '' END
                         || ad1.HOUSE AS address
                       FROM edw_ods.T_000153_RPRT_OO_ADDRESS ad1
                     ) ad1
             ON q.mrf_id = ad1.mrf_id
                AND q.house_lid = ad1.house_lid
                LEFT JOIN (
                  SELECT
                    mrf_id,
                    nls,
                    account,
                    row_number ()
                      OVER (
                      PARTITION BY account
                      ORDER BY COALESCE(date_end, to_date('2999-12-31', 'yyyy-mm-dd')) DESC, date_begin DESC ) rn
                  FROM edw_ods.T_000158_EFFTP_SOUTH_NLS_ACCNT
                ) sa
                  ON sa.mrf_id = 14
                  AND sa.account = q.account
                  AND sa.rn = 1
       ) adr
    FULL JOIN (
                SELECT
                  /*+ NoNestLoop(subs_act, sa)*/
                  subs_act.mrf_id,
                  subs_act.rf_id,
                  CASE WHEN subs_act.mrf_id = 14
                    THEN sa.nls
                  ELSE subs_act.account
                  END                AS account,
                  subs_act.city_name AS city,
                  subs_act.adress    AS address,
                  row_number ( )
                  OVER (
                    PARTITION BY
                      CASE WHEN subs_act.mrf_id = 14
                        THEN sa.nls
                      ELSE subs_act.account
                      END,
                      subs_act.mrf_id,
                      subs_act.rf_id
                    ORDER BY subs_act.city_name, subs_act.adress
                    )                   rn
                FROM edw_ods.T_000153_RPRTSUBSCRIBERSACTUAL subs_act
                  LEFT JOIN (
					SELECT
						mrf_id,
						nls,
						account,
						row_number ()
							OVER (
							PARTITION BY account
							ORDER BY COALESCE(date_end, to_date('2999-12-31', 'yyyy-mm-dd')) DESC, date_begin DESC ) rn
					FROM edw_ods.T_000158_EFFTP_SOUTH_NLS_ACCNT
				) sa
					ON sa.mrf_id = 14
					AND sa.account = subs_act.account
					AND sa.rn = 1
                WHERE coalesce ( subs_act.data_close_serv, to_date ( '2999-12-31', 'yyyy-mm-dd' ) ) =
                      to_date ( '2999-12-31', 'yyyy-mm-dd' )
                      AND
                      coalesce ( subs_act.data_close, to_date ( '2999-12-31', 'yyyy-mm-dd' ) ) =
                      to_date ( '2999-12-31', 'yyyy-mm-dd' )
                      AND city_name != '6666666666666666'
              ) subs
      ON subs.account = adr.account
         AND subs.mrf_id = adr.mrf_id
         AND subs.rf_id = adr.rf_id
  WHERE adr.rn = 1
        AND subs.rn = 1;
ANALYSE edw_stg_dmcm.pre_ota_dim_address_stg_1_PRT_P000153;


SET optimizer = ON;

TRUNCATE TABLE edw_stg_dmcm.pre_ota_dim_account_snap_1_PRT_P000153;
INSERT INTO edw_stg_dmcm.pre_ota_dim_account_snap_1_PRT_P000153 (account_key, parent_account_key, partner_key, branch_key, duty_num_key, center_num_key, agent_scheme_key
  , address_key, payment_type_key, account_name, start_date, end_date, src_id)
  SELECT
    account_key,
    parent_account_key,
    partner_key,
    branch_key,
    duty_num_key,
    center_num_key,
    agent_scheme_key,
    address_key,
    payment_type_key,
    account_name,
    start_date,
    end_date,
    153
  FROM (
         SELECT
           account_key,
           parent_account_key,
           partner_key,
           branch_key,
           duty_num_key,
           center_num_key,
           agent_scheme_key,
           address_key,
           payment_type_key,
           account_name,
           start_date,
           end_date,
           row_number ( )
           OVER (
             PARTITION BY account_key
             ORDER BY eff_dttm DESC, exp_dttm
             ) AS rn
         FROM edw_dds.dim_account
               WHERE
             case when 153 = 151 then src_id between 48 and 62
             when 153 = 152 then src_id = 97
             when 153 = 153 then src_id between 1 and 12
             when 153 = 154 then src_id between 27 and 39
             when 153 = 155 then src_id = 45
             when 153 = 156 then src_id between 80 and 88
             when 153 = 157 then src_id between 107 and 113
            end
       ) tbl
  WHERE rn = 1;
ANALYSE edw_stg_dmcm.pre_ota_dim_account_snap_1_PRT_P000153;



TRUNCATE TABLE edw_stg_dmcm.PRE_OTA_CHARGE_MIN_DATE_STG_1_PRT_P000153;
INSERT INTO edw_stg_dmcm.PRE_OTA_CHARGE_MIN_DATE_STG_1_PRT_P000153 (account, min_date_ota, src_id)
  SELECT
    account,
    MIN ( DATE_CHARGE ) AS date_start,
    153
  FROM edw_ods.T_000153_RPRT_CHARGES_DWH
  WHERE CHARGE_CODE IN
        ( 'R0401011011', 'R0401011012', 'R0401011031', 'R0401011032', 'R0401011033', 'R0401011034', 'R0401011035',
                         'R0401011041', 'R0401011042', 'R0401011043', 'R0401011044', 'R0401011045', 'R0401011046', 'R0401011047',
                                                                                     'R0401011048', 'R040101199', 'R0401012', 'R0401021011', 'R0401021012', 'R0401021031', 'R0401021032',
          'R0401021033', 'R0401021034', 'R0401021035', 'R0401021041', 'R0401021042', 'R0401021043', 'R0401021044',
          'R0401021045', 'R0401021046', 'R0401021047', 'R0401021048', 'R040102199' )
        OR substr ( CHARGE_CODE, 1, 5 ) IN ( 'R0101', 'R0201', 'R0301' )
  GROUP BY account;
ANALYSE edw_stg_dmcm.PRE_OTA_CHARGE_MIN_DATE_STG_1_PRT_P000153;



TRUNCATE TABLE edw_stg_dmcm.PRE_OTA_CHARGE_STG_1_PRT_P000153;
INSERT INTO edw_stg_dmcm.PRE_OTA_CHARGE_STG_1_PRT_P000153 (account_name, date_snap, charge_ota_abon, charge_ota_m, charge_ota_vz, charge_ota_mg, charge_ota_mn, RF_ID, date_start, src_id)
  SELECT
    chg.account_name,
    chg.date_snap,
    sum ( chg.charge_ota_abon ) AS charge_ota_abon,
    sum ( chg.charge_ota_m )    AS charge_ota_m,
    sum ( chg.charge_ota_vz )   AS charge_ota_vz,
    sum ( chg.charge_ota_mg )   AS charge_ota_mg,
    sum ( chg.charge_ota_mn )   AS charge_ota_mn,
    chg.RF_ID,
    chg_min.min_date_ota,
    153
  FROM (
		SELECT
		  coalesce ( CASE WHEN sa.mrf_id = 14 THEN sa.nls ELSE chrg.account END, '' )   AS account_name,
                    coalesce ( chrg.rf_id, 0 )               AS rf_id,
                  ( date_trunc ( 'MONTH', period :: DATE ) + INTERVAL '1 MONTH - 1 day' ) :: DATE AS date_snap,
                 sum (
                        CASE WHEN CHARGE_CODE IN ( 'R0401011031', 'R0401011032', 'R0401011034', 'R0401021031', 'R0401021032', 'R0401021034', 'R0401021041', 'R0401021042', 'R0401021044', 'R0401011046', 'R0401021046' )
                          THEN charge - chrg.vat_amount
                        ELSE 0
                        END
                      )                                        AS charge_ota_abon,
                      sum (
                        CASE WHEN CHARGE_CODE IN (
                          'R0401011011', 'R0401011012', 'R0401011031', 'R0401011032', 'R0401011033', 'R0401011034', 'R0401011035',
                                         'R0401011041', 'R0401011042', 'R0401011043', 'R0401011044', 'R0401011045', 'R0401011046', 'R0401011047',
                                                                                                     'R0401011048', 'R040101199', 'R0401012', 'R0401021011', 'R0401021012', 'R0401021031', 'R0401021032',
                          'R0401021033', 'R0401021034', 'R0401021035', 'R0401021041', 'R0401021042', 'R0401021043', 'R0401021044',
                          'R0401021045', 'R0401021046', 'R0401021047', 'R0401021048', 'R040102199' )
                          THEN charge - chrg.vat_amount
                        ELSE 0
                        END
                      )                                        AS charge_ota_m,
                      sum (
                        CASE substr ( CHARGE_CODE, 1, 5 )
                        WHEN 'R0301'
                          THEN charge - chrg.vat_amount
                        ELSE 0
                        END
                      )                                        AS charge_ota_vz,
                      sum (
                        CASE substr ( CHARGE_CODE, 1, 5 )
                        WHEN 'R0101'
                          THEN charge - chrg.vat_amount
                        ELSE 0
                        END
                      )                                        AS charge_ota_mg,
                      sum (
                        CASE substr ( CHARGE_CODE, 1, 5 )
                        WHEN 'R0201'
                          THEN charge - chrg.vat_amount
                        ELSE 0
                        END
                      )                                        AS charge_ota_mn,
                     153 as src_id
                FROM edw_ods.T_000153_RPRT_CHARGES_DWH  chrg
                  LEFT JOIN (
                    SELECT
                      mrf_id,
                      nls,
                      account,
                      row_number ()
                        OVER (
                        PARTITION BY account
                        ORDER BY COALESCE(date_end, to_date('2999-12-31', 'yyyy-mm-dd')) DESC, date_begin DESC ) rn
                    FROM edw_ods.T_000158_EFFTP_SOUTH_NLS_ACCNT
                  ) sa
                    ON sa.mrf_id = 14
                    AND sa.account = chrg.account
		AND sa.rn = 1
                WHERE ( date_trunc ( 'MONTH', period :: DATE )
                        + INTERVAL '1 MONTH - 1 day' ) :: DATE >= to_date ( '20190601', 'YYYYMMDD' ) AND
                      ( date_trunc ( 'MONTH', period :: DATE )
                        + INTERVAL '1 MONTH - 1 day' ) :: DATE <= to_date ( '20190630', 'YYYYMMDD' )
                      AND chrg.coef_r12 = 1
                    GROUP BY
                          coalesce ( CASE WHEN sa.mrf_id = 14 THEN sa.nls ELSE chrg.account END, '' ),
                          coalesce ( chrg.rf_id, 0 ),
                          ( date_trunc ( 'MONTH', period :: DATE ) + INTERVAL '1 MONTH - 1 day' ) :: DATE
                        ) chg
    LEFT JOIN edw_stg_dmcm.PRE_OTA_CHARGE_MIN_DATE_STG_1_PRT_P000153 chg_min
      ON chg_min.account = chg.account_name
  GROUP BY chg.account_name,
    chg.date_snap,
    chg.RF_ID,
    chg_min.min_date_ota;
ANALYSE edw_stg_dmcm.PRE_OTA_CHARGE_STG_1_PRT_P000153;



TRUNCATE TABLE edw_stg_dmcm.PRE_OTA_TRAFIC_STG_1_PRT_P000153;
INSERT INTO edw_stg_dmcm.PRE_OTA_TRAFIC_STG_1_PRT_P000153 (ACCOUNT_KEY, CALL_START_DTTM, NUM_B, CALL_DUR_ACTUALLY_NVAL, SERVICE_KEY, DATE_SNAP, BUSINESS_SERVICE_KEY, RN, src_id)
  SELECT
    tel.account_key,
    tel.CALL_START_DTTM,
    tel.NUM_B,
    tel.CALL_DUR_ACTUALLY_NVAL,
    tel.SERVICE_KEY,
    date_trunc ( 'MONTH', tel.call_start_dttm :: DATE ) + INTERVAL '1 MONTH - 1 day' AS date_snap,
    s.business_service_key,
    row_number ( )
    OVER (
      PARTITION BY account_key, date_trunc ( 'MONTH', tel.call_start_dttm :: DATE ) + INTERVAL '1 MONTH - 1 day'
      ORDER BY tel.call_start_dttm DESC )                                            AS rn,
    153
  FROM edw_dds.tfct_telephony_consumption tel
    LEFT JOIN edw_dds.dim_service s
      ON tel.service_key = s.service_key
         AND tel.call_start_dttm BETWEEN s.eff_dttm AND s.exp_dttm
  WHERE call_start_dttm BETWEEN to_date ( '20190601', 'YYYYMMDD' ) AND to_date ( '20190630', 'YYYYMMDD' )
        AND tel.deleted_ind = 0
        AND s.business_service_key IN
            (
              10103--Междугородная связь
              , 10104--Международная связь
              -- , 10401--IP-TV
              , 10101--Местная связь
              , 10102--Внутризоновая связь
            )
        AND case when 153 = 151 then tel.src_id between 48 and 62
            when 153 = 152 then tel.src_id = 97
            when 153 = 153 then tel.src_id between 1 and 12
            when 153 = 154 then tel.src_id between 27 and 39
            when 153 = 155 then tel.src_id = 45
            when 153 = 156 then tel.src_id between 80 and 88
            when 153 = 157 then tel.src_id between 107 and 113
           end;
ANALYSE edw_stg_dmcm.PRE_OTA_TRAFIC_STG_1_PRT_P000153;



TRUNCATE TABLE edw_stg_dmcm.pre_ota_traffic_min_date_stg_1_PRT_P000153;
INSERT INTO edw_stg_dmcm.pre_ota_traffic_min_date_stg_1_PRT_P000153 (account_key, min_date_ota, src_id)
  SELECT
    account_key,
    MIN ( call_start_dttm ) AS min_date_ota,
    153
  FROM edw_dds.tfct_telephony_consumption
    where
       case when 153 = 151 then src_id between 48 and 62
        when 153 = 152 then src_id = 97
        when 153 = 153 then src_id between 1 and 12
        when 153 = 154 then src_id between 27 and 39
        when 153 = 155 then src_id = 45
        when 153 = 156 then src_id between 80 and 88
        when 153 = 157 then src_id between 107 and 113
       end
  GROUP BY account_key;
ANALYSE edw_stg_dmcm.pre_ota_traffic_min_date_stg_1_PRT_P000153;


SET optimizer = ON;
TRUNCATE TABLE edw_stg_dmcm.PRE_OTA_TRAFIC_AGG_STG_1_PRT_P000153;
INSERT INTO edw_stg_dmcm.PRE_OTA_TRAFIC_AGG_STG_1_PRT_P000153 (account_name, date_snap, min_date_ota, max_date_ota, tr_out_m_fix_rtk, tr_out_vz_fix_rtk,
                                                    tr_out_mg_fix_rtk, tr_out_m_fix, tr_out_vz_fix, tr_out_mg_fix, tr_out_m_mob_rtk, tr_out_vz_mob_rtk, tr_out_mg_mob_rtk,
                                                    tr_out_m_mob, tr_out_vz_mob, tr_out_mg_mob, tr_out_mn, cnt_out_m, cnt_out_vz, cnt_out_mg, cnt_out_mn, src_id)
  SELECT
    acc.account_name,
    tel.date_snap,
    min ( tel_min.min_date_ota )           AS min_date_ota,
    to_date ( '1000-01-01', 'YYYY-MM-DD' ) AS max_date_ota,
    0                                      AS tr_out_m_fix_rtk,
    0                                      AS tr_out_vz_fix_rtk,
    0                                      AS tr_out_mg_fix_rtk,
    sum (
      CASE
      WHEN tel.business_service_key = 10101--Местная связь
           AND NOT ( ( substr ( num_b, 1, 3 ) = '+79' )
                     OR ( substr ( num_b, 1, 2 ) = '79' )
                     OR ( substr ( num_b, 1, 2 ) = '89' )
                     OR ( substr ( num_b, 1, 1 ) = '9' ) )
           AND length ( num_b ) <= 12
        THEN call_dur_actually_nval
      ELSE 0
      END
    )                                      AS tr_out_m_fix,
    sum (
      CASE WHEN tel.business_service_key = 10102
                AND NOT ( ( substr ( num_b, 1, 3 ) = '+79' )
                          OR ( substr ( num_b, 1, 2 ) = '79' )
                          OR ( substr ( num_b, 1, 2 ) = '89' )
                          OR ( substr ( num_b, 1, 1 ) = '9' ) )
                AND length ( num_b ) <= 12
        THEN call_dur_actually_nval
      ELSE 0
      END
    )                                      AS tr_out_vz_fix,
    sum (
      CASE WHEN tel.business_service_key = 10103
                AND NOT ( ( substr ( num_b, 1, 3 ) = '+79' )
                          OR ( substr ( num_b, 1, 2 ) = '79' )
                          OR ( substr ( num_b, 1, 2 ) = '89' )
                          OR ( substr ( num_b, 1, 1 ) = '9' ) )
                AND length ( num_b ) <= 12
        THEN call_dur_actually_nval
      ELSE 0
      END
    )                                      AS tr_out_mg_fix,
    0                                      AS tr_out_m_mob_rtk,
    0                                      AS tr_out_vz_mob_rtk,
    0                                      AS tr_out_mg_mob_rtk,
    sum (
      CASE WHEN tel.business_service_key = 10101
                AND ( ( substr ( num_b, 1, 3 ) = '+79' )
                      OR ( substr ( num_b, 1, 2 ) = '79' )
                      OR ( substr ( num_b, 1, 2 ) = '89' )
                      OR ( substr ( num_b, 1, 1 ) = '9' ) )
                AND length ( num_b ) <= 12
        THEN call_dur_actually_nval
      ELSE 0
      END
    )                                      AS tr_out_m_mob,
    sum (
      CASE WHEN tel.business_service_key = 10102
                AND ( ( substr ( num_b, 1, 3 ) = '+79' )
                      OR ( substr ( num_b, 1, 2 ) = '79' )
                      OR ( substr ( num_b, 1, 2 ) = '89' )
                      OR ( substr ( num_b, 1, 1 ) = '9' ) )
                AND length ( num_b ) <= 12
        THEN call_dur_actually_nval
      ELSE 0
      END
    )                                      AS tr_out_vz_mob,
    sum (
      CASE WHEN tel.business_service_key = 10103
                AND ( ( substr ( num_b, 1, 3 ) = '+79' )
                      OR ( substr ( num_b, 1, 2 ) = '79' )
                      OR ( substr ( num_b, 1, 2 ) = '89' )
                      OR ( substr ( num_b, 1, 1 ) = '9' ) )
                AND length ( num_b ) <= 12
        THEN call_dur_actually_nval
      ELSE 0
      END
    )                                      AS tr_out_mg_mob,
    sum (
      CASE tel.business_service_key
      WHEN 10104
        THEN call_dur_actually_nval
      ELSE 0
      END
    )                                      AS tr_out_mn,
    sum (
      CASE WHEN ( tel.business_service_key = 10101
                  AND length ( num_b ) <= 12 )
        THEN 1
      ELSE 0
      END
    )                                      AS cnt_out_m,
    sum (
      CASE WHEN ( tel.business_service_key = 10102
                  AND length ( num_b ) <= 12 )
        THEN 1
      ELSE 0
      END
    )                                      AS cnt_out_vz,
    sum (
      CASE WHEN ( tel.business_service_key = 10103
                  AND length ( num_b ) <= 12 )
        THEN 1
      ELSE 0
      END
    )                                      AS cnt_out_mg,
    sum (
      CASE tel.business_service_key
      WHEN 10104
        THEN 1
      ELSE 0
      END
    )                                      AS cnt_out_mn,
    153
  FROM edw_stg_dmcm.PRE_OTA_TRAFIC_STG_1_PRT_P000153 tel
    LEFT JOIN edw_stg_dmcm.pre_ota_traffic_min_date_stg_1_PRT_P000153 tel_min
      ON tel_min.account_key = tel.account_key
    LEFT JOIN (
	  SELECT
		account_key,
		account_name,
		row_number ( )
		OVER (
		  PARTITION BY account_key
		  ORDER BY start_date DESC, end_date DESC ) AS actual_account_key
	  FROM edw_dds.dim_account
	  WHERE
		CASE WHEN 153 = 151
		  THEN src_id BETWEEN 48 AND 62
		WHEN 153 = 152
		  THEN src_id = 97
		WHEN 153 = 153
		  THEN src_id BETWEEN 1 AND 12
		WHEN 153 = 154
		  THEN src_id BETWEEN 27 AND 39
		WHEN 153 = 155
		  THEN src_id = 45
		WHEN 153 = 156
		  THEN src_id BETWEEN 80 AND 88
		WHEN 153 = 157
		  THEN src_id BETWEEN 107 AND 113
		END
	) acc
		ON tel.account_key = acc.account_key
		AND acc.actual_account_key = 1
  WHERE call_start_dttm BETWEEN to_date ( '20190601', 'YYYYMMDD' ) AND to_date ( '20190630', 'YYYYMMDD' )
        AND tel.business_service_key IN
            (
              10103--Междугородная связь
              , 10104--Международная связь
              , 10101--Местная связь
              , 10102--Внутризоновая связь
            )
  GROUP BY tel.date_snap,
    acc.account_name;

ANALYSE edw_stg_dmcm.PRE_OTA_TRAFIC_AGG_STG_1_PRT_P000153;


TRUNCATE TABLE edw_stg_dmcm.pre_ota_stg_1_PRT_P000153;
SET optimizer = ON;
INSERT INTO edw_stg_dmcm.pre_ota_stg_1_PRT_P000153 (account_key, year_month_key, date_snap, account, charge_ota_abon, charge_ota_m, charge_ota_vz, charge_ota_mg, charge_ota_mn, min_date_ota, max_date_ota
  , tr_out_m_fix_rtk, tr_out_vz_fix_rtk, tr_out_mg_fix_rtk, tr_out_m_fix, tr_out_vz_fix, tr_out_mg_fix, tr_out_m_mob_rtk, tr_out_vz_mob_rtk, tr_out_mg_mob_rtk, tr_out_m_mob
  , tr_out_vz_mob, tr_out_mg_mob, tr_out_mn, cnt_out_m, cnt_out_vz, cnt_out_mg, cnt_out_mn, rf_id, src_id)
  SELECT
    0                  AS account_key,
    to_char ( coalesce ( tel.date_snap, chg.date_snap ), 'YYYYMM' )      AS year_month_key,
    coalesce ( tel.date_snap, chg.date_snap, '1000-01-01' ) :: TIMESTAMP AS date_snap,
    coalesce ( tel.account_name, chg.account_name, 'Не определено' )     AS account,
    chg.charge_ota_abon                                                  AS charge_ota_abon,
    chg.charge_ota_m                                                     AS charge_ota_m,
    chg.charge_ota_vz                                                    AS charge_ota_vz,
    chg.charge_ota_mg                                                    AS charge_ota_mg,
    chg.charge_ota_mn                                                    AS charge_ota_mn,
    CASE WHEN chg.date_start IS NOT NULL
      THEN
        CASE WHEN tel.min_date_ota IS NOT NULL
          THEN
            CASE WHEN chg.date_start < tel.min_date_ota
              THEN chg.date_start
            ELSE tel.min_date_ota
            END
        ELSE chg.date_start
        END
    ELSE
      CASE WHEN tel.min_date_ota IS NOT NULL
        THEN tel.min_date_ota
      ELSE '2017-01-01 01:00:00' :: TIMESTAMP
      END
    END                                                                  AS min_date_ota,
    tel.max_date_ota,
    tel.tr_out_m_fix_rtk,
    tel.tr_out_vz_fix_rtk,
    tel.tr_out_mg_fix_rtk,
    tel.tr_out_m_fix,
    tel.tr_out_vz_fix,
    tel.tr_out_mg_fix,
    tel.tr_out_m_mob_rtk,
    tel.tr_out_vz_mob_rtk,
    tel.tr_out_mg_mob_rtk,
    tel.tr_out_m_mob,
    tel.tr_out_vz_mob,
    tel.tr_out_mg_mob,
    tel.tr_out_mn,
    tel.cnt_out_m,
    tel.cnt_out_vz,
    tel.cnt_out_mg,
    tel.cnt_out_mn,
    chg.rf_id,
    153

  FROM edw_stg_dmcm.PRE_OTA_TRAFIC_AGG_STG_1_PRT_P000153 tel

  FULL OUTER JOIN edw_stg_dmcm.PRE_OTA_CHARGE_STG_1_PRT_P000153 chg
		ON chg.account_name = tel.account_name
        AND chg.date_snap = tel.date_snap
  WHERE
    coalesce ( tel.date_snap, chg.date_snap, '1000-01-01' ) BETWEEN to_date ( '20190601', 'YYYYMMDD' ) AND to_date (
      '20190630', 'YYYYMMDD' );
ANALYSE edw_stg_dmcm.pre_ota_stg_1_PRT_P000153;


-- INN, id_rf, account, period, tp_start, rtpl_name, date_snap, src_id
TRUNCATE TABLE edw_stg_dmcm.tfct_ota_1_PRT_P000153;
SET optimizer = ON;
INSERT INTO edw_stg_dmcm.tfct_ota_1_PRT_P000153 (inn, account_key, period, date_snap, account, client_name, rtpl_name, tp_start, charge_ota_abon, charge_ota_m,
                                      charge_ota_vz, charge_ota_mg, charge_ota_mn, min_date_ota, max_date_ota, tr_out_m_fix_rtk, tr_out_vz_fix_rtk,
                                      tr_out_mg_fix_rtk, tr_out_m_fix, tr_out_vz_fix, tr_out_mg_fix, tr_out_m_mob_rtk, tr_out_vz_mob_rtk,
                                      tr_out_mg_mob_rtk, tr_out_m_mob, tr_out_vz_mob, tr_out_mg_mob, tr_out_mn, cnt_out_m, cnt_out_vz, cnt_out_mg,
                                      cnt_out_mn, id_macro_segment, addr_city, k_code, id_rf, name_microsegment, rf, mrf, src_id)
  select inn, max(account_key), period, date_snap, account, max(client_name), rtpl_name, max(tp_start), max(charge_ota_abon), max(charge_ota_m),
                                      max(charge_ota_vz), max(charge_ota_mg), max(charge_ota_mn), max(min_date_ota), max(max_date_ota), max(tr_out_m_fix_rtk), max(tr_out_vz_fix_rtk),
                                      max(tr_out_mg_fix_rtk), max(tr_out_m_fix), max(tr_out_vz_fix), max(tr_out_mg_fix), max(tr_out_m_mob_rtk), max(tr_out_vz_mob_rtk),
                                      max(tr_out_mg_mob_rtk), max(tr_out_m_mob), max(tr_out_vz_mob), max(tr_out_mg_mob), max(tr_out_mn), max(cnt_out_m), max(cnt_out_vz), max(cnt_out_mg),
                                      max(cnt_out_mn), max(id_macro_segment), max(addr_city), max(k_code), id_rf, max(name_microsegment), max(rf), max(mrf), src_id from (
  SELECT
    coalesce (
      CASE
      WHEN cl.inn IN
           ( '-', '0', '00', '000', '0000', '-000', '-0000', '00000', '-00000', '000000', '0000000', '000000000', '0000000000' )
        THEN NULL
      ELSE cl.inn END, ''
    )                                                AS inn,
    pre.account_key,
    pre.year_month_key AS period,
    pre.date_snap,
    pre.account,
    cl.contr_name                                    AS client_name,
    coalesce ( cd.RTPL_NAME, 'Не определено' )       AS RTPL_NAME,
    cd.tp_start,
    pre.charge_ota_abon                              AS charge_ota_abon,
    pre.charge_ota_m                                 AS charge_ota_m,
    pre.charge_ota_vz                                AS charge_ota_vz,
    pre.charge_ota_mg                                AS charge_ota_mg,
    pre.charge_ota_mn                                AS charge_ota_mn,
    pre.min_date_ota,
    pre.max_date_ota,
    pre.tr_out_m_fix_rtk,
    pre.tr_out_vz_fix_rtk,
    pre.tr_out_mg_fix_rtk,
    pre.tr_out_m_fix,
    pre.tr_out_vz_fix,
    pre.tr_out_mg_fix,
    pre.tr_out_m_mob_rtk,
    pre.tr_out_vz_mob_rtk,
    pre.tr_out_mg_mob_rtk,
    pre.tr_out_m_mob,
    pre.tr_out_vz_mob,
    pre.tr_out_mg_mob,
    pre.tr_out_mn,
    pre.cnt_out_m,
    pre.cnt_out_vz,
    pre.cnt_out_mg,
    pre.cnt_out_mn,
    cl.id_macro_segment_ud                           AS id_macro_segment,
    adr.city                                         AS addr_city,
    nm.macro_segment                                 AS k_code,
    coalesce ( br2.branch_key, br.branch_key )       AS id_rf,
    nm.name_microsegment,
    coalesce ( br2.branch_name, br.branch_name, '' ) AS rf,
    coalesce (
		CASE WHEN br2.parent_branch_key = -1
            THEN br2.branch_name
            ELSE br_par2.branch_name
        END,
		CASE WHEN br.parent_branch_key = -1
			THEN br.branch_name
            ELSE br_par.branch_name
               END, '' )                             AS mrf,
    153 as src_id

  FROM edw_stg_dmcm.pre_ota_stg_1_PRT_P000153 pre

    LEFT JOIN (
                SELECT
                  account_                                                       AS account,
                  coalesce ( sss.rf_id, sss.rf_id_ )                             AS rf_id,
                  coalesce ( sss.id_macro_segment_ud, sss.id_macro_segment_ud_ ) AS id_macro_segment_ud,
                  coalesce ( sss.inn, sss.inn_ )                                 AS inn,
                  coalesce ( sss.contr_name, sss.contr_name_ )                   AS contr_name

                FROM (
                       SELECT
                         c.rf_id,
                         c.id_macro_segment_ud,
                         c.inn,
                         c.contr_name,
                         CASE WHEN sa.mrf_id = 14
                           THEN sa.nls
                         ELSE c.account END                        AS account_,
                         min ( c.rf_id )
                         OVER (
                           PARTITION BY CASE WHEN sa.mrf_id = 14
                             THEN sa.nls
                                        ELSE c.account END )       AS rf_id_,
                         min ( id_macro_segment_ud )
                         OVER (
                           PARTITION BY CASE WHEN sa.mrf_id = 14
                             THEN sa.nls
                                        ELSE c.account END )       AS id_macro_segment_ud_,
                         min ( inn )
                         OVER (
                           PARTITION BY CASE WHEN sa.mrf_id = 14
                             THEN sa.nls
                                        ELSE c.account END )       AS inn_,
                         min ( contr_name )
                         OVER (
                           PARTITION BY CASE WHEN sa.mrf_id = 14
                             THEN sa.nls
                                        ELSE c.account END )       AS contr_name_,
                         row_number ( )
                         OVER (
                           PARTITION BY CASE WHEN sa.mrf_id = 14
                             THEN sa.nls
                                        ELSE c.account END
                           ORDER BY CASE WHEN C.date_snap <= to_date ( '20190630', 'YYYYMMDD' )
                             THEN 0
                                    ELSE 1 END, C.date_snap DESC ) AS rn
                       FROM edw_ods.T_000153_RPRT_CLIENT_DWH C
                       LEFT JOIN (
                       SELECT
                       mrf_id,
                       nls,
                       account,
                       row_number ( )
                       OVER (
                       PARTITION BY account
                       ORDER BY COALESCE(date_end, to_date('2999-12-31', 'yyyy-mm-dd')) DESC, date_begin DESC ) rn
                                                  FROM edw_ods.T_000158_EFFTP_SOUTH_NLS_ACCNT
                                 ) sa
                                   ON sa.mrf_id = 14
                                   AND sa.account = c.account
                                          AND sa.rn = 1
                     ) sss
                WHERE sss.rn = 1 ) cl

      ON pre.account = cl.account

    LEFT JOIN (
                SELECT
                  account_                                     AS ACCOUNT,
                  coalesce ( tbl.SPEED, tbl.SPEED_ )           AS SPEED,
                  COALESCE ( tbl.rtpl_name, tbl.rtpl_name_ )   AS rtpl_name,
                  coalesce ( tbl.tech_id, tbl.tech_id_ )       AS TECH_ID,
                  coalesce ( tbl.START_RTPL, tbl.START_RTPL_ ) AS tp_start,
                  coalesce ( BASE_SRC_ID, 0 )                  AS base_src_id,
                  coalesce ( LOG_ID, 0 )                       AS log_id
                FROM
                  (
                    SELECT
                      v.START_RTPL,
                      v.tech_id,
                      v.SPEED,
                      v.rtpl_name,
                      v.BASE_SRC_ID,
                      v.LOG_ID,
                      CASE WHEN sa.mrf_id = 14
                        THEN sa.nls
                      ELSE v.account END                         AS account_,
                      min ( START_RTPL )
                      OVER (
                        PARTITION BY v.account )                 AS START_RTPL_,
                      min ( tech_id )
                      OVER (
                        PARTITION BY v.account )                 AS tech_id_,
                      min ( SPEED )
                      OVER (
                        PARTITION BY v.account )                 AS SPEED_,
                      MIN ( rtpl_name )
                      OVER (
                        PARTITION BY v.account ) AS rtpl_name_,
                      row_number ( )
                      OVER (
                        PARTITION BY CASE WHEN sa.mrf_id = 14
                          THEN sa.nls
                                     ELSE v.account END
                        ORDER BY CASE WHEN v.date_start <= to_date ( '20190630', 'YYYYMMDD' )
                          THEN 0
                                 ELSE 1 END, v.date_start DESC ) AS rn
                    FROM edw_ods.T_000153_RPRT_VRATE_PLANS_DWH v
                    LEFT JOIN (
                        SELECT
                          mrf_id,
                          nls,
                          account,
                          row_number ()
                            OVER (
                            PARTITION BY account
                            ORDER BY COALESCE(date_end, to_date('2999-12-31', 'yyyy-mm-dd')) DESC, date_begin DESC ) rn
                        FROM edw_ods.T_000158_EFFTP_SOUTH_NLS_ACCNT
                      ) sa
                        ON sa.mrf_id = 14
                           AND sa.account = v.account
                           AND sa.rn = 1
     WHERE v.serv_id in (-1,1,50)
                  ) tbl

                WHERE tbl.rn = 1 ) cd ON pre.account = cd.account

    LEFT JOIN edw_dds.hub_dim_branch b ON b.src_id = 158
                                          AND cl.rf_id :: text = b.source_key
                                          AND date_trunc('day',b.exp_dttm) = to_date('2999-12-31','yyyy-mm-dd')

    LEFT JOIN edw_dds.dim_branch br ON b.branch_key = br.branch_key
                                       AND br.deleted_ind = 0
                                       AND date_trunc('day',br.exp_dttm) = to_date('2999-12-31','yyyy-mm-dd')

    LEFT JOIN edw_dds.dim_branch br_par ON br.parent_branch_key = br_par.branch_key
                                           AND br_par.deleted_ind = 0
                                           AND date_trunc('day',br_par.exp_dttm) = to_date('2999-12-31','yyyy-mm-dd')

    LEFT JOIN edw_ods.T_000158_RPRT_DIRD_MACRO_SGMNT nm
      ON nm.id_macro_segment = cl.id_macro_segment_ud

    /* попытка посадить бранчи на rf_id из чарджа, а не клиента*/
    LEFT JOIN edw_dds.hub_dim_branch b2 ON b2.src_id = 158
                                           AND pre.rf_id :: text = b2.source_key
                                           AND date_trunc('day',b2.exp_dttm) = to_date('2999-12-31','yyyy-mm-dd')

    LEFT JOIN edw_dds.dim_branch br2 ON b2.branch_key = br2.branch_key
                                        AND br2.deleted_ind = 0
                                        AND date_trunc('day',br2.exp_dttm) = to_date('2999-12-31','yyyy-mm-dd')


    LEFT JOIN edw_dds.dim_branch br_par2 ON br2.parent_branch_key = br_par2.branch_key
                                            AND br_par2.deleted_ind = 0
                                            AND date_trunc('day',br_par2.exp_dttm) = to_date('2999-12-31','yyyy-mm-dd')
    LEFT JOIN edw_stg_dmcm.PRE_OTA_DIM_ADDRESS_STG_1_PRT_P000153 adr
      ON adr.account = pre.account

  WHERE
    pre.date_snap BETWEEN to_date ( '20190601', 'YYYYMMDD' ) AND to_date (
      '20190630', 'YYYYMMDD' )
) q
group by INN, id_rf, account, period, tp_start, rtpl_name, date_snap, src_id;
ANALYSE edw_stg_dmcm.tfct_ota_1_PRT_P000153;
