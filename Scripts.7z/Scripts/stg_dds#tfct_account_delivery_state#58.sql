/*rev.19996 от 28.12.2018*/
	truncate table edw_stg_dds.t_000058_tfct_account_delivery_state;
	insert into edw_stg_dds.t_000058_tfct_account_delivery_state 
	(
		delivery_type_key,
		manager_fio,
		snap_dt,
		account_key,
		src_id,
		deleted_ind
	)
	select 
		case 
			when sum(case when id_obj = 1000175 and content_str =   'Не доставлять'              then 1 else 0 end)   > 0 then 0 
			when sum(case when id_obj = 1000175 and content_str =   'ЭДО Тензор'                 then 1 else 0 end)   > 0 then 18
			when sum(case when id_obj = 1000175 and content_str =   'ЭДО Контур'                 then 1 else 0 end)   > 0 then 19
			when sum(case when id_obj = 1000175 and content_str in ('Почта', 'Почта + e-mail')   then 1 else 0 end)   > 0 then 6
			when sum(case when id_obj = 1000175 and content_str in ('Курьер', 'Курьер + e-mail') then 1 else 0 end)   > 0 then 14
			when sum(case when id_obj = 1000175 and content_str =   'E-mail'                     then 1 else 0 end)   > 0 then 3
			when sum(case when id_obj = 1000175 and content_str in ('Офис', 'Офис + e-mail')     then 1 else 0 end)   > 0 then 1
			else  -1
		end delivery_type_key
	, max(case when id_obj = 1000114 then content_str end) manager_fio
	, date_trunc('month', to_date('20190630', 'YYYYMMDD')) snap_dt  
	, src_id||'#'||user_id account_key
	, 000058::smallint as src_id
	, deleted_ind
	from 
		(
		select 
			u.user_id,
			u.src_id,
			first_value(nc.content_str) OVER (PARTITION BY u.user_id, nc.id_obj 
					ORDER BY nc.date_begin desc, nc.action_id desc
					ROWS BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING) content_str,
			nc.id_obj,
			coalesce(nullif(nt.deleted_ind, 0), nullif(u.deleted_ind, 0), nc.deleted_ind) as deleted_ind
		from  edw_ods.t_000058_n_titul_treaty nt
		inner join edw_ods.t_000058_t_users u
			on ( 1 = 1 
			and nt.id_host=u.user_id 
			and to_date('20190630', 'YYYYMMDD') between coalesce(u.date_begin,to_date('19000101', 'YYYYMMDD')) and coalesce(u.date_end,to_date('29991231', 'YYYYMMDD'))
			and u.deleted_ind = '0'
			and to_date('20190630', 'YYYYMMDD') between u.eff_dttm and u.exp_dttm
			)
		inner join edw_ods.t_000058_n_content_treaty nc
			on (1 = 1 
			and nc.id_treaty=nt.id_treaty 
			and nc.id_obj in (1000175,1000114)
			and to_date('20190630', 'YYYYMMDD') >= nc.date_begin 
			and nc.deleted_ind = '0'
			and to_date('20190630', 'YYYYMMDD') between nc.eff_dttm and nc.exp_dttm
			)
		where 1 = 1  
		and to_date('20190630', 'YYYYMMDD') between coalesce(nt.date_begin,to_date('19000101', 'YYYYMMDD')) and coalesce(nt.date_end,to_date('29991231', 'YYYYMMDD'))
		and to_date('20190630', 'YYYYMMDD') between nt.eff_dttm and nt.exp_dttm
		and nt.deleted_ind = '0') u
	where 1 = 1
		and deleted_ind = '0'
	group by account_key, src_id, deleted_ind;

	analyze edw_stg_dds.t_000058_tfct_account_delivery_state;

	