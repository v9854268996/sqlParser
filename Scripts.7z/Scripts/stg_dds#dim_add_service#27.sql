/*rev.46650 от 17.01.2020*/

truncate table EDW_STG_DDS.T_000027_DIM_ADD_SERVICE;
truncate table EDW_STG_DDS.T_000027_PRE_DIM_ADD_SERVICE_REC;

set gp_recursive_cte_prototype = ON;

insert into EDW_STG_DDS.T_000027_PRE_DIM_ADD_SERVICE_REC
(
    dfservconst,
    dfmovemaster,
    fvr
)
WITH recursive mm
AS (
      SELECT
        dfservconst,
        dfmovemaster,
        dfservconst as fvr
      FROM EDW_ODS.T_000027_TSERVCONST t
      WHERE t.dfmovemaster is null
        and t.deleted_ind = 0
      UNION ALL
      SELECT t.dfservconst,
        t.dfmovemaster,
        mm.fvr
      FROM EDW_ODS.T_000027_TSERVCONST t 
      JOIN mm ON t.dfmovemaster = mm.dfservconst
      WHERE t.deleted_ind = 0 and (t.dfmovemaster != t.dfservconst)
    )
select dfservconst,
  dfmovemaster,
  fvr
from mm;
commit;

analyze EDW_STG_DDS.T_000027_PRE_DIM_ADD_SERVICE_REC;

insert into EDW_STG_DDS.T_000027_DIM_ADD_SERVICE
(
  add_service_key,
  add_service_parent_key,
  service_key,
  branch_key,
  city_key,
  account_name,
  subs_name,
  mrf_service_key,
  mrf_add_service_name,
  start_date,
  end_date,
  service_cost,
  dop_service_key,
  add_serv_sc_key,
  src_id
)
WITH q_cos 
as
  (
    -- ОПРЕДЕЛЕНИЕ УСЛУГ С ЕДИНОВРЕМЕННЫМИ ПЛАТЕЖАМИ
    SELECT sq_cos.dfservconst,
      sq_cos.dfonenach_dgo
    FROM EDW_ODS.T_000041_TCRM_ORDER_SERVCONST sq_cos
    WHERE NOT EXISTS
      (
        SELECT 1
        FROM EDW_ODS.T_000041_TCRM_ORDER_SERVCONST sq2_cos
        WHERE sq2_cos.dfservconst_master = sq_cos.dfservconst
      )
      and sq_cos.deleted_ind = 0 and sq_cos.exp_dttm = '2999-12-31 00:00:00'
    GROUP BY sq_cos.dfservconst,
      sq_cos.dfonenach_dgo
  ),
tservnach_one 
as 
  (
    SELECT distinct t.dfservconst,
      t.dfonenach,
      t.dfservice,
      t.cnt
    FROM (
          SELECT dfservconst,
            dfonenach,
            dfservice,
            count(distinct dfservice) over (partition by dfservconst) as cnt 
          FROM EDW_ODS.T_000027_TSERVNACH
          WHERE dfonenach is not null 
            and deleted_ind = 0
          ) t
    where t.cnt > 1
  )
  SELECT 
    const.dfservconst::bigint
      || case 
            when q_cos.dfonenach_dgo is not null and tservnach_one.dfonenach is not null then '#' || tservnach_one.dfonenach::bigint
            else '' 
         end as add_service_key,
    coalesce(rec.fvr::bigint 
      || case 
          when q_cos_fvr.dfonenach_dgo is not null and tservnach_one_fvr.dfonenach is not null then '#' || tservnach_one_fvr.dfonenach::bigint
          else '' 
        end, 
      const.dfservconst::bigint
      || case 
          when q_cos.dfonenach_dgo is not null and tservnach_one.dfonenach is not null then '#' || tservnach_one.dfonenach::bigint
          else ''
        end
      ) as add_service_parent_key,
    const.src_id || ';' || coalesce(tservnach_one.dfservice::numeric(38), const.dfservice::numeric(38)) as service_key,
    const.src_id || ';' || const.dfbranch::numeric(38)  as branch_key,
    null                                                as city_key,
    dogovor_nls.dfaccount::numeric(15, 0)               as account_name,
    null                                                as subs_name,
    const.src_id || ';' 
      || coalesce(tservnach_one.dfservice::numeric(38), const.dfservice::numeric(38)) as mrf_service_key,
    serv.dfnamesmall                                                                  as mrf_add_service_name,
    coalesce(const.dfdatebegin, to_date('1900-01-01', 'YYYY-MM-DD'))::timestamp       as start_date,
    coalesce(const.dfdateend, to_date('2999-12-31', 'YYYY-MM-DD'))::timestamp         as end_date,
    null::numeric(38, 5)                                                              as service_cost,
    const.src_id || ';' || coalesce(tservnach_one.dfservice::numeric(38), const.dfservice::numeric(38)) as dop_service_key,
    const.dfservconst::bigint
      || case 
          when q_cos.dfonenach_dgo is not null and tservnach_one.dfonenach is not null then '#' || q_cos.dfonenach_dgo 
          else ''
        end as   add_serv_sc_key,
    const.src_id src_id
  FROM EDW_ODS.T_000027_TSERVCONST const
  LEFT JOIN (
              select dfdogovor_ref,
                dfdatebegin,
                dfels_dogovor,
                deleted_ind,
                row_number() over(partition by dfdogovor_ref order by dfdatebegin desc) rn
              from EDW_ODS.T_000027_TELS_DOGOVOR_LINK
            ) tels_link on tels_link.dfdogovor_ref = const.dfdogovor
    and tels_link.deleted_ind = 0
    and tels_link.rn = 1
  LEFT JOIN EDW_ODS.T_000027_TDOGOVOR dogovor_nls on tels_link.dfels_dogovor = dogovor_nls.dfdogovor
    and dogovor_nls.dfdogtype = 1234567
    and dogovor_nls.deleted_ind = 0
    and (
          dogovor_nls.src_id = 39 or (dogovor_nls.dfdelete <> 'T' or dogovor_nls.dfdelete is null)
        )
  LEFT JOIN EDW_ODS.T_000027_TDOGOVOR tdogovor on tdogovor.dfdogovor = const.dfdogovor
    and tdogovor.dfdogtype <> 1234567
    and tdogovor.deleted_ind = 0
    and (
          tdogovor.src_id = 39 or (tdogovor.dfdelete <> 'T' or tdogovor.dfdelete is null)
        )
LEFT JOIN q_cos on q_cos.dfservconst = const.dfservconst
LEFT JOIN tservnach_one on tservnach_one.dfservconst = q_cos.dfservconst 
  and q_cos.dfonenach_dgo is not null
LEFT JOIN EDW_STG_DDS.T_000027_PRE_DIM_ADD_SERVICE_REC rec on rec.dfservconst = const.dfservconst
LEFT JOIN q_cos as q_cos_fvr on q_cos_fvr.dfservconst = rec.fvr
LEFT JOIN tservnach_one as tservnach_one_fvr on tservnach_one_fvr.dfservconst = q_cos_fvr.dfservconst 
  and tservnach_one_fvr.dfonenach = tservnach_one.dfonenach
LEFT JOIN EDW_ODS.T_000027_TSERVICE serv on serv.dfservice = coalesce(tservnach_one.dfservice::numeric(38), const.dfservice::numeric(38))
  and serv.deleted_ind = 0
WHERE 1 = 1
   and coalesce(const.dfdelete, '') != 'T'
   and coalesce(const.dfcondition, '') <> 'T'
   and const.deleted_ind = 0
   and tdogovor.dfactivity = 23
   and const.dfdevice not in (
                                1102,
                                111, --IPTV
                                1001, -- DSL
                                1002,
                                1003, -- ETTH 
                                191,
                                500,
                                570,
                                1000000020 -- Технологические
                              )
;
commit;
insert into EDW_STG_DDS.T_000027_DIM_ADD_SERVICE
(
  add_service_key,
  add_service_parent_key,
  service_key,
  branch_key,
  city_key,
  account_name,
  subs_name,
  mrf_service_key,
  mrf_add_service_name,
  start_date,
  end_date,
  service_cost,
  dop_service_key,
  add_serv_sc_key,
  src_id
)
SELECT 
  'C' || tserv.dfservnach::bigint || '#' || tserv.dfonenach::bigint as add_service_key,
  'C' || tserv.dfservnach::bigint || '#' || tserv.dfonenach::bigint as add_service_parent_key,
  tserv.src_id || ';' || tserv.dfservice::numeric(38)               as service_key,
  tserv.src_id || ';' || tserv.dfbranch::numeric(38)                as branch_key,
  null                                                              as city_key,
  dogovor_nls.dfaccount::numeric(15, 0)                             as account_name,
  null                                                              as subs_name,
  tserv.src_id || ';' || tserv.dfservice::numeric(38)               as mrf_service_key,
  serv.dfnamesmall                                                  as mrf_add_service_name,
  coalesce(tserv.dfdatebegin, to_date('1900-01-01', 'YYYY-MM-DD'))::timestamp as start_date,
  coalesce(tserv.dfdateend, to_date('2999-12-31', 'YYYY-MM-DD'))::timestamp   as end_date,
  null::numeric(38, 5)                                                        as service_cost,
  tserv.src_id || ';' || tserv.dfservice::numeric(38)                         as dop_service_key,
  '#' || tserv.dfonenach                                                      as add_serv_sc_key,
  tserv.src_id                                                                as src_id
FROM EDW_ODS.T_000027_TSERVNACH tserv
LEFT JOIN EDW_STG_DDS.T_000027_DIM_ADD_SERVICE das on (tserv.dfservconst::bigint)::text = split_part(das.add_service_key,'#',1)
  and tserv.src_id || ';' || tserv.dfservice::numeric(38) = das.mrf_service_key
LEFT JOIN (
            SELECT *, 
              row_number() over(partition by dfdogovor_ref order by dfdatebegin desc) rn
            FROM EDW_ODS.T_000027_TELS_DOGOVOR_LINK
          ) tels_link on tels_link.dfdogovor_ref = tserv.dfdogovor
  and tels_link.deleted_ind = 0
  and tels_link.rn = 1
LEFT JOIN EDW_ODS.T_000027_TDOGOVOR dogovor_nls on tels_link.dfels_dogovor = dogovor_nls.dfdogovor
  and dogovor_nls.dfdogtype = 1234567
  and dogovor_nls.deleted_ind = 0
  and (
        dogovor_nls.src_id = 39 or (dogovor_nls.dfdelete <> 'T' or dogovor_nls.dfdelete is null)
      )
LEFT JOIN EDW_ODS.T_000027_TSERVICE serv on serv.dfservice = tserv.dfservice::numeric(38)
  and serv.deleted_ind = 0
WHERE tserv.dfservconst is not null
  and tserv.dfonenach is not null
  and das.add_service_key is null
;
insert into EDW_STG_DDS.T_000027_DIM_ADD_SERVICE
(
  add_service_key,
  add_service_parent_key,
  service_key,
  branch_key,
  city_key,
  account_name,
  subs_name,
  mrf_service_key,
  mrf_add_service_name,
  start_date,
  end_date,
  service_cost,
  dop_service_key,
  add_serv_sc_key,
  src_id
)
SELECT 
  'N'||tserv.dfservnach::bigint||'#'||tserv.dfonenach::bigint as add_service_key,
  'N'||tserv.dfservnach::bigint||'#'||tserv.dfonenach::bigint as add_service_parent_key,
  tserv.src_id||';'||tserv.dfservice::numeric(38)             as service_key,
  tserv.src_id||';'||tserv.dfbranch::numeric(38)              as branch_key,
  null                                                        as city_key,
  dogovor_nls.dfaccount::numeric(15, 0)                       as account_name,
  null                                                        as subs_name,
  tserv.src_id||';'||tserv.dfservice::numeric(38)             as mrf_service_key,
  serv.dfnamesmall                                            as mrf_add_service_name,
  coalesce(tserv.dfdatebegin, to_date('1900-01-01', 'YYYY-MM-DD'))::timestamp as start_date,
  coalesce(tserv.dfdateend, to_date('2999-12-31', 'YYYY-MM-DD'))::timestamp   as end_date,
  null::numeric(38, 5)                            as service_cost,
  tserv.src_id||';'||tserv.dfservice::numeric(38) as dop_service_key,
  '#'||tserv.dfonenach                            as add_serv_sc_key,
  tserv.src_id                                    as src_id
FROM EDW_ODS.T_000027_TSERVNACH tserv
LEFT JOIN EDW_ODS.T_000027_TDOGOVOR dog on dog.dfdogovor = tserv.dfdogovor
    and dog.dfdogtype <> 1234567
    and dog.deleted_ind = 0
    and (
          dog.src_id = 39 or (dog.dfdelete <> 'T' or dog.dfdelete is null)
        )
LEFT JOIN (
            SELECT *,
              row_number() over(partition by dfdogovor_ref order by dfdatebegin desc) rn
            FROM EDW_ODS.T_000027_TELS_DOGOVOR_LINK
          ) tels_link on tels_link.dfdogovor_ref = tserv.dfdogovor
  and tels_link.deleted_ind = 0
  and tels_link.rn = 1
LEFT JOIN EDW_ODS.T_000027_TDOGOVOR dogovor_nls on tels_link.dfels_dogovor = dogovor_nls.dfdogovor
  and dogovor_nls.dfdogtype = 1234567
  and dogovor_nls.deleted_ind = 0
  and (
        dogovor_nls.src_id = 39 or (dogovor_nls.dfdelete <> 'T' or dogovor_nls.dfdelete is null)
      )
LEFT JOIN EDW_ODS.T_000027_TSERVICE serv on serv.dfservice = tserv.dfservice::numeric(38)
  and serv.deleted_ind = 0
WHERE tserv.dfservconst is null
  and tserv.dfonenach is not null
  and dog.dfactivity = 23
;

commit;

analyze EDW_STG_DDS.T_000027_DIM_ADD_SERVICE;