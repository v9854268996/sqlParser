/*rev.22457 15.02.2019*/
truncate table edw_stg_dds.T_000097_PRE_SUBS_CLNT_HISTORIES;
set optimizer = on;
insert into edw_stg_dds.T_000097_PRE_SUBS_CLNT_HISTORIES (clnt_clnt_id,subs_subs_id
	, number_history
	, navi_date, sbst_sbst_id
	, start_date
	,  end_date)
--create or replace view edw_ods.v_000097_subs_clnt_histories  as
with 
data_set_dup as (
	select
		*,
		row_number() over(partition by  clnt_clnt_id,subs_subs_id,start_date order by number_history desc) as rn
	from edw_ods.t_000097_subs_clnt_histories 
	where deleted_ind = 0
	--where clnt_clnt_id = 1601286 --18428839 17677494  -- Для тестов
	--limit 100
),
data_set_cleared as (
	select
		a1.*
	from data_set_dup a1 
	left join data_set_dup a2
	       on a2.rn = 1 
	       and a2.clnt_clnt_id = a1.clnt_clnt_id
		   and a2.subs_subs_id = a1.subs_subs_id
	       			and a1.start_date >= a2.start_date 
			and a1.start_date < a2.end_date
	    --   and a1.end_date between a2.start_date and a2.end_date
	       and a2.number_history > a1.number_history
	where 
		a1.rn = 1 
		and  a2.clnt_clnt_id is null
)

,clnt_hist_normalised as (
	select 
		clnt_clnt_id,subs_subs_id
		,number_history
		
		,identification, lock_calls, navi_date
		, navi_user,  sbst_sbst_id
		, min(start_date) as start_date
		, max(end_date) as end_date
	from
	    (
			select 
				*
				,row_number()over(partition by clnt_clnt_id,subs_subs_id,
						--		   number_history,
						identification, lock_calls, navi_date
						, navi_user,  sbst_sbst_id  
						order by start_date)
					-row_number()over(partition by  clnt_clnt_id,subs_subs_id order by start_date)
				as gr
			from  data_set_cleared
			where  start_date < end_date 
	    ) t 
	group by clnt_clnt_id,subs_subs_id,number_history, gr,
		 identification, lock_calls, navi_date
		, navi_user,  sbst_sbst_id
)
select 
	clnt_clnt_id,subs_subs_id
	, number_history
	--, identification, lock_calls
	, navi_date
	--, navi_user
	, sbst_sbst_id
	,cast(start_date as timestamp without time zone) as start_date
	,coalesce(lead(start_date) over (partition by subs_subs_id order by start_date)- interval '1 second',end_date) end_date
	from   clnt_hist_normalised  	
--where clnt_clnt_id = 1601286 -- Для тестов
;
commit;
analyze edw_stg_dds.T_000097_PRE_SUBS_CLNT_HISTORIES;
