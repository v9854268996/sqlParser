/*rev. 31693 от 25.06.2019 */
TRUNCATE TABLE EDW_STG_DM_RUZ.TFCT_REPORT_IT_EXPENSES_EIP;

INSERT INTO edw_stg_dm_ruz.tfct_report_it_expenses_eip (period
       , business_segment
       , expense_coef
       , cfo
       , load_dttm
       , src_id
) 
select 
         period
       , business_segment
       , expense_coef
       , cfo
       , now() as load_dttm
       , src_id
	from edw_ods.t_000194_TFCT_EIP_EXPENSE_ALLOC
	where period between to_date('20190601', 'YYYYMMDD') and  to_date('20190630', 'YYYYMMDD');

ANALYSE EDW_STG_DM_RUZ.TFCT_REPORT_IT_EXPENSES_EIP;
