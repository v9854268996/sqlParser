/*rev. 40720 от 18.10.2019*/
set optimizer = on;

truncate table edw_stg_dm_efftp.tfct_mpz_efftp_map_1_prt_p000156
;

-- DS 1
insert into edw_stg_dm_efftp.tfct_mpz_efftp_map_1_prt_p000156
(
	dt,
	mrf_id,
	rf_id,
	serv_id,
	tech_id,
	tech_id_sao,
	tech_name_sao,
	channel_name,
	account,
	sao_include,
	efftp_include,
	service_id,
	option_id,
	subs_id,
	abn_id,
	reason_absence,
	flat,
	hgid,
	hlid,
	insert_date,
	date_start,
	abn_characteristic,
	abn_count,
	load_dttm,
	src_id,
	eff_dttm,
	exp_dttm,
	period_coo
)
select 
	x.dt,
	x.mrf_id,
	x.rf_id,
	x.serv_id,
	x.tech_id,
	x.tech_id_sao,
	x.tech_name_sao,
	x.channel_name,
	x.account,
	x.sao_include,
	x.efftp_include,
	x.service_id,
	x.option_id,
	x.subs_id,
	x.abn_id,
	case when length(x.account) != 12 then 'Ошибка в НЛС' else x.reason_absence end reason_absence,
	x.flat,
	x.hgid,
	x.hlid,
	x.insert_date,
	x.date_start,
	x.abn_characteristic,
	x.abn_count,
	x.load_dttm,
	x.src_id,
	x.eff_dttm,
	x.exp_dttm,
	x.period_coo
from
(
	select 
		date_trunc('month', t.date_change_state) dt,       
		decode(t.name_mrf,
				'МРФ Центр', 11,
				'МРФ Москва', 11,
				'МРФ Северо-Запад', 12,
				'МРФ Волга', 13,
				'МРФ ЮГ', 14,
				'МРФ Урал', 15,
				'МРФ Сибирь', 16,
				'МРФ Дальний Восток', 17,
				null, -1
			) as mrf_id,
		cast(null as numeric(10, 0))  rf_id,
		decode(t.product_category, 1, 2, 5, 3, 2, 1) serv_id, 
		cast (-1 as numeric(10, 0))  tech_id,
		t.tech_id tech_id_sao,
		t.tech_name tech_name_sao,
		t.channel_name,
		trim(t.acc_number) account,
		cast(1 as numeric(1, 0)) sao_include,
		cast(0 as numeric(1, 0)) efftp_include,
		t.service_id,
		t.option_id,
		cast(null as varchar(50)) subs_id,
		cast(null as numeric(38, 0)) abn_id,
		cast(null as varchar(250)) reason_absence,
		substring(t.addr_office, 1, 10) flat,
		t.hgid,
		t.hlid,
		t.insert_date,
		cast(null as date) date_start,
		cast(null as varchar(250)) abn_characteristic,
		cast(0 as numeric(15, 0)) abn_count,
		now() load_dttm,       
		decode(t.name_mrf,
				'МРФ Центр', 151,
				'МРФ Москва', 151,
				'МРФ Северо-Запад', 152,
				'МРФ Волга', 153,
				'МРФ ЮГ', 154,
				'МРФ Урал', 155,
				'МРФ Сибирь', 156,
				'МРФ Дальний Восток', 157,
				null, -1
			) as src_id,
		to_date('19000101','YYYYMMDD') eff_dttm,
		to_date('29991231','YYYYMMDD') exp_dttm,       
		cast(null as numeric(6, 0)) period_coo,
		row_number() over(partition by date_trunc('month', t.date_change_state), t.name_mrf, t.product_category, t.acc_number,
									case when t.src_id in (151, 152, 153, 155, 156, 157) then t.hlid else '1' end,
									case when t.src_id in (153, 154, 155, 156, 157)      then t.hgid else '1' end
						order by t.date_change_state desc, t.date_create desc, t.service_id) rn --t.date_create desc, t.service_id  добавдено, чтобы получить стабильный результат
	from edw_ods.T_000171_dwh_mpz t
	where 1 = 1
		and t.product_category in (2, 1, 5)
		and t.state_id = 7
		and t.acc_number is not null
		and LENGTH(trim(t.acc_number)) > 5
		and t.date_change_state >= to_date('20190601','YYYYMMDD')::timestamp
		and t.date_change_state <= (to_date('20190630','YYYYMMDD') + interval '1 day' - interval '1 second')::timestamp
		and t.request_type = 'Установка'
		and decode(t.name_mrf,
				'МРФ Центр', 151,
				'МРФ Москва', 151,
				'МРФ Северо-Запад', 152,
				'МРФ Волга', 153,
				'МРФ ЮГ', 154,
				'МРФ Урал', 155,
				'МРФ Сибирь', 156,
				'МРФ Дальний Восток', 157,
				null, -1
			) = 000156  
) x where x.rn = 1
;


-- DS 3

---- DS 3.1 кроме Юга

update edw_stg_dm_efftp.tfct_mpz_efftp_map_1_prt_p000156 r
set
rf_id = r2.P3_rf_id, 
abn_id = r2.abn_id,
tech_id = r2.tech_id, 
subs_id = r2.subs_id,
period_coo = r2.p1_period,
date_start = r2.date_start,
efftp_include = 1,
abn_characteristic = case when r2.new_abns = 1   then 'НОВЫЙ АБОНЕНТ'
                          when r2.daily_abns = 1 then 'CУТОЧНЫЙ АБОНЕНТ'
                          when r2.churn_abns = 1 then 'АБОНЕНТ ОТТОКА'
                          when r2.end_per = 1    then 'ДЕЙСТВУЮЩИЙ АБОНЕНТ'
                          when r2.migr = 1       then 'МИГРАЦИЯ С ТЕХНОЛОГИИ'
                          else null
           end,
abn_count = 1, 
reason_absence = case when r2.new_abns = 1   then null
                      when r2.daily_abns = 1 then null
                      when r2.churn_abns = 1 then 'АБОНЕНТ ОТТОКА'
                      when r2.end_per = 1    then 'ДЕЙСТВУЮЩИЙ АБОНЕНТ'
                      when r2.migr = 1       then 'МИГРАЦИЯ С ТЕХНОЛОГИИ'
                      else null
         end    
from 
(
	select 
		fff.* 
	from
	(
		with efftp as 
		(
			select 
				tp.p3_rf_id,
				tp.abn_id,
				tp.subs_id,
				tp.tech_id,
				tp.date_start,
				tp.new_abns,
				tp.daily_abns,
				tp.churn_abns,
				tp.change_tech_flag,
				tp.p24_qnt_end_rp_shpd,
				tp.p81_qnt_end_rp_ota,
				tp.p83_qnt_end_rp_iptv,
				tp.account,
				date_trunc('month', tp.tech_dt) as dt,
				tp.src_id,
				tp.serv_id,
				tp.charge_only_flag,
				tp.hlid,
				tp.hgid,
				tp.P1_PERIOD,
				row_number() over(partition by tp.ABN_ID, tp.P1_PERIOD, case when tp.serv_id > 0 then 1 else 0 end
							order by case when coalesce(tp.p24_qnt_end_rp_shpd,0)+coalesce(tp.p81_qnt_end_rp_ota,0)+coalesce(tp.p83_qnt_end_rp_iptv,0) > 0 then 0 else 1 end) rn
			from edw_ods.t_000156_efftp_oo_eff_tp tp
			where 1 = 1
				and tp.P1_PERIOD between to_number(to_char(date_trunc('month', to_date('20190601', 'YYYYMMDD')), 'YYYYMM'), '999999') and to_number(to_char(date_trunc('month', to_date('20190630', 'YYYYMMDD') + interval '2 month'), 'YYYYMM'), '999999')
				and tp.tech_dt  >= date_trunc('month', to_date('20190601', 'YYYYMMDD'))::timestamp
				and tp.tech_dt  <= (date_trunc('month', to_date('20190630', 'YYYYMMDD')) + interval '3 month - 1 second')::timestamp
		)
		select 
			t.dt,
			t.src_id,
			t.account,
			t.service_id,
			t.option_id,
			t.serv_id,
			t.tech_name_sao,
			t.hlid,
			t.hgid,
			EF.P1_PERIOD,
			ef.p3_rf_id,
			ef.abn_id,
			ef.subs_id,
			coalesce(ef.tech_id, -1) tech_id,
			ef.date_start,
			coalesce(ef.new_abns, 0) new_abns, 
			coalesce(ef.daily_abns, 0) daily_abns,
			decode(ef.churn_abns, 1, 1, 2, 1, null, 0) churn_abns,
			decode(ef.change_tech_flag, 1, 1, 3, 1, 2, 0, 0, 0, null, 0) migr,
			coalesce(ef.p24_qnt_end_rp_shpd, 0) + coalesce(ef.p81_qnt_end_rp_ota, 0) + coalesce(ef.p83_qnt_end_rp_iptv, 0)  end_per,
			row_number() over (partition by t.dt, t.mrf_id, ef.account, t.serv_id,
								case when t.src_id in (151, 152, 153, 155, 156, 157) then t.hlid else '1' end,
								case when t.src_id in (153, 154, 155, 156, 157) then t.hgid else '1' end
								order by ef.dt, coalesce(ef.new_abns, 0) desc, coalesce(ef.daily_abns,0) desc, ef.date_start desc) rn
		from edw_stg_dm_efftp.tfct_mpz_efftp_map_1_prt_p000156 t
			,efftp ef 
		where 1 = 1
			and ef.rn=1
			and t.src_id in (151, 152, 153, 155, 156, 157)
			and ef.src_id in (151, 152, 153, 155, 156, 157)
			and t.efftp_include = 0 
			and t.reason_absence is null 
			and ef.dt between t.dt and t.dt + interval '2 month'
			and ef.serv_id in (1, 2, 3, 4, 5)
			and coalesce(ef.charge_only_flag, 0) = 0
			and ef.account is not null 
			and trim(ef.account) = t.account
			and decode(ef.serv_id, 1, 1, 2, 2, 3, 3, 4, 3, 5, 1) = t.serv_id
			and t.hlid = case when t.src_id in (151, 152, 153, 155, 156, 157) then ef.hlid  else t.hlid end 
			and t.hgid = case when t.src_id in (153, 154, 155, 156, 157)      then ef.hgid  else t.hgid end
	)  fff
		where rn=1 
) r2
where 1 = 1
	and r.dt = r2.dt
	and r.service_id = r2.service_id
	and r.option_id = r2.option_id
	and r.account = r2.account
	and r.serv_id = r2.serv_id
;


---- DS 3.2 для Юга
update edw_stg_dm_efftp.tfct_mpz_efftp_map_1_prt_p000156 r
set
rf_id = r2.P3_rf_id, 
abn_id = r2.abn_id,
tech_id = r2.tech_id, 
subs_id = r2.subs_id,
period_coo = r2.p1_period,
date_start = r2.date_start,
efftp_include = 1,
abn_characteristic = case when r2.new_abns = 1   then 'НОВЫЙ АБОНЕНТ'
                          when r2.daily_abns = 1 then 'CУТОЧНЫЙ АБОНЕНТ'
                          when r2.churn_abns = 1 then 'АБОНЕНТ ОТТОКА'
                          when r2.end_per = 1    then 'ДЕЙСТВУЮЩИЙ АБОНЕНТ'
                          when r2.migr = 1       then 'МИГРАЦИЯ С ТЕХНОЛОГИИ'
                          else null
           end,
abn_count = 1, 
reason_absence = case when r2.new_abns = 1   then null
                      when r2.daily_abns = 1 then null
                      when r2.churn_abns = 1 then 'АБОНЕНТ ОТТОКА'
                      when r2.end_per = 1    then 'ДЕЙСТВУЮЩИЙ АБОНЕНТ'
                      when r2.migr = 1       then 'МИГРАЦИЯ С ТЕХНОЛОГИИ'
                      else null
         end    
from 
(
	select 
		fff.* 
	from
	(
		with efftp as 
		(
			select 
				tp.p3_rf_id,
				tp.abn_id,
				tp.subs_id,
				tp.tech_id,
				tp.date_start,
				tp.new_abns,
				tp.daily_abns,
				tp.churn_abns,
				tp.change_tech_flag,
				tp.p24_qnt_end_rp_shpd,
				tp.p81_qnt_end_rp_ota,
				tp.p83_qnt_end_rp_iptv,
				tp.account,
				date_trunc('month', tp.tech_dt) as dt,
				tp.src_id,
				tp.serv_id,
				tp.charge_only_flag,
				tp.hlid,
				tp.hgid,
				tp.P1_PERIOD,
				row_number() over(partition by tp.ABN_ID, tp.P1_PERIOD, case when tp.serv_id > 0 then 1 else 0 end
							order by case when coalesce(tp.p24_qnt_end_rp_shpd,0)+coalesce(tp.p81_qnt_end_rp_ota,0)+coalesce(tp.p83_qnt_end_rp_iptv,0) > 0 then 0 else 1 end) rn
			from edw_ods.t_000156_efftp_oo_eff_tp tp
			where 1 = 1
				and tp.P1_PERIOD between to_number(to_char(date_trunc('month', to_date('20190601', 'YYYYMMDD')), 'YYYYMM'), '999999') and to_number(to_char(date_trunc('month', to_date('20190630', 'YYYYMMDD') + interval '2 month'), 'YYYYMM'), '999999')
				and tp.tech_dt  >= date_trunc('month', to_date('20190601', 'YYYYMMDD'))::timestamp
				and tp.tech_dt  <= (date_trunc('month', to_date('20190630', 'YYYYMMDD')) + interval '3 month - 1 second')::timestamp
				and tp.src_id in (154)
		)
		select 
			t.dt,
			t.src_id,
			t.account,
			t.service_id,
			t.option_id,
			t.serv_id,
			t.tech_name_sao,
			t.hlid,
			t.hgid,
			EF.P1_PERIOD,
			ef.p3_rf_id,
			ef.abn_id,
			ef.subs_id,
			coalesce(ef.tech_id, -1) tech_id,
			ef.date_start,
			coalesce(ef.new_abns, 0) new_abns, 
			coalesce(ef.daily_abns, 0) daily_abns,
			decode(ef.churn_abns, 1, 1, 2, 1, null, 0) churn_abns,
			decode(ef.change_tech_flag, 1, 1, 3, 1, 2, 0, 0, 0, null, 0) migr,
			coalesce(ef.p24_qnt_end_rp_shpd, 0) + coalesce(ef.p81_qnt_end_rp_ota, 0) + coalesce(ef.p83_qnt_end_rp_iptv, 0)  end_per,
			row_number() over (partition by t.dt, t.mrf_id, /*dd.rf_id,*/ dd.nls, t.serv_id, t.hlid
							order by ef.dt, coalesce(ef.new_abns, 0) desc, coalesce(ef.daily_abns,0) desc, ef.date_start desc) rn
		from edw_stg_dm_efftp.tfct_mpz_efftp_map_1_prt_p000156 t
			,efftp ef 
			,edw_ods.t_000158_efftp_south_nls_accnt dd
		where 1 = 1 
			and rn = 1
			and t.src_id in (154)
			and t.efftp_include = 0 
			and t.reason_absence is null 
			and ef.dt between t.dt and t.dt + interval '2 month'
			and ef.serv_id in (1, 2, 3, 4, 5)
			and coalesce(ef.charge_only_flag, 0) = 0
			and ef.account is not null 
			and ef.account = dd.account
			and dd.date_end is null
			and dd.rf_id = ef.p3_rf_id
			and trim(dd.nls) = t.account
			and decode(ef.serv_id, 1, 1, 2, 2, 3, 3, 4, 3, 5, 1) = t.serv_id  
			and t.hgid = ef.hgid
	)  fff
	where rn=1 
) r2
where r.dt = r2.dt
  and r.src_id = r2.src_id
  and r.service_id = r2.service_id
  and r.option_id = r2.option_id
  and r.account = r2.account
  and r.serv_id = r2.serv_id
;


-- DS 4

---- DS 4.1 кроме Юга
update edw_stg_dm_efftp.tfct_mpz_efftp_map_1_prt_p000156 r
set
rf_id = r2.P3_rf_id, 
abn_id = r2.abn_id,
tech_id = r2.tech_id, 
subs_id = r2.subs_id,
period_coo = r2.p1_period,
date_start = r2.date_start,
efftp_include = 1,
abn_characteristic = case when r2.new_abns = 1   then 'НОВЫЙ АБОНЕНТ'
                          when r2.daily_abns = 1 then 'CУТОЧНЫЙ АБОНЕНТ'
                          when r2.churn_abns = 1 then 'АБОНЕНТ ОТТОКА'
                          when r2.end_per = 1    then 'ДЕЙСТВУЮЩИЙ АБОНЕНТ'
                          when r2.migr = 1       then 'МИГРАЦИЯ С ТЕХНОЛОГИИ'
                          else null
           end,
abn_count = 1, 
reason_absence = case when r2.new_abns = 1   then null
                      when r2.daily_abns = 1 then null
                      when r2.churn_abns = 1 then 'АБОНЕНТ ОТТОКА'
                      when r2.end_per = 1    then 'ДЕЙСТВУЮЩИЙ АБОНЕНТ'
                      when r2.migr = 1       then 'МИГРАЦИЯ С ТЕХНОЛОГИИ'
                      else null
         end    
from 
(
	select 
		fff.* 
	from
	(
		with efftp as 
		(
			select 
				tp.p3_rf_id,
				tp.abn_id,
				tp.subs_id,
				tp.tech_id,
				tp.date_start,
				tp.new_abns,
				tp.daily_abns,
				tp.churn_abns,
				tp.change_tech_flag,
				tp.p24_qnt_end_rp_shpd,
				tp.p81_qnt_end_rp_ota,
				tp.p83_qnt_end_rp_iptv,
				tp.account,
				date_trunc('month', tp.tech_dt) as dt,
				tp.src_id,
				tp.serv_id,
				tp.charge_only_flag,
				tp.hlid,
				tp.hgid,
				tp.P1_PERIOD,
				row_number() over(partition by tp.ABN_ID, tp.P1_PERIOD, case when tp.serv_id > 0 then 1 else 0 end
							order by case when coalesce(tp.p24_qnt_end_rp_shpd,0)+coalesce(tp.p81_qnt_end_rp_ota,0)+coalesce(tp.p83_qnt_end_rp_iptv,0) > 0 then 0 else 1 end) rn
			from edw_ods.t_000156_efftp_oo_eff_tp tp
			where 1 = 1
				and tp.P1_PERIOD between to_number(to_char(date_trunc('month', to_date('20190601', 'YYYYMMDD')), 'YYYYMM'), '999999') and to_number(to_char(date_trunc('month', to_date('20190630', 'YYYYMMDD') + interval '2 month'), 'YYYYMM'), '999999')
				and tp.tech_dt  >= date_trunc('month', to_date('20190601', 'YYYYMMDD'))::timestamp
				and tp.tech_dt  <= (date_trunc('month', to_date('20190630', 'YYYYMMDD')) + interval '3 month - 1 second')::timestamp
		)
		select 
			t.dt,
			t.src_id,
			t.account,
			t.service_id,
			t.option_id,
			t.serv_id,
			t.tech_name_sao,
			t.hlid,
			t.hgid,
			EF.P1_PERIOD,
			ef.p3_rf_id,
			ef.abn_id,
			ef.subs_id,
			coalesce(ef.tech_id, -1) tech_id,
			ef.date_start,
			coalesce(ef.new_abns, 0) new_abns, 
			coalesce(ef.daily_abns, 0) daily_abns,
			decode(ef.churn_abns, 1, 1, 2, 1, null, 0) churn_abns,
			decode(ef.change_tech_flag, 1, 1, 3, 1, 2, 0, 0, 0, null, 0) migr,
			coalesce(ef.p24_qnt_end_rp_shpd, 0) + coalesce(ef.p81_qnt_end_rp_ota, 0) + coalesce(ef.p83_qnt_end_rp_iptv, 0)  end_per,
			row_number() over (partition by t.dt, t.mrf_id, /*ef.p3_rf_id,*/ ef.account, t.serv_id
								order by ef.dt, coalesce(ef.new_abns, 0) desc, coalesce(ef.daily_abns,0) desc, ef.date_start desc) rn
		from edw_stg_dm_efftp.tfct_mpz_efftp_map_1_prt_p000156 t
			,efftp ef 
		where 1= 1
			and ef.rn = 1
			and t.src_id in (151, 152, 153, 155, 156, 157)
			and ef.src_id in (151, 152, 153, 155, 156, 157)
			and t.efftp_include = 0 
			and t.reason_absence is null 
			and ef.dt between t.dt and t.dt + interval '2 month'
			and ef.serv_id in (1, 2, 3, 4, 5)
			and coalesce(ef.charge_only_flag, 0) = 0
			and ef.account is not null  
			and trim(ef.account) = t.account
			and decode(ef.serv_id, 1, 1, 2, 2, 3, 3, 4, 3, 5, 1) = t.serv_id  
	)  fff
	where rn=1 
) r2
where 1 = 1
	and r.dt = r2.dt
	and r.service_id = r2.service_id
	and r.option_id = r2.option_id
	and r.account = r2.account
	and r.serv_id = r2.serv_id
	and r.efftp_include = 0
;---- DS 4.2 для Юга
update edw_stg_dm_efftp.tfct_mpz_efftp_map_1_prt_p000156 r
set
rf_id = r2.P3_rf_id, 
abn_id = r2.abn_id,
tech_id = r2.tech_id, 
subs_id = r2.subs_id,
period_coo = r2.p1_period,
date_start = r2.date_start,
efftp_include = 1,
abn_characteristic = case when r2.new_abns = 1   then 'НОВЫЙ АБОНЕНТ'
                          when r2.daily_abns = 1 then 'CУТОЧНЫЙ АБОНЕНТ'
                          when r2.churn_abns = 1 then 'АБОНЕНТ ОТТОКА'
                          when r2.end_per = 1    then 'ДЕЙСТВУЮЩИЙ АБОНЕНТ'
                          when r2.migr = 1       then 'МИГРАЦИЯ С ТЕХНОЛОГИИ'
                          else null
           end,
abn_count = 1, 
reason_absence = case when r2.new_abns = 1   then null
                      when r2.daily_abns = 1 then null
                      when r2.churn_abns = 1 then 'АБОНЕНТ ОТТОКА'
                      when r2.end_per = 1    then 'ДЕЙСТВУЮЩИЙ АБОНЕНТ'
                      when r2.migr = 1       then 'МИГРАЦИЯ С ТЕХНОЛОГИИ'
                      else null
         end    
from 
(
	select 
		fff.* 
	from
	(
		with efftp as 
		(
			select 
				tp.p3_rf_id,
				tp.abn_id,
				tp.subs_id,
				tp.tech_id,
				tp.date_start,
				tp.new_abns,
				tp.daily_abns,
				tp.churn_abns,
				tp.change_tech_flag,
				tp.p24_qnt_end_rp_shpd,
				tp.p81_qnt_end_rp_ota,
				tp.p83_qnt_end_rp_iptv,
				tp.account,
				date_trunc('month', tp.tech_dt) as dt,
				tp.src_id,
				tp.serv_id,
				tp.charge_only_flag,
				tp.hlid,
				tp.hgid,
				tp.P1_PERIOD,
				row_number() over(partition by tp.ABN_ID, tp.P1_PERIOD, case when tp.serv_id > 0 then 1 else 0 end
							order by case when coalesce(tp.p24_qnt_end_rp_shpd,0)+coalesce(tp.p81_qnt_end_rp_ota,0)+coalesce(tp.p83_qnt_end_rp_iptv,0) > 0 then 0 else 1 end) rn
			from edw_ods.t_000156_efftp_oo_eff_tp tp
			where 1 = 1
				and tp.P1_PERIOD between to_number(to_char(date_trunc('month', to_date('20190601', 'YYYYMMDD')), 'YYYYMM'), '999999') and to_number(to_char(date_trunc('month', to_date('20190630', 'YYYYMMDD') + interval '2 month'), 'YYYYMM'), '999999')
				and tp.tech_dt  >= date_trunc('month', to_date('20190601', 'YYYYMMDD'))::timestamp
				and tp.tech_dt  <= (date_trunc('month', to_date('20190630', 'YYYYMMDD')) + interval '3 month - 1 second')::timestamp
				and tp.src_id in (154)
		),
		post_m as 
		(
			select 
				tp.p3_rf_id,
				tp.abn_id,
				tp.subs_id,
				tp.tech_id,
				tp.date_start,
				tp.new_abns,
				tp.daily_abns,
				tp.churn_abns,
				tp.change_tech_flag,
				tp.p24_qnt_end_rp_shpd,
				tp.p81_qnt_end_rp_ota,
				tp.p83_qnt_end_rp_iptv,
				tp.account,
				tp.dt,
				tp.src_id,
				tp.serv_id,
				tp.charge_only_flag,
				tp.hlid,
				tp.hgid,
				tp.P1_PERIOD,
				trim(dd.nls) nls
			from efftp tp
				inner join edw_ods.t_000158_efftp_south_nls_accnt dd
				on ( tp.account = dd.account
					and dd.date_end is null
					and dd.rf_id = tp.p3_rf_id)
			where 1 = 1
				and tp.rn = 1
				and tp.account is not null
				and coalesce(tp.charge_only_flag, 0) = 0
				and tp.serv_id in (1, 2, 3, 4, 5)
		)
		select t.dt,
			t.src_id,
			t.account,
			t.service_id,
			t.option_id,
			t.serv_id,
			t.tech_name_sao,
			t.hlid,
			t.hgid,
			EF.P1_PERIOD,
			ef.p3_rf_id,
			ef.abn_id,
			ef.subs_id,
			coalesce(ef.tech_id, -1) tech_id,
			ef.date_start,
			coalesce(ef.new_abns, 0) new_abns, 
			coalesce(ef.daily_abns, 0) daily_abns,
			decode(ef.churn_abns, 1, 1, 2, 1, null, 0) churn_abns,
			decode(ef.change_tech_flag, 1, 1, 3, 1, 2, 0, 0, 0, null, 0) migr,
			coalesce(ef.p24_qnt_end_rp_shpd, 0) + coalesce(ef.p81_qnt_end_rp_ota, 0) + coalesce(ef.p83_qnt_end_rp_iptv, 0)  end_per,
			row_number() over (partition by t.dt, t.mrf_id, /*dd.rf_id,*/ t.account, t.serv_id
								order by ef.dt, coalesce(ef.new_abns, 0) desc, coalesce(ef.daily_abns,0) desc, ef.date_start desc) rn
		from edw_stg_dm_efftp.tfct_mpz_efftp_map_1_prt_p000156 t
			/*,efftp*/, post_m ef 
			/*,edw_ods.t_000158_efftp_south_nls_accnt dd*/
		where 1 = 1
			--and ef.rn = 1
			and t.src_id in (154)
			and t.efftp_include = 0 
			and t.reason_absence is null 
			and ef.dt between t.dt and t.dt + interval '2 month'
			--and ef.serv_id in (1, 2, 3, 4, 5)
			--and coalesce(ef.charge_only_flag, 0) = 0
			--and ef.account is not null 
			--and ef.account = dd.account
			--and dd.date_end is null
			--and dd.rf_id = ef.p3_rf_id
			--and trim(dd.nls) = t.account
			and ef.nls = t.account
			and decode(ef.serv_id, 1, 1, 2, 2, 3, 3, 4, 3, 5, 1) = t.serv_id  
	)  fff
	where rn=1 
) r2
where 1 = 1
	and r.dt = r2.dt
	and r.service_id = r2.service_id
	and r.option_id = r2.option_id
	and r.account = r2.account
	and r.serv_id = r2.serv_id
	and r.efftp_include = 0
;


-- DS 5
update edw_stg_dm_efftp.tfct_mpz_efftp_map_1_prt_p000156 t
set abn_count = r.abn_count
from
(
	with efftp as 
	(
		select 
			tp.p3_rf_id,
			tp.abn_id,
			tp.subs_id,
			tp.tech_id,
			tp.date_start,
			tp.new_abns,
			tp.daily_abns,
			tp.churn_abns,
			tp.change_tech_flag,
			tp.p24_qnt_end_rp_shpd,
			tp.p81_qnt_end_rp_ota,
			tp.p83_qnt_end_rp_iptv,
			tp.account,
			date_trunc('month', tp.tech_dt) as dt,
			tp.src_id,
			tp.serv_id,
			tp.charge_only_flag,
			tp.hlid,
			tp.hgid,
			tp.P1_PERIOD,
			row_number() over(partition by tp.ABN_ID, tp.P1_PERIOD, case when tp.serv_id > 0 then 1 else 0 end
						order by case when coalesce(tp.p24_qnt_end_rp_shpd,0)+coalesce(tp.p81_qnt_end_rp_ota,0)+coalesce(tp.p83_qnt_end_rp_iptv,0) > 0 then 0 else 1 end) rn
		from edw_ods.t_000156_efftp_oo_eff_tp tp
		where 1 = 1
			and tp.P1_PERIOD between to_number(to_char(date_trunc('month', to_date('20190601', 'YYYYMMDD')), 'YYYYMM'), '999999') and to_number(to_char(date_trunc('month', to_date('20190630', 'YYYYMMDD') + interval '2 month'), 'YYYYMM'), '999999')
			and tp.tech_dt  >= date_trunc('month', to_date('20190601', 'YYYYMMDD'))::timestamp
			and tp.tech_dt  <= (date_trunc('month', to_date('20190630', 'YYYYMMDD')) + interval '3 month - 1 second')::timestamp
	)
	select 
		p1_period period,
		a.src_id,
		a.dt,
		a.p3_rf_id rf_id,
		trim(a.account) account,
		decode(a.serv_id, 1, 1, 2, 2, 3, 3, 4, 3, 5, 1 ) serv_id,
		count(*) abn_count
	from efftp a
	where 1 = 1
		and a.rn=1
		and a.serv_id in (1, 2, 3, 4, 5)
		and coalesce(a.CHARGE_ONLY_FLAG, 0) = 0
		and a.account is not null
		and exists
		(
			select null
			from edw_stg_dm_efftp.tfct_mpz_efftp_map_1_prt_p000156 s
			where 1 = 1
				and s.src_id != 154
				and s.efftp_include = 1
				and s.rf_id = a.p3_rf_id
				and s.account = a.account
				and s.serv_id = a.serv_id-- decode(a.serv_id, 1, 1, 2, 2, 3, 3, 4, 3, 5, 1)
				and s.period_coo = a.p1_period
				and s.dt = a.dt
		)
	group by 
		p1_period,
		a.src_id,
		a.dt,
		a.p3_rf_id,
		a.account,
		decode(a.serv_id, 1, 1, 2, 2, 3, 3, 4, 3, 5, 1)
)  r
where 1 = 1
	and t.efftp_include=1
	and t.rf_id = r.rf_id 
	and t.account = r.account
	and t.serv_id = r.serv_id
	and t.period_coo = r.period
	and t.dt = r.dt
	and t.src_id != 154
;

update edw_stg_dm_efftp.tfct_mpz_efftp_map_1_prt_p000156 t
set abn_count = r.abn_count
from
(
	with efftp as 
	(
		select 
			tp.p3_rf_id,
			tp.abn_id,
			tp.subs_id,
			tp.tech_id,
			tp.date_start,
			tp.new_abns,
			tp.daily_abns,
			tp.churn_abns,
			tp.change_tech_flag,
			tp.p24_qnt_end_rp_shpd,
			tp.p81_qnt_end_rp_ota,
			tp.p83_qnt_end_rp_iptv,
			tp.account,
			date_trunc('month', tp.tech_dt) as dt,
			tp.src_id,
			tp.serv_id,
			tp.charge_only_flag,
			tp.hlid,
			tp.hgid,
			tp.P1_PERIOD,
			row_number() over(partition by tp.ABN_ID, tp.P1_PERIOD, case when tp.serv_id > 0 then 1 else 0 end
						order by case when coalesce(tp.p24_qnt_end_rp_shpd,0)+coalesce(tp.p81_qnt_end_rp_ota,0)+coalesce(tp.p83_qnt_end_rp_iptv,0) > 0 then 0 else 1 end) rn
		from edw_ods.t_000156_efftp_oo_eff_tp tp
		where 1 = 1
			and tp.P1_PERIOD between to_number(to_char(date_trunc('month', to_date('20190601', 'YYYYMMDD')), 'YYYYMM'), '999999') and to_number(to_char(date_trunc('month', to_date('20190630', 'YYYYMMDD') + interval '2 month'), 'YYYYMM'), '999999')
			and tp.tech_dt  >= date_trunc('month', to_date('20190601', 'YYYYMMDD'))::timestamp
			and tp.tech_dt  <= (date_trunc('month', to_date('20190630', 'YYYYMMDD')) + interval '3 month - 1 second')::timestamp
	)
	select 
		p1_period period,
		a.src_id,
		a.dt,
		a.p3_rf_id rf_id,
		trim(dd.nls) account,
		decode(a.serv_id, 1, 1, 2, 2, 3, 3, 4, 3, 5, 1 ) serv_id,
		count(*) abn_count
	from efftp a,
		edw_ods.T_000158_EFFTP_SOUTH_NLS_ACCNT dd
	where 1 = 1
		and a.rn = 1
		and a.serv_id in (1, 2, 3, 4, 5)
		and coalesce(a.CHARGE_ONLY_FLAG, 0) = 0
		and a.account is not null
		and a.account = dd.account
		and dd.date_end is null
		and dd.rf_id = a.p3_rf_id
		and exists
		(
			select null
			from edw_stg_dm_efftp.tfct_mpz_efftp_map_1_prt_p000156 s
			where 1 = 1
				and s.dt = to_date('20190601', 'YYYYMMDD')::timestamp
				and s.src_id = 154
				and s.efftp_include = 1
				and s.rf_id = a.p3_rf_id
				and s.account = trim(dd.nls)
				and s.serv_id = a.serv_id-- decode(a.serv_id, 1, 1, 2, 2, 3, 3, 4, 3, 5, 1)
				and s.period_coo = a.p1_period
				and s.dt = a.dt
		)
	group by p1_period,
			a.src_id,
			a.dt,
			a.p3_rf_id,
			dd.nls,
			decode(a.serv_id, 1, 1, 2, 2, 3, 3, 4, 3, 5, 1)
)  r
where 1 = 1
	and t.efftp_include=1
	and t.rf_id = r.rf_id 
	and t.account = r.account
	and t.serv_id = r.serv_id
	and t.period_coo = r.period
	and t.dt = r.dt
	and t.src_id = 154
;


-- DS 6
insert into edw_stg_dm_efftp.tfct_mpz_efftp_map_1_prt_p000156
(
dt,
src_id,
mrf_id,
rf_id,
serv_id,
tech_id,
account,
sao_include,
efftp_include,
subs_id,
abn_id,
hgid,
hlid,
date_start,
abn_characteristic,
abn_count,
period_coo)
with efftp as 
(
	select 
		tp.p3_rf_id,
		tp.p2_mrf_id,
		tp.abn_id,
		tp.subs_id,
		tp.tech_id,
		tp.date_start,
		tp.new_abns,
		tp.daily_abns,
		tp.churn_abns,
		tp.change_tech_flag,
		tp.p24_qnt_end_rp_shpd,
		tp.p81_qnt_end_rp_ota,
		tp.p83_qnt_end_rp_iptv,
		tp.account,
		date_trunc('month', tp.tech_dt) as dt,
		tp.src_id,
		tp.serv_id,
		tp.charge_only_flag,
		tp.hlid,
		tp.hgid,
		tp.P1_PERIOD,
		row_number() over(partition by tp.ABN_ID, tp.P1_PERIOD, case when tp.serv_id > 0 then 1 else 0 end
					order by case when coalesce(tp.p24_qnt_end_rp_shpd,0)+coalesce(tp.p81_qnt_end_rp_ota,0)+coalesce(tp.p83_qnt_end_rp_iptv,0) > 0 then 0 else 1 end) rn
	from edw_ods.t_000156_efftp_oo_eff_tp tp
	where 1 = 1
		and tp.P1_PERIOD between to_number(to_char(date_trunc('month', to_date('20190601', 'YYYYMMDD')), 'YYYYMM'), '999999') and to_number(to_char(date_trunc('month', to_date('20190630', 'YYYYMMDD')), 'YYYYMM'), '999999')
		and tp.tech_dt  >= date_trunc('month', to_date('20190601', 'YYYYMMDD'))::timestamp
		and tp.tech_dt  <= (date_trunc('month', to_date('20190630', 'YYYYMMDD')))::timestamp
),
main as (
select
	a.dt,
	src_id,
	p2_mrf_id mrf_id,
	p3_rf_id  rf_id,
	decode(a.serv_id, 1, 1, 2, 2, 3, 3, 4, 3, 5, 1) serv_id,
	coalesce (a.tech_id, -1) tech_id,
	trim(a.account) account,
	0 sao_include,
	1 efftp_include,
	subs_id,
	abn_id,
	hgid,
	hlid,
	date_start,
	case when coalesce (a.new_abns,0)=1 then 'НОВЫЙ АБОНЕНТ'
		when coalesce (a.daily_abns,0)=1 then 'CУТОЧНЫЙ АБОНЕНТ'
		else null
	end abn_characteristic,
	1 abn_count,
	p1_period period_coo,
	row_number() over (partition by a.dt, a.p2_mrf_id, a.account, a.serv_id
                               order by coalesce(a.new_abns, 0) desc, coalesce(a.daily_abns,0) desc, a.date_start desc) rn
	from efftp a
	where 1 = 1
		and a.rn = 1
		and a.src_id in (151, 152, 153, 155, 156, 157)
		and a.serv_id in (1, 2, 3, 4, 5)
		and coalesce(a.charge_only_flag, 0) = 0 
		and a.account is not null
		and coalesce(a.new_abns, 0) + coalesce(a.daily_abns, 0) > 0
		and not exists
		(
			select null
			from edw_stg_dm_efftp.tfct_mpz_efftp_map_1_prt_p000156 tm
			where 1 = 1
				and tm.dt = a.dt
				and tm.efftp_include = 1
				and tm.account = a.account 
				and tm.serv_id = decode(a.serv_id, 1, 1, 2, 2, 3, 3, 4, 3, 5, 1)   
		)
)
select 
	dd.dt,
	dd.src_id,
	dd.mrf_id,
	dd.rf_id,
	dd.serv_id,
	dd.tech_id,
	dd.account,
	dd.sao_include,
	dd.efftp_include,
	dd.subs_id,
	dd.abn_id,
	dd.hgid,
	dd.hlid,
	dd.date_start,
	dd.abn_characteristic,
	dd.abn_count,
	dd.period_coo
from main dd
where dd.rn = 1
;


insert into edw_stg_dm_efftp.tfct_mpz_efftp_map_1_prt_p000156
(
dt,
src_id,
mrf_id,
rf_id,
serv_id,
tech_id,
account,
sao_include,
efftp_include,
subs_id,
abn_id,
hgid,
hlid,
date_start,
abn_characteristic,
abn_count,
period_coo)
with efftp as 
(
	select 
		tp.p3_rf_id,
		tp.p2_mrf_id,
		tp.abn_id,
		tp.subs_id,
		tp.tech_id,
		tp.date_start,
		tp.new_abns,
		tp.daily_abns,
		tp.churn_abns,
		tp.change_tech_flag,
		tp.p24_qnt_end_rp_shpd,
		tp.p81_qnt_end_rp_ota,
		tp.p83_qnt_end_rp_iptv,
		tp.account,
		date_trunc('month', tp.tech_dt) as dt,
		tp.src_id,
		tp.serv_id,
		tp.charge_only_flag,
		tp.hlid,
		tp.hgid,
		tp.P1_PERIOD,
		row_number() over(partition by tp.ABN_ID, tp.P1_PERIOD, case when tp.serv_id > 0 then 1 else 0 end
					order by case when coalesce(tp.p24_qnt_end_rp_shpd,0)+coalesce(tp.p81_qnt_end_rp_ota,0)+coalesce(tp.p83_qnt_end_rp_iptv,0) > 0 then 0 else 1 end) rn
	from edw_ods.t_000156_efftp_oo_eff_tp tp
	where 1 = 1
		and tp.P1_PERIOD between to_number(to_char(date_trunc('month', to_date('20190601', 'YYYYMMDD')), 'YYYYMM'), '999999') and to_number(to_char(date_trunc('month', to_date('20190630', 'YYYYMMDD')), 'YYYYMM'), '999999')
		and tp.tech_dt  >= date_trunc('month', to_date('20190601', 'YYYYMMDD'))::timestamp
		and tp.tech_dt  <= (date_trunc('month', to_date('20190630', 'YYYYMMDD')) + interval '1 day - 1 second')::timestamp
		and tp.src_id in (154)
),
main as (
	select
		--to_date($p_period,'YYYYMM') dt,
		a.dt,
		a.src_id,
		p2_mrf_id mrf_id,
		p3_rf_id  rf_id,
		a.serv_id  serv_id,
		coalesce (a.tech_id, -1) tech_id,
		trim(dd.nls) account,
		0 sao_include,
		1 efftp_include,
		subs_id,
		abn_id,
		hgid,
		hlid,
		date_start,
		case when coalesce (a.new_abns,0)=1 then 'НОВЫЙ АБОНЕНТ'
			when coalesce (a.daily_abns,0)=1 then 'CУТОЧНЫЙ АБОНЕНТ'
			else null
		end abn_characteristic,
		1 abn_count,
		p1_period period_coo,
		row_number() over (partition by a.dt, a.p2_mrf_id, a.account, a.serv_id
								order by coalesce(a.new_abns, 0) desc, coalesce(a.daily_abns,0) desc, a.date_start desc) rn
	from efftp a,
		edw_ods.t_000158_efftp_south_nls_accnt dd
	where 1 = 1
		and a.rn = 1
		and a.serv_id in (1, 2, 3, 4, 5)
		and coalesce(a.charge_only_flag, 0) = 0 
		and a.account is not null
		and a.account = dd.account
		and dd.date_end is null
		and dd.rf_id = a.p3_rf_id
		and coalesce(a.new_abns, 0) + coalesce(a.daily_abns, 0) > 0
		and not exists
		(
			select null
			from edw_stg_dm_efftp.tfct_mpz_efftp_map_1_prt_p000156 tm
			where 1 = 1
				and tm.dt = a.dt
				and tm.efftp_include = 1
				and tm.account = dd.nls
				and tm.serv_id = decode(a.serv_id, 1, 1, 2, 2, 3, 3, 4, 3, 5, 1)   
		)
)
select 
	dd.dt,
	dd.src_id,
	dd.mrf_id,
	dd.rf_id,
	dd.serv_id,
	dd.tech_id,
	dd.account,
	dd.sao_include,
	dd.efftp_include,
	dd.subs_id,
	dd.abn_id,
	dd.hgid,
	dd.hlid,
	dd.date_start,
	dd.abn_characteristic,
	dd.abn_count,
	dd.period_coo
from main dd
where dd.rn = 1
;


-- DS 7
update edw_stg_dm_efftp.tfct_mpz_efftp_map_1_prt_p000156 r
set tech_id_sao = r2.tech_id_sao,
    tech_name_sao = r2.tech_name_sao, 
    channel_name = r2.channel_name,
    sao_include = 1, 
    service_id = r2.service_id,
    insert_date = r2.insert_date,
    flat = r2.flat
from
(
---Выбираем записи ЭТП, добавленные на пред шаге и объединяем с данными МПЗ за 3 пердшеств расчетному месяца  ( ЛС, услуга)
select
a.dt,
a.src_id,
a.mrf_id,
a.abn_id,
a.account,
a.rf_id,
a.serv_id,
p.tech_id_sao,
p.tech_name_sao,
p.channel_name,
p.service_id,
p.insert_date,
p.flat
from edw_stg_dm_efftp.tfct_mpz_efftp_map_1_prt_p000156 a,
 (
	--- МПЗ за 3 предыдущих периода до расчетного, где выбрана одна  запись ближайшая к расчетному пер по ЛС, услуге .   
	select  
		ddd.*
	from (
		select
			decode(t.product_category, 1, 2, 5, 3, 2, 1) serv_id,
			decode(t.name_mrf,
					'МРФ Центр', 11,
					'МРФ Москва', 11,
					'МРФ Северо-Запад', 12,
					'МРФ Волга', 13,
					'МРФ ЮГ', 14,
					'МРФ Урал', 15,
					'МРФ Сибирь', 16,
					'МРФ Дальний Восток', 17,
					null, -1) as mrf_id,
			decode(t.name_mrf,
					'МРФ Центр', 151,
					'МРФ Москва', 151,
					'МРФ Северо-Запад', 152,
					'МРФ Волга', 153,
					'МРФ ЮГ', 154,
					'МРФ Урал', 155,
					'МРФ Сибирь', 156,
					'МРФ Дальний Восток', 157,
					null, -1) as src_id,
			to_number(to_char(t.date_change_state, 'YYYYMM'), '999999') period,
			cld.date_key as dt,
			t.service_id,
			t.channel_name,
			t.date_change_state,
			trim(t.acc_number) account,
			t.hgid,
			t.hlid,
			t.product_name,
			t.tech_id tech_id_sao,
			t.tech_name tech_name_sao,
			t.insert_date,
			substring(t.addr_office, 1, 10) flat,
			row_number() over (partition by t.name_mrf, t.product_category, acc_number, cld.date_key order by t.date_change_state desc)  rn
		from edw_ods.T_000171_dwh_mpz t
		inner join (select date_key from edw_dds.dim_calendar
					where date_key between to_date('20190601','YYYYMMDD') and to_date('20190630','YYYYMMDD')
					and date_key = month_start_date) cld
			on 1 = 1
		where 1 = 1
			and t.product_category in (2, 1, 5)
			and t.state_id = 7
			and t.acc_number is not null
			and LENGTH(trim(t.acc_number)) = 12       
			and t.date_change_state >= (cld.date_key + interval '-3 month')::timestamp
			and t.date_change_state <= (cld.date_key + interval '-1 second')::timestamp       
			and decode(t.name_mrf,
						'МРФ Центр', 151,
						'МРФ Москва', 151,
						'МРФ Северо-Запад', 152,
						'МРФ Волга', 153,
						'МРФ ЮГ', 154,
						'МРФ Урал', 155,
						'МРФ Сибирь', 156,
						'МРФ Дальний Восток', 157,
						null, -1) = 000156 
	) ddd
	where ddd.rn=1 
) p   
where 1 = 1
	and a.dt = p.dt
	and a.sao_include = 0
	and a.abn_id is not null  
	and a.src_id = p.src_id
	and a.account = p.account 
	and decode(a.serv_id, 1, 1, 2, 2, 3, 3, 4, 3, 5, 1) = p.serv_id
group by
	a.dt,
	a.src_id,
	a.mrf_id,
	a.abn_id,
	a.account,
	a.rf_id,
	a.serv_id,
	p.tech_id_sao,
	p.tech_name_sao,
	p.channel_name,
	p.service_id,
	p.insert_date,
	p.flat
) r2   
where 1 = 1
	and r.dt = r2.dt
	and r.sao_include=0
	and r.abn_id is not null
	and r.src_id = r2.src_id
	and r.rf_id = r2.rf_id
	and r.abn_id = r2.abn_id 
	and r.account = r2.account
	and decode(r.serv_id, 1, 1, 2, 2, 3, 3, 4, 3, 5, 1 ) = r2.serv_id
;
analyze edw_stg_dm_efftp.tfct_mpz_efftp_map_1_prt_p000156;
