/*rev. 10512 11.05.2018 */
truncate table edw_stg_dmcm.tfct_asrv;
insert into edw_stg_dmcm.tfct_ASRV(mrf_id,cm_id,accn_id,cstm_id,srvs_id,srvs_type,srvs_address,srvs_region,srvs_mr,srvs_tech,dt_start_srvs,srvs_member_id,tp_bandl,tp_full,tp_dmv,home_ownership_cnt,tp_gr,srvs_iptv_san,srvs_iptv_mac,srvs_ren_address,dev_ls_on,dev_ls_on_cnt,dev_ls_type,dev_ls_mod,eff_dttm
,exp_dttm,load_dttm)
SELECT mrf_id,cm_id,accn_id,cstm_id,srvs_id,srvs_type,srvs_address,srvs_region,srvs_mr,srvs_tech,dt_start_srvs,srvs_member_id,tp_bandl,tp_full,tp_dmv,home_ownership_cnt,tp_gr,srvs_iptv_san,srvs_iptv_mac,srvs_ren_address,dev_ls_on,dev_ls_on_cnt,dev_ls_type,dev_ls_mod,eff_dttm
,exp_dttm,load_dttm
FROM(
select distinct
OO_EFF_TP.P2_MRF_ID as mrf_id
,OO_EFF_TP.P2_MRF_ID||'#'||OO_EFF_TP.ACCOUNT as cm_id
,OO_EFF_TP.ACCOUNT as accn_id
,OO_EFF_TP.ACCOUNT as cstm_id
,OO_EFF_TP.SERV_ID as srvs_id
,dir_services.DEF as srvs_type
,SUBSCRIBERS_ACTUAL.ADRESS as srvs_address
,OO_EFF_TP.P3_RF_ID as srvs_region
,OO_EFF_TP.P2_MRF_ID as srvs_mr
,DIR_TECH.DEF as srvs_tech
,OO_EFF_TP.DATE_START as dt_start_srvs
,OO_EFF_TP.LOGIN as srvs_member_id
,'-1' as tp_bandl
,OO_EFF_TP.RTPL_NAME as tp_full
,'-1' as tp_dmv
,-1 as home_ownership_cnt
,VRATE_PLANS_DWH.RTPL_GROUP_NAME as tp_gr
,'-1' as srvs_iptv_san
,'-1'  as srvs_iptv_mac
,SUBSCRIBERS_ACTUAL.ADRESS_DEV as srvs_ren_address
,OO_EFF_TP.IS_ARENDA_SUBS as dev_ls_on
,-1  as dev_ls_on_cnt
,-1  as dev_ls_type
,'-1'  as dev_ls_mod
,TO_DATE(OO_EFF_TP.P1_PERIOD,'YYYYMM') AS eff_dttm
,to_date(OO_EFF_TP.P1_PERIOD,'YYYYMM') + INTERVAL'1 month - 1 second' AS exp_dttm
,now() as load_dttm
from edw_ods.t_000132_OO_EFF_TP OO_EFF_TP
left join edw_ods.t_000132_dir_services dir_services on OO_EFF_TP.serv_id = dir_services.serv_id
left join edw_ods.t_000132_dir_tech dir_tech on OO_EFF_TP.TECH_ID = dir_tech.TECH_ID
left join edw_ods.t_000132_SUBSCRIBERS_ACTUAL SUBSCRIBERS_ACTUAL on OO_EFF_TP.account = SUBSCRIBERS_ACTUAL.account and OO_EFF_TP.P2_mrf_id = SUBSCRIBERS_ACTUAL.mrf_id and OO_EFF_TP.P3_rf_id = SUBSCRIBERS_ACTUAL.rf_id and OO_EFF_TP.abn_id = SUBSCRIBERS_ACTUAL.abn_id and OO_EFF_TP.clie_id = SUBSCRIBERS_ACTUAL.clie_id
left join edw_ods.t_000132_VRATE_PLANS_DWH VRATE_PLANS_DWH on OO_EFF_TP.account = VRATE_PLANS_DWH.account and OO_EFF_TP.P2_mrf_id = VRATE_PLANS_DWH.mrf_id and OO_EFF_TP.P3_rf_id = VRATE_PLANS_DWH.rf_id and OO_EFF_TP.abn_id = VRATE_PLANS_DWH.abn_id and OO_EFF_TP.clie_id = VRATE_PLANS_DWH.clie_id
LEFT JOIN edw_ods.t_000132_DIR_BRANCHES DIR_BRANCHES_1 ON OO_EFF_TP.P2_MRF_ID = DIR_BRANCHES_1.BRNC_ID
LEFT JOIN edw_ods.t_000132_DIR_BRANCHES DIR_BRANCHES_2 ON OO_EFF_TP.P3_RF_ID = DIR_BRANCHES_2.BRNC_ID
where OO_EFF_TP.tech_dt = to_date('20190601', 'YYYYMMDD')
)SSS;


analyse edw_stg_dmcm.tfct_asrv;