-- rev. 59691 от 02.06.2020

SET optimizer = ON;
SET search_path = edw_stg_dm_b2b;
--SET client_min_messages = ERROR; -- только wrk скрипт
COMMIT;

-- справочник сегментов
SET gp_recursive_cte_prototype = 'true';

BEGIN;
  TRUNCATE TABLE edw_stg_dm_b2b.pre_serv_sales_trad_segment_1_prt_p000005;
COMMIT;

BEGIN;
INSERT INTO edw_stg_dm_b2b.pre_serv_sales_trad_segment_1_prt_p000005
  (source_key, segment_key, macro_segment_key, src_id)
WITH
recursive r(source, root, segment_key, parent_segment_key, path, level, cycle) AS
(
  SELECT 'CHILD' AS source,
         vdcs.source_key AS root,
         edcs.segment_key,
         edcs.parent_segment_key,
         ARRAY [ edcs.segment_key ],
         1,
         FALSE
    FROM edw_dds.hub_dim_segment vdcs
         JOIN
         edw_dds.dim_segment edcs
           ON edcs.segment_key = vdcs.segment_key
          AND date_trunc('day', edcs.exp_dttm) = to_date('2999-12-31', 'yyyy-mm-dd')
          AND edcs.deleted_ind = 0
   WHERE vdcs.src_id = 000005
     AND date_trunc('day', vdcs.exp_dttm) = to_date('2999-12-31', 'yyyy-mm-dd')
   UNION ALL
  SELECT 'PARENT' AS source,
         r.root AS root,
         edcs.segment_key,
         edcs.parent_segment_key,
         r.path || edcs.segment_key,
         r.level + 1 AS level,
         edcs.segment_key = ANY(r.path)
    FROM edw_dds.dim_segment edcs
         JOIN
         r
           ON edcs.segment_key = r.parent_segment_key
          AND date_trunc('day', edcs.exp_dttm) = to_date('2999-12-31', 'yyyy-mm-dd')
          AND edcs.deleted_ind = 0
          AND edcs.parent_segment_key <> '-1'
          AND NOT cycle
)
SELECT r.root AS source_key,
       r.segment_key,
       r2.segment_key AS macro_segment_key,
       000005::smallint AS src_id
  FROM r
       JOIN
       r r2
         ON r2.root = r.root
        AND r2.level = (SELECT MAX(level) FROM r rr WHERE rr.root = r.root)
 WHERE r.source = 'CHILD';
COMMIT;

BEGIN;
  TRUNCATE TABLE edw_stg_dm_b2b.tfct_serv_sales_1_prt_p000005;
COMMIT;

BEGIN;
INSERT INTO edw_stg_dm_b2b.tfct_serv_sales_1_prt_p000005
(
  period,
  service_key,
  business_service_key,
  branch_key,
  segment_key,
  macro_segment_key,
  client_name,
  inn,
  account,
  subs_src_id,
  subs_login,
  subs_activation_dt,
  order_num,
  order_dt,
  sales_channel_key,
  sales_channel,
  seller_name,
  iptv_type_id,
  shpd_migration_flg,
  serv_qnty,
  sale_serv_id,
  load_dttm,
  src_id
)
WITH
-- справочник абонентообразующих (постоянных) услуг
c_svc_ref AS
(
  SELECT CASE WHEN sl.svc_id = -1 THEN lb.svc_id ELSE sl.svc_id END AS svc_id,
         sl.service_key,
         lb.id_cell_svc
    FROM edw_ods.t_000005_ekhd_hub_svc_volga sl
         LEFT JOIN
         edw_ods.t_000008_t_svc_layer_bunch lb
           ON lb.id_cell_svc = sl.id_cell_svc
          AND date_trunc('day', to_date('20190630', 'YYYYMMDD')) + interval '1 day - 1 second' >= lb.eff_dttm
          AND date_trunc('day', to_date('20190630', 'YYYYMMDD')) <= lb.exp_dttm
          AND lb.deleted_ind = 0
   WHERE report_type = 'abonent'
     AND date_trunc('day', to_date('20190630', 'YYYYMMDD')) + interval '1 day - 1 second' >= sl.eff_dttm
     AND date_trunc('day', to_date('20190630', 'YYYYMMDD')) <= sl.exp_dttm
     AND sl.deleted_ind = 0
),
-- справочник разовых (ПД, ПЕРЕКЛЮЧЕНИЕ) услуг
o_svc_ref AS
(
  SELECT sl.cnt_type_alt,
         CASE WHEN sl.svc_id = -1 THEN lb.svc_id ELSE sl.svc_id END AS svc_id,
         sl.service_key,
         sl.type_order
    FROM edw_ods.t_000005_ekhd_hub_svc_volga sl
         LEFT JOIN
         edw_ods.t_000008_t_svc_layer_bunch lb
           ON lb.id_cell_svc = sl.id_cell_svc
          AND date_trunc('day', to_date('20190630', 'YYYYMMDD')) + interval '1 day - 1 second' >= lb.eff_dttm
          AND date_trunc('day', to_date('20190630', 'YYYYMMDD')) <= lb.exp_dttm
          AND lb.deleted_ind = 0
   WHERE report_type = 'dynamic'
     AND date_trunc('day', to_date('20190630', 'YYYYMMDD')) + interval '1 day - 1 second' >= sl.eff_dttm
     AND date_trunc('day', to_date('20190630', 'YYYYMMDD')) <= sl.exp_dttm
     AND sl.deleted_ind = 0
),
t_vip AS
(
  SELECT vip.user_id_vip,
         vip.user_id_sp,
         uv.dept_id,
         uv.user_type_id,
         uv.inn
    FROM edw_ods.t_000005_t_vip vip
         JOIN
         edw_ods.t_000005_t_users uv
           ON vip.user_id_vip = uv.user_id
          AND date_trunc('day', to_date('20190630', 'YYYYMMDD')) + interval '1 day - 1 second' >= uv.eff_dttm
          AND date_trunc('day', to_date('20190630', 'YYYYMMDD')) <= uv.exp_dttm
          AND uv.deleted_ind = 0
   WHERE vip.date_begin <= date_trunc('month', to_date('20190630', 'YYYYMMDD') + interval '1 month - 1 second')
     AND (vip.date_end IS NULL OR vip.date_end >= date_trunc('month', to_date('20190630', 'YYYYMMDD')) + interval '1 month - 1 second')
     AND date_trunc('day', to_date('20190630', 'YYYYMMDD')) + interval '1 day - 1 second' >= vip.eff_dttm
     AND date_trunc('day', to_date('20190630', 'YYYYMMDD')) <= vip.exp_dttm
     AND vip.deleted_ind = 0
),
t_vip_sp AS
(
  SELECT vip.user_id_vip,
         vip.user_id_sp,
         uv.dept_id,
         uv.user_type_id,
         uv.inn
    FROM edw_ods.t_000005_t_vip_sp vip
         JOIN
         edw_ods.t_000005_t_users uv
           ON vip.user_id_vip = uv.user_id
          AND date_trunc('day', to_date('20190630', 'YYYYMMDD')) + interval '1 day - 1 second' >= uv.eff_dttm
          AND date_trunc('day', to_date('20190630', 'YYYYMMDD')) <= uv.exp_dttm
          AND uv.deleted_ind = 0
   WHERE date_trunc('day', to_date('20190630', 'YYYYMMDD')) + interval '1 day - 1 second' >= vip.eff_dttm
     AND date_trunc('day', to_date('20190630', 'YYYYMMDD')) <= vip.exp_dttm
     AND vip.deleted_ind = 0
),
-- справочник МРФ/РФ
dim_branch AS
(
  SELECT hub.source_key,
         br.branch_key
    FROM edw_dds.hub_dim_branch hub
         LEFT JOIN
         edw_dds.dim_branch br
           ON hub.branch_key = br.branch_key
          AND br.deleted_ind = 0
          AND date_trunc('day', br.exp_dttm) = to_date('2999-12-31', 'yyyy-mm-dd')
         LEFT JOIN
         edw_dds.dim_branch brp
           ON br.parent_branch_key = brp.branch_key
          AND brp.deleted_ind = 0
          AND date_trunc('day', brp.exp_dttm) = to_date('2999-12-31', 'yyyy-mm-dd')
   WHERE hub.src_id = 000005::smallint
     AND date_trunc('day', hub.exp_dttm) = to_date('2999-12-31', 'yyyy-mm-dd')
),
-- справочник услуг
dim_service AS
(
  SELECT svc.service_key,
         bs.business_service_key
    FROM edw_dds.dim_service svc
         LEFT JOIN
         edw_dds.dim_business_service bs
           ON svc.business_service_key = bs.business_service_key
          AND bs.deleted_ind = 0
          AND date_trunc('day', bs.exp_dttm) = to_date('2999-12-31', 'yyyy-mm-dd')
   WHERE svc.deleted_ind = 0
     AND date_trunc('day', svc.exp_dttm) = to_date('2999-12-31', 'yyyy-mm-dd')
),
-- определяем список закрытых нарядов
ol AS
(
  SELECT ol.num_list,
         CASE
           WHEN o_svc_ref.type_order = 1 THEN coalesce(s1.service_id, s2.service_id)
           ELSE coalesce(s3.service_id, s4.service_id)
         END AS service_id,
         CASE
           WHEN o_svc_ref.type_order = 1 THEN coalesce(s1.serv_first_id, s2.serv_first_id)
           ELSE coalesce(s3.serv_first_id, s4.serv_first_id)
         END AS serv_first_id,
         CASE
           WHEN o_svc_ref.type_order = 1 THEN coalesce(s1.svc_nmb, s2.svc_nmb)
           ELSE coalesce(s3.svc_nmb, s4.svc_nmb)
         END AS svc_nmb,
         CASE
           WHEN o_svc_ref.type_order = 1 THEN coalesce(s1.user_id, s2.user_id, np.user_id)
           ELSE coalesce(s3.user_id, s4.user_id, ol.user_id)
         END AS user_id,
         CASE
           WHEN o_svc_ref.type_order = 1 THEN coalesce(s1.dev_id, s2.dev_id, np.dev_id)
           ELSE coalesce(s3.dev_id, s4.dev_id, ol.dev_id)
         END AS dev_id,
         CASE
           WHEN o_svc_ref.type_order = 1 THEN coalesce(s1.svc_id, s2.svc_id, np.svc_id)
           ELSE coalesce(s3.svc_id, s4.svc_id)
         END AS c_svc_id,
         CASE
           WHEN o_svc_ref.type_order = 1 THEN coalesce(s1.date_begin, s2.date_begin)
           ELSE coalesce(s3.date_begin, s4.date_begin)
         END AS date_begin,
         CASE
           WHEN o_svc_ref.cnt_type_alt = 'migration_tt_qnt' THEN 1
           ELSE 0
         END AS action_type,
         f.date_sys,
         coalesce(trunc(or_num.num_order, 0) ::text || '/' ::text || trunc(or_num_l.n_lst_ord, 0) ::text, trunc(or_num.num_order, 0) ::text) AS num_order,
         nco1.value_str AS salesgroup,
         nco2.value_str AS salespersonname,
         nco3.name
    FROM edw_ods.t_000005_n_order_lists ol
         JOIN
         edw_ods.t_000005_n_order_life f
           ON ol.num_list = f.num_list
          AND ol.last_action_id = f.action_id
          AND f.type_action_id = 4
          AND f.active_ind = 'Y'
          AND f.deleted_ind = 0
          AND date_trunc('month', to_date('20190630', 'YYYYMMDD')) + interval '1 month - 1 second' >= f.date_sys
          AND date_trunc('month', to_date('20190601', 'YYYYMMDD')) <= f.date_sys
         JOIN
         o_svc_ref
           ON o_svc_ref.svc_id = ol.id_svc
         JOIN
         edw_ods.t_000005_n_planned_services np
           ON ol.num_list = np.num_list
          AND date_trunc('day', to_date('20190630', 'YYYYMMDD')) + interval '1 day - 1 second' >= np.eff_dttm
          AND date_trunc('day', to_date('20190630', 'YYYYMMDD')) <= np.exp_dttm
         LEFT JOIN
         edw_ods.t_000005_t_services s1
           ON o_svc_ref.type_order = 1
          AND np.plan_service_id = s1.service_id
          AND ((s1.svctype = '0' AND (s1.phone IS NULL OR (upper(s1.phone) NOT LIKE '%П%' AND s1.phone NOT LIKE '%М%' AND s1.phone NOT LIKE '%К%' AND
              s1.phone NOT LIKE '%Д%' AND s1.phone NOT LIKE '%С%' AND s1.phone NOT LIKE '%В%'))) OR s1.svctype = '1')
          AND s1.deleted_ind = 0
          AND date_trunc('day', to_date('20190630', 'YYYYMMDD')) + interval '1 day - 1 second' >= s1.eff_dttm
          AND date_trunc('day', to_date('20190630', 'YYYYMMDD')) <= s1.exp_dttm
         LEFT JOIN
         edw_ods.t_000005_t_services s2
           ON s1.service_id IS NULL
          AND o_svc_ref.type_order = 1
          AND ol.service_id = s2.service_id
          AND ((s2.svctype = '0' AND (s2.phone IS NULL OR (upper(s2.phone) NOT LIKE '%П%' AND s2.phone NOT LIKE '%М%' AND s2.phone NOT LIKE '%К%' AND
              s2.phone NOT LIKE '%Д%' AND s2.phone NOT LIKE '%С%' AND s2.phone NOT LIKE '%В%'))) OR s2.svctype = '1')
          AND s2.deleted_ind = 0
          AND date_trunc('day', to_date('20190630', 'YYYYMMDD')) + interval '1 day - 1 second' >= s2.eff_dttm
          AND date_trunc('day', to_date('20190630', 'YYYYMMDD')) <= s2.exp_dttm
         LEFT JOIN
         edw_ods.t_000005_t_services s3
           ON o_svc_ref.type_order = -1
          AND ol.service_id = s3.service_id
          AND ((s3.svctype = '0' AND (s3.phone IS NULL OR (upper(s3.phone) NOT LIKE '%П%' AND s3.phone NOT LIKE '%М%' AND s3.phone NOT LIKE '%К%' AND
              s3.phone NOT LIKE '%Д%' AND s3.phone NOT LIKE '%С%' AND s3.phone NOT LIKE '%В%'))) OR s3.svctype = '1')
          AND s3.deleted_ind = 0
          AND date_trunc('day', to_date('20190630', 'YYYYMMDD')) + interval '1 day - 1 second' >= s3.eff_dttm
          AND date_trunc('day', to_date('20190630', 'YYYYMMDD')) <= s3.exp_dttm
         LEFT JOIN
         edw_ods.t_000005_t_services s4
           ON s3.service_id IS NULL
          AND o_svc_ref.type_order = -1
          AND np.plan_service_id = s4.service_id
          AND ((s4.svctype = '0' AND (s4.phone IS NULL OR (upper(s4.phone) NOT LIKE '%П%' AND s4.phone NOT LIKE '%М%' AND s4.phone NOT LIKE '%К%' AND
              s4.phone NOT LIKE '%Д%' AND s4.phone NOT LIKE '%С%' AND s4.phone NOT LIKE '%В%'))) OR s4.svctype = '1')
          AND s4.deleted_ind = 0
          AND date_trunc('day', to_date('20190630', 'YYYYMMDD')) + interval '1 day - 1 second' >= s4.eff_dttm
          AND date_trunc('day', to_date('20190630', 'YYYYMMDD')) <= s4.exp_dttm
         LEFT JOIN
         edw_ods.t_000005_n_titul_order or_num
           ON ol.id_titul_order = or_num.id_titul_order
          AND date_trunc('day', to_date('20190630', 'YYYYMMDD')) + interval '1 day - 1 second' >= or_num.eff_dttm
          AND date_trunc('day', to_date('20190630', 'YYYYMMDD')) <= or_num.exp_dttm
         LEFT JOIN
         edw_ods.t_000005_n_list_exec or_num_l
           ON ol.num_list = or_num_l.num_list
          AND date_trunc('day', to_date('20190630', 'YYYYMMDD')) + interval '1 day - 1 second' >= or_num_l.eff_dttm
          AND date_trunc('day', to_date('20190630', 'YYYYMMDD')) <= or_num_l.exp_dttm
         LEFT JOIN
         edw_ods.t_000005_n_contents_orders nco1
           ON nco1.str_order = 'Сотрудник B2B/B2G'
          AND ol.last_action_id = nco1.action_id
          AND ol.num_list = nco1.num_list
         LEFT JOIN
         edw_ods.t_000005_n_contents_orders nco2
           ON nco2.str_order = 'Дилер/Агент'
          AND ol.last_action_id = nco2.action_id
          AND ol.num_list = nco2.num_list
         LEFT JOIN
         edw_ods.t_000005_usdeal_sales_channels nco3
           ON nco3.id = CASE
                          WHEN o_svc_ref.type_order = 1 THEN coalesce(s1.deal_sale_chan_id, s2.deal_sale_chan_id)
                          ELSE coalesce(s3.deal_sale_chan_id, s4.deal_sale_chan_id)
                        END
   WHERE ol.id_condition = 4
     AND date_trunc('day', to_date('20190630', 'YYYYMMDD')) + interval '1 day - 1 second' >= ol.eff_dttm
     AND date_trunc('day', to_date('20190630', 'YYYYMMDD')) <= ol.exp_dttm
)

SELECT date_trunc('month', ol.date_sys) AS period,
       dim_service.service_key,
       dim_service.business_service_key,
       coalesce(dim_branch.branch_key, -1) AS branch_key,
       dim_segment.segment_key,
       coalesce(dim_segment.macro_segment_key, -1) AS macro_segment_key,
       u.name AS client_name,
       coalesce(t_vip.inn, t_vip_sp.inn, u.inn) AS inn,
       u.account,
       u.src_id || '#' || ol.user_id AS subs_src_id,
       ol.dev_id || '#' || ol.serv_first_id AS subs_login,
       ol.date_begin AS subs_activation_dt,
       ol.num_order AS order_num,
       ol.date_sys AS order_dt,
       NULL AS sales_channel_key,
       ol.salesgroup AS sales_channel,
       ol.salespersonname AS seller_name,
       CASE
         WHEN c_svc_ref.id_cell_svc IN (654725931, 654725937, 654725941, 654725935) THEN
          1
         WHEN c_svc_ref.id_cell_svc = 703118623 THEN
          2
         WHEN c_svc_ref.id_cell_svc IN (15380338397, 1001402853563, 3852805, 3853114, 1000257309963) THEN
          3
       END AS iptv_type_id,
       ol.action_type AS shpd_migration_flg,
       ol.svc_nmb AS serv_qnty,
       coalesce(u.account, '-1') || '#' || coalesce(ol.dev_id, '-1') || '#' || coalesce(ol.serv_first_id, '-1') AS sale_serv_id,
       now() AS load_dttm,
       u.src_id
  FROM ol
       JOIN
       edw_ods.t_000005_t_users u
         ON ol.user_id = u.user_id
        AND date_trunc('day', to_date('20190630', 'YYYYMMDD')) + interval '1 day - 1 second' >= u.eff_dttm
        AND date_trunc('day', to_date('20190630', 'YYYYMMDD')) <= u.exp_dttm
        AND u.deleted_ind = 0
       JOIN
       edw_ods.t_000005_t_user_type_ref ut
         ON u.user_type_id = ut.user_type_id
        AND ut.iscorp = 'Y'
        AND date_trunc('day', to_date('20190630', 'YYYYMMDD')) + interval '1 day - 1 second' >= ut.eff_dttm
        AND date_trunc('day', to_date('20190630', 'YYYYMMDD')) <= ut.exp_dttm
        AND ut.deleted_ind = 0
       JOIN
       c_svc_ref
         ON c_svc_ref.svc_id ::text = ol.c_svc_id ::text
       JOIN
       dim_service
         ON dim_service.service_key = c_svc_ref.service_key
       LEFT JOIN
       t_vip
         ON ol.user_id = t_vip.user_id_sp
       LEFT JOIN
       t_vip_sp
         ON ol.user_id = t_vip_sp.user_id_sp
       JOIN
       edw_stg_dm_b2b.pre_serv_sales_trad_segment_1_prt_p000005 dim_segment
         ON dim_segment.source_key = coalesce(t_vip.user_type_id, t_vip_sp.user_type_id, ut.user_type_id) ::text
       JOIN
       dim_branch
         ON dim_branch.source_key = coalesce(t_vip.dept_id, t_vip_sp.dept_id, u.dept_id) ::text;
COMMIT;

BEGIN;
  ANALYZE edw_stg_dm_b2b.tfct_serv_sales_1_prt_p000005;
COMMIT;