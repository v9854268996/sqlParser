/*rev.30133 04.06.2019*/
/*
	000069			-	Код СИ StartIP. Значения: 000063-000077
	000054		-	Код СИ Start. Значения: 000048-000062
	69				-	Код СИ StartIP. Значения: 48-62
	
	20190601			-	Дата начала расчетного периода. Значение в формате YYYYMMDD
	YYYYMMDD			-	Формат даты. Значение: YYYYMMDD
	
	edw_ods			-	Схема ODS. Значение: EDW_ODS
	edw_dds			-	Схема DDS. Значение: EDW_DDS
	edw_stg_dm_efftp			- 	EDW_STG_DM_EFFTP
	EDW_DM_EFFTP		-	EDW_DM_EFFTP
	YYYYMM		-	Формат месяца. Значение: YYYYMM
*/

truncate table edw_stg_dm_efftp.tfct_sdp_vitrina_detail_1_prt_p000069;

insert into edw_stg_dm_efftp.tfct_sdp_vitrina_detail_1_prt_p000069
	(
	PERIOD,
	MRF,
	RF,
	ACCOUNT,
	SAN,
	ABN_ID,
	SUBS_ID,
	NAME_PACK_ASR,
	NAME_PACK_STANDART,
	FLAG_TYPE_PACK,
	FLAG_PACK_BEGIN,
	FLAG_PACK_END,
	DT,
	SRC_ID,
	ID_ASR_PACK
	)
with 
	dates as 
(
	select 'B' be_flag, to_date('20190601','YYYYMMDD') DATE_ union all 
	select 'E' be_flag, to_date('20190601','YYYYMMDD') + interval '1 month - 1 second' DATE_
),
	tusa as 
(
	select 
		usa_uss_logname	
		,usa_sl_type	
		,usa_sat_name	
		,usa_value
		,load_dttm	
		,src_id	
		,package_id	
		,wf_run_id	
		,tech_dt
	from 
		edw_ods.t_000069_tb_user_serv_attrs atr
	where 1 = 1
		and substring(atr.USA_VALUE::text, '[a-zA-Z]') is not null -- Есть буквы в строке, тогда считаем что это не TIMESTAMP
),
	ChanelPackageName as 
(
	select 
		d.be_flag,
		p.itvpf_code, 
		pic.itvpic_itvpc_id, 
		pic.itvpic_itvcp_id, 
		pic.itvpic_srd_code, 
		pc.itvpc_itvpct_code, 
		cp.itvcp_external_id, 
		cp.itvcp_id,
		cp.itvcp_name
	from 
		edw_ods.T_000069_IPTV_PACKAGES_IN_CATEGORY pic
		JOIN edw_ods.T_000069_IPTV_PACKAGE_CATEGORIES pc
			on 1 = 1
			and pic.itvpic_itvpc_id = pc.itvpc_id
			and pic.deleted_ind = 0
			and pc.deleted_ind = 0			
		JOIN DATES D 
			on 1 = 1
			and D.DATE_ between PIC.Eff_dttm and PIC.Exp_dttm
			and D.DATE_ between PC.Eff_dttm and PC.Exp_dttm
		JOIN edw_ods.T_000069_IPTV_PROFILES p
			on 1 = 1
			and pc.itvpc_itvpf_id = p.itvpf_id	
			and D.DATE_ between P.Eff_dttm and P.Exp_dttm
		JOIN edw_ods.T_000069_IPTV_CHANNEL_PACKAGES cp  
			on 1 = 1
			and pic.itvpic_itvcp_id = cp.itvcp_id
			and cp.deleted_ind = 0			
			and D.DATE_ between CP.Eff_dttm and CP.Exp_dttm			
),
	ChanelPackage as 
(
	select 
		d.be_flag,
		CUS.uss_us_user_name, 
		USA.usa_value,
		USA.USA_USS_LOGNAME,
		case
			when upper(CUS.uss_sl_type) = 'IPTVSTB' then 'НОВАЯ ПЛАТФОРМА'
		end ind 
	from 
		tusa USA 
		join edw_ods.T_000069_CT_USER_SERVICES CUS
			on 1 = 1
			and lower(USA.usa_sl_type) = lower(CUS.uss_sl_type)
			and lower(CUS.uss_logname) = lower(USA.usa_uss_logname)
			and lower(USA.usa_sl_type) = lower('IPTV')
			and lower(USA.usa_sat_name) = lower('IPTV_ChanelPackage')
			and CUS.deleted_ind = 0
		JOIN DATES D
			on 1 = 1
			and D.DATE_ between CUS.Eff_dttm and CUS.Exp_dttm
		join edw_ods.T_000069_ABONENT A
			on 1 = 1 
			and A.ab_id = CUS.uss_ab_id
			and upper(A.ab_ur_ustp) != 'TEST'
			and A.deleted_ind = 0
			and D.DATE_ between A.Eff_dttm and A.Exp_dttm
),
	ProfileCode as 
(
	select 
		d.be_flag,
		CUS.uss_us_user_name, 
		USA.usa_value,
		USA.USA_USS_LOGNAME,
		A.ab_ur_ustp,
		A.ab_account 
	from 
		tusa USA 
		join edw_ods.T_000069_CT_USER_SERVICES CUS
			on 1 = 1
			and USA.usa_sl_type = CUS.uss_sl_type
			and CUS.uss_logname = USA.usa_uss_logname
			and USA.usa_sl_type = 'IPTV'
			and USA.usa_sat_name ='IPTV_ProfileCode'
			and CUS.deleted_ind = 0
		JOIN DATES D
			on 1 = 1
			and D.DATE_ between CUS.Eff_dttm and CUS.Exp_dttm			
		join edw_ods.T_000069_ABONENT A 
			on 1 = 1
			and A.ab_id = CUS.uss_ab_id
			and A.ab_ur_ustp != 'TEST' 
			and A.deleted_ind = 0
			and D.DATE_ between A.Eff_dttm and A.Exp_dttm
		join edw_ods.T_000069_CT_USERS CU
			on 1 = 1	
			and CUS.uss_us_user_name = CU.us_user_name 
			and CU.us_tfp_code not in ('TVS_Tech', 'TVS_DEMO', 'TVS_Web', 'TVS_NEW_UI')
			and CU.us_uc_code not in ('TVZ','IPTAR','TVSWB','TVSWB','TVTCH','TVDEM','TVSWB','iTVSW','kPTVD','kTVSW','oTVSW','TVdem','Test','oTVST','DialS','rTVSW','rTVST','IPTVD','sTVSW','IPTVD','sTVST','TVSO','IPTVE','SL','TVSWB','TVSDM','yPTVD','yTVSW')
),
	ActivateUser as 
(
	select
		d.be_flag,
		CUS.uss_us_user_name,
		USA.usa_value,
		USA.USA_USS_LOGNAME,
		A.AB_LR_LEGAL_STATUS,
		P.PRV_NAME 
	from 
		tusa USA
		join edw_ods.T_000069_CT_USER_SERVICES CUS
			on 1 = 1
			and USA.usa_sl_type = CUS.uss_sl_type
			and USA.usa_uss_logname = CUS.uss_logname
			and USA.usa_sl_type = 'IPTV'
			and USA.usa_sat_name ='IPTV_ActivationDate'
			and CUS.deleted_ind = 0
		JOIN DATES D
			on 1 = 1
			and D.DATE_ between CUS.Eff_dttm and CUS.Exp_dttm
		join edw_ods.T_000069_ABONENT A
			on 1 = 1
			and CUS.uss_ab_id = A.ab_id
			and A.ab_ur_ustp != 'TEST'	
			and A.deleted_ind = 0
			and D.DATE_ between A.Eff_dttm and A.Exp_dttm	
		join edw_ods.T_000069_PROVIDERS P  
			on 1 = 1 
			and A.AB_PRV_ID = P.PRV_ID
			and D.DATE_ between P.Eff_dttm and P.Exp_dttm
),
	main1 as 
(
	select
		cpn.be_flag,
		CPN.itvcp_id,
		CPN.itvcp_name,
		decode(AU.usa_value,null,'N','Y') usa_value,
		CP.ind, 
		count(1) as cnt,
		PC.ab_ur_ustp,
		PC.ab_account
	from 
		ChanelPackageName cpn
		join ChanelPackage cp
			on 1 = 1
			and cpn.itvcp_external_id = cp.usa_value
			and cpn.be_flag = cp.be_flag
		join ProfileCode pc
			on 1 = 1
			and cp.uss_us_user_name = pc.uss_us_user_name
			and cpn.itvpf_code = pc.usa_value
			and cpn.be_flag = pc.be_flag
		left join ActivateUser au
			on 1 = 1
			and pc.uss_us_user_name = au.uss_us_user_name
			and pc.be_flag = au.be_flag
/*		left join (select * from 
					public.T_MDV_TB_USER_SERV_ATTRS	--edw_ods.T_000069_TB_USER_SERV_ATTRS 
					where USA_VALUE is not null
						and src_id = 63
					) x 
			on 1 = 1
			and pc.USA_USS_LOGNAME = x.USA_USS_LOGNAME
	where 1 = 1
		and x.USA_USS_LOGNAME is null */
	group by 
		cpn.be_flag,
		CPN.itvcp_id,
		cpn.itvcp_name, 
		decode(AU.usa_value,null,'N','Y'),
		CP.ind,
		PC.ab_ur_ustp,
		PC.ab_account
),
	main2 as 
(
	select 
		be_flag,
		itvcp_id,
		coalesce(itvcp_name,'1.Итого по всем пакетам') itvcp_name,
		decode(usa_value,'Y','Активация выполнена','N','Активация не выполнена','Итого по пакету') as usa_value,
		ind, 
		cnt,
		ab_ur_ustp,
		ab_account
	from
		main1
),
	traf as -- Определение был трафик или нет в текущем и предыдущем месяцах
(
	select 
		d.be_flag,
		A.ab_account as acc,
		case
			when TSD.srd_no_view_stat = 'N' then 0
			when TSD.srd_no_view_stat = 'Y' then 1
		end is_trafa,
		case 
			when coalesce(sum(TI.inv_cnt),0) > 0 then 1 
			else 0 
		end ind_traf_
	from 
		edw_ods.T_000069_TB_INVOICES TI
		JOIN edw_ods.T_000069_ABONENT A
			on 1 = 1
			and A.ab_id = TI.inv_ab_id
			and TI.inv_cnt > 0
		JOIN DATES D
			on 1 = 1
			and TI.inv_tdate >= D.DATE_ - interval '1 month'
			and TI.inv_tdate < D.DATE_
			and A.deleted_ind = 0
			and D.DATE_ between A.Eff_dttm and A.Exp_dttm
			and D.DATE_ between TI.Eff_dttm and TI.Exp_dttm
		JOIN edw_ods.T_000069_TB_SERV_DEFS TSD
			on 1 = 1
			and TI.inv_srd_code = TSD.srd_code
			and TI.inv_int_code = TSD.srd_int_code
			and TSD.srd_srt_code = 'FLOW'
			and TSD.srd_traffic_in = 'Y'
			and TSD.deleted_ind = 0
			and D.DATE_ between TSD.Eff_dttm and TSD.Exp_dttm
	group by 
		be_flag,
		a.ab_account,
		is_trafa
),
	main3 as 
(
	select 
		m.be_flag,
		max(to_number(to_char(date_trunc('month', D.DATE_), 'YYYYMM'), '999999')) START_DATE,
		m.itvcp_id, 
		m.itvcp_name, 
		m.usa_value,
		m.ind, 
		sum(m.cnt)cnt,
		m.ab_ur_ustp,
		m.ab_account as ACCOUNT,
		coalesce(t1.ind_traf_,0)ind_traf,
		coalesce(t2.ind_traf_,0)ind_trafa
	from  
		main2 m
		join DATES D 
			on 1 = 1
			and m.be_flag = d.be_flag
		left join (select * from traf where is_trafa = 0) t1
			on 1 = 1 
			and m.ab_account = t1.acc
			and m.be_flag = t1.be_flag
		left join (select * from traf where is_trafa = 1) t2
			on 1 = 1 
			and m.ab_account = t2.acc 
			and m.be_flag = t2.be_flag
	group by 
		m.be_flag,
		m.itvcp_id, 
		m.itvcp_name, 
		m.usa_value, 
		m.ind,
		m.ab_ur_ustp,
		m.ab_account,
		ind_traf,
		ind_trafa
),
	accs as 
(
	select 
		D.be_flag,
		tu.account as ACCOUNT,
		hdb.branch_key as RF,
		ts.serv_first_id as SUBS_ID,
		toet.ABN_ID
	from 
		edw_ods.t_000054_t_services	ts
		join edw_ods.t_000054_t_users tu
			on 1 = 1
			and ts.user_id = tu.user_id
			and ts.svc_id = 545161749 -- Тип услуг IPTV
			and ts.deleted_ind = 0
			and tu.deleted_ind = 0
		JOIN DATES D
			on 1 = 1
			and D.DATE_ between ts.Eff_dttm and ts.Exp_dttm
			and D.DATE_ between tu.Eff_dttm and tu.Exp_dttm
		join edw_dds.hub_dim_branch hdb
			on 1 = 1
			and ts.dept_id::varchar = hdb.source_key
			and ts.src_id = hdb.src_id
		left join (
				select 
					* 
				from 
					EDW_DM_EFFTP.tfct_oo_eff_tp
				where 1 = 1
					and serv_id = 3
					and p1_period = to_char(to_date('20190601', 'YYYYMMDD'),'YYYYMM')::int4
					and p2_mrf_id = 11
				) toet 
			on 1 = 1
			and ts.serv_first_id::varchar = toet.subs_id
			and tu.account = toet.account
			and hdb.branch_key = toet.p3_rf_id
),
	main4 AS
(
	select 
		m.START_DATE,
		coalesce(a.RF,-1) RF,
		coalesce(m.ACCOUNT,'-1')ACCOUNT,
		coalesce(a.ABN_ID,-1)ABN_ID,
		a.SUBS_ID,
		m.itvcp_name NAME_PACK_ASR,
		--case when m.cnt>0 then 1 else 0 end cnt,
		case when min(m.be_flag) = 'B' then 1 else 0 end FLAG_PACK_BEGIN,
		case when max(m.be_flag) = 'E' then 1 else 0 end FLAG_PACK_END,
		m.itvcp_id ID_ASR_PACK
	from
		main3 m 
		join accs a 
			on 1 = 1
			and m.account = a.account
			and m.be_flag = a.be_flag
			and m.cnt > 0
			and m.ind_traf = 1 and m.ind_trafa = 1
	group by 
		m.START_DATE,
		coalesce(a.RF,-1),
		coalesce(m.ACCOUNT,'-1'),
		coalesce(a.abn_id,-1),
		a.SUBS_ID,
		m.itvcp_name,
		m.itvcp_id
),
	main5 as 
(
	select 
		START_DATE,
		11::int2 as MRF,
		RF,
		ACCOUNT,
		null::text SAN,
		ABN_ID,
		SUBS_ID,
		NAME_PACK_ASR,
		null::text NAME_PACK_STANDART,
		null::int FLAG_TYPE_PACK,
		FLAG_PACK_BEGIN,
		FLAG_PACK_END,
		(date_trunc('month', to_date('20190601', 'YYYYMMDD')))::date DT,
		69 SRC_ID,
		ID_ASR_PACK::int8
	from 
		main4
)
select 
	* 
from 
	main5
;

analyze edw_stg_dm_efftp.tfct_sdp_vitrina_detail_1_prt_p000069
;
