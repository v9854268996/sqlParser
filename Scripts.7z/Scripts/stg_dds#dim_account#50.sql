--rev. 55847 от 23.04.2020


--исправление скрипта (хот-фикс) по задаче DHREP-27008 от 11072019		
	
truncate edw_stg_dds.t_000050_dim_account;
insert into edw_stg_dds.t_000050_dim_account 
(
account_key
, account_name
, partner_key
, agent_scheme_key
, parent_account_key
, duty_num_key
, center_num_key
, branch_key
, region_key
, cession_date
, src_id
, load_dttm
, eff_dttm
, exp_dttm
, start_date
, end_date
)

with ttr as
	( SELECT round(tu.user_type_id) AS user_type_id, round(tu.user_id) AS user_id, round(ttr.coef) AS coef, round(tu.dept_id) AS dept_id, hub.branch_key, round(tu.billing_id) AS billing_id
	   FROM edw_ods.t_000048_t_saldo tu
	   LEFT JOIN edw_ods.t_000048_t_user_type_ref ttr ON round(ttr.user_type_id) = round(tu.user_type_id) AND ttr.deleted_ind <> 1
		AND to_date('20190630','YYYYMMDD') + INTERVAL '1 day - 1 second' between ttr.eff_dttm AND ttr.exp_dttm
	   LEFT JOIN edw_dds.hub_dim_branch hub ON round(tu.dept_id)::text = hub.source_key::text AND hub.src_id = 48
		AND to_date('20190630','YYYYMMDD') + INTERVAL '1 day - 1 second'
			between ttr.eff_dttm AND ttr.exp_dttm
	  WHERE tu.billing_id <= substr('20190601', 1, 6)::int
		and tu.tech_dt <= to_date('20190630','YYYYMMDD') + INTERVAL '1 day - 1 second'
	UNION ALL 
	 SELECT round(tu.user_type_id) AS user_type_id, round(tu.user_id) AS user_id, round(ttr.coef) AS coef, round(tu.dept_id) AS dept_id, hub.branch_key, round(tu.billing_id) AS billing_id
	   FROM edw_ods.t_000049_t_saldo tu
	   LEFT JOIN edw_ods.t_000049_t_user_type_ref ttr ON round(ttr.user_type_id) = round(tu.user_type_id) AND ttr.deleted_ind <> 1 
		AND to_date('20190630','YYYYMMDD') + INTERVAL '1 day - 1 second' between ttr.eff_dttm AND ttr.exp_dttm
	   LEFT JOIN edw_dds.hub_dim_branch hub ON round(tu.dept_id)::text = hub.source_key::text AND hub.src_id = 49
		AND to_date('20190630','YYYYMMDD') + INTERVAL '1 day - 1 second'
			between ttr.eff_dttm AND ttr.exp_dttm
	  WHERE tu.billing_id <= substr('20190601', 1, 6)::int
		and tu.tech_dt <=to_date('20190630','YYYYMMDD') + INTERVAL '1 day - 1 second'
	UNION ALL 
	 SELECT round(tu.user_type_id) AS user_type_id, round(tu.user_id) AS user_id, round(ttr.coef) AS coef, round(tu.dept_id) AS dept_id, hub.branch_key, round(tu.billing_id) AS billing_id
	   FROM edw_ods.t_000050_t_saldo tu
	   LEFT JOIN edw_ods.t_000050_t_user_type_ref ttr ON round(ttr.user_type_id) = round(tu.user_type_id) AND ttr.deleted_ind <> 1
		AND to_date('20190630','YYYYMMDD') + INTERVAL '1 day - 1 second' between ttr.eff_dttm AND ttr.exp_dttm
	   LEFT JOIN edw_dds.hub_dim_branch hub ON round(tu.dept_id)::text = hub.source_key::text AND hub.src_id = 50
	  WHERE tu.billing_id <= substr('20190601', 1, 6)::int
		and tu.tech_dt <= to_date('20190630','YYYYMMDD') + INTERVAL '1 day - 1 second'
	UNION ALL 
	 SELECT round(tu.user_type_id) AS user_type_id, round(tu.user_id) AS user_id, round(ttr.coef) AS coef, round(tu.dept_id) AS dept_id, hub.branch_key, round(tu.billing_id) AS billing_id
	   FROM edw_ods.t_000051_t_saldo tu
	   LEFT JOIN edw_ods.t_000051_t_user_type_ref ttr ON round(ttr.user_type_id) = round(tu.user_type_id) AND ttr.deleted_ind <> 1
		AND to_date('20190630','YYYYMMDD') + INTERVAL '1 day - 1 second' between ttr.eff_dttm AND ttr.exp_dttm
	   LEFT JOIN edw_dds.hub_dim_branch hub ON round(tu.dept_id)::text = hub.source_key::text AND hub.src_id = 51
	  WHERE tu.billing_id <= substr('20190601', 1, 6)::int
		and tu.tech_dt <= to_date('20190630','YYYYMMDD') + INTERVAL '1 day - 1 second'
	UNION ALL 
	 SELECT round(tu.user_type_id) AS user_type_id, round(tu.user_id) AS user_id, round(ttr.coef) AS coef, round(tu.dept_id) AS dept_id, hub.branch_key, round(tu.billing_id) AS billing_id
	   FROM edw_ods.t_000052_t_saldo tu
	   LEFT JOIN edw_ods.t_000052_t_user_type_ref ttr ON round(ttr.user_type_id) = round(tu.user_type_id) AND ttr.deleted_ind <> 1
	   AND to_date('20190630','YYYYMMDD') + INTERVAL '1 day - 1 second' between ttr.eff_dttm AND ttr.exp_dttm
	   LEFT JOIN edw_dds.hub_dim_branch hub ON round(tu.dept_id)::text = hub.source_key::text AND hub.src_id = 52
		AND to_date('20190630','YYYYMMDD') + INTERVAL '1 day - 1 second'
			between ttr.eff_dttm AND ttr.exp_dttm
	  WHERE tu.billing_id <= substr('20190601', 1, 6)::int
		and tu.tech_dt <=to_date('20190630','YYYYMMDD') + INTERVAL '1 day - 1 second'
	UNION ALL 
	 SELECT round(tu.user_type_id) AS user_type_id, round(tu.user_id) AS user_id, round(ttr.coef) AS coef, round(tu.dept_id) AS dept_id, hub.branch_key, round(tu.billing_id) AS billing_id
	   FROM edw_ods.t_000053_t_saldo tu
	   LEFT JOIN edw_ods.t_000053_t_user_type_ref ttr ON round(ttr.user_type_id) = round(tu.user_type_id) AND ttr.deleted_ind <> 1
	   AND to_date('20190630','YYYYMMDD') + INTERVAL '1 day - 1 second' between ttr.eff_dttm AND ttr.exp_dttm
	   LEFT JOIN edw_dds.hub_dim_branch hub ON round(tu.dept_id)::text = hub.source_key::text AND hub.src_id = 53
		AND to_date('20190630','YYYYMMDD') + INTERVAL '1 day - 1 second'
			between ttr.eff_dttm AND ttr.exp_dttm
	  WHERE tu.billing_id <= substr('20190601', 1, 6)::int
		and tu.tech_dt <= to_date('20190630','YYYYMMDD') + INTERVAL '1 day - 1 second'
	UNION ALL 
	 SELECT round(tu.user_type_id) AS user_type_id, round(tu.user_id) AS user_id, round(ttr.coef) AS coef, round(tu.dept_id) AS dept_id, hub.branch_key, round(tu.billing_id) AS billing_id
	   FROM edw_ods.t_000054_t_saldo tu
	   LEFT JOIN edw_ods.t_000054_t_user_type_ref ttr ON round(ttr.user_type_id) = round(tu.user_type_id) AND ttr.deleted_ind <> 1
	   AND to_date('20190630','YYYYMMDD') + INTERVAL '1 day - 1 second' between ttr.eff_dttm AND ttr.exp_dttm
	   LEFT JOIN edw_dds.hub_dim_branch hub ON round(tu.dept_id)::text = hub.source_key::text AND hub.src_id = 54
		AND to_date('20190630','YYYYMMDD') + INTERVAL '1 day - 1 second'
			between ttr.eff_dttm AND ttr.exp_dttm
	  WHERE tu.billing_id <= substr('20190601', 1, 6)::int
		and tu.tech_dt <= to_date('20190630','YYYYMMDD') + INTERVAL '1 day - 1 second'
	UNION ALL 
	 SELECT round(tu.user_type_id) AS user_type_id, round(tu.user_id) AS user_id, round(ttr.coef) AS coef, round(tu.dept_id) AS dept_id, hub.branch_key, round(tu.billing_id) AS billing_id
	   FROM edw_ods.t_000055_t_saldo tu
	   LEFT JOIN edw_ods.t_000055_t_user_type_ref ttr ON round(ttr.user_type_id) = round(tu.user_type_id) AND ttr.deleted_ind <> 1
		AND to_date('20190630','YYYYMMDD') + INTERVAL '1 day - 1 second' between ttr.eff_dttm AND ttr.exp_dttm
	   LEFT JOIN edw_dds.hub_dim_branch hub ON round(tu.dept_id)::text = hub.source_key::text AND hub.src_id = 55
		AND to_date('20190630','YYYYMMDD') + INTERVAL '1 day - 1 second'
			between ttr.eff_dttm AND ttr.exp_dttm
	  WHERE tu.billing_id <= substr('20190601', 1, 6)::int
		and tu.tech_dt <= to_date('20190630','YYYYMMDD') + INTERVAL '1 day - 1 second'
	UNION ALL 
	 SELECT round(tu.user_type_id) AS user_type_id, round(tu.user_id) AS user_id, round(ttr.coef) AS coef, round(tu.dept_id) AS dept_id, hub.branch_key, round(tu.billing_id) AS billing_id
	   FROM edw_ods.t_000056_t_saldo tu
	   LEFT JOIN edw_ods.t_000056_t_user_type_ref ttr ON round(ttr.user_type_id) = round(tu.user_type_id) AND ttr.deleted_ind <> 1
	   AND to_date('20190630','YYYYMMDD') + INTERVAL '1 day - 1 second' between ttr.eff_dttm AND ttr.exp_dttm
	   LEFT JOIN edw_dds.hub_dim_branch hub ON round(tu.dept_id)::text = hub.source_key::text AND hub.src_id = 56
		AND to_date('20190630','YYYYMMDD') + INTERVAL '1 day - 1 second'
			between ttr.eff_dttm AND ttr.exp_dttm
	  WHERE tu.billing_id <= substr('20190601', 1, 6)::int
		and tu.tech_dt <= to_date('20190630','YYYYMMDD') + INTERVAL '1 day - 1 second'
	UNION ALL 
	 SELECT round(tu.user_type_id) AS user_type_id, round(tu.user_id) AS user_id, round(ttr.coef) AS coef, round(tu.dept_id) AS dept_id, hub.branch_key, round(tu.billing_id) AS billing_id
	   FROM edw_ods.t_000057_t_saldo tu
	   LEFT JOIN edw_ods.t_000057_t_user_type_ref ttr ON round(ttr.user_type_id) = round(tu.user_type_id) AND ttr.deleted_ind <> 1
		AND to_date('20190630','YYYYMMDD') + INTERVAL '1 day - 1 second' between ttr.eff_dttm AND ttr.exp_dttm
	   LEFT JOIN edw_dds.hub_dim_branch hub ON round(tu.dept_id)::text = hub.source_key::text AND hub.src_id = 57
		AND to_date('20190630','YYYYMMDD') + INTERVAL '1 day - 1 second'
			between ttr.eff_dttm AND ttr.exp_dttm
	  WHERE tu.billing_id <= substr('20190601', 1, 6)::int
		and tu.tech_dt <= to_date('20190630','YYYYMMDD') + INTERVAL '1 day - 1 second'
	UNION ALL 
	 SELECT round(tu.user_type_id) AS user_type_id, round(tu.user_id) AS user_id, round(ttr.coef) AS coef, round(tu.dept_id) AS dept_id, hub.branch_key, round(tu.billing_id) AS billing_id
	   FROM edw_ods.t_000058_t_saldo tu
	   LEFT JOIN edw_ods.t_000058_t_user_type_ref ttr ON round(ttr.user_type_id) = round(tu.user_type_id) AND ttr.deleted_ind <> 1
		AND to_date('20190630','YYYYMMDD') + INTERVAL '1 day - 1 second' between ttr.eff_dttm AND ttr.exp_dttm
	   LEFT JOIN edw_dds.hub_dim_branch hub ON round(tu.dept_id)::text = hub.source_key::text AND hub.src_id = 58
		AND to_date('20190630','YYYYMMDD') + INTERVAL '1 day - 1 second'
			between ttr.eff_dttm AND ttr.exp_dttm
	  WHERE tu.billing_id <= substr('20190601', 1, 6)::int
		and tu.tech_dt <= to_date('20190630','YYYYMMDD') + INTERVAL '1 day - 1 second'
	UNION ALL 
	 SELECT round(tu.user_type_id) AS user_type_id, round(tu.user_id) AS user_id, round(ttr.coef) AS coef, round(tu.dept_id) AS dept_id, hub.branch_key, round(tu.billing_id) AS billing_id
	   FROM edw_ods.t_000059_t_saldo tu
	   LEFT JOIN edw_ods.t_000059_t_user_type_ref ttr ON round(ttr.user_type_id) = round(tu.user_type_id) AND ttr.deleted_ind <> 1
		AND to_date('20190630','YYYYMMDD') + INTERVAL '1 day - 1 second' between ttr.eff_dttm AND ttr.exp_dttm
	   LEFT JOIN edw_dds.hub_dim_branch hub ON round(tu.dept_id)::text = hub.source_key::text AND hub.src_id = 59
		AND to_date('20190630','YYYYMMDD') + INTERVAL '1 day - 1 second'
			between ttr.eff_dttm AND ttr.exp_dttm
	  WHERE tu.billing_id <= substr('20190601', 1, 6)::int
		and tu.tech_dt <= to_date('20190630','YYYYMMDD') + INTERVAL '1 day - 1 second'
	UNION ALL 
	 SELECT round(tu.user_type_id) AS user_type_id, round(tu.user_id) AS user_id, round(ttr.coef) AS coef, round(tu.dept_id) AS dept_id, hub.branch_key, round(tu.billing_id) AS billing_id
	   FROM edw_ods.t_000060_t_saldo tu
	   LEFT JOIN edw_ods.t_000060_t_user_type_ref ttr ON round(ttr.user_type_id) = round(tu.user_type_id) AND ttr.deleted_ind <> 1
		AND to_date('20190630','YYYYMMDD') + INTERVAL '1 day - 1 second' between ttr.eff_dttm AND ttr.exp_dttm
	   LEFT JOIN edw_dds.hub_dim_branch hub ON round(tu.dept_id)::text = hub.source_key::text AND hub.src_id = 60
		AND to_date('20190630','YYYYMMDD') + INTERVAL '1 day - 1 second'
			between ttr.eff_dttm AND ttr.exp_dttm
	  WHERE tu.billing_id <= substr('20190601', 1, 6)::int
		and tu.tech_dt <= to_date('20190630','YYYYMMDD') + INTERVAL '1 day - 1 second'
	UNION ALL 
	 SELECT round(tu.user_type_id) AS user_type_id, round(tu.user_id) AS user_id, round(ttr.coef) AS coef, round(tu.dept_id) AS dept_id, hub.branch_key, round(tu.billing_id) AS billing_id
	   FROM edw_ods.t_000061_t_saldo tu
	   LEFT JOIN edw_ods.t_000061_t_user_type_ref ttr ON round(ttr.user_type_id) = round(tu.user_type_id) AND ttr.deleted_ind <> 1
		AND to_date('20190630','YYYYMMDD') + INTERVAL '1 day - 1 second' between ttr.eff_dttm AND ttr.exp_dttm
	   LEFT JOIN edw_dds.hub_dim_branch hub ON round(tu.dept_id)::text = hub.source_key::text AND hub.src_id = 61
		AND to_date('20190630','YYYYMMDD') + INTERVAL '1 day - 1 second'
			between ttr.eff_dttm AND ttr.exp_dttm
	  WHERE tu.billing_id <= substr('20190601', 1, 6)::int
		and tu.tech_dt <= to_date('20190630','YYYYMMDD') + INTERVAL '1 day - 1 second'
	UNION ALL 
	 SELECT round(tu.user_type_id) AS user_type_id, round(tu.user_id) AS user_id, round(ttr.coef) AS coef, round(tu.dept_id) AS dept_id, hub.branch_key, round(tu.billing_id) AS billing_id
	   FROM edw_ods.t_000062_t_saldo tu
	   LEFT JOIN edw_ods.t_000062_t_user_type_ref ttr ON round(ttr.user_type_id) = round(tu.user_type_id) AND ttr.deleted_ind <> 1
		AND to_date('20190630','YYYYMMDD') + INTERVAL '1 day - 1 second' between ttr.eff_dttm AND ttr.exp_dttm
	   LEFT JOIN edw_dds.hub_dim_branch hub ON round(tu.dept_id)::text = hub.source_key::text AND hub.src_id = 62
		AND to_date('20190630','YYYYMMDD') + INTERVAL '1 day - 1 second'
			between ttr.eff_dttm AND ttr.exp_dttm
	  WHERE tu.billing_id <= substr('20190601', 1, 6)::int
		and tu.tech_dt <= to_date('20190630','YYYYMMDD') + INTERVAL '1 day - 1 second'
)
select 
account_key
, account_name
, partner_key
, agent_scheme_key
, parent_account_key
, duty_num_key
, center_num_key
, branch_key
, region_key
, cession_date
, src_id
, load_dttm
, eff_dttm
, case 
	when date_trunc('day',exp_dttm)::timestamp = '2999-12-31' 
		then date_trunc('day',exp_dttm)::timestamp 
		else exp_dttm 
end as exp_dttm
, start_date
, case 
	when date_trunc('day',end_date)::timestamp = '2999-12-31' 
		then date_trunc('day',end_date)::timestamp 
		else end_date 
end as end_date

from
(
select 
--удалено окрубление t_users.user_id
t_users.src_id||'#'||t_users.user_id as account_key
, t_users.account as account_name
, t_users.user_id as partner_key
, 1 as agent_scheme_key
,round(t_vip_sp.user_id_vip) as parent_account_key
, case
--удалено окрубление t_user_type_ref.user_type_id и ttr.coef везде
	when t_user_type_ref.user_type_id in (499920451, 540553906) 
		then 0
	when coalesce(ttr.coef,round(t_user_type_ref.coef)) = 1 
		then 0
	when coalesce(ttr.coef,round(t_user_type_ref.coef)) = 0 
	--удалено окрубление t_user_type_ref.user_type_id
	and coalesce(round(ttr.user_type_id),round(t_saldo.user_type_id),t_users.user_type_id) in (499920451, 540553906) 
		then 0
		else 1 
end as duty_num_key
, case 
	when t_user_type_ref.user_type_id in (499920451, 540553906) 
		then 1
	when coalesce(ttr.coef, round(t_user_type_ref.coef)) = 1 
		then 0
	when coalesce(ttr.coef, round(t_user_type_ref.coef)) = 0 
	and coalesce(round(ttr.user_type_id),round(t_saldo.user_type_id),t_users.user_type_id) in (499920451, 540553906) 
		then 1 
		else 0 
end as center_num_key
, coalesce(round(t_saldo.dept_id),round(t_users.dept_id)) as branch_key
, coalesce(round(t_saldo.dept_id),round(t_users.dept_id)) as region_key
, cession.cession_date
, t_users.src_id as src_id
, now() as load_dttm
--удалено округление round(t_saldo.billing_id)
, coalesce(decode(t_saldo.billing_id,t_saldo.min_billing_id,to_date('1900-01-01', 'YYYY-MM-DD')),to_date(t_saldo.billing_id::text, 'YYYYMM') , to_date('1900-01-01', 'YYYY-MM-DD')) as eff_dttm
, coalesce(decode(t_saldo.billing_id,t_saldo.max_billing_id,to_date('2999-12-31', 'YYYY-MM-DD')),to_date(t_saldo.billing_id::text, 'YYYYMM') + interval '1 month - 1 day', to_date('2999-12-31', 'YYYY-MM-DD')) + interval '1 day - 1 second' as exp_dttm
, coalesce(decode(t_saldo.billing_id,t_saldo.min_billing_id,to_date('1900-01-01', 'YYYY-MM-DD')),to_date(t_saldo.billing_id::text, 'YYYYMM') , to_date('1900-01-01', 'YYYY-MM-DD')) as start_date
, coalesce(decode(t_saldo.billing_id,t_saldo.max_billing_id,to_date('2999-12-31', 'YYYY-MM-DD')),to_date(t_saldo.billing_id::text, 'YYYYMM') + interval '1 month - 1 day', to_date('2999-12-31', 'YYYY-MM-DD')) + interval '1 day - 1 second' as end_date

from edw_ods.t_000050_t_users t_users
left join 
(
	select 
	*
	, max(billing_id) over (PARTITION BY user_id) as max_billing_id
	, min(billing_id) over (PARTITION BY user_id) as min_billing_id 
	
	from edw_ods.t_000050_t_saldo
	where billing_id <= substr('20190601', 1, 6)::int
	  and tech_dt <= to_date(substr('20190601', 1, 6), 'YYYYMM')
) t_saldo 
--убрано округление t_users.user_id t_users.user_id = round(t_saldo.user_id)   и ttr.billing_id
	on t_users.user_id = t_saldo.user_id
	and t_users.deleted_ind = 0
inner join edw_ods.t_000050_t_user_type_ref t_user_type_ref 
	on t_user_type_ref.user_type_id = coalesce(t_users.user_type_id,t_users.user_type_id) 
	and t_user_type_ref.DELETED_IND = 0
	AND to_date('20190630','YYYYMMDD') + INTERVAL '1 day - 1 second'
            between t_user_type_ref.eff_dttm and t_user_type_ref.exp_dttm
left join 
(
	select 
	  round(sp.user_id_sp) as user_id_sp
	, round(v.user_id_vip) as user_id_vip
	, round(sp.dept_id_vip) as dept_id_vip
	, case 
		when coalesce(date_begin,'1900-01-01 00:00:00') = min(coalesce(date_begin,'1900-01-01 00:00:00')) over (PARTITION BY v.user_id_sp) 
			then '1900-01-01 00:00:00' 
			else coalesce(date_begin,'1900-01-01 00:00:00') 
	end as date_begin_v2
	,case 
		when coalesce(date_end,'2999-12-31 00:00:00') = max(coalesce(date_end,'2999-12-31 00:00:00')) over (PARTITION BY v.user_id_sp) 
			then '2999-12-31 00:00:00' 
			else coalesce(date_end,'2999-12-31 00:00:00') 
	end as date_end_v2
	from edw_ods.t_000050_t_vip_sp sp
		inner join 
		(select v.*,row_number() over (partition by USER_ID_VIP, DEPT_ID_SP, USER_ID_SP order by date_begin desc) as rn 
		from edw_ods.t_000050_t_vip v 
			where  to_date('20190630', 'YYYYMMDD') + INTERVAL '1 day - 1 second'
                between v.eff_dttm and v.exp_dttm
		)v
			on sp.user_id_sp=v.user_id_sp and v.rn = 1 
	where 1=1
	AND to_date('20190630','YYYYMMDD') + INTERVAL '1 day - 1 second'
                between sp.eff_dttm and sp.exp_dttm
	and v.deleted_ind = 0
	and sp.deleted_ind = 0
) t_vip_sp 
	on t_users.user_id = t_vip_sp.user_id_sp 
	and to_date(t_saldo.billing_id::text, 'YYYYMM') between date_begin_v2 and date_end_v2
left join edw_dds.hub_dim_branch hub 
	ON t_vip_sp.dept_id_vip::text = hub.source_key 
	AND t_users.src_id = hub.src_id
	and to_date('20190601','YYYYMMDD') + INTERVAL '1 MONTH - 1 second' between hub.eff_dttm and hub.exp_dttm
left join ttr 
	on ttr.user_id = t_vip_sp.user_id_vip
	and hub.branch_key = ttr.branch_key 
	and ttr.billing_id = t_saldo.billing_id
left join 	(select nt.id_host as user_id
                  , min(nc.date_begin) as cession_date
				from
				edw_ods.t_000050_n_titul_treaty nt
				inner join edw_ods.t_000050_n_content_treaty nc
						on (1 = 1 
							and nc.id_treaty=nt.id_treaty 
							and nc.id_obj in (1000030) 
							and to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second' between nc.eff_dttm and nc.exp_dttm 
							and nc.deleted_ind = '0'
							)
				where to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second' between nt.eff_dttm and nt.exp_dttm 
				and (lower(content_str) like '%цесс%' and (lower(content_str) like '%продажа%' or lower(content_str) like '%списан%')
					or content_str = 'Цессия')
				group by nt.id_host
			) cession
	on t_users.user_id = cession.user_id	
where
   to_date('20190630','YYYYMMDD') + INTERVAL '1 day - 1 second' +  interval '7 day' 
      between t_users.eff_dttm and t_users.exp_dttm
)s;
commit;
analyze edw_stg_dds.t_000050_dim_account;