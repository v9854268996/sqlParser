/*rev.57809 от 15.05.2020 (Hot fix)*/
/*Центр Старт IP 63-77*/
truncate table edw_stg_mdm.put_xref_dim_sales_channel_1_prt_p000063;

insert into edw_stg_mdm.put_xref_dim_sales_channel_1_prt_p000063
(
    source_key,
    source_name,
    src_id
)    
select distinct
    regexp_replace(trim(upper(h1.title)),'[ ]+',' ','g') as source_key,
    regexp_replace(trim(upper(h1.title)),'[ ]+',' ','g') as source_name,
    av.src_id 
from edw_ods.t_000044_ktp_order_option ktpo
join edw_ods.t_000044_table_case a on a.objid = ktpo.opt2case
join edw_ods.t_000063_abonent av on av.ab_account = ktpo.account   
left join edw_ods.t_000044_table_close_case tcc on tcc. last_close2case = a.objid
left join edw_ods.t_000044_table_gbst_elm g1 on g1.objid = tcc.close_rsolut2gbst_elm
left join edw_ods.t_000044_table_customer cu on cu.x_bankbook_id = ktpo.account
left join edw_ods.t_000044_table_hgbst_elm h1 on coalesce(ktpo.opt2channel,a.x_case_type2hgbst_elm) = h1.objid
left join edw_ods.t_000044_table_channel ch on ch.objid = ktpo.opt2channel
left join edw_ods.t_000044_table_ktp_order ktp on ktp.id = ktpo.opt2order
left join edw_ods.t_000044_table_user u on upper(u.login_name) = upper(ktp.login)
left join edw_ods.t_000044_table_employee e on e.employee2user = u.objid
where ktpo.status is not null
    and (
          a.CASE_TYPE_LVL1 = 'Продажа'
          or (
                a.CASE_TYPE_LVL1 = 'Управление опциями'
                and coalesce(g1.title,' ') <> 'Отказ.Дубликат'
                and ktpo.Acttype = 'ON'
          )
    );
commit;

analyze edw_stg_mdm.put_xref_dim_sales_channel_1_prt_p000063;
