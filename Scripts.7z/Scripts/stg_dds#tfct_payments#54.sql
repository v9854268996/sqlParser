/*rev.46746 17.01.2020*/truncate edw_stg_dds.t_000054_tfct_payments;
insert into edw_stg_dds.t_000054_tfct_payments 
	(payment_key
	, account_key
	, payment_amt
	, payment_dttm
	, billing_dttm
	, comments
	, src_id
	, load_dttm
	, eff_dttm
	, exp_dttm)
select 
     payment_key
	 , src_id||'#'||account_key as account_key
	 , payment_amt
	 , payment_dttm
	 , billing_dttm
	 , comments
	 , src_id
	 , load_dttm
	 , eff_dttm
	 , exp_dttm
from(
select   t_payments.payment_id as payment_key -- Идентификатор платежа
		,t_payments.user_id as account_key -- Идентификатор лицевого счета
		,t_payments.summ as payment_amt -- Сумма платежа
		,t_payments.pay_date as payment_dttm -- Дата платежа
		,to_date(Billing_id::text, 'YYYYMM') as billing_dttm -- Дата билинга
		,pdr.NAME comments
		,000054 as src_id
  		,now() as load_dttm
		, to_timestamp('19000101', 'YYYYMMDD') as EFF_DTTM
        , to_timestamp('29991231', 'YYYYMMDD') as EXP_DTTM
		
from edw_ods.t_000054_t_payments t_payments
left join edw_ods.t_000054_t_pay_doc_ref pdr
  on pdr.pay_doc_id = t_payments.pay_doc_id
 and pdr.deleted_ind = 0
 and to_date(round(t_payments.billing_id)::text, 'YYYYMM') between pdr.eff_dttm and pdr.exp_dttm
where Billing_id between substr('20190601', 1, 6)::int and substr('20190630', 1, 6)::int
  and tech_dt between to_date(substr('20190601', 1, 8), 'YYYYMMDD') and to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second'
)sss;
commit;
analyze edw_stg_dds.t_000054_tfct_payments;