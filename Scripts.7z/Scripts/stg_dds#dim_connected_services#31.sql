/*rev.23469 28.02.2019*/
  
truncate edw_stg_dds.t_000031_dim_connected_service;
insert into edw_stg_dds.t_000031_dim_connected_service
	( connected_service_key
	, subs_key
	, account_key
	, service_key
	, duty_num_key
	, center_num_key
	, address_key
	, cpe_key
	, port_key
	, subs_code
	, start_date
	, end_date
	, eff_dttm
	, exp_dttm
	, src_id
	, wf_run_id
	, mapping_code 
	, deleted_ind
	, load_dttm
	)
SELECT
	 a.service_id
	, a.subs_key
	, a.account_key
	, a.service_key
	, a.duty_num_key
	, a.center_num_key
	, a.address_key
	, a.cpe_key
	, a.port_key
	, a.subs_code
	, a.eff_dttm as start_date
	, a.exp_dttm as end_date
	, to_date('19000101', 'YYYYMMDD') as eff_dttm
	, to_date('29991231', 'YYYYMMDD') as exp_dttm
	, a.src_id
	, a.wf_run_id
	, a.mapping_code
	, a.deleted_ind
	, now ()
FROM edw_stg_dds.t_000031_dim_subs a;
commit;
analyze edw_stg_dds.t_000031_dim_connected_service;