--rev. 49335 от 12.02.2020
SET optimizer = ON;
SET search_path = edw_stg_dmcm;

TRUNCATE TABLE edw_stg_dmcm.pre_wifi_services_1_prt_p000151;
INSERT INTO edw_stg_dmcm.pre_wifi_services_1_prt_p000151
 (period,
  mrf_id,
  rf_id,
  region_id,
  fldinn,
  segment,
  fldordernumber,
  tarif_name,
  serv_name,
  serv_startdate,
  serv_enddate,
  salespersonname,
  salesgroup,
  serv_status,
  new_ap_count,
  new_serv_count,
  churn_ap_count,
  churn_serv_count,
  ap_count_end,
  serv_count_end,
  new_ap_count_cms,
  churn_ap_count_cms,
  ap_count_end_cms,
  calendar_key,
  flag_pack,
  platform,
  serv_address,
  cl_id,
  fldapmodelindoor,
  fldapmodeloutdoor,
  fldisneedfiltration,
  fldmarketaccess,
  src_id)
WITH
pre_wifi_ssid AS
(
  SELECT
    lag(ss.fldstatus, 1, '')
      OVER (PARTITION BY ss.flddocumentunid ORDER BY ss.currentversion) AS status_previous,
    ss.localsystemid,
    min(ss.fldmarketaccess)
      OVER (PARTITION BY ss.flddocumentunid) AS fldmarketaccess,
    ss.fldparentdocunid,
    ss.fldstatus,
    ss.attribute_startdate,
    ss.currentversion
  FROM edw_ods.t_000137_ssidcms ss
),
wifi_ssid AS
(
  SELECT
    pws.localsystemid,
    pws.fldparentdocunid,
    pws.fldstatus,
    pws.fldmarketaccess,
    pws.attribute_startdate,
    coalesce((lead(pws.attribute_startdate)
      OVER (PARTITION BY pws.localsystemid ORDER BY pws.currentversion)), '2999-01-01 00:00:00') AS attribute_enddate,
    row_number()
      OVER (PARTITION BY pws.localsystemid, pws.attribute_startdate ORDER BY pws.currentversion DESC) AS rn
  FROM pre_wifi_ssid pws
  WHERE pws.fldstatus <> pws.status_previous
),
ssid AS
(
  SELECT
    ws.localsystemid,
    ws.fldparentdocunid,
    ws.fldstatus,
    ws.fldmarketaccess,
    ws.attribute_startdate,
    ws.attribute_enddate
  FROM wifi_ssid ws
  WHERE rn = 1
    AND ws.fldmarketaccess ='Да'
),
pre_orders AS
(
  SELECT
    o.flddocumentunid,
    min(CASE
          WHEN o.fldordertype = 'Новый заказ' AND upper(o.fldwfstatus) IN ('ПРИЕМКА КЛИЕНТОМ',
                                                                           'ТЕСТИРОВАНИЕ УСЛУГИ',
                                                                           'УСЛУГА ЭКСПЛУАТИРУЕТСЯ')
               THEN o.attribute_startdate
          WHEN o.fldordertype LIKE 'Изменение%' AND upper(o.fldwfstatus) IN ('УСЛУГА ЭКСПЛУАТИРУЕТСЯ')
               THEN o.attribute_startdate
        END) AS start_dt,
    coalesce((min(CASE
                    WHEN upper(o.fldwfstatus) IN ('УСЛУГА ОТКЛЮЧЕНА',
                                                  'ОТКАЗ КЛИЕНТА',
                                                  'ОТКЛЮЧЕНИЕ БЕЗ ПРИЕМКИ КЛИЕНТОМ',
                                                  'ОТМЕНЕН')
                            OR (upper(o.fldwfstatus) IN ('ЗАКАЗ ПЕРЕПОДПИСАН') AND o.fldchangeorder IS NULL)
                         THEN o.attribute_startdate
                  END)), '2999-01-01') AS end_date,
    min(CASE
          WHEN o.fldordertype = 'Новый заказ' AND upper(o.fldwfstatus) IN ('ПРИЕМКА КЛИЕНТОМ',
                                                                           'ТЕСТИРОВАНИЕ УСЛУГИ',
                                                                           'УСЛУГА ЭКСПЛУАТИРУЕТСЯ')
               THEN o.currentversion
          WHEN o.fldordertype LIKE 'Изменение%' AND upper(o.fldwfstatus) IN ('УСЛУГА ЭКСПЛУАТИРУЕТСЯ')
               THEN o.currentversion
        END) AS start_version,
    coalesce((min(CASE
                    WHEN upper(o.fldwfstatus) IN ('УСЛУГА ОТКЛЮЧЕНА',
                                                  'ОТКАЗ КЛИЕНТА',
                                                  'ЗАКАЗ ПЕРЕПОДПИСАН',
                                                  'ОТКЛЮЧЕНИЕ БЕЗ ПРИЕМКИ КЛИЕНТОМ',
                                                  'ОТМЕНЕН')
                        OR (upper(o.fldwfstatus) IN ('ЗАКАЗ ПЕРЕПОДПИСАН') AND o.fldchangeorder IS NULL)
                         THEN o.currentversion
                  END)), 1000) AS end_version
   FROM edw_stg_dmcm.pre_wifi_ordercms_1_prt_p000151 o
  WHERE o.fldordercategory = 'Коммерческий'
    AND o.fldservicetype IN ('Wi-Fi Hotspot', 'Wi-Fi OTT. Пакет', 'Wi-Fi OTT')
    AND o.form = 'formOrder'
  GROUP BY o.flddocumentunid
),
orders AS
(
  SELECT
    dc.calendar_key,
    t.flddocumentunid,
    t.start_dt,
    t.end_date,
    t.start_version,
    t.end_version
  FROM pre_orders t
  JOIN edw_ads.dim_calendar dc
    ON dc.calendar_key BETWEEN t.start_dt AND t.end_date
  WHERE dc.calendar_key <= to_date('20190630', 'YYYYMMDD')
),
max_ver AS
(
  SELECT
    cl.flddocumentunid,
    max(currentversion) AS max_version
  FROM edw_ods.t_000137_client cl
  WHERE cl.form = 'formOrganization'
  GROUP BY cl.flddocumentunid
),
finall AS
(
  SELECT
    t.calendar_key,--new
    o.fldordernumber,
    o.fldSalesPersonName,
    o.fldSalesGroup,
    CASE
        WHEN upper(o.fldWFStatus) IN ('ЗАКАЗ ПЕРЕПОДПИСАН') AND o.fldchangeorder IS NULL
            THEN 'УСЛУГА ОТКЛЮЧЕНА'
        ELSE o.fldWFStatus
    END AS fldWFStatus,
    o.fldAPType,
    o.attribute_startdate,
    o.fldpoint2addressregion,
    o.fldpoint2address,
    o.fldorganizationunid,
    o.fldchangeorder,
    o.fldbaseordernumber,
    CASE WHEN o.fldisneedfiltration = '1' THEN 1 ELSE 0 END AS fldisneedfiltration,
    coalesce(o.fldapcountindoor::INT, 0) AS fldapcountindoor,
    coalesce(o.fldapcountoutdoor::INT, 0) AS fldapcountoutdoor,
    t.start_dt AS serv_startdate,
    t.end_date AS serv_enddate,
    CASE
      WHEN o.fldTariffClass::TEXT <> '' OR o.fldTariffCommand::TEXT <> ''
           THEN 'Тарифный план ' || o.fldTariffClass::TEXT || ' по приказу ' || o.fldTariffCommand::TEXT
      ELSE ''
    END AS tarif_name,
    CASE
      WHEN upper(o.fldAPType) = 'CLIENT'
           THEN 'Управляемый Wi-Fi на ТД клиента'
      WHEN upper(o.fldAPType) = 'COMPANY' OR o.fldAPType IS NULL
           THEN 'Управляемый Wi-Fi на ТД Общества'
      WHEN o.fldisneedfiltration = '1'
           THEN 'Фильтрация трафика'
      WHEN upper(o.fldWFStatus) IN ('БЛОКИРОВКА WI-FI', 'ЗАПРОС НА РАЗБЛОКИРОВКУ WI-FI')
           THEN 'Добровольная блокировка услуги'
    END AS serv_name,
    CASE
      WHEN coalesce(upper(replace(o.fldSpeedMeasure, ' ', '')), '') = 'МБ/С'
           THEN replace(coalesce(o.fldSpeedValue, '0'), ',', '.')::NUMERIC(10, 2)
      WHEN upper(replace(o.fldSpeedMeasure, ' ', '')) = 'КБ/С'
           THEN replace(coalesce(o.fldSpeedValue, '0'), ',', '.')::NUMERIC(10, 2)/1024
      WHEN upper(replace(o.fldSpeedMeasure, ' ', '')) = 'ГБ/С'
           THEN replace(coalesce(o.fldSpeedValue, '0'), ',', '.')::NUMERIC(10, 2)*1024
      ELSE -1
    END AS speedMb,
    CASE
      WHEN o.fldapcountindoor IS NULL AND o.fldapcountoutdoor IS NULL
           THEN coalesce(o.fldaccesspointscount::INT, 1)
      ELSE coalesce(o.fldapcountindoor::INT, 0) + coalesce(o.fldapcountoutdoor::INT, 0)
    END AS ap_count,
    CASE
      WHEN upper(o.fldWFStatus) IN ('ПРИЕМКА КЛИЕНТОМ',
                                    'ТЕСТИРОВАНИЕ УСЛУГИ',
                                    'УСЛУГА ЭКСПЛУАТИРУЕТСЯ',
                                    'ВЫПОЛНЯЕТСЯ ПЕРЕПОДПИСАНИЕ')
           AND date_trunc('day', t.start_dt) = t.calendar_key
           AND ((upper(o.fldAPType) = 'COMPANY' OR o.fldAPType IS NULL) OR o.fldisneedfiltration = '1')
           THEN TRUE
      ELSE FALSE
    END AS is_company_open,
    CASE
      WHEN (upper(o.fldWFStatus) IN ('УСЛУГА ОТКЛЮЧЕНА',
                                     'ОТКАЗ КЛИЕНТА',
                                     'ОТКЛЮЧЕНИЕ БЕЗ ПРИЕМКИ КЛИЕНТОМ',
                                     'ОТМЕНЕН')
              OR (upper(o.fldwfstatus) IN ('ЗАКАЗ ПЕРЕПОДПИСАН') AND o.fldchangeorder IS NULL))
           AND date_trunc('day', t.end_date) = t.calendar_key
           AND ((upper(o.fldAPType) = 'COMPANY' OR o.fldAPType IS NULL) OR o.fldisneedfiltration = '1')
           THEN TRUE
      ELSE FALSE
    END AS is_company_close,
    CASE
      WHEN upper(o.fldWFStatus) IN ('ПРИЕМКА КЛИЕНТОМ',
                                    'ТЕСТИРОВАНИЕ УСЛУГИ',
                                    'УСЛУГА ЭКСПЛУАТИРУЕТСЯ',
                                    'ВЫПОЛНЯЕТСЯ ПЕРЕПОДПИСАНИЕ')
           AND date_trunc('day', t.start_dt) = t.calendar_key
           AND upper(o.fldAPType) = 'CLIENT'
           THEN TRUE
      ELSE FALSE
    END AS is_client_open,
    CASE
      WHEN (upper(o.fldWFStatus) IN ('УСЛУГА ОТКЛЮЧЕНА',
                                     'ОТКАЗ КЛИЕНТА',
                                     'ОТКЛЮЧЕНИЕ БЕЗ ПРИЕМКИ КЛИЕНТОМ',
                                     'ОТМЕНЕН')
              OR (upper(o.fldwfstatus) IN ('ЗАКАЗ ПЕРЕПОДПИСАН') AND o.fldchangeorder IS NULL))
           AND date_trunc('day', t.end_date) = t.calendar_key
           AND upper(o.fldAPType) = 'CLIENT'
           THEN TRUE
      ELSE FALSE
    END AS is_client_close,
    CASE
      WHEN o.is_operating
           AND ((upper(o.fldAPType) = 'COMPANY' OR o.fldAPType IS NULL) OR o.fldisneedfiltration = '1')
           THEN TRUE
      ELSE FALSE
    END AS is_company_end_open,
    CASE
      WHEN o.is_operating
           AND upper(o.fldAPType) = 'CLIENT'
           THEN TRUE
      ELSE FALSE
    END AS is_company_end_close,
    o.is_operating,
    CASE
      WHEN upper(o.fldsmpb2b)= 'ДА' AND o.fldservicetype IN ('Wi-Fi OTT', 'Wi-Fi Hotspot') THEN 1
      WHEN o.fldservicetype  = 'Wi-Fi OTT. Пакет' THEN 2
      ELSE 0
    END AS flag_pack,
    CASE
      WHEN (o.fldplatform IS NULL OR upper(o.fldplatform) = 'ФЕДЕРАЛЬНАЯ')
           THEN 'Федеральная'
      ELSE 'МРФ Центр'
    END AS platform,
    CASE WHEN ss.fldmarketaccess = 'Да' THEN 1 ELSE 0 END AS fldmarketaccess
  FROM orders t
  JOIN
  (
    SELECT
      lead(oper.attribute_startdate, 1, '2999-01-01')
        OVER (PARTITION BY oper.fldordernumber ORDER BY oper.attribute_startdate) AS period_last,
      oper.*
    FROM
    (
      SELECT
        CASE
          WHEN (upper(pwo.fldWFStatus) NOT IN ('УСЛУГА ОТКЛЮЧЕНА',
                                               'ОТКАЗ КЛИЕНТА',
                                               'ОТКЛЮЧЕНИЕ БЕЗ ПРИЕМКИ КЛИЕНТОМ',
                                               'ОТМЕНЕН')
                    AND NOT (upper(pwo.fldwfstatus) IN ('ЗАКАЗ ПЕРЕПОДПИСАН') AND pwo.fldchangeorder IS NULL))
               THEN TRUE
          ELSE FALSE
        END is_operating,
        row_number()
          OVER (PARTITION BY pwo.fldordernumber, (pwo.attribute_startdate::DATE)
                    ORDER BY pwo.currentversion DESC) AS rn,
        pwo.*
      FROM edw_stg_dmcm.pre_wifi_ordercms_1_prt_p000151 pwo
    ) oper
    WHERE oper.rn = 1
  ) o
    ON t.flddocumentunid = o.flddocumentunid
    AND o.currentversion BETWEEN t.start_version AND t.end_version
    AND t.calendar_key >= o.attribute_startdate AND t.calendar_key < o.period_last
  LEFT JOIN
  (
    SELECT
      row_number() OVER (PARTITION BY t.flddocumentunid, t.calendar_key ORDER BY ss.attribute_startdate DESC) AS rn,
      ss.*,
      t.*
    FROM ssid ss
         LEFT JOIN
         orders t
           ON position(t.flddocumentunid IN ss.fldParentDocUNID) > 0
           AND ss.attribute_startdate <= t.calendar_key
           AND t.calendar_key < ss.attribute_enddate
  ) ss
    ON ss.flddocumentunid = t.flddocumentunid
    AND t.calendar_key = ss.calendar_key
    AND ss.rn = 1
)
SELECT
  o.calendar_key AS period,
  CASE
    WHEN db.parent_branch_key = -1
         THEN db.branch_key
    ELSE db.parent_branch_key
  END AS mrf_id,
  drg.branch_key AS rf_id,
  br.region_key AS region_id,
  cl.fldinn,
  cl.fldorganizationsegment AS segment,
  o.fldordernumber,
  o.tarif_name,
  o.serv_name,
  o.serv_startdate,
  o.serv_enddate,
  o.fldSalesPersonName AS SalesPersonName,
  o.fldSalesGroup AS SalesGroup,
  CASE
    WHEN o.is_operating
         THEN 'Услуга эксплуатируется'
    WHEN upper(o.fldWFStatus) IN ('УСЛУГА ОТКЛЮЧЕНА', 'ОТКАЗ КЛИЕНТА', 'ОТКЛЮЧЕНИЕ БЕЗ ПРИЕМКИ КЛИЕНТОМ', 'ОТМЕНЕН')
         THEN 'Услуга отключена'
    ELSE o.fldWFStatus
  END AS serv_status,
  o.new_ap_count,
  o.new_serv_count,
  o.churn_ap_count,
  o.churn_serv_count,
  o.ap_count_end,
  o.serv_count_end,
  o.new_ap_count_cms,
  o.churn_ap_count_cms,
  o.ap_count_end_cms,
  to_char(o.calendar_key::date, 'YYYYMM') AS calendar_key,
  o.flag_pack,
  o.platform,
  o.fldpoint2address AS serv_address,
  o.fldorganizationunid AS cl_id,
  o.fldapmodelindoor,    -- тип внешних ТД, новое - без правки предагрегата по заказам не отработает
  o.fldapmodeloutdoor,   -- тип внутренних ТД, новое - без правки предагрегата по заказам не отработает
  o.fldisneedfiltration, -- новое
  o.fldmarketaccess,     -- новое
  000151::smallint AS src_id
FROM
(
  SELECT
    f.*,
    p.*,
    CASE
      WHEN f.is_company_open
           THEN CASE
                  WHEN p.current_order IS NULL
                       THEN f.ap_count
                  ELSE CASE
                         WHEN (f.ap_count - p.parent_ap_count) > 0
                               THEN (f.ap_count - p.parent_ap_count)
                         ELSE 0
                       END
                END
      WHEN f.is_client_open
           THEN CASE
                  WHEN p.current_order IS NULL
                       THEN 1
                  ELSE CASE
                         WHEN (f.ap_count - p.parent_ap_count) > 0
                              THEN (f.ap_count - p.parent_ap_count)
                         ELSE 0
                       END
                END
      ELSE NULL
    END AS new_ap_count,
    CASE
      WHEN f.is_company_open
           THEN CASE
                  WHEN p.current_order IS NULL
                       THEN F.ap_count
                  ELSE CASE
                         WHEN (f.ap_count - p.parent_ap_count) > 0
                              THEN (f.ap_count - p.parent_ap_count)
                         ELSE 0
                       END
                END
      WHEN f.is_client_open
           THEN CASE
                  WHEN p.current_order IS NULL
                       THEN f.speedMb
                    ELSE CASE
                           WHEN (f.speedMb - p.parent_speedMb) > 0
                                THEN (f.speedMb - p.parent_speedMb)
                           ELSE 0
                         END
                END
      ELSE NULL
    END AS new_serv_count,
    CASE
      WHEN f.is_company_close
           THEN CASE
                  WHEN p.current_order IS NULL
                       THEN F.ap_count
                  ELSE CASE
                         WHEN (f.ap_count - p.parent_ap_count) < 0
                              THEN (p.parent_ap_count - f.ap_count)
                         ELSE 0
                       END
                END
      WHEN f.is_client_close
           THEN CASE
                  WHEN p.current_order IS NULL
                       THEN 1
                  ELSE 0
                END
    END AS churn_ap_count,
    CASE
      WHEN f.is_company_close
           THEN CASE
                  WHEN p.current_order IS NULL
                      THEN F.ap_count
                  ELSE CASE
                         WHEN (f.ap_count - p.parent_ap_count) < 0
                              THEN (p.parent_ap_count - f.ap_count)
                         ELSE 0
                       END
                END
      WHEN f.is_client_close
           THEN CASE
                  WHEN p.current_order IS NULL
                       THEN f.speedMb
                  ELSE CASE
                         WHEN (f.speedMb - p.parent_speedMb) < 0
                              THEN (p.parent_speedMb - f.speedMb)
                         ELSE 0
                       END
                END
      ELSE NULL
    END AS churn_serv_count,
    CASE
      WHEN is_company_end_open
           THEN f.ap_count
      WHEN is_company_end_close
           THEN 1
      ELSE NULL
    END AS ap_count_end,
    CASE
      WHEN is_company_end_open
           THEN f.ap_count
      WHEN is_company_end_close
           THEN F.speedMb
      ELSE NULL
    END AS serv_count_end,
    CASE
      WHEN (f.is_company_open OR f.is_client_open)
              THEN CASE
                     WHEN p.current_order IS NULL
                          THEN f.ap_count
                     ELSE CASE
                            WHEN (f.ap_count - p.parent_ap_count) > 0
                                 THEN (f.ap_count - p.parent_ap_count)
                            ELSE NULL
                          END
                   END
    END AS new_ap_count_cms,
    CASE
      WHEN (f.is_company_close OR f.is_client_close)
           THEN CASE
                  WHEN p.current_order IS NULL
                       THEN F.ap_count
                  ELSE CASE
                         WHEN (f.ap_count - p.parent_ap_count) < 0
                              THEN (p.parent_ap_count - f.ap_count)
                         ELSE NULL
                       END
                END
    END AS churn_ap_count_cms,
    CASE
      WHEN (is_company_end_open OR is_company_end_close)
           THEN f.ap_count
      ELSE NULL
    END AS ap_count_end_cms
  FROM finall f
  LEFT JOIN
  (
    SELECT
      t.flddocumentunid AS parent_order_unid,
      o.fldchangeorder AS current_order,
      coalesce(
        CASE
          WHEN o.fldapcountindoor IS NULL AND o.fldapcountoutdoor IS NULL
               THEN coalesce(o.fldaccesspointscount::INT, 1)
          ELSE coalesce(o.fldapcountindoor::INT, 0) + coalesce(o.fldapcountoutdoor::INT, 0)
        END) AS parent_ap_count,
      coalesce(
        CASE
          WHEN coalesce(upper(replace(o.fldSpeedMeasure, ' ', '')), '') = 'МБ/С'
               THEN replace(coalesce(o.fldSpeedValue, '0'), ',', '.')::NUMERIC(10, 2)
          WHEN upper(replace(o.fldSpeedMeasure, ' ', '')) = 'КБ/С'
               THEN replace(coalesce(o.fldSpeedValue, '0'), ',', '.')::NUMERIC(10, 2)/1024
          WHEN upper(replace(o.fldSpeedMeasure, ' ', '')) = 'ГБ/С'
               THEN replace(coalesce(o.fldSpeedValue, '0'), ',', '.')::NUMERIC(10, 2)*1024
          ELSE -1
        END) AS parent_speedMb,
      o.fldapmodelindoor,
      o.fldapmodeloutdoor
    FROM 
    (
      SELECT
        flddocumentunid,
        min(CASE upper(fldWFStatus) WHEN 'ЗАКАЗ ПЕРЕПОДПИСАН' THEN o.currentversion END) AS close_version
      FROM edw_stg_dmcm.pre_wifi_ordercms_1_prt_p000151 o
      WHERE 1 = 1
        AND fldordercategory = 'Коммерческий'
        AND fldservicetype IN ('Wi-Fi Hotspot', 'Wi-Fi OTT. Пакет', 'Wi-Fi OTT')
        AND form = 'formOrder'
      GROUP BY flddocumentunid
    ) t
    JOIN edw_stg_dmcm.pre_wifi_ordercms_1_prt_p000151 o
      ON t.flddocumentunid = o.flddocumentunid
      AND t.close_version = o.currentversion
  ) p
    ON f.fldordernumber = p.current_order) o
  LEFT JOIN max_ver l
    ON l.flddocumentunid = o.fldorganizationunid
  LEFT JOIN edw_dds.hub_dim_region br
    ON upper(o.fldpoint2addressregion) = upper(br.source_key)
    AND br.exp_dttm = '2999-12-31 00:00:00'
  LEFT JOIN edw_dds.dim_region drg
    ON drg.region_key = br.region_key
    AND drg.deleted_ind = 0
    AND drg.exp_dttm = '2999-12-31 00:00:00'
  LEFT JOIN edw_dds.dim_branch db
    ON db.branch_key = drg.branch_key
    AND db.deleted_ind = 0
    AND db.exp_dttm = '2999-12-31 00:00:00'
  LEFT JOIN
  (
    SELECT
      row_number() OVER (PARTITION BY localsystemid ORDER BY currentversion DESC) AS rn,
      cl.flddocumentunid,
      cl.form,
      cl.currentversion,
      cl.fldinn,
      cl.fldorganizationsegment
    FROM edw_ods.t_000137_client cl
  ) cl
    ON cl.flddocumentunid = o.fldorganizationunid
    AND cl.form = 'formOrganization'
    AND cl.currentversion = l.max_version
    AND cl.rn = 1
WHERE ((o.calendar_key >= to_date('2017-01-01', 'yyyy-mm-dd')
       AND o.calendar_key <= to_date('20190630', 'YYYYMMDD'))
       AND o.calendar_key >= o.serv_startdate)
  AND o.serv_startdate IS NOT NULL
  AND upper(o.fldWFStatus) <> 'ЗАКАЗ ПЕРЕПОДПИСАН';

ANALYSE edw_stg_dmcm.pre_wifi_services_1_prt_p000151;