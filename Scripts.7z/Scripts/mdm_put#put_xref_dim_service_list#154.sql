/*rev.29753 от 30.05.2019*/
delete from edw_stg_mdm.put_xref_dim_service_list where src_id = 000154;

insert into edw_stg_mdm.put_xref_dim_service_list 
(
  source_key,
  source_name,
  src_id
)
SELECT distinct
	src_id||'_'||coalesce(p5_pack,'null')  as source_key
	,p5_pack  as source_name
	,src_id as src_id
FROM
	edw_ods.t_000154_efftp_oo_eff_tp as eff;
  
analyze edw_stg_mdm.put_xref_dim_service_list;