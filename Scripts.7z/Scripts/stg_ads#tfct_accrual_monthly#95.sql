/*rev. 47654 28.01.2020*/
set optimizer = on;
truncate table edw_stg_ads.tfct_accrual_monthly_1_prt_p000095;
insert into    edw_stg_ads.tfct_accrual_monthly_1_prt_p000095
(
	calendar_key,
	year_month_key,
	adjust_period,
	adjust_type_key,
	subs_key,
	account_key,
	period_account_name,
	center_num_key,
	duty_num_key,
	service_key,
	frequency_services_key,
	technology_type_key,
	service_rtk_detail_key,
	rc_key,
	segment_key,
	branch_key,
	region_key,
	partner_key,
	period_tax_number,
	charge_rub,
	adjust_rub,
	src_id,
	load_dttm,
	wf_run_id,
	md5
)
with dim_account as (
				select account_key, partner_key,center_num_key,duty_num_key,account_name,branch_key
				from edw_dds.dim_account_1_prt_p000095 da
				where  to_date('20190601', 'YYYYMMDD')+ interval '1 month -1 sec'  between da.eff_dttm and da.exp_dttm
						and da.deleted_ind = 0
						and da.branch_key <> -2
)
,dim_partner as (
select partner_key,segment_key,tax_number_cval from  edw_dds.dim_partner_1_prt_p000095 AS dp
					where  to_date('20190601', 'YYYYMMDD')+ interval '1 month -1 sec' between dp.eff_dttm and dp.exp_dttm
						and dp.deleted_ind = 0
						and dp.partner_key <> -2
)
Select
	total_charge.calendar_key,
	to_char(total_charge.calendar_key, 'YYYYMM') 				as year_month_key,
	total_charge.adjust_period,
	total_charge.adjust_type_key,
	total_charge.subs_key,
	total_charge.account_key,
	total_charge.account_name									as period_account_name,
	total_charge.center_num_key,
	total_charge.duty_num_key,
	total_charge.service_key,
	total_charge.frequency_services_key,
	total_charge.technology_type_key,
	total_charge.service_rtk_detail_key,
	total_charge.rc_key,
	total_charge.segment_key,
	total_charge.branch_key,
	total_charge.region_key,
	total_charge.partner_key,
	total_charge.tax_number_cval								as period_tax_number,
	sum(total_charge.charge_rub)								as charge_rub,
	sum(total_charge.adjust_rub)								as adjust_rub,
	total_charge.src_id,
	CURRENT_TIMESTAMP as load_dttm,
	-1 as wf_run_id,
	MD5
		(((((((((((((((((((((
			COALESCE(total_charge.subs_key::text, ''::text)) || CHR(9)) ||
			COALESCE(total_charge.calendar_key::text, ''::text)) || CHR(9)) ||
			COALESCE(total_charge.partner_key::text, ''::text)) || CHR(9)) ||
			COALESCE(total_charge.segment_key::text, ''::text)) || CHR(9)) ||
			COALESCE(total_charge.account_key::text, ''::text)) || CHR(9)) ||
			COALESCE(total_charge.account_name::text, ''::text)) || CHR(9)) ||
			COALESCE(total_charge.branch_key::text, ''::text))|| CHR(9)) ||
			COALESCE(total_charge.service_rtk_detail_key::text, ''::text)) || CHR(9)) ||
			COALESCE(total_charge.technology_type_key::text, ''::text)) || CHR(9)) ||
			COALESCE(total_charge.service_key::text, ''::text)) || CHR(9))
		) AS md5
from
	(
		Select
			date_trunc('day', total_charge.calendar_key) 		as calendar_key,
			total_charge.adjust_period,
			total_charge.adjust_type_key,
			total_charge.subs_key,
			total_charge.account_key,
			da.account_name,
			coalesce(da.center_num_key, 0)						as center_num_key,
			coalesce(da.duty_num_key, 0)						as duty_num_key,
			coalesce(total_charge.service_key, -1) 				as service_key,
			coalesce(srv.frequency_services_key, -1)			as frequency_services_key,
			coalesce(srv.technology_type_key, -1)				as technology_type_key,
			coalesce(srv.service_rtk_detail_key, -1)			as service_rtk_detail_key,
			case
				when total_charge.rc_key <> -1 then total_charge.rc_key
				when total_charge.rc_key = -1 and  mrc.matrix_rc_key is not null then mrc.rc_key
				else -1
			end	as rc_key,
			coalesce(dp.segment_key, -1)						as segment_key,
			coalesce(da.branch_key, -1)							as branch_key,
			coalesce(da.partner_key, -1)						as partner_key,
			/*coalesce(dr.region_key, -1)*/ -1							as region_key,
			dp.tax_number_cval,
			total_charge.charge_rub,
			total_charge.adjust_rub,
			total_charge.src_id
		from
			(
					Select
						tch.subs_key,
						tch.service_key,
						tch.account_key,
						tch.rc_key,
						date_trunc('month', tch.charge_date) + interval '1 month -1 sec' as calendar_key,
						to_char(tch.charge_date, 'YYYYMM') as adjust_period,
						sum(tch.charge_rub) as charge_rub,
						0 as adjust_rub,
						-1 as adjust_type_key,
						tch.src_id
					From edw_dds.tfct_total_charge_1_prt_p000095 AS tch
					where
						tch.charge_period_start_dttm between to_date('20190601', 'YYYYMMDD') and (to_date('20190630', 'YYYYMMDD') + interval '1 day -1 sec')
						and tch.src_id=000095
					group by
						tch.subs_key,
						tch.service_key,
						tch.account_key,
						tch.rc_key,
						date_trunc('month', tch.charge_date) + interval '1 month -1 sec',
						to_char(tch.charge_date, 'YYYYMM'),
						tch.src_id
				UNION ALL
					Select
						adj.subs_key,
						adj.service_key,
						adj.account_key,
						adj.rc_key,
						date_trunc('month', adj.billing_dttm) + interval '1 month -1 sec' as calendar_key,
						adj.corr_billing_id as adjust_period,
						0 as charge_rub,
						adj.adjust_amt as adjust_rub,
						coalesce(adj.adjust_type_key, -1) as adjust_type_key,
						adj.src_id
					From edw_dds.tfct_adjust_1_prt_p000095 AS adj
					where
						adj.billing_dttm between  to_date('20190601', 'YYYYMMDD') and (to_date('20190630', 'YYYYMMDD') + interval '1 day -1 sec')
						and adj.src_id=000095
						and adj.adjust_type_key between 10000 and 19999
						and cast(adj.corr_billing_id as integer) >= cast(date_part('year', adj.billing_dttm)*100+1 as integer)
			) total_charge
				inner join dim_account AS da
					on da.account_key = total_charge.account_key
				inner join dim_partner  AS dp
					on dp.partner_key = da.partner_key
				left join edw_dds.dim_service AS srv
					on 	srv.service_key = total_charge.service_key
						and total_charge.calendar_key between srv.eff_dttm and srv.exp_dttm
						and srv.deleted_ind = 0
				left join edw_dds.dim_matrix_rc AS mrc
					on srv.service_rtk_detail_key = mrc.service_rtk_detail_key
						AND mrc.segment_key = dp.segment_key
						AND mrc.rc_default = 1
						and total_charge.calendar_key between mrc.eff_dttm and mrc.exp_dttm
						and mrc.deleted_ind = 0
			/*	left join edw_dds.dim_region as dr
					on da.branch_key = dr.branch_key
						and total_charge.calendar_key between dr.eff_dttm and dr.exp_dttm
						and dr.deleted_ind = 0
						*/
		where srv.service_key <> -2
	) as total_charge
group by
	total_charge.calendar_key,
	to_char(total_charge.calendar_key, 'YYYYMM'),
	total_charge.adjust_period,
	total_charge.adjust_type_key,
	total_charge.subs_key,
	total_charge.account_key,
	total_charge.account_name,
	total_charge.center_num_key,
	total_charge.duty_num_key,
	total_charge.service_key,
	total_charge.frequency_services_key,
	total_charge.technology_type_key,
	total_charge.service_rtk_detail_key,
	total_charge.rc_key,
	total_charge.segment_key,
	total_charge.branch_key,
	total_charge.region_key,
	total_charge.partner_key,
	total_charge.tax_number_cval,
	total_charge.src_id
;
commit;
analyze edw_stg_ads.tfct_accrual_monthly_1_prt_p000095 ;
  