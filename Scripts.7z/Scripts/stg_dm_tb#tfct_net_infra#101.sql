--rev. 53655 от 01.04.2020
truncate table edw_stg_dm_tb.tfct_net_infra_1_prt_p000101;
commit;
insert into edw_stg_dm_tb.tfct_net_infra_1_prt_p000101
  ( 
    load_date           ,
    house_key           ,
    entrance            ,
    floor               ,
    device_id           ,
    td_date             ,
    optics_type         ,
    optics_flg          ,
    speed_channel       ,
    device_type         ,
    access_type         ,
    device_name         ,
    device_type_name    ,
    model_name          ,
    vendor_name         ,
    ip_address          ,
    inv_proj_code       ,
    log_status          ,
    tech_status         ,
    create_date         ,
    modification_date   ,
    dsl_flg             ,
    mount_port_qty      ,
    busy_port_qty       ,
    ready_port_qty      ,
    busy_abn_port_qty   ,
    mount_tech_port_qty ,
    busy_tech_port_qty  ,
    wi_fi_flg           ,
    bshpd_flg           ,
    shpd_b2c_qty        ,
    iptv_b2c_qty        ,
    ota_b2c_qty         ,
    shpd_b2b_qty        ,
    iptv_b2b_qty        ,
    ota_b2b_qty         ,
    load_dttm           ,
    src_id
  )
with 
house as
  (
    --вычисляем связку дома с населенным пунктом и его атрибутами
    select
      h.house_key,
      case 
        when a.hierarchy_level in (4,6,65,90) 
          or (
            lower(a.city_name) in ('москва','санкт-петербург','севастополь') 
            and a.hierarchy_level in (1)
          )
          then a.address_key 
          else      
          case
            when a_par.hierarchy_level in (4,6,65,90)
              or (
                lower(a_par.city_name)    in ('москва','санкт-петербург','севастополь')
                and a_par.hierarchy_level in (1)
              )
              then a_par.address_key
              else
              case
                when a_par1.hierarchy_level in (4,6,65,90)
                  or (
                    lower(a_par1.city_name)    in ('москва','санкт-петербург','севастополь')
                    and a_par1.hierarchy_level in (1)
                  )
                  then a_par1.address_key
                  else
                  case
                    when a_par2.hierarchy_level in (4,6,65,90)
                      or (
                        lower(a_par2.city_name)    in ('москва','санкт-петербург','севастополь')
                        and a_par2.hierarchy_level in (1)
                      )
                      then a_par2.address_key
                  end
              end
          end
      end as address_key
    from
      edw_dds.dim_house h
      inner join
        edw_dds.dim_address a
        on
          h.address_key    = a.address_key
          and a.active_ind = 'Y'
      left join
        edw_dds.dim_address a_par
        on
          a_par.address_key    = a.parent_address_key
          and a_par.active_ind = 'Y'
      left join
        edw_dds.dim_address a_par1
        on
          a_par1.address_key    = a_par.parent_address_key
          and a_par1.active_ind = 'Y'
      left join
        edw_dds.dim_address a_par2
        on
          a_par2.address_key    = a_par1.parent_address_key
          and a_par2.active_ind = 'Y'
    where h.active_ind = 'Y'
  ),
ct as (
    select
      city_gid,
      case
        when upper(lt) like '%ВОЛС%' then 'ВОЛС'
        when upper(lt) like '%СПУТНИК%' then 'СПУТНИК'
        when upper(lt) like '%МЕДЬ%' then 'МЕДЬ'
          else mlt
      end as line_type
    from
      (
        select
          string_agg(line_type, ',' ORDER BY line_type) as lt,
          max(line_type)                                as mlt,
          city_gid
        from
          (
            select distinct
              city_gid,
              line_type
            from
              edw_ods.T_000240_X_RPT_CHD_250_10K gms
            where to_date('20190601', 'YYYYMMDD')+interval '1 month - 1second' between gms.eff_dttm and gms.exp_dttm
          )
          h
        group by
          city_gid
      )
      gg
  ),    
house_key_line_type as (
  select 
    a.house_key, 
    gms.line_type 
  from 
    house a
    inner join edw_dds.hub_dim_address ha 
      on ha.address_key = a.address_key
    inner join ct gms 
      on ha.source_key = gms.city_gid 
  ),
--подтягиваем данные витрины b2c по эффективности тарифных планов
eff as (
  select 
    hgid::numeric, 
    sum(case when serv_id = 1 then 1 else 0 end) as ota_b2c_qty,
    sum(case when serv_id = 2 then 1 else 0 end) as shpd_b2c_qty,
    sum(case when serv_id = 3 then 1 else 0 end) as iptv_b2c_qty
  from  edw_ods.t_000155_efftp_oo_eff_tp oo_eff_tp 
  where
    tech_dt= to_date('20190601', 'YYYYMMDD') - interval '1 month'
    and coalesce(oo_eff_tp.charge_only_flag, 0) <> 1
    and coalesce(oo_eff_tp.p24_qnt_end_rp_shpd, 0) + coalesce(oo_eff_tp.p81_qnt_end_rp_ota, 0) + coalesce(oo_eff_tp.p83_qnt_end_rp_iptv, 0) > 0 
    and oo_eff_tp.abn_id is not null
    and oo_eff_tp.account is not null 
    and serv_id in (1,2,3)
  group by hgid
),
ia as (
  select
    a1.node_id                      as nod,
    string_agg (a2.ip_address, ',') as ip
  from
    edw_ods.t_000101_network_interface a1
  inner join
    edw_ods.t_000101_ip_address a2
    on
      a1.network_address_id = a2.ip_address_id
      and to_date('20190601', 'YYYYMMDD')+interval '1 month - 1second' between a2.eff_dttm and a2.exp_dttm
  where
    to_date('20190601', 'YYYYMMDD')+interval '1 month - 1second' between a1.eff_dttm and a1.exp_dttm
  group by
    a1.node_id
),
cu as (  
  select
    a3.node_id        nod,
    count (*)         me ,
    sum (a3.capacity) ze
  from
    edw_ods.t_000101_connection_unit a3
  inner join 
    edw_ods.t_000101_object          a4
      on a3.connection_unit_id = a4.object_id
      and a4.object_status_id in (258, 260, 386, 770)
      and to_date('20190601', 'YYYYMMDD')+interval '1 month - 1second' between a4.eff_dttm and a4.exp_dttm
  where
    a3.entity_id = 400037
    and to_date('20190601', 'YYYYMMDD')+interval '1 month - 1second' between a3.eff_dttm and a3.exp_dttm
  group by
    a3.node_id
  order by
    a3.node_id
),
adr  as (
select
  a5.object_id bid                ,
  a5.primary_address_id           ,
  a6.enterprise_branch_id         ,
  a9.name as filial_name          ,
  a6.region_category_id           ,
  a10.name as region_caterory_name,
  a5.private_sector               ,
  a6.region_tree_name             ,
  a8.street_type_name             ,
  a7.street_name                  ,
  a5.house                        ,
  a5.corpus
from
  edw_ods.t_000101_building_l a5
  inner join
    edw_ods.t_000101_region_l a6
    on
      a5.region_id = a6.object_id
      and to_date('20190601', 'YYYYMMDD')+interval '1 month - 1second' between a6.eff_dttm and a6.exp_dttm
  inner join
    edw_ods.t_000101_street_l a7
    on
      a5.street_id = a7.object_id
      and to_date('20190601', 'YYYYMMDD')+interval '1 month - 1second' between a7.eff_dttm and a7.exp_dttm
  inner join
    edw_ods.t_000101_street_type a8
    on
      a7.street_type_id = a8.street_type_id
      and to_date('20190601', 'YYYYMMDD')+interval '1 month - 1second' between a8.eff_dttm and a8.exp_dttm
  inner join
    edw_ods.t_000101_enterprise_branch a9
    on
      a6.enterprise_branch_id = a9.id
      and to_date('20190601', 'YYYYMMDD')+interval '1 month - 1second' between a9.eff_dttm and a9.exp_dttm
  inner join
    edw_ods.t_000101_region_category a10
    on
      a6.region_category_id = a10.region_category_id
      and to_date('20190601', 'YYYYMMDD')+interval '1 month - 1second' between a10.eff_dttm and a10.exp_dttm
where
  to_date('20190601', 'YYYYMMDD')+interval '1 month - 1second' between a5.eff_dttm and a5.exp_dttm
),
xtt as (
select
  n.node_id as device_id              ,
  ee.entity_id                        ,
  ee.entity_name      as device_type  ,
  e.entity_name       as model_name   ,
  o.invest_project_id as inv_proj_code,
  o.create_date                       ,
  o.availability_date                 ,
  n.object_name      as device_name        ,
  ia.ip              as ip_address         ,
  o.object_status_id as tech_status        ,
  os.object_status_name                    ,
  nt.type_name as device_type_name         ,
  n.building_id                            ,
  adr.primary_address_id                   ,
  adr.enterprise_branch_id                 ,
  adr.filial_name                          ,
  adr.region_category_id                   ,
  adr.region_caterory_name                 ,
  adr.private_sector                       ,
  adr.region_tree_name                     ,
  adr.street_type_name                     ,
  adr.street_name                          ,
  adr.house                                ,
  adr.corpus                               ,
  cu.me as tech_port_summ                  ,
  cu.ze as tech_port_busy_summ
from
  edw_ods.t_000101_node n
  inner join
    edw_ods.t_000101_object o
    on
      n.node_id = o.object_id
      and to_date('20190601', 'YYYYMMDD')+interval '1 month - 1second' between o.eff_dttm and o.exp_dttm
  inner join
    edw_ods.t_000101_object_status os
    on
      o.object_status_id = os.object_status_id
      and to_date('20190601', 'YYYYMMDD')+interval '1 month - 1second' between os.eff_dttm and os.exp_dttm
  inner join
    adr
    on
      n.building_id = adr.bid
  inner join
    edw_ods.t_000101_entity e
    on
      n.entity_id = e.entity_id
      and to_date('20190601', 'YYYYMMDD')+interval '1 month - 1second' between e.eff_dttm and e.exp_dttm
  inner join
    edw_ods.t_000101_entity ee
    on
      e.ancestor_id    = ee.entity_id
      and ee.entity_id = 1272000013
      and to_date('20190601', 'YYYYMMDD')+interval '1 month - 1second' between ee.eff_dttm and ee.exp_dttm
  left join
    edw_ods.t_000101_telephone_network_type nt
    on
      n.tel_network_type_id = nt.telephone_network_type_id
      and to_date('20190601', 'YYYYMMDD')+interval '1 month - 1second' between nt.eff_dttm and nt.exp_dttm
  left join
    ia
    on
      n.node_id = ia.nod
  left join
    cu
    on
      n.node_id = cu.nod
where
  to_date('20190601', 'YYYYMMDD')+interval '1 month - 1second' between n.eff_dttm and n.exp_dttm
),
ent_id_vs_estate_house as (
select 
  e.external_id
  , hs.orponid 
  , row_number() over(partition by e.external_id order by e.estate_id) rn
 from
  edw_ods.t_000148_ent_id_vs_estate e
  inner join
    edw_ods.t_000148_ent_as_house hs
    on
      e.estate_id   = hs.ob_ned_id
      and hs.mrf_id = 354858664  
 where e.system_id = 354541477
 and hs.livestatus              = 1
 and hs.ob_ned_id is not null
),
--основные данные
 tc as (
-------------------------argus------------------------------------------------
select
  house_key                                    , --или orponid для дальнейшего перехода к house_key
  null               as entrance               ,
  null               as floor                  ,
  node_id            as device_id              ,
  null::date         as td_date                ,
  null::varchar      as optics_type            ,
  null::numeric      as optics_flg             ,
  null::varchar      as speed_channel          ,
  device_type        as device_type            ,
  device_relatioship as access_type            ,
  title              as device_name            ,
  entity_name        as device_type_name       ,
  model              as model_name             ,
  firm               as vendor_name            ,
  ip_address         as ip_address             ,
  code               as inv_proj_code          ,
  status             as log_status             ,
  trunc(status_id)   as tech_status            ,
  a.create_date      as create_date            ,
  null::date         as modification_date      ,
  0                  as dsl_flg                ,
  null::numeric      as mount_port_qty         ,
  null::numeric      as busy_port_qty          ,
  mounted            as ready_port_qty         ,
  involved           as busy_abn_port_qty      ,
  null::numeric      as mount_tech_port_qty    ,
  null::numeric      as busy_tech_port_busy_qty,
  0                  as wi_fi_flg              ,
  0                  as bshpd_flg              ,
  e.orponid
from
  edw_ods.t_000101_capacity_fttb_pon a
  inner join
    ent_id_vs_estate_house e
    on
      trunc(a.building_id)=e.external_id::numeric
      and  e.rn=1
  inner join
    edw_dds.hub_dim_house hb
    on
      e.orponid::varchar = hb.source_key
where
  a.tech_dt              =
  (
    select
      max(tech_dt)
    from
      edw_ods.t_000101_capacity_fttb_pon a
    where
      tech_dt between to_date('20190601', 'YYYYMMDD') and to_date('20190601', 'YYYYMMDD')+interval '1 month - 1second'
  )
union all
--брать на 1 число месяца в котором считаем!
select
  house_key                               , --или orponid для дальнейшего перехода к house_key
  doorway_name        as entrance         ,
  null                as floor            ,
  object_id           as device_id        ,
  null                as td_date          ,
  null                as optics_type      ,
  null                as optics_flg       ,
  null                as speed_channel    ,
  entity_name         as device_type      ,
  null                as access_type      ,
  title               as device_name      ,
  null                as device_type_name ,
  model_name          as model_name       ,
  firm_build_name     as vendor_name      ,
  ip_address          as ip_address       ,
  invest_project_code as inv_proj_code    ,
  object_status_name  as log_status       ,
  null                as tech_status      ,
  a.create_date       as create_date      ,
  null                as modification_date,
  1                   as dsl_flg          ,
  mount_summ                              ,
  mount_busy_summ                         ,
  mount_line_summ                         ,
  mount_line_busy_summ                    ,
  null                                    ,
  null                                    ,
  0 as wi_fi_flg                          ,
  0 as bshpd_flg                          ,
  e.orponid
from
  edw_ods.t_000101_xdsl_equip a
  inner join
    ent_id_vs_estate_house e
    on
      trunc(a.building_id)=e.external_id::numeric
      and  e.rn=1
  inner join
    edw_dds.hub_dim_house hb
    on
      e.orponid::varchar = hb.source_key
where
  to_date('20190601', 'YYYYMMDD')+interval '1 month - 1second' between valid_from and coalesce(valid_to::date, '2999-12-31'::date)
  and a.tech_dt=to_date('20190601', 'YYYYMMDD')
union all
select
  house_key                                           , --или orponid для дальнейшего перехода к house_key
  null                         as entrance            ,
  null                         as floor               ,
  object_id                    as device_id           ,
  null                         as td_date             ,
  null                         as optics_type         ,
  null                         as optics_flg          ,
  null                         as speed_channel       ,
  entity_name                  as device_type         ,
  null                         as access_type         ,
  null                         as device_name         ,
  null                         as device_type_name    ,
  model_name                   as model_name          ,
  firm_build_name              as vendor_name         ,
  ip_address                   as ip_address          ,
  invest_project_code::varchar as inv_proj_code       ,
  object_status_name           as log_status          ,
  null                         as tech_status         ,
  a.create_date                as create_date         ,
  null                         as modification_date   ,
  0                            as dsl_flg             ,
  null                         as mount_summ          ,
  null                         as mount_busy_summ     ,
  null                         as mount_line_summ     ,
  null                         as mount_line_busy_summ,
  null                         as tech_port_summ      ,
  null                         as tech_port_busy_summ ,
  case 
    when object_status_name IN ('Предварительная готовность', 'Готов') and entity_name in ('Точка доступа Wi-Fi', 'Репитер Wi-Fi') 
      then 1 
    else 0 
  end as WI_FI_FLG,
  case 
    when object_status_name IN ('Предварительная готовность', 'Готов') and entity_name in ('Базовая станция БШПД') 
      then 1 
    else 0 
  end AS BSHPD_FLG,
  e.orponid
from
  edw_ods.t_000101_wba_equip a
  inner join
    ent_id_vs_estate_house e
    on
      trunc(a.building_id)=e.external_id::numeric
      and  e.rn=1
  inner join
    edw_dds.hub_dim_house hb
    on
      e.orponid::varchar = hb.source_key
where
  to_date('20190601', 'YYYYMMDD')+interval '1 month - 1second' between valid_from and coalesce(valid_to::date, '2999-12-31'::date)
  and a.tech_dt = to_date('20190601', 'YYYYMMDD')
union all
select
  house_key                                             , --или orponid для дальнейшего перехода к house_key
  null as entrance                                      ,
  null as floor                                         ,
  a.device_id                                           ,
  null as td_date                                       ,
  null as optics_type                                   ,
  null as optics_flg                                    ,
  null as speed_channel                                 ,
  a.device_type                                         ,
  null as access_type                                   ,
  a.device_name                                         ,
  a.device_type_name                                    ,
  a.model_name                                          ,
  null as vendor_name                                   ,
  a.ip_address                                          ,
  cast (a.inv_proj_code as varchar) as inv_proj_code    ,
  null                              as log_status       ,
  trunc(a.tech_status)              as tech_status      ,
  a.create_date                     as create_date      ,
  null                              as modification_date,
  0                                                     ,
  null                                                  ,
  null                                                  ,
  null                                                  ,
  null                                                  ,
  cast(tech_port_summ as      numeric)                       ,
  cast(tech_port_busy_summ as numeric)                       ,
  0                                                          ,
  0                                                          ,
  e.orponid
from
  xtt a
  inner join
    ent_id_vs_estate_house e
    on
      trunc(a.building_id)=e.external_id::numeric
      and  e.rn=1
  inner join
    edw_dds.hub_dim_house hb
    on
      e.orponid::varchar = hb.source_key
)

select
  to_date('20190601', 'YYYYMMDD') as load_date,
  t.house_key                                          ,
  entrance                                             ,
  floor                                                ,
  device_id                                            ,
  td_date                                              ,
  hklt.line_type optics_type                           ,
  case 
    when (Device_type in ('Коммутатор', 'Плата', 'Базовая станция СС', 'Голосовой шлюз', 'Логический модуль', 'Маршрутизатор') and Access_type = 'Оборудование агрегации')
        or Device_type in ('OLT', 'Оптический сплиттер') 
        or Line_type = 'ВОЛС'
      then 1 
    else 0 
  end as optics_flg                                    ,
  speed_channel                                        ,
  device_type                                          ,
  access_type                                          ,
  device_name                                          ,
  device_type_name                                     ,
  model_name                                           ,
  vendor_name                                          ,
  ip_address                                           ,
  inv_proj_code                                        ,
  log_status                                           ,
  tech_status                                          ,
  create_date                                          ,
  modification_date                                    ,
  dsl_flg                                              ,
  mount_port_qty                                       ,
  busy_port_qty                                        ,
  ready_port_qty                                       ,
  busy_abn_port_qty                                    ,
  mount_tech_port_qty                                  ,
  busy_tech_port_busy_qty                              ,
  wi_fi_flg                                            ,
  bshpd_flg                                            ,
  shpd_b2c_qty                                         ,
  iptv_b2c_qty                                         ,
  ota_b2c_qty                                          ,
  null         as shpd_b2b_qty                         ,
  null         as iptv_b2b_qty                         ,
  null         as ota_b2b_qty                          ,
  now()        as load_dttm                            ,
  000101 as src_id
from
  tc t
  left join
    eff
    on
      t.orponid = eff.hgid
  left join 
    house_key_line_type hklt
    on t.house_key=hklt.house_key
;

commit;
analyze edw_stg_dm_tb.tfct_net_infra_1_prt_p000101;
