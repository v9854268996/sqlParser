/*rev.58030 18.05.2020*/

TRUNCATE edw_stg_dds.t_000030_dim_account;
INSERT INTO edw_stg_dds.t_000030_dim_account
(
  account_key,
  account_name,
  partner_key,
  branch_key,
  region_key,
  duty_num_key,
  center_num_key,
  cession_date,
  src_id,
  parent_account_key,
  start_date,
  end_date,
  eff_dttm,
  exp_dttm
)
	
  WITH
      sel AS
    (
        SELECT DISTINCT dfdogovor_main,dfdogovor,min(dfdatebegin)
          OVER (PARTITION BY dfdogovor, rank_sum ) AS dfdatebegin, max(dfdateend)
          OVER (PARTITION BY dfdogovor, rank_sum ) AS dfdateend,min(dfdatebegin)
          OVER (PARTITION BY dfdogovor ) AS acc_act, max(dfdateend)
          OVER (PARTITION BY dfdogovor ) AS acc_conc
        FROM (
               select *,sum(rank_dif)
                 OVER (PARTITION BY dfdogovor ORDER BY rn ) AS rank_sum
               FROM (
                      SELECT *,
                        CASE
                        WHEN
                          coalesce(lag(dfdogovor_main) OVER (PARTITION BY dfdogovor ORDER BY rn ), dfdogovor_main) = dfdogovor_main
                          THEN 0
                        ELSE 1
                        END AS rank_dif
                      FROM (
                             SELECT*,
                               row_number()
                               OVER ( PARTITION BY dfdogovor ORDER BY dfdatebegin, dfdateend, dfdogovor_main ) rn
                             FROM (
                                    SELECT
                                      dop.dfdogovor_main,
                                      dop.dfdogovor,
                                      coalesce(dop.dfdatebegin, '19000101' :: TIMESTAMP) AS dfdatebegin,
                                      coalesce(dop.dfdateend, '29991231' :: TIMESTAMP)   AS dfdateend
                                    FROM edw_ods.t_000030_tdogovor_operator dop
                                    WHERE dop.deleted_ind = 0
                                    union                                
                                    SELECT
                                      dfdogovor_main,
                                      dfdogovor,
                                      coalesce(dfdatebegin, '19000101' :: TIMESTAMP) AS dfdatebegin,
                                      coalesce(dfdateend, '29991231' :: TIMESTAMP)   AS dfdateend
                                    FROM edw_ods.t_000030_tdogovor_union du
                                    WHERE
                                      du.deleted_ind = 0
                                  ) l1
                           ) l2
                    ) l3
             ) l4
    )
    , sel1 AS
  (
      SELECT
        d.dfdogovor                                                     AS account_key,
        d.dfaccount                                                     AS account_name,
        d.dfabonent                                                     AS partner_key,
        d.dfbranch                                                      AS branch_key,
        coalesce(lts.duty_num_key, '0')                                 AS duty_num_key,
        coalesce(lts.center_num_key, '0')                               AS center_num_key,
		tadddata.dfdate													as cession_date,
        coalesce(sel.dfdatebegin, '19000101'::timestamp)               AS start_dates,
        coalesce(sel.dfdateend, '29991231'::timestamp)                 AS end_dates,
        d.src_id                                                        AS src_id,
        -1                                                              AS workflow,
        current_timestamp(6)                                            AS load_dttm,
        3                                                               AS agent_scheme_key,
        -- Прямой договор
        sel.dfdogovor_main                                              AS parent_account_key,
        row_number()
        OVER (PARTITION BY d.dfdogovor ORDER BY sel.dfdatebegin, sel.dfdateend, sel.dfdogovor_main ) AS rn
      FROM edw_ods.t_000030_tdogovor d
      LEFT JOIN sel ON (sel.dfdogovor = d.dfdogovor)
      LEFT JOIN edw_stg_dds.t_kurs_group_filter_lts lts
        ON lts.dflinepartgroup = d.DFLinepartGroup :: NUMERIC(38, 0)
           AND lts.src_id = d.src_id
      LEFT JOIN (select dfid, min(dfdate) as dfdate
				from edw_ods.t_000027_tadddata 
				where dfaddtype=100000000004005
				and dfdelete = 'F'
				group by dfid)  tadddata	
        ON  d.dfdogovor = tadddata.dfid					
      WHERE d.dfdogtype <> 1234567
            AND d.deleted_ind = 0
            AND (d.src_id = 39 OR (d.dfdelete <> 'T' OR d.dfdelete IS NULL))
		--	AND to_date('20190601', '~p_dt_format~') + INTERVAL '1 day - 1 second' between d.eff_dttm and d.exp_dttm --scd2
  )
  SELECT
    account_key,
    account_name,
    partner_key,
    branch_key,
    branch_key                                     AS region_key,
    duty_num_key,
    center_num_key,
	cession_date,
    src_id,
    parent_account_key,
    start_date,
    end_date,
    start_date                                     AS eff_dttm,
    end_date                                       AS exp_dttm
  FROM (
         SELECT
           account_key,
           coalesce(dfaccount, account_name) AS account_name,
           partner_key,
           branch_key,
           branch_key                        AS region_key,
           duty_num_key,
           center_num_key,
		   cession_date,
           src_id,
           parent_account_key,
           CASE
				WHEN dfdatebegin > start_date THEN dfdatebegin ELSE start_date
           END  AS start_date,
           CASE
           WHEN dfdateend < end_date THEN dfdateend ELSE end_date
           END  AS end_date
         FROM (
                SELECT
                  account_key,
                  account_name,
                  partner_key || '#' || dfactivity_dop_segment AS partner_key,
                  branch_key,
                  branch_key                                   AS region_key,
                  duty_num_key,
                  center_num_key,
				  cession_date,
                  src_id,
                  parent_account_key,
                  CASE
                  WHEN datebeginseg > start_date
                    THEN datebeginseg
                  ELSE start_date
                  END                                          AS start_date,
                  CASE
                  WHEN dateendseg < end_date
                    THEN dateendseg
                  ELSE end_date
                  END                                          AS end_date
                FROM (
                       SELECT
                         t.account_key,
                         t.account_name,
                         t.partner_key,
                         t.branch_key,
                         t.branch_key                              AS region_key,
                         t.duty_num_key,
                         t.center_num_key,
						 t.cession_date,
                         t.src_id,
                         t.parent_account_key,
                         t.start_date,
                         t.end_date,
                         coalesce(tds.dfactivity_dop_segment, 'N') AS dfactivity_dop_segment,
                         dfdatebegin                               AS datebeginseg,
                         dfdateend                                 AS dateendseg
                       FROM (
							         SELECT * from (
										 SELECT
											sel1.src_id || ';' || sel1.account_key :: NUMERIC(38, 0) AS account_key,
											sel1.account_name,
											sel1.src_id || ';' || sel1.partner_key :: NUMERIC(38, 0) AS partner_key,
											sel1.src_id || ';' || sel1.branch_key :: NUMERIC(38, 0)  AS branch_key,
											sel1.duty_num_key,
											sel1.center_num_key,
											sel1.cession_date,
											sel1.src_id,
											sel1.parent_account_key                                  AS parent_account_key,
											CASE
											WHEN
											  sel1.rn = 1
											  THEN '19000101'
											ELSE sel1.start_dates
											END                                                      AS start_date,
											CASE
											WHEN
											  sel1.rn = max(sel1.rn) OVER (PARTITION BY sel1.account_key )
											  THEN '29991231'
											ELSE
											  lead(sel1.start_dates)OVER (PARTITION BY sel1.account_key ORDER BY sel1.rn ) - INTERVAL '1 sec' END            AS end_date
										  FROM sel1
										) t0
									WHERE 	start_date < end_date
									)t	
									 
                         LEFT JOIN (
                                     SELECT
                                       dfdogovor,
                                       src_id,
                                       dfactivity_dop_segment,
                                       suma,
                                       min(ndfdatebegin) AS dfdatebegin,
                                       max(ndfdateend)   AS dfdateend
                                     FROM (
                                            SELECT
                                              *,
                                              sum(dif)
                                              OVER (
                                                PARTITION BY dfdogovor
                                                ORDER BY rn )                                                  suma,
                                              decode(rn, 1, '19000101',
                                                     dfdatebegin)                                           AS ndfdatebegin,
                                              decode(rn, max(rn)
                                              OVER (
                                                PARTITION BY dfdogovor ), '29991231',
                                                     dfdateend)                                             AS ndfdateend
                                            FROM (
                                                   SELECT
                                                     *,
                                                     CASE
                                                     WHEN lag(dfactivity_dop_segment)
                                                          OVER (
                                                            PARTITION BY dfdogovor
                                                            ORDER BY rn ) = dfactivity_dop_segment
                                                       THEN 0
                                                     ELSE 1
                                                     END dif
                                                   FROM (
                                                          SELECT
                                                            dfdogovor,
                                                            src_id,
                                                            CASE
                                                            WHEN dfactivity_dop_segment
                                                                 IS NULL
                                                              THEN NULL
                                                            WHEN dfactivity_dop_segment = -23
                                                              THEN 'N'
                                                            ELSE 'Y' END                               dfactivity_dop_segment,
                                                            dfdatebegin,
                                                            coalesce(dfdateend, '29991231'::timestamp) dfdateend,
                                                            row_number()
                                                            OVER (
                                                              PARTITION BY dfdogovor
                                                              ORDER BY dfdatebegin, dfdateend )        rn
                                                          FROM edw_ods.t_000030_tdog_dop_segment
                                                          WHERE dfactivity_dop_segment
                                                                IS NOT NULL AND dfdatebegin
                                                                                IS NOT NULL AND deleted_ind = 0
                                                        ) lvl1
                                                 ) lvl2
                                          ) lvl3
                                     GROUP BY dfdogovor, src_id, dfactivity_dop_segment, suma) tds
                           ON tds.src_id || ';' || tds.dfdogovor :: NUMERIC(38) = t.account_key
                              AND
                              (dfdatebegin
                               BETWEEN start_date
                               AND end_date
                               OR dfdateend
                               BETWEEN start_date
                               AND end_date
                               OR start_date
                               BETWEEN dfdatebegin
                               AND dfdateend
                               OR end_date
                               BETWEEN dfdatebegin
                               AND dfdateend)
                     ) tt
              ) ttt
           LEFT JOIN (
                       SELECT
                         dfdogovor_ref,
                         dfaccount,
                         dfdatebegin,
							 CASE
							 WHEN rn = max(rn)OVER (PARTITION BY dfdogovor_ref )
							 THEN '29991231'
							 ELSE dfdateend
                         END AS dfdateend
                       FROM (
                              SELECT
                                dfdogovor_ref,
                                dfaccount,
                                CASE
                                WHEN rn = 1
                                  THEN '19000101'
                                ELSE dfdatebegin
                                END                                                                 AS dfdatebegin,
                                coalesce(lead(dfdatebegin) OVER (PARTITION BY dfdogovor_ref ORDER BY rn ) - INTERVAL '1 sec', '29991231'::timestamp) AS dfdateend,
                                rn
                              FROM (
                                     SELECT
                                       tels_link.src_id || ';' ||
                                       tels_link.dfdogovor_ref :: NUMERIC(38)   AS                           dfdogovor_ref,
                                       dogovor_nls.dfaccount,
                                       date_trunc('day',tels_link.dfdatebegin)        AS                           dfdatebegin,
                                       coalesce(tels_link.dfdateend, '29991231'::timestamp)                  dfdateend,
                                       row_number() OVER (PARTITION BY dfdogovor_ref ORDER BY tels_link.dfdatebegin,
                                       coalesce(tels_link.dfdateend, '29991231'::TIMESTAMP), dfaccount ) rn
                                     FROM edw_ods.t_000030_tels_dogovor_link tels_link
                                    JOIN edw_ods.t_000030_tdogovor dogovor_nls
                                      ON tels_link.dfels_dogovor = dogovor_nls.dfdogovor
                                    WHERE dfdogtype = 1234567
                                   ) nls1
                            ) nls2
                       WHERE dfdateend > dfdatebegin) nls 
					   ON nls.dfdogovor_ref = ttt.account_key
						 AND
						 (dfdatebegin BETWEEN start_date AND end_date
						  OR 
						  dfdateend BETWEEN start_date AND end_date
						  OR  
						  start_date BETWEEN dfdatebegin AND dfdateend
						  OR 
						  end_date BETWEEN dfdatebegin AND dfdateend)
						  )
       tttt;
commit;
analyze edw_stg_dds.t_000030_dim_account;