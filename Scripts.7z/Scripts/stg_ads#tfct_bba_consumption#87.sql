/*rev.34588 31.07.2019 Changed by: NAREK.ALAVERDYAN */
		--TFCT_BBA_CONSUMPTION
		truncate table edw_stg_ads.tfct_bba_consumption_1_prt_p000087;
		insert into edw_stg_ads.tfct_bba_consumption_1_prt_p000087
			(
				calendar_key,
				year_month_key,
				adjust_period,
				subs_key,
				partner_key,
				segment_key,
				account_key,
				period_account_name,
				center_num_key,
				duty_num_key,
				branch_key,
				region_key,
				type_of_billing_services_key,
				service_rtk_detail_key,
				rc_key,
				technology_type_key,
				service_type_key,
				service_key,
				total_download_data_volume,
				total_upload_data_volume,
				src_id,
				load_dttm,
				wf_run_id,
				md5
			)

		SELECT 
			spd.calendar_key,
			to_char(spd.calendar_key, 'YYYYMM') AS year_month_key,
			spd.adjust_period,
			spd.subs_key,
			spd.partner_key,
			spd.segment_key,
			spd.account_key,
			spd.account_name AS period_account_name,
			spd.center_num_key,
			spd.duty_num_key,
			spd.branch_key,
			spd.region_key,
			spd.type_of_billing_services_key,
			spd.service_rtk_detail_key,
			spd.rc_key,
			spd.technology_type_key,
			spd.service_type_key,
			spd.service_key,
			SUM(spd.download_data_volume) AS total_download_data_volume,
			SUM(spd.upload_data_volume) AS total_upload_data_volume,
			spd.src_id,
			CURRENT_TIMESTAMP as load_dttm,
			-1 as wf_run_id,
			MD5 
				(((((((((((((((((((((((((
					COALESCE(spd.subs_key::text, ''::text)) || CHR(9)) ||
					COALESCE(spd.calendar_key::text, ''::text)) || CHR(9)) ||
					COALESCE(spd.partner_key::text, ''::text)) || CHR(9)) ||
					COALESCE(spd.segment_key::text, ''::text)) || CHR(9)) ||
					COALESCE(spd.account_key::text, ''::text)) || CHR(9)) ||
					COALESCE(spd.account_name::text, ''::text)) || CHR(9)) ||
					COALESCE(spd.branch_key::text, ''::text))|| CHR(9)) ||
					COALESCE(spd.type_of_billing_services_key::text, ''::text)) || CHR(9)) ||
					COALESCE(spd.service_rtk_detail_key::text, ''::text)) || CHR(9)) ||
					COALESCE(spd.technology_type_key::text, ''::text)) || CHR(9)) ||
					COALESCE(spd.service_type_key::text, ''::text)) || CHR(9)) ||
					COALESCE(spd.service_key::text, ''::text)) || CHR(9))
				) AS md5
		FROM
			(
				SELECT
					date_trunc('day', spd.calendar_key) as calendar_key,
					spd.adjust_period,
					COALESCE(spd.subs_key, -1) AS subs_key,
					COALESCE(dp.partner_key, -1) AS partner_key,
					COALESCE(dp.segment_key, -1) AS segment_key,
					COALESCE(da.account_key, -1) AS account_key,
					da.account_name,
					COALESCE(da.center_num_key, 0) AS center_num_key,
					COALESCE(da.duty_num_key, 0) AS duty_num_key,
					COALESCE(da.branch_key, -1) AS branch_key,
					/*coalesce(dr.region_key, -1)*/ -1 as region_key,
					srv.type_of_billing_services_key,
					COALESCE(srv.service_rtk_detail_key, -1) AS service_rtk_detail_key,
					case 
						when spd.rc_key <> -1 then spd.rc_key
						when spd.rc_key = -1 and  mrc.matrix_rc_key is not null then mrc.rc_key
						else -1
					end	as rc_key,
					COALESCE(srv.technology_type_key, -1) AS technology_type_key,
					COALESCE(srv.service_type_key, -1) AS service_type_key,
					COALESCE(srv.service_key, -1) AS service_key,
					spd.download_data_volume,
					spd.upload_data_volume,
					spd.src_id
				FROM
					(
							SELECT
								subs_key,
								src_id,
								account_key,
								service_key,
								rc_key,
								billing_id as adjust_period,
								to_date(billing_id, 'YYYYMM') + INTERVAL '1 MONTH' + INTERVAL '-1 sec' AS calendar_key,
								SUM(download_data_vol_nval) AS download_data_volume,
								SUM(upload_data_vol_nval) AS upload_data_volume
							FROM edw_dds.tfct_bba_consumption_1_prt_p000087
							WHERE
								src_id=000087
								AND consumption_network_dttm BETWEEN 
									to_date('20190601' , 'YYYYMMDD')
									AND ( to_date('20190601' , 'YYYYMMDD') + INTERVAL '1 MONTH' + INTERVAL '-1 sec')


							GROUP BY 
								subs_key,
								src_id,
								account_key,
								service_key,
								rc_key,
								--to_char(consumption_network_dttm,'YYYYMM'),
								billing_id,
								--date_trunc('MONTH', consumption_network_dttm) + INTERVAL '1 MONTH' + INTERVAL '-1 sec' 
								to_date(billing_id, 'YYYYMM') + INTERVAL '1 MONTH' + INTERVAL '-1 sec'
					) AS spd
						JOIN edw_dds.dim_account_1_prt_p000087 AS da
							ON spd.account_key = da.account_key
								AND spd.calendar_key between da.eff_dttm and da.exp_dttm
								AND da.deleted_ind = 0
								and da.branch_key <> -2

						JOIN edw_dds.dim_partner_1_prt_p000087 AS dp
							ON da.partner_key = dp.partner_key
								AND spd.calendar_key between dp.eff_dttm and dp.exp_dttm
								AND dp.deleted_ind = 0
								and dp.segment_key <> -2

						LEFT JOIN edw_dds.dim_service AS srv
							ON srv.service_key = spd.service_key
								AND srv.deleted_ind = 0
								AND srv.exp_dttm = '2999-12-31'

						LEFT JOIN edw_dds.dim_matrix_rc AS mrc
							ON srv.service_rtk_detail_key = mrc.service_rtk_detail_key
								AND mrc.segment_key = dp.segment_key
								AND mrc.rc_default = 1
								AND mrc.deleted_ind = 0
								AND mrc.exp_dttm = '2999-12-31'
						/*left join edw_dds.dim_region as dr
							on da.branch_key = dr.branch_key
								and dr.exp_dttm = '2999-12-31'
								and dr.deleted_ind = 0*/
				WHERE srv.service_key <> -2
			) AS spd
		GROUP BY
			spd.calendar_key,
			to_char(spd.calendar_key, 'YYYYMM'),
			spd.adjust_period,
			spd.subs_key,
			spd.partner_key,
			spd.segment_key,
			spd.account_key,
			spd.account_name,
			spd.center_num_key,
			spd.duty_num_key,
			spd.branch_key,
			spd.region_key,
			spd.type_of_billing_services_key,
			spd.service_rtk_detail_key,
			spd.rc_key,
			spd.technology_type_key,
			spd.service_type_key,
			spd.service_key,
			spd.src_id
		;

		ANALYZE edw_stg_ads.tfct_bba_consumption_1_prt_p000087;
	