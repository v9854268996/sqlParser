--rev.45268 от 19.12.2019
delete from edw_stg_mdm.put_xref_dim_region_mis where src_id BETWEEN 107 and 113;

insert into edw_stg_mdm.put_xref_dim_region_mis (source_key, branch_src_name, src_id)
select
 distinct source_key::numeric,
 case
  when source_key = '728' then 'Амурский'
  when source_key = '765' then 'Сахалинский'
  when source_key = '725' then'Приморский'
  when source_key = '727' then 'Хабаровский'
  when source_key = '741' then 'Камчатский'
  when source_key = '749' then 'Магаданский'
  when source_key = '714' then 'Сахателеком'
  when source_key = '787' then 'Чукотский АО'
  when source_key = '779' then 'Еврейская АО'
 end branch_src_name,
 src_id
from (
select distinct substring(account from 1 for 3) as source_key, src_id from edw_ods.t_000107_t_users u
 where 1=1
      and u.deleted_ind = 0
 UNION ALL
select distinct substring(account from 1 for 3) as source_key, src_id from edw_ods.t_000108_t_users u
 where 1=1
      and u.deleted_ind = 0
 UNION ALL
select distinct substring(account from 1 for 3) as source_key, src_id from edw_ods.t_000109_t_users u
 where 1=1
      and u.deleted_ind = 0
 UNION ALL
select distinct substring(account from 1 for 3)  as source_key, src_id  from edw_ods.t_000110_t_users u
 where 1=1
      and u.deleted_ind = 0
 UNION ALL
select distinct substring(account from 1 for 3) as source_key, src_id  from edw_ods.t_000111_t_users u
 where 1=1
      and u.deleted_ind = 0
 UNION ALL
select distinct substring(account from 1 for 3)  as source_key, src_id from edw_ods.t_000112_t_users u
 where 1=1
      and u.deleted_ind = 0
 UNION ALL
select distinct substring(account from 1 for 3) as source_key, src_id  from edw_ods.t_000113_t_users u
 where 1=1
      and u.deleted_ind = 0
) t;

analyze edw_stg_mdm.put_xref_dim_region_mis;