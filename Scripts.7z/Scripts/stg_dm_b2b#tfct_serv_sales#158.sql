-- rev. 59691 от 02.06.2020
SET search_path = edw_stg_dm_b2b;
SET optimizer = ON;
COMMIT;
-- Video src_id = 158 Находим новые заказы в дне расчета и новые камеры, сравнивая кол-во камер рассчетного дня с предыдущем днем
BEGIN;
  TRUNCATE TABLE edw_stg_dm_b2b.tfct_serv_sales_1_prt_p000158;
COMMIT;

BEGIN;
INSERT INTO edw_stg_dm_b2b.tfct_serv_sales_1_prt_p000158
(
  period,
  business_service_key,
  branch_key,
  segment_key,
  client_name,
  inn,
  account,
  order_num,
  order_dt,
  sales_channel,
  seller_name,
  shpd_migration_flg,
  serv_qnty,
  sale_serv_id,
  src_id,
  macro_segment_key
)
-- Определяем id бизнес услуги
WITH
w_service AS
(
  SELECT
         max(business_service_key) AS business_service_key
    FROM edw_dds.dim_business_service
   WHERE exp_dttm = '2999-12-31 00:00:00'
     AND upper(business_service_name) LIKE 'ВИДЕОНАБЛ%'
     AND active_ind = 'Y'
     AND deleted_ind = 0
),
-- Определяем К код по ЛС на данных СОО
w_coo_cl AS
(
  SELECT
         cln.day, cln.mrf_id, cln.account, cln.id_macro_segment_ud, mc.macro_segment AS k_code
    FROM (
           SELECT
                  dd.day, cl.mrf_id, cl.account, cl.id_macro_segment_ud,
                  row_number() OVER (PARTITION BY dd.day, mrf_id, cl.account ORDER BY cl.date_snap DESC) AS rn
             FROM edw_ods.t_000151_rprt_client_dwh cl
                  JOIN
                  (SELECT generate_series(to_date('20190601', 'YYYYMMDD'), to_date('20190630', 'YYYYMMDD'), '1 day'::interval) AS day) dd
                    ON coalesce(cl.data_contr, to_date('19000101','YYYYMMDD')) <= dd.day
            WHERE coalesce(cl.data_close, to_date('29991231', 'YYYYMMDD')) >= to_date('20180101', 'YYYYMMDD')
              --AND coalesce(cl.data_contr, to_date('20190630', 'YYYYMMDD')) <= to_date('20190630', 'YYYYMMDD')
              AND id_macro_segment_ud IS NOT NULL
              AND cl.jr_type NOT IN (3, 6, 8)
              AND cl.deleted_ind = 0
            UNION ALL
           SELECT
                  dd.day, cl.mrf_id, cl.account, cl.id_macro_segment_ud,
                  row_number() OVER (PARTITION BY dd.day, mrf_id, cl.account ORDER BY cl.date_snap DESC) AS rn
             FROM edw_ods.t_000152_rprt_client_dwh cl
                  JOIN
                  (SELECT generate_series(to_date('20190601', 'YYYYMMDD'), to_date('20190630', 'YYYYMMDD'), '1 day'::interval) AS day) dd
                    ON coalesce(cl.data_contr, to_date('19000101','YYYYMMDD')) <= dd.day
            WHERE coalesce(cl.data_close, to_date('29991231', 'YYYYMMDD')) >= to_date('20180101', 'YYYYMMDD')
              --AND coalesce(cl.data_contr, to_date('20190630', 'YYYYMMDD')) <= to_date('20190630', 'YYYYMMDD')
              AND id_macro_segment_ud IS NOT NULL
              AND cl.jr_type NOT IN (3, 6, 8)
              AND cl.deleted_ind = 0
            UNION ALL
           SELECT
                  dd.day, cl.mrf_id, cl.account, cl.id_macro_segment_ud,
                  row_number() OVER (PARTITION BY dd.day, mrf_id, cl.account ORDER BY cl.date_snap DESC) AS rn
             FROM edw_ods.t_000153_rprt_client_dwh cl
                  JOIN
                  (SELECT generate_series(to_date('20190601', 'YYYYMMDD'), to_date('20190630', 'YYYYMMDD'), '1 day'::interval) AS day) dd
                    ON coalesce(cl.data_contr, to_date('19000101','YYYYMMDD')) <= dd.day
            WHERE coalesce(cl.data_close, to_date('29991231', 'YYYYMMDD')) >= to_date('20180101', 'YYYYMMDD')
              --AND coalesce(cl.data_contr, to_date('20190630', 'YYYYMMDD')) <= to_date('20190630', 'YYYYMMDD')
              AND id_macro_segment_ud IS NOT NULL
              AND cl.jr_type NOT IN (3, 6, 8)
              AND cl.deleted_ind = 0
            UNION ALL
           SELECT
                  dd.day, cl.mrf_id, cl.account, cl.id_macro_segment_ud,
                  row_number() OVER (PARTITION BY dd.day, mrf_id, cl.account ORDER BY cl.date_snap DESC) AS rn
             FROM edw_ods.t_000155_rprt_client_dwh cl
                  JOIN
                  (SELECT generate_series(to_date('20190601', 'YYYYMMDD'), to_date('20190630', 'YYYYMMDD'), '1 day'::interval) AS day) dd
                    ON coalesce(cl.data_contr, to_date('19000101','YYYYMMDD')) <= dd.day
            WHERE coalesce(cl.data_close, to_date('29991231', 'YYYYMMDD')) >= to_date('20180101', 'YYYYMMDD')
              --AND coalesce(cl.data_contr, to_date('20190630', 'YYYYMMDD')) <= to_date('20190630', 'YYYYMMDD')
              AND id_macro_segment_ud IS NOT NULL
              AND cl.jr_type NOT IN (3, 6, 8)
              AND cl.deleted_ind = 0
            UNION ALL
           SELECT
                  dd.day, cl.mrf_id, cl.account, cl.id_macro_segment_ud,
                  row_number() OVER (PARTITION BY dd.day, mrf_id, cl.account ORDER BY cl.date_snap DESC) AS rn
             FROM edw_ods.t_000156_rprt_client_dwh cl
                  JOIN
                  (SELECT generate_series(to_date('20190601', 'YYYYMMDD'), to_date('20190630', 'YYYYMMDD'), '1 day'::interval) AS day) dd
                    ON coalesce(cl.data_contr, to_date('19000101','YYYYMMDD')) <= dd.day
            WHERE coalesce(cl.data_close, to_date('29991231', 'YYYYMMDD')) >= to_date('20180101', 'YYYYMMDD')
              --AND coalesce(cl.data_contr, to_date('20190630', 'YYYYMMDD')) <= to_date('20190630', 'YYYYMMDD')
              AND id_macro_segment_ud IS NOT NULL
              AND cl.jr_type NOT IN (3, 6, 8)
              AND cl.deleted_ind = 0
            UNION ALL
           SELECT
                  dd.day, cl.mrf_id, cl.account, cl.id_macro_segment_ud,
                  row_number() OVER (PARTITION BY dd.day, mrf_id, cl.account ORDER BY cl.date_snap DESC) AS rn
             FROM edw_ods.t_000157_rprt_client_dwh cl
                  JOIN
                  (SELECT generate_series(to_date('20190601', 'YYYYMMDD'), to_date('20190630', 'YYYYMMDD'), '1 day'::interval) AS day) dd
                    ON coalesce(cl.data_contr, to_date('19000101','YYYYMMDD')) <= dd.day
            WHERE coalesce(cl.data_close, to_date('29991231', 'YYYYMMDD')) >= to_date('20180101', 'YYYYMMDD')
              --AND coalesce(cl.data_contr, to_date('20190630', 'YYYYMMDD')) <= to_date('20190630', 'YYYYMMDD')
              AND id_macro_segment_ud IS NOT NULL
              AND cl.jr_type NOT IN (3, 6, 8)
              AND cl.deleted_ind = 0
            UNION ALL
           SELECT
                  dd.day, cl.mrf_id, coalesce(a.nls, cl.nls_account, cl.account) AS account, cl.id_macro_segment_ud,
                  row_number() OVER (PARTITION BY dd.day, cl.mrf_id, coalesce(a.nls, cl.nls_account, cl.account) ORDER BY cl.date_snap DESC) AS rn
             FROM edw_ods.t_000154_rprt_client_dwh cl
                  LEFT JOIN
                  edw_ods.t_000158_efftp_south_nls_accnt a
                    ON a.date_end IS NULL
                   AND a.account = cl.account
                  JOIN
                  (SELECT generate_series(to_date('20190601', 'YYYYMMDD'), to_date('20190630', 'YYYYMMDD'), '1 day'::interval) AS day) dd
                    ON coalesce(cl.data_contr, to_date('19000101','YYYYMMDD')) <= dd.day
            WHERE coalesce(cl.data_close, to_date('29991231', 'YYYYMMDD')) >= to_date('20180101', 'YYYYMMDD')
              --AND coalesce(cl.data_contr, to_date('20190630', 'YYYYMMDD')) <= to_date('20190630', 'YYYYMMDD')
              AND id_macro_segment_ud IS NOT NULL
              AND cl.jr_type NOT IN (3, 6, 8)
              AND cl.deleted_ind = 0
         ) cln
         LEFT JOIN
         edw_ods.t_000158_rprt_dird_macro_sgmnt mc
           ON mc.id_macro_segment = cln.id_macro_segment_ud
          AND mc.deleted_ind = 0
		      AND mc.date_end >= cln.day
   WHERE cln.rn = 1
),
-- Новое подключение заказа
w_video AS
(
  SELECT
         o7n.period, o7n.mrf_bk, o7n.rf_bk, o7n.customer, o7n.inn, o7n.account_num, o7n.order_num,
         o7n.dt, o7n.moved_to_comm, sum(o7n.value_sum) AS value_sum
    FROM ( -- Убираем дубли, которые могли возникнуть при многоразовой загрузке
           SELECT -- DISTINCT
                  to_date(substring(a.f_name, 21, 8), 'YYYYMMDD') AS period,
                  a.mrf,
                  db.parent_branch_key AS mrf_bk,
                  a.rf,
                  hdb.branch_key AS rf_bk,
                  a.customer,
                  a.inn,
                  a.account_num,
                  a.order_num,
                  to_date(a.date_open, 'DD.MM.YYYY') AS dt,
                  a.moved_to_comm,
                  a.parametr,
                  value_sum::numeric
             FROM edw_ods.t_000158_report_o7_2data a
                  LEFT JOIN
                  edw_dds.hub_dim_branch hdb
                    ON hdb.src_id = 158
                   AND hdb.exp_dttm = '2999-12-31 00:00:00'
                   AND upper(hdb.source_key) = upper(a.rf)
                  LEFT JOIN
                  edw_dds.dim_branch db
                    ON db.exp_dttm = '2999-12-31 00:00:00'
                   AND db.branch_key = hdb.branch_key
                   AND db.deleted_ind = 0
            WHERE a.tech_dt >= to_date('20190601', 'YYYYMMDD') -- a.load_date >= to_date('20190601', 'YYYYMMDD')
              AND a.report_name = 'videocomfort'
              AND upper(a.account_num) NOT LIKE 'VA_%'
              AND upper(a.esb) = 'ДА'
              AND a.status = 'Работает'
              AND a.mode_type = 'Коммерческий'
              AND upper(a.parametr) LIKE '%NOP%'
              AND to_date(substring(a.f_name, 21, 8), 'YYYYMMDD') BETWEEN to_date('20190601', 'YYYYMMDD') - interval '1 day' AND to_date('20190630', 'YYYYMMDD')
            GROUP BY to_date(substring(a.f_name, 21, 8), 'YYYYMMDD'),
                     a.mrf,
                     db.parent_branch_key,
                     a.rf,
                     hdb.branch_key,
                     a.customer,
                     a.inn,
                     a.account_num,
                     a.order_num,
                     to_date(a.date_open, 'DD.MM.YYYY'),
                     a.moved_to_comm,
                     a.parametr,
                     a.value_sum::numeric
         ) o7n
   GROUP BY o7n.period, o7n.mrf_bk, o7n.rf_bk, o7n.customer, o7n.inn, o7n.account_num, o7n.order_num,
            o7n.dt, o7n.moved_to_comm
)
-- продажи услуги VIDEO
SELECT
       t.period,
       (SELECT business_service_key FROM w_service) AS business_service_key,
       coalesce(t.rf_bk, t.mrf_bk, -1) AS branch_key,
       coalesce(sg.segment_id, -1) AS segment_key,
       t.client_name,
       t.inn,
       t.account,
       t.order_num,
       t.order_dt,
       '-1' AS sales_channel,
       t.seller_name,
       0 AS shpd_migration_flg,
       t.serv_qnty,
       t.account || '#' || t.order_num AS sale_serv_id,
       158 AS src_id,
       coalesce(sg.macro_segment_key, -1) AS macro_segment_key
  FROM (
         -- выбираем из всей базы новые ордера на последний день периода
         SELECT
                date_trunc('month', period) AS period,
                rf_bk,
                mrf_bk,
                customer AS client_name,
                inn,
                account_num AS account,
                order_num,
                dt AS order_dt,
                coalesce(moved_to_comm, '-1') AS seller_name,
                value_sum AS serv_qnty
           FROM (
                  SELECT period,
                         mrf_bk,
                         rf_bk,
                         customer,
                         inn,
                         account_num,
                         order_num,
                         dt,
                         moved_to_comm,
                         value_sum,
                         row_number() over(PARTITION BY order_num ORDER BY period DESC) AS rn
                    FROM w_video
                   WHERE dt BETWEEN to_date('20190601', 'YYYYMMDD') AND to_date('20190630', 'YYYYMMDD')
                ) v
          WHERE rn = 1
          UNION ALL
         -- Вычисляем новые камеры по ордерам, подключенным ранее
         SELECT
                date_trunc('month', t1.period) AS period,
                t1.rf_bk,
                t1.mrf_bk,
                t1.customer AS client_name,
                t1.inn,
                t1.account_num AS account,
                t1.order_num,
                t1.period AS order_dt,
                coalesce(t1.moved_to_comm, '-1') AS seller_name,
                t1.value_sum - dy.value_sum AS serv_qnty
           FROM w_video t1
                JOIN
                w_video dy
                  ON dy.period = t1.period - interval ' 1 day'
                 AND coalesce(dy.rf_bk, dy.mrf_bk, -1) = coalesce(t1.rf_bk, t1.mrf_bk, -1)
                 AND dy.order_num = t1.order_num
                 AND dy.account_num = t1.account_num
                 AND t1.value_sum - dy.value_sum > 0
                 AND dy.dt < to_date('20190601', 'YYYYMMDD')
          WHERE t1.dt < to_date('20190601', 'YYYYMMDD')
       ) t
       LEFT JOIN
       w_coo_cl cl
         ON cl.mrf_id = t.mrf_bk
        AND cl.account = t.account
        AND cl.day = t.order_dt
       LEFT JOIN
       (
         SELECT
                edcs.segment_key AS segment_id,
                edcs.segment_name,
                coalesce(edcs3.segment_key, edcs2.segment_key, edcs1.segment_key, edcs.segment_key) AS macro_segment_key
           FROM edw_dds.dim_segment edcs
                LEFT JOIN
                edw_dds.dim_segment edcs1
                  ON edcs1.segment_key = edcs.parent_segment_key
                 AND edcs1.exp_dttm = to_date('2999-12-31', 'yyyy-mm-dd')
                 AND edcs1.deleted_ind = 0
                 AND edcs1.parent_segment_key <> -1
                LEFT JOIN
                edw_dds.dim_segment edcs2
                  ON edcs2.segment_key = edcs1.parent_segment_key
                 AND edcs2.exp_dttm = to_date('2999-12-31', 'yyyy-mm-dd')
                 AND edcs2.deleted_ind = 0
                 AND edcs2.parent_segment_key <> -1
                LEFT JOIN
                edw_dds.dim_segment edcs3
                  ON edcs3.segment_key = edcs2.parent_segment_key
                 AND edcs3.exp_dttm = to_date('2999-12-31', 'yyyy-mm-dd')
                 AND edcs3.deleted_ind = 0
                 AND edcs3.parent_segment_key <> -1
          WHERE edcs.exp_dttm = to_date('2999-12-31', 'yyyy-mm-dd')
            AND edcs.deleted_ind = 0
       ) sg
      ON upper(sg.segment_name) = upper(cl.k_code);
COMMIT;

BEGIN;
-- ВЦОД src_id = 158 Находим новые заказы в дне расчета
INSERT INTO edw_stg_dm_b2b.tfct_serv_sales_1_prt_p000158
(
  period,
  business_service_key,
  branch_key,
  segment_key,
  client_name,
  inn,
  account,
  order_num,
  order_dt,
  sales_channel,
  seller_name,
  shpd_migration_flg,
  serv_qnty,
  sale_serv_id,
  src_id,
  macro_segment_key
)
-- Определяем id бизнес услуги
WITH
w_service AS
(
  SELECT
         max(business_service_key) AS business_service_key
    FROM edw_dds.dim_business_service
   WHERE exp_dttm = '2999-12-31 00:00:00'
     AND upper(business_service_name) LIKE 'ВИРТ%ЦОД%'
     AND active_ind = 'Y'
     AND deleted_ind = 0
),
-- Определяем К код по ЛС на данных СОО
w_coo_cl AS
(
  SELECT
         cln.day, cln.mrf_id, cln.account, cln.id_macro_segment_ud, mc.macro_segment AS k_code
    FROM (
           SELECT
                  dd.day, cl.mrf_id, cl.account, cl.id_macro_segment_ud,
                  row_number() OVER (PARTITION BY dd.day, mrf_id, cl.account ORDER BY cl.date_snap DESC) AS rn
             FROM edw_ods.t_000151_rprt_client_dwh cl
                  JOIN
                  (SELECT generate_series(to_date('20190601', 'YYYYMMDD'), to_date('20190630', 'YYYYMMDD'), '1 day'::interval) AS day) dd
                    ON coalesce(cl.data_contr, to_date('19000101','YYYYMMDD')) <= dd.day
            WHERE coalesce(cl.data_close, to_date('29991231', 'YYYYMMDD')) >= to_date('20180101', 'YYYYMMDD')
              --AND coalesce(cl.data_contr, to_date('20190630', 'YYYYMMDD')) <= to_date('20190630', 'YYYYMMDD')
              AND id_macro_segment_ud IS NOT NULL
              AND cl.jr_type NOT IN (3, 6, 8)
              AND cl.deleted_ind = 0
            UNION ALL
           SELECT
                  dd.day, cl.mrf_id, cl.account, cl.id_macro_segment_ud,
                  row_number() OVER (PARTITION BY dd.day, mrf_id, cl.account ORDER BY cl.date_snap DESC) AS rn
             FROM edw_ods.t_000152_rprt_client_dwh cl
                  JOIN
                  (SELECT generate_series(to_date('20190601', 'YYYYMMDD'), to_date('20190630', 'YYYYMMDD'), '1 day'::interval) AS day) dd
                    ON coalesce(cl.data_contr, to_date('19000101','YYYYMMDD')) <= dd.day
            WHERE coalesce(cl.data_close, to_date('29991231', 'YYYYMMDD')) >= to_date('20180101', 'YYYYMMDD')
              --AND coalesce(cl.data_contr, to_date('20190630', 'YYYYMMDD')) <= to_date('20190630', 'YYYYMMDD')
              AND id_macro_segment_ud IS NOT NULL
              AND cl.jr_type NOT IN (3, 6, 8)
              AND cl.deleted_ind = 0
            UNION ALL
           SELECT
                  dd.day, cl.mrf_id, cl.account, cl.id_macro_segment_ud,
                  row_number() OVER (PARTITION BY dd.day, mrf_id, cl.account ORDER BY cl.date_snap DESC) AS rn
             FROM edw_ods.t_000153_rprt_client_dwh cl
                  JOIN
                  (SELECT generate_series(to_date('20190601', 'YYYYMMDD'), to_date('20190630', 'YYYYMMDD'), '1 day'::interval) AS day) dd
                    ON coalesce(cl.data_contr, to_date('19000101','YYYYMMDD')) <= dd.day
            WHERE coalesce(cl.data_close, to_date('29991231', 'YYYYMMDD')) >= to_date('20180101', 'YYYYMMDD')
              --AND coalesce(cl.data_contr, to_date('20190630', 'YYYYMMDD')) <= to_date('20190630', 'YYYYMMDD')
              AND id_macro_segment_ud IS NOT NULL
              AND cl.jr_type NOT IN (3, 6, 8)
              AND cl.deleted_ind = 0
            UNION ALL
           SELECT
                  dd.day, cl.mrf_id, cl.account, cl.id_macro_segment_ud,
                  row_number() OVER (PARTITION BY dd.day, mrf_id, cl.account ORDER BY cl.date_snap DESC) AS rn
             FROM edw_ods.t_000155_rprt_client_dwh cl
                  JOIN
                  (SELECT generate_series(to_date('20190601', 'YYYYMMDD'), to_date('20190630', 'YYYYMMDD'), '1 day'::interval) AS day) dd
                    ON coalesce(cl.data_contr, to_date('19000101','YYYYMMDD')) <= dd.day
            WHERE coalesce(cl.data_close, to_date('29991231', 'YYYYMMDD')) >= to_date('20180101', 'YYYYMMDD')
              --AND coalesce(cl.data_contr, to_date('20190630', 'YYYYMMDD')) <= to_date('20190630', 'YYYYMMDD')
              AND id_macro_segment_ud IS NOT NULL
              AND cl.jr_type NOT IN (3, 6, 8)
              AND cl.deleted_ind = 0
            UNION ALL
           SELECT
                  dd.day, cl.mrf_id, cl.account, cl.id_macro_segment_ud,
                  row_number() OVER (PARTITION BY dd.day, mrf_id, cl.account ORDER BY cl.date_snap DESC) AS rn
             FROM edw_ods.t_000156_rprt_client_dwh cl
                  JOIN
                  (SELECT generate_series(to_date('20190601', 'YYYYMMDD'), to_date('20190630', 'YYYYMMDD'), '1 day'::interval) AS day) dd
                    ON coalesce(cl.data_contr, to_date('19000101','YYYYMMDD')) <= dd.day
            WHERE coalesce(cl.data_close, to_date('29991231', 'YYYYMMDD')) >= to_date('20180101', 'YYYYMMDD')
              --AND coalesce(cl.data_contr, to_date('20190630', 'YYYYMMDD')) <= to_date('20190630', 'YYYYMMDD')
              AND id_macro_segment_ud IS NOT NULL
              AND cl.jr_type NOT IN (3, 6, 8)
              AND cl.deleted_ind = 0
            UNION ALL
           SELECT
                  dd.day, cl.mrf_id, cl.account, cl.id_macro_segment_ud,
                  row_number() OVER (PARTITION BY dd.day, mrf_id, cl.account ORDER BY cl.date_snap DESC) AS rn
             FROM edw_ods.t_000157_rprt_client_dwh cl
                  JOIN
                  (SELECT generate_series(to_date('20190601', 'YYYYMMDD'), to_date('20190630', 'YYYYMMDD'), '1 day'::interval) AS day) dd
                    ON coalesce(cl.data_contr, to_date('19000101','YYYYMMDD')) <= dd.day
            WHERE coalesce(cl.data_close, to_date('29991231', 'YYYYMMDD')) >= to_date('20180101', 'YYYYMMDD')
              --AND coalesce(cl.data_contr, to_date('20190630', 'YYYYMMDD')) <= to_date('20190630', 'YYYYMMDD')
              AND id_macro_segment_ud IS NOT NULL
              AND cl.jr_type NOT IN (3, 6, 8)
              AND cl.deleted_ind = 0
            UNION ALL
           SELECT
                  dd.day, cl.mrf_id, coalesce(a.nls, cl.nls_account, cl.account) AS account, cl.id_macro_segment_ud,
                  row_number() OVER (PARTITION BY dd.day, cl.mrf_id, coalesce(a.nls, cl.nls_account, cl.account) ORDER BY cl.date_snap DESC) AS rn
             FROM edw_ods.t_000154_rprt_client_dwh cl
                  JOIN
                  (SELECT generate_series(to_date('20190601', 'YYYYMMDD'), to_date('20190630', 'YYYYMMDD'), '1 day'::interval) AS day) dd
                    ON coalesce(cl.data_contr, to_date('19000101','YYYYMMDD')) <= dd.day
                  LEFT JOIN
                  edw_ods.t_000158_efftp_south_nls_accnt a
                    ON a.date_end IS NULL
                   AND a.account = cl.account
            WHERE coalesce(cl.data_close, to_date('29991231', 'YYYYMMDD')) >= to_date('20180101', 'YYYYMMDD')
              --AND coalesce(cl.data_contr, to_date('20190630', 'YYYYMMDD')) <= to_date('20190630', 'YYYYMMDD')
              AND id_macro_segment_ud IS NOT NULL
              AND cl.jr_type NOT IN (3, 6, 8)
              AND cl.deleted_ind = 0
         ) cln
         LEFT JOIN
         edw_ods.t_000158_rprt_dird_macro_sgmnt mc
           ON mc.id_macro_segment = cln.id_macro_segment_ud
          AND mc.deleted_ind = 0
          AND mc.date_end >= cln.day
   WHERE cln.rn = 1
),
-- Новое подключение заказа ВЦОД
w_orders_new AS
(
  -- Сортируем отдера по дате абонбазы
  SELECT period,
         mrf_bk,
         rf_bk,
         customer,
         inn,
         account_num,
         order_num,
         dt,
         moved_to_comm,
         count_serv,
         row_number() OVER (PARTITION BY order_num ORDER BY period DESC) AS rn
    FROM (
           -- Суммируем кол-во оборудов на ордере
           SELECT period,
                  mrf,
                  mrf_bk,
                  rf,
                  rf_bk,
                  customer,
                  inn,
                  account_num,
                  order_num,
                  dt,
                  moved_to_comm,
                  sum(count_serv) AS count_serv
             FROM (
                    SELECT
                           to_date(substring(a.f_name, 21, 8), 'YYYYMMDD') AS period,
                           a.mrf,
                           coalesce(db.parent_branch_key, -1) AS mrf_bk,
                           a.rf,
                           coalesce(hdb.branch_key, -1) AS rf_bk,
                           a.customer,
                           a.inn,
                           a.account_num,
                           a.order_num,
                           to_date(a.date_open, 'DD.MM.YYYY') AS dt,
                           a.moved_to_comm,
                           a.parametr,
                           value_sum::numeric AS count_serv
                      FROM edw_ods.t_000158_report_o7_2data a
                           LEFT JOIN
                           edw_dds.hub_dim_branch hdb
                             ON hdb.src_id = 158
                            AND hdb.exp_dttm = '2999-12-31 00:00:00'
                            AND upper(hdb.source_key) = upper(a.rf)
                           LEFT JOIN
                           edw_dds.dim_branch db
                             ON db.exp_dttm = '2999-12-31 00:00:00'
                            AND db.branch_key = hdb.branch_key
                            AND db.deleted_ind = 0
                     WHERE -- a.load_date >= to_date('20190630', 'YYYYMMDD')
                           a.tech_dt >= to_date('20190601', 'YYYYMMDD')
                       AND a.report_name = 'xvdc'
                       AND a.department LIKE 'E501212%продажи%ВЦОД)'
                       AND upper(mode_type) = 'КОММЕРЧЕСКИЙ'
                       AND to_date(substring(a.f_name, 21, 8), 'YYYYMMDD') BETWEEN to_date('20190601', 'YYYYMMDD') AND to_date('20190630', 'YYYYMMDD')
                       AND to_date(a.date_open, 'DD.MM.YYYY') BETWEEN to_date('20190601', 'YYYYMMDD') AND to_date('20190630', 'YYYYMMDD')
                       AND substring(a.f_name, 21, 4) >= '2019'
                     GROUP BY to_date(substring(a.f_name, 21, 8), 'YYYYMMDD'),
                              a.mrf,
                              db.parent_branch_key,
                              a.rf,
                              hdb.branch_key,
                              a.customer,
                              a.inn,
                              a.account_num,
                              a.order_num,
                              to_date(a.date_open, 'DD.MM.YYYY'),
                              a.moved_to_comm,
                              a.parametr,
                              a.value_sum::numeric
                  ) r
            GROUP BY period, mrf, mrf_bk, rf, rf_bk, customer, inn, account_num, order_num, dt, moved_to_comm
         ) rep
)
-- продажи услуги ВЦОД
SELECT
       t.period,
       (SELECT business_service_key FROM w_service) AS business_service_key,
       coalesce(t.rf_bk, t.mrf_bk, -1) AS branch_key,
       coalesce(sg.segment_id, -1) AS segment_key,
       t.client_name,
       t.inn,
       t.account,
       t.order_num,
       t.order_dt,
       '-1' AS sales_channel,
       t.seller_name,
       0 AS shpd_migration_flg,
       t.serv_qnty,
       t.order_num || '#' || (SELECT business_service_key FROM w_service) AS sale_serv_id,
       158 AS src_id,
       coalesce(sg.macro_segment_key, -1) AS macro_segment_key
  FROM (
         SELECT
                date_trunc('month', period) AS period,
                rf_bk,
                mrf_bk,
                customer AS client_name,
                inn,
                account_num AS account,
                order_num,
                dt AS order_dt,
                coalesce(moved_to_comm, '-1') AS seller_name,
                count_serv AS serv_qnty
           FROM w_orders_new
          WHERE rn = 1
       ) t
       LEFT JOIN
       w_coo_cl cl
         ON cl.mrf_id = t.mrf_bk
        AND cl.account = t.account
        AND cl.day = t.order_dt
       LEFT JOIN
       (
         SELECT
                edcs.segment_key AS segment_id,
                edcs.segment_name,
                coalesce(edcs3.segment_key, edcs2.segment_key, edcs1.segment_key, edcs.segment_key) AS macro_segment_key
           FROM edw_dds.dim_segment edcs
                LEFT JOIN
                edw_dds.dim_segment edcs1
                  ON edcs1.segment_key = edcs.parent_segment_key
                 AND edcs1.exp_dttm = to_date('2999-12-31', 'yyyy-mm-dd')
                 AND edcs1.deleted_ind = 0
                 AND edcs1.parent_segment_key <> -1
                LEFT JOIN
                edw_dds.dim_segment edcs2
                  ON edcs2.segment_key = edcs1.parent_segment_key
                 AND edcs2.exp_dttm = to_date('2999-12-31', 'yyyy-mm-dd')
                 AND edcs2.deleted_ind = 0
                 AND edcs2.parent_segment_key <> -1
                LEFT JOIN
                edw_dds.dim_segment edcs3
                  ON edcs3.segment_key = edcs2.parent_segment_key
                 AND edcs3.exp_dttm = to_date('2999-12-31', 'yyyy-mm-dd')
                 AND edcs3.deleted_ind = 0
                 AND edcs3.parent_segment_key <> -1
          WHERE edcs.exp_dttm = to_date('2999-12-31', 'yyyy-mm-dd')
            AND edcs.deleted_ind = 0
       ) sg
      ON upper(sg.segment_name) = upper(cl.k_code);
COMMIT;

BEGIN;
  ANALYZE edw_stg_dm_b2b.tfct_serv_sales_1_prt_p000158;
COMMIT;
