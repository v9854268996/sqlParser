--rev. 50507 от 26.01.2020

truncate table edw_stg_ads.tfct_add_service_charges_month_1_prt_p000087;
commit;

/*
  Отбираем начисления за текущий месяц, которые связаны с доп. услугами
*/
insert into edw_stg_ads.tfct_add_service_charges_month_1_prt_p000087
(
      calendar_key
    , year_month_key
    , is_service_active
    , is_service_active_period
    , is_conn_curr_period
    , add_service_key
    , add_service_parent_key
    , add_serv_sc_key
    , dop_service_key
    , branch_key
    , sales_channel_key
    , account_name
    , start_date
    , end_date
    , parent_start_date
    , pay_days_qty
    , notpay_days_qty
    , tot_days_qty
    , charge_sum
    , vat_sum
    , charge_period_start_dttm
    , src_id
)
select
      (to_date('20190601', 'YYYYMMDD') + interval '1 month - 1 day')::date as calendar_key
    , substr('20190601', 1, 6) as year_month_key
    , (to_date('20190601', 'YYYYMMDD') + interval '1 month - 1 day') <= das.end_date::date as is_service_active
    , (das.end_date::date - to_date('20190601', 'YYYYMMDD')) * ((to_date('20190601', 'YYYYMMDD') + interval '1 month - 1 day')::date - das.start_date::date)::bigint >= 0 as is_service_active_period
    , (das.parent_start_date::date >= to_date('20190601', 'YYYYMMDD') and das.parent_start_date::date < to_date('20190601', 'YYYYMMDD') + interval '1 month') as is_conn_curr_period
    , das.add_service_key
    , das.add_service_parent_key
    , das.add_serv_sc_key::bigint
    , das.dop_service_key
    , das.branch_key
    , das.sales_channel_key
    , das.account_name
    , das.start_date::date
    , das.end_date::date
    , das.parent_start_date::date
    , coalesce(crg.cnt_pay_days::int, 0) as pay_days_qty
    , coalesce(crg.cnt_notpay_days::int, 0) as notpay_days_qty
    , coalesce(crg.cnt_pay_days::int + crg.cnt_notpay_days::int, 0) as tot_days_qty
    , coalesce(crg.charge_rub, 0) as charge_sum
    , coalesce(crg.vat_rub, 0) as vat_sum
    , charge_period_start_dttm
    , das.src_id
from edw_dds.tfct_add_service_charges crg
join (
        select
              coalesce(reestr.add_service_key, -1) as add_service_key
            , coalesce(reestr.add_service_parent_key, reestr.add_service_key) as add_service_parent_key
            , coalesce(reestr.add_serv_sc_key, '-1') as add_serv_sc_key
            , reestr.service_key as service_key
            , reestr.branch_key as branch_key
            , coalesce(city_key, '-1') as city_key
            , reestr.account_name as account_name
            , coalesce(subs_name, '-1') as subs_name
            , reestr.mrf_service_key as mrf_service_key
            , reestr.mrf_add_service_name as mrf_add_service_name
            , reestr.start_date as start_date
            , reestr.end_date as end_date
            , coalesce(reestr.parent_start_date, reestr.start_date) as parent_start_date
            , reestr.dop_service_key as dop_service_key
            , reestr.sales_channel_key::bigint as sales_channel_key
            , coalesce(reestr.init_system, '-1') as init_system
            , coalesce(reestr.oper_id, '-1') as oper_id
            , coalesce(reestr.oper_name, '-1') as oper_name
            , reestr.src_id as src_id
        from (
                select
                    das.add_service_key
                    , das_p.add_service_key as add_service_parent_key
                    , das.service_key
                    , das.branch_key
                    , das.account_name
                    , das.subs_name
                    , das.city_key
                    , das.mrf_service_key
                    , das.mrf_add_service_name
                    , das.start_date
                    , das.end_date
                    , das_p.start_date as parent_start_date
                    , das.dop_service_key
                    , decode(das.add_serv_sc_key, '-1', das_p.add_serv_sc_key, das.add_serv_sc_key) as add_serv_sc_key
                    , decode(coalesce(dassc.sales_channel_key,'-1'),'-1', dassc_p.sales_channel_key, coalesce(dassc.sales_channel_key,'-1')) as sales_channel_key
                    , coalesce(dassc.init_system, dassc_p.init_system) as init_system
                    , coalesce(dassc.oper_id, dassc_p.oper_id) as oper_id
                    , coalesce(dassc.oper_name, dassc_p.oper_name) as oper_name
                    , das.src_id
                from edw_dds.dim_add_service das
                left join edw_dds.dim_add_serv_sales_channel dassc on das.add_serv_sc_key::bigint = dassc.add_serv_sc_key 
                    and dassc.src_id = 000087::numeric
                    and dassc.active_ind = 'Y'
                    and dassc.deleted_ind=0
                left join edw_dds.dim_add_service das_p on das.add_service_parent_key = das_p.add_service_key 
                    and das_p.src_id = 000087::numeric
                    and das_p.active_ind = 'Y'
                    and das_p.deleted_ind=0
                left join edw_dds.dim_add_serv_sales_channel dassc_p on das_p.add_serv_sc_key::bigint = dassc_p.add_serv_sc_key 
                    and dassc_p.src_id = 000087::numeric
                    and dassc_p.active_ind = 'Y'
                    and dassc_p.deleted_ind=0
                where das.src_id = 000087::numeric --выбор SRC
                    and das.active_ind = 'Y'
                    and das.deleted_ind=0
                    --and das.dop_service_key in (360,350,251,93,46)
        ) reestr
) das on das.add_service_key = crg.add_service_key
where crg.src_id = 000087::numeric
    and crg.charge_period_start_dttm = to_date('20190601', 'YYYYMMDD')
;
commit;

/*
  Отбираем данные по доп. услугам в текущем месяце, которые связаны с начислениями
*/
insert into edw_stg_ads.tfct_add_service_charges_month_1_prt_p000087
(
      calendar_key
    , year_month_key
    , is_service_active
    , is_service_active_period
    , is_conn_curr_period
    , add_service_key
    , add_service_parent_key
    , add_serv_sc_key
    , dop_service_key
    , branch_key
    , sales_channel_key
    , account_name
    , start_date
    , end_date
    , parent_start_date
    , pay_days_qty
    , notpay_days_qty
    , tot_days_qty
    , charge_sum
    , vat_sum
    , charge_period_start_dttm
    , src_id
)
select
      (to_date('20190601', 'YYYYMMDD') + interval '1 month - 1 day')::date as calendar_key
    , substr('20190601', 1, 6) as year_month_key
    , (to_date('20190601', 'YYYYMMDD') + interval '1 month - 1 day') <= das.end_date::date as is_service_active
    , (das.end_date::date - to_date('20190601', 'YYYYMMDD')) * ((to_date('20190601', 'YYYYMMDD') + interval '1 month - 1 day')::date - das.start_date::date)::bigint >= 0 as is_service_active_period
    , (das.parent_start_date::date >= to_date('20190601', 'YYYYMMDD') and das.parent_start_date::date < to_date('20190601', 'YYYYMMDD') + interval '1 month') as is_conn_curr_period
    , das.add_service_key
    , das.add_service_parent_key
    , das.add_serv_sc_key::bigint
    , das.dop_service_key
    , das.branch_key
    , das.sales_channel_key
    , das.account_name
    , das.start_date::date
    , das.end_date::date
    , das.parent_start_date::date
    , 0 as pay_days_qty
    , 0 as notpay_days_qty
    , 0 as tot_days_qty
    , 0 as charge_sum
    , 0 as vat_sum
    , to_date('20190601', 'YYYYMMDD') as charge_period_start_dttm
    , das.src_id
from (
        select
              coalesce(reestr.add_service_key, -1) as add_service_key
            , coalesce(reestr.add_service_parent_key, reestr.add_service_key) as add_service_parent_key
            , coalesce(reestr.add_serv_sc_key, '-1') as add_serv_sc_key
            , reestr.service_key as service_key
            , reestr.branch_key as branch_key
            , coalesce(city_key, '-1') as city_key
            , reestr.account_name as account_name
            , coalesce(subs_name, '-1') as subs_name
            , reestr.mrf_service_key as mrf_service_key
            , reestr.mrf_add_service_name as mrf_add_service_name
            , reestr.start_date as start_date
            , reestr.end_date as end_date
            , coalesce(reestr.parent_start_date, reestr.start_date) as parent_start_date
            , reestr.dop_service_key as dop_service_key
            , reestr.sales_channel_key::bigint as sales_channel_key
            , coalesce(reestr.init_system, '-1') as init_system
            , coalesce(reestr.oper_id, '-1') as oper_id
            , coalesce(reestr.oper_name, '-1') as oper_name
            , reestr.src_id as src_id
        from (
                select
                    das.add_service_key
                    , das_p.add_service_key as add_service_parent_key
                    , das.service_key
                    , das.branch_key
                    , das.account_name
                    , das.subs_name
                    , das.city_key
                    , das.mrf_service_key
                    , das.mrf_add_service_name
                    , das.start_date
                    , das.end_date
                    , das_p.start_date as parent_start_date
                    , das.dop_service_key
                    , decode(das.add_serv_sc_key, '-1', das_p.add_serv_sc_key, das.add_serv_sc_key) as add_serv_sc_key
                    , decode(coalesce(dassc.sales_channel_key,'-1'),'-1', dassc_p.sales_channel_key, coalesce(dassc.sales_channel_key,'-1')) as sales_channel_key
                    , coalesce(dassc.init_system, dassc_p.init_system) as init_system
                    , coalesce(dassc.oper_id, dassc_p.oper_id) as oper_id
                    , coalesce(dassc.oper_name, dassc_p.oper_name) as oper_name
                    , das.src_id
                from (
                        select das.*
                        from edw_dds.dim_add_service das
                        left join edw_dds.tfct_add_service_charges crg on crg.src_id = 000087::numeric
                            and crg.charge_period_start_dttm = to_date('20190601', 'YYYYMMDD')
                            and das.add_service_key = crg.add_service_key
                        where crg.add_service_key is null
                            and das.src_id = 000087::numeric
                            and to_date('20190601', 'YYYYMMDD') between date_trunc('month', das.start_date::timestamp) and date_trunc('month', das.end_date::timestamp)
                    ) das
                left join edw_dds.dim_add_serv_sales_channel dassc on das.add_serv_sc_key::bigint = dassc.add_serv_sc_key 
                    and dassc.src_id = 000087::numeric
                    and dassc.active_ind = 'Y'
                    and dassc.deleted_ind=0
                left join edw_dds.dim_add_service das_p on das.add_service_parent_key = das_p.add_service_key 
                    and das_p.src_id = 000087::numeric
                    and das_p.active_ind = 'Y'
                    and das_p.deleted_ind=0
                left join edw_dds.dim_add_serv_sales_channel dassc_p on das_p.add_serv_sc_key::bigint = dassc_p.add_serv_sc_key 
                    and dassc_p.src_id = 000087::numeric
                    and dassc_p.active_ind = 'Y'
                    and dassc_p.deleted_ind=0
                where das.src_id = 000087::numeric --выбор SRC
                    and das.active_ind = 'Y'
                    and das.deleted_ind=0
                    --and das.dop_service_key in (360,350,251,93,46)
        ) reestr
        where to_date('20190601', 'YYYYMMDD') between date_trunc('month', reestr.start_date::timestamp) and date_trunc('month', reestr.end_date::timestamp)
) das
;
commit;

/*
  Отбираем данные по новым каналам продаж в текущем месяце, которые не были привязаны к доп.услугам
*/
insert into edw_stg_ads.tfct_add_service_charges_month_1_prt_p000087
(
      calendar_key
    , year_month_key
    , is_service_active
    , is_service_active_period
    , is_conn_curr_period
    , add_service_key
    , add_service_parent_key
    , add_serv_sc_key
    , dop_service_key
    , branch_key
    , sales_channel_key
    , account_name
    , start_date
    , end_date
    , parent_start_date
    , pay_days_qty
    , notpay_days_qty
    , tot_days_qty
    , charge_sum
    , vat_sum
    , charge_period_start_dttm
    , src_id
)
with dass2 as 
(
    select distinct add_serv_sc_key::bigint as add_serv_sc_key
    from edw_dds.dim_add_service das
    where das.src_id = 000087::numeric
        and das.active_ind = 'Y'
        and das.deleted_ind=0
)
select
      (to_date('20190601', 'YYYYMMDD') + interval '1 month - 1 day')::date as calendar_key
    , substr('20190601', 1, 6) as year_month_key
    , (to_date('20190601', 'YYYYMMDD') + interval '1 month - 1 day') <= das.end_date::date as is_service_active
    , (das.end_date::date - to_date('20190601', 'YYYYMMDD')) * ((to_date('20190601', 'YYYYMMDD') + interval '1 month - 1 day')::date - das.start_date::date)::bigint >= 0 as is_service_active_period
    , (das.parent_start_date::date >= to_date('20190601', 'YYYYMMDD') and das.parent_start_date::date < to_date('20190601', 'YYYYMMDD') + interval '1 month') as is_conn_curr_period
    , das.add_service_key
    , das.add_service_parent_key
    , das.add_serv_sc_key::bigint
    , das.dop_service_key
    , das.branch_key
    , das.sales_channel_key
    , das.account_name
    , das.start_date::date
    , das.end_date::date
    , das.parent_start_date::date
    , 0 as pay_days_qty
    , 0 as notpay_days_qty
    , 0 as tot_days_qty
    , 0 as charge_sum
    , 0 as vat_sum
    , to_date('20190601', 'YYYYMMDD') as charge_period_start_dttm
    , das.src_id
from (
        select
              dassc.add_service_key as add_service_key
            , dassc.add_serv_sc_key as add_service_parent_key
            , dassc.add_serv_sc_key as add_serv_sc_key
            , dassc.service_key as service_key
            , dassc.branch_key as branch_key
            , '-1' as city_key
            , dassc.account_name as account_name
            , '-1' as subs_name
            , dassc.mrf_service_key as mrf_service_key
            , dassc.mrf_add_service_name as mrf_add_service_name
            , dassc.start_date as start_date
            , dassc.end_date as end_date
            , dassc.start_date as parent_start_date
            , dassc.dop_service_key as dop_service_key
            , dassc.sales_channel_key as sales_channel_key
            , coalesce(dassc.init_system, '-1') as init_system
            , coalesce(dassc.oper_id, '-1') as oper_id
            , coalesce(dassc.oper_name, '-1') as oper_name
            , dassc.src_id as src_id
        from (
                select
                    '-1' as add_service_key
                    , service_key
                    , branch_key
                    , account_name
                    , mrf_service_key
                    , mrf_add_service_name
                    , start_date
                    , to_date('29991231', 'YYYYMMDD') as end_date
                    , dop_service_key
                    , add_serv_sc_key
                    , sales_channel_key
                    , init_system
                    , oper_id
                    , oper_name
                    , src_id
                from edw_dds.dim_add_serv_sales_channel
                where src_id = 000087::numeric  -- выбор SRC 
                    and active_ind = 'Y'
                    and deleted_ind=0
                    and start_date::date between date_trunc('month',to_date('20190601', 'YYYYMMDD')::timestamp) and to_date('20190601', 'YYYYMMDD') + interval '1 month - 1 second'
        ) dassc
        left join dass2 on dass2.add_serv_sc_key = dassc.add_serv_sc_key
        where dass2.add_serv_sc_key is null
) das
;
commit;

analyze edw_stg_ads.tfct_add_service_charges_month_1_prt_p000087;

