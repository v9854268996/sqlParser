/*rev.31470 от 21.06.2019*/
TRUNCATE TABLE edw_stg_dds.t_000127_dim_crm_case_resolution;

INSERT INTO edw_stg_dds.t_000127_dim_crm_case_resolution (case_resolution_key, objid, case_resolution_name, state_name, rank_nval, src_id)
SELECT
  elm.OBJID as CASE_RESOLUTION_KEY,
  elm.OBJID as OBJID,
  elm.TITLE as CASE_RESOLUTION_NAME,
  elm.STATE as STATE_NAME,
  elm.RANK as RANK_NVAL,
  127 as src_id
FROM
  edw_ods.T_000127_SA_TABLE_GBST_ELM elm
  INNER JOIN edw_ods.t_000127_SA_TABLE_GBST_LST lst ON lst.OBJID = elm.GBST_ELM2GBST_LST  AND lst.s_ref_id ='RESOLUTION CODE' AND lst.DELETED_IND = 0
WHERE
  elm.DELETED_IND = 0;

analyse edw_stg_dds.t_000127_dim_crm_case_resolution;
