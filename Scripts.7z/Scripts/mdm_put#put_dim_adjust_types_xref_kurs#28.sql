/*rev.36320 от 23.08.2019*/

delete from  edw_stg_mdm.put_dim_adjust_types_xref_kurs where src_id = 000028;

insert into edw_stg_mdm.put_dim_adjust_types_xref_kurs (ajtp_key,src_id)
/*27-34 36-39*/
select distinct  dfcorrection_reazon::numeric(50),src_id  
  from edw_ods.t_000028_tcorrection_nach_link
;

commit;
analyse edw_stg_mdm.put_dim_adjust_types_xref_kurs;

