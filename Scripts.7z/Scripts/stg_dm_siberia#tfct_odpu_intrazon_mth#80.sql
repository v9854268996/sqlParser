/*rev.49001 от 10.02.2020*/
--1. удаляем данные за анализируемый период по источнику, если они там есть.
 truncate table EDW_STG_DM_SIBERIA.TFCT_ODPU_INTRAZON_MTH_1_prt_P000080;
--2. вставляем данные за период по источнику
insert into EDW_STG_DM_SIBERIA.TFCT_ODPU_INTRAZON_MTH_1_prt_P000080
            (src_id,
       dept_id,
       BILL_PRD_DTTM,
       line_rate,
       num_rate,
       name_rate,
       k_name,
       ODPU_INTRAZON_QTY
      )

select                  --производим агрегацию
       SRC_ID,
       DEPT_ID,
       BILL_PRD_DTTM::timestamp,
       LINE_RATE,
       NUM_RATE,
       NAME_RATE,
       TYPE_UT      K_NAME,
       sum(case when num_rate in (2011,2012,2013,2014) then qt else round(qt/1000,3) end) CNT
from (with dept as (select distinct
                           tgts.dept_id        dept_id         --отбираем структуру филиала для обработки. вершина структуры (dept_id) подается на вход
                    from EDW_ODS.t_000080_t_gts tgts
                    where tgts.SRC_ID = 000080::int
            and date_trunc('month',to_date('20190601','YYYYMMDD'))::timestamp + INTERVAL '1 month - 1 second' between tgts.eff_dttm and tgts.exp_dttm
            )

        ,svc as (select svc.svc_id, --отбираем услуги через виды и слои услуг (только ВНЗ - внутризоновая связь)
                    svc.cod,
                    svc.name      name_svc,           --для отбора ВНЗ устанавливаем slb.id_layer_svc in (53,54) и substr(slc.name,1,1)='2'
                    slb.id_layer_svc,                 --выводим ид и наименование услуги, идентификатор слоя и элемента слоя, код слоя и элемента слоя и наименование
                    slb.id_cell_svc,
                    substr(slc.name,1,3)::int  line_rate,
                    substr(slc.name,1,POSITION(':' in slc.name)-1)::bigint   num_rate,
                    substr(slc.name,POSITION(':' in slc.name)+2)                name_rate
             from EDW_ODS.T_000080_T_SVC_LAYER_CELL slc, EDW_ODS.T_000080_T_SVC_LAYER_BUNCH slb, EDW_ODS.T_000080_T_SVC_REF svc
             where slc.id_cell_svc=slb.id_cell_svc
                   and slc.id_layer_svc=slb.id_layer_svc
                   and slb.svc_id=svc.svc_id
                   and slb.id_layer_svc in (53,54)        --отбор ВНЗ
                   and substr(slc.name,1,1)='2'     --отбор ВНЗ
                   and date_trunc('month',to_date('20190601','YYYYMMDD'))::timestamp + INTERVAL '1 month - 1 second' between slc.eff_dttm and slc.exp_dttm and slc.deleted_ind=0
                   and date_trunc('month',to_date('20190601','YYYYMMDD'))::timestamp + INTERVAL '1 month - 1 second' between slb.eff_dttm and slb.exp_dttm and slb.deleted_ind=0
                   and date_trunc('month',to_date('20190601','YYYYMMDD'))::timestamp + INTERVAL '1 month - 1 second' between svc.eff_dttm and svc.exp_dttm and svc.deleted_ind=0

      )
        ,ut as (select ut.user_type_id,                                      --отбираем типы клиентов из T_USER_TYPE_REF
                       ut.name name_ut,                                       --наименование типа клиента
                       'K'||coalesce(case when substr(ulc.name,2,6) = '029902' and ut.user_type_id in (80000,80100) then '029908'  --клиенты - прочие 3К и Централизованные договора КЦ и ГД
                                          else substr(ulc.name,2,POSITION(' ' in ulc.name)-2) end,               --или возвращаем код из наименования
                                    (case when ut.iscorp='N' then '04'                                     --не юр лица
                                          when (upper(ut.name) like '%ОПЕР%' or upper(ut.name) like 'ГК%') then '0399'   --операторы связь
                                  when ut.isbudg='Y' then '019901'                                 --забюджетированные клиенты
                                    when ut.user_type_id = 20571  then '029901'                      --клиенты ТОП100
                                          when ut.user_type_id in (80000,80100)  then '029908'               --!!!клиенты - Централизованные договора КЦ и ГД
                                          else '029902' end)) type_ut                                      --для остальных ставим код 029902
                from EDW_ODS.T_000080_T_USER_TYPE_REF ut
                left join EDW_ODS.T_000080_T_MON_SETUP mt --таблица самих множественных настроек
                    ON date_trunc('month',to_date('20190601','YYYYMMDD'))::timestamp + INTERVAL '1 month - 1 second' between mt.eff_dttm and mt.exp_dttm and mt.deleted_ind=0
             and mt.mon_value = ut.user_type_id::varchar
             and mt.mon_setup_id=3
                left join EDW_ODS.T_000080_T_UT_LAYER_BUNCH ulb
                    ON ulb.u_type_id=ut.user_type_id
                       and ulb.layer_id=8
             and date_trunc('month',to_date('20190601','YYYYMMDD'))::timestamp + INTERVAL '1 month - 1 second' between ulb.eff_dttm and ulb.exp_dttm and ulb.deleted_ind=0
                left join EDW_ODS.T_000080_T_UT_LAYER_CELL ulc
                    ON ulc.cell_id=ulb.cell_id
                       and ulc.layer_id=ulb.layer_id
             and date_trunc('month',to_date('20190601','YYYYMMDD'))::timestamp + INTERVAL '1 month - 1 second' between ulc.eff_dttm and ulc.exp_dttm and ulc.deleted_ind=0
                where (ut.coef=1 or mt.mon_value is not null or ut.user_type_id in (80000,80100,40600))
             and date_trunc('month',to_date('20190601','YYYYMMDD'))::timestamp + INTERVAL '1 month - 1 second' between ut.eff_dttm and ut.exp_dttm and ut.deleted_ind=0)

     ,summ_ut as (select ut.user_type_id,                         --отбираем типы клиентов из EDW_ODS.T_000080_T_USER_TYPE_REF без обращения к настройкам в EDW_ODS.T_000080_T_MON_SETUP
                           ut.name     name_ut,                      --наименование типа клиента
                           substr(ulc.name,1,POSITION(' ' in ulc.name)-1)    type_ut     --код
                    from EDW_ODS.T_000080_T_UT_LAYER_CELL ulc,
               EDW_ODS.T_000080_T_UT_LAYER_BUNCH ulb,
             EDW_ODS.T_000080_T_USER_TYPE_REF ut               --элементы слоев пользователей, таблица-связка для справочника слоёв типов пользователей, справочник типов клиентов
                    where ulc.cell_id=ulb.cell_id
                      and ulc.layer_id=ulb.layer_id
                      and ulb.layer_id=8
                      and ulb.u_type_id=ut.user_type_id
                      and date_trunc('month',to_date('20190601','YYYYMMDD'))::timestamp + INTERVAL '1 month - 1 second' between ut.eff_dttm and ut.exp_dttm and ut.deleted_ind=0
                      and date_trunc('month',to_date('20190601','YYYYMMDD'))::timestamp + INTERVAL '1 month - 1 second' between ulb.eff_dttm and ulb.exp_dttm and ulb.deleted_ind=0
                      and date_trunc('month',to_date('20190601','YYYYMMDD'))::timestamp + INTERVAL '1 month - 1 second' between ulc.eff_dttm and ulc.exp_dttm and ulc.deleted_ind=0)

    -----------------START LOW SELECT-----------------
        select
                000080 src_id,
                dept.DEPT_ID,
                date_trunc('month',to_date('20190601','YYYYMMDD'))::TIMESTAMP BILL_PRD_DTTM,
                line_rate,
                num_rate,
                name_rate,
                type_ut,
                0 qt
        from (select svc.line_rate, svc.num_rate, svc.name_rate, ut.type_ut, 0 qt from svc, ut    --предварительно заполняем все возможные варианты услуг и филиалов
              group by svc.line_rate, svc.num_rate, svc.name_rate, ut.type_ut
          union all
            select 201 line_rate, 2011 num_rate, 'пользующихся услугами в/з соединений' name_rate, ut.type_ut, 0 qt from ut
            group by ut.type_ut
            union all
            select 201 line_rate, 2012 num_rate, 'пользующихся услугами в/з соединений между абонентами сети фиксированной телефонной связи (ABC на ABC)' name_rate, ut.type_ut, 0 qt from ut
              group by ut.type_ut
              union all
              select 201 line_rate, 2013 num_rate, 'пользующихся услугами в/з соединений в пределах одного поселения между абонентами сети фиксированной телефонной связи (АВС) и сети подвижной радиосвязи (DEF)' name_rate, ut.type_ut, 0 qt from ut
              group by ut.type_ut
              union all
              select 201 line_rate, 2014 num_rate, 'пользующихся услугами в/з соединений за пределами одного поселения между абонентами сети фиксированной телефонной связи (АВС) и сети подвижной радиосвязи (DEF)' name_rate, ut.type_ut, 0 qt from ut
              group by ut.type_ut) tmp_dic, dept
        group by line_rate, num_rate, name_rate, type_ut, dept.DEPT_ID

        union all                --собираем Исходящие внутризон.соединения от таксофонов(ABC-ABC), тыс.мин.

      select 000080 src_id,
               uni_agr.DEPT_ID,
         date_trunc('month',to_date('20190601','YYYYMMDD'))::TIMESTAMP BILL_PRD_DTTM,
               uni_agr.line_rate,
               uni_agr.num_rate,
               uni_agr.name_rate,
               uni_agr.type_ut,
               uni_agr.qt
        from (select
                     svc.line_rate,    --Исх.внутризон.соед-я от таксофонов(ABC-DEF)в пределах поселения, тыс.мин.
                     svc.num_rate,     --соединение АВС-АВС и ABC-DEF
                     svc.name_rate,
                     ut.type_ut,
                     sal.dept_id,
                     sum(os.svc_nmb) qt
              from EDW_ODS.T_000080_T_OTHER_SVC os,
             EDW_ODS.T_000080_T_SALDO sal,
           svc,
           ut,
           EDW_ODS.T_000080_T_USERS u
              where os.tech_dt between date_trunc('month',to_date('20190601','YYYYMMDD'))::timestamp and date_trunc('month',to_date('20190601','YYYYMMDD'))::timestamp + INTERVAL '1 month - 1 second'
          and os.billing_id=substr('20190601',1,6)::int
                and os.svc_id=svc.svc_id
                and svc.id_layer_svc=53     --отбор ВНЗ фикс. связь
                and ((svc.num_rate in (2201,2301,2401) and svc.svc_id in (35531830,280641,35532441,280645,35532431,280644))
                     or svc.num_rate in (2501,2601,2701,2901))   --отбираем Исходящие внутризон.соединения в тыс. минут
                and sal.user_id=os.user_id
                and sal.billing_id=substr('20190601',1,6)::int
                and u.user_id = sal.user_id
                and date_trunc('month',to_date('20190601','YYYYMMDD'))::timestamp + INTERVAL '1 month - 1 second' between u.eff_dttm and u.exp_dttm and u.deleted_ind=0
                and ((u.user_type_id in (20400,3792977,29043226,29031857,29031859,29031863,20555,20585)
                      and ut.user_type_id = coalesce((select max(b.user_type_id) from EDW_ODS.T_000080_T_VIP v, EDW_ODS.T_000080_T_USERS b
                                                      where v.user_id_sp = u.user_id
                                                        and b.user_id = v.user_id_vip
                                                        and date_trunc('month',to_date('20190601','YYYYMMDD'))::timestamp + INTERVAL '1 month - 1 second' between v.eff_dttm and v.exp_dttm and v.deleted_ind=0
                                                        and date_trunc('month',to_date('20190601','YYYYMMDD'))::timestamp + INTERVAL '1 month - 1 second' between b.eff_dttm and b.exp_dttm and b.deleted_ind=0),

                            sal.user_type_id)
                       ) or (u.user_type_id NOT in (20400,3792977,29043226,29031857,29031859,29031863,20555,20585)
                             and ut.user_type_id = sal.user_type_id))  --Выбор головного счета.
              group by svc.line_rate, svc.num_rate, svc.name_rate, ut.type_ut, sal.dept_id


          union all                   --собираем line_rate 220, 230 и 240 отбираем следующие type_ut (K0298, K019901, K010302, K0205, K0410, K010202, K04, K010301, K0399, K019801, K010201, K010401, K029908, K029902, K010402, K010101, K010102, K029901, K0203, K019802, K0310, K0308, K0311)

        select
                    svc.line_rate,       --соединение АВС-АВС и ABC-DEF
                  svc.num_rate,
                  svc.name_rate,
                  ut.type_ut,
                  msa.dept_id,
                  sum(msa.summ_dlit) qt
            from EDW_ODS.T_000080_T_MTS_SVC_AGR msa,
             EDW_ODS.T_000080_T_MTS_ZONE mz,
           EDW_ODS.T_000080_T_MTS_TYPE_CROSS_VND mtcv,
           svc,
           ut
              where msa.tech_dt between date_trunc('month',to_date('20190601','YYYYMMDD'))::timestamp and date_trunc('month',to_date('20190601','YYYYMMDD'))::timestamp + INTERVAL '1 month - 1 second'
          and msa.billing_id=substr('20190601',1,6)::int
                and msa.vndr_id=1            --ID поставщика
                and mtcv.cod in ('1','31')   --ВНЗ
                and svc.id_layer_svc=53      --отбор ВНЗ фикс. связь
                and msa.user_type_id=ut.user_type_id
                and mz.mts_zone_id=msa.mts_zone_id
                and date_trunc('month',to_date('20190601','YYYYMMDD'))::timestamp + INTERVAL '1 month - 1 second' between mz.eff_dttm and mz.exp_dttm and mz.deleted_ind=0
                and date_trunc('month',to_date('20190601','YYYYMMDD'))::timestamp + INTERVAL '1 month - 1 second' between mtcv.eff_dttm and mtcv.exp_dttm and mtcv.deleted_ind=0

                and mtcv.mts_type_vnd_id=mz.mts_type_vnd_id
                and decode(msa.mts_svc_cod,'1',mz.a_svc_id,mz.z_svc_id)=svc.svc_id
              group by svc.line_rate, svc.num_rate, svc.name_rate, ut.type_ut, msa.dept_id

              union all
              select
                   201 line_rate,                 --собираем line_rate 201 отбираем следующие type_ut (K010101, K010102, K010201, K010202, K010301, K010302, K010401, K010402, K019801, K019802, K019901, K0203, K0205, K0298, K029901, K029902, K029908, K0308, K0310, K0311, K0399, K04, K0410)
                   2011 num_rate,
                    'пользующихся услугами в/з соединений' name_rate,
                  ut.type_ut,
                  sal.dept_id,
                  count(distinct ms.phonefrom) qt
              from EDW_ODS.T_000080_T_MTS_RES mr,
             EDW_ODS.T_000080_T_MTS_SIG ms,
           EDW_ODS.T_000080_T_MTS_ZONE mz,
           EDW_ODS.T_000080_T_SALDO sal,
           svc,
           ut,
           EDW_ODS.T_000080_T_USERS U
              where mr.tech_dt between date_trunc('month',to_date('20190601','YYYYMMDD'))::timestamp and date_trunc('month',to_date('20190601','YYYYMMDD'))::timestamp  + INTERVAL '1 month - 1 second'
          and ms.tech_dt between date_trunc('month',to_date('20190601','YYYYMMDD'))::timestamp  and date_trunc('month',to_date('20190601','YYYYMMDD'))::timestamp  + INTERVAL '1 month - 1 second'
        and sal.tech_dt between date_trunc('month',to_date('20190601','YYYYMMDD'))::timestamp  and date_trunc('month',to_date('20190601','YYYYMMDD'))::timestamp  + INTERVAL '1 month - 1 second'
          and mr.billing_id = substr('20190601',1,6)::int
                and mr.vndr_id=1  --ID поставщика
                and ms.vid_cod in ('1','31') --ВНЗ
                and svc.id_layer_svc=53    --отбор ВНЗ фикс. связь
                and mr.mtr_id=ms.mtr_id
                and ms.billing_id=substr('20190601',1,6)::int
                and mr.mts_zone_id=mz.mts_zone_id
                and decode(ms.mts_svc_cod,'1',mz.a_svc_id,mz.z_svc_id)=svc.svc_id
                and sal.user_id=mr.user_id
                and sal.billing_id= substr('20190601',1,6)::int
                and u.user_id = sal.user_id
                and date_trunc('month',to_date('20190601','YYYYMMDD'))::timestamp + INTERVAL '1 month - 1 second' between mz.eff_dttm and mz.exp_dttm and mz.deleted_ind=0
                and date_trunc('month',to_date('20190601','YYYYMMDD'))::timestamp + INTERVAL '1 month - 1 second' between u.eff_dttm and u.exp_dttm and u.deleted_ind=0
                and ((u.user_type_id in (20400,3792977,29043226,29031857,29031859,29031863,20555,20585)
                       and ut.user_type_id = coalesce((select max(b.user_type_id) from EDW_ODS.T_000080_T_VIP v, EDW_ODS.T_000080_T_USERS b
                                                       where v.user_id_sp = u.user_id
                                                         and b.user_id = v.user_id_vip
                                                         and date_trunc('month',to_date('20190601','YYYYMMDD'))::timestamp + INTERVAL '1 month - 1 second' between v.eff_dttm and v.exp_dttm and v.deleted_ind=0
                                           and date_trunc('month',to_date('20190601','YYYYMMDD'))::timestamp + INTERVAL '1 month - 1 second' between b.eff_dttm and b.exp_dttm and b.deleted_ind=0),
                             sal.user_type_id)
                       ) or (u.user_type_id NOT in (20400,3792977,29043226,29031857,29031859,29031863,20555,20585)
                             and ut.user_type_id = sal.user_type_id))  --Выбор головного счета.
              group by ut.type_ut, sal.dept_id

              union all
              select
                     201 line_rate,
                   decode(substr(to_char(svc.line_rate,'FM9999999999'),1,2),'22',2012,'23',2013,'24',2014) num_rate,
                   decode(substr(to_char(svc.line_rate,'FM9999999999'),1,2),'22','пользующихся услугами в/з соединений между абонентами сети фиксированной телефонной связи (ABC на ABC)',
                                                      '23','пользующихся услугами в/з соединений в пределах одного поселения между абонентами сети фиксированной телефонной связи (АВС) и сети подвижной радиосвязи (DEF)',
                                                      '24','пользующихся услугами в/з соединений за пределами одного поселения между абонентами сети фиксированной телефонной связи (АВС) и сети подвижной радиосвязи (DEF)') name_rate,
                     ut.type_ut,
                   sal.dept_id,
                   count(distinct ms.phonefrom) qt
              from EDW_ODS.T_000080_T_MTS_RES mr,
             EDW_ODS.T_000080_T_MTS_SIG ms,
           EDW_ODS.T_000080_T_MTS_ZONE mz,
           EDW_ODS.T_000080_T_SALDO sal,
           svc,
           ut,
           EDW_ODS.T_000080_T_USERS U
              where mr.tech_dt between date_trunc('month',to_date('20190601','YYYYMMDD'))::timestamp and date_trunc('month',to_date('20190601','YYYYMMDD'))::timestamp + INTERVAL '1 month - 1 second'
          and ms.tech_dt between date_trunc('month',to_date('20190601','YYYYMMDD'))::timestamp and date_trunc('month',to_date('20190601','YYYYMMDD'))::timestamp + INTERVAL '1 month - 1 second'
        and sal.tech_dt between date_trunc('month',to_date('20190601','YYYYMMDD'))::timestamp and date_trunc('month',to_date('20190601','YYYYMMDD'))::timestamp + INTERVAL '1 month - 1 second'
          and mr.billing_id = substr('20190601',1,6)::int
                and mr.vndr_id = 1  --ID поставщика
                and ms.vid_cod in ('1','31')  --ВНЗ
                and svc.id_layer_svc=53    --отбор ВНЗ фикс. связь
                and mr.mtr_id=ms.mtr_id
                and ms.billing_id = substr('20190601',1,6)::int
                and mr.mts_zone_id=mz.mts_zone_id
                and decode(ms.mts_svc_cod,'1',mz.a_svc_id,mz.z_svc_id)=svc.svc_id
                and sal.user_id=mr.user_id
                and sal.billing_id = substr('20190601',1,6)::int
                and u.user_id = sal.user_id
                and date_trunc('month',to_date('20190601','YYYYMMDD'))::timestamp + INTERVAL '1 month - 1 second' between mz.eff_dttm and mz.exp_dttm and mz.deleted_ind=0
                and date_trunc('month',to_date('20190601','YYYYMMDD'))::timestamp + INTERVAL '1 month - 1 second' between u.eff_dttm and u.exp_dttm and u.deleted_ind=0
                and ((u.user_type_id in (20400,3792977,29043226,29031857,29031859,29031863,20555,20585)
                      and ut.user_type_id = coalesce((select max(b.user_type_id) from EDW_ODS.T_000080_T_VIP v, EDW_ODS.T_000080_T_USERS b
                                                      where v.user_id_sp = u.user_id
                                                        and b.user_id = v.user_id_vip
                                                        and date_trunc('month',to_date('20190601','YYYYMMDD'))::timestamp + INTERVAL '1 month - 1 second' between v.eff_dttm and v.exp_dttm and v.deleted_ind=0
                                          and date_trunc('month',to_date('20190601','YYYYMMDD'))::timestamp + INTERVAL '1 month - 1 second' between b.eff_dttm and b.exp_dttm and b.deleted_ind=0),
                            sal.user_type_id)
                      ) or (u.user_type_id NOT in (20400,3792977,29043226,29031857,29031859,29031863,20555,20585)
                            and ut.user_type_id = sal.user_type_id))  --Выбор головного счета.
              group by decode(substr(to_char(svc.line_rate,'FM9999999999'),1,2),'22',2012,'23',2013,'24',2014),
                       decode(substr(to_char(svc.line_rate,'FM9999999999'),1,2),'22','пользующихся услугами в/з соединений между абонентами сети фиксированной телефонной связи (ABC на ABC)',
                                                        '23','пользующихся услугами в/з соединений в пределах одного поселения между абонентами сети фиксированной телефонной связи (АВС) и сети подвижной радиосвязи (DEF)',
                                                        '24','пользующихся услугами в/з соединений за пределами одного поселения между абонентами сети фиксированной телефонной связи (АВС) и сети подвижной радиосвязи (DEF)'),
                       ut.type_ut, sal.dept_id

              union all                                                    --доходы от ВЗ
              select
                     svc.line_rate,
                   svc.num_rate,
                     svc.name_rate,
                     summ_ut.type_ut,
                     sa.filial_dept_id dept_id,
                     sum(sa.charge_summ-sa.charge_tax) qt
              from EDW_ODS.T_000080_DP_SVC_AGR sa,
             svc,
           summ_ut
              where sa.tech_dt between date_trunc('month',to_date('20190601','YYYYMMDD'))::timestamp and date_trunc('month',to_date('20190601','YYYYMMDD'))::timestamp + INTERVAL '1 month - 1 second'
          and sa.billing_id = substr('20190601',1,6)::int
                and sa.vnd_id=1  --ID поставщика
                and svc.id_layer_svc=54   --отбор доходы ВНЗ
                and sa.svc_id=svc.svc_id
                and sa.user_type_id=summ_ut.user_type_id
                and (sa.charge_type='ch' or (sa.charge_type='chc' and coalesce(substr(to_char(sa.ebid,'999999'),1,4),substr(to_char(sa.billing_id,'999999'),1,4))=substr(to_char(sa.billing_id,'999999'),1,4)))  ----отбираем начисления или корректировки для текущего billing_id
              group by svc.line_rate, svc.num_rate, svc.name_rate, summ_ut.type_ut, sa.filial_dept_id
              ) uni_agr
     ) sel_agr
group by
       SRC_ID,
       DEPT_ID,
       BILL_PRD_DTTM,
       LINE_RATE,
       NUM_RATE,
       NAME_RATE,
       TYPE_UT
order by line_rate, num_rate;

analyse EDW_STG_DM_SIBERIA.TFCT_ODPU_INTRAZON_MTH_1_prt_P000080;
