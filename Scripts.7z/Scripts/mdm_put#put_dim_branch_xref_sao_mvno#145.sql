/*rev.31462 21.06.2019*/
	DELETE FROM edw_stg_mdm.put_dim_branch_xref_sao_mvno WHERE src_id = 145;

  insert into edw_stg_mdm.put_dim_branch_xref_sao_mvno
    (
     SOURCE_KEY,
     SRC_ID
    )
  select distinct upper(rf),
                  145
  from edw_ods.t_000145_v_sas_subs
  where rf is not null;

  ANALYSE edw_stg_mdm.put_dim_branch_xref_sao_mvno;