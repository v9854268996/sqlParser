/*rev.  20.04.2020*/
delete from edw_stg_mdm.put_dim_segment_xref_start where region_id = 'CENTER' and src_id = 000060;

insert into edw_stg_mdm.put_dim_segment_xref_start (segment_key,segment_name,region_id,src_id)
	select distinct 
       (round(user_type.user_type_id)) as code,
       user_type.name,
	   'CENTER' as region_id
	   ,t_users.src_id
    from edw_ods.t_000060_t_users t_users
       join edw_ods.t_000062_t_user_type_ref user_type
	     on t_users.user_type_id = user_type.user_type_id
	and user_type.deleted_ind = 0
	and to_date(substr('20190630', 1, 8),'YYYYMMDD') + INTERVAL '1 day - 1 second'  + interval '7 days'  between user_type.eff_dttm and user_type.exp_dttm
where t_users.deleted_ind = 0
	and to_date(substr('20190630', 1, 8),'YYYYMMDD') + INTERVAL '1 day - 1 second'  + interval '7 days'  between t_users.eff_dttm and t_users.exp_dttm
;
commit;
analyse edw_stg_mdm.put_dim_segment_xref_start;
