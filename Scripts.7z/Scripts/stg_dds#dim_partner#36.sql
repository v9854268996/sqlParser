/*rev.22684 18.02.2019*/
  
truncate edw_stg_dds.t_000036_dim_partner;
insert into edw_stg_dds.t_000036_dim_partner
(
  partner_key,
  parent_tax_number_cval,
  tax_number_cval,
  segment_key,
  partner_full_name,
  src_id,
  start_date,
  end_date,
  eff_dttm,
  exp_dttm
)
  select
    partner_key,
    parent_tax_number_cval,
    tax_number_cval,
    segment_key,
    partner_full_name,
    src_id,
    start_date,
    end_date,
    start_date as eff_dttm,
    end_date   as exp_dttm
  from(
			select
			  partner_key,
			  parent_tax_number_cval,
			  tax_number_cval,
			  segment_key,
			  partner_full_name,
			  src_id,
			  case when
				rns=1 then '19000101'
			  else dfdatebegins end as start_date,
			  case when
				rns=max(rns) over (partition by partner_key) then '29991231'
			  else
				lead(dfdatebegins) over (partition by partner_key order by rns) - interval '1 sec' end as end_date
			from(
				  SELECT
					a.src_id||';'||coalesce(dds.dfabonent,a.dfabonent::numeric(38,0)||'#N')   as partner_key,
					null                        as parent_tax_number_cval,
					case when length(a.dfinn) > 0 then a.dfinn end                    as tax_number_cval,
					coalesce(dds.dfactivity_dop_segment, '-23')::numeric(38) as segment_key,
					case when coalesce(a.dfenterprises,'F') = 'T'
					  then case when length(a.dfname) > 0 then a.dfname end
					else case when length(a.dffamili) > 0 or length(a.dfim) > 0 or length(a.dfotch) > 0 then a.dffamili||' '||a.dfim||' '||a.dfotch end
					end                         as partner_full_name,
					a.src_id,
					dfdatebegins,
					dfdateends,
					row_number() over(partition by a.dfabonent order by dfdatebegins,dfdateends,dfactivity_dop_segment desc)  as rns

				  FROM edw_ods.t_000036_tabonent  a
					left join (
								select distinct
								  dfactivity_dop_segment,
								  dfabonent,
								  dfabonentold,
								  min(dfdatebegin) over (partition by dfabonent,rank_sum) as dfdatebegins,
								  max(dfdateend) over (partition by dfabonent,rank_sum) as dfdateends
								from(
									  select *,
										sum(rank_dif) over(partition by dfabonent order by rn) as rank_sum
									  from(
											select *,
											  case when
												coalesce(lag(dfactivity_dop_segment) over (partition by dfabonent order by rn),dfactivity_dop_segment)=dfactivity_dop_segment
												then 0 else 1 end as rank_dif
											from(
												  select dfdogovor, dfabonent,dfabonentold,
													dfactivity_dop_segment,dfdatebegin,dfdateend,
													row_number() over(partition by dfabonent order by dfdatebegin,dfdateend,dfdogovor,dfactivity_dop_segment desc) rn
												  from(
														select td.dfdogovor, case
																			 when tds.dfactivity_dop_segment=-23 then
																			   td.dfabonent::numeric(38)||'#N'
																			 else td.dfabonent::numeric(38)||'#Y' end as dfabonent,
																			 td.dfabonent as dfabonentold
														  ,tds.dfactivity_dop_segment,tds.dfdatebegin,coalesce(tds.dfdateend,'29991231') as dfdateend
														from edw_ods.t_000036_tdogovor td
														  join edw_ods.t_000036_tdog_dop_segment tds on tds.dfdogovor=td.dfdogovor and tds.dfactivity_dop_segment is not null and tds.dfdatebegin is not null
														where td.deleted_ind=0 and tds.deleted_ind = 0
													  )l0
												)l1
										  )l2
									)l3
							  )  dds ON dds.dfabonentold=a.dfabonent

              where a.deleted_ind = 0
            )t
      )t1
	  where start_date < end_date		
	  ;
commit;
analyze edw_stg_dds.t_000036_dim_partner;