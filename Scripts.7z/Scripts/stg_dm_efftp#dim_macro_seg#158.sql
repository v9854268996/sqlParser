--rev. 60611 от 10.06.2020

truncate table edw_stg_dm_efftp.dim_macro_seg_1_prt_p000158;

insert into edw_stg_dm_efftp.dim_macro_seg_1_prt_p000158
(
    MACRO_SEG_ID,
    MACRO_SEG_CODE,
    MACRO_SEG_NAME,
    MACRO_SEG_SHORT_NAME,
    DATE_BEGIN,
    DATE_END,
    SEG_CODE,
    PAR_DEF,
    CLINT_TYPE,
    KAT_CL,
    SAS_CM_TYPE,
    SEG,
    SRC_ID
)
with addit_string as
(
    select md5('-1' || chr(9)) as MACRO_SEG_ID,
        'Не определено'::text as MACRO_SEG_CODE,
        'Не определено'::text as MACRO_SEG_NAME,
        null::text as MACRO_SEG_SHORT_NAME,
        '1980-01-01'::date as DATE_BEGIN,
        '2099-01-01'::date as DATE_END,
        '-1'::text as SEG_CODE,
        'Не определено'::text as PAR_DEF,
        'Не определено'::text as CLINT_TYPE,
        null::text as KAT_CL,
        null::text as SAS_CM_TYPE,
        null::text as SEG,
        000158 as SRC_ID
    union all
    select md5('-901' || chr(9)) as MACRO_SEG_ID,
        'K0487'::text as MACRO_SEG_CODE,
        'Физические лица конвергенты (кроме расчетов по агентской схеме, кроме расчетов на персональных счетах, кроме абонентов «Бизнес-окружения»)'::text as MACRO_SEG_NAME,
        'Физические лица конвергенты' as MACRO_SEG_SHORT_NAME,
        '1980-01-01'::date as DATE_BEGIN,
        '2099-01-01'::date as DATE_END,
        'K0487'::text as SEG_CODE,
        'Физические лица'::text as PAR_DEF,
        'B2C'::text as CLINT_TYPE,
        null::text as KAT_CL,
        null::text as SAS_CM_TYPE,
        null::text as SEG,
        000158 as SRC_ID
    union all
    select md5('-902' || chr(9)) as MACRO_SEG_ID,
        'K0488'::text as MACRO_SEG_CODE,
        'Физические лица конвергенты (кроме расчетов по агентской схеме, кроме расчетов на персональных счетах, кроме абонентов «Бизнес-окружения») по сделкам M'||'&'||'A'::text as MACRO_SEG_NAME,
        'Физические лица конвергенты по сделкам M'||'&'||'A' as MACRO_SEG_SHORT_NAME,
        '2018-01-01'::date as DATE_BEGIN,
        '2999-12-31'::date as DATE_END,
        'K0488'::text as SEG_CODE,
        'Физические лица'::text as PAR_DEF,
        'B2C'::text as CLINT_TYPE,
        null::text as KAT_CL,
        null::text as SAS_CM_TYPE,
        null::text as SEG,
        000158 as SRC_ID
)
select md5(coalesce(dms.id_macro_segment::text, ''::text) || chr(9)) as MACRO_SEG_ID,
    dms.macro_segment as MACRO_SEG_CODE,
    dms.name_microsegment as MACRO_SEG_NAME,
    case
      when lower(dms.name_microsegment) SIMILAR TO '%физические лица%' and lower(dms.name_microsegment) SIMILAR TO '%сделкам m&a%' then 'Физические лица по сделкам M&A'
      when lower(dms.name_microsegment) SIMILAR TO '%физические лица%' then 'Физические лица'
      else null
    end as MACRO_SEG_SHORT_NAME,
    dms.DATE_BEGIN,
    dms.DATE_END,
    dms.macro_segment_d as SEG_CODE,
    dms.PAR_DEF,
    dms.client_type as CLINT_TYPE,
    dms.KAT_CL,
    dms.sas_cm_ctype as SAS_CM_TYPE,
    dms.segment as SEG,
    000158 as SRC_ID
from EDW_ODS.T_000158_RPRT_DIRD_MACRO_SGMNT dms
where dms.MACRO_SEGMENT is not null

union all

select *
from addit_string
;

commit;

analyze edw_stg_dm_efftp.dim_macro_seg_1_prt_p000158;
