/*rev.55847 24.04.2020*/

/*Корректировки начислений*/
truncate edw_stg_dds.t_000049_tfct_adjust;
insert into edw_stg_dds.t_000049_tfct_adjust 
(  
adjust_key
, subs_key
, account_key
, service_key
, bill_detail_key
, payment_key 
, contract_key
, adjust_type_key
, service_user_key
, rc_key 
, corr_billing_id
, adjust_dttm
, adjust_amt
, vat_rub
, billing_dttm
, src_id
, load_dttm
, eff_dttm
, exp_dttm
)

SELECT 
adjust_key
, subs_key
, src_id||'#'||account_key as account_key
, service_key
, bill_detail_key
, payment_key 
, contract_key
, adjust_type_key
, service_user_key
, rc_key 
, corr_billing_id
, adjust_dttm
, adjust_amt
, vat_rub
, billing_dttm
, src_id
, load_dttm
, eff_dttm
, exp_dttm

from 
(   
	select  
	'1#'||tsc.corr_id as adjust_key -- Идентификатор корректировки
	, coalesce(tsc.error_billing_id,to_char(cdate,'YYYYMM')::numeric, tsc.billing_id) as corr_billing_id -- Идентификатор корректируемого периода
	, tsc.cdate as adjust_dttm -- Дата создания корректировки
	, tsc.user_id as account_key -- Идентификатор лицевого счета
	, tsc.svc_id as service_key
	, -1 as payment_key -- Идентификатор платежа
	, (tsc.billing_id::text) ||'#'|| LPAD ((TRIM (u.account)::numeric)::text, 12, '0') as bill_key -- Идентификатор счета
	, coalesce('1'||'#'||tsc.reason_id,'1') as adjust_type_key -- Идентификатор типа корректировки
	, decode(tsc.svc_corr_type::int,1,-1,2,-1,1) * (tsc.summ - tsc.tax) as adjust_amt -- Сумма корректировки в рублях, без НДС
	, decode(tsc.svc_corr_type::int,1,-1,2,-1,1) * tsc.tax as vat_rub -- Сумма НДС, руб.
	, (
		select 
		CASE 
			WHEN ROW_NUMBER () OVER (PARTITION BY o_contract.user_id ORDER BY DECODE (t_sub_contract.vndr_contract_id, t_sub_contract.contract_id, 1, 2), t_sub_contract.vndr_contract_id) = 1
				THEN  o_contract.contract_id
				ELSE  t_sub_contract.vndr_contract_id
		END
	) as contract_key -- Идентификатор договора
	, cpa_charge.charge_id as bill_detail_key --Идентификатор Детали счета            
	, u.user_id||'#'||coalesce(tsc.phone,'0') as service_user_key
	, dim_subs.subs_key as subs_key
	, ROW_NUMBER() OVER (partition by tsc.corr_id order by 	case 
													        	when (xref.sub_make=1 and tsc.service_id::text = dim_subs.service_id)  
																	then 1
																when (xref.sub_make=0 and (tsc.phone=dim_subs.dev_id) and et.technology_type_key=dim_subs.technology_type_key) 
																	then 2
																when (xref.sub_make=0 and (tsc.phone=dim_subs.dev_id)) 
																	then 3
																when (xref.sub_make=0) 
																	then 4
																	else 99999
															end asc) 
	as key1 -- ключ уникальности начисления 
	, tsc.src_id as src_id
	, dim_segment.segment_name||'#'||xref.rcode_asr as rc_key
	, now() as load_dttm
	, cast('1900-01-01 00:00:00' as timestamp(0) without time zone) as eff_dttm
	, cast('2999-12-31 00:00:00' as timestamp(0) without time zone) as exp_dttm
	, case when coalesce(tsc.vnd_id,1) in (1,195039493,496417573,485899633,538867560,1,2,453179910,544753179,550566590,722731353) then 1 else 0 end as VND
    , to_date(tsc.billing_id::text,'yyyymm') as billing_dttm 
	from 
	(
		select * 
		from edw_ods.t_000049_t_svc_correction tsc 
		where 1=1
		and tsc.billing_id <> coalesce(tsc.error_billing_id,to_char(cdate,'YYYYMM')::numeric, tsc.billing_id) 
		and tsc.billing_id between substr('20190601', 1, 6)::int and substr('20190630', 1, 6)::int 
		and tsc.tech_dt between to_date(substr('20190601', 1, 8), 'YYYYMMDD') and to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second'
	) tsc

	JOIN edw_stg_dds.t_000049_dim_account dim_account 
		ON tsc.src_id||'#'||tsc.user_id = dim_account.account_key 
		and tsc.src_id = dim_account.src_id 
		and to_date(tsc.billing_id::text,'YYYYMMDD') + INTERVAL '1 MONTH - 1 second' between dim_account.eff_dttm and dim_account.exp_dttm

	JOIN edw_stg_dds.t_000049_dim_partner dim_partner 
		ON dim_account.partner_key = dim_partner.partner_key 
		and dim_account.src_id = dim_partner.src_id 
		and to_date(tsc.billing_id::text,'YYYYMMDD') + INTERVAL '1 MONTH - 1 second' between dim_partner.eff_dttm and dim_partner.exp_dttm		

	LEFT JOIN edw_dds.hub_dim_segment hub_dim_segment 
		ON hub_dim_segment.source_key = dim_partner.segment_key 
		and hub_dim_segment.src_id = dim_partner.src_id 
		and to_date(tsc.billing_id::text,'YYYYMMDD') + INTERVAL '1 MONTH - 1 second' between hub_dim_segment.eff_dttm and hub_dim_segment.exp_dttm

	LEFT JOIN edw_dds.dim_segment dim_segment 
		ON dim_segment.segment_key = hub_dim_segment.segment_key 
		and dim_segment.deleted_ind=0 
		and to_date(tsc.billing_id::text,'YYYYMMDD') + INTERVAL '1 MONTH - 1 second' between dim_segment.eff_dttm and dim_segment.exp_dttm	


	LEFT JOIN edw_ods.t_000049_t_users u 
		on u.user_id = tsc.user_id 
		and u.DELETED_IND <> 1
        and to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second' + interval '7 day'  between u.eff_dttm and u.exp_dttm
	left join edw_stg_dds.t_dim_service_xref_start xref
		on xref.source_key = tsc.svc_id::text 
			and to_date(tsc.billing_id::text,'YYYYMMDD') + INTERVAL '1 MONTH - 1 second' between xref.eff_dttm and xref.exp_dttm
			and xref.region_id = 'CENTER'
	left join edw_dds.dim_service et
		on et.service_key = xref.service_key
		and to_date(tsc.billing_id::text,'YYYYMMDD') + INTERVAL '1 MONTH - 1 second' between et.eff_dttm and et.exp_dttm
	left join
	(
     select cpa_charge.bid,
            cpa_charge.user_id,
            cpa_charge.svc_id,
            min(cpa_charge.charge_id) charge_id
     from edw_ods.t_000049_cpa_charge cpa_charge
     where cpa_charge.tech_dt between to_date(substr('20190601', 1, 8), 'YYYYMMDD') and to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second' -- because cpa_charge.bid = tsc.billing_id
     group by cpa_charge.bid,

              cpa_charge.user_id,
              cpa_charge.svc_id
    ) cpa_charge
		on cpa_charge.bid = tsc.billing_id
		and cpa_charge.user_id = tsc.user_id
		and cpa_charge.svc_id = tsc.svc_id         
	left join  edw_ods.t_000049_o_contract  o_contract   
		on o_contract.user_id = tsc.user_id 
		and o_contract.DELETED_IND <> 1
        and to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second' between o_contract.eff_dttm and o_contract.exp_dttm

	left join edw_ods.t_000049_t_sub_contract t_sub_contract  
        on  t_sub_contract.contract_id = o_contract.contract_id 
		and t_sub_contract.DELETED_IND <> 1
        and to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second' between t_sub_contract.eff_dttm and t_sub_contract.exp_dttm

	left join  
	(
        select 
		dim_subs.service_id
		, dim_subs.subs_key
		, dim_subs.account_key
		, dim_subs.subs_code as dev_id
		, dim_subs.start_date
		, dim_subs.end_date
		, et.business_service_key 
		, et.technology_type_key 
		from edw_stg_dds.t_000049_dim_subs dim_subs
		left join edw_stg_dds.t_dim_service_xref_start xref
			on xref.source_key = dim_subs.service_key 
			and to_date('20190601','YYYYMMDD') + INTERVAL '1 MONTH - 1 second' between xref.eff_dttm and xref.exp_dttm
			and xref.region_id = 'CENTER'	
        left join edw_dds.dim_service et
			on et.service_key = xref.service_key
			and to_date('20190601','YYYYMMDD') + INTERVAL '1 MONTH - 1 second' between et.eff_dttm and et.exp_dttm   
	) dim_subs        
		on tsc.src_id||'#'||tsc.user_id = dim_subs.account_key            
		and et.business_service_key = dim_subs.business_service_key    
        and date_trunc('month',to_date(coalesce(tsc.error_billing_id,billing_id)::text,'YYYYMM')) between date_trunc('month',dim_subs.start_date) and date_trunc('month',dim_subs.end_date)
) s
where s.key1=1 and VND = 1
;

/*t_pay_correction*/  
/*Корректировки платежей*/

insert into edw_stg_dds.t_000049_tfct_adjust(
                  adjust_key
				, subs_key
				, account_key
				, service_key
				, bill_detail_key
				, payment_key 
				, contract_key
				, adjust_type_key
				, service_user_key
				, rc_key 
				, corr_billing_id
				, adjust_dttm
				, adjust_amt
				, vat_rub
				, billing_dttm
				, src_id
				, load_dttm
				, eff_dttm
				, exp_dttm)
SELECT adjust_key
, subs_key
, src_id||'#'||account_key as account_key
, service_key
, bill_detail_key
, payment_key 
, contract_key
, adjust_type_key
, service_user_key
, rc_key 
, corr_billing_id
, adjust_dttm
, adjust_amt
, vat_rub
, billing_dttm
, src_id
, load_dttm
, eff_dttm
, exp_dttm
  FROM(	
SELECT  '3#'||t_pay_correction.pay_corr_id as adjust_key -- Идентификатор корректировки 
		,coalesce(t_pay_correction.error_billing_id,to_char(pay_date,'YYYYMM')::numeric, t_pay_correction.billing_id) as corr_billing_ID -- Идентификатор корректируемого периода корректируемого периода
		,t_pay_correction.corr_date as adjust_dttm -- Дата создания корректировки
	  	,coalesce('3'||'#'||t_pay_correction.reason_id, '3') as adjust_type_key -- Идентификатор типа корректировки
	  	,-1 as subs_key                     -- Идентификатор Абонента
	  	,-1 as service_key
		, -1 as service_user_key
	  	, -1 as rc_key
	  	,t_pay_correction.user_id as account_key -- Идентификатор лицевого счета
	  	,t_pay_correction.payment_id as payment_key -- Идентификатор платежа
	  	,-1 as bill_key -- Идентификатор счета
	  	,-1 as bill_detail_key --Идентификатор Детали счета
	  	,-1 as contract_key -- Идентификатор договора
	  	,(decode(t_pay_correction.pay_corr_type::numeric,1,-1,2,-1,1)*t_pay_correction.summ)*(0.2/(1+0.2)) as vat_rub -- Сумма НДС, руб.
		,(decode(t_pay_correction.pay_corr_type::numeric,1,-1,2,-1,1)*t_pay_correction.summ)*(1/(1+0.2)) as adjust_amt -- Сумма корректировки в рублях, без НДС 
	  	,000049 as src_id
	  	,now() as load_dttm
		,to_date(t_pay_correction.billing_id::text,'yyyymm') as billing_dttm
		,cast('1900-01-01 00:00:00' as timestamp(0) without time zone) as eff_dttm
		,cast('2999-12-31 00:00:00' as timestamp(0) without time zone) as exp_dttm
		,cast('1900-01-01 00:00:00' as timestamp(0) without time zone) as start_date
		,cast('2999-12-31 00:00:00' as timestamp(0) without time zone) as end_date	

FROM edw_ods.t_000049_t_pay_correction t_pay_correction
where t_pay_correction.billing_id between substr('20190601', 1, 6)::int and substr('20190630', 1, 6)::int
  and t_pay_correction.tech_dt between to_date(substr('20190601', 1, 8), 'YYYYMMDD') and to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second'
)sss;
analyze edw_stg_dds.t_000049_tfct_adjust;
