/*rev. 39557 13.09.2019*/
SET search_path = edw_stg_dmcm;
SET optimizer = ON;


TRUNCATE TABLE edw_stg_dmcm.PRE_IPTV_ABN_PORT3_STG_1_PRT_P000154;
INSERT
INTO edw_stg_dmcm.PRE_IPTV_ABN_PORT3_STG_1_PRT_P000154
(
  login,
  port_num,
  abn_id,
  rf_id,
  mrf_id,
  city_name,
  date_snap,
  port_usage,
  port_state,
  src_id,
  load_dttm
)
  SELECT
    login,
    port_num,
    abn_id,
    rf_id,
    mrf_id,
    city_name,
    date_snap,
    port_usage,
    port_state,
    154 :: SMALLINT,
    current_date AS load_dttm
  FROM
    (
      SELECT
        port_num,
        abn_id,
        login,
        rf_id,
        mrf_id,
        city_name,
        date_snap,
        date_comm,
        port_usage,
        port_state,
        row_number ( )
        OVER (
          PARTITION BY abn_id
          ORDER BY
            CASE WHEN date_snap <= to_date ( '20190630', 'YYYYMMDD' )
              THEN 0
            ELSE 1 END,
            date_snap DESC,
            date_comm DESC
          ) AS rn
      FROM edw_ods.T_000154_rprt_tchncl_data_dwh  -- lol154
      where tech_dt between to_date ( '20190601', 'YYYYMMDD' ) and to_date ( '20190630', 'YYYYMMDD' )
    ) port
  WHERE rn = 1;
ANALYSE edw_stg_dmcm.PRE_IPTV_ABN_PORT3_STG_1_PRT_P000154;


TRUNCATE TABLE edw_stg_dmcm.PRE_IPTV_ABN_CHRG_STG_1_PRT_P000154;
INSERT INTO edw_stg_dmcm.PRE_IPTV_ABN_CHRG_STG_1_PRT_P000154
(abn_id
  , account_key
  , account
  , charge_code
  , period
  , date_snap
  , rf_id
  , mrf_id
  , charge
  , load_dttm
  , src_id
)
  WITH
      hub_dim_branch AS (
      SELECT
        branch_key,
        source_key
      FROM edw_dds.hub_dim_branch hdb
      WHERE date_trunc ( 'day', hdb.exp_dttm ) = to_date ( '2999-12-31', 'yyyy-mm-dd' )
            AND hdb.src_id = 158),
      dim_branch AS (
      SELECT
        branch_key,
        parent_branch_key
      FROM edw_dds.dim_branch
      WHERE date_trunc ( 'day', dim_branch.exp_dttm ) = to_date ( '2999-12-31', 'yyyy-mm-dd' )
    ),
      sa AS (
      SELECT
        account,
        nls
      FROM (
             SELECT
               account,
               nls,
               row_number ( )
               OVER (
                 PARTITION BY account
                 ORDER BY COALESCE ( date_end, to_date ( '29991231', 'yyyymmdd' ) ) DESC, date_begin DESC
                 ) AS rn
             FROM edw_ods.t_000158_efftp_south_nls_accnt
           ) P
      WHERE p.rn = 1
    ),
      dim_account AS (
      SELECT
        account_name,
        account_key,
        branch_key,
        exp_dttm
      FROM edw_dds.dim_account acc
      WHERE CASE
            WHEN 154 = 151
              THEN acc.src_id BETWEEN 48 AND 62
            WHEN 154 = 152
              THEN acc.src_id = 97
            WHEN 154 = 153
              THEN acc.src_id BETWEEN 1 AND 12
            WHEN 154 = 154
              THEN acc.src_id BETWEEN 27 AND 39
            WHEN 154 = 155
              THEN acc.src_id = 45
            WHEN 154 = 156
              THEN acc.src_id BETWEEN 80 AND 89
            WHEN 154 = 157
              THEN acc.src_id BETWEEN 107 AND 113
            END
            AND date_trunc ( 'day', acc.exp_dttm ) = to_date ( '2999-12-31', 'yyyy-mm-dd' )
    )
  SELECT
    chrg.abn_id                            AS abn_id,
    dim_account.account_key                AS account_key,
    CASE WHEN chrg.mrf_id = 14
      THEN sa.nls
    ELSE chrg.account
    END                                    AS account,
    chrg.charge_code                       AS charge_code,
    to_char ( chrg.period,
              'yyyymm' )                   AS period,
    ( date_trunc ( 'MONTH' :: TEXT, chrg.period :: DATE ) +
      INTERVAL '1 MONTH - 1 day' ) :: DATE AS date_snap,
    hdb.branch_key                         AS rf_id,
    CASE
    WHEN dim_branch.parent_branch_key = -1
      THEN dim_branch.branch_key
    ELSE dim_branch.parent_branch_key
    END                                    AS mrf_id,
    sum ( chrg.charge -
          chrg.vat_amount )                AS charge,
    current_date                           AS load_dttm,
    154                            AS src_id
  FROM edw_ods.T_000154_rprt_charges_dwh chrg  -- lol154
    LEFT JOIN
    hub_dim_branch hdb
      ON hdb.source_key = chrg.rf_id :: TEXT
    LEFT JOIN
    dim_branch
      ON dim_branch.branch_key = hdb.branch_key
    LEFT JOIN
    sa
      ON sa.account = chrg.account
         AND chrg.mrf_id = 14
    LEFT JOIN dim_account
      ON dim_account.account_name = (CASE WHEN chrg.mrf_id = 14
      THEN sa.nls
                                    ELSE chrg.account END)
  WHERE (CHARGE_CODE LIKE 'R08010102%' OR CHARGE_CODE LIKE 'R08010103%')
        AND chrg.coef_r12 = 1
        AND chrg.period BETWEEN to_date ( '20190601', 'YYYYMMDD' ) AND to_date ( '20190630',
                                                                                        'YYYYMMDD' )
  GROUP BY
    chrg.abn_id,
    dim_account.account_key,
    (CASE WHEN chrg.mrf_id = 14
      THEN sa.nls
    ELSE chrg.account
    END),
    chrg.charge_code,
    to_char ( chrg.period, 'yyyymm' ),
    ( date_trunc ( 'MONTH' :: TEXT, chrg.period :: DATE ) + INTERVAL '1 MONTH - 1 day' ),
    hdb.branch_key,
    (CASE
    WHEN dim_branch.parent_branch_key = -1
      THEN dim_branch.branch_key
    ELSE dim_branch.parent_branch_key END);
ANALYSE edw_stg_dmcm.PRE_IPTV_ABN_CHRG_STG_1_PRT_P000154;


TRUNCATE TABLE edw_stg_dmcm.PRE_IPTV_ABN_DATE_START_STG_1_PRT_P000154;
INSERT INTO edw_stg_dmcm.PRE_IPTV_ABN_DATE_START_STG_1_PRT_P000154
(abn_id
  , date_start
  , load_dttm
  , src_id
)
  SELECT
    chrg.abn_id    AS abn_id,
    min ( period ) AS date_start,
    current_date   AS load_dttm,
    154    AS src_id
  FROM edw_ods.t_000154_rprt_charges_dwh chrg -- lol154
  WHERE (CHARGE_CODE LIKE 'R08010102%' OR CHARGE_CODE LIKE 'R08010103%')
        AND chrg.coef_r12 = 1
  GROUP BY
    chrg.abn_id;


SET optimizer = ON;
TRUNCATE TABLE edw_stg_dmcm.TFCT_IPTV_ABN_1_PRT_P000154;
INSERT INTO edw_stg_dmcm.TFCT_IPTV_ABN_1_PRT_P000154
(period
  , date_snap
  , mrf
  , rf
  , id_rf
  , locality_name
  , street_name
  , house_number
  , address
  , orpon_id
  , okn
  , okved
  , account
  , account_key
  , inn
  , client_name
  , k_code
  , segment
  , id_macro_segment
  , special_usr_attr
  , migration_attr
  , inv_project_code
  , login
  , port_num
  , date_start
  , port_state
  , rtpl_name
  , charge
  , dz_sum
  , dz_date
  , cfo
  , abn_id
  , charge_code
  , tech_name
  , tp_start
  , src_id
  , load_dttm)
  WITH w_vrate_plans_dwh AS
  (
    SELECT
      tbl.rtpl_name,
      tbl.date_start                                                AS tp_start,
      to_char ( to_date ( '20190630', 'YYYYMMDD' ), 'YYYYMM' ) AS period,
      coalesce ( tbl.speed, tbl.speed_min )                         AS speed,
      coalesce ( tbl.tech_id, tbl.tech_id_min )                     AS tech_id,
      coalesce ( tbl.start_rtpl, tbl.start_rtpl_min )               AS start_rtpl,
      tbl.abn_id
    FROM (
           SELECT
             v.rtpl_name,
             v.date_start,
             v.speed,
             v.tech_id,
             v.start_rtpl,
             v.abn_id,
             min ( v.start_rtpl )
             OVER (
               PARTITION BY v.abn_id ) AS start_rtpl_min,
             min ( v.tech_id )
             OVER (
               PARTITION BY v.abn_id ) AS tech_id_min,
             min ( v.speed )
             OVER (
               PARTITION BY v.abn_id ) AS speed_min,
             row_number ( )
             OVER (
               PARTITION BY v.abn_id
               ORDER BY CASE WHEN v.date_start <= to_date ( '20190630', 'YYYYMMDD' )
                 THEN 0
                        ELSE 1 END,
                 CASE WHEN hub_dim_business_service.business_service_key between 10400 and 10499
                   THEN 0
                 ELSE 1 END,
                 v.date_start DESC
               )                       AS rn
           FROM edw_ods.t_000154_rprt_vrate_plans_dwh v  -- lol154
             JOIN
             edw_dds.hub_dim_business_service hub_dim_business_service
               ON hub_dim_business_service.src_id = 158
                  AND date_trunc ( 'day', hub_dim_business_service.exp_dttm ) = to_date ( '2999-12-31', 'yyyy-mm-dd' )
                  AND hub_dim_business_service.source_key =
                      coalesce ( v.serv_id, '-1' ) || '#' || coalesce ( v.tech_id, '-1' )
         ) tbl
    WHERE tbl.rn = 1
  ),
      w_oo_address AS
    (
      SELECT
        postoffice_id || CASE WHEN postoffice_id IS NOT NULL
          THEN ', '
                         ELSE '' END
        || terr_type || CASE WHEN terr_type IS NOT NULL
          THEN ' '
                        ELSE '' END
        || name_terr || CASE WHEN coalesce ( terr_type, name_terr ) IS NOT NULL
          THEN ', '
                        ELSE '' END
        || city || CASE WHEN city IS NOT NULL
          THEN ', '
                   ELSE '' END
        || name_street_type || CASE WHEN name_street_type IS NOT NULL
          THEN ' '
                               ELSE '' END
        || name_street || CASE WHEN coalesce ( name_street_type, name_street ) IS NOT NULL
          THEN ', '
                          ELSE '' END
        || house AS address,
        house_lid,
        house_gid,
        city,
        name_street,
        house,
        mrf_id
      FROM edw_ods.T_000154_rprt_oo_address  -- lol154
    ),
      w_subscribersdetal AS
    (
      SELECT *
      FROM
        (
          SELECT
            abn_id,
            mrf_id,
            flag_mgr,
            row_number ( )
            OVER (
              PARTITION BY abn_id, mrf_id
              ORDER BY CASE WHEN dt_end IS NULL
                THEN '2999-12-31 00:00:00'
                       ELSE dt_end END DESC,
                CASE WHEN dt_start IS NULL
                  THEN '2999-12-31 00:00:00'
                ELSE dt_start END DESC ) rn
          FROM edw_ods.T_000154_rprt_subscribersdetal  -- lol154
        ) r
      WHERE r.rn = 1
    ),
      w_oo_addressabndwh AS
    (
      SELECT
        abn_id,
        mrf_id,
        house_lid,
        flat
      FROM
        (
          SELECT
            abn_id,
            mrf_id,
            house_lid,
            flat,
            row_number ( )
            OVER (
              PARTITION BY abn_id, mrf_id
              ORDER BY CASE WHEN date_end IS NULL
                THEN '2999-12-31 00:00:00'
                       ELSE date_end END DESC,
                CASE WHEN date_begin IS NULL
                  THEN '2999-12-31 00:00:00'
                ELSE date_begin END DESC ) rn
          FROM edw_ods.T_000154_rprt_oo_addressabndwh   -- lol154
        ) a
      WHERE a.rn = 1
    ),
      w_inv_charges_abn_view_b2b AS
    (
      SELECT
        abn_id,
        mrf_id,
        period,
        invest_pr,
        cfo,
        charge_code,
        charge_code_detal
      FROM
        (
          SELECT
            abn_id,
            mrf_id,
            period,
            invest_pr,
            cfo,
            charge_code,
            charge_code_detal,
            row_number ( )
            OVER (
              PARTITION BY abn_id, mrf_id, period
              ORDER BY CASE WHEN invest_pr IS NULL
                THEN 1
                       ELSE 0 END,
                CASE WHEN cfo IS NULL
                  THEN 1
                ELSE 0 END ) AS rn
          FROM edw_ods.T_000154_inv_charges_abn_view_b2b -- lol154
          WHERE (CHARGE_CODE LIKE 'R08010102%' OR CHARGE_CODE LIKE 'R08010103%' OR charge_code_detal LIKE 'R08010102%' OR charge_code_detal LIKE 'R08010103%')
                   AND period = to_char ( to_date ( '20190630', 'YYYYMMDD' ), 'YYYYMM' )
        ) inv
      WHERE inv.rn = 1
    ),
      scor AS (
      SELECT
        cast ( db.user_id AS VARCHAR(100) ) AS user_id,
        cast ( db.period AS VARCHAR(6) )    AS period,
        sum ( db.overdue_deb )              AS dz_sum,
        max ( db.date_planed )              AS dz_date,
        db.mrf_id
      FROM edw_ods.t_000159_debt_dwh db
      WHERE db.overdue_deb > 0
            AND db.period :: TEXT = to_char ( to_date ( '20190630', 'YYYYMMDD' ), 'YYYYMM' )
      GROUP BY db.user_id, db.period, db.mrf_id
    ),
      addr_okn AS (
      SELECT *
      FROM (
             SELECT
               house_lid,
               mrf_id,
               globalid,
               okn_area,
               addr_okn.globalid :: TEXT AS       globalid__,
               row_number ( )
               OVER (
                 PARTITION BY house_lid, mrf_id ) rn
             FROM edw_ods.t_000158_address_okn addr_okn
             WHERE house_lid IS NOT NULL
           ) P
      WHERE p.RN = 1
    ),
      org AS (
      SELECT *
      FROM (
             SELECT
               inn,
               okved,
               row_number ( )
               OVER (
                 PARTITION BY inn
                 ORDER BY date_start DESC, update_snap DESC ) AS rn
             FROM edw_ods.t_000158_budget_org_detail
             WHERE date_end = to_date ( '2999-12-31', 'yyyy-mm-dd' )
           ) P
      WHERE p.RN = 1
    ),
  w_sa AS
  (
   SELECT account, nls FROM (
    SELECT
      account,
      nls,
      row_number ( )
      OVER (
        PARTITION BY account
        ORDER BY COALESCE ( date_end, to_date ( '29991231', 'yyyymmdd' ) ) DESC, date_begin DESC
        ) AS rn
    FROM edw_ods.t_000158_efftp_south_nls_accnt) a
   WHERE rn = 1
  ),
  w_cl2 AS
  (
    SELECT account, id_macro_segment_ud, contr_name, inn
    FROM
    (
        SELECT
          CASE WHEN c.mrf_id = 14 THEN sa.nls ELSE c.account END AS account,
          id_macro_segment_ud,
          contr_name,
          inn,
          row_number() OVER (
            PARTITION BY CASE WHEN c.mrf_id = 14 THEN sa.nls ELSE c.account END
            ORDER BY CASE WHEN c.date_snap <= to_date('20190630', 'YYYYMMDD') THEN 0 ELSE 1 END, c.date_snap DESC) AS rn
        FROM edw_ods.T_000154_rprt_client_dwh c  -- lol154
             LEFT JOIN
             w_sa sa
               ON sa.account = c.account
               AND c.mrf_id = 14
    ) c
    WHERE rn = 1
  )
  SELECT
    tel.period                                        AS period,
    tel.date_snap                                     AS date_snap,
    CASE
    WHEN dbr.parent_branch_key = -1
      THEN dbr.branch_name
    ELSE pdbr.branch_name
    END                                               AS mrf,
    dbr.branch_name                                   AS rf,
    tel.rf_id                                         AS id_rf,
    addr.city                                         AS locality_name,
    addr.name_street                                  AS street_name,
    addr.house                                        AS house_number,
    coalesce (
      addr.address
      || CASE WHEN addr_abn.flat IS NULL
        THEN ''
         ELSE ', '
         END
      || coalesce ( addr_abn.flat, '' ),
      subs.adress_dev )                               AS address,
    addr.house_gid                                    AS orpon_id,
    addr_okn.okn_area                                 AS okn,
    org.okved                                         AS okved,
    coalesce ( tel.account, '0' )                     AS account,
    coalesce ( tel.account_key :: NUMERIC(22, 0), 0 ) AS account_key,
    coalesce ( cl.inn, cl2.inn )                      AS inn,
    coalesce ( cl.contr_name, cl2.contr_name )        AS client_name,
    nm.macro_segment                                  AS k_code,
    nm.name_microsegment                              AS segment,
    coalesce(cl.id_macro_segment_ud, cl2.id_macro_segment_ud, 0) AS id_macro_segment,
    CASE WHEN nm.macro_segment IN ( 'K0102', 'K0104' )
      THEN 1
    ELSE 0
    END                                               AS special_usr_attr,
    coalesce ( subs_det.flag_mgr, 0 )                 AS migration_attr,
    inv.invest_pr                                     AS inv_project_code,
    prt.login                                         AS login,
    prt.port_num                                      AS port_num,
    dsm.date_start                                    AS date_start,
    prt.port_state                                    AS port_state,
    pln.rtpl_name                                     AS rtpl_name,
    coalesce ( tel.charge, 0 )                        AS charge,
    scor.dz_sum                                       AS dz_sum,
    scor.dz_date                                      AS dz_date,
    inv.cfo :: NUMERIC(22, 0)                         AS cfo,
    coalesce(tel.abn_id, -1)                          AS abn_id,
    tel.charge_code                                   AS charge_code,
    CASE WHEN ( tch.def IS NULL OR tch.def :: TEXT = '' )
      THEN
        CASE WHEN position ( 'DSL' IN upper ( pln.rtpl_name ) ) > 0
          THEN 'xDSL'
        WHEN position ( 'PON' IN upper ( pln.rtpl_name ) ) > 0
          THEN 'PON'
        WHEN position ( 'FTTX' IN upper ( pln.rtpl_name ) ) > 0
          THEN 'FTTx'
        WHEN position ( 'DOCSIS' IN upper ( pln.rtpl_name ) ) > 0
          THEN 'DOCSIS'
        WHEN position ( 'ETTH' IN upper ( pln.rtpl_name ) ) > 0
          THEN 'ETTH'
        WHEN position ( 'ETHERNET' IN upper ( pln.rtpl_name ) ) > 0
          THEN 'ETTH'
        ELSE ''
        END
    ELSE tch.def
    END                                               AS tech_name,
    pln.tp_start                                      AS tp_start,
    154                                       AS src_id,
    current_date
  FROM edw_stg_dmcm.PRE_IPTV_ABN_CHRG_STG_1_PRT_P000154 tel
    LEFT JOIN
    edw_ods.T_000154_rprtsubscribersactual subs   -- lol154
      ON subs.abn_id = tel.abn_id
    LEFT JOIN
    edw_stg_dmcm.PRE_IPTV_ABN_PORT3_STG_1_PRT_P000154 prt
      ON prt.abn_id = tel.abn_id
    LEFT JOIN
    edw_dds.dim_branch dbr
      ON tel.rf_id = dbr.branch_key
         AND date_trunc ( 'day', dbr.exp_dttm ) = to_date ( '2999-12-31', 'yyyy-mm-dd' )
    LEFT JOIN
    edw_dds.dim_branch pdbr
      ON pdbr.branch_key = dbr.parent_branch_key
         AND date_trunc ( 'day', pdbr.exp_dttm ) = to_date ( '2999-12-31', 'yyyy-mm-dd' )
    LEFT JOIN
    w_inv_charges_abn_view_b2b inv
      ON inv.abn_id = tel.abn_id
         AND inv.period = tel.period
         AND inv.mrf_id = tel.mrf_id
         AND ( inv.charge_code = tel.charge_code OR inv.charge_code_detal = tel.charge_code )
    LEFT JOIN
    w_oo_addressabndwh addr_abn
      ON addr_abn.abn_id = tel.abn_id
         AND addr_abn.mrf_id = subs.mrf_id
    LEFT JOIN
    w_oo_address addr
      ON addr.house_lid = addr_abn.house_lid
         AND addr.mrf_id = addr_abn.mrf_id
    LEFT JOIN
    w_subscribersdetal subs_det
      ON subs_det.abn_id = tel.abn_id
         AND subs_det.mrf_id = subs.mrf_id
    LEFT JOIN
    scor
      ON user_id = subs.org_subs_id
         AND scor.mrf_id = subs.mrf_id
         AND scor.period = tel.period
    LEFT JOIN
    addr_okn
      ON ( addr_okn.house_lid = addr_abn.house_lid
           OR ( addr_okn.house_lid IS NULL AND addr_okn.globalid__ = addr.house_gid ) )
         AND addr_okn.mrf_id = addr_abn.mrf_id
    LEFT JOIN
    w_vrate_plans_dwh pln
      ON pln.abn_id = tel.abn_id
    LEFT JOIN
    edw_ods.T_000154_rprt_client_dwh cl  -- lol154
      ON cl.cl_id = subs.cl_id
    LEFT JOIN
    w_cl2 cl2
        ON cl2.account = tel.account
    LEFT JOIN
    edw_ods.t_000158_rprt_dird_macro_sgmnt nm
      ON nm.id_macro_segment = coalesce(cl.id_macro_segment_ud, cl2.id_macro_segment_ud, 0)
    LEFT JOIN
    edw_ods.t_000158_rprt_dir_tech tch
      ON tch.tech_id = COALESCE ( subs.tech_id, pln.tech_id )
    LEFT JOIN
    org
      ON org.inn = coalesce ( cl.inn, cl2.inn )
    LEFT JOIN
    edw_stg_dmcm.PRE_IPTV_ABN_DATE_START_STG_1_PRT_P000154 dsm
      ON dsm.abn_id = tel.abn_id
  WHERE (CASE WHEN ( nm.macro_segment is not null or nm.macro_segment like 'К04%' )
                      AND (length(coalesce(cl.inn, cl2.inn)) = 10
                             OR lower(coalesce(cl.contr_name, cl2.contr_name)) LIKE 'ип %'
                             OR lower(coalesce(cl.contr_name, cl2.contr_name)) LIKE '%индивидуальный предприниматель%')
                 THEN 'К02'
            ELSE coalesce(nm.macro_segment, '')
          END) NOT LIKE 'K04%';
ANALYZE edw_stg_dmcm.TFCT_IPTV_ABN_1_PRT_P000154;
