/*rev.18947 06.12.2018*/
--General Subscriber Base Fact Table
truncate table edw_stg_ads.tfct_sub_base_1_prt_p000047  ;insert into edw_stg_ads.tfct_sub_base_1_prt_p000047
(
	calendar_key,
	year_month_key,
	account_key,
	period_account_name,
	subs_key,
	center_num_key,
	duty_num_key,
	segment_key,
	service_key,
	frequency_services_key,
	technology_type_key,
	service_rtk_detail_key,
	rc_key,
	branch_key,
	region_key,
	partner_key,
	period_tax_number,
	src_id
)

Select
	date_trunc('day', month_end_date)				as calendar_key,
	year_month_key,
	account_key,
	account_name									as period_account_name,
	subs_key,
	coalesce(center_num_key, 0)						as center_num_key,
	coalesce(duty_num_key, 0)						as duty_num_key,
	coalesce(segment_key, -1)						as segment_key,
	coalesce(service_key, -1)						as service_key,
	coalesce(frequency_services_key, -1) 			as frequency_services_key,
	coalesce(technology_type_key, -1)				as technology_type_key,
	coalesce(service_rtk_detail_key, '-1')			as service_rtk_detail_key,
	rc_key,
	coalesce(branch_key, -1)						as branch_key,
	coalesce(region_key, -1) 						as region_key,
	coalesce(partner_key, -1)						as partner_key,
	tax_number_cval									as period_tax_number,
	src_id
From 
	(
		Select
			cal.month_end_date,
			cal.year_month_key,
			da.account_name,
			da.account_key,
			da.center_num_key,
			da.duty_num_key,
			dp.segment_key,
			con_serv.service_key,
			srv.frequency_services_key,
			srv.technology_type_key,				
			srv.service_rtk_detail_key,
			case 
				when con_serv.rc_key <> -1 then con_serv.rc_key
				when con_serv.rc_key = -1 and  mrc.matrix_rc_key is not null then mrc.rc_key
				else -1
			end											as rc_key,
			da.branch_key,
			/*dr.region_key*/-1 as region_key,
			subs.subs_key,
			da.partner_key,
			dp.tax_number_cval,
			subs.src_id
		FROM 
			(
				SELECT DISTINCT
				  month_start_date, 
				  month_end_date + interval '1 day' + interval '-1 sec' as month_end_date,
				  to_char(month_end_date, 'YYYYMM') as year_month_key
				FROM 
				  edw_dds.dim_calendar
				WHERE 
					month_end_date between date_trunc('month', to_date('20190601', 'YYYYMMDD'))
						and (date_trunc('month', to_date('20190630', 'YYYYMMDD')) + interval '1 month' + interval '-1 sec')
			) as cal
			inner join edw_dds.dim_subscribers_1_prt_p000047 as subs
				on cal.month_end_date between subs.eff_dttm and subs.exp_dttm
					and date_trunc('day',subs.subs_cancellation_dttm) - INTERVAL '3 day' > date_trunc('day',subs.subs_activation_dttm)
					and cal.month_end_date >= subs.subs_activation_dttm 
					and cal.month_end_date < subs.subs_cancellation_dttm
					and subs.deleted_ind = 0
			inner join edw_dds.dim_connected_service_1_prt_p000047 as con_serv
				on 	   subs.subs_key = con_serv.subs_key
					and cal.month_end_date between con_serv.eff_dttm and con_serv.exp_dttm
					and cal.month_end_date between con_serv.start_date and con_serv.end_date
					and con_serv.deleted_ind = 0
			inner join edw_dds.dim_account_1_prt_p000047 as da 
				on da.account_key=con_serv.account_key 
					and cal.month_end_date between da.eff_dttm and da.exp_dttm
					and da.deleted_ind = 0
					and da.branch_key <> -2
			inner join edw_dds.dim_partner_1_prt_p000047 as dp 
				on dp.partner_key=da.partner_key
					and cal.month_end_date between dp.eff_dttm and dp.exp_dttm
					and dp.deleted_ind = 0
					and dp.partner_key <> -2
			left join edw_dds.dim_service as srv 
				on 	srv.service_key = con_serv.service_key 
					and srv.end_date='2999-12-31'
					and srv.deleted_ind = 0
			left join edw_dds.dim_matrix_rc as mrc
				on srv.service_rtk_detail_key = mrc.service_rtk_detail_key
					AND mrc.segment_key = dp.segment_key
					AND mrc.rc_default = 1
					and mrc.exp_dttm = '2999-12-31'
					and mrc.deleted_ind = 0
			/*left join edw_dds.dim_region as dr
				on da.branch_key = dr.branch_key
					and dr.exp_dttm = '2999-12-31'
					and dr.deleted_ind = 0*/
		where srv.service_key <> -2
	) base
;