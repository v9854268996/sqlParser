/*rev.47398 от 24.01.2020*/

delete from edw_stg_mdm.put_xref_dim_dop_service
where src_id = 000045;

insert into edw_stg_mdm.put_xref_dim_dop_service
(
  source_key,
  mrf_add_service_name,
  src_id
)
select distinct
    mrf_service_key,
    mrf_add_service_name,
    src_id
from edw_stg_dds.t_000045_dim_add_service
where src_id = 000045
union
select distinct
    split_part(key_asr, '^',2) as mrf_service_key,
    productname, 
    src_id
from edw_ods.t_000045_V_RTK_REP_ANTIVIR_CHANNEL_VW;

commit;

analyze edw_stg_mdm.put_xref_dim_dop_service;
