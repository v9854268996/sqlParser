/*rev.34588 31.07.2019 Changed by: NAREK.ALAVERDYAN */
		--dim_subs
		truncate table edw_stg_ads.dim_subs_1_prt_p000124 ;
		insert into edw_stg_ads.dim_subs_1_prt_p000124 
		( subs_key,  account_key,  service_key,  duty_num_key,
		  center_num_key,  address_key,  cpe_key,  port_key,
		  subs_code,  subs_activation_dt,  subs_cancellation_dt,
		  start_date,  end_date,  src_id, md5)
		select
		 subs_key,  account_key,  service_key,  duty_num_key,
		  center_num_key,  address_key,  cpe_key,  port_key,
		  subs_code,  subs_activation_dt,  subs_cancellation_dt,
		  start_date,  end_date,  src_id,
		  md5(((((((((((((((((((((((((((coalesce(subs_key::text, ''::text)) || chr(9)) || coalesce(account_key::text, ''::text)) || chr(9)) || coalesce(service_key::text, ''::text)) || chr(9)) || coalesce(duty_num_key::text, ''::text)) || chr(9)) || coalesce(center_num_key::text, ''::text)) || chr(9)) || coalesce(address_key::text, ''::text)) || chr(9)) || coalesce(cpe_key::text, ''::text)) || chr(9)) || coalesce(port_key::text, ''::text)) || chr(9)) || coalesce(subs_code::text, ''::text)) || chr(9)) || coalesce(subs_activation_dt::text, ''::text)) || chr(9)) || coalesce(subs_cancellation_dt::text, ''::text)) || chr(9)) || coalesce(start_date::text, ''::text)) || chr(9)) || coalesce(end_date::text, ''::text)) || chr(9)) ) as md5
		from 
		  edw_dds.dim_subs_1_prt_p000124
		where
		  date_trunc('day', exp_dttm) = to_date('29991231', 'yyyymmdd')
		  and src_id = 000124 ;

		ANALYZE edw_stg_ads.dim_subs_1_prt_p000124;
	