/*rev.58232 от 20.05.2020 */ /*Корректировки начислений*/

truncate edw_stg_dds.t_000107_tfct_adjust;
insert into edw_stg_dds.t_000107_tfct_adjust 
    (adjust_key
	, adjust_type_key
	, subs_key
	, account_key
	, service_key
	, payment_key
	, bill_detail_key
	, contract_key
	, vat_rub
	, adjust_amt
	, adjust_dttm
	, corr_billing_id
	, src_id
	, load_dttm
	, eff_dttm
	, exp_dttm
	, rc_key
	, billing_dttm)
SELECT 
    adjust_key
	, adjust_type_key
	, subs_key
	, src_id||'#'||account_key as account_key
	, service_key
	, payment_key
	, bill_detail_key
	, contract_key
	, vat_rub
	, adjust_amt
	, adjust_dttm
	, corr_billing_id
	, src_id
	, load_dttm
	, eff_dttm
	, exp_dttm
	, rc_key
	, billing_dttm
from (       	  
select  
	 '1#'||tsc.corr_id::text as adjust_key                   -- Идентификатор корректировки
	 ,coalesce(tsc.error_billing_id,to_char(cdate,'YYYYMM')::numeric, tsc.billing_id) as corr_billing_id -- Идентификатор корректируемого периода
    ,cdate as adjust_dttm   -- Дата создания корректировки
    ,tsc.user_id as account_key                    	-- Идентификатор лицевого счета
	,tsc.svc_id::text as service_key
	,-1 as payment_key                      	-- Идентификатор платежа
	,tsc.billing_id::text ||'#'|| LPAD (TRIM (u.account), 12, '0') as bill_key -- Идентификатор счета
    ,coalesce('1'||'#'|| tsc.reason_id,'1') as adjust_type_key             -- Идентификатор типа корректировки
    ,decode(tsc.svc_corr_type::numeric,1,-1,2,-1,1) * (tsc.summ - tsc.tax) as adjust_amt  -- Сумма корректировки в рублях, без НДС
    ,decode(tsc.svc_corr_type::numeric,1,-1,2,-1,1) * tsc.tax as vat_rub         -- Сумма НДС, руб.
    ,(
      select CASE WHEN 
       ROW_NUMBER () OVER (
            PARTITION BY o_contract.user_id
                           ORDER BY DECODE (t_sub_contract.vndr_contract_id, t_sub_contract.contract_id, 1, 2), t_sub_contract.vndr_contract_id
            ) = 1
                 THEN  o_contract.contract_id
                 ELSE  t_sub_contract.vndr_contract_id
            END
    ) as contract_key                       -- Идентификатор договора
    ,cpa_charge.charge_id as bill_detail_key --Идентификатор Детали счета            
    ,u.user_id::text||'#'||coalesce(tsc.phone,'0') as service_start_data_key
    ,dim_subs.subs_key as subs_key
    ,ROW_NUMBER() OVER 
      (partition by tsc.corr_id order by case 
      when (xref.sub_make=1 and tsc.service_id::text = dim_subs.service_id)  then 1
               when (xref.sub_make=0 and (tsc.phone=dim_subs.dev_id) and et.technology_type_key=dim_subs.technology_type_key) then 2
               when (xref.sub_make=0 and (tsc.phone=dim_subs.dev_id)) then 3
               when (xref.sub_make=0) then 4
               else 99999
               end asc) as key1 -- ключ уникальности начисления 
    ,cast('19000101' as timestamp(0) without time zone) as start_date
	,cast('29991231' as timestamp(0) without time zone) as end_date
	,000107 as src_id
	,now() as load_dttm
	,cast('19000101' as timestamp(0) without time zone) as eff_dttm
	,cast('29991231' as timestamp(0) without time zone) as exp_dttm
																				
																			  
	,case when coalesce(tsc.vnd_id,1) in (1,2,18,20,21,22,23,25,26,27,28,29,43,44,45,46,47,48,49) then 1 else 0 end as VND
	,case 	when tsc.svc_id::text in ('110503','5441','106787','105129','105128','116326','116327','116328','116329','116330','116331','116332','4889','7311','5767','115686','115687','1620','4890','5979','5990','108310','109838','1954')
			then '1'||'#'||tsc.svc_id::text
          --else '2'||'#'||dim_partner.segment_key
		else coalesce(rt.service_rtk_detail_code||'#'||soo.soogu_group_id,'-1')											
    end as rc_key
	,to_date(trunc(tsc.billing_id)::text,'yyyymm') billing_dttm
	
from (select * from edw_ods.t_000107_t_svc_correction tsc 
       where tsc.billing_id <> coalesce(tsc.error_billing_id,to_char(cdate,'YYYYMM')::numeric, tsc.billing_id) 
	   and tsc.billing_id between substr('20190601', 1, 6)::int and substr('20190630', 1, 6)::int
						  
       ) tsc
    JOIN edw_stg_dds.t_000107_dim_partner dim_partner ON tsc.user_id::text = dim_partner.partner_key and  to_date(tsc.billing_id::text,'YYYYMM') + INTERVAL '1 MONTH - 1 day' between dim_partner.eff_dttm and dim_partner.exp_dttm 
	
	LEFT JOIN edw_ods.t_000107_t_soogu soo 
		ON dim_partner.segment_key = soo.soogu_id::text 	
		and to_date('20190630', 'YYYYMMDD') + INTERVAL '1 day - 1 second' + interval '7 days' 
			between soo.eff_dttm and soo.exp_dttm
	
    LEFT JOIN   edw_ods.t_000107_t_users u 
        on u.user_id = tsc.user_id and u.DELETED_IND <> 1
		and to_date('20190630', 'YYYYMMDD') + INTERVAL '1 day - 1 second' + interval '7 days' 
			between u.eff_dttm and u.exp_dttm
        
   -- left join  edw_stg_dds.v_dim_services_xref_dv ss 
   --      on tsc.svc_id  = ss.svc_id and to_date(ss.exp_dttm, 'YYYY-MM-DD') = '2999-12-31'   
	left join edw_stg_dds.t_dim_service_xref_start xref
		on xref.source_key = tsc.svc_id::text  
		and to_date('20190601','YYYYMMDD') + INTERVAL '1 MONTH - 1 second' between xref.eff_dttm and xref.exp_dttm
		and xref.region_id = 'DV'
	left join edw_dds.dim_service et
		on et.service_key = xref.service_key
		and to_date('20190601','YYYYMMDD') + INTERVAL '1 MONTH - 1 second' between et.eff_dttm and et.exp_dttm	
	LEFT JOIN edw_dds.dim_service_rtk_detail rt 
		ON  rt.service_rtk_detail_key = et.service_rtk_detail_key 
		and to_date('20190601','YYYYMMDD') + INTERVAL '1 MONTH - 1 second' between rt.eff_dttm and rt.exp_dttm		
    left join   edw_ods.t_000107_cpa_charge cpa_charge
        on cpa_charge.bid = tsc.billing_id 
        and cpa_charge.user_id = tsc.user_id 
        and cpa_charge.svc_id = tsc.svc_id 
         
    left join  edw_ods.t_000107_o_contract  o_contract   
        on o_contract.user_id = tsc.user_id and o_contract.DELETED_IND <> 1
		and to_date('20190630', 'YYYYMMDD') + INTERVAL '1 day - 1 second' 
			between o_contract.eff_dttm and o_contract.exp_dttm
        
    left join edw_ods.t_000107_t_sub_contract t_sub_contract  
        on t_sub_contract.contract_id = o_contract.contract_id and t_sub_contract.DELETED_IND <> 1
		and to_date('20190630', 'YYYYMMDD') + INTERVAL '1 day - 1 second' 
			between t_sub_contract.eff_dttm and t_sub_contract.exp_dttm		
   
    left join  (
         select dim_subs.service_id,dim_subs.subs_key, dim_subs.account_key,dim_subs.subs_code as dev_id,dim_subs.start_date,dim_subs.end_date,et.business_service_key ,et.technology_type_key
         from edw_stg_dds.t_000107_dim_subs dim_subs
       --  left join edw_stg_dds.v_dim_services_xref_dv ss
        -- on dim_subs.service_key= ss.svc_id::text and cast(ss.exp_dttm as date) = to_date('2999-12-31', 'YYYY-MM-DD')
		left join edw_stg_dds.t_dim_service_xref_start xref
			on xref.source_key = dim_subs.service_key  
				and to_date('20190601','YYYYMMDD') + INTERVAL '1 MONTH - 1 second' between xref.eff_dttm and xref.exp_dttm
				and xref.region_id = 'DV'
		left join edw_dds.dim_service et
			on et.service_key = xref.service_key
			and to_date('20190601','YYYYMMDD') + INTERVAL '1 MONTH - 1 second' between et.eff_dttm and et.exp_dttm	
		
            ) dim_subs        
        on tsc.src_id::text||'#'||tsc.user_id::text = dim_subs.account_key            
               and et.business_service_key  = dim_subs.business_service_key 
        and date_trunc('month',to_date(coalesce(tsc.error_billing_id,billing_id)::text,'YYYYMM')) between date_trunc('month',dim_subs.start_date) and date_trunc('month',dim_subs.end_date)        
) s
where s.key1=1 and s.VND = 1;
commit;

/*Корректировки платежей*/
insert into edw_stg_dds.t_000107_tfct_adjust
	(adjust_key
	, adjust_type_key
	, subs_key
	, account_key
	, service_key
	, payment_key
	, bill_detail_key
	, contract_key
	, vat_rub
	, adjust_amt
	, adjust_dttm
	, corr_billing_id
	, src_id
	, load_dttm
	, eff_dttm
	, exp_dttm
	, billing_dttm
	)
SELECT 
    adjust_key
	, adjust_type_key
	, subs_key
	, src_id||'#'||account_key as account_key
	, service_key
	, payment_key
	, bill_detail_key
	, contract_key
	, vat_rub
	, adjust_amt
	, adjust_dttm
	, corr_billing_id
	, src_id
	, load_dttm
	, eff_dttm
	, exp_dttm
	, billing_dttm
  FROM(	
SELECT  	'2#'||t_pay_correction.pay_corr_id||'#'||t_pay_correction.User_id as adjust_key -- Идентификатор корректировки 
		,coalesce(t_pay_correction.error_billing_id,to_char(pay_date,'YYYYMM')::numeric, t_pay_correction.billing_id) as corr_billing_ID -- Идентификатор корректируемого периода
		,t_pay_correction.corr_date as adjust_dttm -- Дата создания корректировки
	  	,coalesce('2'||'#'||t_pay_correction.reason_id, '2') as adjust_type_key -- Идентификатор типа корректировки
	  	,-1 as subs_key                     -- Идентификатор Абонента
	  	,-1 as service_key
	  	,t_pay_correction.User_id as account_key -- Идентификатор лицевого счета
	  	,t_pay_correction.payment_id as payment_key -- Идентификатор платежа
	  	,-1 as bill_key -- Идентификатор счета
	  	,-1 as bill_detail_key --Идентификатор Детали счета
	  	,-1 as contract_key -- Идентификатор договора
	  	,(decode(t_pay_correction.pay_corr_type::numeric,1,-1,2,-1,1)*t_pay_correction.summ)*(0.2/(1+0.2)) as vat_rub -- Сумма НДС, руб.
		,(decode(t_pay_correction.pay_corr_type::numeric,1,-1,2,-1,1)*t_pay_correction.summ)*(1/(1+0.2)) as adjust_amt-- Сумма корректировки в рублях, без НДС 
	  	,000107 as src_id
	  	,now() as load_dttm
		,cast('19000101' as timestamp(0) without time zone) as eff_dttm
		,cast('29991231' as timestamp(0) without time zone) as exp_dttm
		,cast('19000101' as timestamp(0) without time zone) as start_date
		,cast('29991231' as timestamp(0) without time zone) as end_date	
		,to_date(trunc(t_pay_correction.billing_id)::text,'yyyymm') as billing_dttm
FROM	(select * from edw_ods.t_000107_t_pay_correction t_pay_correction
       	where t_pay_correction.billing_id between substr('20190601', 1, 6)::int and substr('20190630', 1, 6)::int
     	) t_pay_correction
)sss;
commit;
analyze edw_stg_dds.t_000107_tfct_adjust;