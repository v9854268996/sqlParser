/*rev.38458 26.11.2019*/
truncate table edw_stg_dds.t_000030_tfct_telephony_consumption;
insert into edw_stg_dds.t_000030_tfct_telephony_consumption
  (
  telephony_consumption_key
  , call_start_dttm
  , subs_key
  , service_key
  , account_key
  , rc_key
  , billing_id
  , call_dur_paid_nval
  , num_a
  , is_vims
  , src_id
  , eff_dttm
  , exp_dttm)

SELECT tservnach.src_id||';'||tservnach.dfservnach::numeric(38) as telephony_consumption_key
  , tperioddfdatebegin as call_start_dttm
  , tservnach.src_id||';'||tservnach.dfservconst::numeric(38) as subs_key
  , tservnach.src_id||';'||tservnach.dfservice::numeric(38) as service_key
  , tservnach.src_id||';'||tservnach.dfdogovor::numeric(38) as account_key
  , coalesce(tdopcs.dfcfo_segment,'-1') as rc_key
  , to_date(to_char(tperioddfdatebegin,'YYYYMMDD'),'YYYYMMDD') as billing_id
  , tservnach.dfcount*60 as call_dur_paid_nval
  --Получение 10-значного номера
  , decode(length(dftel_a),10,dftel_a,11,dftel_a,
      (SELECT (ARRAY_AGG(us.dfmagistral_cod||us.dfzona_a||SUBSTRING(ttrafday.DFTEL_A,'.{'||10-LENGTH(us.dfmagistral_cod)-LENGTH(us.dfzona_a)||'}$')
      ORDER BY length(us.dfzona_a) desc))[1]
        FROM edw_ods.t_000030_tunipay_link_server us
        WHERE us.dfzona_convert = ttrafday.DFZONA_A
        AND ttrafday.DFTEL_A LIKE coalesce(us.dfprefix,'') || '%'
        AND LENGTH(ttrafday.DFTEL_A) = us.dflength_phone::numeric(38) + COALESCE(LENGTH(us.dfprefix), 0)
        AND us.dfmagistral_cod = reg.dfregion_a
        AND SUBSTRING(ttrafday.DFTEL_A, 1 + COALESCE(LENGTH(us.dfprefix), 0) + decode(length(ttrafday.DFTEL_A),10,3,0)) LIKE
              SUBSTRING(us.dfzona_a, 1 + decode(length(ttrafday.DFTEL_A),10,0,(10 - LENGTH(us.dfmagistral_cod) - us.dflength_phone::int))) || '%'
        AND (us.dfdatebegin IS NULL OR us.dfdatebegin <= current_date)
        AND (us.dfdateend IS NULL OR current_date IS NULL OR us.dfdateend >= current_date))) as num_a
        and to_date('20190630', 'YYYYMMDD') + INTERVAL '1 day - 1 second'  between us.eff_dttm and us.exp_dttm
  , null is_vims
  , tservnach.src_id
  , to_timestamp('19000101', 'YYYYMMDD') as EFF_DTTM
  , to_timestamp('29991231', 'YYYYMMDD') as EXP_DTTM
  --, 19000101::timestamp as EFF_DTTM
  --, 29991231::timestamp as EXP_DTTM
FROM edw_ods.t_000030_tservnach tservnach
join edw_ods.t_000030_tdogovor tdogovor on tservnach.dfdogovor=tdogovor.dfdogovor and to_date('20190630', 'YYYYMMDD') + INTERVAL '1 day - 1 second'  between tdogovor.eff_dttm and tdogovor.exp_dttm
join (SELECT
          td.dfservnach
      , dftel_a
    , dfzona_a --Получение 10-значного номера
    , SUM (td.dfdlt) AS dfdlt
      FROM edw_ods.t_000030_ttrafday td
      GROUP BY td.dfservnach
      , dftel_a
    , dfzona_a
      ) ttrafday
  on ttrafday.dfservnach = tservnach.dftimeconversation
left join edw_ods.t_000030_TDOG_CFO_SEGMENT tdogcs
  on tdogcs.DFDOGOVOR=tservnach.dfdogovor
  and tperioddfdatebegin between tdogcs.dfdatebegin and coalesce(tdogcs.dfdateend,to_timestamp('29991231', 'YYYYMMDD'))
  and tdogcs.deleted_ind=0
  and to_date('20190630', 'YYYYMMDD') + INTERVAL '1 day - 1 second'  between tdogcs.eff_dttm and tdogcs.exp_dttm
left join edw_ods.t_000030_TDOP_CFO_SEGMENT tdopcs
  on tdogcs.DFDOP_CFO_SEGMENT = tdopcs.DFDOP_CFO_SEGMENT and tdopcs.deleted_ind=0
  and to_date('20190630', 'YYYYMMDD') + INTERVAL '1 day - 1 second'  between tdopcs.eff_dttm and tdopcs.exp_dttm
left join edw_ods.t_000030_tservconst sc on sc.dfservconst = tservnach.DFservconst--Получение 10-значного номера
  and to_date('20190630', 'YYYYMMDD') + INTERVAL '1 day - 1 second'  between sc.eff_dttm and sc.exp_dttm
left join edw_ods.t_000030_tdogovor d on d.dfdogovor = sc.dfdogovor--Получение 10-значного номера
  and to_date('20190630', 'YYYYMMDD') + INTERVAL '1 day - 1 second'  between d.eff_dttm and d.exp_dttm
left join (select
        adt.dfvarchar2 as dfregion_a,
        adt.dfid -- DFLINEPARTGROUP
        from
        edw_ods.t_000030_taddtype t,
        edw_ods.t_000030_tadddata adt
        where t.dfname = 'DFREGION_A'
          and t.dftable = 'TLINEPARTGROUP'
          and t.dfaddtype = adt.dfaddtype
          and coalesce(adt.dfdelete,'F')='F'
          and current_date between coalesce(adt.dfdatebegin,current_date) and coalesce(adt.dfdateend,current_date)
        and to_date('20190630', 'YYYYMMDD') + INTERVAL '1 day - 1 second'  between t.eff_dttm and t.exp_dttm
        and to_date('20190630', 'YYYYMMDD') + INTERVAL '1 day - 1 second'  between adt.eff_dttm and adt.exp_dttm
      )reg on reg.dfid=d.dflinepartgroup --получение 10-значного номера
WHERE  date_trunc('DAY', tservnach.tperioddfdatebegin) between to_date('20190601', 'YYYYMMDD') and to_date('20190630', 'YYYYMMDD');
commit;
analyze edw_stg_dds.t_000030_tfct_telephony_consumption;

truncate edw_stg_dds.t_000030_tfct_telephony_consumption_stg_1_tservnach;
insert into edw_stg_dds.t_000030_tfct_telephony_consumption_stg_1_tservnach
  select
    a.dfservnach
  , d.dfbranch
  , d.dflinepartgroup
  , a.dfperiod
  , a.dfdogovor
  , a.dfservice
  , a.dfservtarif
  , a.dfcena
  , a.dfcount
  , a.dfsumma
  , a.dfdatebegin
  , a.dfdateend
  , a.dfperegovor
  , a.dfservconst
  , a.dfonenach
  , a.dftimeconversation
  , a.dfoplata
  , a.dfperiodper
  , a.dfpack
  , a.dfndsinout
  , a.dfndssumma
  , a.dfndspercent
  , a.dfnspsumma
  , a.dfnsppercent
  , a.dfperegdopserv
  , a.df06telegr
  , a.dfpriveleg
  , a.dfprivpercent
  , a.dfprivpercentnach
  , p.dftape
  , P.dfvector
  , p.dfzona
  , p.dfdatetime
  , p.dfzona_a
  , p.dfzona_b
  , p.dftel_b
  , p.dfdlt
  , p.dfkategor
  , p.dfspeaktype
  , p.dfauto
  , a.DFSERVNACHMASTER
  , n.dfpacket_id
  , n.dfcount_info
  , n.dfonyma_name
FROM edw_ods.t_000030_tservnach a
left join edw_ods.t_000030_tonenach n
  on n.dfonenach = a.dfonenach
left join edw_ods.t_000030_tperegovor p
  on p.dfperegovor = a.dfperegovor
join edw_ods.t_000030_tdogovor d
  on d.dfdogovor= a.dfdogovor
  and to_date('20190630', 'YYYYMMDD') + INTERVAL '1 day - 1 second'  between d.eff_dttm and d.exp_dttm
WHERE date_trunc('DAY', a.tperioddfdatebegin) between to_date('20190601', 'YYYYMMDD') and to_date('20190630', 'YYYYMMDD');
commit;
analyze edw_stg_dds.t_000030_tfct_telephony_consumption_stg_1_tservnach;


truncate table edw_stg_dds.t_000030_tfct_telephony_consumption_stg_2_tpereg;
insert into edw_stg_dds.t_000030_tfct_telephony_consumption_stg_2_tpereg
SELECT
    dfperiod
  , dfbranch
  , dflinepartgroup
  , dfactivity
  , dfperiodper
  , dfdevice
  , dfservice
  , dfvector
  , dfspeaktype
  , dfzona
  , dfperegday
  , dfservtarif
  , dfzona_a
  , dfzona_b
  , dfdop_uslugi
  , sum(dfcount_all) dfcount_all
  , sum(dfdlt_all_nach) dfdlt_all_nach
  , sum(dfdlt_all_pereg) dfdlt_all_pereg
  , sum(dfcount_null_sum) dfcount_null_sum
  , sum(dfdlt_null_sum_nach) dfdlt_null_sum_nach
  , sum(dfdlt_null_sum_pereg) dfdlt_null_sum_pereg
  , sum(dfsumma_bez_nds) dfsumma_bez_nds
  , sum(dfsumma_nds) dfsumma_nds
  , sum(dfsumma_s_nds) dfsumma_s_nds
  , dfpercent_nds
  , dfauto
  , dfcena
  , sum(dfdlt_all_pereg_sec) dfdlt_all_pereg_sec
  , sum(dfdlt_null_sum_pereg_sec) dfdlt_null_sum_pereg_sec
  , dfkateg
  , dfprivpercent
  , dfsum_privpercentnach
  , dfdev_auto
  , dfdev_ats
  , dftapetype
  , dfperegovor
  , dfdogovor
  , dfservconst
FROM(

  SELECT
    sn.dfperiod
    , d.dfbranch
    , d.dflinepartgroup
    , d.dfactivity
    , sn.dfperiodper
    , coalesce (sc.dfdevice, -1) dfdevice
    , sn.dfservice
    , sn.dfvector
    , sn.dfspeaktype
    , sn.dfzona
    , CASE WHEN sn.dfdatetime< pd.dfdatebegin THEN DATE_TRUNC ('month',sn.dfdatetime) else DATE_TRUNC ('day',sn.dfdatetime) end dfperegday
    , sn.dfservtarif
    , TRIM (sn.dfzona_a) dfzona_a
    , TRIM (sn.dfzona_b) dfzona_b
    , DECODE (sn.dfperegdopserv, NULL,'F','T') dfdop_uslugi
    , SIGN (sn.dfcount + 0.1) dfcount_all
    , sn.dfcount dfdlt_all_nach
    , SIGN (sn.dfcount)* CEIL (DECODE (tt.dftimeunit, 'MI', sn.dfdlt * 60, sn.dfdlt) / 60) dfdlt_all_pereg
    , DECODE (coalesce (sn.dfsumma, 0), 0, SIGN (sn.dfcount + 0.1), 0) dfcount_null_sum
    , DECODE (coalesce (sn.dfsumma, 0), 0, sn.dfcount, 0) dfdlt_null_sum_nach
    , SIGN (sn.dfcount) * CEIL (  DECODE (coalesce (sn.dfsumma, 0),0, (DECODE (tt.dftimeunit,'MI', sn.dfdlt * 60, sn.dfdlt)),0) / 60) dfdlt_null_sum_pereg
    , sn.dfsumma - DECODE (sn.dfndsinout, 'T', coalesce (sn.dfndssumma, 0), 0) dfsumma_bez_nds
    , coalesce (sn.dfndssumma, 0) dfsumma_nds
    , sn.dfsumma + DECODE (sn.dfndsinout, 'F', coalesce (sn.dfndssumma, 0), 0) dfsumma_s_nds
    , sn.dfndspercent dfpercent_nds
    , coalesce (sn.dfauto, 'T') dfauto
    , sn.dfcena
    , SIGN (sn.dfcount) * DECODE (tt.dftimeunit, 'MI', sn.dfdlt * 60, sn.dfdlt) dfdlt_all_pereg_sec
    , SIGN (sn.dfcount) * DECODE (coalesce(sn.dfsumma,0), 0, (DECODE (tt.dftimeunit,'MI', sn.dfdlt * 60, sn.dfdlt)), 0) dfdlt_null_sum_pereg_sec
    , sn.dfkategor dfkateg
    , sn.dfprivpercent
    , sn.dfprivpercentnach dfsum_privpercentnach
    , decode(coalesce(trim(dev.dfauto),'T'),'B','B','F','F','M','M','T') dfdev_auto
    , null dfdev_ats
    , t.dftapetype
    , sn.dfperegovor
    , sn.dfdogovor
    , sn.dfservconst
    FROM (
         SELECT
          t2.dfservnach
        , t2.dfbranch
        , t2.dflinepartgroup
        , t2.dfperiod
        , t2.dfdogovor
        , t2.dfservice
        , t2.dfservtarif
        , t2.dfcena
        , t1.dfcount
        , t1.dfsumma
        , t2.dfdatebegin
        , t2.dfdateend
        , t2.dfperegovor
        , t2.dfservconst
        , t2.dfonenach
        , t2.dftimeconversation
        , t2.dfoplata
        , t2.dfperiodper
        , t2.dfpack
        , t2.dfndsinout
        , t1.dfndssumma
        , t2.dfndspercent
        , t1.dfnspsumma
        , t1.dfnsppercent
        , t2.dfperegdopserv
        , t2.df06telegr
        , t2.dfpriveleg
        , t2.dfprivpercent
        , t2.dfprivpercentnach
        , t2.dftape
        , t2.dfvector
        , t2.dfzona
        , t2.dfdatetime
        , t2.dfzona_a
        , t2.dfzona_b
        , t2.dftel_b
        , t1.dfdlt
        , t2.dfkategor
        , t2.dfspeaktype
        , t2.dfauto
        , t2.dfservnachmaster
        , t2.dfpacket_id
        , t2.dfpacket_id
        , t2.dfcount_info
        , t2.dfonyma_name
         FROM(
              SELECT ts1.*
               FROM edw_stg_dds.t_000030_tfct_telephony_consumption_stg_1_tservnach ts1
               left join edw_stg_dds.t_000030_tfct_telephony_consumption_stg_1_tservnach ts2
           on ts1.dfservnach=ts2.dfservnachmaster
               left join edw_stg_dds.t_000030_tfct_telephony_consumption_stg_1_tservnach ts3
           on ts1.dfservnachmaster=ts3.dfservnach
              WHERE (ts2.dfservnachmaster is null and ts3.dfservnach is null)
                and ts1.dfperegovor is not null)t1
         left join (
                SELECT *
            FROM(
                 SELECT *
                 FROM (
                     SELECT *
                         , row_number() over(partition by dfperegovor order by dfservnach desc) as rn
                                     FROM(
                        SELECT ts1.*
                          FROM edw_stg_dds.t_000030_tfct_telephony_consumption_stg_1_tservnach ts1
                        left join edw_stg_dds.t_000030_tfct_telephony_consumption_stg_1_tservnach ts2
                        on ts1.dfservnach=ts2.dfservnachmaster
                        left join edw_stg_dds.t_000030_tfct_telephony_consumption_stg_1_tservnach ts3
                        on ts1.dfservnachmaster=ts3.dfservnach
                         WHERE (ts2.dfservnachmaster is null and ts3.dfservnach is null)
                       and ts1.dfperegovor is not null and ts1.dfcount>=0
                       )t
                  )t where rn=1
               ) t
           )t2
       on t1.dfperegovor=t2.dfperegovor) sn
         join edw_ods.t_000030_ttape t
       on t.dftape = sn.dftape
         left join edw_ods.t_000030_tservconst sc
       on sc.dfservconst = sn.dfservconst
       and to_date('20190630', 'YYYYMMDD') + INTERVAL '1 day - 1 second'  between sc.eff_dttm and sc.exp_dttm
         left join edw_ods.t_000030_tdevvolume dev
       on dev.dfdevvolume = sc.dfdevvolume
       and dev.Active_ind = 'Y'
         join edw_ods.t_000030_ttapetype tt
       on tt.dftapetype = t.dftapetype
       and to_date('20190630', 'YYYYMMDD') + INTERVAL '1 day - 1 second'  between tt.eff_dttm and tt.exp_dttm
         join edw_ods.t_000030_tdogovor d
       on d.dfdogovor = sn.dfdogovor
       and to_date('20190630', 'YYYYMMDD') + INTERVAL '1 day - 1 second'  between d.eff_dttm and d.exp_dttm
         join edw_ods.t_000030_tperiod pd
       on pd.dfperiod = sn.dfperiod
       and to_date('20190630', 'YYYYMMDD') + INTERVAL '1 day - 1 second'  between pd.eff_dttm and pd.exp_dttm
       )t
  group by
          dfperiod
      , dfbranch
      , dflinepartgroup
      , dfactivity
      , dfperiodper
      , dfdevice
      , dfservice
      , dfvector
      , dfspeaktype
      , dfzona
      , dfperegday
      , dfservtarif
      , dfzona_a
      , dfzona_b
      , dfdop_uslugi
      , dfpercent_nds
      , dfauto
      , dfcena
      , dfkateg
      , dfprivpercent
      , dfsum_privpercentnach
      , dfdev_auto
      , dfdev_ats
      , dftapetype
      , dfperegovor
      , dfdogovor
      , dfservconst;
commit;
analyze edw_stg_dds.t_000030_tfct_telephony_consumption_stg_2_tpereg;

--МГМН--
insert into edw_stg_dds.t_000030_tfct_telephony_consumption
     (
   telephony_consumption_key
   , call_start_dttm
   , subs_key
   , service_key
   , account_key
   , rc_key
   , mobile_flg
   , billing_id
   , call_dur_rounded_nval
   , call_dur_actually_nval
   , call_dur_paid_nval
   , charge_rub
   , num_a
   , num_b
   , is_vims
   , src_id
   , eff_dttm
   , exp_dttm)
SELECT
     consumption_telephony_services_key
     , call_start_dttm
     , subs_key
     , service_key
     , account_key
     , coalesce(tdopcs.dfcfo_segment,'-1') as rc_key
   , mobile_flg
     , billing_id
     , call_dur_rounded_nval
     , call_dur_actually_nval
     , call_dur_paid_nval
     , charge_rub
     , dftel_a
     , dftel_b
   , null is_vims
     , pc.src_id
     , eff_dttm
     , exp_dttm
FROM(
   SELECT
    a.src_id||';'||a.dfperegovor::numeric(38) as consumption_telephony_services_key
   , a.dfperegday as call_start_dttm
   , a.src_id||';'||a.dfservconst::numeric(38) as subs_key
   , a.src_id||';'||a.dfservice::numeric(38) as service_key
   , a.src_id||';'||a.dfdogovor::numeric(38) as account_key
   , a.mobile_flg
   , to_date(to_char(a.tperioddfdatebegin,'YYYYMMDD'),'YYYYMMDD') as billing_id
   , coalesce(a.dlt, 0)*60  as call_dur_rounded_nval
   , coalesce(a.unround_dlt, 0)      call_dur_actually_nval
   , coalesce(a.dlt, 0)*60      call_dur_paid_nval
   , a.summa_bez_nds as charge_rub
   , decode(length(dftel_a),10,dftel_a,11,dftel_a,dftel_a10) as dftel_a
   , dftel_b
   , a.src_id
   , to_timestamp('19000101', 'YYYYMMDD') as EFF_DTTM
   , to_timestamp('29991231', 'YYYYMMDD') as EXP_DTTM
   --, 19000101::timestamp as eff_dttm
   --, 29991231::timestamp as exp_dttm
   FROM(
       SELECT l1.dflinepartgroup, l1.dfname
         FROM edw_ods.t_000030_tlinepartgroup l1
         left join (
                SELECT
                        coalesce (dfvarchar2, coalesce (dfboolean, 'F')) as varchar1
                        , dfid
                      FROM edw_ods.t_000030_tadddata
                     WHERE dfaddtype IN (
                                         SELECT dfaddtype
                                           FROM edw_ods.t_000030_taddtype
                                          WHERE UPPER(dftable) = 'TLINEPARTGROUP'
                                            AND UPPER(dfname) = 'DFLPGSPEC'
                      and to_date('20190630', 'YYYYMMDD') + INTERVAL '1 day - 1 second'  between eff_dttm and exp_dttm
                      )
                       AND coalesce (dfdelete, 'F') <> 'T'
             and to_date('20190630', 'YYYYMMDD') + INTERVAL '1 day - 1 second'  between eff_dttm and exp_dttm
                    ) varchar1
         on varchar1.dfid = dflinepartgroup
         left join (
                    SELECT
                        case when dfboolean is null and (LENGTH(dfVARCHAR2)=1) AND (upper(dfVARCHAR2)='T' OR upper(dfVARCHAR2)='F')
                             then upper(dfVARCHAR2)
                             else 'F' end as bool1
              , dfid
                      FROM edw_ods.t_000030_tadddata
                     WHERE dfaddtype IN (
                                         SELECT dfaddtype
                                           FROM edw_ods.t_000030_taddtype
                                          WHERE UPPER(dftable) = 'TLINEPARTGROUP'
                                            AND UPPER(dfname) = 'DFLPG_TEST'
                      and to_date('20190630', 'YYYYMMDD') + INTERVAL '1 day - 1 second'  between eff_dttm and exp_dttm
                      )
          and to_date('20190630', 'YYYYMMDD') + INTERVAL '1 day - 1 second'  between eff_dttm and exp_dttm
                    ) bool1
       on bool1.dfid = dflinepartgroup
         left join (
                    SELECT
                        coalesce (dfvarchar2, coalesce (dfboolean, 'F')) as varchar2
                        , dfid
                      FROM edw_ods.t_000030_tadddata
                     WHERE dfaddtype IN (
                                         SELECT dfaddtype
                                           FROM edw_ods.t_000030_taddtype
                                          WHERE UPPER(dftable) = 'TLINEPARTGROUP'
                                            AND UPPER(dfname) = 'DFLPG_STK'
                      and to_date('20190630', 'YYYYMMDD') + INTERVAL '1 day - 1 second'  between eff_dttm and exp_dttm
                    )
                       and coalesce (dfdelete, 'F') <> 'T'
             and to_date('20190630', 'YYYYMMDD') + INTERVAL '1 day - 1 second'  between eff_dttm and exp_dttm
                   ) varch2
         on varch2.dfid = dflinepartgroup
         left join (
                SELECT
                        dfnumber as numb1
            , dfid
                      FROM edw_ods.t_000030_tadddata
                     WHERE dfaddtype IN (
                                         SELECT dfaddtype
                                           FROM edw_ods.t_000030_taddtype
                                          WHERE UPPER(dftable) = 'TLINEPARTGROUP'
                                            AND UPPER(dfname) = 'DOPER_LONG'
                      and to_date('20190630', 'YYYYMMDD') + INTERVAL '1 day - 1 second'  between eff_dttm and exp_dttm
                    )
                       and coalesce (dfdelete, 'F') <> 'T'
             and to_date('20190630', 'YYYYMMDD') + INTERVAL '1 day - 1 second'  between eff_dttm and exp_dttm
                   ) numb1
       on numb1.dfid = dflinepartgroup
     WHERE coalesce(varchar1,'F')='F'
       and coalesce(bool1,'F')='F'
     and  coalesce(varchar2,'F')='F'
     and  coalesce(numb1,1) IN (1,2)
     and to_date('20190630', 'YYYYMMDD') + INTERVAL '1 day - 1 second'  between l1.eff_dttm and l1.exp_dttm
       ) lin
   join (
         SELECT
         sn.dfperegovor
       , sp.dfname sp_name
       , ac.dfname act_name
       , z1.dfip_peregovor dfip
       , sn.dfdop_uslugi dfdop
       , sn.DFZONA_B
       , z1.dfname zona_type
       , sn.dflinepartgroup
       , sn.dfvector
       , sn.dfperegday
       , sn.dfzona
       , z1.dfoutcountry
       , z1.dfmagistral
       , z1.dfadd2
       , zz.dfname zona_name
       , tp.DFTEL_A
       --Получение 10-значного номера
       , (SELECT (ARRAY_AGG(us.dfmagistral_cod||us.dfzona_a||SUBSTRING(tp.DFTEL_A,'.{'||10-LENGTH(us.dfmagistral_cod)-LENGTH(us.dfzona_a)||'}$')
        ORDER BY length(us.dfzona_a) desc))[1]
          FROM edw_ods.t_000030_tunipay_link_server us
          WHERE us.dfzona_convert = sn.DFZONA_A
          AND tp.DFTEL_A LIKE coalesce(us.dfprefix,'') || '%'
          AND LENGTH(tp.DFTEL_A) = us.dflength_phone::numeric(38) + COALESCE(LENGTH(us.dfprefix), 0)
          AND us.dfmagistral_cod = reg.dfregion_a
          AND SUBSTRING(tp.DFTEL_A, 1 + COALESCE(LENGTH(us.dfprefix), 0) + decode(length(tp.DFTEL_A),10,3,0)) LIKE
              SUBSTRING(us.dfzona_a, 1 + decode(length(tp.DFTEL_A),10,0,(10 - LENGTH(us.dfmagistral_cod) - us.dflength_phone::int))) || '%'
          AND (us.dfdatebegin IS NULL OR us.dfdatebegin <= current_date)
          AND (us.dfdateend IS NULL OR current_date IS NULL OR us.dfdateend >= current_date)
          and to_date('20190630', 'YYYYMMDD') + INTERVAL '1 day - 1 second'  between us.eff_dttm and us.exp_dttm
          ) as DFTEL_A10
       , tp.DFTEL_B
       , sn.DFSERVCONST
       , sn.dfdogovor
       , tp.src_id
       , sn.dfservice
       , decode(sn.DFdop_uslugi,'T',0,SN.DFDLT_all_nach) dlt
       , decode(sn.DFdop_uslugi,'T',0,SN.dfdlt_all_pereg_sec) unround_dlt
       , tper.dfdatebegin as tperioddfdatebegin
       , SN.dfcount_all kolvo
       , sn.dfsumma_s_nds summa_s_nds
       , sn.dfsumma_bez_nds summa_bez_nds
       , case when coalesce(zz.dfnumber,'ABC')='DEF' then 'Y' end as mobile_flg
        FROM edw_stg_dds.t_000030_tfct_telephony_consumption_stg_2_tpereg SN
      join edw_ods.t_000030_tperegovor tp
        on tp.dfperegovor=sn.dfperegovor
      join edw_ods.t_000030_tperiod tper
        on tper.dfperiod=sn.dfperiod
      and to_date('20190630', 'YYYYMMDD') + INTERVAL '1 day - 1 second'  between tper.eff_dttm and tper.exp_dttm
      join edw_ods.t_000030_tactivity ac
        on ac.dfactivity= sn.dfactivity
      and to_date('20190630', 'YYYYMMDD') + INTERVAL '1 day - 1 second'  between ac.eff_dttm and ac.exp_dttm
      join edw_ods.t_000030_tSpeakType sp
        on sp.dfspeaktype=sn.dfspeaktype
      and to_date('20190630', 'YYYYMMDD') + INTERVAL '1 day - 1 second'  between sp.eff_dttm and sp.exp_dttm
      join edw_ods.t_000030_tzona zz
        on zz.dfzona = sn.dfzona
      and to_date('20190630', 'YYYYMMDD') + INTERVAL '1 day - 1 second'  between zz.eff_dttm and zz.exp_dttm
      join (
            SELECT
            zt.dfip_peregovor
          , zt.dfzona_add_type
          , zt.dfoutcountry
          , zt.dfmagistral
          , zt.dfadd2
          , zt.dfname
            FROM edw_ods.t_000030_tzona_add_type zt
         WHERE zt.DFPEREGOVOR='T'
           AND zt.DFINZONA='F'
           and to_date('20190630', 'YYYYMMDD') + INTERVAL '1 day - 1 second'  between zt.eff_dttm and zt.exp_dttm
        ) z1
      on z1.dfzona_add_type = zz.dfadditional
          left join (
             SELECT
                 case when dfboolean is null and (LENGTH(dfVARCHAR2)=1) AND (upper(dfVARCHAR2)='T' OR upper(dfVARCHAR2)='F')
                    then upper(dfVARCHAR2)
                      else 'F' end as bool2
             , dfid
               FROM edw_ods.t_000030_tadddata
              WHERE dfaddtype IN (
                      SELECT dfaddtype
                        FROM edw_ods.t_000030_taddtype
                       WHERE UPPER(dftable) = 'TLINEPARTGROUP'
                       AND UPPER(dfname) = 'DF_LPG_NOT_IN_REP_9208_B2C'
                       and to_date('20190630', 'YYYYMMDD') + INTERVAL '1 day - 1 second'  between eff_dttm and exp_dttm
                     )
            and to_date('20190630', 'YYYYMMDD') + INTERVAL '1 day - 1 second'  between eff_dttm and exp_dttm
          ) bool2
      on bool2.dfid = sn.dflinepartgroup
      left join (
                     SELECT
                         case when dfboolean is null and (LENGTH(dfVARCHAR2)=1) AND (upper(dfVARCHAR2)='T' OR upper(dfVARCHAR2)='F')
                              then upper(dfVARCHAR2)
                              else 'F' end as bool3
             , dfid
                       FROM edw_ods.t_000030_tadddata
                      WHERE dfaddtype IN (
                                          SELECT dfaddtype
                                            FROM edw_ods.t_000030_taddtype
                                           WHERE UPPER(dftable) = 'TLINEPARTGROUP'
                                             AND UPPER(dfname) = 'DF_LPG_NOT_IN_REP_9208_B2B'
                       and to_date('20190630', 'YYYYMMDD') + INTERVAL '1 day - 1 second'  between eff_dttm and exp_dttm
                     )
            and to_date('20190630', 'YYYYMMDD') + INTERVAL '1 day - 1 second'  between eff_dttm and exp_dttm
                    ) bool3
      on bool3.dfid = sn.dflinepartgroup
      left join edw_ods.t_000030_tservconst sc on sc.dfservconst = sn.DFservconst--Получение 10-значного номера
        and to_date('20190630', 'YYYYMMDD') + INTERVAL '1 day - 1 second'  between sc.eff_dttm and sc.exp_dttm
      left join edw_ods.t_000030_tdogovor d on d.dfdogovor = sc.dfdogovor --Получение 10-значного номера
        and to_date('20190630', 'YYYYMMDD') + INTERVAL '1 day - 1 second'  between d.eff_dttm and d.exp_dttm
      left join (select
        adt.dfvarchar2 as dfregion_a,
        adt.dfid -- DFLINEPARTGROUP
        from
        edw_ods.t_000030_taddtype t,
        edw_ods.t_000030_tadddata adt
        where t.dfname = 'DFREGION_A'
          and t.dftable = 'TLINEPARTGROUP'
          and t.dfaddtype = adt.dfaddtype
          and coalesce(adt.dfdelete,'F')='F'
          and current_date between coalesce(adt.dfdatebegin,current_date) and coalesce(adt.dfdateend,current_date)
        and to_date('20190630', 'YYYYMMDD') + INTERVAL '1 day - 1 second'  between t.eff_dttm and t.exp_dttm
        and to_date('20190630', 'YYYYMMDD') + INTERVAL '1 day - 1 second'  between adt.eff_dttm and adt.exp_dttm
      )reg on reg.dfid=d.dflinepartgroup --получение 10-значного номера
         WHERE sn.dfsumma_bez_nds>=0
           and upper(sn.dfdop_uslugi)='F'
           and upper(z1.dfname)!='МАГИСТРАЛЬНАЯ - ИСС'
           and ((23=ac.dfactivity AND coalesce(bool2,'F')='F') or (23<>ac.dfactivity AND coalesce(bool3,'F')='F'))
        )a
   on lin.dflinepartgroup=a.dflinepartgroup)pc
   left join edw_ods.t_000030_TDOG_CFO_SEGMENT tdogcs
   on tdogcs.src_id||';'||tdogcs.DFDOGOVOR::numeric(38)=pc.account_key
  and pc.call_start_dttm between tdogcs.dfdatebegin and coalesce(tdogcs.dfdateend,'29991231')
  and tdogcs.deleted_ind=0
  and to_date('20190630', 'YYYYMMDD') + INTERVAL '1 day - 1 second'  between tdogcs.eff_dttm and tdogcs.exp_dttm
   left join edw_ods.t_000030_TDOP_CFO_SEGMENT tdopcs
   on tdogcs.DFDOP_CFO_SEGMENT = tdopcs.DFDOP_CFO_SEGMENT
  and tdopcs.deleted_ind=0
  and to_date('20190630', 'YYYYMMDD') + INTERVAL '1 day - 1 second'  between tdopcs.eff_dttm and tdopcs.exp_dttm
  ;

commit;
analyze edw_stg_dds.t_000030_tfct_telephony_consumption;

----------------ВЗ

insert into edw_stg_dds.t_000030_tfct_telephony_consumption
  (
  telephony_consumption_key
  , call_start_dttm
  , subs_key
  , service_key
  , account_key
  , rc_key
  , billing_id
  , call_dur_rounded_nval
  , call_dur_actually_nval
  , call_dur_paid_nval
  , charge_rub
  , num_a
  , num_b
  , mobile_flg
  , is_vims
  , src_id
  , eff_dttm
  , exp_dttm)
SELECT
    consumption_telephony_services_key
    , call_start_dttm
    , subs_key
    , service_key
    , account_key
    , coalesce(tdopcs.dfcfo_segment,'-1') as rc_key
    , billing_id
    , call_dur_rounded_nval
    , call_dur_actually_nval
    , call_dur_paid_nval
    , charge_rub
    , dftel_a
    , dftel_b
  , case when dftel_b like '89%' or dftel_b like '79%' then 'y' else 'n' end mobile_flg
  , null is_vims
    , pc.src_id
    , eff_dttm
    , exp_dttm
FROM(
    SELECT
    a.src_id||';'||a.dfperegovor::numeric(38) as consumption_telephony_services_key
    , a.dfperegday as call_start_dttm
    , a.src_id||';'||a.dfservconst::numeric(38) as subs_key
    , a.src_id||';'||a.dfservice::numeric(38) as service_key
    , a.src_id||';'||a.dfdogovor::numeric(38) as account_key
    , to_date(to_char(a.tperioddfdatebegin,'YYYYMMDD'),'YYYYMMDD') as billing_id
    , coalesce(a.dlt, 0)*60  as call_dur_rounded_nval
    , coalesce(a.unround_dlt, 0)      call_dur_actually_nval
    , coalesce(a.dlt, 0)*60      call_dur_paid_nval
    , a.summa_bez_nds as charge_rub
    , decode(length(dftel_a),10,dftel_a,11,dftel_a,dftel_a10) as dftel_a
    , dftel_b
    , a.src_id
    , to_timestamp('19000101', 'YYYYMMDD') as EFF_DTTM
    , to_timestamp('29991231', 'YYYYMMDD') as EXP_DTTM
    --, 19000101::timestamp as eff_dttm
    --, 29991231::timestamp as exp_dttm
  FROM(
      SELECT
        l1.dflinepartgroup
      , l1.dfname
        FROM edw_ods.t_000030_tlinepartgroup l1
        left join (
                    SELECT
                        coalesce (dfvarchar2, coalesce (dfboolean, 'F')) as varchar1
                        , dfid
                      FROM edw_ods.t_000030_tadddata
                     WHERE dfaddtype IN (
                                         SELECT dfaddtype
                                           FROM edw_ods.t_000030_taddtype
                                          WHERE UPPER(dftable) = 'TLINEPARTGROUP'
                                            AND UPPER(dfname) = 'DFLPGSPEC'
                      and to_date('20190630', 'YYYYMMDD') + INTERVAL '1 day - 1 second'  between eff_dttm and exp_dttm
                    )
                       and coalesce (dfdelete, 'F') <> 'T'
             and to_date('20190630', 'YYYYMMDD') + INTERVAL '1 day - 1 second'  between eff_dttm and exp_dttm
                  ) varchar1
        on varchar1.dfid = dflinepartgroup
        left join (
          SELECT
              case when dfboolean is null and (LENGTH(dfVARCHAR2)=1) AND (upper(dfVARCHAR2)='T' OR upper(dfVARCHAR2)='F')
                 then upper(dfVARCHAR2)
                   else 'F' end as bool1
              , dfid
            FROM edw_ods.t_000030_tadddata
           WHERE dfaddtype IN (
                               SELECT dfaddtype
                                 FROM edw_ods.t_000030_taddtype
                                WHERE UPPER(dftable) = 'TLINEPARTGROUP'
                                AND UPPER(dfname) = 'DFLPG_TEST'
                      and to_date('20190630', 'YYYYMMDD') + INTERVAL '1 day - 1 second'  between eff_dttm and exp_dttm
                      )
          and to_date('20190630', 'YYYYMMDD') + INTERVAL '1 day - 1 second'  between eff_dttm and exp_dttm
          ) bool1
      on bool1.dfid = dflinepartgroup
        left join (
                    SELECT
                        coalesce (dfvarchar2, coalesce (dfboolean, 'F')) as varchar2
                        , dfid
                      FROM edw_ods.t_000030_tadddata
                     WHERE dfaddtype IN (
                                         SELECT dfaddtype
                                           FROM edw_ods.t_000030_taddtype
                                          WHERE UPPER(dftable) = 'TLINEPARTGROUP'
                                            AND UPPER(dfname) = 'DFLPG_STK'
                      and to_date('20190630', 'YYYYMMDD') + INTERVAL '1 day - 1 second'  between eff_dttm and exp_dttm
                    )
                      and coalesce (dfdelete, 'F') <> 'T'
            and to_date('20190630', 'YYYYMMDD') + INTERVAL '1 day - 1 second'  between eff_dttm and exp_dttm
                  ) varch2
      on varch2.dfid = dflinepartgroup
        WHERE coalesce(varchar1,'F')='F'
          and  coalesce(bool1,'F')='F'
          and  coalesce(varchar2,'F')='F'
      and to_date('20190630', 'YYYYMMDD') + INTERVAL '1 day - 1 second'  between l1.eff_dttm and l1.exp_dttm
        ) lin
  join(
        SELECT
        sn.dfperegovor
      , sp.dfname sp_name
      , ac.dfname act_name
      , z1.dfip_peregovor dfip
      , sn.dfdop_uslugi dfdop
      , sn.DFZONA_B
      , z1.dfname zona_type
      , sn.dflinepartgroup
      , sn.dfvector
      , sn.dfperegday
      , sn.dfzona
      , z1.dfoutcountry
      , z1.dfmagistral
      , z1.dfadd2
      , zz.dfname zona_name
      , tp.DFTEL_A
      --Получение 10-значного номера
      , (SELECT (ARRAY_AGG(us.dfmagistral_cod||us.dfzona_a||SUBSTRING(tp.DFTEL_A,'.{'||10-LENGTH(us.dfmagistral_cod)-LENGTH(us.dfzona_a)||'}$')
        ORDER BY length(us.dfzona_a) desc))[1]
          FROM edw_ods.t_000030_tunipay_link_server us
          WHERE us.dfzona_convert = sn.DFZONA_A
          AND tp.DFTEL_A LIKE coalesce(us.dfprefix,'') || '%'
          AND LENGTH(tp.DFTEL_A) = us.dflength_phone::numeric(38) + COALESCE(LENGTH(us.dfprefix), 0)
          AND us.dfmagistral_cod = reg.dfregion_a
          AND SUBSTRING(tp.DFTEL_A, 1 + COALESCE(LENGTH(us.dfprefix), 0) + decode(length(tp.DFTEL_A),10,3,0)) LIKE
              SUBSTRING(us.dfzona_a, 1 + decode(length(tp.DFTEL_A),10,0,(10 - LENGTH(us.dfmagistral_cod) - us.dflength_phone::int))) || '%'
          AND (us.dfdatebegin IS NULL OR us.dfdatebegin <= current_date)
          AND (us.dfdateend IS NULL OR current_date IS NULL OR us.dfdateend >= current_date)
          and to_date('20190630', 'YYYYMMDD') + INTERVAL '1 day - 1 second'  between us.eff_dttm and us.exp_dttm
          ) as DFTEL_A10
      , tp.DFTEL_B
      , sn.DFSERVCONST
      , sn.dfdogovor
      , tp.src_id
      , sn.dfservice
      , tper.dfdatebegin as tperioddfdatebegin
      , decode(sn.DFdop_uslugi,'T',0,SN.DFDLT_all_nach) dlt
      , decode(sn.DFdop_uslugi,'T',0,SN.dfdlt_all_pereg_sec) unround_dlt
      , SN.dfcount_all kolvo
      , sn.dfsumma_s_nds summa_s_nds
      , sn.dfsumma_bez_nds summa_bez_nds
          FROM edw_stg_dds.t_000030_tfct_telephony_consumption_stg_2_tpereg SN
      join edw_ods.t_000030_tperegovor tp
        on tp.dfperegovor=sn.dfperegovor
      join edw_ods.t_000030_tperiod tper
        on tper.dfperiod=sn.dfperiod
      and to_date('20190630', 'YYYYMMDD') + INTERVAL '1 day - 1 second'  between tper.eff_dttm and tper.exp_dttm
      join edw_ods.t_000030_tactivity ac
        on ac.dfactivity= sn.dfactivity
      and to_date('20190630', 'YYYYMMDD') + INTERVAL '1 day - 1 second'  between ac.eff_dttm and ac.exp_dttm
      join edw_ods.t_000030_tSpeakType sp
        on sp.dfspeaktype=sn.dfspeaktype
      and to_date('20190630', 'YYYYMMDD') + INTERVAL '1 day - 1 second'  between sp.eff_dttm and sp.exp_dttm
      join edw_ods.t_000030_tzona zz
        on zz.dfzona = sn.dfzona
      and to_date('20190630', 'YYYYMMDD') + INTERVAL '1 day - 1 second'  between zz.eff_dttm and zz.exp_dttm
      join (
            SELECT
            zt.dfip_peregovor
          , zt.dfzona_add_type
          , zt.dfoutcountry
          , zt.dfmagistral
          , zt.dfadd2
          , zt.dfname
            FROM edw_ods.t_000030_tzona_add_type zt
         WHERE zt.DFPEREGOVOR='T'
           AND zt.DFINZONA='T'
           and to_date('20190630', 'YYYYMMDD') + INTERVAL '1 day - 1 second'  between zt.eff_dttm and zt.exp_dttm
         ) z1
      on z1.dfzona_add_type = zz.dfadditional
          left join (
                     SELECT
                         case when dfboolean is null and (LENGTH(dfVARCHAR2)=1) AND (upper(dfVARCHAR2)='T' OR upper(dfVARCHAR2)='F')
                              then upper(dfVARCHAR2)
                              else 'F' end as bool2
            , dfid
                       FROM edw_ods.t_000030_tadddata
                      WHERE dfaddtype IN (
                                          SELECT dfaddtype
                                            FROM edw_ods.t_000030_taddtype
                                           WHERE UPPER(dftable) = 'TLINEPARTGROUP'
                                             AND UPPER(dfname) = 'DF_LPG_NOT_IN_REP_9208_B2C'
                       and to_date('20190630', 'YYYYMMDD') + INTERVAL '1 day - 1 second'  between eff_dttm and exp_dttm
                     )
            and to_date('20190630', 'YYYYMMDD') + INTERVAL '1 day - 1 second'  between eff_dttm and exp_dttm
                    ) bool2
      on bool2.dfid = sn.dflinepartgroup
          left join (
           SELECT
               case when dfboolean is null and (LENGTH(dfVARCHAR2)=1) AND (upper(dfVARCHAR2)='T' OR upper(dfVARCHAR2)='F')
                  then upper(dfVARCHAR2)
                    else 'F' end as bool3
               , dfid
             FROM edw_ods.t_000030_tadddata
            WHERE dfaddtype IN (
                                SELECT dfaddtype
                                  FROM edw_ods.t_000030_taddtype
                                 WHERE UPPER (dftable) = 'TLINEPARTGROUP'
                                 AND UPPER (dfname) = 'DF_LPG_NOT_IN_REP_9208_B2B'
                       and to_date('20190630', 'YYYYMMDD') + INTERVAL '1 day - 1 second'  between eff_dttm and exp_dttm
                     )
            and to_date('20190630', 'YYYYMMDD') + INTERVAL '1 day - 1 second'  between eff_dttm and exp_dttm
                    ) bool3
      on bool3.dfid = sn.dflinepartgroup
      left join edw_ods.t_000030_tservconst sc on sc.dfservconst = sn.DFservconst--Получение 10-значного номера
        and to_date('20190630', 'YYYYMMDD') + INTERVAL '1 day - 1 second'  between sc.eff_dttm and sc.exp_dttm
      left join edw_ods.t_000030_tdogovor d on d.dfdogovor = sc.dfdogovor --Получение 10-значного номера
        and to_date('20190630', 'YYYYMMDD') + INTERVAL '1 day - 1 second'  between d.eff_dttm and d.exp_dttm
      left join (select
        adt.dfvarchar2 as dfregion_a,
        adt.dfid -- DFLINEPARTGROUP
        from
        edw_ods.t_000030_taddtype t,
        edw_ods.t_000030_tadddata adt
        where t.dfname = 'DFREGION_A'
          and t.dftable = 'TLINEPARTGROUP'
          and t.dfaddtype = adt.dfaddtype
          and coalesce(adt.dfdelete,'F')='F'
          and current_date between coalesce(adt.dfdatebegin,current_date) and coalesce(adt.dfdateend,current_date)
        and to_date('20190630', 'YYYYMMDD') + INTERVAL '1 day - 1 second'  between t.eff_dttm and t.exp_dttm
        and to_date('20190630', 'YYYYMMDD') + INTERVAL '1 day - 1 second'  between adt.eff_dttm and adt.exp_dttm
      )reg on reg.dfid=d.dflinepartgroup --получение 10-значного номера
          WHERE upper(sn.dfdop_uslugi)='F'
            and upper(z1.dfname)!='ВНУТРИЗОНОВАЯ - ИСС'
            and ((23=ac.dfactivity AND coalesce(bool2,'F')='F') or (23<>ac.dfactivity AND coalesce(bool3,'F')='F'))
        )a
    on lin.dflinepartgroup=a.dflinepartgroup)pc
    left join edw_ods.t_000030_TDOG_CFO_SEGMENT tdogcs
    on tdogcs.src_id||';'||tdogcs.DFDOGOVOR::numeric(38)=pc.account_key
     and pc.call_start_dttm between tdogcs.dfdatebegin and coalesce(tdogcs.dfdateend,to_timestamp('29991231', 'YYYYMMDD'))
   and tdogcs.deleted_ind=0
   and to_date('20190630', 'YYYYMMDD') + INTERVAL '1 day - 1 second'  between tdogcs.eff_dttm and tdogcs.exp_dttm
    left join edw_ods.t_000030_TDOP_CFO_SEGMENT tdopcs
    on tdogcs.DFDOP_CFO_SEGMENT = tdopcs.DFDOP_CFO_SEGMENT
   and tdopcs.deleted_ind=0
   and to_date('20190630', 'YYYYMMDD') + INTERVAL '1 day - 1 second'  between tdopcs.eff_dttm and tdopcs.exp_dttm
   ;
commit;
analyze edw_stg_dds.t_000030_tfct_telephony_consumption;
  