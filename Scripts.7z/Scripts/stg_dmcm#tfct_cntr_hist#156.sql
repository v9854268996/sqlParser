/*rev. 59469 от 01.06.2020*/
truncate table edw_stg_dmcm.tfct_cntr_hist_1_prt_p000156;
commit;
insert into edw_stg_dmcm.tfct_cntr_hist_1_prt_p000156
  ( 
    account      ,
    contr_id     ,
    contr_num    ,
    data_contr   ,
    contr_status ,
    data_close   ,
    clie_id      ,
    abn_id       ,
    cntr_dttm    ,
    eff_dttm     ,
    exp_dttm     ,
    load_dttm    ,
    src_id
  )
  select distinct
    client.account      ,
    client.contr_id     ,
    client.contr_num    ,
    client.data_contr   ,
    client.contr_status ,
    client.data_close   ,
    client.clie_id      ,
    -1 as abn_id      ,
    to_date('20190601', 'yyyymmdd') + interval '1 month'            as cntr_dttm,
    to_date('20190601', 'yyyymmdd')                                 as eff_dttm ,
    to_date('20190601', 'yyyymmdd') + interval '1 month - 1 second' as exp_dttm ,
    now()         as load_dttm       ,
    000156  as src_id
    from
    (
      select
        client_dwh.account      ,
        client_dwh.contr_id     ,
        client_dwh.rf_id        ,
        client_dwh.contr_num    ,
        client_dwh.data_contr   ,
        client_dwh.contr_status ,
        client_dwh.data_close   ,
        client_dwh.clie_id      ,
        row_number() over (partition by account,clie_id order by coalesce(data_contr, '1900-01-01'::date) desc) as rn
      from
        edw_ods.t_000156_rprt_client_dwh client_dwh
      where
        client_dwh.account is not null
        and client_dwh.clie_id is not null
        and rf_id is not null
    )
    client
    inner join 
    (
      select distinct 
        clnt_id as clnt_clie_id,
        account,
        rf_id
      from
        edw_ods.t_000156_RPRTSUBSCRIBERSACTUAL sub
      where
        serv_id in (1,2,3)
        and coalesce(data_close_serv, to_date('29991231', 'yyyymmdd')) >= to_date('20190601', 'yyyymmdd') + interval '1 month'
        and data_connect <= to_date('20190601', 'yyyymmdd') + interval '2 month - 1 second'
        and abn_id is not null
        and clnt_id is not null
        and account is not null
        and rf_id is not null
        and 000156 != 154
      union all
      select distinct 
        clie_id as clnt_clie_id,
        account,
        rf_id
      from
        edw_ods.t_000156_RPRTSUBSCRIBERSACTUAL sub
      where
        serv_id in (1,2,3)
        and coalesce(data_close_serv, to_date('29991231', 'yyyymmdd')) >= to_date('20190601', 'yyyymmdd') + interval '1 month'
        and data_connect <= to_date('20190601', 'yyyymmdd') + interval '2 month - 1 second'
        and abn_id is not null
        and clie_id is not null
        and account is not null
        and rf_id is not null
        and 000156 = 154      
    ) sub 
    on 
      sub.clnt_clie_id = client.clie_id 
      and sub.account = client.account
      and sub.rf_id = client.rf_id
    where rn=1
        ;
analyze edw_stg_dmcm.tfct_cntr_hist_1_prt_p000156;  
