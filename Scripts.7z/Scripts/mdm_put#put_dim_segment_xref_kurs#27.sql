/*rev.10468 от 11.05.2018*/
delete from  edw_stg_mdm.put_dim_segment_xref_kurs where src_id = 000027;
insert into edw_stg_mdm.put_dim_segment_xref_kurs (segment_key,segment_name,src_id)
/*27-34 36-39*/
select dfactivity_dop_segment,dfname,src_id
  from edw_ods.t_000027_tactivity_dop_segment
;

commit;
analyse edw_stg_mdm.put_dim_segment_xref_kurs;
