/*rev.34588 31.07.2019 Changed by: NAREK.ALAVERDYAN */
		truncate table edw_stg_ads.tfct_network_resources;
		insert into edw_stg_ads.tfct_network_resources
		(
			calendar_key,
			year_month_key,
			install_dt,
			deinstall_dt,
			branch_key,
			region_key,
			segment_key,
			port_type_key,
			port_status_key,
			technology_type_key,
			network_element_key,
			network_element_type_key,
			equipment_status_key,
			port_count,
			installed_capacity,
			involved_capacity,
			in_capacity,
			out_capacity,
			src_id
		)

		SELECT
			date_trunc('day', cal.month_end_date) as calendar_key,
			cal.year_month_key,
			dne.install_dt,
			dne.deinstall_dt,
			coalesce(dne.branch_key, -1) as branch_key,
			/*coalesce(dr.region_key, -1) */-1 as region_key,
			coalesce(dne.segment_key, -1) as segment_key,
			coalesce(dp.port_type_key, -1) as port_type_key,
			coalesce(dp.port_status_key, -1) as port_status_key,
			coalesce(dp.technology_type_key, -1) as technology_type_key,
			coalesce(dne.network_element_key, -1) as network_element_key,
			coalesce(dne.network_element_type_key, -1) as network_element_type_key,
			coalesce(dne.equipment_status_key, -1) as equipment_status_key,
			count(dp.port_key) as port_count,
			sum
				(
					case
						when dne.equipment_status_key in (3,4)
							and cal.month_end_date >= dne.install_dt
							and cal.month_end_date < dne.deinstall_dt
							and cal.month_end_date between dne.eff_dttm and dne.exp_dttm
						then 1 else 0 
					end
				) as installed_capacity,
			sum
				(
					case
						when dp.port_status_key in (2)
							and cal.month_end_date >= dne.install_dt
							and cal.month_end_date < dne.deinstall_dt
							and cal.month_end_date between dne.eff_dttm and dne.exp_dttm		
						then 1 else 0 
					end
				) as involved_capacity,
			sum
				(
					case 
						when dne.equipment_status_key in (3,4)
							and dne.install_dt between cal.month_start_date and cal.month_end_date
							and dne.install_dt between dne.eff_dttm and dne.exp_dttm
							and dne.install_dt between dp.eff_dttm and dp.exp_dttm
						then 1 else 0 
					end
				) as in_capacity,
			sum
				(
					case 
						when dne.equipment_status_key in (3,4)
							and dne.deinstall_dt between cal.month_start_date and cal.month_end_date
							and dne.deinstall_dt between dne.eff_dttm and dne.exp_dttm
							and dne.deinstall_dt between dp.eff_dttm and dp.exp_dttm
						then 1 else 0 
					end
				) as out_capacity,
			000087 as src_id
		FROM 
			(
				SELECT DISTINCT
					month_start_date, 
					month_end_date + INTERVAL '1 day' + INTERVAL '-1 sec' as month_end_date,
					to_char(month_end_date, 'YYYYMM') as year_month_key
				FROM edw_dds.dim_calendar
				WHERE month_end_date between date_trunc('month', to_date('20190601', 'YYYYMMDD'))
						and (date_trunc('month', to_date('20190630', 'YYYYMMDD')) + interval '1 month' + interval '-1 sec')
			) as cal
			join edw_dds.dim_port as dp
				on cal.month_end_date BETWEEN dp.eff_dttm and dp.exp_dttm
					and dp.src_id = 000087
			join edw_dds.dim_network_element as dne
				on dne.network_element_key = dp.network_element_key
			/*left join edw_dds.dim_region as dr
				on dne.branch_key = dr.branch_key
					and dr.exp_dttm = '2999-12-31'
					and dr.deleted_ind = 0*/
		GROUP BY
			date_trunc('day', cal.month_end_date),
			cal.year_month_key,
			dne.install_dt,
			dne.deinstall_dt,
			dne.branch_key,
			--dr.region_key,
			dne.segment_key,
			dp.port_type_key,
			dp.port_status_key,
			dp.technology_type_key,
			dne.network_element_key,
			dne.network_element_type_key,
			dne.equipment_status_key
		;

		ANALYZE edw_stg_ads.tfct_network_resources;		
	