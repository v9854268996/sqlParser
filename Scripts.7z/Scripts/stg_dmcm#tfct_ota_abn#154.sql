/*rev. 39973 11.10.2019*/
SET search_path = edw_stg_dmcm;
SET optimizer = ON;

/*
 151: 48-62 (mrf_id = 11)
 153: 1-12 (mrf_id = 13)
 156: 80-89 (mrf_id = 16)
 157: 107-113 (mrf_id = 17)
*/

/*pre_ota_abn_subs_act_serv_not1_stg*/
truncate table edw_stg_dmcm.pre_ota_abn_subs_act_stg_1_PRT_P000154;
insert into edw_stg_dmcm.pre_ota_abn_subs_act_stg_1_PRT_P000154
(
    abn_id,
    subs_id,
    rf_id,
    mrf_id,
    src_id,
    account,
    serv_id,
    tech_id,
    subs_key,
    src_id_ekhd,
    cl_id,
    adress,
    account_key,
    business_service_key,
  load_dttm
)
WITH
services AS
(
            select service_id::varchar(38), serv_first_id, src_id from edw_ods.t_000107_t_services where 154 = 157
  union all select service_id::varchar(38), serv_first_id, src_id from edw_ods.t_000108_t_services where 154 = 157
  union all select service_id::varchar(38), serv_first_id, src_id from edw_ods.t_000109_t_services where 154 = 157
  union all select service_id::varchar(38), serv_first_id, src_id from edw_ods.t_000110_t_services where 154 = 157
  union all select service_id::varchar(38), serv_first_id, src_id from edw_ods.t_000111_t_services where 154 = 157
  union all select service_id::varchar(38), serv_first_id, src_id from edw_ods.t_000112_t_services where 154 = 157
  union all select service_id::varchar(38), serv_first_id, src_id from edw_ods.t_000113_t_services where 154 = 157

  union all select service_id::varchar(38), serv_first_id, src_id from edw_ods.t_000080_t_services where 154 = 156
  union all select service_id::varchar(38), serv_first_id, src_id from edw_ods.t_000081_t_services where 154 = 156
  union all select service_id::varchar(38), serv_first_id, src_id from edw_ods.t_000082_t_services where 154 = 156
  union all select service_id::varchar(38), serv_first_id, src_id from edw_ods.t_000083_t_services where 154 = 156
  union all select service_id::varchar(38), serv_first_id, src_id from edw_ods.t_000084_t_services where 154 = 156
  union all select service_id::varchar(38), serv_first_id, src_id from edw_ods.t_000085_t_services where 154 = 156
  union all select service_id::varchar(38), serv_first_id, src_id from edw_ods.t_000086_t_services where 154 = 156
  union all select service_id::varchar(38), serv_first_id, src_id from edw_ods.t_000087_t_services where 154 = 156
  union all select service_id::varchar(38), serv_first_id, src_id from edw_ods.t_000088_t_services where 154 = 156
  union all select service_id::varchar(38), serv_first_id, src_id from edw_ods.t_000089_t_services where 154 = 156

  union all select service_id::varchar(38), serv_first_id, src_id from edw_ods.t_000001_t_services where 154 = 153
  union all select service_id::varchar(38), serv_first_id, src_id from edw_ods.t_000002_t_services where 154 = 153
  union all select service_id::varchar(38), serv_first_id, src_id from edw_ods.t_000003_t_services where 154 = 153
  union all select service_id::varchar(38), serv_first_id, src_id from edw_ods.t_000004_t_services where 154 = 153
  union all select service_id::varchar(38), serv_first_id, src_id from edw_ods.t_000005_t_services where 154 = 153
  union all select service_id::varchar(38), serv_first_id, src_id from edw_ods.t_000006_t_services where 154 = 153
  union all select service_id::varchar(38), serv_first_id, src_id from edw_ods.t_000007_t_services where 154 = 153
  union all select service_id::varchar(38), serv_first_id, src_id from edw_ods.t_000008_t_services where 154 = 153
  union all select service_id::varchar(38), serv_first_id, src_id from edw_ods.t_000009_t_services where 154 = 153
  union all select service_id::varchar(38), serv_first_id, src_id from edw_ods.t_000010_t_services where 154 = 153
  union all select service_id::varchar(38), serv_first_id, src_id from edw_ods.t_000011_t_services where 154 = 153
  union all select service_id::varchar(38), serv_first_id, src_id from edw_ods.t_000012_t_services where 154 = 153

  union all select service_id::varchar(38), serv_first_id, src_id from edw_ods.t_000048_t_services where 154 = 151
  union all select service_id::varchar(38), serv_first_id, src_id from edw_ods.t_000049_t_services where 154 = 151
  union all select service_id::varchar(38), serv_first_id, src_id from edw_ods.t_000050_t_services where 154 = 151
  union all select service_id::varchar(38), serv_first_id, src_id from edw_ods.t_000051_t_services where 154 = 151
  union all select service_id::varchar(38), serv_first_id, src_id from edw_ods.t_000052_t_services where 154 = 151
  union all select service_id::varchar(38), serv_first_id, src_id from edw_ods.t_000053_t_services where 154 = 151
  union all select service_id::varchar(38), serv_first_id, src_id from edw_ods.t_000054_t_services where 154 = 151
  union all select service_id::varchar(38), serv_first_id, src_id from edw_ods.t_000055_t_services where 154 = 151
  union all select service_id::varchar(38), serv_first_id, src_id from edw_ods.t_000056_t_services where 154 = 151
  union all select service_id::varchar(38), serv_first_id, src_id from edw_ods.t_000057_t_services where 154 = 151
  union all select service_id::varchar(38), serv_first_id, src_id from edw_ods.t_000058_t_services where 154 = 151
  union all select service_id::varchar(38), serv_first_id, src_id from edw_ods.t_000059_t_services where 154 = 151
  union all select service_id::varchar(38), serv_first_id, src_id from edw_ods.t_000060_t_services where 154 = 151
  union all select service_id::varchar(38), serv_first_id, src_id from edw_ods.t_000061_t_services where 154 = 151
  union all select service_id::varchar(38), serv_first_id, src_id from edw_ods.t_000062_t_services where 154 = 151
),
dim_connected_service AS
(
  SELECT
    dim_connected_service.exp_dttm as exp_dttm_dcs,
    dim_connected_service.eff_dttm as eff_dttm_dcs,
    dim_service.exp_dttm as exp_dttm_ds,
    dim_service.eff_dttm as eff_dttm_ds,
    dim_connected_service.subs_key,
    dim_service.business_service_key,
    dim_connected_service.account_key,
    dim_connected_service.start_date,
    dim_connected_service.end_date,
    dim_connected_service.subs_code,
    dim_connected_service.src_id,
    t_services.serv_first_id,
    hub_dim_subscribers.source_key       AS source_subs_key,
    hub_dim_connected_service.source_key AS source_key_connected_service_key,
    split_part(hub_dim_subscribers.source_key, chr(9), 1) as source_subs_key_ural,
    split_part(hub_dim_subscribers.source_key, chr(9), 2) as source_subs_key_sz,
    split_part(hub_dim_subscribers.source_key, ';', 2) as source_subs_key_kurs_stg1
  FROM edw_dds.dim_connected_service dim_connected_service
  LEFT JOIN edw_dds.hub_dim_connected_service
      ON dim_connected_service.connected_service_key = hub_dim_connected_service.connected_service_key
      AND dim_connected_service.src_id = hub_dim_connected_service.src_id
  LEFT JOIN edw_dds.hub_dim_subscribers
      ON dim_connected_service.subs_key = hub_dim_subscribers.subs_key
      AND dim_connected_service.src_id = hub_dim_connected_service.src_id
  LEFT JOIN services t_services
      ON hub_dim_connected_service.source_key = t_services.service_id
      AND hub_dim_connected_service.src_id = t_services.src_id
  LEFT JOIN edw_dds.dim_service dim_service
      ON dim_service.service_key = dim_connected_service.service_key
  AND date_trunc('day', dim_service.exp_dttm) = to_date('2999-12-31', 'yyyy-mm-dd')
  WHERE date_trunc('day', dim_connected_service.exp_dttm) = to_date('2999-12-31', 'yyyy-mm-dd')
  AND dim_service.business_service_key in ( 10101, 10102, 10103, 10104, 10105, 10106, 10107, 10108, 10109, 10199 )
)
SELECT
  abn_id,
  subs_id,
  rf_id,
  mrf_id,
  src_id,
  account,
  serv_id,
  tech_id,
  subs_key,
  src_id_ekhd,
  cl_id,
  adress,
  account_key,
  business_service_key,
  current_date
FROM
(
  SELECT
    subs_act.abn_id,
    subs_act.subs_id,
    subs_act.rf_id,
    subs_act.mrf_id,
    154 as src_id,
    subs_act.account,
    subs_act.serv_id,
    subs_act.tech_id,
    dim_connected_service1.subs_key,
    dim_connected_service1.src_id AS src_id_ekhd,
    subs_act.cl_id,
    subs_act.adress,
    dim_connected_service1.account_key,
 hub_dim_business_service.business_service_key,
    row_number () OVER (PARTITION BY dim_connected_service1.subs_key
                            ORDER BY CASE WHEN hub_dim_business_service.business_service_key in ( 10101, 10102, 10103, 10104, 10105, 10106, 10107, 10108, 10109, 10199 ) THEN 0 ELSE 1 END,
                                     subs_act.date_snap DESC,
                                     subs_act.log_id DESC) AS rn
  FROM edw_ods.t_000154_rprtsubscribersactual subs_act
    JOIN
    edw_dds.hub_dim_business_service hub_dim_business_service
    ON hub_dim_business_service.src_id = 158
    AND date_trunc('day', hub_dim_business_service.exp_dttm) = to_date('2999-12-31', 'yyyy-mm-dd')
    AND hub_dim_business_service.source_key = coalesce(subs_act.serv_id,'-1') || '#' || coalesce(subs_act.tech_id,'-1')
       JOIN
       dim_connected_service dim_connected_service1
        ON dim_connected_service1.serv_first_id :: varchar(38) = subs_act.subs_id
        and case  when 154 = 151 THEN dim_connected_service1.src_id BETWEEN 48 AND 62
                  when 154 = 153 THEN dim_connected_service1.src_id BETWEEN 1 AND 12
                  when 154 = 156 THEN dim_connected_service1.src_id BETWEEN 80 AND 89
                  when 154 = 157 THEN dim_connected_service1.src_id BETWEEN 107 AND 113
            end
  WHERE subs_act.serv_id != 1
    AND subs_act.mrf_id = case when 154 = 151 then 11
                               when 154 = 153 then 13
                               when 154 = 156 then 16
                               when 154 = 157 then 17
                          end
) a
WHERE rn = 1;


/*edw_stg_dmcm.pre_ota_abn_subs_act_serv_1_stg_1_PRT_P000154*/
insert into edw_stg_dmcm.pre_ota_abn_subs_act_stg_1_PRT_P000154
  (
    abn_id,
    subs_id,
    rf_id,
    mrf_id,
    src_id,
    account,
    serv_id,
    tech_id,
    subs_key,
    src_id_ekhd,
    cl_id,
    adress,
    account_key,
    business_service_key,
  load_dttm
)
WITH
services AS
(
            select service_id::varchar(38), serv_first_id, src_id from edw_ods.t_000107_t_services where 154 = 157
  union all select service_id::varchar(38), serv_first_id, src_id from edw_ods.t_000108_t_services where 154 = 157
  union all select service_id::varchar(38), serv_first_id, src_id from edw_ods.t_000109_t_services where 154 = 157
  union all select service_id::varchar(38), serv_first_id, src_id from edw_ods.t_000110_t_services where 154 = 157
  union all select service_id::varchar(38), serv_first_id, src_id from edw_ods.t_000111_t_services where 154 = 157
  union all select service_id::varchar(38), serv_first_id, src_id from edw_ods.t_000112_t_services where 154 = 157
  union all select service_id::varchar(38), serv_first_id, src_id from edw_ods.t_000113_t_services where 154 = 157

  union all select service_id::varchar(38), serv_first_id, src_id from edw_ods.t_000080_t_services where 154 = 156
  union all select service_id::varchar(38), serv_first_id, src_id from edw_ods.t_000081_t_services where 154 = 156
  union all select service_id::varchar(38), serv_first_id, src_id from edw_ods.t_000082_t_services where 154 = 156
  union all select service_id::varchar(38), serv_first_id, src_id from edw_ods.t_000083_t_services where 154 = 156
  union all select service_id::varchar(38), serv_first_id, src_id from edw_ods.t_000084_t_services where 154 = 156
  union all select service_id::varchar(38), serv_first_id, src_id from edw_ods.t_000085_t_services where 154 = 156
  union all select service_id::varchar(38), serv_first_id, src_id from edw_ods.t_000086_t_services where 154 = 156
  union all select service_id::varchar(38), serv_first_id, src_id from edw_ods.t_000087_t_services where 154 = 156
  union all select service_id::varchar(38), serv_first_id, src_id from edw_ods.t_000088_t_services where 154 = 156
  union all select service_id::varchar(38), serv_first_id, src_id from edw_ods.t_000089_t_services where 154 = 156

  union all select service_id::varchar(38), serv_first_id, src_id from edw_ods.t_000001_t_services where 154 = 153
  union all select service_id::varchar(38), serv_first_id, src_id from edw_ods.t_000002_t_services where 154 = 153
  union all select service_id::varchar(38), serv_first_id, src_id from edw_ods.t_000003_t_services where 154 = 153
  union all select service_id::varchar(38), serv_first_id, src_id from edw_ods.t_000004_t_services where 154 = 153
  union all select service_id::varchar(38), serv_first_id, src_id from edw_ods.t_000005_t_services where 154 = 153
  union all select service_id::varchar(38), serv_first_id, src_id from edw_ods.t_000006_t_services where 154 = 153
  union all select service_id::varchar(38), serv_first_id, src_id from edw_ods.t_000007_t_services where 154 = 153
  union all select service_id::varchar(38), serv_first_id, src_id from edw_ods.t_000008_t_services where 154 = 153
  union all select service_id::varchar(38), serv_first_id, src_id from edw_ods.t_000009_t_services where 154 = 153
  union all select service_id::varchar(38), serv_first_id, src_id from edw_ods.t_000010_t_services where 154 = 153
  union all select service_id::varchar(38), serv_first_id, src_id from edw_ods.t_000011_t_services where 154 = 153
  union all select service_id::varchar(38), serv_first_id, src_id from edw_ods.t_000012_t_services where 154 = 153

  union all select service_id::varchar(38), serv_first_id, src_id from edw_ods.t_000048_t_services where 154 = 151
  union all select service_id::varchar(38), serv_first_id, src_id from edw_ods.t_000049_t_services where 154 = 151
  union all select service_id::varchar(38), serv_first_id, src_id from edw_ods.t_000050_t_services where 154 = 151
  union all select service_id::varchar(38), serv_first_id, src_id from edw_ods.t_000051_t_services where 154 = 151
  union all select service_id::varchar(38), serv_first_id, src_id from edw_ods.t_000052_t_services where 154 = 151
  union all select service_id::varchar(38), serv_first_id, src_id from edw_ods.t_000053_t_services where 154 = 151
  union all select service_id::varchar(38), serv_first_id, src_id from edw_ods.t_000054_t_services where 154 = 151
  union all select service_id::varchar(38), serv_first_id, src_id from edw_ods.t_000055_t_services where 154 = 151
  union all select service_id::varchar(38), serv_first_id, src_id from edw_ods.t_000056_t_services where 154 = 151
  union all select service_id::varchar(38), serv_first_id, src_id from edw_ods.t_000057_t_services where 154 = 151
  union all select service_id::varchar(38), serv_first_id, src_id from edw_ods.t_000058_t_services where 154 = 151
  union all select service_id::varchar(38), serv_first_id, src_id from edw_ods.t_000059_t_services where 154 = 151
  union all select service_id::varchar(38), serv_first_id, src_id from edw_ods.t_000060_t_services where 154 = 151
  union all select service_id::varchar(38), serv_first_id, src_id from edw_ods.t_000061_t_services where 154 = 151
  union all select service_id::varchar(38), serv_first_id, src_id from edw_ods.t_000062_t_services where 154 = 151
),
dim_connected_service AS
(
  SELECT
    dim_connected_service.exp_dttm as exp_dttm_dcs,
    dim_connected_service.eff_dttm as eff_dttm_dcs,
    dim_service.exp_dttm as exp_dttm_ds,
    dim_service.eff_dttm as eff_dttm_ds,
    dim_connected_service.subs_key,
    dim_service.business_service_key,
    dim_connected_service.account_key,
    dim_connected_service.start_date,
    dim_connected_service.end_date,
    dim_connected_service.subs_code,
    dim_connected_service.src_id,
    t_services.serv_first_id,
    hub_dim_subscribers.source_key       AS source_subs_key,
    hub_dim_connected_service.source_key AS source_key_connected_service_key,
    split_part(hub_dim_subscribers.source_key, chr(9), 1) as source_subs_key_ural,
    split_part(hub_dim_subscribers.source_key, chr(9), 2) as source_subs_key_sz,
    split_part(hub_dim_subscribers.source_key, ';', 2) as source_subs_key_kurs_stg1
  FROM edw_dds.dim_connected_service dim_connected_service
  LEFT JOIN edw_dds.hub_dim_connected_service
      ON dim_connected_service.connected_service_key = hub_dim_connected_service.connected_service_key
      AND dim_connected_service.src_id = hub_dim_connected_service.src_id
  LEFT JOIN edw_dds.hub_dim_subscribers
      ON dim_connected_service.subs_key = hub_dim_subscribers.subs_key
      AND dim_connected_service.src_id = hub_dim_connected_service.src_id
  LEFT JOIN services t_services
      ON hub_dim_connected_service.source_key = t_services.service_id
      AND hub_dim_connected_service.src_id = t_services.src_id
  LEFT JOIN edw_dds.dim_service dim_service
      ON dim_service.service_key = dim_connected_service.service_key
  AND date_trunc('day', dim_service.exp_dttm) = to_date('2999-12-31', 'yyyy-mm-dd')
  WHERE date_trunc('day', dim_connected_service.exp_dttm) = to_date('2999-12-31', 'yyyy-mm-dd')
  AND dim_service.business_service_key in ( 10101, 10102, 10103, 10104, 10105, 10106, 10107, 10108, 10109, 10199 )
)
SELECT
  abn_id,
  subs_id,
  rf_id,
  mrf_id,
  src_id,
  account,
  serv_id,
  tech_id,
  subs_key,
  src_id_ekhd,
  cl_id,
  adress,
  account_key,
  business_service_key,
  current_date
FROM
(
  SELECT
    subs_act.abn_id,
    subs_act.subs_id,
    subs_act.rf_id,
    subs_act.mrf_id,
    154 as src_id,
    subs_act.account,
    subs_act.serv_id,
    subs_act.tech_id,
    dim_connected_service1.subs_key,
    dim_connected_service1.src_id AS src_id_ekhd,
    subs_act.cl_id,
    subs_act.adress,
    dim_connected_service1.account_key,
 hub_dim_business_service.business_service_key,
    row_number () OVER (PARTITION BY dim_connected_service1.subs_key
                            ORDER BY CASE WHEN hub_dim_business_service.business_service_key in ( 10101, 10102, 10103, 10104, 10105, 10106, 10107, 10108, 10109, 10199 ) THEN 0 ELSE 1 END,
                                     subs_act.date_snap DESC,
                                     subs_act.log_id DESC) AS rn
  FROM edw_ods.t_000154_rprtsubscribersactual subs_act
    JOIN
    edw_dds.hub_dim_business_service hub_dim_business_service
    ON hub_dim_business_service.src_id = 158
    AND date_trunc('day', hub_dim_business_service.exp_dttm) = to_date('2999-12-31', 'yyyy-mm-dd')
    AND hub_dim_business_service.source_key = coalesce(subs_act.serv_id,'-1') || '#' || coalesce(subs_act.tech_id,'-1')

    JOIN
       dim_connected_service dim_connected_service1
        ON dim_connected_service1.subs_code||'##' = subs_act.subs_id
        and case  when 154 = 151 THEN dim_connected_service1.src_id BETWEEN 48 AND 62
                  when 154 = 153 THEN dim_connected_service1.src_id BETWEEN 1 AND 12
                  when 154 = 156 THEN dim_connected_service1.src_id BETWEEN 80 AND 89
                  when 154 = 157 THEN dim_connected_service1.src_id BETWEEN 107 AND 113
            end
  WHERE subs_act.serv_id = 1
    AND subs_act.mrf_id = case when 154 = 151 then 11
                               when 154 = 153 then 13
                               when 154 = 156 then 16
                               when 154 = 157 then 17
                          end
) a
WHERE rn = 1;


/*edw_stg_dmcm.pre_ota_abn_subs_act_bis_ural_sz_stg_1_PRT_P000154*/
insert into edw_stg_dmcm.pre_ota_abn_subs_act_stg_1_PRT_P000154
(abn_id,
subs_id,
rf_id,
mrf_id,
src_id,
account,
serv_id,
tech_id,
subs_key,
src_id_ekhd,
cl_id,
adress,
account_key,
business_service_key,
load_dttm)
  WITH dim_connected_service AS
(
  SELECT
    dim_connected_service.exp_dttm as exp_dttm_dcs,
    dim_connected_service.eff_dttm as eff_dttm_dcs,
    dim_service.exp_dttm as exp_dttm_ds,
    dim_service.eff_dttm as eff_dttm_ds,
    dim_connected_service.subs_key,
    dim_service.business_service_key,
    dim_connected_service.account_key,
    dim_connected_service.start_date,
    dim_connected_service.end_date,
    dim_connected_service.subs_code,
    dim_connected_service.src_id,
    hub_dim_subscribers.source_key       AS source_subs_key,
    hub_dim_connected_service.source_key AS source_key_connected_service_key,
    split_part(hub_dim_subscribers.source_key, chr(9), 1) as source_subs_key_ural,
    split_part(hub_dim_subscribers.source_key, chr(9), 2) as source_subs_key_sz,
    split_part(hub_dim_subscribers.source_key, ';', 2) as source_subs_key_kurs_stg1
  FROM edw_dds.dim_connected_service dim_connected_service
  LEFT JOIN edw_dds.hub_dim_connected_service
      ON dim_connected_service.connected_service_key = hub_dim_connected_service.connected_service_key
      AND dim_connected_service.src_id = hub_dim_connected_service.src_id
  LEFT JOIN edw_dds.hub_dim_subscribers
      ON dim_connected_service.subs_key = hub_dim_subscribers.subs_key
      AND dim_connected_service.src_id = hub_dim_connected_service.src_id
  LEFT JOIN edw_dds.dim_service dim_service
      ON dim_service.service_key = dim_connected_service.service_key
  AND date_trunc('day', dim_service.exp_dttm) = to_date('2999-12-31', 'yyyy-mm-dd')
  WHERE date_trunc('day', dim_connected_service.exp_dttm) = to_date('2999-12-31', 'yyyy-mm-dd')
  AND dim_service.business_service_key in ( 10101, 10102, 10103, 10104, 10105, 10106, 10107, 10108, 10109, 10199 )
)
SELECT
  abn_id,
  subs_id,
  rf_id,
  mrf_id,
  src_id,
  account,
  serv_id,
  tech_id,
  subs_key,
  src_id_ekhd,
  cl_id,
  adress,
  account_key,
  business_service_key,
  current_date
    from (
select subs_act.abn_id
    , subs_act.subs_id
    , subs_act.rf_id
    , subs_act.mrf_id
    , subs_act.src_id
    , subs_act.account
    , subs_act.SERV_ID
    , subs_act.TECH_ID
    , dim_connected_service1.subs_key
    , dim_connected_service1.src_id as src_id_ekhd
    , subs_act.cl_id
    , subs_act.adress
    , dim_connected_service1.account_key
    , hub_dim_business_service.business_service_key
    , row_number () OVER (PARTITION BY dim_connected_service1.subs_key
                            ORDER BY CASE WHEN hub_dim_business_service.business_service_key in ( 10101, 10102, 10103, 10104, 10105, 10106, 10107, 10108, 10109, 10199 ) THEN 0 ELSE 1 END,
                                     subs_act.date_snap DESC,
                                     subs_act.log_id DESC) AS rn
from edw_ods.t_000154_rprtsubscribersactual subs_act
JOIN
       edw_dds.hub_dim_business_service hub_dim_business_service
       ON hub_dim_business_service.src_id = 158
       AND date_trunc('day', hub_dim_business_service.exp_dttm) = to_date('2999-12-31', 'yyyy-mm-dd')
       AND hub_dim_business_service.source_key = coalesce(subs_act.serv_id,'-1') || '#' || coalesce(subs_act.tech_id,'-1')

       JOIN
       dim_connected_service dim_connected_service1
         ON dim_connected_service1.src_id = (case when 154 = 155 then 45 when 154 = 152 then 97 else -666 end)
         AND split_part(dim_connected_service1.source_subs_key, chr(9), case when 154 = 155 then 1 when 154 = 152 then 2 else -666 end) = subs_act.subs_id
where subs_act.mrf_id = (case when 154 = 155 then 15 when 154 = 152 then 12 else -666 end)
and 154 in (155,152)) A
where rn = 1;


/*edw_stg_dmcm.pre_ota_abn_subs_act_kurs_stg_1_PRT_P000154*/
insert into edw_stg_dmcm.pre_ota_abn_subs_act_stg_1_PRT_P000154
(abn_id,
subs_id,
rf_id,
mrf_id,
src_id,
account,
serv_id,
tech_id,
subs_key,
src_id_ekhd,
cl_id,
adress,
account_key,
business_service_key,
load_dttm)
WITH dim_connected_service AS
(
  SELECT
    dim_connected_service.exp_dttm as exp_dttm_dcs,
    dim_connected_service.eff_dttm as eff_dttm_dcs,
    dim_service.exp_dttm as exp_dttm_ds,
    dim_service.eff_dttm as eff_dttm_ds,
    dim_connected_service.subs_key,
    dim_service.business_service_key,
    dim_connected_service.account_key,
    dim_connected_service.start_date,
    dim_connected_service.end_date,
    dim_connected_service.subs_code,
    dim_connected_service.src_id,
    hub_dim_subscribers.source_key       AS source_subs_key,
    hub_dim_connected_service.source_key AS source_key_connected_service_key,
    split_part(hub_dim_subscribers.source_key, chr(9), 1) as source_subs_key_ural,
    split_part(hub_dim_subscribers.source_key, chr(9), 2) as source_subs_key_sz,
    split_part(hub_dim_subscribers.source_key, ';', 2) as source_subs_key_kurs_stg1
  FROM edw_dds.dim_connected_service dim_connected_service
  LEFT JOIN edw_dds.hub_dim_connected_service
      ON dim_connected_service.connected_service_key = hub_dim_connected_service.connected_service_key
      AND dim_connected_service.src_id = hub_dim_connected_service.src_id
  LEFT JOIN edw_dds.hub_dim_subscribers
      ON dim_connected_service.subs_key = hub_dim_subscribers.subs_key
      AND dim_connected_service.src_id = hub_dim_connected_service.src_id
  LEFT JOIN edw_dds.dim_service dim_service
      ON dim_service.service_key = dim_connected_service.service_key
  AND date_trunc('day', dim_service.exp_dttm) = to_date('2999-12-31', 'yyyy-mm-dd')
  WHERE date_trunc('day', dim_connected_service.exp_dttm) = to_date('2999-12-31', 'yyyy-mm-dd')
  AND dim_service.business_service_key in ( 10101, 10102, 10103, 10104, 10105, 10106, 10107, 10108, 10109, 10199 )
)SELECT
  abn_id,
  subs_id,
  rf_id,
  mrf_id,
  src_id,
  nls as account,
  serv_id,
  tech_id,
  subs_key,
  src_id_ekhd,
  cl_id,
  adress,
  account_key,
  business_service_key,
  current_date
    from (
select subs_act.abn_id
    , subs_act.subs_id
    , subs_act.rf_id
    , subs_act.mrf_id
    , subs_act.src_id
    , sa.nls
    , subs_act.SERV_ID
    , subs_act.TECH_ID
    , dim_connected_service1.subs_key
    , dim_connected_service1.src_id as src_id_ekhd
    , subs_act.cl_id
    , subs_act.adress
    , dim_connected_service1.account_key
    , hub_dim_business_service.business_service_key
    , row_number () OVER (PARTITION BY dim_connected_service1.subs_key
                            ORDER BY CASE WHEN hub_dim_business_service.business_service_key in ( 10101, 10102, 10103, 10104, 10105, 10106, 10107, 10108, 10109, 10199 ) THEN 0 ELSE 1 END,
                                     subs_act.date_snap DESC,
                                     subs_act.log_id DESC) AS rn
from edw_ods.t_000154_rprtsubscribersactual subs_act
LEFT JOIN
         (
           SELECT
             account, nls,
             row_number() OVER (
              PARTITION BY account
              ORDER BY coalesce(date_end, to_date('29991231','yyyymmdd')) DESC, date_begin DESC
             ) AS rn
            FROM edw_ods.t_000158_efftp_south_nls_accnt
         ) sa
           ON sa.account = subs_act.account
          AND sa.rn = 1
JOIN
       edw_dds.hub_dim_business_service hub_dim_business_service
       ON hub_dim_business_service.src_id = 158
       AND date_trunc('day', hub_dim_business_service.exp_dttm) = to_date('2999-12-31', 'yyyy-mm-dd')
       AND hub_dim_business_service.source_key = coalesce(subs_act.serv_id,'-1') || '#' || coalesce(subs_act.tech_id,'-1')

       JOIN
       dim_connected_service dim_connected_service1
         ON dim_connected_service1.src_id between 27 and 39
         AND split_part(dim_connected_service1.source_subs_key, ';', 2) = subs_act.subs_id

where subs_act.mrf_id = 14 and 154 = 154) A
where rn = 1;


/*edw_stg_dmcm.pre_ota_abn_subs_act_kurs_stg_1_PRT_P000154*/
INSERT INTO edw_stg_dmcm.PRE_OTA_ABN_SUBS_ACT_STG_1_PRT_P000154
(abn_id,
 subs_id,
 rf_id,
 mrf_id,
 src_id,
 account,
 serv_id,
 tech_id,
 subs_key,
 src_id_ekhd,
 cl_id,
 adress,
 account_key,
 business_service_key,
 load_dttm)
  WITH dim_connected_service AS
  (
    SELECT
      dim_connected_service.exp_dttm                              AS exp_dttm_dcs,
      dim_connected_service.eff_dttm                              AS eff_dttm_dcs,
      dim_service.exp_dttm                                        AS exp_dttm_ds,
      dim_service.eff_dttm                                        AS eff_dttm_ds,
      dim_connected_service.subs_key,
      dim_service.business_service_key,
      dim_connected_service.account_key,
      dim_connected_service.start_date,
      dim_connected_service.end_date,
      dim_connected_service.subs_code,
      dim_connected_service.src_id,
      hub_dim_subscribers.source_key                              AS source_subs_key,
      hub_dim_connected_service.source_key                        AS source_key_connected_service_key,
      split_part ( hub_dim_subscribers.source_key, chr ( 9 ), 1 ) AS source_subs_key_ural,
      split_part ( hub_dim_subscribers.source_key, chr ( 9 ), 2 ) AS source_subs_key_sz,
      split_part ( hub_dim_subscribers.source_key, ';', 2 )       AS source_subs_key_kurs_stg1
    FROM edw_dds.dim_connected_service dim_connected_service
      LEFT JOIN edw_dds.hub_dim_connected_service
        ON dim_connected_service.connected_service_key = hub_dim_connected_service.connected_service_key
           AND dim_connected_service.src_id = hub_dim_connected_service.src_id
      LEFT JOIN edw_dds.hub_dim_subscribers
        ON dim_connected_service.subs_key = hub_dim_subscribers.subs_key
           AND dim_connected_service.src_id = hub_dim_connected_service.src_id
      LEFT JOIN edw_dds.dim_service dim_service
        ON dim_service.service_key = dim_connected_service.service_key
           AND date_trunc ( 'day', dim_service.exp_dttm ) = to_date ( '2999-12-31', 'yyyy-mm-dd' )
    WHERE date_trunc ( 'day', dim_connected_service.exp_dttm ) = to_date ( '2999-12-31', 'yyyy-mm-dd' )
          AND
          dim_service.business_service_key IN ( 10101, 10102, 10103, 10104, 10105, 10106, 10107, 10108, 10109, 10199 )
  )
  SELECT
    abn_id,
    subs_id,
    rf_id,
    mrf_id,
    src_id,
    nls AS account,
    serv_id,
    tech_id,
    subs_key,
    src_id_ekhd,
    cl_id,
    adress,
    account_key,
    business_service_key,
    current_date
  FROM (
         SELECT
           subs_act.abn_id,
           subs_act.subs_id,
           subs_act.rf_id,
           subs_act.mrf_id,
           subs_act.src_id,
           sa.nls,
           subs_act.SERV_ID,
           subs_act.TECH_ID,
           dim_connected_service1.subs_key,
           dim_connected_service1.src_id AS src_id_ekhd,
           subs_act.cl_id,
           subs_act.adress,
           dim_connected_service1.account_key,
           hub_dim_business_service.business_service_key,
           row_number ( )
           OVER (
             PARTITION BY dim_connected_service1.subs_key
             ORDER BY CASE WHEN hub_dim_business_service.business_service_key IN
                                ( 10101, 10102, 10103, 10104, 10105, 10106, 10107, 10108, 10109, 10199 )
               THEN 0
                      ELSE 1 END,
               subs_act.date_snap DESC,
               subs_act.log_id DESC )    AS rn
         FROM edw_ods.T_000154_rprtsubscribersactual subs_act           -- lol 154
         LEFT JOIN
         (
         SELECT
         account, nls,
         row_number() OVER (
         PARTITION BY account
         ORDER BY COALESCE (date_end, to_date('29991231', 'yyyymmdd')) DESC, date_begin DESC
                           ) AS rn
                             FROM edw_ods.t_000158_efftp_south_nls_accnt
         ) sa
           ON sa.account = subs_act.account
           AND sa.rn = 1
               JOIN
               edw_dds.hub_dim_business_service hub_dim_business_service
         ON hub_dim_business_service.src_id = 158
         AND date_trunc('day', hub_dim_business_service.exp_dttm) = to_date('2999-12-31', 'yyyy-mm-dd')
         AND hub_dim_business_service.source_key = COALESCE (subs_act.serv_id, '-1') || '#' || COALESCE (subs_act.tech_id, '-1')

         JOIN
         dim_connected_service dim_connected_service1
         ON dim_connected_service1.src_id BETWEEN 27 AND 39
                                                         AND split_part(source_key_connected_service_key, ';', 2) = subs_act.subs_id

                                                                                                                  WHERE subs_act.mrf_id = 14 AND 154 = 154 ) A
  WHERE rn = 1;
ANALYSE edw_stg_dmcm.PRE_OTA_ABN_SUBS_ACT_STG_1_PRT_P000154;


TRUNCATE TABLE edw_stg_dmcm.PRE_OTA_ABN_SUBS_SOO_EKHD_STG_1_PRT_P000154;
INSERT INTO edw_stg_dmcm.PRE_OTA_ABN_SUBS_SOO_EKHD_STG_1_PRT_P000154
(
  abn_id,
  subs_id,
  rf_id,
  mrf_id,
  src_id,
  account,
  serv_id,
  tech_id,
  subs_key,
  src_id_ekhd,
  cl_id,
  adress,
  account_key,
  load_dttm
)
  SELECT
    subs_all.abn_id,
    subs_all.subs_id,
    dim_branch.branch_key AS rf_id,
    CASE
    WHEN dim_branch.parent_branch_key = -1
      THEN dim_branch.branch_key
    ELSE dim_branch.parent_branch_key
    END                   AS mrf_id,
    subs_all.src_id,
    subs_all.account,
    subs_all.serv_id,
    subs_all.tech_id,
    subs_all.subs_key,
    subs_all.src_id_ekhd,
    subs_all.cl_id,
    subs_all.adress,
    subs_all.account_key,
    current_date
  FROM
    edw_stg_dmcm.PRE_OTA_ABN_SUBS_ACT_STG_1_PRT_P000154 subs_all
    LEFT JOIN
    edw_dds.hub_dim_branch hub_dim_branch
      ON date_trunc ( 'day', hub_dim_branch.exp_dttm ) = to_date ( '2999-12-31', 'yyyy-mm-dd' )
         AND hub_dim_branch.src_id = 158
         AND hub_dim_branch.source_key = subs_all.rf_id :: TEXT
    LEFT JOIN
    edw_dds.dim_branch
      ON date_trunc ( 'day', dim_branch.exp_dttm ) = to_date ( '2999-12-31', 'yyyy-mm-dd' )
         AND dim_branch.branch_key = hub_dim_branch.branch_key;
--15 090 347
ANALYSE edw_stg_dmcm.PRE_OTA_ABN_SUBS_SOO_EKHD_STG_1_PRT_P000154;

------------------------------------------------------------------------------------------------------------------------


TRUNCATE TABLE edw_stg_dmcm.PRE_OTA_ABN_PORT3_STG_1_PRT_P000154;
INSERT
INTO edw_stg_dmcm.PRE_OTA_ABN_PORT3_STG_1_PRT_P000154
(
  login,
  port_num,
  abn_id,
  rf_id,
  mrf_id,
  city_name,
  date_snap,
  port_usage,
  port_state,
  src_id,
  load_dttm
)
  SELECT
    login,
    port_num,
    abn_id,
    rf_id,
    mrf_id,
    city_name,
    date_snap,
    port_usage,
    port_state,
    154 :: SMALLINT,
    current_date
  FROM
    (
      SELECT
        port_num,
        abn_id,
        login,
        rf_id,
        mrf_id,
        city_name,
        date_snap,
        date_comm,
        port_usage,
        port_state,
        row_number ( )
        OVER (
          PARTITION BY abn_id
          ORDER BY
            CASE WHEN date_snap <= to_date ( '20190630', 'YYYYMMDD' )
              THEN 0
            ELSE 1 END,
            date_snap DESC,
            date_comm DESC
          ) AS rn
      FROM edw_ods.T_000154_rprt_tchncl_data_dwh -- lol 154
      WHERE tech_dt BETWEEN to_date ( '20190601', 'YYYYMMDD' ) AND to_date ( '20190630', 'YYYYMMDD' )
    ) port
  WHERE rn = 1;
ANALYSE edw_stg_dmcm.PRE_OTA_ABN_PORT3_STG_1_PRT_P000154;


TRUNCATE TABLE edw_stg_dmcm.PRE_OTA_ABN_TRAFFIC_TEL_STG_1_PRT_P000154;
INSERT INTO edw_stg_dmcm.PRE_OTA_ABN_TRAFFIC_TEL_STG_1_PRT_P000154
(abn_id
  , account_key
  , account
  , charge_code
  , period
  , date_snap
  , rf_id
  , mrf_id
  , traffic
  , load_dttm
  , src_id
)
  WITH dim_account AS (
    SELECT
      account_key,
      branch_key,
      exp_dttm
    FROM edw_dds.dim_account acc
    WHERE CASE
          WHEN 154 = 151
            THEN acc.src_id BETWEEN 48 AND 62
          WHEN 154 = 152
            THEN acc.src_id = 97
          WHEN 154 = 153
            THEN acc.src_id BETWEEN 1 AND 12
          WHEN 154 = 154
            THEN acc.src_id BETWEEN 27 AND 39
          WHEN 154 = 155
            THEN acc.src_id = 45
          WHEN 154 = 156
            THEN acc.src_id BETWEEN 80 AND 89
          WHEN 154 = 157
            THEN acc.src_id BETWEEN 107 AND 113
          END
          AND date_trunc ( 'day', acc.exp_dttm ) = to_date ( '2999-12-31', 'yyyy-mm-dd' )
          AND deleted_ind = 0
  ),
      dim_branch AS (
      SELECT
        branch_key,
        parent_branch_key
      FROM edw_dds.dim_branch
      WHERE date_trunc ( 'day', dim_branch.exp_dttm ) = to_date ( '2999-12-31', 'yyyy-mm-dd' )
    )
  SELECT
    coalesce(subs.abn_id, -1)                                      AS abn_id,
    tel.account_key                                                AS account_key,
    tel.period_account_name                                        AS account,
    rd.service_rtk_detail_code                                     AS charge_code,
    to_char ( date_trunc ( 'MONTH', tel.calendar_key ), 'yyyymm' ) AS period,
    tel.calendar_key                                               AS date_snap,
    dim_account.branch_key                                         AS rf_id,
    CASE
    WHEN dim_branch.parent_branch_key = -1
      THEN dim_branch.branch_key
    ELSE dim_branch.parent_branch_key
    END                                                            AS mrf_id,
    sum ( tel.total_call_dur_actually )                            AS traffic,
    current_date,
    154                                                    AS src_id
  FROM edw_ads.tfct_telephony_consumption tel
    LEFT JOIN edw_dds.dim_service_rtk_detail rd
      ON rd.service_rtk_detail_key = tel.service_rtk_detail_key
         AND tel.calendar_key BETWEEN rd.eff_dttm AND rd.exp_dttm
    LEFT JOIN dim_account
      ON dim_account.account_key = tel.account_key

    LEFT JOIN
    edw_stg_dmcm.PRE_OTA_ABN_SUBS_SOO_EKHD_STG_1_PRT_P000154 subs
      ON subs.subs_key = tel.subs_key
    LEFT JOIN
    dim_branch
      ON dim_branch.branch_key = tel.branch_key
    LEFT JOIN edw_dds.dim_segment ds
      ON ds.segment_key = tel.segment_key
         AND ds.deleted_ind = 0
         AND date_trunc ( 'day', ds.exp_dttm ) = to_date ( '29991231', 'yyyymmdd' )
  WHERE tel.calendar_key BETWEEN to_date ( '20190601', 'YYYYMMDD' ) AND to_date ( '20190630',
                                                                                         'YYYYMMDD' )
        AND CASE
            WHEN 154 = 151
              THEN tel.src_id BETWEEN 48 AND 62
            WHEN 154 = 152
              THEN tel.src_id = 97
            WHEN 154 = 153
              THEN tel.src_id BETWEEN 1 AND 12
            WHEN 154 = 154
              THEN tel.src_id BETWEEN 27 AND 39
            WHEN 154 = 155
              THEN tel.src_id = 45
            WHEN 154 = 156
              THEN tel.src_id BETWEEN 80 AND 89
            WHEN 154 = 157
              THEN tel.src_id BETWEEN 107 AND 113
            END
        AND ( subs.abn_id IS NOT NULL OR ds.segment_name NOT LIKE 'K04%' )

  GROUP BY
    coalesce(subs.abn_id, -1),
    tel.account_key,
    tel.period_account_name,
    rd.service_rtk_detail_code,
    date_trunc ( 'MONTH' :: TEXT, tel.calendar_key ),
    tel.calendar_key,
    dim_account.branch_key,
    CASE
    WHEN dim_branch.parent_branch_key = -1
      THEN dim_branch.branch_key
    ELSE dim_branch.parent_branch_key
    END;
ANALYSE edw_stg_dmcm.PRE_OTA_ABN_TRAFFIC_TEL_STG_1_PRT_P000154;


TRUNCATE TABLE edw_stg_dmcm.PRE_OTA_ABN_TRAFFIC_CHRG_STG_1_PRT_P000154;
INSERT INTO edw_stg_dmcm.PRE_OTA_ABN_TRAFFIC_CHRG_STG_1_PRT_P000154
(abn_id
  , account_key
  , account
  , charge_code
  , period
  , date_snap
  , rf_id
  , mrf_id
  , charge
  , load_dttm
  , src_id
)
  WITH
      hdb AS (
      SELECT
        branch_key,
        source_key
      FROM edw_dds.hub_dim_branch
      WHERE date_trunc ( 'day', exp_dttm ) = to_date ( '2999-12-31', 'yyyy-mm-dd' )
            AND src_id = 158),
      dim_branch AS (
      SELECT
        branch_key,
        parent_branch_key
      FROM edw_dds.dim_branch
      WHERE date_trunc ( 'day', exp_dttm ) = to_date ( '2999-12-31', 'yyyy-mm-dd' )
    ),
      sa AS (
      SELECT
        account,
        nls
      FROM (
             SELECT
               account,
               nls,
               row_number ( )
               OVER (
                 PARTITION BY account
                 ORDER BY COALESCE ( date_end, to_date ( '29991231', 'yyyymmdd' ) ) DESC, date_begin DESC
                 ) AS rn
             FROM edw_ods.t_000158_efftp_south_nls_accnt
           ) P
      WHERE p.rn = 1
    ),
      dim_account AS (
      SELECT
        account_name,
        account_key,
        branch_key,
        exp_dttm
      FROM edw_dds.dim_account acc
      WHERE CASE
            WHEN 154 = 151
              THEN acc.src_id BETWEEN 48 AND 62
            WHEN 154 = 152
              THEN acc.src_id = 97
            WHEN 154 = 153
              THEN acc.src_id BETWEEN 1 AND 12
            WHEN 154 = 154
              THEN acc.src_id BETWEEN 27 AND 39
            WHEN 154 = 155
              THEN acc.src_id = 45
            WHEN 154 = 156
              THEN acc.src_id BETWEEN 80 AND 89
            WHEN 154 = 157
              THEN acc.src_id BETWEEN 107 AND 113
            END
            AND date_trunc ( 'day', acc.exp_dttm ) = to_date ( '2999-12-31', 'yyyy-mm-dd' )
            AND deleted_ind = 0
    )
  SELECT
    coalesce(chrg.abn_id, -1)              AS abn_id,
    dim_account.account_key                AS account_key,
    CASE WHEN chrg.mrf_id = 14
      THEN sa.nls
    ELSE chrg.account
    END                                    AS account,
    chrg.charge_code                       AS charge_code,
    to_char ( chrg.period,
              'yyyymm' )                   AS period,
    ( date_trunc ( 'MONTH' :: TEXT, chrg.period :: DATE ) +
      INTERVAL '1 MONTH - 1 day' ) :: DATE AS date_snap,
    hdb.branch_key                         AS rf_id,
    CASE
    WHEN dim_branch.parent_branch_key = -1
      THEN dim_branch.branch_key
    ELSE dim_branch.parent_branch_key
    END                                    AS mrf_id,
    sum ( chrg.charge -
          chrg.vat_amount )                AS charge,
    current_date,
    154                            AS src_id
  FROM edw_ods.T_000154_rprt_charges_dwh chrg  -- lol 154
    LEFT JOIN
    hdb
      ON hdb.source_key = chrg.rf_id :: TEXT
    LEFT JOIN
    dim_branch
      ON dim_branch.branch_key = hdb.branch_key
    LEFT JOIN
    sa
      ON sa.account = chrg.account
    LEFT JOIN
    dim_account
      ON dim_account.account_name = chrg.account
  WHERE ( CHARGE_CODE IN
          ( 'R0401011011', 'R0401011012', 'R0401011031', 'R0401011032', 'R0401011033', 'R0401011034', 'R0401011035',
                           'R0401011041', 'R0401011042', 'R0401011043', 'R0401011044', 'R0401011045', 'R0401011046', 'R0401011047',
                                                                                       'R0401011048', 'R040101199', 'R0401012', 'R0401021011', 'R0401021012', 'R0401021031', 'R0401021032',
            'R0401021033', 'R0401021034', 'R0401021035', 'R0401021041', 'R0401021042', 'R0401021043', 'R0401021044',
            'R0401021045', 'R0401021046', 'R0401021047', 'R0401021048', 'R040102199' )
          OR substr ( CHARGE_CODE, 1, 5 ) IN ( 'R0101', 'R0201', 'R0301' ) )
        AND chrg.coef_r12 = 1
        AND chrg.period BETWEEN to_date ( '20190601', 'YYYYMMDD' ) AND to_date ( '20190630',
                                                                                        'YYYYMMDD' )
  GROUP BY
    coalesce(chrg.abn_id, -1),
    dim_account.account_key,
    CASE WHEN chrg.mrf_id = 14
      THEN sa.nls
    ELSE chrg.account
    END,
    chrg.charge_code,
    to_char ( chrg.period, 'yyyymm' ),
    ( date_trunc ( 'MONTH' :: TEXT, chrg.period :: DATE ) + INTERVAL '1 MONTH - 1 day' ),
    hdb.branch_key,
    CASE
    WHEN dim_branch.parent_branch_key = -1
      THEN dim_branch.branch_key
    ELSE dim_branch.parent_branch_key END;
ANALYSE edw_stg_dmcm.PRE_OTA_ABN_TRAFFIC_CHRG_STG_1_PRT_P000154;


TRUNCATE TABLE edw_stg_dmcm.PRE_OTA_ABN_TRAFFIC_STG_1_PRT_P000154;
INSERT INTO edw_stg_dmcm.PRE_OTA_ABN_TRAFFIC_STG_1_PRT_P000154
(
  abn_id,
  src_id,
  account_key,
  account,
  charge_code,
  period,
  date_snap,
  rf_id,
  mrf_id,
  traffic,
  charge,
  load_dttm
)
  SELECT
    coalesce ( tel.abn_id, chrg.abn_id )           AS abn_id,
    154 :: SMALLINT                         AS src_id,
    coalesce ( tel.account_key, chrg.account_key ) AS account_key,
    coalesce ( tel.account, chrg.account )         AS account,
    coalesce ( tel.charge_code, chrg.charge_code ) AS charge_code,
    coalesce ( tel.period, chrg.period )           AS period,
    coalesce ( tel.date_snap, chrg.date_snap )     AS date_snap,
    coalesce ( tel.rf_id, chrg.rf_id )             AS rf_id,
    coalesce ( tel.mrf_id, chrg.mrf_id )           AS mrf_id,
    tel.traffic                                    AS traffic,
    chrg.charge                                    AS charge,
    current_date

  FROM edw_stg_dmcm.PRE_OTA_ABN_TRAFFIC_TEL_STG_1_PRT_P000154 tel
    FULL OUTER JOIN edw_stg_dmcm.PRE_OTA_ABN_TRAFFIC_CHRG_STG_1_PRT_P000154 chrg
      ON tel.abn_id = chrg.abn_id
         AND tel.account = chrg.account
         AND tel.date_snap = chrg.date_snap
         AND tel.charge_code = chrg.charge_code;
ANALYSE edw_stg_dmcm.PRE_OTA_ABN_TRAFFIC_STG_1_PRT_P000154;


SET optimizer = ON;
TRUNCATE TABLE edw_stg_dmcm.PRE_OTA_ABN_DATE_START_STG_1_PRT_P000154;
INSERT INTO edw_stg_dmcm.PRE_OTA_ABN_DATE_START_STG_1_PRT_P000154
(abn_id
 --  , mrf_id
  , date_start
  , load_dttm
  , src_id
)
  SELECT
    chrg.abn_id    AS abn_id,
    min ( period ) AS date_start,
    current_date,
    154    AS src_id
  FROM edw_ods.T_000154_rprt_charges_dwh chrg -- lol 154
  WHERE ( CHARGE_CODE IN
          ( 'R0401011011', 'R0401011012', 'R0401011031', 'R0401011032', 'R0401011033', 'R0401011034', 'R0401011035',
                           'R0401011041', 'R0401011042', 'R0401011043', 'R0401011044', 'R0401011045', 'R0401011046', 'R0401011047',
                                                                                       'R0401011048', 'R040101199', 'R0401012', 'R0401021011', 'R0401021012', 'R0401021031', 'R0401021032',
            'R0401021033', 'R0401021034', 'R0401021035', 'R0401021041', 'R0401021042', 'R0401021043', 'R0401021044',
            'R0401021045', 'R0401021046', 'R0401021047', 'R0401021048', 'R040102199' )
          OR substr ( CHARGE_CODE, 1, 5 ) IN ( 'R0101', 'R0201', 'R0301' ) )
        AND chrg.coef_r12 = 1
  GROUP BY
    chrg.abn_id;


INSERT INTO edw_stg_dmcm.PRE_OTA_ABN_DATE_START_STG_1_PRT_P000154
(abn_id
 --  , mrf_id
  , date_start
  , load_dttm
  , src_id
)
  SELECT
    subs.abn_id             AS abn_id,
    min ( call_start_dttm ) AS date_start,
    current_date,
    154             AS src_id
  FROM edw_dds.tfct_telephony_consumption tel
    LEFT JOIN
    edw_stg_dmcm.pre_ota_abn_subs_soo_ekhd_stg_1_PRT_P000154 subs
      ON subs.subs_key = tel.subs_key
  WHERE CASE
        WHEN 154 = 151
          THEN tel.src_id BETWEEN 48 AND 62
        WHEN 154 = 152
          THEN tel.src_id = 97
        WHEN 154 = 153
          THEN tel.src_id BETWEEN 1 AND 12
        WHEN 154 = 154
          THEN tel.src_id BETWEEN 27 AND 39
        WHEN 154 = 155
          THEN tel.src_id = 45
        WHEN 154 = 156
          THEN tel.src_id BETWEEN 80 AND 89
        WHEN 154 = 157
          THEN tel.src_id BETWEEN 107 AND 113
        END
  GROUP BY
    subs.abn_id;
ANALYSE edw_stg_dmcm.PRE_OTA_ABN_DATE_START_STG_1_PRT_P000154;


TRUNCATE TABLE edw_stg_dmcm.PRE_OTA_ABN_DATE_START_MIN_STG_1_PRT_P000154;
INSERT INTO edw_stg_dmcm.PRE_OTA_ABN_DATE_START_MIN_STG_1_PRT_P000154
(abn_id
 --  , mrf_id
  , date_start
  , load_dttm
  , src_id
)
  SELECT
    abn_id,
    -- mrf_id,
    min ( date_start ) AS date_start,
    current_date,
    154        AS src_id
  FROM edw_stg_dmcm.pre_ota_abn_date_start_stg_1_PRT_P000154
  GROUP BY abn_id, mrf_id;
ANALYSE edw_stg_dmcm.PRE_OTA_ABN_DATE_START_MIN_STG_1_PRT_P000154;

TRUNCATE TABLE edw_stg_dmcm.TFCT_OTA_ABN_1_PRT_P000154;
INSERT INTO edw_stg_dmcm.TFCT_OTA_ABN_1_PRT_P000154
(period
  , date_snap
  , mrf
  , rf
  , id_rf
  , locality_name
  , street_name
  , house_number
  , address
  , orpon_id
  , okn
  , okved
  , account
  , account_key
  , inn
  , client_name
  , k_code
  , segment
  , id_macro_segment
  , special_usr_attr
  , migration_attr
  , inv_project_code
  , login
  , port_num
  , date_start
  , port_state
  , rtpl_name
  , charge
  , traffic
  , dz_sum
  , dz_date
  , cfo
  , abn_id
  , charge_code
  , tech_name
  , tp_start
  , src_id
  , load_dttm)
  WITH w_vrate_plans_dwh AS
  (
    SELECT
      tbl.rtpl_name,
      tbl.date_start                                                AS tp_start,
      to_char ( to_date ( '20190630', 'YYYYMMDD' ), 'YYYYMM' ) AS period,
      coalesce ( tbl.speed, tbl.speed_min )                         AS speed,
      coalesce ( tbl.tech_id, tbl.tech_id_min )                     AS tech_id,
      coalesce ( tbl.start_rtpl, tbl.start_rtpl_min )               AS start_rtpl,
      tbl.abn_id
    FROM (
           SELECT
             v.rtpl_name,
             v.date_start,
             v.speed,
             v.tech_id,
             v.start_rtpl,
             v.abn_id,
             min ( v.start_rtpl )
             OVER (
               PARTITION BY v.abn_id ) AS start_rtpl_min,
             min ( v.tech_id )
             OVER (
               PARTITION BY v.abn_id ) AS tech_id_min,
             min ( v.speed )
             OVER (
               PARTITION BY v.abn_id ) AS speed_min,
             row_number ( )
             OVER (
               PARTITION BY v.abn_id
               ORDER BY CASE WHEN v.date_start <= to_date ( '20190630', 'YYYYMMDD' )
                 THEN 0
                        ELSE 1 END,
                 CASE WHEN hub_dim_business_service.business_service_key IN
                           ( 10101, 10102, 10103, 10104, 10105, 10106, 10107, 10108, 10109, 10199 )
                   THEN 0
                 ELSE 1 END,
                 v.date_start DESC
               )                       AS rn
           FROM edw_ods.T_000154_rprt_vrate_plans_dwh v  -- lol 154
             JOIN
             edw_dds.hub_dim_business_service hub_dim_business_service
               ON hub_dim_business_service.src_id = 158
                  AND date_trunc ( 'day', hub_dim_business_service.exp_dttm ) = to_date ( '2999-12-31', 'yyyy-mm-dd' )
                  AND hub_dim_business_service.source_key =
                      COALESCE ( v.serv_id, '-1' ) || '#' || COALESCE ( v.tech_id, '-1' )
         ) tbl
    WHERE tbl.rn = 1
  ),
      w_oo_address AS
    (
      SELECT
        postoffice_id || CASE WHEN postoffice_id IS NOT NULL
          THEN ', '
                         ELSE '' END
        || terr_type || CASE WHEN terr_type IS NOT NULL
          THEN ' '
                        ELSE '' END
        || name_terr || CASE WHEN coalesce ( terr_type, name_terr ) IS NOT NULL
          THEN ', '
                        ELSE '' END
        || city || CASE WHEN city IS NOT NULL
          THEN ', '
                   ELSE '' END
        || name_street_type || CASE WHEN name_street_type IS NOT NULL
          THEN ' '
                               ELSE '' END
        || name_street || CASE WHEN coalesce ( name_street_type, name_street ) IS NOT NULL
          THEN ', '
                          ELSE '' END
        || house AS address,
        house_lid,
        house_gid,
        city,
        name_street,
        house,
        mrf_id
      FROM edw_ods.T_000154_rprt_oo_address            -- lol 154
    ),
      w_subscribersdetal AS
    (
      SELECT
        abn_id,
        mrf_id,
        flag_mgr,
        rn
      FROM
        (
          SELECT
            abn_id,
            mrf_id,
            flag_mgr,
            row_number ( )
            OVER (
              PARTITION BY abn_id, mrf_id
              ORDER BY CASE WHEN dt_end IS NULL
                THEN '2999-12-31 00:00:00'
                       ELSE dt_end END DESC,
                CASE WHEN dt_start IS NULL
                  THEN '2999-12-31 00:00:00'
                ELSE dt_start END DESC ) rn
          FROM edw_ods.T_000154_rprt_subscribersdetal      -- lol 154
        ) r
      WHERE r.rn = 1
    ),
      w_oo_addressabndwh AS
    (
      SELECT
        abn_id,
        mrf_id,
        house_lid,
        flat,
        rn
      FROM
        (
          SELECT
            abn_id,
            mrf_id,
            house_lid,
            flat,
            row_number ( )
            OVER (
              PARTITION BY abn_id, mrf_id
              ORDER BY CASE WHEN date_end IS NULL
                THEN '2999-12-31 00:00:00'
                       ELSE date_end END DESC,
                CASE WHEN date_begin IS NULL
                  THEN '2999-12-31 00:00:00'
                ELSE date_begin END DESC ) rn
          FROM edw_ods.T_000154_rprt_oo_addressabndwh    -- lol 154
        ) a
      WHERE a.rn = 1
    ),
      w_inv_charges_abn_view_b2b AS
    (
      SELECT
        abn_id,
        mrf_id,
        period,
        invest_pr,
        cfo,
        charge_code,
        charge_code_detal,
        rn
      FROM
        (
          SELECT
            abn_id,
            mrf_id,
            period,
            invest_pr,
            cfo,
            charge_code,
            charge_code_detal,
            row_number ( )
            OVER (
              PARTITION BY abn_id, mrf_id, period
              ORDER BY CASE WHEN invest_pr IS NULL
                THEN 1
                       ELSE 0 END,
                CASE WHEN cfo IS NULL
                  THEN 1
                ELSE 0 END ) AS rn
          FROM edw_ods.T_000154_inv_charges_abn_view_b2b -- lol 154
          WHERE ( CHARGE_CODE IN
                  ( 'R0401011011', 'R0401011012', 'R0401011031', 'R0401011032', 'R0401011033', 'R0401011034', 'R0401011035',
                                   'R0401011041', 'R0401011042', 'R0401011043', 'R0401011044', 'R0401011045', 'R0401011046', 'R0401011047',
                                                                                               'R0401011048', 'R040101199', 'R0401012', 'R0401021011', 'R0401021012', 'R0401021031', 'R0401021032',
                    'R0401021033', 'R0401021034', 'R0401021035', 'R0401021041', 'R0401021042', 'R0401021043', 'R0401021044',
                    'R0401021045', 'R0401021046', 'R0401021047', 'R0401021048', 'R040102199' )
                  OR substr ( CHARGE_CODE, 1, 5 ) IN ( 'R0101', 'R0201', 'R0301' )
                  OR charge_code_detal IN
                     ( 'R0401011011', 'R0401011012', 'R0401011031', 'R0401011032', 'R0401011033', 'R0401011034', 'R0401011035',
                                      'R0401011041', 'R0401011042', 'R0401011043', 'R0401011044', 'R0401011045', 'R0401011046', 'R0401011047',
                                                                                                  'R0401011048', 'R040101199', 'R0401012', 'R0401021011', 'R0401021012', 'R0401021031', 'R0401021032',
                       'R0401021033', 'R0401021034', 'R0401021035', 'R0401021041', 'R0401021042', 'R0401021043', 'R0401021044',
                       'R0401021045', 'R0401021046', 'R0401021047', 'R0401021048', 'R040102199' ) )
                AND period = to_char ( to_date ( '20190630', 'YYYYMMDD' ), 'YYYYMM' )
        ) inv
      WHERE inv.rn = 1
    ),
    scor as (
      SELECT
        CAST ( db.user_id AS VARCHAR(100) ) AS user_id,
        CAST ( db.period AS VARCHAR(6) )    AS period,
        sum ( db.overdue_deb )              AS dz_sum,
        max ( db.date_planed )              AS dz_date,
        db.mrf_id
      FROM edw_ods.t_000159_debt_dwh db
      WHERE db.overdue_deb > 0
            AND db.period :: TEXT = to_char ( to_date ( '20190630', 'YYYYMMDD' ), 'YYYYMM' )
      GROUP BY db.user_id, db.period, db.mrf_id
    ),
    addr_okn as (
      select * from (
        SELECT
          house_lid,
          mrf_id,
          globalid,
          okn_area,
          addr_okn.globalid :: TEXT as globalid__,
          row_number ( )
          OVER (
            PARTITION BY house_lid, mrf_id ) rn
        FROM edw_ods.t_000158_address_okn addr_okn
        WHERE house_lid IS NOT NULL
      ) Q where q.rn = 1
    ),
    org as (
      select * from (
        SELECT
          inn,
          okved,
          row_number ( )
          OVER (
            PARTITION BY inn
            ORDER BY date_start DESC, update_snap DESC ) AS rn
        FROM edw_ods.t_000158_budget_org_detail
        WHERE date_end = to_date ( '2999-12-31', 'yyyy-mm-dd' )
      ) Q where q.rn = 1
    ),
  w_sa AS
  (
   SELECT account, nls FROM (
    SELECT
      account,
      nls,
      row_number ( )
      OVER (
        PARTITION BY account
        ORDER BY COALESCE ( date_end, to_date ( '29991231', 'yyyymmdd' ) ) DESC, date_begin DESC
        ) AS rn
    FROM edw_ods.t_000158_efftp_south_nls_accnt) a
   WHERE rn = 1
  ),
  w_cl2 AS
  (
    SELECT account, id_macro_segment_ud, contr_name, inn
    FROM
    (
        SELECT
          CASE WHEN c.mrf_id = 14 THEN sa.nls ELSE c.account END AS account,
          id_macro_segment_ud,
          contr_name,
          inn,
          row_number() OVER (
            PARTITION BY CASE WHEN c.mrf_id = 14 THEN sa.nls ELSE c.account END
            ORDER BY CASE WHEN c.date_snap <= to_date('20190630', 'YYYYMMDD') THEN 0 ELSE 1 END, c.date_snap DESC) AS rn
        FROM edw_ods.T_000154_rprt_client_dwh c  -- lol154
             LEFT JOIN
             w_sa sa
               ON sa.account = c.account
               AND c.mrf_id = 14
    ) c
    WHERE rn = 1
  )
  SELECT
    tel.period                                        AS period,
    tel.date_snap                                     AS date_snap,
    CASE
    WHEN dbr.parent_branch_key = -1
      THEN dbr.branch_name
    ELSE pdbr.branch_name
    END                                               AS mrf,
    dbr.branch_name                                   AS rf,
    tel.rf_id                                         AS id_rf,
    addr.city                                         AS locality_name,
    addr.name_street                                  AS street_name,
    addr.house                                        AS house_number,
    coalesce ( addr.address ||
               CASE
               WHEN addr_abn.flat IS NULL
                 THEN ''
               ELSE ', '
               END || coalesce ( addr_abn.flat, '' ),
               subs.adress_dev )                      AS address,
    addr.house_gid                                    AS orpon_id,
    addr_okn.okn_area                                 AS okn,
    org.okved                                         AS okved,
    coalesce ( tel.account, '0' )                     AS account,
    coalesce ( tel.account_key :: NUMERIC(22, 0), 0 ) AS account_key,
    coalesce(cl.inn, cl2.inn)                         AS inn,
    coalesce(cl.contr_name, cl2.contr_name)           AS client_name,
    CASE WHEN (nm.macro_segment is null or nm.macro_segment like 'К04%')
                      AND (length(coalesce(cl.inn, cl2.inn)) = 10
                             OR lower(coalesce(cl.contr_name, cl2.contr_name)) LIKE 'ип %'
                             OR lower(coalesce(cl.contr_name, cl2.contr_name)) LIKE '%индивидуальный предприниматель%')
                 THEN 'К02'
            ELSE coalesce(nm.macro_segment, '')
          END                                         AS k_code,
    nm.name_microsegment                              AS segment,
    coalesce(cl.id_macro_segment_ud, cl2.id_macro_segment_ud, 0) AS id_macro_segment,
    CASE WHEN nm.macro_segment IN ( 'K0102', 'K0104' )
      THEN 1
    ELSE 0
    END                                               AS special_usr_attr,
    coalesce ( subs_det.flag_mgr, 0 )                 AS migration_attr,
    inv.invest_pr                                     AS inv_project_code,
    prt.login                                         AS login,
    prt.port_num                                      AS port_num,
    dsm.date_start                                    AS date_start,
    prt.port_state                                    AS port_state,
    pln.rtpl_name                                     AS rtpl_name,
    coalesce ( tel.charge, 0 )                        AS charge,
    coalesce ( tel.traffic, 0 )                       AS traffic,
    scor.dz_sum                                       AS dz_sum,
    scor.dz_date                                      AS dz_date,
    inv.cfo :: NUMERIC(22, 0)                         AS cfo,
    coalesce(tel.abn_id, -1)                          AS abn_id,
    tel.charge_code                                   AS charge_code,
    CASE WHEN position ( 'DSL' IN upper ( pln.rtpl_name ) ) > 0
      THEN 'xDSL'
    WHEN position ( 'PON' IN upper ( pln.rtpl_name ) ) > 0
      THEN 'PON'
    WHEN position ( 'FTTX' IN upper ( pln.rtpl_name ) ) > 0
      THEN 'FTTx'
    WHEN position ( 'DOCSIS' IN upper ( pln.rtpl_name ) ) > 0
      THEN 'DOCSIS'
    WHEN position ( 'ETTH' IN upper ( pln.rtpl_name ) ) > 0
      THEN 'ETTH'
    WHEN position ( 'ETHERNET' IN upper ( pln.rtpl_name ) ) > 0
      THEN 'ETTH'
    ELSE tch.def
    END                                               AS tech_name,
    pln.tp_start                                      AS tp_start,
    154                                       AS src_id,
    current_date
  FROM edw_stg_dmcm.PRE_OTA_ABN_TRAFFIC_STG_1_PRT_P000154 tel
    LEFT JOIN
    edw_ods.T_000154_rprtsubscribersactual subs    -- lol 154
      ON subs.abn_id = tel.abn_id
    LEFT JOIN
    edw_stg_dmcm.PRE_OTA_ABN_PORT3_STG_1_PRT_P000154 prt
      ON prt.abn_id = tel.abn_id
    LEFT JOIN
    edw_dds.dim_branch dbr
      ON tel.rf_id = dbr.branch_key
         AND date_trunc ( 'day', dbr.exp_dttm ) = to_date ( '2999-12-31', 'yyyy-mm-dd' )
    LEFT JOIN
    edw_dds.dim_branch pdbr
      ON pdbr.branch_key = dbr.parent_branch_key
         AND date_trunc ( 'day', pdbr.exp_dttm ) = to_date ( '2999-12-31', 'yyyy-mm-dd' )
    LEFT JOIN
    w_inv_charges_abn_view_b2b inv
      ON inv.abn_id = tel.abn_id
         AND inv.period = tel.period
         AND inv.mrf_id = tel.mrf_id
         AND ( inv.charge_code = tel.charge_code OR inv.charge_code_detal = tel.charge_code )
    LEFT JOIN
    w_oo_addressabndwh addr_abn
      ON addr_abn.abn_id = tel.abn_id
         AND addr_abn.mrf_id = subs.mrf_id
    LEFT JOIN
    w_oo_address addr
      ON addr.house_lid = addr_abn.house_lid
         AND addr.mrf_id = addr_abn.mrf_id
    LEFT JOIN
    w_subscribersdetal subs_det
      ON subs_det.abn_id = tel.abn_id
         AND subs_det.mrf_id = subs.mrf_id
    LEFT JOIN
     scor
      ON user_id = subs.org_subs_id
         AND scor.mrf_id = subs.mrf_id
         AND scor.period = tel.period
    LEFT JOIN
     addr_okn
      ON ( addr_okn.house_lid = addr_abn.house_lid
           OR ( addr_okn.house_lid IS NULL AND addr_okn.globalid__ = addr.house_gid ) )
         AND addr_okn.mrf_id = addr_abn.mrf_id
    LEFT JOIN
    w_vrate_plans_dwh pln
      ON pln.abn_id = tel.abn_id
    LEFT JOIN
    edw_ods.T_000154_rprt_client_dwh cl    -- lol 154
      ON cl.cl_id = subs.cl_id
    LEFT JOIN
    w_cl2 cl2
      ON cl2.account = tel.account
    LEFT JOIN
    edw_ods.t_000158_rprt_dird_macro_sgmnt nm
      ON nm.id_macro_segment = coalesce(cl.id_macro_segment_ud, cl2.id_macro_segment_ud, 0)
    LEFT JOIN
    edw_ods.t_000158_rprt_dir_tech tch
      ON tch.tech_id = COALESCE ( subs.tech_id, pln.tech_id )
    LEFT JOIN
     org
      ON org.inn = coalesce(cl.inn, cl2.inn)
    LEFT JOIN
    edw_stg_dmcm.PRE_OTA_ABN_DATE_START_MIN_STG_1_PRT_P000154 dsm
      ON dsm.abn_id = tel.abn_id
  WHERE (CASE WHEN ( nm.macro_segment is null or nm.macro_segment like 'К04%')
                      AND (length(coalesce(cl.inn, cl2.inn)) = 10
                             OR lower(coalesce(cl.contr_name, cl2.contr_name)) LIKE 'ип %'
                             OR lower(coalesce(cl.contr_name, cl2.contr_name)) LIKE '%индивидуальный предприниматель%')
                 THEN 'К02'
            ELSE coalesce(nm.macro_segment, '')
          END) NOT LIKE 'K04%';

ANALYZE edw_stg_dmcm.TFCT_OTA_ABN_1_PRT_P000154;