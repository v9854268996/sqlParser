/*rev.18948 22.11.2018*/
	delete from edw_stg_mdm.put_xref_dim_oebs_r12_branch_ruz where src_id = 158;
	insert into edw_stg_mdm.put_xref_dim_oebs_r12_branch_ruz
	(
		source_key
		,branch_name
		,src_id
		,load_dttm
	)
	select 
		brnc_id
		,def
		,158::int as src_id
		,now()
	from edw_ods.t_000158_rprt_dir_branches;
	commit;
	analyse edw_stg_mdm.put_xref_dim_oebs_r12_branch_ruz;
	