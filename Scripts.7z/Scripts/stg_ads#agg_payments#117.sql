/*rev.34588 31.07.2019 Changed by: NAREK.ALAVERDYAN */
		--AGG_PAYMENTS
		truncate table edw_stg_ads.agg_payments_1_prt_p000117;
		insert into edw_stg_ads.agg_payments_1_prt_p000117
		(
			calendar_key,
			year_month_key,
			adjust_period,
			adjust_type_key,
			center_num_key,
			duty_num_key,
			segment_key,
			branch_key,
			region_key,
			payment_rub,
			adjust_rub,
			src_id,
			load_dttm,
			md5
		)

		Select 
			calendar_key,
			year_month_key,
			adjust_period,
			adjust_type_key,
			center_num_key,
			duty_num_key,
			segment_key,
			branch_key,
			region_key,
			payment_rub,
			adjust_rub,
			src_id,
			CURRENT_TIMESTAMP as load_dttm,
			MD5
				((((((((((((((
					COALESCE(year_month_key::text, ''::text)) || CHR(9)) || 
					COALESCE(center_num_key::text, ''::text)) || CHR(9)) || 
					COALESCE(duty_num_key::text, ''::text)) || CHR(9)) || 
					COALESCE(segment_key::text, ''::text)) || CHR(9)) || 
					COALESCE(branch_key::text, ''::text)) || CHR(9)) || 
					COALESCE(adjust_period::text, ''::text)) || CHR(9)) || 
					COALESCE(adjust_type_key::text, ''::text)) || CHR(9)
				) as md5 
		from (
		Select 
			date_trunc('month', calendar_key) + interval '1 month' + interval '-1 day' as calendar_key,
			year_month_key,
			adjust_period,
			adjust_type_key,
			center_num_key,
			duty_num_key,
			segment_key,
			branch_key,
			region_key,
			sum(payment_rub) as payment_rub,
			sum(adjust_rub) as adjust_rub,
			src_id
		From edw_stg_ads.tfct_payments_1_prt_p000117
		where src_id=117
			and calendar_key between date_trunc('month', to_date('20190601', 'YYYYMMDD'))
				and (date_trunc('month', to_date('20190630', 'YYYYMMDD')) + interval '1 month' + interval '-1 day')
		group by 
			date_trunc('month', calendar_key),
			year_month_key,
			adjust_period,
			adjust_type_key,
			center_num_key,
			duty_num_key,
			segment_key,
			branch_key,
			region_key,
			src_id
		) total;

		ANALYZE edw_stg_ads.agg_payments_1_prt_p000117;
	