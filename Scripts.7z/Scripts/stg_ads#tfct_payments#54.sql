/*rev. 47654 28.01.2020*/
set optimizer = on;
truncate table edw_stg_ads.tfct_payments_1_prt_p000054;
insert into    edw_stg_ads.tfct_payments_1_prt_p000054
(
	calendar_key,
	year_month_key,
	adjust_period,
	adjust_type_key,
	account_key,
	period_account_name,
	center_num_key,
	duty_num_key,
	segment_key,
	branch_key,
	region_key,
	partner_key,
	payment_rub,
	adjust_rub,
	src_id,
	load_dttm,
	md5
)

Select
	calendar_key,
	year_month_key,
	adjust_period,
	adjust_type_key,
	account_key,
	period_account_name,
	center_num_key,
	duty_num_key,
	segment_key,
	branch_key,
	region_key,
	partner_key,
	payment_rub,
	adjust_rub,
	src_id,
	CURRENT_TIMESTAMP as load_dttm,
	MD5
		(((((((((((((((((((
			COALESCE(calendar_key::text, ''::text)) || CHR(9)) ||
			COALESCE(account_key::text, ''::text)) || CHR(9)) ||
			COALESCE(center_num_key::text, ''::text)) || CHR(9)) ||
			COALESCE(duty_num_key::text, ''::text)) || CHR(9)) ||
			COALESCE(period_account_name::text, ''::text)) || CHR(9)) ||
			COALESCE(segment_key::text, ''::text)) || CHR(9)) ||
			COALESCE(branch_key::text, ''::text)) || CHR(9)) ||
			COALESCE(adjust_period::text, ''::text)) || CHR(9)) ||
			COALESCE(adjust_type_key::text, ''::text)) || CHR(9))
		) as md5
from
(
	Select
		date_trunc('day', payments.calendar_key) 					as calendar_key,
		to_char(payments.calendar_key, 'YYYYMM') 					as year_month_key,
		payments.adjust_period,
		payments.adjust_type_key,
		payments.account_key,
		da.account_name 											as period_account_name,
		coalesce(da.center_num_key, 0)								as center_num_key,
		coalesce(da.duty_num_key, 0)								as duty_num_key,
		coalesce(dp.segment_key, -1)								as segment_key,
		coalesce(da.branch_key, -1)									as branch_key,
		/*coalesce(dr.region_key, -1)*/ -1 								as region_key,
		coalesce(da.partner_key, -1)								as partner_key,
		sum(payments.payment_rub)									as payment_rub,
		sum(payments.adjust_rub)									as adjust_rub,
		payments.src_id
	From
		(
				Select
					pp.account_key,
					date_trunc('month', pp.billing_dttm) + interval '1 month' + interval '-1 sec' as calendar_key,
					to_char(pp.billing_dttm, 'YYYYMM') as adjust_period,
					pp.payment_amt as payment_rub,
					0 as adjust_rub,
					-1 as adjust_type_key,
					pp.src_id
				From edw_dds.tfct_payments_1_prt_p000054 pp
				where
					pp.billing_dttm between   TO_DATE('20190601', 'YYYYMMDD')  and to_date('20190630', 'YYYYMMDD') + interval '1 day' + interval '-1 sec'
					and pp.src_id=000054
			UNION ALL
				Select
					adj.account_key,
					date_trunc('month', adj.billing_dttm) + interval '1 month' + interval '-1 sec' as calendar_key,
					cast(cast(adj.corr_billing_id as numeric(6,0)) as char(6)) as adjust_period,
					0 as payment_rub,
					adjust_amt+coalesce(vat_rub,0) as adjust_rub,
					coalesce(adj.adjust_type_key, -1) as adjust_type_key,
					adj.src_id
				FROM edw_dds.tfct_adjust_1_prt_p000054 adj
				where
					adj.billing_dttm between   to_date('20190601', 'YYYYMMDD')  and (to_date('20190630', 'YYYYMMDD') + interval '1 day' + interval '-1 sec')
					and adj.src_id=000054
					and adj.adjust_type_key between 20000 and 39999
		) payments
			inner join edw_dds.dim_account_1_prt_p000054 AS da
				on da.account_key=payments.account_key
					and payments.calendar_key between da.eff_dttm and da.exp_dttm
					and da.deleted_ind = 0
					and da.branch_key <> -2
			inner join edw_dds.dim_partner_1_prt_p000054 AS dp
				on dp.partner_key=da.partner_key
					and payments.calendar_key between dp.eff_dttm and dp.exp_dttm
					and dp.deleted_ind = 0
					and dp.segment_key <> -2
			/*left join edw_dds.dim_region as dr
				on da.branch_key = dr.branch_key
					and dr.exp_dttm = '2999-12-31'
					and dr.deleted_ind = 0*/
	group by
		date_trunc('day', payments.calendar_key),
		to_char(payments.calendar_key, 'YYYYMM'),
		payments.adjust_period,
		payments.adjust_type_key,
		payments.account_key,
		da.account_name,
		coalesce(da.center_num_key, 0),
		coalesce(da.duty_num_key, 0),
		coalesce(dp.segment_key, -1),
		coalesce(da.branch_key, -1),
		--coalesce(dr.region_key, -1),
		coalesce(da.partner_key, -1),
		payments.src_id
) as paym ;
commit;
ANALYZE edw_stg_ads.tfct_payments_1_prt_p000054;
  