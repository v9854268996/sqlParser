/*rev.36678 от 28.08.2019*/
truncate table edw_stg_dm_ruz.tfct_traffic_revenue_vims_1_prt_p000002;
	insert into edw_stg_dm_ruz.tfct_traffic_revenue_vims_1_prt_p000002
	(
	billing_id
	, year_name
	, month_num_in_year
	, mrf_oebs_r12_code
	, mrf_oebs_r12_name
	, oebs_r12_branch_key
	, branch_code
	, branch_name
	, rf_oebs_r12_code
	, service_rtk_detail_code
	, num_a
	, num_b_abc
	, num_b_def
	, budget_segmentation
	, rc_code
	, rc_short_name
	, business_segment_short_name
	, traffic
	, charge
	, account_name
	, load_dttm
	, src_id
	)
with 
vims_subs as 
(select subs_key 
	from edw_dds.tfct_telephony_consumption_1_prt_p000002 t
	where  1=1
		and t.billing_id = to_date('20190601', 'YYYYMMDD')
		and t.is_vims = 'Y'
		and t.subs_key != -1
		and t.num_b not in ('01','101','02','102','03','103','04','104','112','122','123','001','002','003','004')
		and t.deleted_ind='0'
		and t.exp_dttm = to_date('29991231', 'YYYYMMDD')
	group by subs_key
),
charge as
(
	select 
		tc.src_id,
		tc.charge_period_start_dttm,
		tc.account_key,
		tc.subs_key,
		sd.service_rtk_detail_key,
		sum(tc.charge_rub) as charge_rub 
	from edw_dds.tfct_total_charge_1_prt_p000002 tc
	left join edw_dds.dim_service s  
		on ( 1 = 1
			and tc.service_key = s.service_key 
			and tc.charge_period_start_dttm between s.eff_dttm and s.exp_dttm
			and s.deleted_ind='0'
		)
	left join edw_dds.dim_service_rtk_detail sd 
		on ( 1 = 1
			and s.service_rtk_detail_key = sd.service_rtk_detail_key 
			and tc.charge_period_start_dttm between sd.eff_dttm and sd.exp_dttm
			and sd.deleted_ind='0'
		)
	where 1 = 1
		and tc.charge_period_start_dttm = cast(to_date('20190601', 'YYYYMMDD') as timestamp(0))
		and tc.deleted_ind='0'
		and tc.charge_rub>=0
	group by
		tc.src_id,
		tc.charge_period_start_dttm,
		tc.account_key,
		tc.subs_key,
		sd.service_rtk_detail_key
) 
, total_traf_vims as (
	select 
		t.src_id,
		t.billing_id,
		t.account_key,
		t.subs_key,
		s.service_rtk_detail_key,
		sum (t.call_dur_paid_nval) traffic
	from edw_dds.tfct_telephony_consumption_1_prt_p000002 t
	left join edw_dds.dim_service s 
		on ( 1 = 1
			and t.service_key = s.service_key 
			and t.billing_id between s.eff_dttm and s.exp_dttm
			and s.deleted_ind = '0'
		)
	inner join vims_subs 
		on (1=1
			and t.subs_key = vims_subs.subs_key
		)
	where 1 = 1
		and t.billing_id = to_date('20190601', 'YYYYMMDD')
		and t.subs_key != -1
		and t.num_b not in ('01','101','02','102','03','103','04','104','112','122','123','001','002','003','004')
		and t.deleted_ind='0'
		and t.exp_dttm = to_date('29991231', 'YYYYMMDD')
	group by
		t.src_id,
		t.billing_id,
		t.account_key,
		t.subs_key,
		s.service_rtk_detail_key
	having sum (t.call_dur_paid_nval) > 0
)
, total_traf_full as (
	select 
		t.src_id,
		t.billing_id,
		t.account_key,
		s.service_rtk_detail_key,
		sum (t.call_dur_paid_nval) traffic
	from edw_dds.tfct_telephony_consumption_1_prt_p000002 t
	left join edw_dds.dim_service s 
		on ( 1 = 1
			and t.service_key = s.service_key 
			and t.billing_id between s.eff_dttm and s.exp_dttm
			and s.deleted_ind = '0'
		)
	where 1 = 1
		and t.billing_id = to_date('20190601', 'YYYYMMDD')
		and t.subs_key != -1
		and t.num_b not in ('01','101','02','102','03','103','04','104','112','122','123','001','002','003','004')
		and t.deleted_ind='0'
		and t.exp_dttm = to_date('29991231', 'YYYYMMDD')
	group by
		t.src_id,
		t.billing_id,
		t.account_key,
		s.service_rtk_detail_key
	having sum (t.call_dur_paid_nval) > 0
)
select
	t.billing_id,
	c.year_name as year_name, 
	c.month_num_in_year as month_num_in_year,  
	null as mrf_oebs_r12_code,
	m.branch_name as mrf_oebs_r12_name,
	null as oebs_r12_branch_key,
	null as branch_code,
	br.branch_name as branch_name,
	null as rf_oebs_r12_code,
	sd.service_rtk_detail_code, 
	t.num_a, 
	substring(case when t.mobile_flg = 'N' then t.num_b else null end,1,5) num_b_abc, 
	substring(case when t.mobile_flg = 'Y' then t.num_b else null end,1,5) num_b_def,
	seg.budget_segmentation,
	rc.rc_code,
	rc.rc_short_name,
	bs.business_segment_short_name, 
	sum(t.call_dur_paid_nval) traffic,  
	coalesce(ch.charge_rub *(sum(t.call_dur_paid_nval) / tt.traffic),
			(ch_no_subs.charge_rub) * (sum(t.call_dur_paid_nval) / total_traf_full.traffic)
		 ) charge ,
	a.account_name,
	now() as load_dttm,
	000002 as src_id
from edw_dds.tfct_telephony_consumption_1_prt_p000002 t
inner join vims_subs on t.subs_key = vims_subs.subs_key
left join edw_dds.dim_calendar c on t.billing_id = c.date_key
left join edw_dds.dim_service s 
	on ( 1 = 1 
		and t.service_key = s.service_key 
		and cast(to_date('20190601', 'YYYYMMDD') as timestamp(0)) between s.eff_dttm and s.exp_dttm
		and s.deleted_ind = '0'
	)
left join edw_dds.dim_service_rtk_detail sd 
	on ( 1 = 1
		and s.service_rtk_detail_key = sd.service_rtk_detail_key 
		and cast(to_date('20190601', 'YYYYMMDD') as timestamp(0)) between sd.eff_dttm and sd.exp_dttm
		and sd.deleted_ind = '0'
	)
left join edw_dds.dim_account_1_prt_p000002 a 
	on ( 1 = 1
		and t.account_key = a.account_key 
		and cast(to_date('20190601', 'YYYYMMDD') as timestamp(0)) between a.eff_dttm and a.exp_dttm
		and a.deleted_ind = '0'
	)
left join edw_dds.dim_branch br 
	on ( 1 =1
		and br.branch_key = a.branch_key 
		and cast(to_date('20190601', 'YYYYMMDD') as timestamp(0)) between br.eff_dttm and br.exp_dttm 
		and br.deleted_ind = '0'
	)
left join edw_dds.dim_branch m 
	on ( 1 = 1
		and br.parent_branch_key = m.branch_key 
		and cast(to_date('20190601', 'YYYYMMDD') as timestamp(0)) between m.eff_dttm and m.exp_dttm 
		and m.deleted_ind ='0'	
	)
left join edw_dds.dim_partner_1_prt_p000002 p 
	on ( 1 = 1
		and a.partner_key = p.partner_key 
		and cast(to_date('20190601', 'YYYYMMDD') as timestamp(0)) between p.eff_dttm and p.exp_dttm
		and p.deleted_ind = '0'
	)
left join edw_dds.dim_segment seg 
	on ( 1 = 1
		and p.segment_key = seg.segment_key 
		and cast(to_date('20190601', 'YYYYMMDD') as timestamp(0)) between seg.eff_dttm and seg.exp_dttm
		and seg.deleted_ind = '0'
	)
left join edw_dds.dim_matrix_rc mat 
	on ( 1 = 1
		and sd.service_rtk_detail_key = mat.service_rtk_detail_key 
		and seg.segment_key = mat.segment_key 
		and cast(to_date('20190601', 'YYYYMMDD') as timestamp(0)) between mat.eff_dttm and mat.exp_dttm
		and mat.deleted_ind = '0'
	)
left join edw_dds.dim_rc rc 
	on ( 1= 1
		and mat.rc_key = rc.rc_key 
		and cast(to_date('20190601', 'YYYYMMDD') as timestamp(0)) between rc.eff_dttm and rc.exp_dttm
		and rc.deleted_ind = '0'
	)
left join edw_dds.dim_business_segment bs 
	on ( 1 = 1
		and rc.business_segment_key = bs.business_segment_key 
		and cast(to_date('20190601', 'YYYYMMDD') as timestamp(0)) between bs.eff_dttm and bs.exp_dttm
		and bs.deleted_ind = '0'
	)
left join charge ch 
	on ( 1 = 1
		and t.account_key = ch.account_key 
		and sd.service_rtk_detail_key = ch.service_rtk_detail_key         
		and t.subs_key = ch.subs_key
	)
left join charge ch_no_subs 
	on ( 1 = 1
		and t.account_key = ch_no_subs.account_key 
		and sd.service_rtk_detail_key = ch_no_subs.service_rtk_detail_key 
		and ch_no_subs.subs_key = -1 
		and ch.subs_key is null 
		)
left join total_traf_vims tt 
	on ( 1 = 1
		and t.account_key = tt.account_key 
		and tt.service_rtk_detail_key = s.service_rtk_detail_key 
		and t.subs_key = tt.subs_key
	)
inner join total_traf_full 
	on ( 1= 1
		and t.account_key = total_traf_full.account_key 
		and total_traf_full.service_rtk_detail_key = s.service_rtk_detail_key 
		)
where 1 = 1
	and t.billing_id = to_date('20190601', 'YYYYMMDD')
	and t.deleted_ind = '0'
	and t.exp_dttm = to_date('29991231', 'YYYYMMDD')
	and t.subs_key!= -1 
	and t.call_dur_paid_nval > 0
	and t.num_b not in ('01','101','02','102','03','103','04','104','112','122','123','001','002','003','004')
	and s.service_key != -2
group by
	t.billing_id,
	c.year_name	,
	c.month_num_in_year,
	sd.service_rtk_detail_key,
	sd.service_rtk_detail_code, 
	t.num_a, 
	substring(case when t.mobile_flg = 'N' then t.num_b else null end,1,5) , 
	substring(case when t.mobile_flg = 'Y' then t.num_b else null end,1,5) ,
	seg.segment_key, 
	seg.budget_segmentation,
	rc.rc_key, 
	rc.rc_code,
	rc.rc_short_name,
	bs.business_segment_key, 
	bs.business_segment_short_name,
	ch.charge_rub, 
	tt.traffic,
	total_traf_full.traffic,
	m.branch_name,
	br.branch_name,
	ch_no_subs.charge_rub,
	a.account_name
having sum(t.call_dur_paid_nval)>0;
commit;
analyse edw_stg_dm_ruz.tfct_traffic_revenue_vims_1_prt_p000002;