/*rev.22457 15.02.2019*/
truncate table edw_stg_dds.T_000097_PRE_RATE_PLANS;
set optimizer = on;
insert into edw_stg_dds.T_000097_PRE_RATE_PLANS (	rtpl_id
	, number_history
	, active_end, active_start, all_quantity_eqpm, brnc_brnc_id
	, ccat_ccat_id, ctyp_ctyp_id, cur_cur_id, flag_add_eqpm
	, flag_all_stnd, flag_mix, is_complect, is_equipment
	, name_1, name_2, name_e, name_r, navi_date, navi_user
	, rptp_rptp_id, scls_scls_id
	, stnd_stnd_id, traf_by_dir_n, xtyp_xtyp_id
	, start_date
	,  end_date)
with 
data_set_dup as (
	select
		*,
		row_number() over(partition by rtpl_id,start_date order by number_history desc) as rn
	from edw_ods.t_000097_rate_plans 
	where deleted_ind = 0
),
data_set_cleared as (
	select
		a1.*
	from data_set_dup a1 
	left join data_set_dup a2
	       on a2.rn = 1 
	       and a2.rtpl_id = a1.rtpl_id
	       	and a1.start_date >= a2.start_date 
			and a1.start_date < a2.end_date
	    --   and a1.end_date between a2.start_date and a2.end_date
	       and a2.number_history > a1.number_history
	where 
		a1.rn = 1 
		and  a2.rtpl_id is null
)

,data_hist_normalised as (
	select 
		rtpl_id
		,number_history
		,active_end, active_start, all_quantity_eqpm, brnc_brnc_id
		, ccat_ccat_id, ctyp_ctyp_id, cur_cur_id, flag_add_eqpm
		, flag_all_stnd, flag_mix, is_complect, is_equipment
		, name_1, name_2, name_e, name_r, navi_date, navi_user
		,  rptp_rptp_id, scls_scls_id
		, stnd_stnd_id, traf_by_dir_n, xtyp_xtyp_id
		, min(start_date) as start_date
		, max(end_date) as end_date
	from
	    (
			select 
				*
				,row_number()over(partition by rtpl_id,
						--		   number_history,
						active_end, active_start, all_quantity_eqpm, brnc_brnc_id
						, ccat_ccat_id, ctyp_ctyp_id, cur_cur_id, flag_add_eqpm
						, flag_all_stnd, flag_mix, is_complect, is_equipment
						, name_1, name_2, name_e, name_r, navi_date, navi_user
						, rptp_rptp_id, scls_scls_id
						, stnd_stnd_id, traf_by_dir_n, xtyp_xtyp_id  
						order by start_date)
					-row_number()over(partition by  rtpl_id order by start_date)
				as gr
			from  data_set_cleared
			where  start_date < end_date 
	    ) t 
	group by rtpl_id,number_history, gr,
		 active_end, active_start, all_quantity_eqpm, brnc_brnc_id
		, ccat_ccat_id, ctyp_ctyp_id, cur_cur_id, flag_add_eqpm
		, flag_all_stnd, flag_mix, is_complect, is_equipment
		, name_1, name_2, name_e, name_r, navi_date, navi_user
		, rptp_rptp_id, scls_scls_id
		, stnd_stnd_id, traf_by_dir_n, xtyp_xtyp_id

)
select 
	rtpl_id
	, number_history
	, active_end, active_start, all_quantity_eqpm, brnc_brnc_id
	, ccat_ccat_id, ctyp_ctyp_id, cur_cur_id, flag_add_eqpm
	, flag_all_stnd, flag_mix, is_complect, is_equipment
	, name_1, name_2, name_e, name_r, navi_date, navi_user
	, rptp_rptp_id, scls_scls_id
	, stnd_stnd_id, traf_by_dir_n, xtyp_xtyp_id
	,cast(start_date as timestamp without time zone) as start_date
	,coalesce(lead(start_date) over (partition by rtpl_id order by start_date)- interval '1 second',end_date) end_date
	from   data_hist_normalised  	
;
commit;
analyze edw_stg_dds.T_000097_PRE_RATE_PLANS;
