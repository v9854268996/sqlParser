/*rev.10792 от 05.02.2019*/
truncate table edw_stg_dds.t_000080_dim_connected_service;
insert into edw_stg_dds.t_000080_DIM_CONNECTED_SERVICE
	( 
	connected_service_key, subs_key, account_key, service_key, duty_num_key, center_num_key, address_key, cpe_key, port_key, subs_code, start_date, end_date, rc_key, load_dttm, src_id, md5, eff_dttm, exp_dttm
	)
SELECT
	  dim_subs.service_id as connected_service_key
	, dim_subs.subs_key
	, dim_subs.account_key
	, dim_subs.service_key
	, dim_subs.duty_num_key
	, dim_subs.center_num_key
	, dim_subs.address_key
	, dim_subs.cpe_key
	, dim_subs.port_key
	, dim_subs.subs_code
	, dim_subs.start_date
	, dim_subs.end_date
	, dim_subs.rc_key
	, now () as load_dttm
	, dim_subs.src_id
	, md5( subs_key ||'#'|| cast(subs_activation_dt as varchar) ||'#'|| cast(subs_cancellation_dt as varchar) ||'#'|| coalesce(subs_code,'') ||'#'|| service_key ||'#'|| coalesce(address_key,'') ||'#'|| account_key ||'#'|| service_id ||'#'|| serv_first_id ) as md5 
	, to_date('1900-01-01','YYYY-MM-DD')::timestamp as eff_dttm
	, to_date('2999-12-31','YYYY-MM-DD')::timestamp as exp_dttm
	
FROM edw_stg_dds.t_000080_dim_subs dim_subs;