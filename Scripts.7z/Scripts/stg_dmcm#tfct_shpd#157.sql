/*rev. 45497*/

SET optimizer = OFF;
SET search_path = edw_stg_dmcm;

truncate table edw_stg_dmcm.PRE_SHPD_DIM_ADDRESS_STG_1_PRT_P000157;
INSERT INTO edw_stg_dmcm.PRE_SHPD_DIM_ADDRESS_STG_1_PRT_P000157 (
  mrf_id,
  rf_id,
  account,
  city,
  address,
  src_id
)
  SELECT
    coalesce ( adr.mrf_id, subs.mrf_id )   AS mrf_id,
    coalesce ( adr.rf_id, subs.rf_id )     AS rf_id,
    coalesce ( adr.account, subs.account ) AS account,
    coalesce ( subs.city, adr.city )       AS city,
    CASE WHEN subs.city IS NOT NULL
      THEN subs.address
    ELSE adr.address
    END                                    AS address,
    157 as src_id
  FROM (
         SELECT
           /*+ NoNestLoop(q, ad1, sa)*/
           q.mrf_id,
           q.rf_id,
           CASE WHEN q.mrf_id = 14
             THEN sa.nls
           ELSE q.account
           END                                                     AS account,
           ad1.city                                                AS city,
           ad1.address || CASE WHEN q.flat IS NULL
             THEN ''
                          ELSE ', ' END || coalesce ( q.flat, '' ) AS address,
           row_number ( )
           OVER (
             PARTITION BY
               CASE WHEN q.mrf_id = 14
                 THEN sa.nls
               ELSE q.account
               END,
               q.mrf_id,
               q.rf_id
             ORDER BY ad1.city, ad1.address || CASE WHEN q.flat IS NULL
               THEN ''
                                               ELSE ', ' END || coalesce ( q.flat, '' )
             )                                                        rn
         FROM (
                SELECT
                  ad1.mrf_id,
                  ad1.rf_id,
                  ad1.account,
                  ad1.house_lid,
                  ad1.flat
                FROM edw_ods.T_000157_RPRT_OO_ADDRESSABNDWH ad1
              ) q
           LEFT JOIN (
                       SELECT
                         ad1.city,
                         ad1.mrf_id,
                         ad1.house_lid,
                         ad1.POSTOFFICE_ID || CASE WHEN ad1.POSTOFFICE_ID IS NOT NULL
                           THEN ', '
                                              ELSE '' END
                         || ad1.TERR_TYPE || CASE WHEN ad1.TERR_TYPE IS NOT NULL
                           THEN ' '
                                             ELSE '' END
                         || ad1.NAME_TERR || CASE WHEN coalesce ( ad1.TERR_TYPE, ad1.NAME_TERR ) IS NOT NULL
                           THEN ', '
                                             ELSE '' END
                         || ad1.CITY || CASE WHEN CITY IS NOT NULL
                           THEN ', '
                                        ELSE '' END
                         || ad1.NAME_STREET_TYPE || CASE WHEN ad1.NAME_STREET_TYPE IS NOT NULL
                           THEN ' '
                                                    ELSE '' END
                         || ad1.NAME_STREET || CASE WHEN coalesce ( ad1.NAME_STREET_TYPE, ad1.NAME_STREET ) IS NOT NULL
                           THEN ', '
                                               ELSE '' END
                         || ad1.HOUSE AS address
                       FROM edw_ods.T_000157_RPRT_OO_ADDRESS ad1
                     ) ad1
             ON q.mrf_id = ad1.mrf_id
                AND q.house_lid = ad1.house_lid
           LEFT JOIN (
				SELECT
					mrf_id,
					nls,
					account,
					row_number ()
						OVER (
						PARTITION BY account
						ORDER BY COALESCE(date_end, to_date('2999-12-31', 'yyyy-mm-dd')) DESC, date_begin DESC ) rn
				FROM edw_ods.T_000158_EFFTP_SOUTH_NLS_ACCNT
			) sa
				ON sa.mrf_id = 14
				AND sa.account = q.account
				AND sa.rn = 1
       ) adr
    FULL JOIN (
                SELECT
                  /*+ NoNestLoop(subs_act, sa)*/
                  subs_act.mrf_id,
                  subs_act.rf_id,
                  CASE WHEN subs_act.mrf_id = 14
                    THEN sa.nls
                  ELSE subs_act.account
                  END                AS account,
                  subs_act.city_name AS city,
                  subs_act.adress    AS address,
                  row_number ( )
                  OVER (
                    PARTITION BY
                      CASE WHEN subs_act.mrf_id = 14
                        THEN sa.nls
                      ELSE subs_act.account
                      END,
                      subs_act.mrf_id,
                      subs_act.rf_id
                    ORDER BY subs_act.city_name, subs_act.adress
                    )                   rn
                FROM edw_ods.T_000157_RPRTSUBSCRIBERSACTUAL subs_act
                  LEFT JOIN (
					SELECT
						mrf_id,
						nls,
						account,
						row_number ()
							OVER (
							PARTITION BY account
							ORDER BY COALESCE(date_end, to_date('2999-12-31', 'yyyy-mm-dd')) DESC, date_begin DESC ) rn
					FROM edw_ods.T_000158_EFFTP_SOUTH_NLS_ACCNT
				) sa
					ON sa.mrf_id = 14
					AND sa.account = subs_act.account
					AND sa.rn = 1
                WHERE coalesce ( subs_act.data_close_serv, to_date ( '2999-12-31', 'yyyy-mm-dd' ) ) =
                      to_date ( '2999-12-31', 'yyyy-mm-dd' )
                      AND
                      coalesce ( subs_act.data_close, to_date ( '2999-12-31', 'yyyy-mm-dd' ) ) =
                      to_date ( '2999-12-31', 'yyyy-mm-dd' )
                      AND city_name != '6666666666666666'
              ) subs
      ON subs.account = adr.account
         AND subs.mrf_id = adr.mrf_id
         AND subs.rf_id = adr.rf_id
  WHERE adr.rn = 1
        AND subs.rn = 1;
ANALYSE edw_stg_dmcm.PRE_SHPD_DIM_ADDRESS_STG_1_PRT_P000157;


TRUNCATE TABLE edw_stg_dmcm.pre_shpd_south_tp_1_PRT_P000157;
INSERT INTO edw_stg_dmcm.pre_shpd_south_tp_1_PRT_P000157
(account, rtpl_name, tp_start, speed_tp, tech_name, src_id)
  SELECT
    account,
    rtpl_name,
    tp_start,
    speed_tp,
    tech_name,
    157 as src_id
  FROM (
         SELECT
           stg1.dfaccount AS account,
           tl.tmname      AS rtpl_name,
           CASE WHEN tl.start_date < '2017-01-01 00:00:00'
             THEN '2017-01-01 00:00:00'
           ELSE tl.start_date
           END            AS tp_start,
           CASE WHEN position ( 'КБ' IN upper ( tl.tmname ) ) > 0
             THEN cast ( to_number ( replace ( substring ( substring ( upper ( tl.tmname )
                                                                       FROM
                                                                       '[[:digit:]]{1,5}[\,\.]{0,1}[[:digit:]]{0,5}[[:space:]]{0,3}КБ' )
                                                           FROM '[[:digit:]]{1,5}[\,\.]{0,1}[[:digit:]]{0,5}' ), ',',
                                               '.' ),
                                     '9999999999.9999' ) AS NUMERIC(10, 2) )
           WHEN position ( '2048К' IN upper ( tl.tmname ) ) > 0
             THEN cast ( substring ( upper ( tl.tmname ) FROM '2048' ) AS NUMERIC(10, 2) )
           WHEN position ( 'МБ' IN upper ( tl.tmname ) ) > 0
             THEN cast ( to_number ( replace ( substring ( substring ( upper ( tl.tmname )
                                                                       FROM
                                                                       '[[:digit:]]{1,5}[\,\.]{0,1}[[:digit:]]{0,5}[[:space:]]{0,3}МБ' )
                                                           FROM '[[:digit:]]{1,5}[\,\.]{0,1}[[:digit:]]{0,5}' ), ',',
                                               '.' ),
                                     '9999999999.9999' ) * 1024 AS NUMERIC(10, 2) )
           WHEN position ( 'MБ' IN upper ( tl.tmname ) ) > 0
             THEN cast ( to_number ( replace ( substring ( substring ( upper ( tl.tmname )
                                                                       FROM
                                                                       '[[:digit:]]{1,5}[\,\.]{0,1}[[:digit:]]{0,5}[[:space:]]{0,3}MБ' )
                                                           FROM '[[:digit:]]{1,5}[\,\.]{0,1}[[:digit:]]{0,5}' ), ',',
                                               '.' ),
                                     '9999999999.9999' ) * 1024 AS NUMERIC(10, 2) )
           WHEN position ( 'ГБ' IN upper ( tl.tmname ) ) > 0
             THEN cast ( to_number ( replace ( substring ( substring ( upper ( tl.tmname )
                                                                       FROM
                                                                       '[[:digit:]]{1,5}[\,\.]{0,1}[[:digit:]]{0,5}[[:space:]]{0,3}ГБ' )
                                                           FROM '[[:digit:]]{1,5}[\,\.]{0,1}[[:digit:]]{0,5}' ), ',',
                                               '.' ),
                                     '9999999999.9999' ) * 1024 * 1024 AS NUMERIC(10, 2) )
           WHEN cast ( substring ( upper ( tl.tmname ) FROM '[[:digit:]]{1,5}' ) AS NUMERIC(10, 2) ) >= 64.0
                AND
                ( log ( 2.0, cast ( substring ( upper ( tl.tmname ) FROM '[[:digit:]]{1,5}' ) AS NUMERIC(10, 2) ) ) -
                  ceil ( log ( 2.0, cast ( substring ( upper ( tl.tmname )
                                                       FROM '[[:digit:]]{1,5}' ) AS NUMERIC(10, 2) ) ) ) ) = 0.0
             THEN cast ( substring ( upper ( tl.tmname ) FROM '[[:digit:]]{1,5}' ) AS NUMERIC(10, 2) )
           ELSE NULL
           END            AS speed_tp,
           CASE WHEN position ( 'DSL' IN upper ( tl.tmname ) ) > 0
             THEN 'xDSL'
           WHEN position ( 'PON' IN upper ( tl.tmname ) ) > 0
             THEN 'PON'
           WHEN position ( 'FTTX' IN upper ( tl.tmname ) ) > 0
             THEN 'FTTx'
           WHEN position ( 'DOCSIS' IN upper ( tl.tmname ) ) > 0
             THEN 'DOCSIS'
           WHEN position ( 'ETTH' IN upper ( tl.tmname ) ) > 0
             THEN 'ETTH'
           WHEN position ( 'ETHERNET' IN upper ( tl.tmname ) ) > 0
             THEN 'ETTH'
           ELSE NULL
           END            AS tech_name,
           row_number ( )
           OVER (
             PARTITION BY stg1.dfaccount
             ORDER BY
               CASE WHEN tl.start_date < '2017-01-01 00:00:00'
                 THEN '2017-01-01 00:00:00'
               ELSE tl.start_date
               END )         rn
         FROM (
                SELECT
                  *,
                  row_number ( )
                  OVER (
                    PARTITION BY td.dfaccount, aoa.orgid ) rn_stg
                FROM (
                       SELECT
                         td.dfaccount,
                         cast ( tdl.dfdogovor_ref AS NUMERIC(38, 0) ) AS dfdogovor_ref
                       FROM edw_ods.t_000027_tdogovor td
                         INNER JOIN edw_ods.t_000027_tels_dogovor_link tdl ON tdl.dfels_dogovor = td.dfdogovor
                       WHERE td.dfdogtype = 1234567
                       UNION
                       SELECT
                         td.dfaccount,
                         cast ( tdl.dfdogovor_ref AS NUMERIC(38, 0) ) AS dfdogovor_ref
                       FROM edw_ods.t_000028_tdogovor td
                         INNER JOIN edw_ods.t_000028_tels_dogovor_link tdl ON tdl.dfels_dogovor = td.dfdogovor
                       WHERE td.dfdogtype = 1234567
                       UNION
                       SELECT
                         td.dfaccount,
                         cast ( tdl.dfdogovor_ref AS NUMERIC(38, 0) ) AS dfdogovor_ref
                       FROM edw_ods.t_000029_tdogovor td
                         INNER JOIN edw_ods.t_000029_tels_dogovor_link tdl ON tdl.dfels_dogovor = td.dfdogovor
                       WHERE td.dfdogtype = 1234567
                       UNION
                       SELECT
                         td.dfaccount,
                         cast ( tdl.dfdogovor_ref AS NUMERIC(38, 0) ) AS dfdogovor_ref
                       FROM edw_ods.t_000030_tdogovor td
                         INNER JOIN edw_ods.t_000030_tels_dogovor_link tdl ON tdl.dfels_dogovor = td.dfdogovor
                       WHERE td.dfdogtype = 1234567
                       UNION
                       SELECT
                         td.dfaccount,
                         cast ( tdl.dfdogovor_ref AS NUMERIC(38, 0) ) AS dfdogovor_ref
                       FROM edw_ods.t_000031_tdogovor td
                         INNER JOIN edw_ods.t_000031_tels_dogovor_link tdl ON tdl.dfels_dogovor = td.dfdogovor
                       WHERE td.dfdogtype = 1234567
                       UNION
                       SELECT
                         td.dfaccount,
                         cast ( tdl.dfdogovor_ref AS NUMERIC(38, 0) ) AS dfdogovor_ref
                       FROM edw_ods.t_000032_tdogovor td
                         INNER JOIN edw_ods.t_000032_tels_dogovor_link tdl ON tdl.dfels_dogovor = td.dfdogovor
                       WHERE td.dfdogtype = 1234567
                       UNION
                       SELECT
                         td.dfaccount,
                         cast ( tdl.dfdogovor_ref AS NUMERIC(38, 0) ) AS dfdogovor_ref
                       FROM edw_ods.t_000033_tdogovor td
                         INNER JOIN edw_ods.t_000033_tels_dogovor_link tdl ON tdl.dfels_dogovor = td.dfdogovor
                       WHERE td.dfdogtype = 1234567
                       UNION
                       SELECT
                         td.dfaccount,
                         cast ( tdl.dfdogovor_ref AS NUMERIC(38, 0) ) AS dfdogovor_ref
                       FROM edw_ods.t_000034_tdogovor td
                         INNER JOIN edw_ods.t_000034_tels_dogovor_link tdl ON tdl.dfels_dogovor = td.dfdogovor
                       WHERE td.dfdogtype = 1234567
                       UNION
                       SELECT
                         td.dfaccount,
                         cast ( tdl.dfdogovor_ref AS NUMERIC(38, 0) ) AS dfdogovor_ref
                       FROM edw_ods.t_000035_tdogovor td
                         INNER JOIN edw_ods.t_000035_tels_dogovor_link tdl ON tdl.dfels_dogovor = td.dfdogovor
                       WHERE td.dfdogtype = 1234567
                       UNION
                       SELECT
                         td.dfaccount,
                         cast ( tdl.dfdogovor_ref AS NUMERIC(38, 0) ) AS dfdogovor_ref
                       FROM edw_ods.t_000036_tdogovor td
                         INNER JOIN edw_ods.t_000036_tels_dogovor_link tdl ON tdl.dfels_dogovor = td.dfdogovor
                       WHERE td.dfdogtype = 1234567
                       UNION
                       SELECT
                         td.dfaccount,
                         cast ( tdl.dfdogovor_ref AS NUMERIC(38, 0) ) AS dfdogovor_ref
                       FROM edw_ods.t_000037_tdogovor td
                         INNER JOIN edw_ods.t_000037_tels_dogovor_link tdl ON tdl.dfels_dogovor = td.dfdogovor
                       WHERE td.dfdogtype = 1234567
                       UNION
                       SELECT
                         td.dfaccount,
                         cast ( tdl.dfdogovor_ref AS NUMERIC(38, 0) ) AS dfdogovor_ref
                       FROM edw_ods.t_000038_tdogovor td
                         INNER JOIN edw_ods.t_000038_tels_dogovor_link tdl ON tdl.dfels_dogovor = td.dfdogovor
                       WHERE td.dfdogtype = 1234567
                       UNION
                       SELECT
                         td.dfaccount,
                         cast ( tdl.dfdogovor_ref AS NUMERIC(38, 0) ) AS dfdogovor_ref
                       FROM edw_ods.t_000039_tdogovor td
                         INNER JOIN edw_ods.t_000039_tels_dogovor_link tdl ON tdl.dfels_dogovor = td.dfdogovor
                       WHERE td.dfdogtype = 1234567
                     ) td --23 365 676
                  INNER JOIN (
                               SELECT
                                 val,
                                 orgid,
                                 attrid,
                                 row_number ( )
                                 OVER (
                                   PARTITION BY val
                                   ORDER BY mdate DESC ) rn
                               FROM edw_ods.t_000026_add_org_attrib
                               WHERE attrid = 202
                             ) aoa
                    ON aoa.val = td.dfdogovor_ref :: text
                       AND aoa.rn = 1
              ) stg1
           INNER JOIN edw_ods.t_000026_dog_list dl
             ON dl.orgid = stg1.orgid
           INNER JOIN (
                        SELECT
                          dogid,
                          dmid,
                          row_number ( )
                          OVER (
                            PARTITION BY dogid
                            ORDER BY whenmake DESC ) rn
                        FROM edw_ods.t_000026_map_main_vw
                      ) mm
             ON mm.dogid = dl.dogid
                AND mm.rn = 1
           INNER JOIN (
                        SELECT
                          t.dmid,
                          t.tmid,
                          row_number ( )
                          OVER (
                            PARTITION BY t.dmid
                            ORDER BY t.begdate DESC ) rn
                        FROM (
                               SELECT
                                 ds.dmid,
                                 ds.tmid,
                                 ds.begdate
                               FROM edw_ods.t_000026_dog_serv ds
                                 LEFT JOIN edw_dds.hub_dim_service hds
                                   ON '26;' || cast ( ceil ( ds.servid ) AS VARCHAR ) || ';' ||
                                      cast ( ceil ( ds.tmid ) AS VARCHAR ) = hds.source_key
                                      AND hds.exp_dttm = '2999-12-31 00:00:00'

                                 LEFT JOIN edw_dds.dim_service dimserv
                                   ON dimserv.service_key = hds.service_key
                                      AND dimserv.exp_dttm = '2999-12-31 00:00:00'
                               WHERE dimserv.business_service_key BETWEEN 10200 AND 10203
							   		and ds.deleted_ind = 0
                             ) t
                      ) ds
             ON ds.dmid = mm.dmid
                AND ds.rn = 1
           INNER JOIN (
                        SELECT
                          tmname,
                          tmid,
                          start_date
                        FROM edw_ods.t_000026_tm_list
                      ) tl
             ON tl.tmid = ds.tmid
         WHERE stg1.rn = 1
       ) stg2
  WHERE stg2.rn = 1
  and 157 = 154;
ANALYSE edw_stg_dmcm.pre_shpd_south_tp_1_PRT_P000157;



TRUNCATE TABLE edw_stg_dmcm.PRE_SHPD_VOLGA_TP_1_PRT_P000157;
INSERT INTO edw_stg_dmcm.PRE_SHPD_VOLGA_TP_1_PRT_P000157
(account, speed_tp, rtpl_name, tech_name, tp_start, src_id)
  SELECT
    account,
    CASE WHEN speed_tp > 99999999
      THEN NULL
    ELSE speed_tp END,
    rtpl_name,
    tech_name,
    tp_start,
    157 as src_id
  FROM (
         SELECT
           account,
           CASE WHEN usa_value IS NOT NULL
             THEN
               CASE WHEN position ( 'К' IN upper ( usa_value ) ) > 0
                 THEN cast ( to_number ( replace ( substring ( substring ( upper ( usa_value )
                                                                           FROM
                                                                           '[[:digit:]]{1,5}[\,\.]{0,1}[[:digit:]]{0,5}[[:space:]]{0,3}К' )
                                                               FROM '[[:digit:]]{1,5}[\,\.]{0,1}[[:digit:]]{0,5}' ),
                                                   ',',
                                                   '.' ), '9999999999.9999' ) AS NUMERIC(20, 2) )
               WHEN position ( 'K' IN upper ( usa_value ) ) > 0
                 THEN cast ( to_number ( replace ( substring ( substring ( upper ( usa_value )
                                                                           FROM
                                                                           '[[:digit:]]{1,5}[\,\.]{0,1}[[:digit:]]{0,5}[[:space:]]{0,3}K' )
                                                               FROM '[[:digit:]]{1,5}[\,\.]{0,1}[[:digit:]]{0,5}' ),
                                                   ',',
                                                   '.' ), '9999999999.9999' ) AS NUMERIC(20, 2) )
               WHEN position ( 'М' IN upper ( usa_value ) ) > 0
                 THEN cast ( to_number ( replace ( substring ( substring ( upper ( usa_value )
                                                                           FROM
                                                                           '[[:digit:]]{1,5}[\,\.]{0,1}[[:digit:]]{0,5}[[:space:]]{0,3}М' )
                                                               FROM '[[:digit:]]{1,5}[\,\.]{0,1}[[:digit:]]{0,5}' ),
                                                   ',',
                                                   '.' ), '9999999999.9999' ) * 1024 AS NUMERIC(20, 2) )
               WHEN position ( 'M' IN upper ( usa_value ) ) > 0
                 THEN cast ( to_number ( replace ( substring ( substring ( upper ( usa_value )
                                                                           FROM
                                                                           '[[:digit:]]{1,5}[\,\.]{0,1}[[:digit:]]{0,5}[[:space:]]{0,3}M' )
                                                               FROM '[[:digit:]]{1,5}[\,\.]{0,1}[[:digit:]]{0,5}' ),
                                                   ',',
                                                   '.' ), '9999999999.9999' ) * 1024 AS NUMERIC(20, 2) )
               WHEN position ( 'ГБ' IN upper ( usa_value ) ) > 0
                 THEN cast ( to_number ( replace ( substring ( substring ( upper ( usa_value )
                                                                           FROM
                                                                           '[[:digit:]]{1,5}[\,\.]{0,1}[[:digit:]]{0,5}[[:space:]]{0,3}ГБ' )
                                                               FROM '[[:digit:]]{1,5}[\,\.]{0,1}[[:digit:]]{0,5}' ),
                                                   ',',
                                                   '.' ), '9999999999.9999' ) * 1024 * 1024 AS NUMERIC(20, 2) )
               WHEN cast ( substring ( upper ( usa_value ) FROM '[[:digit:]]{1,5}' ) AS NUMERIC(20, 2) ) >= 64.0
                    AND
                    ( log ( 2.0, cast ( substring ( upper ( usa_value ) FROM '[[:digit:]]{1,5}' ) AS NUMERIC(20, 2) ) )
                      -
                      ceil ( log ( 2.0, cast ( substring ( upper ( usa_value )
                                                           FROM '[[:digit:]]{1,5}' ) AS NUMERIC(20, 2) ) ) ) ) = 0.0
                 THEN cast ( substring ( upper ( usa_value ) FROM '[[:digit:]]{1,5}' ) AS NUMERIC(20, 2) )
               WHEN upper ( usa_value ) LIKE '%U_11111_%'
                 THEN 11111 :: NUMERIC(10, 2)
               WHEN upper ( usa_value ) LIKE '%U_1111_%'
                 THEN 1111 :: NUMERIC(10, 2)
               WHEN upper ( usa_value ) LIKE '%U_15555%'
                 THEN 15555 :: NUMERIC(10, 2)
               WHEN upper ( usa_value ) LIKE '%U_22222%'
                 THEN 22222 :: NUMERIC(10, 2)
               WHEN upper ( usa_value ) LIKE '%U_2222_%'
                 THEN 2222 :: NUMERIC(10, 2)
               WHEN upper ( usa_value ) LIKE '%U_33333%'
                 THEN 33333 :: NUMERIC(10, 2)
               WHEN upper ( usa_value ) LIKE '%U_44444%'
                 THEN 44444 :: NUMERIC(10, 2)
               WHEN upper ( usa_value ) LIKE '%U_4444_%'
                 THEN 4444 :: NUMERIC(10, 2)
               WHEN upper ( usa_value ) LIKE '%U_5555_%'
                 THEN 5555 :: NUMERIC(10, 2)
               WHEN upper ( usa_value ) LIKE '%U_6666_%'
                 THEN 6666 :: NUMERIC(10, 2)
               WHEN upper ( usa_value ) LIKE '%U_77777%'
                 THEN 77777 :: NUMERIC(10, 2)
               WHEN upper ( usa_value ) LIKE '%U_8888_%'
                 THEN 8888 :: NUMERIC(10, 2)
               WHEN usa_value LIKE '%Juniper%384%'
                 THEN 384 :: NUMERIC(10, 2)
               WHEN usa_value LIKE '%Juniper%768%'
                 THEN 768 :: NUMERIC(10, 2)
               WHEN usa_value LIKE '%Juniper%1536%'
                 THEN 1536 :: NUMERIC(10, 2)
               WHEN usa_value LIKE '%Juniper%2200%'
                 THEN 2200 :: NUMERIC(10, 2)
               ELSE NULL
               END
           ELSE
             CASE WHEN position ( 'К' IN upper ( tfp_name ) ) > 0
               THEN cast ( to_number ( replace ( substring ( substring ( upper ( tfp_name )
                                                                         FROM
                                                                         '[[:digit:]]{1,5}[\,\.]{0,1}[[:digit:]]{0,5}[[:space:]]{0,3}К' )
                                                             FROM '[[:digit:]]{1,5}[\,\.]{0,1}[[:digit:]]{0,5}' ), ',',
                                                 '.' ), '9999999999.9999' ) AS NUMERIC(20, 2) )
             WHEN position ( 'K' IN upper ( tfp_name ) ) > 0
               THEN cast ( to_number ( replace ( substring ( substring ( upper ( tfp_name )
                                                                         FROM
                                                                         '[[:digit:]]{1,5}[\,\.]{0,1}[[:digit:]]{0,5}[[:space:]]{0,3}K' )
                                                             FROM '[[:digit:]]{1,5}[\,\.]{0,1}[[:digit:]]{0,5}' ), ',',
                                                 '.' ), '9999999999.9999' ) AS NUMERIC(20, 2) )
             WHEN position ( 'М' IN upper ( tfp_name ) ) > 0
               THEN cast ( to_number ( replace ( substring ( substring ( upper ( tfp_name )
                                                                         FROM
                                                                         '[[:digit:]]{1,5}[\,\.]{0,1}[[:digit:]]{0,5}[[:space:]]{0,3}М' )
                                                             FROM '[[:digit:]]{1,5}[\,\.]{0,1}[[:digit:]]{0,5}' ), ',',
                                                 '.' ), '9999999999.9999' ) * 1024 AS NUMERIC(20, 2) )
             WHEN position ( 'M' IN upper ( tfp_name ) ) > 0
               THEN cast ( to_number ( replace ( substring ( substring ( upper ( tfp_name )
                                                                         FROM
                                                                         '[[:digit:]]{1,5}[\,\.]{0,1}[[:digit:]]{0,5}[[:space:]]{0,3}M' )
                                                             FROM '[[:digit:]]{1,5}[\,\.]{0,1}[[:digit:]]{0,5}' ), ',',
                                                 '.' ), '9999999999.9999' ) * 1024 AS NUMERIC(20, 2) )
             WHEN position ( 'ГБ' IN upper ( tfp_name ) ) > 0
               THEN cast ( to_number ( replace ( substring ( substring ( upper ( tfp_name )
                                                                         FROM
                                                                         '[[:digit:]]{1,5}[\,\.]{0,1}[[:digit:]]{0,5}[[:space:]]{0,3}ГБ' )
                                                             FROM '[[:digit:]]{1,5}[\,\.]{0,1}[[:digit:]]{0,5}' ), ',',
                                                 '.' ), '9999999999.9999' ) * 1024 * 1024 AS NUMERIC(20, 2) )
             WHEN cast ( substring ( upper ( tfp_name ) FROM '[[:digit:]]{1,5}' ) AS NUMERIC(20, 2) ) >= 64.0
                  AND
                  ( log ( 2.0, cast ( substring ( upper ( tfp_name ) FROM '[[:digit:]]{1,5}' ) AS NUMERIC(20, 2) ) ) -
                    ceil ( log ( 2.0, cast ( substring ( upper ( tfp_name )
                                                         FROM '[[:digit:]]{1,5}' ) AS NUMERIC(20, 2) ) ) ) ) = 0.0
               THEN cast ( substring ( upper ( tfp_name ) FROM '[[:digit:]]{1,5}' ) AS NUMERIC(20, 2) )
             WHEN upper ( tfp_name ) LIKE '%U_11111_%'
               THEN 11111 :: NUMERIC(10, 2)
             WHEN upper ( tfp_name ) LIKE '%U_1111_%'
               THEN 1111 :: NUMERIC(10, 2)
             WHEN upper ( tfp_name ) LIKE '%U_15555%'
               THEN 15555 :: NUMERIC(10, 2)
             WHEN upper ( tfp_name ) LIKE '%U_22222%'
               THEN 22222 :: NUMERIC(10, 2)
             WHEN upper ( tfp_name ) LIKE '%U_2222_%'
               THEN 2222 :: NUMERIC(10, 2)
             WHEN upper ( tfp_name ) LIKE '%U_33333%'
               THEN 33333 :: NUMERIC(10, 2)
             WHEN upper ( tfp_name ) LIKE '%U_44444%'
               THEN 44444 :: NUMERIC(10, 2)
             WHEN upper ( tfp_name ) LIKE '%U_4444_%'
               THEN 4444 :: NUMERIC(10, 2)
             WHEN upper ( tfp_name ) LIKE '%U_5555_%'
               THEN 5555 :: NUMERIC(10, 2)
             WHEN upper ( tfp_name ) LIKE '%U_6666_%'
               THEN 6666 :: NUMERIC(10, 2)
             WHEN upper ( tfp_name ) LIKE '%U_77777%'
               THEN 77777 :: NUMERIC(10, 2)
             WHEN upper ( tfp_name ) LIKE '%U_8888_%'
               THEN 8888 :: NUMERIC(10, 2)
             WHEN tfp_name LIKE '%Juniper%384%'
               THEN 384 :: NUMERIC(10, 2)
             WHEN tfp_name LIKE '%Juniper%768%'
               THEN 768 :: NUMERIC(10, 2)
             WHEN tfp_name LIKE '%Juniper%1536%'
               THEN 1536 :: NUMERIC(10, 2)
             WHEN tfp_name LIKE '%Juniper%2200%'
               THEN 2200 :: NUMERIC(10, 2)
             ELSE NULL
             END
           END           AS           speed_tp,
           tfp_name      AS           rtpl_name,
           CASE WHEN position ( 'DSL' IN upper ( tfp_name ) ) > 0
             THEN 'xDSL'
           WHEN position ( 'PON' IN upper ( tfp_name ) ) > 0
             THEN 'PON'
           WHEN position ( 'FTTX' IN upper ( tfp_name ) ) > 0
             THEN 'FTTx'
           WHEN position ( 'DOCSIS' IN upper ( tfp_name ) ) > 0
             THEN 'DOCSIS'
           WHEN position ( 'ETTH' IN upper ( tfp_name ) ) > 0
             THEN 'ETTH'
           WHEN position ( 'ETHERNET' IN upper ( tfp_name ) ) > 0
             THEN 'ETTH'
           ELSE NULL
           END           AS           tech_name,
           us_tfp_change AS           tp_start,
           row_number ( )
           OVER (
             PARTITION BY account
             ORDER BY us_tfp_change ) rn
         FROM (
                SELECT
                  abn.ab_account AS account,
                  usr_srv_atr.usa_value,
                  pln.tfp_name,
                  usr.us_tfp_change
                FROM edw_ods.t_000013_abonent abn --(ab_account - лицевой счет)
                  INNER JOIN (
                               SELECT
                                 t.us_ab_id,
                                 t.US_USER_NAME,
                                 t.US_TFP_CODE,
                                 t.us_tfp_change,
                                 row_number ( )
                                 OVER (
                                   PARTITION BY t.us_ab_id
                                   ORDER BY t.input_date DESC ) rn
                               FROM edw_ods.t_000013_ct_users t
                               WHERE t.us_close_date IS NULL
                             ) usr
                    ON usr.us_ab_id = abn.ab_id
                       AND usr.rn = 1
                  LEFT JOIN (
                              SELECT
                                t.USS_US_USER_NAME,
                                t.USS_LOGNAME,
                                row_number ( )
                                OVER (
                                  PARTITION BY USS_US_USER_NAME
                                  ORDER BY t.input_date DESC ) rn
                              FROM edw_ods.t_000013_ct_user_services t
                              WHERE t.USS_SL_TYPE = 'RADIUS'
                            ) usr_srv
                    ON usr_srv.USS_US_USER_NAME = usr.US_USER_NAME
                       AND usr_srv.rn = 1
                  LEFT JOIN edw_ods.t_000013_tb_user_serv_attrs usr_srv_atr
                    ON usr_srv_atr.USA_USS_LOGNAME = usr_srv.USS_LOGNAME
                       AND usr_srv_atr.USA_SAT_NAME = 'profile'
                  LEFT JOIN edw_ods.t_000013_tb_tariff_plans pln
                    ON usr.US_TFP_CODE = pln.TFP_CODE

                UNION

                SELECT
                  abn.ab_account AS account,
                  usr_srv_atr.usa_value,
                  pln.tfp_name,
                  usr.us_tfp_change
                FROM edw_ods.t_000014_abonent abn --(ab_account - лицевой счет)
                  INNER JOIN (
                               SELECT
                                 t.us_ab_id,
                                 t.US_USER_NAME,
                                 t.US_TFP_CODE,
                                 t.us_tfp_change,
                                 row_number ( )
                                 OVER (
                                   PARTITION BY t.us_ab_id
                                   ORDER BY t.input_date DESC ) rn
                               FROM edw_ods.t_000014_ct_users t
                               WHERE t.us_close_date IS NULL
                             ) usr
                    ON usr.us_ab_id = abn.ab_id
                       AND usr.rn = 1
                  LEFT JOIN (
                              SELECT
                                t.USS_US_USER_NAME,
                                t.USS_LOGNAME,
                                row_number ( )
                                OVER (
                                  PARTITION BY USS_US_USER_NAME
                                  ORDER BY t.input_date DESC ) rn
                              FROM edw_ods.t_000014_ct_user_services t
                              WHERE t.USS_SL_TYPE = 'RADIUS'
                            ) usr_srv
                    ON usr_srv.USS_US_USER_NAME = usr.US_USER_NAME
                       AND usr_srv.rn = 1
                  LEFT JOIN edw_ods.t_000014_tb_user_serv_attrs usr_srv_atr
                    ON usr_srv_atr.USA_USS_LOGNAME = usr_srv.USS_LOGNAME
                       AND usr_srv_atr.USA_SAT_NAME = 'profile'
                  LEFT JOIN edw_ods.t_000014_tb_tariff_plans pln
                    ON usr.US_TFP_CODE = pln.TFP_CODE

                UNION

                SELECT
                  abn.ab_account AS account,
                  usr_srv_atr.usa_value,
                  pln.tfp_name,
                  usr.us_tfp_change
                FROM edw_ods.t_000015_abonent abn --(ab_account - лицевой счет)
                  INNER JOIN (
                               SELECT
                                 t.us_ab_id,
                                 t.US_USER_NAME,
                                 t.US_TFP_CODE,
                                 t.us_tfp_change,
                                 row_number ( )
                                 OVER (
                                   PARTITION BY t.us_ab_id
                                   ORDER BY t.input_date DESC ) rn
                               FROM edw_ods.t_000015_ct_users t
                               WHERE t.us_close_date IS NULL
                             ) usr
                    ON usr.us_ab_id = abn.ab_id
                       AND usr.rn = 1
                  LEFT JOIN (
                              SELECT
                                t.USS_US_USER_NAME,
                                t.USS_LOGNAME,
                                row_number ( )
                                OVER (
                                  PARTITION BY USS_US_USER_NAME
                                  ORDER BY t.input_date DESC ) rn
                              FROM edw_ods.t_000015_ct_user_services t
                              WHERE t.USS_SL_TYPE = 'RADIUS'
                            ) usr_srv
                    ON usr_srv.USS_US_USER_NAME = usr.US_USER_NAME
                       AND usr_srv.rn = 1
                  LEFT JOIN edw_ods.t_000015_tb_user_serv_attrs usr_srv_atr
                    ON usr_srv_atr.USA_USS_LOGNAME = usr_srv.USS_LOGNAME
                       AND usr_srv_atr.USA_SAT_NAME = 'profile'
                  LEFT JOIN edw_ods.t_000015_tb_tariff_plans pln
                    ON usr.US_TFP_CODE = pln.TFP_CODE

                UNION

                SELECT
                  abn.ab_account AS account,
                  usr_srv_atr.usa_value,
                  pln.tfp_name,
                  usr.us_tfp_change
                FROM edw_ods.t_000016_abonent abn --(ab_account - лицевой счет)
                  INNER JOIN (
                               SELECT
                                 t.us_ab_id,
                                 t.US_USER_NAME,
                                 t.US_TFP_CODE,
                                 t.us_tfp_change,
                                 row_number ( )
                                 OVER (
                                   PARTITION BY t.us_ab_id
                                   ORDER BY t.input_date DESC ) rn
                               FROM edw_ods.t_000016_ct_users t
                               WHERE t.us_close_date IS NULL
                             ) usr
                    ON usr.us_ab_id = abn.ab_id
                       AND usr.rn = 1
                  LEFT JOIN (
                              SELECT
                                t.USS_US_USER_NAME,
                                t.USS_LOGNAME,
                                row_number ( )
                                OVER (
                                  PARTITION BY USS_US_USER_NAME
                                  ORDER BY t.input_date DESC ) rn
                              FROM edw_ods.t_000016_ct_user_services t
                              WHERE t.USS_SL_TYPE = 'RADIUS'
                            ) usr_srv
                    ON usr_srv.USS_US_USER_NAME = usr.US_USER_NAME
                       AND usr_srv.rn = 1
                  LEFT JOIN edw_ods.t_000016_tb_user_serv_attrs usr_srv_atr
                    ON usr_srv_atr.USA_USS_LOGNAME = usr_srv.USS_LOGNAME
                       AND usr_srv_atr.USA_SAT_NAME = 'profile'
                  LEFT JOIN edw_ods.t_000016_tb_tariff_plans pln
                    ON usr.US_TFP_CODE = pln.TFP_CODE

                UNION

                SELECT
                  abn.ab_account AS account,
                  usr_srv_atr.usa_value,
                  pln.tfp_name,
                  usr.us_tfp_change
                FROM edw_ods.t_000017_abonent abn --(ab_account - лицевой счет)
                  INNER JOIN (
                               SELECT
                                 t.us_ab_id,
                                 t.US_USER_NAME,
                                 t.US_TFP_CODE,
                                 t.us_tfp_change,
                                 row_number ( )
                                 OVER (
                                   PARTITION BY t.us_ab_id
                                   ORDER BY t.input_date DESC ) rn
                               FROM edw_ods.t_000017_ct_users t
                               WHERE t.us_close_date IS NULL
                             ) usr
                    ON usr.us_ab_id = abn.ab_id
                       AND usr.rn = 1
                  LEFT JOIN (
                              SELECT
                                t.USS_US_USER_NAME,
                                t.USS_LOGNAME,
                                row_number ( )
                                OVER (
                                  PARTITION BY USS_US_USER_NAME
                                  ORDER BY t.input_date DESC ) rn
                              FROM edw_ods.t_000017_ct_user_services t
                              WHERE t.USS_SL_TYPE = 'RADIUS'
                            ) usr_srv
                    ON usr_srv.USS_US_USER_NAME = usr.US_USER_NAME
                       AND usr_srv.rn = 1
                  LEFT JOIN edw_ods.t_000017_tb_user_serv_attrs usr_srv_atr
                    ON usr_srv_atr.USA_USS_LOGNAME = usr_srv.USS_LOGNAME
                       AND usr_srv_atr.USA_SAT_NAME = 'profile'
                  LEFT JOIN edw_ods.t_000017_tb_tariff_plans pln
                    ON usr.US_TFP_CODE = pln.TFP_CODE

                UNION

                SELECT
                  abn.ab_account AS account,
                  usr_srv_atr.usa_value,
                  pln.tfp_name,
                  usr.us_tfp_change
                FROM edw_ods.t_000018_abonent abn --(ab_account - лицевой счет)
                  INNER JOIN (
                               SELECT
                                 t.us_ab_id,
                                 t.US_USER_NAME,
                                 t.US_TFP_CODE,
                                 t.us_tfp_change,
                                 row_number ( )
                                 OVER (
                                   PARTITION BY t.us_ab_id
                                   ORDER BY t.input_date DESC ) rn
                               FROM edw_ods.t_000018_ct_users t
                               WHERE t.us_close_date IS NULL
                             ) usr
                    ON usr.us_ab_id = abn.ab_id
                       AND usr.rn = 1
                  LEFT JOIN (
                              SELECT
                                t.USS_US_USER_NAME,
                                t.USS_LOGNAME,
                                row_number ( )
                                OVER (
                                  PARTITION BY USS_US_USER_NAME
                                  ORDER BY t.input_date DESC ) rn
                              FROM edw_ods.t_000018_ct_user_services t
                              WHERE t.USS_SL_TYPE = 'RADIUS'
                            ) usr_srv
                    ON usr_srv.USS_US_USER_NAME = usr.US_USER_NAME
                       AND usr_srv.rn = 1
                  LEFT JOIN edw_ods.t_000018_tb_user_serv_attrs usr_srv_atr
                    ON usr_srv_atr.USA_USS_LOGNAME = usr_srv.USS_LOGNAME
                       AND usr_srv_atr.USA_SAT_NAME = 'profile'
                  LEFT JOIN edw_ods.t_000018_tb_tariff_plans pln
                    ON usr.US_TFP_CODE = pln.TFP_CODE

                UNION

                SELECT
                  abn.ab_account AS account,
                  usr_srv_atr.usa_value,
                  pln.tfp_name,
                  usr.us_tfp_change
                FROM edw_ods.t_000019_abonent abn --(ab_account - лицевой счет)
                  INNER JOIN (
                               SELECT
                                 t.us_ab_id,
                                 t.US_USER_NAME,
                                 t.US_TFP_CODE,
                                 t.us_tfp_change,
                                 row_number ( )
                                 OVER (
                                   PARTITION BY t.us_ab_id
                                   ORDER BY t.input_date DESC ) rn
                               FROM edw_ods.t_000019_ct_users t
                               WHERE t.us_close_date IS NULL
                             ) usr
                    ON usr.us_ab_id = abn.ab_id
                       AND usr.rn = 1
                  LEFT JOIN (
                              SELECT
                                t.USS_US_USER_NAME,
                                t.USS_LOGNAME,
                                row_number ( )
                                OVER (
                                  PARTITION BY USS_US_USER_NAME
                                  ORDER BY t.input_date DESC ) rn
                              FROM edw_ods.t_000019_ct_user_services t
                              WHERE t.USS_SL_TYPE = 'RADIUS'
                            ) usr_srv
                    ON usr_srv.USS_US_USER_NAME = usr.US_USER_NAME
                       AND usr_srv.rn = 1
                  LEFT JOIN edw_ods.t_000019_tb_user_serv_attrs usr_srv_atr
                    ON usr_srv_atr.USA_USS_LOGNAME = usr_srv.USS_LOGNAME
                       AND usr_srv_atr.USA_SAT_NAME = 'profile'
                  LEFT JOIN edw_ods.t_000019_tb_tariff_plans pln
                    ON usr.US_TFP_CODE = pln.TFP_CODE

                UNION

                SELECT
                  abn.ab_account AS account,
                  usr_srv_atr.usa_value,
                  pln.tfp_name,
                  usr.us_tfp_change
                FROM edw_ods.t_000020_abonent abn --(ab_account - лицевой счет)
                  INNER JOIN (
                               SELECT
                                 t.us_ab_id,
                                 t.US_USER_NAME,
                                 t.US_TFP_CODE,
                                 t.us_tfp_change,
                                 row_number ( )
                                 OVER (
                                   PARTITION BY t.us_ab_id
                                   ORDER BY t.input_date DESC ) rn
                               FROM edw_ods.t_000020_ct_users t
                               WHERE t.us_close_date IS NULL
                             ) usr
                    ON usr.us_ab_id = abn.ab_id
                       AND usr.rn = 1
                  LEFT JOIN (
                              SELECT
                                t.USS_US_USER_NAME,
                                t.USS_LOGNAME,
                                row_number ( )
                                OVER (
                                  PARTITION BY USS_US_USER_NAME
                                  ORDER BY t.input_date DESC ) rn
                              FROM edw_ods.t_000020_ct_user_services t
                              WHERE t.USS_SL_TYPE = 'RADIUS'
                            ) usr_srv
                    ON usr_srv.USS_US_USER_NAME = usr.US_USER_NAME
                       AND usr_srv.rn = 1
                  LEFT JOIN edw_ods.t_000020_tb_user_serv_attrs usr_srv_atr
                    ON usr_srv_atr.USA_USS_LOGNAME = usr_srv.USS_LOGNAME
                       AND usr_srv_atr.USA_SAT_NAME = 'profile'
                  LEFT JOIN edw_ods.t_000020_tb_tariff_plans pln
                    ON usr.US_TFP_CODE = pln.TFP_CODE

                UNION

                SELECT
                  abn.ab_account AS account,
                  usr_srv_atr.usa_value,
                  pln.tfp_name,
                  usr.us_tfp_change
                FROM edw_ods.t_000021_abonent abn --(ab_account - лицевой счет)
                  INNER JOIN (
                               SELECT
                                 t.us_ab_id,
                                 t.US_USER_NAME,
                                 t.US_TFP_CODE,
                                 t.us_tfp_change,
                                 row_number ( )
                                 OVER (
                                   PARTITION BY t.us_ab_id
                                   ORDER BY t.input_date DESC ) rn
                               FROM edw_ods.t_000021_ct_users t
                               WHERE t.us_close_date IS NULL
                             ) usr
                    ON usr.us_ab_id = abn.ab_id
                       AND usr.rn = 1
                  LEFT JOIN (
                              SELECT
                                t.USS_US_USER_NAME,
                                t.USS_LOGNAME,
                                row_number ( )
                                OVER (
                                  PARTITION BY USS_US_USER_NAME
                                  ORDER BY t.input_date DESC ) rn
                              FROM edw_ods.t_000021_ct_user_services t
                              WHERE t.USS_SL_TYPE = 'RADIUS'
                            ) usr_srv
                    ON usr_srv.USS_US_USER_NAME = usr.US_USER_NAME
                       AND usr_srv.rn = 1
                  LEFT JOIN edw_ods.t_000021_tb_user_serv_attrs usr_srv_atr
                    ON usr_srv_atr.USA_USS_LOGNAME = usr_srv.USS_LOGNAME
                       AND usr_srv_atr.USA_SAT_NAME = 'profile'
                  LEFT JOIN edw_ods.t_000021_tb_tariff_plans pln
                    ON usr.US_TFP_CODE = pln.TFP_CODE

                UNION

                SELECT
                  abn.ab_account AS account,
                  usr_srv_atr.usa_value,
                  pln.tfp_name,
                  usr.us_tfp_change
                FROM edw_ods.t_000022_abonent abn --(ab_account - лицевой счет)
                  INNER JOIN (
                               SELECT
                                 t.us_ab_id,
                                 t.US_USER_NAME,
                                 t.US_TFP_CODE,
                                 t.us_tfp_change,
                                 row_number ( )
                                 OVER (
                                   PARTITION BY t.us_ab_id
                                   ORDER BY t.input_date DESC ) rn
                               FROM edw_ods.t_000022_ct_users t
                               WHERE t.us_close_date IS NULL
                             ) usr
                    ON usr.us_ab_id = abn.ab_id
                       AND usr.rn = 1
                  LEFT JOIN (
                              SELECT
                                t.USS_US_USER_NAME,
                                t.USS_LOGNAME,
                                row_number ( )
                                OVER (
                                  PARTITION BY USS_US_USER_NAME
                                  ORDER BY t.input_date DESC ) rn
                              FROM edw_ods.t_000022_ct_user_services t
                              WHERE t.USS_SL_TYPE = 'RADIUS'
                            ) usr_srv
                    ON usr_srv.USS_US_USER_NAME = usr.US_USER_NAME
                       AND usr_srv.rn = 1
                  LEFT JOIN edw_ods.t_000022_tb_user_serv_attrs usr_srv_atr
                    ON usr_srv_atr.USA_USS_LOGNAME = usr_srv.USS_LOGNAME
                       AND usr_srv_atr.USA_SAT_NAME = 'profile'
                  LEFT JOIN edw_ods.t_000022_tb_tariff_plans pln
                    ON usr.US_TFP_CODE = pln.TFP_CODE

                UNION

                SELECT
                  abn.ab_account AS account,
                  usr_srv_atr.usa_value,
                  pln.tfp_name,
                  usr.us_tfp_change
                FROM edw_ods.t_000023_abonent abn --(ab_account - лицевой счет)
                  INNER JOIN (
                               SELECT
                                 t.us_ab_id,
                                 t.US_USER_NAME,
                                 t.US_TFP_CODE,
                                 t.us_tfp_change,
                                 row_number ( )
                                 OVER (
                                   PARTITION BY t.us_ab_id
                                   ORDER BY t.input_date DESC ) rn
                               FROM edw_ods.t_000023_ct_users t
                               WHERE t.us_close_date IS NULL
                             ) usr
                    ON usr.us_ab_id = abn.ab_id
                       AND usr.rn = 1
                  LEFT JOIN (
                              SELECT
                                t.USS_US_USER_NAME,
                                t.USS_LOGNAME,
                                row_number ( )
                                OVER (
                                  PARTITION BY USS_US_USER_NAME
                                  ORDER BY t.input_date DESC ) rn
                              FROM edw_ods.t_000023_ct_user_services t
                              WHERE t.USS_SL_TYPE = 'RADIUS'
                            ) usr_srv
                    ON usr_srv.USS_US_USER_NAME = usr.US_USER_NAME
                       AND usr_srv.rn = 1
                  LEFT JOIN edw_ods.t_000023_tb_user_serv_attrs usr_srv_atr
                    ON usr_srv_atr.USA_USS_LOGNAME = usr_srv.USS_LOGNAME
                       AND usr_srv_atr.USA_SAT_NAME = 'profile'
                  LEFT JOIN edw_ods.t_000023_tb_tariff_plans pln
                    ON usr.US_TFP_CODE = pln.TFP_CODE

                UNION

                SELECT
                  abn.ab_account AS account,
                  usr_srv_atr.usa_value,
                  pln.tfp_name,
                  usr.us_tfp_change
                FROM edw_ods.t_000024_abonent abn --(ab_account - лицевой счет)
                  INNER JOIN (
                               SELECT
                                 t.us_ab_id,
                                 t.US_USER_NAME,
                                 t.US_TFP_CODE,
                                 t.us_tfp_change,
                                 row_number ( )
                                 OVER (
                                   PARTITION BY t.us_ab_id
                                   ORDER BY t.input_date DESC ) rn
                               FROM edw_ods.t_000024_ct_users t
                               WHERE t.us_close_date IS NULL
                             ) usr
                    ON usr.us_ab_id = abn.ab_id
                       AND usr.rn = 1
                  LEFT JOIN (
                              SELECT
                                t.USS_US_USER_NAME,
                                t.USS_LOGNAME,
                                row_number ( )
                                OVER (
                                  PARTITION BY USS_US_USER_NAME
                                  ORDER BY t.input_date DESC ) rn
                              FROM edw_ods.t_000024_ct_user_services t
                              WHERE t.USS_SL_TYPE = 'RADIUS'
                            ) usr_srv
                    ON usr_srv.USS_US_USER_NAME = usr.US_USER_NAME
                       AND usr_srv.rn = 1
                  LEFT JOIN edw_ods.t_000024_tb_user_serv_attrs usr_srv_atr
                    ON usr_srv_atr.USA_USS_LOGNAME = usr_srv.USS_LOGNAME
                       AND usr_srv_atr.USA_SAT_NAME = 'profile'
                  LEFT JOIN edw_ods.t_000024_tb_tariff_plans pln
                    ON usr.US_TFP_CODE = pln.TFP_CODE
              ) stg
       ) stg2
  WHERE stg2.rn = 1
        AND speed_tp IS NOT NULL
        and 157 = 153;
ANALYSE edw_stg_dmcm.PRE_SHPD_VOLGA_TP_1_PRT_P000157;


TRUNCATE TABLE edw_stg_dmcm.PRE_SHPD_DV_TP_1_PRT_P000157;
INSERT INTO edw_stg_dmcm.PRE_SHPD_DV_TP_1_PRT_P000157
(account, speed_tp, rtpl_name, tech_name, tp_start, src_id)
  SELECT
    account,
    speed_tp,
    rtpl_name,
    tech_name,
    tp_start,
    157 as src_id
  FROM (
         SELECT
           account,

           CASE WHEN usa_value IS NOT NULL
             THEN
               CASE WHEN position ( 'К' IN upper ( usa_value ) ) > 0
                 THEN cast ( to_number ( replace ( substring ( substring ( upper ( usa_value )
                                                                           FROM
                                                                           '[[:digit:]]{1,5}[\,\.]{0,1}[[:digit:]]{0,5}[[:space:]]{0,3}К' )
                                                               FROM '[[:digit:]]{1,5}[\,\.]{0,1}[[:digit:]]{0,5}' ),
                                                   ',',
                                                   '.' ), '9999999999.9999' ) AS NUMERIC(10, 2) )
               WHEN position ( 'K' IN upper ( usa_value ) ) > 0
                 THEN cast ( to_number ( replace ( substring ( substring ( upper ( usa_value )
                                                                           FROM
                                                                           '[[:digit:]]{1,5}[\,\.]{0,1}[[:digit:]]{0,5}[[:space:]]{0,3}K' )
                                                               FROM '[[:digit:]]{1,5}[\,\.]{0,1}[[:digit:]]{0,5}' ),
                                                   ',',
                                                   '.' ), '9999999999.9999' ) AS NUMERIC(10, 2) )
               WHEN position ( 'М' IN upper ( usa_value ) ) > 0
                 THEN cast ( to_number ( replace ( substring ( substring ( upper ( usa_value )
                                                                           FROM
                                                                           '[[:digit:]]{1,5}[\,\.]{0,1}[[:digit:]]{0,5}[[:space:]]{0,3}М' )
                                                               FROM '[[:digit:]]{1,5}[\,\.]{0,1}[[:digit:]]{0,5}' ),
                                                   ',',
                                                   '.' ), '9999999999.9999' ) * 1024 AS NUMERIC(10, 2) )
               WHEN position ( 'M' IN upper ( usa_value ) ) > 0
                 THEN cast ( to_number ( replace ( substring ( substring ( upper ( usa_value )
                                                                           FROM
                                                                           '[[:digit:]]{1,5}[\,\.]{0,1}[[:digit:]]{0,5}[[:space:]]{0,3}M' )
                                                               FROM '[[:digit:]]{1,5}[\,\.]{0,1}[[:digit:]]{0,5}' ),
                                                   ',',
                                                   '.' ), '9999999999.9999' ) * 1024 AS NUMERIC(10, 2) )
               WHEN position ( 'ГБ' IN upper ( usa_value ) ) > 0
                 THEN cast ( to_number ( replace ( substring ( substring ( upper ( usa_value )
                                                                           FROM
                                                                           '[[:digit:]]{1,5}[\,\.]{0,1}[[:digit:]]{0,5}[[:space:]]{0,3}ГБ' )
                                                               FROM '[[:digit:]]{1,5}[\,\.]{0,1}[[:digit:]]{0,5}' ),
                                                   ',',
                                                   '.' ), '9999999999.9999' ) * 1024 * 1024 AS NUMERIC(10, 2) )
               WHEN cast ( substring ( upper ( usa_value ) FROM '[[:digit:]]{1,5}' ) AS NUMERIC(10, 2) ) >= 64.0
                    AND
                    ( log ( 2.0, cast ( substring ( upper ( usa_value ) FROM '[[:digit:]]{1,5}' ) AS NUMERIC(10, 2) ) )
                      -
                      ceil ( log ( 2.0, cast ( substring ( upper ( usa_value )
                                                           FROM '[[:digit:]]{1,5}' ) AS NUMERIC(10, 2) ) ) ) ) = 0.0
                 THEN cast ( substring ( upper ( usa_value ) FROM '[[:digit:]]{1,5}' ) AS NUMERIC(10, 2) )
               WHEN upper ( usa_value ) LIKE '%U_11111_%'
                 THEN 11111 :: NUMERIC(10, 2)
               WHEN upper ( usa_value ) LIKE '%U_1111_%'
                 THEN 1111 :: NUMERIC(10, 2)
               WHEN upper ( usa_value ) LIKE '%U_15555%'
                 THEN 15555 :: NUMERIC(10, 2)
               WHEN upper ( usa_value ) LIKE '%U_22222%'
                 THEN 22222 :: NUMERIC(10, 2)
               WHEN upper ( usa_value ) LIKE '%U_2222_%'
                 THEN 2222 :: NUMERIC(10, 2)
               WHEN upper ( usa_value ) LIKE '%U_33333%'
                 THEN 33333 :: NUMERIC(10, 2)
               WHEN upper ( usa_value ) LIKE '%U_44444%'
                 THEN 44444 :: NUMERIC(10, 2)
               WHEN upper ( usa_value ) LIKE '%U_4444_%'
                 THEN 4444 :: NUMERIC(10, 2)
               WHEN upper ( usa_value ) LIKE '%U_5555_%'
                 THEN 5555 :: NUMERIC(10, 2)
               WHEN upper ( usa_value ) LIKE '%U_6666_%'
                 THEN 6666 :: NUMERIC(10, 2)
               WHEN upper ( usa_value ) LIKE '%U_77777%'
                 THEN 77777 :: NUMERIC(10, 2)
               WHEN upper ( usa_value ) LIKE '%U_8888_%'
                 THEN 8888 :: NUMERIC(10, 2)
               WHEN usa_value LIKE '%Juniper%384%'
                 THEN 384 :: NUMERIC(10, 2)
               WHEN usa_value LIKE '%Juniper%768%'
                 THEN 768 :: NUMERIC(10, 2)
               WHEN usa_value LIKE '%Juniper%1536%'
                 THEN 1536 :: NUMERIC(10, 2)
               WHEN usa_value LIKE '%Juniper%2200%'
                 THEN 2200 :: NUMERIC(10, 2)
               ELSE NULL
               END
           ELSE
             CASE WHEN position ( 'К' IN upper ( tfp_name ) ) > 0
               THEN cast ( to_number ( replace ( substring ( substring ( upper ( tfp_name )
                                                                         FROM
                                                                         '[[:digit:]]{1,5}[\,\.]{0,1}[[:digit:]]{0,5}[[:space:]]{0,3}К' )
                                                             FROM '[[:digit:]]{1,5}[\,\.]{0,1}[[:digit:]]{0,5}' ), ',',
                                                 '.' ), '9999999999.9999' ) AS NUMERIC(10, 2) )
             WHEN position ( 'K' IN upper ( tfp_name ) ) > 0
               THEN cast ( to_number ( replace ( substring ( substring ( upper ( tfp_name )
                                                                         FROM
                                                                         '[[:digit:]]{1,5}[\,\.]{0,1}[[:digit:]]{0,5}[[:space:]]{0,3}K' )
                                                             FROM '[[:digit:]]{1,5}[\,\.]{0,1}[[:digit:]]{0,5}' ), ',',
                                                 '.' ), '9999999999.9999' ) AS NUMERIC(10, 2) )
             WHEN position ( 'М' IN upper ( tfp_name ) ) > 0
               THEN cast ( to_number ( replace ( substring ( substring ( upper ( tfp_name )
                                                                         FROM
                                                                         '[[:digit:]]{1,5}[\,\.]{0,1}[[:digit:]]{0,5}[[:space:]]{0,3}М' )
                                                             FROM '[[:digit:]]{1,5}[\,\.]{0,1}[[:digit:]]{0,5}' ), ',',
                                                 '.' ), '9999999999.9999' ) * 1024 AS NUMERIC(10, 2) )
             WHEN position ( 'M' IN upper ( tfp_name ) ) > 0
               THEN cast ( to_number ( replace ( substring ( substring ( upper ( tfp_name )
                                                                         FROM
                                                                         '[[:digit:]]{1,5}[\,\.]{0,1}[[:digit:]]{0,5}[[:space:]]{0,3}M' )
                                                             FROM '[[:digit:]]{1,5}[\,\.]{0,1}[[:digit:]]{0,5}' ), ',',
                                                 '.' ), '9999999999.9999' ) * 1024 AS NUMERIC(10, 2) )
             WHEN position ( 'ГБ' IN upper ( tfp_name ) ) > 0
               THEN cast ( to_number ( replace ( substring ( substring ( upper ( tfp_name )
                                                                         FROM
                                                                         '[[:digit:]]{1,5}[\,\.]{0,1}[[:digit:]]{0,5}[[:space:]]{0,3}ГБ' )
                                                             FROM '[[:digit:]]{1,5}[\,\.]{0,1}[[:digit:]]{0,5}' ), ',',
                                                 '.' ), '9999999999.9999' ) * 1024 * 1024 AS NUMERIC(10, 2) )
             WHEN cast ( substring ( upper ( tfp_name ) FROM '[[:digit:]]{1,5}' ) AS NUMERIC(10, 2) ) >= 64.0
                  AND
                  ( log ( 2.0, cast ( substring ( upper ( tfp_name ) FROM '[[:digit:]]{1,5}' ) AS NUMERIC(10, 2) ) ) -
                    ceil ( log ( 2.0, cast ( substring ( upper ( tfp_name )
                                                         FROM '[[:digit:]]{1,5}' ) AS NUMERIC(10, 2) ) ) ) ) = 0.0
               THEN cast ( substring ( upper ( tfp_name ) FROM '[[:digit:]]{1,5}' ) AS NUMERIC(10, 2) )
             WHEN upper ( tfp_name ) LIKE '%U_11111_%'
               THEN 11111 :: NUMERIC(10, 2)
             WHEN upper ( tfp_name ) LIKE '%U_1111_%'
               THEN 1111 :: NUMERIC(10, 2)
             WHEN upper ( tfp_name ) LIKE '%U_15555%'
               THEN 15555 :: NUMERIC(10, 2)
             WHEN upper ( tfp_name ) LIKE '%U_22222%'
               THEN 22222 :: NUMERIC(10, 2)
             WHEN upper ( tfp_name ) LIKE '%U_2222_%'
               THEN 2222 :: NUMERIC(10, 2)
             WHEN upper ( tfp_name ) LIKE '%U_33333%'
               THEN 33333 :: NUMERIC(10, 2)
             WHEN upper ( tfp_name ) LIKE '%U_44444%'
               THEN 44444 :: NUMERIC(10, 2)
             WHEN upper ( tfp_name ) LIKE '%U_4444_%'
               THEN 4444 :: NUMERIC(10, 2)
             WHEN upper ( tfp_name ) LIKE '%U_5555_%'
               THEN 5555 :: NUMERIC(10, 2)
             WHEN upper ( tfp_name ) LIKE '%U_6666_%'
               THEN 6666 :: NUMERIC(10, 2)
             WHEN upper ( tfp_name ) LIKE '%U_77777%'
               THEN 77777 :: NUMERIC(10, 2)
             WHEN upper ( tfp_name ) LIKE '%U_8888_%'
               THEN 8888 :: NUMERIC(10, 2)
             WHEN tfp_name LIKE '%Juniper%384%'
               THEN 384 :: NUMERIC(10, 2)
             WHEN tfp_name LIKE '%Juniper%768%'
               THEN 768 :: NUMERIC(10, 2)
             WHEN tfp_name LIKE '%Juniper%1536%'
               THEN 1536 :: NUMERIC(10, 2)
             WHEN tfp_name LIKE '%Juniper%2200%'
               THEN 2200 :: NUMERIC(10, 2)
             ELSE NULL
             END

           END           AS           speed_tp,
           tfp_name      AS           rtpl_name,
           CASE WHEN position ( 'DSL' IN upper ( tfp_name ) ) > 0
             THEN 'xDSL'
           WHEN position ( 'PON' IN upper ( tfp_name ) ) > 0
             THEN 'PON'
           WHEN position ( 'FTTX' IN upper ( tfp_name ) ) > 0
             THEN 'FTTx'
           WHEN position ( 'DOCSIS' IN upper ( tfp_name ) ) > 0
             THEN 'DOCSIS'
           WHEN position ( 'ETTH' IN upper ( tfp_name ) ) > 0
             THEN 'ETTH'
           WHEN position ( 'ETHERNET' IN upper ( tfp_name ) ) > 0
             THEN 'ETTH'
           ELSE NULL
           END           AS           tech_name,
           us_tfp_change AS           tp_start,
           row_number ( )
           OVER (
             PARTITION BY account
             ORDER BY us_tfp_change ) rn
         FROM (
                SELECT
                  abn.ab_account AS account,
                  usr_srv_atr.usa_value,
                  pln.tfp_name,
                  usr.us_tfp_change
                FROM edw_ods.t_000114_abonent abn --(ab_account - лицевой счет)
                  INNER JOIN (
                               SELECT
                                 t.us_ab_id,
                                 t.US_USER_NAME,
                                 t.US_TFP_CODE,
                                 t.us_tfp_change,
                                 row_number ( )
                                 OVER (
                                   PARTITION BY t.us_ab_id
                                   ORDER BY t.input_date DESC ) rn
                               FROM edw_ods.t_000114_ct_users t
                               WHERE t.us_close_date IS NULL
                             ) usr
                    ON usr.us_ab_id = abn.ab_id
                       AND usr.rn = 1
                  LEFT JOIN (
                              SELECT
                                t.USS_US_USER_NAME,
                                t.USS_LOGNAME,
                                row_number ( )
                                OVER (
                                  PARTITION BY USS_US_USER_NAME
                                  ORDER BY t.input_date DESC ) rn
                              FROM edw_ods.t_000114_ct_user_services t
                              WHERE t.USS_SL_TYPE = 'RADIUS'
                            ) usr_srv
                    ON usr_srv.USS_US_USER_NAME = usr.US_USER_NAME
                       AND usr_srv.rn = 1
                  LEFT JOIN edw_ods.t_000114_tb_user_serv_attrs usr_srv_atr
                    ON usr_srv_atr.USA_USS_LOGNAME = usr_srv.USS_LOGNAME
                       AND usr_srv_atr.USA_SAT_NAME = 'profile'
                  LEFT JOIN edw_ods.t_000114_tb_tariff_plans pln
                    ON usr.US_TFP_CODE = pln.TFP_CODE
              ) stg
       ) stg2
  WHERE stg2.rn = 1
        AND speed_tp IS NOT NULL
        and 157 = 157;
ANALYSE edw_stg_dmcm.PRE_SHPD_DV_TP_1_PRT_P000157;


TRUNCATE TABLE edw_stg_dmcm.PRE_SHPD_CENTR_TP_1_PRT_P000157;
INSERT INTO edw_stg_dmcm.PRE_SHPD_CENTR_TP_1_PRT_P000157
(account, speed_tp, rtpl_name, tech_name, tp_start, src_id)
  SELECT
    account,
    speed_tp,
    rtpl_name,
    tech_name,
    tp_start,
    157 as src_id
  FROM (
         SELECT
           account,
           CASE WHEN position ( 'К' IN upper ( sp_speed_in ) ) > 0
             THEN cast ( to_number ( replace ( substring ( substring ( upper ( sp_speed_in )
                                                                       FROM
                                                                       '[[:digit:]]{1,5}[\,\.]{0,1}[[:digit:]]{0,5}[[:space:]]{0,3}К' )
                                                           FROM '[[:digit:]]{1,5}[\,\.]{0,1}[[:digit:]]{0,5}' ), ',',
                                               '.' ),
                                     '9999999999.9999' ) AS NUMERIC(10, 2) )
           WHEN position ( 'K' IN upper ( sp_speed_in ) ) > 0
             THEN cast ( to_number ( replace ( substring ( substring ( upper ( sp_speed_in )
                                                                       FROM
                                                                       '[[:digit:]]{1,5}[\,\.]{0,1}[[:digit:]]{0,5}[[:space:]]{0,3}K' )
                                                           FROM '[[:digit:]]{1,5}[\,\.]{0,1}[[:digit:]]{0,5}' ), ',',
                                               '.' ),
                                     '9999999999.9999' ) AS NUMERIC(10, 2) )
           WHEN position ( 'М' IN upper ( sp_speed_in ) ) > 0
             THEN cast ( to_number ( replace ( substring ( substring ( upper ( sp_speed_in )
                                                                       FROM
                                                                       '[[:digit:]]{1,5}[\,\.]{0,1}[[:digit:]]{0,5}[[:space:]]{0,3}М' )
                                                           FROM '[[:digit:]]{1,5}[\,\.]{0,1}[[:digit:]]{0,5}' ), ',',
                                               '.' ),
                                     '9999999999.9999' ) * 1024 AS NUMERIC(10, 2) )
           WHEN position ( 'M' IN upper ( sp_speed_in ) ) > 0
             THEN cast ( to_number ( replace ( substring ( substring ( upper ( sp_speed_in )
                                                                       FROM
                                                                       '[[:digit:]]{1,5}[\,\.]{0,1}[[:digit:]]{0,5}[[:space:]]{0,3}M' )
                                                           FROM '[[:digit:]]{1,5}[\,\.]{0,1}[[:digit:]]{0,5}' ), ',',
                                               '.' ),
                                     '9999999999.9999' ) * 1024 AS NUMERIC(10, 2) )
           WHEN position ( 'ГБ' IN upper ( sp_speed_in ) ) > 0
             THEN cast ( to_number ( replace ( substring ( substring ( upper ( sp_speed_in )
                                                                       FROM
                                                                       '[[:digit:]]{1,5}[\,\.]{0,1}[[:digit:]]{0,5}[[:space:]]{0,3}ГБ' )
                                                           FROM '[[:digit:]]{1,5}[\,\.]{0,1}[[:digit:]]{0,5}' ), ',',
                                               '.' ),
                                     '9999999999.9999' ) * 1024 * 1024 AS NUMERIC(10, 2) )
           WHEN upper ( sp_speed_in ) SIMILAR TO '^INT([0-9]+)'
             THEN 9999999
           ELSE NULL
           END           AS           speed_tp,
           tfp_name      AS           rtpl_name,
           TECH          AS           tech_name,
           us_tfp_change AS           tp_start,
           row_number ( )
           OVER (
             PARTITION BY account
             ORDER BY us_tfp_change ) rn
         FROM (
                SELECT
                  abn.ab_account AS account,
                  sp.sp_speed_in,
                  sp.sp_speed2_in,
                  sp.sp_speed_out,
                  sp.sp_speed2_out,
                  pln.tfp_name,
                  sp.TECH,
                  usr.us_tfp_change
                FROM edw_ods.t_000063_abonent abn --(ab_account - лицевой счет)
                  INNER JOIN (
                               SELECT
                                 t.us_ab_id,
                                 t.US_USER_NAME,
                                 t.US_TFP_CODE,
                                 t.us_tfp_change,
                                 row_number ( )
                                 OVER (
                                   PARTITION BY t.us_ab_id
                                   ORDER BY t.input_date DESC ) rn
                               FROM edw_ods.t_000063_ct_users t
                               WHERE t.us_close_date IS NULL
                             ) usr
                    ON usr.us_ab_id = abn.ab_id
                       AND usr.rn = 1
                  LEFT JOIN edw_ods.t_000063_TB_SRV_PROFILE sp
                    ON usr.US_TFP_CODE = sp.SP_TFP_CODE
                  LEFT JOIN edw_ods.t_000063_tb_tariff_plans pln
                    ON usr.US_TFP_CODE = pln.TFP_CODE
                UNION

                SELECT
                  abn.ab_account AS account,
                  sp.sp_speed_in,
                  sp.sp_speed2_in,
                  sp.sp_speed_out,
                  sp.sp_speed2_out,
                  pln.tfp_name,
                  sp.TECH,
                  usr.us_tfp_change
                FROM edw_ods.t_000064_abonent abn --(ab_account - лицевой счет)
                  INNER JOIN (
                               SELECT
                                 t.us_ab_id,
                                 t.US_USER_NAME,
                                 t.US_TFP_CODE,
                                 t.us_tfp_change,
                                 row_number ( )
                                 OVER (
                                   PARTITION BY t.us_ab_id
                                   ORDER BY t.input_date DESC ) rn
                               FROM edw_ods.t_000064_ct_users t
                               WHERE t.us_close_date IS NULL
                             ) usr
                    ON usr.us_ab_id = abn.ab_id
                       AND usr.rn = 1
                  LEFT JOIN edw_ods.t_000064_TB_SRV_PROFILE sp
                    ON usr.US_TFP_CODE = sp.SP_TFP_CODE
                  LEFT JOIN edw_ods.t_000064_tb_tariff_plans pln
                    ON usr.US_TFP_CODE = pln.TFP_CODE
                UNION

                SELECT
                  abn.ab_account AS account,
                  sp.sp_speed_in,
                  sp.sp_speed2_in,
                  sp.sp_speed_out,
                  sp.sp_speed2_out,
                  pln.tfp_name,
                  sp.TECH,
                  usr.us_tfp_change
                FROM edw_ods.t_000065_abonent abn --(ab_account - лицевой счет)
                  INNER JOIN (
                               SELECT
                                 t.us_ab_id,
                                 t.US_USER_NAME,
                                 t.US_TFP_CODE,
                                 t.us_tfp_change,
                                 row_number ( )
                                 OVER (
                                   PARTITION BY t.us_ab_id
                                   ORDER BY t.input_date DESC ) rn
                               FROM edw_ods.t_000065_ct_users t
                               WHERE t.us_close_date IS NULL
                             ) usr
                    ON usr.us_ab_id = abn.ab_id
                       AND usr.rn = 1
                  LEFT JOIN edw_ods.t_000065_TB_SRV_PROFILE sp
                    ON usr.US_TFP_CODE = sp.SP_TFP_CODE
                  LEFT JOIN edw_ods.t_000065_tb_tariff_plans pln
                    ON usr.US_TFP_CODE = pln.TFP_CODE
                UNION

                SELECT
                  abn.ab_account AS account,
                  sp.sp_speed_in,
                  sp.sp_speed2_in,
                  sp.sp_speed_out,
                  sp.sp_speed2_out,
                  pln.tfp_name,
                  sp.TECH,
                  usr.us_tfp_change
                FROM edw_ods.t_000066_abonent abn --(ab_account - лицевой счет)
                  INNER JOIN (
                               SELECT
                                 t.us_ab_id,
                                 t.US_USER_NAME,
                                 t.US_TFP_CODE,
                                 t.us_tfp_change,
                                 row_number ( )
                                 OVER (
                                   PARTITION BY t.us_ab_id
                                   ORDER BY t.input_date DESC ) rn
                               FROM edw_ods.t_000066_ct_users t
                               WHERE t.us_close_date IS NULL
                             ) usr
                    ON usr.us_ab_id = abn.ab_id
                       AND usr.rn = 1
                  LEFT JOIN edw_ods.t_000066_TB_SRV_PROFILE sp
                    ON usr.US_TFP_CODE = sp.SP_TFP_CODE
                  LEFT JOIN edw_ods.t_000066_tb_tariff_plans pln
                    ON usr.US_TFP_CODE = pln.TFP_CODE
                UNION

                SELECT
                  abn.ab_account AS account,
                  sp.sp_speed_in,
                  sp.sp_speed2_in,
                  sp.sp_speed_out,
                  sp.sp_speed2_out,
                  pln.tfp_name,
                  sp.TECH,
                  usr.us_tfp_change
                FROM edw_ods.t_000067_abonent abn --(ab_account - лицевой счет)
                  INNER JOIN (
                               SELECT
                                 t.us_ab_id,
                                 t.US_USER_NAME,
                                 t.US_TFP_CODE,
                                 t.us_tfp_change,
                                 row_number ( )
                                 OVER (
                                   PARTITION BY t.us_ab_id
                                   ORDER BY t.input_date DESC ) rn
                               FROM edw_ods.t_000067_ct_users t
                               WHERE t.us_close_date IS NULL
                             ) usr
                    ON usr.us_ab_id = abn.ab_id
                       AND usr.rn = 1
                  LEFT JOIN edw_ods.t_000067_TB_SRV_PROFILE sp
                    ON usr.US_TFP_CODE = sp.SP_TFP_CODE
                  LEFT JOIN edw_ods.t_000067_tb_tariff_plans pln
                    ON usr.US_TFP_CODE = pln.TFP_CODE
                UNION

                SELECT
                  abn.ab_account AS account,
                  sp.sp_speed_in,
                  sp.sp_speed2_in,
                  sp.sp_speed_out,
                  sp.sp_speed2_out,
                  pln.tfp_name,
                  sp.TECH,
                  usr.us_tfp_change
                FROM edw_ods.t_000068_abonent abn --(ab_account - лицевой счет)
                  INNER JOIN (
                               SELECT
                                 t.us_ab_id,
                                 t.US_USER_NAME,
                                 t.US_TFP_CODE,
                                 t.us_tfp_change,
                                 row_number ( )
                                 OVER (
                                   PARTITION BY t.us_ab_id
                                   ORDER BY t.input_date DESC ) rn
                               FROM edw_ods.t_000068_ct_users t
                               WHERE t.us_close_date IS NULL
                             ) usr
                    ON usr.us_ab_id = abn.ab_id
                       AND usr.rn = 1
                  LEFT JOIN edw_ods.t_000068_TB_SRV_PROFILE sp
                    ON usr.US_TFP_CODE = sp.SP_TFP_CODE
                  LEFT JOIN edw_ods.t_000068_tb_tariff_plans pln
                    ON usr.US_TFP_CODE = pln.TFP_CODE
                UNION

                SELECT
                  abn.ab_account AS account,
                  sp.sp_speed_in,
                  sp.sp_speed2_in,
                  sp.sp_speed_out,
                  sp.sp_speed2_out,
                  pln.tfp_name,
                  sp.TECH,
                  usr.us_tfp_change
                FROM edw_ods.t_000069_abonent abn --(ab_account - лицевой счет)
                  INNER JOIN (
                               SELECT
                                 t.us_ab_id,
                                 t.US_USER_NAME,
                                 t.US_TFP_CODE,
                                 t.us_tfp_change,
                                 row_number ( )
                                 OVER (
                                   PARTITION BY t.us_ab_id
                                   ORDER BY t.input_date DESC ) rn
                               FROM edw_ods.t_000069_ct_users t
                               WHERE t.us_close_date IS NULL
                             ) usr
                    ON usr.us_ab_id = abn.ab_id
                       AND usr.rn = 1
                  LEFT JOIN edw_ods.t_000069_TB_SRV_PROFILE sp
                    ON usr.US_TFP_CODE = sp.SP_TFP_CODE
                  LEFT JOIN edw_ods.t_000069_tb_tariff_plans pln
                    ON usr.US_TFP_CODE = pln.TFP_CODE
                UNION

                SELECT
                  abn.ab_account AS account,
                  sp.sp_speed_in,
                  sp.sp_speed2_in,
                  sp.sp_speed_out,
                  sp.sp_speed2_out,
                  pln.tfp_name,
                  sp.TECH,
                  usr.us_tfp_change
                FROM edw_ods.t_000070_abonent abn --(ab_account - лицевой счет)
                  INNER JOIN (
                               SELECT
                                 t.us_ab_id,
                                 t.US_USER_NAME,
                                 t.US_TFP_CODE,
                                 t.us_tfp_change,
                                 row_number ( )
                                 OVER (
                                   PARTITION BY t.us_ab_id
                                   ORDER BY t.input_date DESC ) rn
                               FROM edw_ods.t_000070_ct_users t
                               WHERE t.us_close_date IS NULL
                             ) usr
                    ON usr.us_ab_id = abn.ab_id
                       AND usr.rn = 1
                  LEFT JOIN edw_ods.t_000070_TB_SRV_PROFILE sp
                    ON usr.US_TFP_CODE = sp.SP_TFP_CODE
                  LEFT JOIN edw_ods.t_000070_tb_tariff_plans pln
                    ON usr.US_TFP_CODE = pln.TFP_CODE
                UNION

                SELECT
                  abn.ab_account AS account,
                  sp.sp_speed_in,
                  sp.sp_speed2_in,
                  sp.sp_speed_out,
                  sp.sp_speed2_out,
                  pln.tfp_name,
                  sp.TECH,
                  usr.us_tfp_change
                FROM edw_ods.t_000071_abonent abn --(ab_account - лицевой счет)
                  INNER JOIN (
                               SELECT
                                 t.us_ab_id,
                                 t.US_USER_NAME,
                                 t.US_TFP_CODE,
                                 t.us_tfp_change,
                                 row_number ( )
                                 OVER (
                                   PARTITION BY t.us_ab_id
                                   ORDER BY t.input_date DESC ) rn
                               FROM edw_ods.t_000071_ct_users t
                               WHERE t.us_close_date IS NULL
                             ) usr
                    ON usr.us_ab_id = abn.ab_id
                       AND usr.rn = 1
                  LEFT JOIN edw_ods.t_000071_TB_SRV_PROFILE sp
                    ON usr.US_TFP_CODE = sp.SP_TFP_CODE
                  LEFT JOIN edw_ods.t_000071_tb_tariff_plans pln
                    ON usr.US_TFP_CODE = pln.TFP_CODE
                UNION

                SELECT
                  abn.ab_account AS account,
                  sp.sp_speed_in,
                  sp.sp_speed2_in,
                  sp.sp_speed_out,
                  sp.sp_speed2_out,
                  pln.tfp_name,
                  sp.TECH,
                  usr.us_tfp_change
                FROM edw_ods.t_000072_abonent abn --(ab_account - лицевой счет)
                  INNER JOIN (
                               SELECT
                                 t.us_ab_id,
                                 t.US_USER_NAME,
                                 t.US_TFP_CODE,
                                 t.us_tfp_change,
                                 row_number ( )
                                 OVER (
                                   PARTITION BY t.us_ab_id
                                   ORDER BY t.input_date DESC ) rn
                               FROM edw_ods.t_000072_ct_users t
                               WHERE t.us_close_date IS NULL
                             ) usr
                    ON usr.us_ab_id = abn.ab_id
                       AND usr.rn = 1
                  LEFT JOIN edw_ods.t_000072_TB_SRV_PROFILE sp
                    ON usr.US_TFP_CODE = sp.SP_TFP_CODE
                  LEFT JOIN edw_ods.t_000072_tb_tariff_plans pln
                    ON usr.US_TFP_CODE = pln.TFP_CODE
                UNION

                SELECT
                  abn.ab_account AS account,
                  sp.sp_speed_in,
                  sp.sp_speed2_in,
                  sp.sp_speed_out,
                  sp.sp_speed2_out,
                  pln.tfp_name,
                  sp.TECH,
                  usr.us_tfp_change
                FROM edw_ods.t_000073_abonent abn --(ab_account - лицевой счет)
                  INNER JOIN (
                               SELECT
                                 t.us_ab_id,
                                 t.US_USER_NAME,
                                 t.US_TFP_CODE,
                                 t.us_tfp_change,
                                 row_number ( )
                                 OVER (
                                   PARTITION BY t.us_ab_id
                                   ORDER BY t.input_date DESC ) rn
                               FROM edw_ods.t_000073_ct_users t
                               WHERE t.us_close_date IS NULL
                             ) usr
                    ON usr.us_ab_id = abn.ab_id
                       AND usr.rn = 1
                  LEFT JOIN edw_ods.t_000073_TB_SRV_PROFILE sp
                    ON usr.US_TFP_CODE = sp.SP_TFP_CODE
                  LEFT JOIN edw_ods.t_000073_tb_tariff_plans pln
                    ON usr.US_TFP_CODE = pln.TFP_CODE
                UNION

                SELECT
                  abn.ab_account AS account,
                  sp.sp_speed_in,
                  sp.sp_speed2_in,
                  sp.sp_speed_out,
                  sp.sp_speed2_out,
                  pln.tfp_name,
                  sp.TECH,
                  usr.us_tfp_change
                FROM edw_ods.t_000074_abonent abn --(ab_account - лицевой счет)
                  INNER JOIN (
                               SELECT
                                 t.us_ab_id,
                                 t.US_USER_NAME,
                                 t.US_TFP_CODE,
                                 t.us_tfp_change,
                                 row_number ( )
                                 OVER (
                                   PARTITION BY t.us_ab_id
                                   ORDER BY t.input_date DESC ) rn
                               FROM edw_ods.t_000074_ct_users t
                               WHERE t.us_close_date IS NULL
                             ) usr
                    ON usr.us_ab_id = abn.ab_id
                       AND usr.rn = 1
                  LEFT JOIN edw_ods.t_000074_TB_SRV_PROFILE sp
                    ON usr.US_TFP_CODE = sp.SP_TFP_CODE
                  LEFT JOIN edw_ods.t_000074_tb_tariff_plans pln
                    ON usr.US_TFP_CODE = pln.TFP_CODE
                UNION

                SELECT
                  abn.ab_account AS account,
                  sp.sp_speed_in,
                  sp.sp_speed2_in,
                  sp.sp_speed_out,
                  sp.sp_speed2_out,
                  pln.tfp_name,
                  sp.TECH,
                  usr.us_tfp_change
                FROM edw_ods.t_000075_abonent abn --(ab_account - лицевой счет)
                  INNER JOIN (
                               SELECT
                                 t.us_ab_id,
                                 t.US_USER_NAME,
                                 t.US_TFP_CODE,
                                 t.us_tfp_change,
                                 row_number ( )
                                 OVER (
                                   PARTITION BY t.us_ab_id
                                   ORDER BY t.input_date DESC ) rn
                               FROM edw_ods.t_000075_ct_users t
                               WHERE t.us_close_date IS NULL
                             ) usr
                    ON usr.us_ab_id = abn.ab_id
                       AND usr.rn = 1
                  LEFT JOIN edw_ods.t_000075_TB_SRV_PROFILE sp
                    ON usr.US_TFP_CODE = sp.SP_TFP_CODE
                  LEFT JOIN edw_ods.t_000075_tb_tariff_plans pln
                    ON usr.US_TFP_CODE = pln.TFP_CODE
                UNION

                SELECT
                  abn.ab_account AS account,
                  sp.sp_speed_in,
                  sp.sp_speed2_in,
                  sp.sp_speed_out,
                  sp.sp_speed2_out,
                  pln.tfp_name,
                  sp.TECH,
                  usr.us_tfp_change
                FROM edw_ods.t_000076_abonent abn --(ab_account - лицевой счет)
                  INNER JOIN (
                               SELECT
                                 t.us_ab_id,
                                 t.US_USER_NAME,
                                 t.US_TFP_CODE,
                                 t.us_tfp_change,
                                 row_number ( )
                                 OVER (
                                   PARTITION BY t.us_ab_id
                                   ORDER BY t.input_date DESC ) rn
                               FROM edw_ods.t_000076_ct_users t
                               WHERE t.us_close_date IS NULL
                             ) usr
                    ON usr.us_ab_id = abn.ab_id
                       AND usr.rn = 1
                  LEFT JOIN edw_ods.t_000076_TB_SRV_PROFILE sp
                    ON usr.US_TFP_CODE = sp.SP_TFP_CODE
                  LEFT JOIN edw_ods.t_000076_tb_tariff_plans pln
                    ON usr.US_TFP_CODE = pln.TFP_CODE
                UNION

                SELECT
                  abn.ab_account AS account,
                  sp.sp_speed_in,
                  sp.sp_speed2_in,
                  sp.sp_speed_out,
                  sp.sp_speed2_out,
                  pln.tfp_name,
                  sp.TECH,
                  usr.us_tfp_change
                FROM edw_ods.t_000077_abonent abn --(ab_account - лицевой счет)
                  INNER JOIN (
                               SELECT
                                 t.us_ab_id,
                                 t.US_USER_NAME,
                                 t.US_TFP_CODE,
                                 t.us_tfp_change,
                                 row_number ( )
                                 OVER (
                                   PARTITION BY t.us_ab_id
                                   ORDER BY t.input_date DESC ) rn
                               FROM edw_ods.t_000077_ct_users t
                               WHERE t.us_close_date IS NULL
                             ) usr
                    ON usr.us_ab_id = abn.ab_id
                       AND usr.rn = 1
                  LEFT JOIN edw_ods.t_000077_TB_SRV_PROFILE sp
                    ON usr.US_TFP_CODE = sp.SP_TFP_CODE
                  LEFT JOIN edw_ods.t_000077_tb_tariff_plans pln
                    ON usr.US_TFP_CODE = pln.TFP_CODE
              ) stg1
         WHERE sp_speed_in IS NOT NULL
       ) stg2
  WHERE stg2.rn = 1
        AND speed_tp IS NOT NULL
        and 157 = 151;
ANALYSE edw_stg_dmcm.PRE_SHPD_CENTR_TP_1_PRT_P000157;


TRUNCATE TABLE edw_stg_dmcm.PRE_SHPD_SIBIR_TP_1_PRT_P000157;
INSERT INTO edw_stg_dmcm.PRE_SHPD_SIBIR_TP_1_PRT_P000157
(account, speed_tp, rtpl_name, tech_name, tp_start, src_id)
  SELECT
    account,
    speed_tp,
    rtpl_name,
    tech_name,
    tp_start,
    157 as src_id
  FROM (
         SELECT
           account,
           CASE WHEN usa_value IS NOT NULL
             THEN
               CASE WHEN position ( 'К' IN upper ( usa_value ) ) > 0
                 THEN cast ( to_number ( replace ( substring ( substring ( upper ( usa_value )
                                                                           FROM
                                                                           '[[:digit:]]{1,5}[\,\.]{0,1}[[:digit:]]{0,5}[[:space:]]{0,3}К' )
                                                               FROM '[[:digit:]]{1,5}[\,\.]{0,1}[[:digit:]]{0,5}' ),
                                                   ',',
                                                   '.' ), '9999999999.9999' ) AS NUMERIC(10, 2) )
               WHEN position ( 'K' IN upper ( usa_value ) ) > 0
                 THEN cast ( to_number ( replace ( substring ( substring ( upper ( usa_value )
                                                                           FROM
                                                                           '[[:digit:]]{1,5}[\,\.]{0,1}[[:digit:]]{0,5}[[:space:]]{0,3}K' )
                                                               FROM '[[:digit:]]{1,5}[\,\.]{0,1}[[:digit:]]{0,5}' ),
                                                   ',',
                                                   '.' ), '9999999999.9999' ) AS NUMERIC(10, 2) )
               WHEN position ( 'М' IN upper ( usa_value ) ) > 0
                 THEN cast ( to_number ( replace ( substring ( substring ( upper ( usa_value )
                                                                           FROM
                                                                           '[[:digit:]]{1,5}[\,\.]{0,1}[[:digit:]]{0,5}[[:space:]]{0,3}М' )
                                                               FROM '[[:digit:]]{1,5}[\,\.]{0,1}[[:digit:]]{0,5}' ),
                                                   ',',
                                                   '.' ), '9999999999.9999' ) * 1024 AS NUMERIC(10, 2) )
               WHEN position ( 'M' IN upper ( usa_value ) ) > 0
                 THEN cast ( to_number ( replace ( substring ( substring ( upper ( usa_value )
                                                                           FROM
                                                                           '[[:digit:]]{1,5}[\,\.]{0,1}[[:digit:]]{0,5}[[:space:]]{0,3}M' )
                                                               FROM '[[:digit:]]{1,5}[\,\.]{0,1}[[:digit:]]{0,5}' ),
                                                   ',',
                                                   '.' ), '9999999999.9999' ) * 1024 AS NUMERIC(10, 2) )
               WHEN position ( 'ГБ' IN upper ( usa_value ) ) > 0
                 THEN cast ( to_number ( replace ( substring ( substring ( upper ( usa_value )
                                                                           FROM
                                                                           '[[:digit:]]{1,5}[\,\.]{0,1}[[:digit:]]{0,5}[[:space:]]{0,3}ГБ' )
                                                               FROM '[[:digit:]]{1,5}[\,\.]{0,1}[[:digit:]]{0,5}' ),
                                                   ',',
                                                   '.' ), '9999999999.9999' ) * 1024 * 1024 AS NUMERIC(10, 2) )
               WHEN cast ( substring ( upper ( usa_value ) FROM '[[:digit:]]{1,5}' ) AS NUMERIC(10, 2) ) >= 64.0
                    AND
                    ( log ( 2.0, cast ( substring ( upper ( usa_value ) FROM '[[:digit:]]{1,5}' ) AS NUMERIC(10, 2) ) )
                      -
                      ceil ( log ( 2.0, cast ( substring ( upper ( usa_value )
                                                           FROM '[[:digit:]]{1,5}' ) AS NUMERIC(10, 2) ) ) ) ) = 0.0
                 THEN cast ( substring ( upper ( usa_value ) FROM '[[:digit:]]{1,5}' ) AS NUMERIC(10, 2) )
               WHEN upper ( usa_value ) LIKE '%U_11111_%'
                 THEN 11111 :: NUMERIC(10, 2)
               WHEN upper ( usa_value ) LIKE '%U_1111_%'
                 THEN 1111 :: NUMERIC(10, 2)
               WHEN upper ( usa_value ) LIKE '%U_15555%'
                 THEN 15555 :: NUMERIC(10, 2)
               WHEN upper ( usa_value ) LIKE '%U_22222%'
                 THEN 22222 :: NUMERIC(10, 2)
               WHEN upper ( usa_value ) LIKE '%U_2222_%'
                 THEN 2222 :: NUMERIC(10, 2)
               WHEN upper ( usa_value ) LIKE '%U_33333%'
                 THEN 33333 :: NUMERIC(10, 2)
               WHEN upper ( usa_value ) LIKE '%U_44444%'
                 THEN 44444 :: NUMERIC(10, 2)
               WHEN upper ( usa_value ) LIKE '%U_4444_%'
                 THEN 4444 :: NUMERIC(10, 2)
               WHEN upper ( usa_value ) LIKE '%U_5555_%'
                 THEN 5555 :: NUMERIC(10, 2)
               WHEN upper ( usa_value ) LIKE '%U_6666_%'
                 THEN 6666 :: NUMERIC(10, 2)
               WHEN upper ( usa_value ) LIKE '%U_77777%'
                 THEN 77777 :: NUMERIC(10, 2)
               WHEN upper ( usa_value ) LIKE '%U_8888_%'
                 THEN 8888 :: NUMERIC(10, 2)
               WHEN usa_value LIKE '%Juniper%384%'
                 THEN 384 :: NUMERIC(10, 2)
               WHEN usa_value LIKE '%Juniper%768%'
                 THEN 768 :: NUMERIC(10, 2)
               WHEN usa_value LIKE '%Juniper%1536%'
                 THEN 1536 :: NUMERIC(10, 2)
               WHEN usa_value LIKE '%Juniper%2200%'
                 THEN 2200 :: NUMERIC(10, 2)
               ELSE NULL
               END
           ELSE
             CASE WHEN position ( 'К' IN upper ( tfp_name ) ) > 0
               THEN cast ( to_number ( replace ( substring ( substring ( upper ( tfp_name )
                                                                         FROM
                                                                         '[[:digit:]]{1,5}[\,\.]{0,1}[[:digit:]]{0,5}[[:space:]]{0,3}К' )
                                                             FROM '[[:digit:]]{1,5}[\,\.]{0,1}[[:digit:]]{0,5}' ), ',',
                                                 '.' ), '9999999999.9999' ) AS NUMERIC(10, 2) )
             WHEN position ( 'K' IN upper ( tfp_name ) ) > 0
               THEN cast ( to_number ( replace ( substring ( substring ( upper ( tfp_name )
                                                                         FROM
                                                                         '[[:digit:]]{1,5}[\,\.]{0,1}[[:digit:]]{0,5}[[:space:]]{0,3}K' )
                                                             FROM '[[:digit:]]{1,5}[\,\.]{0,1}[[:digit:]]{0,5}' ), ',',
                                                 '.' ), '9999999999.9999' ) AS NUMERIC(10, 2) )
             WHEN position ( 'М' IN upper ( tfp_name ) ) > 0
               THEN cast ( to_number ( replace ( substring ( substring ( upper ( tfp_name )
                                                                         FROM
                                                                         '[[:digit:]]{1,5}[\,\.]{0,1}[[:digit:]]{0,5}[[:space:]]{0,3}М' )
                                                             FROM '[[:digit:]]{1,5}[\,\.]{0,1}[[:digit:]]{0,5}' ), ',',
                                                 '.' ), '9999999999.9999' ) * 1024 AS NUMERIC(10, 2) )
             WHEN position ( 'M' IN upper ( tfp_name ) ) > 0
               THEN cast ( to_number ( replace ( substring ( substring ( upper ( tfp_name )
                                                                         FROM
                                                                         '[[:digit:]]{1,5}[\,\.]{0,1}[[:digit:]]{0,5}[[:space:]]{0,3}M' )
                                                             FROM '[[:digit:]]{1,5}[\,\.]{0,1}[[:digit:]]{0,5}' ), ',',
                                                 '.' ), '9999999999.9999' ) * 1024 AS NUMERIC(10, 2) )
             WHEN position ( 'ГБ' IN upper ( tfp_name ) ) > 0
               THEN cast ( to_number ( replace ( substring ( substring ( upper ( tfp_name )
                                                                         FROM
                                                                         '[[:digit:]]{1,5}[\,\.]{0,1}[[:digit:]]{0,5}[[:space:]]{0,3}ГБ' )
                                                             FROM '[[:digit:]]{1,5}[\,\.]{0,1}[[:digit:]]{0,5}' ), ',',
                                                 '.' ), '9999999999.9999' ) * 1024 * 1024 AS NUMERIC(10, 2) )
             WHEN cast ( substring ( upper ( tfp_name ) FROM '[[:digit:]]{1,5}' ) AS NUMERIC(10, 2) ) >= 64.0
                  AND
                  ( log ( 2.0, cast ( substring ( upper ( tfp_name ) FROM '[[:digit:]]{1,5}' ) AS NUMERIC(10, 2) ) ) -
                    ceil ( log ( 2.0, cast ( substring ( upper ( tfp_name )
                                                         FROM '[[:digit:]]{1,5}' ) AS NUMERIC(10, 2) ) ) ) ) = 0.0
               THEN cast ( substring ( upper ( tfp_name ) FROM '[[:digit:]]{1,5}' ) AS NUMERIC(10, 2) )
             WHEN upper ( tfp_name ) LIKE '%U_11111_%'
               THEN 11111 :: NUMERIC(10, 2)
             WHEN upper ( tfp_name ) LIKE '%U_1111_%'
               THEN 1111 :: NUMERIC(10, 2)
             WHEN upper ( tfp_name ) LIKE '%U_15555%'
               THEN 15555 :: NUMERIC(10, 2)
             WHEN upper ( tfp_name ) LIKE '%U_22222%'
               THEN 22222 :: NUMERIC(10, 2)
             WHEN upper ( tfp_name ) LIKE '%U_2222_%'
               THEN 2222 :: NUMERIC(10, 2)
             WHEN upper ( tfp_name ) LIKE '%U_33333%'
               THEN 33333 :: NUMERIC(10, 2)
             WHEN upper ( tfp_name ) LIKE '%U_44444%'
               THEN 44444 :: NUMERIC(10, 2)
             WHEN upper ( tfp_name ) LIKE '%U_4444_%'
               THEN 4444 :: NUMERIC(10, 2)
             WHEN upper ( tfp_name ) LIKE '%U_5555_%'
               THEN 5555 :: NUMERIC(10, 2)
             WHEN upper ( tfp_name ) LIKE '%U_6666_%'
               THEN 6666 :: NUMERIC(10, 2)
             WHEN upper ( tfp_name ) LIKE '%U_77777%'
               THEN 77777 :: NUMERIC(10, 2)
             WHEN upper ( tfp_name ) LIKE '%U_8888_%'
               THEN 8888 :: NUMERIC(10, 2)
             WHEN tfp_name LIKE '%Juniper%384%'
               THEN 384 :: NUMERIC(10, 2)
             WHEN tfp_name LIKE '%Juniper%768%'
               THEN 768 :: NUMERIC(10, 2)
             WHEN tfp_name LIKE '%Juniper%1536%'
               THEN 1536 :: NUMERIC(10, 2)
             WHEN tfp_name LIKE '%Juniper%2200%'
               THEN 2200 :: NUMERIC(10, 2)
             ELSE NULL
             END
           END           AS           speed_tp,
           tfp_name      AS           rtpl_name,
           CASE WHEN position ( 'DSL' IN upper ( tfp_name ) ) > 0
             THEN 'xDSL'
           WHEN position ( 'PON' IN upper ( tfp_name ) ) > 0
             THEN 'PON'
           WHEN position ( 'FTTX' IN upper ( tfp_name ) ) > 0
             THEN 'FTTx'
           WHEN position ( 'DOCSIS' IN upper ( tfp_name ) ) > 0
             THEN 'DOCSIS'
           WHEN position ( 'ETTH' IN upper ( tfp_name ) ) > 0
             THEN 'ETTH'
           WHEN position ( 'ETHERNET' IN upper ( tfp_name ) ) > 0
             THEN 'ETTH'
           ELSE NULL
           END           AS           tech_name,
           us_tfp_change AS           tp_start,
           row_number ( )
           OVER (
             PARTITION BY account
             ORDER BY us_tfp_change ) rn
         FROM (
                SELECT
                  abn.ab_account AS account,
                  usr_srv_atr.usa_value,
                  pln.tfp_name,
                  usr.us_tfp_change
                FROM edw_ods.t_000090_abonent abn --(ab_account - лицевой счет)
                  INNER JOIN (
                               SELECT
                                 t.us_ab_id,
                                 t.US_USER_NAME,
                                 t.US_TFP_CODE,
                                 t.us_tfp_change,
                                 row_number ( )
                                 OVER (
                                   PARTITION BY t.us_ab_id
                                   ORDER BY t.input_date DESC ) rn
                               FROM edw_ods.t_000090_ct_users t
                               WHERE t.us_close_date IS NULL
                             ) usr
                    ON usr.us_ab_id = abn.ab_id
                       AND usr.rn = 1
                  LEFT JOIN (
                              SELECT
                                t.USS_US_USER_NAME,
                                t.USS_LOGNAME,
                                row_number ( )
                                OVER (
                                  PARTITION BY USS_US_USER_NAME
                                  ORDER BY t.input_date DESC ) rn
                              FROM edw_ods.t_000090_ct_user_services t
                              WHERE t.USS_SL_TYPE = 'RADIUS'
                            ) usr_srv
                    ON usr_srv.USS_US_USER_NAME = usr.US_USER_NAME
                       AND usr_srv.rn = 1
                  LEFT JOIN edw_ods.t_000090_tb_user_serv_attrs usr_srv_atr
                    ON usr_srv_atr.USA_USS_LOGNAME = usr_srv.USS_LOGNAME
                       AND usr_srv_atr.USA_SAT_NAME = 'profile'
                  LEFT JOIN edw_ods.t_000090_tb_tariff_plans pln
                    ON usr.US_TFP_CODE = pln.TFP_CODE

                UNION

                SELECT
                  abn.ab_account AS account,
                  usr_srv_atr.usa_value,
                  pln.tfp_name,
                  usr.us_tfp_change
                FROM edw_ods.t_000091_abonent abn --(ab_account - лицевой счет)
                  INNER JOIN (
                               SELECT
                                 t.us_ab_id,
                                 t.US_USER_NAME,
                                 t.US_TFP_CODE,
                                 t.us_tfp_change,
                                 row_number ( )
                                 OVER (
                                   PARTITION BY t.us_ab_id
                                   ORDER BY t.input_date DESC ) rn
                               FROM edw_ods.t_000091_ct_users t
                               WHERE t.us_close_date IS NULL
                             ) usr
                    ON usr.us_ab_id = abn.ab_id
                       AND usr.rn = 1
                  LEFT JOIN (
                              SELECT
                                t.USS_US_USER_NAME,
                                t.USS_LOGNAME,
                                row_number ( )
                                OVER (
                                  PARTITION BY USS_US_USER_NAME
                                  ORDER BY t.input_date DESC ) rn
                              FROM edw_ods.t_000091_ct_user_services t
                              WHERE t.USS_SL_TYPE = 'RADIUS'
                            ) usr_srv
                    ON usr_srv.USS_US_USER_NAME = usr.US_USER_NAME
                       AND usr_srv.rn = 1
                  LEFT JOIN edw_ods.t_000091_tb_user_serv_attrs usr_srv_atr
                    ON usr_srv_atr.USA_USS_LOGNAME = usr_srv.USS_LOGNAME
                       AND usr_srv_atr.USA_SAT_NAME = 'profile'
                  LEFT JOIN edw_ods.t_000091_tb_tariff_plans pln
                    ON usr.US_TFP_CODE = pln.TFP_CODE

                UNION

                SELECT
                  abn.ab_account AS account,
                  usr_srv_atr.usa_value,
                  pln.tfp_name,
                  usr.us_tfp_change
                FROM edw_ods.t_000092_abonent abn --(ab_account - лицевой счет)
                  INNER JOIN (
                               SELECT
                                 t.us_ab_id,
                                 t.US_USER_NAME,
                                 t.US_TFP_CODE,
                                 t.us_tfp_change,
                                 row_number ( )
                                 OVER (
                                   PARTITION BY t.us_ab_id
                                   ORDER BY t.input_date DESC ) rn
                               FROM edw_ods.t_000092_ct_users t
                               WHERE t.us_close_date IS NULL
                             ) usr
                    ON usr.us_ab_id = abn.ab_id
                       AND usr.rn = 1
                  LEFT JOIN (
                              SELECT
                                t.USS_US_USER_NAME,
                                t.USS_LOGNAME,
                                row_number ( )
                                OVER (
                                  PARTITION BY USS_US_USER_NAME
                                  ORDER BY t.input_date DESC ) rn
                              FROM edw_ods.t_000092_ct_user_services t
                              WHERE t.USS_SL_TYPE = 'RADIUS'
                            ) usr_srv
                    ON usr_srv.USS_US_USER_NAME = usr.US_USER_NAME
                       AND usr_srv.rn = 1
                  LEFT JOIN edw_ods.t_000092_tb_user_serv_attrs usr_srv_atr
                    ON usr_srv_atr.USA_USS_LOGNAME = usr_srv.USS_LOGNAME
                       AND usr_srv_atr.USA_SAT_NAME = 'profile'
                  LEFT JOIN edw_ods.t_000092_tb_tariff_plans pln
                    ON usr.US_TFP_CODE = pln.TFP_CODE
              ) stg
       ) stg2
  WHERE stg2.rn = 1
        AND speed_tp IS NOT NULL
        and 157 = 156;
ANALYSE edw_stg_dmcm.PRE_SHPD_SIBIR_TP_1_PRT_P000157;


TRUNCATE TABLE edw_stg_dmcm.PRE_SHPD_URAL_TP_1_PRT_P000157;
INSERT INTO edw_stg_dmcm.PRE_SHPD_URAL_TP_1_PRT_P000157
(account, speed_tp, rtpl_name, tech_name, tp_start, src_id)
  SELECT
    account,
    speed_tp,
    rtpl_name,
    tech_name,
    tp_start,
    157 as src_id
  FROM (
         SELECT
           tp.account,
           CASE WHEN position ( 'K' IN tp.j_base ) > 0
             THEN substring ( tp.j_base, '[[:digit:]]*' ) :: NUMERIC(10, 2)
           WHEN position ( 'M' IN tp.j_base ) > 0
             THEN substring ( tp.j_base, '[[:digit:]]*' ) :: NUMERIC(10, 2) * 1024
           ELSE NULL
           END                  AS           speed_tp,
           tp.name_r            AS           rtpl_name,
           tp.tech              AS           tech_name,
           subs.activation_date AS           tp_start,
           row_number ( )
           OVER (
             PARTITION BY tp.account
             ORDER BY subs.activation_date ) rn
         FROM edw_ods.t_000045_V_RTK_SUBS_CURRENT_SHPD_SPEED tp
           LEFT JOIN edw_ods.t_000045_subscribers subs
             ON subs.subs_id = tp.subs_subs_id
       ) tp_speed
  WHERE tp_speed.rn = 1
        and 157 = 155;
ANALYSE edw_stg_dmcm.PRE_SHPD_URAL_TP_1_PRT_P000157;


SET optimizer = ON;
TRUNCATE TABLE edw_stg_dmcm.PRE_SHPD_TRAFFIC_MIN_DATE_STG_1_PRT_P000157;
INSERT INTO edw_stg_dmcm.PRE_SHPD_TRAFFIC_MIN_DATE_STG_1_PRT_P000157 (account_name, min_date_shpd, src_id)
   SELECT
    account_name,
    min_date_shpd,
    157 as src_id
  FROM (
         SELECT
           acc.account_name,
           bba.service_key,
           min ( bba.calendar_key ) AS min_date_shpd
         FROM edw_ads.tfct_bba_consumption bba
		 LEFT JOIN (
		  SELECT
			account_key,
			account_name,
			row_number ( )
			OVER (
			  PARTITION BY account_key
			  ORDER BY start_date DESC, end_date DESC ) AS actual_account_key
		  FROM edw_dds.dim_account
		  WHERE
			CASE WHEN 157 = 151
			  THEN src_id BETWEEN 48 AND 62
			WHEN 157 = 152
			  THEN src_id = 97
			WHEN 157 = 153
			  THEN src_id BETWEEN 1 AND 12
			WHEN 157 = 154
			  THEN src_id BETWEEN 27 AND 39
			WHEN 157 = 155
			  THEN src_id = 45
			WHEN 157 = 156
			  THEN src_id BETWEEN 80 AND 88
			WHEN 157 = 157
			  THEN src_id BETWEEN 107 AND 113
			END
		) acc
			ON bba.account_key = acc.account_key
			AND acc.actual_account_key = 1
         WHERE
			   CASE WHEN 157 = 151
				  THEN src_id BETWEEN 63 AND 77
				WHEN 157 = 152
				  THEN src_id = 97
				WHEN 157 = 153
				  THEN src_id BETWEEN 13 AND 24
				WHEN 157 = 154
				  THEN src_id = 26
				WHEN 157 = 155
				  THEN src_id = 45
				WHEN 157 = 156
				  THEN src_id BETWEEN 90 AND 92
				WHEN 157 = 157
				  THEN src_id = 114
				END

         GROUP BY acc.account_name, bba.service_key
    ) spd
    LEFT JOIN edw_dds.dim_service srv
      ON spd.service_key = srv.service_key
         AND srv.deleted_ind = 0
         AND date_trunc ( 'day', srv.exp_dttm ) = to_date ( '2999-12-31', 'yyyy-mm-dd' )
  WHERE srv.business_service_key IN (
    10202--ШПД в Интернет по проводным технологиям
    , 10201--ШПД по беспроводным технологиям+B42
    , 10200--ШПД
  );
ANALYSE edw_stg_dmcm.PRE_SHPD_TRAFFIC_MIN_DATE_STG_1_PRT_P000157;


TRUNCATE TABLE edw_stg_dmcm.PRE_SHPD_CHARGE_MIN_DATE_STG_1_PRT_P000157;
INSERT INTO edw_stg_dmcm.PRE_SHPD_CHARGE_MIN_DATE_STG_1_PRT_P000157 (account_name, min_date_shpd, src_id)
  SELECT

    CASE WHEN sa.mrf_id = 14
      THEN sa.nls
    ELSE chrg.account
    END AS account_name,
    chrg.min_date_shpd,
    157 as src_id
  FROM (
         SELECT
           account,
           min ( DATE_CHARGE ) AS min_date_shpd
         FROM edw_ods.T_000157_RPRT_CHARGES_DWH
         WHERE charge_code LIKE 'R070101%'
               OR charge_code LIKE 'R07010297%'
               OR charge_code LIKE 'R07010298%'
               OR charge_code LIKE 'R070106%'
               OR charge_code LIKE 'R070107%'
               OR charge_code IN
                  ( 'R07010201', 'R07010202', 'R07010203', 'R07010204', 'R07010205', 'R07010206', 'R07010209' )
         GROUP BY account
       ) chrg
   LEFT JOIN (
		SELECT
			mrf_id,
			nls,
			account,
			row_number ()
				OVER (
				PARTITION BY account
				ORDER BY COALESCE(date_end, to_date('2999-12-31', 'yyyy-mm-dd')) DESC, date_begin DESC ) rn
		FROM edw_ods.T_000158_EFFTP_SOUTH_NLS_ACCNT
	) sa
		ON sa.mrf_id = 14
		AND sa.account = chrg.account
		AND sa.rn = 1;
ANALYSE edw_stg_dmcm.PRE_SHPD_CHARGE_MIN_DATE_STG_1_PRT_P000157;


TRUNCATE TABLE edw_stg_dmcm.PRE_SHPD_TRAFIC_1_PRT_P000157;
INSERT INTO edw_stg_dmcm.PRE_SHPD_TRAFIC_1_PRT_P000157 (account_key, account, subs_key, year_month_key, date_snap, tr_shpd, /*tr_ota,*/ service_rtk_detail_code, src_id)
  SELECT
    NULL 					 AS account_key,
    acc.account_name         AS account,
    NULL                     AS subs_key,
    spd.year_month_key,
    spd.calendar_key :: DATE AS date_snap,
    sum (
      CASE WHEN srv.business_service_key IN
                (
                  10202--ШПД в Интернет по проводным технологиям
                  , 10201--ШПД по беспроводным технологиям+B42
                  , 10200--ШПД
                )
        THEN total_download_data_volume
      ELSE 0
      END
    )                        AS tr_shpd,
    srd.service_rtk_detail_code,
    157 as src_id
  FROM edw_ads.tfct_bba_consumption spd
    LEFT JOIN edw_dds.dim_service srv
      ON spd.service_key = srv.service_key
         AND srv.deleted_ind = 0
         AND date_trunc ( 'day', srv.exp_dttm ) = to_date ( '2999-12-31', 'yyyy-mm-dd' )
    LEFT JOIN
    (
      SELECT
        account_key,
        account_name,
        row_number ( )
        OVER (
          PARTITION BY account_key
          ORDER BY start_date DESC, end_date DESC ) AS actual_account_key
      FROM edw_dds.dim_account
      WHERE
        CASE WHEN 157 = 151
          THEN src_id BETWEEN 48 AND 62
        WHEN 157 = 152
          THEN src_id = 97
        WHEN 157 = 153
          THEN src_id BETWEEN 1 AND 12
        WHEN 157 = 154
          THEN src_id BETWEEN 27 AND 39
        WHEN 157 = 155
          THEN src_id = 45
        WHEN 157 = 156
          THEN src_id BETWEEN 80 AND 88
        WHEN 157 = 157
          THEN src_id BETWEEN 107 AND 113
        END
    ) acc
      ON spd.account_key = acc.account_key
         AND acc.actual_account_key = 1

    LEFT JOIN edw_dds.dim_service_rtk_detail srd
      ON srd.service_rtk_detail_key = spd.service_rtk_detail_key
         AND spd.calendar_key BETWEEN srd.eff_dttm AND srd.exp_dttm
         AND srd.deleted_ind = 0
  WHERE
    (date_trunc ( 'MONTH', spd.calendar_key :: DATE ) + INTERVAL '1 MONTH - 1 day' ) :: DATE >= to_date ( '20190601', 'YYYYMMDD' ) AND
    (date_trunc ( 'MONTH', spd.calendar_key :: DATE ) + INTERVAL '1 MONTH - 1 day' ) :: DATE <= to_date ( '20190630', 'YYYYMMDD' ) and
        srv.business_service_key IN (
          10202--ШПД в Интернет по проводным технологиям
          , 10201--ШПД по беспроводным технологиям+B42
          , 10200--ШПД
        )
    AND
         CASE WHEN 157 = 151
                                          THEN spd.src_id BETWEEN 63 AND 77
                                        WHEN 157 = 152
                                          THEN spd.src_id = 97
                                        WHEN 157 = 153
                                          THEN spd.src_id BETWEEN 13 AND 24
                                        WHEN 157 = 154
                                          THEN spd.src_id = 26
                                        WHEN 157 = 155
                                          THEN spd.src_id = 45
                                        WHEN 157 = 156
                                          THEN spd.src_id BETWEEN 90 AND 92
                                        WHEN 157 = 157
                                          THEN spd.src_id = 114
                                        END
  GROUP BY
    acc.account_name,
    spd.year_month_key,
    spd.calendar_key,
    srd.service_rtk_detail_code;
ANALYSE edw_stg_dmcm.PRE_SHPD_TRAFIC_1_PRT_P000157;


TRUNCATE TABLE edw_stg_dmcm.PRE_SHPD_CHARGE_STG_1_PRT_P000157;
INSERT INTO edw_stg_dmcm.PRE_SHPD_CHARGE_STG_1_PRT_P000157
(ACCOUNT_KEY,ACCOUNT_NAME,RF_ID,YEAR_MONTH_KEY,DATE_SNAP,CHARGE_SHPD,MIN_DATE_SHPD,MAX_DATE_SHPD,CHARGE_CODE, src_id)
  SELECT
 	null              AS account_key,
    coalesce ( CASE WHEN sa.mrf_id = 14
      THEN sa.nls
               ELSE chrg.account END, '' )   AS account_name,
    coalesce ( chrg.rf_id, 0 )               AS rf_id,
    to_char ( period :: DATE, 'YYYYMM' )     AS year_month_key,
    ( date_trunc ( 'MONTH', period :: DATE )
      + INTERVAL '1 MONTH - 1 day' ) :: DATE AS date_snap,
    sum (
      CASE
      WHEN chrg.CHARGE_CODE LIKE 'R070101%'
           OR chrg.CHARGE_CODE LIKE 'R07010297%'
           OR chrg.CHARGE_CODE LIKE 'R07010298%'
           OR chrg.CHARGE_CODE LIKE 'R070106%'
           OR chrg.CHARGE_CODE LIKE 'R070107%'
           OR chrg.CHARGE_CODE IN
              ( 'R07010201', 'R07010202', 'R07010203', 'R07010204', 'R07010205', 'R07010206', 'R07010209' )
        THEN charge - chrg.vat_amount
      ELSE 0
      END
    )                                        AS charge_shpd,
    coalesce ( min (
                 CASE WHEN
                   chrg.CHARGE_CODE LIKE 'R070101%'
                   OR chrg.CHARGE_CODE LIKE 'R07010297%'
                   OR chrg.CHARGE_CODE LIKE 'R07010298%'
                   OR chrg.CHARGE_CODE LIKE 'R070106%'
                   OR chrg.CHARGE_CODE LIKE 'R070107%'
                   OR
                   chrg.CHARGE_CODE IN
                   ( 'R07010201', 'R07010202', 'R07010203', 'R07010204', 'R07010205', 'R07010206', 'R07010209' )
                   THEN DATE_CHARGE
                 ELSE '1000-01-01 01:00:00'
                 END
               ), '1000-01-01 01:00:00' )    AS min_date_shpd,
    coalesce ( max (
                 CASE WHEN
                   chrg.CHARGE_CODE LIKE 'R070101%'
                   OR chrg.CHARGE_CODE LIKE 'R07010297%'
                   OR chrg.CHARGE_CODE LIKE 'R07010298%'
                   OR chrg.CHARGE_CODE LIKE 'R070106%'
                   OR chrg.CHARGE_CODE LIKE 'R070107%'
                   OR
                   chrg.CHARGE_CODE IN
                   ( 'R07010201', 'R07010202', 'R07010203', 'R07010204', 'R07010205', 'R07010206', 'R07010209' )
                   THEN DATE_CHARGE
                 ELSE '1000-01-01 01:00:00'
                 END
               ), '1000-01-01 01:00:00' )    AS max_date_shpd,
     coalesce ( charge_code, '' )             AS charge_code,
    157 as src_id
  FROM edw_ods.T_000157_RPRT_CHARGES_DWH  chrg

   LEFT JOIN (
		SELECT
			mrf_id,
			nls,
			account,
			row_number ()
				OVER (
				PARTITION BY account
				ORDER BY COALESCE(date_end, to_date('2999-12-31', 'yyyy-mm-dd')) DESC, date_begin DESC ) rn
		FROM edw_ods.T_000158_EFFTP_SOUTH_NLS_ACCNT
	) sa
		ON sa.mrf_id = 14
		AND sa.account = chrg.account
		AND sa.rn = 1

  WHERE ( date_trunc ( 'MONTH', period :: DATE )
          + INTERVAL '1 MONTH - 1 day' ) :: DATE >= to_date ( '20190601', 'YYYYMMDD' ) AND
        ( date_trunc ( 'MONTH', period :: DATE )
          + INTERVAL '1 MONTH - 1 day' ) :: DATE <= to_date ( '20190630', 'YYYYMMDD' )
        AND chrg.coef_r12 = 1

  GROUP BY
    COALESCE ( CASE WHEN sa.mrf_id = 14
      THEN sa.nls
               ELSE chrg.account END, '' ),
    chrg.rf_id,
    chrg.abn_id,
    to_char ( period :: DATE, 'YYYYMM' ),
    ( date_trunc ( 'MONTH', period :: DATE )
      + INTERVAL '1 MONTH - 1 day' ) :: DATE,
    chrg.charge_code,
    chrg.period;

ANALYSE edw_stg_dmcm.PRE_SHPD_CHARGE_STG_1_PRT_P000157;



TRUNCATE TABLE edw_stg_dmcm.PRE_SHPD_CHARGE_TRAFIC_STG_1_PRT_P000157;
INSERT INTO edw_stg_dmcm.PRE_SHPD_CHARGE_TRAFIC_STG_1_PRT_P000157 (account_key, account, date_snap, charge_code, min_date_shpd, max_date_shpd, trafic, charge, period, rf_id, src_id)
  SELECT
    null										             AS account_key,
    coalesce ( chg.account_name, tr.account )                AS account,
    coalesce ( chg.date_snap, tr.date_snap )                 AS date_snap,
    coalesce ( chg.charge_code, tr.service_rtk_detail_code ) AS charge_code,
    CASE WHEN chg.min_date_shpd IS NOT NULL
      THEN
        CASE WHEN tr.min_date_shpd IS NOT NULL
          THEN
            CASE WHEN chg.min_date_shpd < tr.min_date_shpd
              THEN chg.min_date_shpd
            ELSE tr.min_date_shpd
            END
        ELSE chg.min_date_shpd
        END
    ELSE
      CASE WHEN tr.min_date_shpd IS NOT NULL
        THEN tr.min_date_shpd
      ELSE '2017-01-01 01:00:00' :: TIMESTAMP
      END
    END                                                      AS min_date_shpd,
    null as max_date_shpd,
    coalesce ( tr.tr_shpd, 0 )                               AS TRAFIC,
    coalesce ( charge_shpd, 0 )                              AS CHARGE,
    coalesce ( chg.year_month_key, tr.year_month_key )       AS PERIOD,
    chg.rf_id                                                AS rf_id,
    157 as src_id
  FROM (
         SELECT
           chg_stg.account_name,
           chg_stg.date_snap,
           chg_stg.charge_code,
           chg_min.min_date_shpd,
           chg_stg.year_month_key,
           chg_stg.charge_shpd,
           chg_stg.rf_id
         FROM (
                SELECT
                  account_name,
                  date_snap,
                  charge_code,
                  year_month_key,
                  sum ( charge_shpd ) AS charge_shpd,
                  rf_id
                FROM
                  edw_stg_dmcm.PRE_SHPD_CHARGE_STG_1_PRT_P000157
                WHERE
                  date_snap >= to_date ( '20190601', 'YYYYMMDD' ) AND
                  date_snap <= to_date ( '20190630', 'YYYYMMDD' )
                GROUP BY
                  account_name,
                  date_snap,
                  charge_code,
                  year_month_key,
                  rf_id
              ) chg_stg
           LEFT JOIN edw_stg_dmcm.PRE_SHPD_CHARGE_MIN_DATE_STG_1_PRT_P000157 chg_min
             ON chg_min.account_name = chg_stg.account_name
       ) chg
    FULL JOIN (
                SELECT
                  tr_stg.*,
                  tr_min.min_date_shpd
                FROM (
                       SELECT *
                       FROM edw_stg_dmcm.PRE_SHPD_TRAFIC_1_PRT_P000157
                       WHERE tr_shpd > 0
                     ) tr_stg
                  LEFT JOIN edw_stg_dmcm.PRE_SHPD_TRAFFIC_MIN_DATE_STG_1_PRT_P000157 tr_min
                    ON tr_min.account_name = tr_stg.account
              ) tr
      ON chg.account_name = tr.account
         AND chg.charge_code = tr.service_rtk_detail_code
         AND chg.date_snap = tr.date_snap;
ANALYSE edw_stg_dmcm.PRE_SHPD_CHARGE_TRAFIC_STG_1_PRT_P000157;


SET optimizer = ON;
TRUNCATE TABLE edw_stg_dmcm.tfct_shpd_1_PRT_P000157;
INSERT INTO edw_stg_dmcm.tfct_shpd_1_PRT_P000157 (inn, account_key, period, date_snap, account, client_name, rtpl_name, tp_start, trafic, charge, id_macro_segment,
                                    addr_city, charge_code, rf, mrf, speed_tp, tech_name, serv_status, name_microsegment, k_code, id_rf, date_start, src_id)
  select inn,
  max(account_key),
  period,
  date_snap,
  account,
  max(client_name),
  rtpl_name,
  max(tp_start),
  max(trafic),
  max(charge),
  max(id_macro_segment),
  max(addr_city),
  charge_code,
  max(rf),
  max(mrf),
  max(speed_tp),
  max(tech_name),
  max(serv_status),
  max(name_microsegment),
  max(k_code),
  id_rf,
  max(date_start),
  src_id from (
  SELECT
    stg.inn,
    stg.account_key,
    stg.period,
    stg.date_snap,
    stg.account,
    stg.client_name,
    CASE WHEN stg.mrf = 'Группирующий узел Юг'
      THEN coalesce ( south_tp.rtpl_name, stg.rtpl_name, '' )
    WHEN stg.mrf = 'Группирующий узел Сибирь'
      THEN coalesce ( sibir_tp.rtpl_name, stg.rtpl_name, '' )
    WHEN stg.mrf = 'Группирующий узел Центр'
      THEN coalesce ( centr_tp.rtpl_name, stg.rtpl_name, '' )
    WHEN stg.mrf = 'Группирующий узел Волга'
      THEN coalesce ( volga_tp.rtpl_name, stg.rtpl_name, '' )
    WHEN stg.mrf = 'Группирующий узел Дальный Восток'
      THEN coalesce ( dv_tp.rtpl_name, stg.rtpl_name, '' )
    WHEN stg.mrf = 'Группирующий узел Урал'
      THEN coalesce ( ural_tp.rtpl_name, stg.rtpl_name, '' )
    ELSE coalesce ( stg.rtpl_name, '' ) END                     rtpl_name,

    CASE WHEN stg.mrf = 'Группирующий узел Юг'
      THEN coalesce ( south_tp.tp_start, stg.date_start, '2017-01-01 00:00:00' )
    WHEN stg.mrf = 'Группирующий узел Сибирь'
      THEN coalesce ( sibir_tp.tp_start, stg.date_start, '2017-01-01 00:00:00' )
    WHEN stg.mrf = 'Группирующий узел Центр'
      THEN coalesce ( centr_tp.tp_start, stg.date_start, '2017-01-01 00:00:00' )
    WHEN stg.mrf = 'Группирующий узел Волга'
      THEN coalesce ( volga_tp.tp_start, stg.date_start, '2017-01-01 00:00:00' )
    WHEN stg.mrf = 'Группирующий узел Дальный Восток'
      THEN coalesce ( dv_tp.tp_start, stg.date_start, '2017-01-01 00:00:00' )
    WHEN stg.mrf = 'Группирующий узел Урал'
      THEN coalesce ( ural_tp.tp_start, stg.date_start, '2017-01-01 00:00:00' )
    ELSE coalesce ( stg.date_start, '2017-01-01 00:00:00' ) END tp_start,
    stg.trafic,
    stg.charge,
    stg.id_macro_segment,
    stg.addr_city,
    stg.charge_code,
    stg.rf,
    stg.mrf,
    CASE WHEN stg.mrf = 'Группирующий узел Юг'
      THEN coalesce ( south_tp.speed_tp, stg.speed_tp, 0 )
    WHEN stg.mrf = 'Группирующий узел Сибирь'
      THEN coalesce ( sibir_tp.speed_tp, stg.speed_tp, 0 )
    WHEN stg.mrf = 'Группирующий узел Центр'
      THEN coalesce ( centr_tp.speed_tp, stg.speed_tp, 0 )
    WHEN stg.mrf = 'Группирующий узел Волга'
      THEN coalesce ( volga_tp.speed_tp, stg.speed_tp, 0 )
    WHEN stg.mrf = 'Группирующий узел Дальный Восток'
      THEN coalesce ( dv_tp.speed_tp, stg.speed_tp, 0 )
    WHEN stg.mrf = 'Группирующий узел Урал'
      THEN coalesce ( ural_tp.speed_tp, stg.speed_tp, 0 )
    ELSE coalesce ( stg.speed_tp, 0 ) END                       speed_tp,
    CASE WHEN stg.mrf = 'Группирующий узел Юг'
      THEN coalesce ( south_tp.tech_name, stg.tech_name, '' )
    WHEN stg.mrf = 'Группирующий узел Сибирь'
      THEN coalesce ( sibir_tp.tech_name, stg.tech_name, '' )
    WHEN stg.mrf = 'Группирующий узел Центр'
      THEN coalesce ( centr_tp.tech_name, stg.tech_name, '' )
    WHEN stg.mrf = 'Группирующий узел Волга'
      THEN coalesce ( volga_tp.tech_name, stg.tech_name, '' )
    WHEN stg.mrf = 'Группирующий узел Дальный Восток'
      THEN coalesce ( dv_tp.tech_name, stg.tech_name, '' )
    WHEN stg.mrf = 'Группирующий узел Урал'
      THEN coalesce ( ural_tp.tech_name, stg.tech_name, '' )
    ELSE coalesce ( stg.tech_name, '' ) END                     tech_name,
    stg.serv_status,
    stg.name_microsegment,
    stg.k_code,
    stg.id_rf,
    stg.date_start,
    157 AS                                                      src_id
  FROM (
         SELECT
           coalesce (
             CASE WHEN cl.inn IN
                       ( '-', '0', '00', '000', '0000', '-000', '-0000', '00000', '-00000', '000000', '0000000', '000000000', '0000000000' )
               THEN NULL
             ELSE cl.inn END, '' )                            AS inn,
           coalesce ( src.account_key, 0 )                    AS account_key,
           src.period                                         AS period,
           src.date_snap,
           coalesce ( src.account, '0' )                      AS account,
           cl.contr_name                                      AS client_name,
           coalesce ( vpd.rtpl_name, '' )                     AS rtpl_name,
           coalesce ( vpd.date_start, '2017-01-01 00:00:00' ) AS tp_start,
           src.trafic,
           charge,
           coalesce ( cl.id_macro_segment_ud, 0 )             AS id_macro_segment,
           adr.city                                           AS addr_city,
           charge_code,
           coalesce ( br2.branch_name, br.branch_name, '' )   AS rf,
           coalesce (
			        CASE WHEN br2.parent_branch_key = -1
				            THEN br2.branch_name
                ELSE br_par2.branch_name
              END,
            CASE WHEN br.parent_branch_key = -1
                THEN br.branch_name
                ELSE br_par.branch_name
            END, '' )                               AS mrf,
           coalesce (
             CASE WHEN ( vpd.speed = 0 OR vpd.speed IS NULL )
               THEN
                 CASE WHEN position ( 'КБ' IN upper ( vpd.rtpl_name ) ) > 0
                   THEN cast ( to_number ( replace ( substring ( substring ( upper ( vpd.rtpl_name ) FROM
                                                                             '[[:digit:]]{1,5}[\,\.]{0,1}[[:digit:]]{0,5}[[:space:]]{0,3}КБ' )
                                                                 FROM '[[:digit:]]{1,5}[\,\.]{0,1}[[:digit:]]{0,5}' ),
                                                     ',',
                                                     '.' ), '9999999999.9999' ) AS NUMERIC(10, 2) )
                 WHEN position ( '2048К' IN upper ( vpd.rtpl_name ) ) > 0
                   THEN cast ( substring ( upper ( vpd.rtpl_name ) FROM '2048' ) AS NUMERIC(10, 2) )
                 WHEN position ( 'МБ' IN upper ( vpd.rtpl_name ) ) > 0
                   THEN cast ( to_number ( replace ( substring ( substring ( upper ( vpd.rtpl_name ) FROM
                                                                             '[[:digit:]]{1,5}[\,\.]{0,1}[[:digit:]]{0,5}[[:space:]]{0,3}МБ' )
                                                                 FROM '[[:digit:]]{1,5}[\,\.]{0,1}[[:digit:]]{0,5}' ),
                                                     ',',
                                                     '.' ), '9999999999.9999' ) * 1024 AS NUMERIC(10, 2) )
                 WHEN position ( 'MБ' IN upper ( vpd.rtpl_name ) ) > 0
                   THEN cast ( to_number ( replace ( substring ( substring ( upper ( vpd.rtpl_name ) FROM
                                                                             '[[:digit:]]{1,5}[\,\.]{0,1}[[:digit:]]{0,5}[[:space:]]{0,3}MБ' )
                                                                 FROM '[[:digit:]]{1,5}[\,\.]{0,1}[[:digit:]]{0,5}' ),
                                                     ',',
                                                     '.' ), '9999999999.9999' ) * 1024 AS NUMERIC(10, 2) )
                 WHEN position ( 'ГБ' IN upper ( vpd.rtpl_name ) ) > 0
                   THEN cast ( to_number ( replace ( substring ( substring ( upper ( vpd.rtpl_name ) FROM
                                                                             '[[:digit:]]{1,5}[\,\.]{0,1}[[:digit:]]{0,5}[[:space:]]{0,3}ГБ' )
                                                                 FROM '[[:digit:]]{1,5}[\,\.]{0,1}[[:digit:]]{0,5}' ),
                                                     ',',
                                                     '.' ), '9999999999.9999' ) * 1024 * 1024 AS NUMERIC(10, 2) )
                 WHEN cast ( substring ( upper ( vpd.rtpl_name ) FROM '[[:digit:]]{1,5}' ) AS NUMERIC(10, 2) ) >= 64.0
                      AND
                      ( log ( 2.0,
                              cast ( substring ( upper ( vpd.rtpl_name ) FROM '[[:digit:]]{1,5}' ) AS NUMERIC(10, 2) ) )
                        -
                        ceil ( log ( 2.0, cast ( substring ( upper ( vpd.rtpl_name ) FROM '[[:digit:]]{1,5}' ) AS
                                                 NUMERIC(10, 2) ) ) ) ) = 0.0
                   THEN cast ( substring ( upper ( vpd.rtpl_name ) FROM '[[:digit:]]{1,5}' ) AS NUMERIC(10, 2) )
                 ELSE 0
                 END
             ELSE
               CASE WHEN vpd.speed IN ( 1, 2, 3 )
                 THEN vpd.speed * 1024.0
               ELSE vpd.speed
               END
             END, 0
           )                                                  AS speed_tp,
           CASE WHEN ( dir_tech.def IS NULL OR dir_tech.def = '' )
             THEN
               CASE WHEN charge_code IN ( 'R07010101', 'R07010102', 'R07010103', 'R07010197', 'R0701019701',
                 'R0701019702', 'R07010198', 'R0701019801', 'R0701019802', 'R0701019803', 'R0701019804' )
                 THEN 'xDSL'
               WHEN charge_code IN ( 'R0701069701', 'R0701069702', 'R0701069801', 'R0701069802',
                                     'R0701069803', 'R0701069804' )
                 THEN 'PON'
               ELSE
                 CASE WHEN position ( 'DSL' IN upper ( vpd.rtpl_name ) ) > 0
                   THEN 'xDSL'
                 WHEN position ( 'PON' IN upper ( vpd.rtpl_name ) ) > 0
                   THEN 'PON'
                 WHEN position ( 'FTTX' IN upper ( vpd.rtpl_name ) ) > 0
                   THEN 'FTTx'
                 WHEN position ( 'DOCSIS' IN upper ( vpd.rtpl_name ) ) > 0
                   THEN 'DOCSIS'
                 WHEN position ( 'ETTH' IN upper ( vpd.rtpl_name ) ) > 0
                   THEN 'ETTH'
                 WHEN position ( 'ETHERNET' IN upper ( vpd.rtpl_name ) ) > 0
                   THEN 'ETTH'
                 ELSE ''
                 END
               END
           ELSE dir_tech.def
           END
                                                              AS tech_name,
           NULL                                               AS serv_status,
           nm.name_microsegment,
           nm.macro_segment                                   AS k_code,
           coalesce ( br2.branch_key, br.branch_key )         AS id_rf,
           src.min_date_shpd                                  AS date_start
         FROM
           edw_stg_dmcm.pre_shpd_charge_trafic_stg_1_PRT_P000157 src

            LEFT JOIN (
                SELECT
                  account_                                                       AS account,
                  coalesce ( sss.rf_id, sss.rf_id_ )                             AS rf_id,
                  coalesce ( sss.id_macro_segment_ud, sss.id_macro_segment_ud_ ) AS id_macro_segment_ud,
                  coalesce ( sss.inn, sss.inn_ )                                 AS inn,
                  coalesce ( sss.contr_name, sss.contr_name_ )                   AS contr_name

                FROM (
                       SELECT
                         c.rf_id,
                         c.id_macro_segment_ud,
                         c.inn,
                         c.contr_name,
                         CASE WHEN sa.mrf_id = 14
                           THEN sa.nls
                         ELSE c.account END                        AS account_,
                         min ( c.rf_id )
                         OVER (
                           PARTITION BY CASE WHEN sa.mrf_id = 14
                             THEN sa.nls
                                        ELSE c.account END )       AS rf_id_,
                         min ( id_macro_segment_ud )
                         OVER (
                           PARTITION BY CASE WHEN sa.mrf_id = 14
                             THEN sa.nls
                                        ELSE c.account END )       AS id_macro_segment_ud_,
                         min ( inn )
                         OVER (
                           PARTITION BY CASE WHEN sa.mrf_id = 14
                             THEN sa.nls
                                        ELSE c.account END )       AS inn_,
                         min ( contr_name )
                         OVER (
                           PARTITION BY CASE WHEN sa.mrf_id = 14
                             THEN sa.nls
                                        ELSE c.account END )       AS contr_name_,
                         row_number ( )
                         OVER (
                           PARTITION BY CASE WHEN sa.mrf_id = 14
                             THEN sa.nls
                                        ELSE c.account END
                           ORDER BY CASE WHEN C.date_snap <= to_date ( '20190630', 'YYYYMMDD' )
                             THEN 0
                                    ELSE 1 END, C.date_snap DESC ) AS rn
                       FROM edw_ods.T_000157_RPRT_CLIENT_DWH C
                       LEFT JOIN (
                       SELECT
                       mrf_id,
                       nls,
                       account,
                       row_number ( )
                       OVER (
                       PARTITION BY account
                       ORDER BY COALESCE(date_end, to_date('2999-12-31', 'yyyy-mm-dd')) DESC, date_begin DESC ) rn
                                                  FROM edw_ods.T_000158_EFFTP_SOUTH_NLS_ACCNT
                                 ) sa
                                   ON sa.mrf_id = 14
                                   AND sa.account = c.account
                                          AND sa.rn = 1
                     ) sss
                WHERE sss.rn = 1 ) cl

      ON src.account = cl.account

           LEFT JOIN (
                       SELECT
                         account_                                     AS ACCOUNT,
                         COALESCE ( tbl.SPEED, tbl.SPEED_ )           AS SPEED,
                         COALESCE ( tbl.tech_id, tbl.tech_id_ )       AS TECH_ID,
                         COALESCE ( tbl.START_RTPL, tbl.START_RTPL_ ) AS tp_start,
                         COALESCE ( tbl.rtpl_name, tbl.rtpl_name_ )   AS rtpl_name,
                         COALESCE ( BASE_SRC_ID, 0 )                  AS base_src_id,
                         COALESCE ( LOG_ID, 0 )                       AS log_id,
                         date_start
                       FROM
                         (
                           SELECT
                             v.START_RTPL,
                             v.tech_id,
                             v.SPEED,
                             v.rtpl_name,
                             v.BASE_SRC_ID,
                             v.LOG_ID,
                             v.date_start,
                             CASE WHEN sa.mrf_id = 14
                               THEN sa.nls
                             ELSE v.account END         AS account_,
                             MIN ( START_RTPL )
                             OVER (
                               PARTITION BY v.account ) AS START_RTPL_,
                             MIN ( tech_id )
                             OVER (
                               PARTITION BY v.account ) AS tech_id_,
                             MIN ( SPEED )
                             OVER (
                               PARTITION BY v.account ) AS SPEED_,
                             	MIN ( rtpl_name )
                        OVER (
                          PARTITION BY v.account ) AS rtpl_name_,
                             row_number ( )
                             OVER (
                               PARTITION BY CASE WHEN sa.mrf_id = 14
                                 THEN sa.nls
                                            ELSE v.account END
                               ORDER BY CASE WHEN v.date_start <= to_date ( '20190630', 'YYYYMMDD' )
                           THEN 0
                           ELSE 1 END, v.date_start DESC ) AS rn
                       FROM edw_ods.T_000157_RPRT_VRATE_PLANS_DWH v
                           LEFT JOIN (
								SELECT
									mrf_id,
									nls,
									account,
									row_number ()
										OVER (
										PARTITION BY account
										ORDER BY COALESCE(date_end, to_date('2999-12-31', 'yyyy-mm-dd')) DESC, date_begin DESC ) rn
								FROM edw_ods.T_000158_EFFTP_SOUTH_NLS_ACCNT
							) sa
								ON sa.mrf_id = 14
								AND sa.account = v.account
								AND sa.rn = 1
                                                           WHERE v.serv_id IN (-1, 2, 22)
                     ) tbl

         WHERE tbl.rn = 1 ) vpd
            ON src.account = vpd.account

           LEFT JOIN edw_dds.hub_dim_branch b ON b.src_id = 158
                                                 AND cl.rf_id :: text = b.source_key
                                                 AND date_trunc('day',b.exp_dttm) = to_date('2999-12-31','yyyy-mm-dd')

           LEFT JOIN edw_dds.dim_branch br ON b.branch_key = br.branch_key
                                              AND br.deleted_ind = 0
                                              AND date_trunc('day',br.exp_dttm) = to_date('2999-12-31','yyyy-mm-dd')


           LEFT JOIN edw_dds.dim_branch br_par ON br.parent_branch_key = br_par.branch_key
                                                  AND br_par.deleted_ind = 0
                                                  AND date_trunc('day',br_par.exp_dttm) = to_date('2999-12-31','yyyy-mm-dd')

           /* попытка посадить бранчи на rf_id из чарджа, а не клиента*/
           LEFT JOIN edw_dds.hub_dim_branch b2 ON b2.src_id = 158
                                                  AND src.rf_id :: text = b2.source_key
                                                  AND date_trunc('day',b2.exp_dttm) = to_date('2999-12-31','yyyy-mm-dd')

           LEFT JOIN edw_dds.dim_branch br2 ON b2.branch_key = br2.branch_key
                                               AND br2.deleted_ind = 0
                                               AND date_trunc('day',br2.exp_dttm) = to_date('2999-12-31','yyyy-mm-dd')


           LEFT JOIN edw_dds.dim_branch br_par2 ON br2.parent_branch_key = br_par2.branch_key
                                                   AND br_par2.deleted_ind = 0
                                                   AND date_trunc('day',br_par2.exp_dttm) = to_date('2999-12-31','yyyy-mm-dd')

           LEFT JOIN edw_ods.T_000158_RPRT_DIR_TECH dir_tech ON vpd.tech_id = dir_tech.tech_id

           LEFT JOIN edw_ods.T_000158_RPRT_DIRD_MACRO_SGMNT nm
             ON nm.id_macro_segment =
                cl.id_macro_segment_ud
           LEFT JOIN edw_stg_dmcm.PRE_SHPD_DIM_ADDRESS_STG_1_PRT_P000157 adr
             ON adr.account = src.account
         WHERE substring ( src.CHARGE_CODE, 1, 5 ) = 'R0701' ) stg
    LEFT JOIN edw_stg_dmcm.pre_shpd_south_tp_1_PRT_P000157 south_tp
      ON south_tp.account = stg.account
    LEFT JOIN edw_stg_dmcm.pre_shpd_sibir_tp_1_PRT_P000157 sibir_tp
      ON sibir_tp.account = stg.account
    LEFT JOIN edw_stg_dmcm.pre_shpd_centr_tp_1_PRT_P000157 centr_tp
      ON centr_tp.account = stg.account
    LEFT JOIN edw_stg_dmcm.pre_shpd_volga_tp_1_PRT_P000157 volga_tp
      ON volga_tp.account = stg.account
    LEFT JOIN edw_stg_dmcm.pre_shpd_dv_tp_1_PRT_P000157 dv_tp
      ON dv_tp.account = stg.account
    LEFT JOIN edw_stg_dmcm.PRE_SHPD_URAL_TP_1_PRT_P000157 ural_tp
      ON ural_tp.account = stg.account) q
group by INN, id_rf, account, period, charge_code, tp_start, rtpl_name, date_snap, src_id;
ANALYSE edw_stg_dmcm.tfct_shpd_1_PRT_P000157;


/*
select period, src_id, count(1) from edw_stg_dmcm.tfct_shpd group by period, src_id
order by period, src_id
*/




