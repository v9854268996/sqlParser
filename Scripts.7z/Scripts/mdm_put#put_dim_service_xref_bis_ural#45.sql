/*rev.27443 16.04.2019*//* Шаг 1 */truncate table edw_stg_mdm.put_dim_service_xref_bis_ural_stg_1;
/*
1.1 Абонент:
Запуск скрипта после загрузки t_000045_dim_subs_t_stg_18 После  обновления xrefa сборка Абонента стартует с этого шага.
*/
--delete from edw_stg_mdm.put_dim_service_xref_bis_ural_stg_1 where entity = 'dim_subs';
set optimizer = on;
insert into edw_stg_mdm.put_dim_service_xref_bis_ural_stg_1
(
    service_key,
	r_code,
	srls_id,
	prcl_id,
	lcal_id,
	rtpl_id,
	pack_id,
	detg_id,
	entity,
	load_dttm
)
WITH
  accc_detg_rtpl AS
  (
    SELECT
        pack_pack_id,
        detg_detg_id,
        rtpl_rtpl_id,
        ACCC_ACCC_ID,
        period_start,
        period_end
      FROM edw_ods.t_000045_accc_detg_rtpl t
	  WHERE period_start <=to_date ('20190630', 'YYYYMMDD') + interval '1 day -  1 second'
		and period_end >= to_date ('20190630', 'YYYYMMDD') + interval '1 day -  1 second'
  )

 ,subs AS
  (
    select distinct t1.service_key
	     , subs_id
         , substring(t1.service_key, strpos(t1.service_key,'DT')+2,length(t1.service_key)) as detg_id
         , substring(t1.service_key, strpos(t1.service_key,'RP')+2,strpos(t1.service_key,'PK')-strpos(t1.service_key,'RP')-3) as rtpl_id
         , substring(t1.service_key, strpos(t1.service_key,'PK')+2,strpos(t1.service_key,'DT')-strpos(t1.service_key,'PK')-3) as pack_id2
         --t1.subs_id, t2.pkey_src_object, start_date, end_date   , business_service_name
         , start_date
         , end_date
       from edw_stg_dds.t_000045_dim_subs_stg_18 t1
         left join edw_stg_dds.t_dim_service_xref_bis_ural xr
		   on xr.service_key = t1.service_key
		   --and xr.exp_dttm ='2999-12-31 00:00:00'
		   and t1.start_date <=  xr.exp_dttm
		   and t1.end_date   >=  xr.eff_dttm
         left join edw_stg_dds.v_dim_service et
		   on et.service_key = xr.pkey_src_object
		   --and et.exp_dttm ='2999-12-31 00:00:00'
		   and t1.start_date <=  et.exp_dttm
		   and t1.end_date   >=  et.eff_dttm
      where to_date ('20190630', 'YYYYMMDD') + interval '1 day -  1 second' between start_date and end_date
        and (xr.service_key is null or pkey_src_object = -1 )
  )

 ,SERV AS
  (
    SELECT
        sk.RTPL_ID,
        sk.DETG_ID,
        sk.subs_id,
        sk.pack_id2,
        CASE
          WHEN ADR1.ACCC_ACCC_ID IS NOT NULL THEN ADR1.PACK_PACK_ID
          WHEN ADR3.ACCC_ACCC_ID IS NOT NULL THEN ADR3.PACK_PACK_ID
          ELSE NULL
        END as PACK_ID,
        -- переопределение пакета!!!
        AA.ACC_NUM as R_CODE,
        AA.ACCC_ID as ACCC_ID,
        CASE
          WHEN ADR1.ACCC_ACCC_ID IS NOT NULL THEN 1
          WHEN ADR2.ACCC_ACCC_ID IS NOT NULL THEN 2
          WHEN ADR3.ACCC_ACCC_ID IS NOT NULL THEN 3
          WHEN ADR4.ACCC_ACCC_ID IS NOT NULL THEN 4
        END as PR,
        service_key
      FROM subs sk
        -- полное совпадение
        LEFT JOIN accc_detg_rtpl ADR1
          ON ADR1.PACK_PACK_ID::text = Sk.PACK_ID2
          AND ADR1.DETG_DETG_ID::text = sk.detg_id
          AND ADR1.RTPL_RTPL_ID::text = sk.RTPL_ID
        -- нет пакета
        LEFT JOIN accc_detg_rtpl ADR2
          ON sk.detg_id = ADR2.DETG_DETG_ID::text
          AND sk.RTPL_ID = ADR2.RTPL_RTPL_ID::text
          AND ADR2.PACK_PACK_ID IS NULL
        -- нет тарифного плана
        LEFT JOIN accc_detg_rtpl ADR3
          ON ADR3.DETG_DETG_ID::text =  sk.detg_id
          AND ADR3.RTPL_RTPL_ID IS NULL
          AND ADR3.PACK_PACK_ID::text = Sk.PACK_ID2
        -- нет пакета и тарифного плана
        LEFT JOIN accc_detg_rtpl ADR4
          ON   sk.detg_id = ADR4.DETG_DETG_ID::text
          AND ADR4.RTPL_RTPL_ID IS NULL
          AND ADR4.PACK_PACK_ID IS NULL

        LEFT JOIN edw_ods.t_000045_acc_accounts AA
          ON COALESCE(ADR1.ACCC_ACCC_ID,
                      ADR2.ACCC_ACCC_ID,
                      ADR3.ACCC_ACCC_ID,
                      ADR4.ACCC_ACCC_ID) = AA.ACCC_ID
  )

 ,SERV2 AS
  (
    SELECT
        service_key ,
	    substring(t.service_key, strpos(t.service_key,'SL')+2,strpos(t.service_key,'PL')-strpos(t.service_key,'SL')-3) as srls_id,
        substring(t.service_key, strpos(t.service_key,'PL')+2,strpos(t.service_key,'LC')-strpos(t.service_key,'PL')-3) as prcl_id,
	    substring(t.service_key, strpos(t.service_key,'LC')+2,strpos(t.service_key,'RP')-strpos(t.service_key,'LC')-3) as lcal_id,
	    rtpl_id,
	    substring(t.service_key, strpos(t.service_key,'PK')+2,strpos(t.service_key,'DT')-strpos(t.service_key,'PK')-3) as pack_id,
	    R_CODE,
        detg_id,
        subs_id,
        ROW_NUMBER() OVER (PARTITION BY service_key ORDER BY t.PR, ACCC_ID)  RN
      FROM SERV t
  )

SELECT
     service_key,
     R_CODE,
     case when srls_id = '' then null else srls_id::numeric end   as srls_id,
     case when prcl_id = '' then null else prcl_id::numeric end  as prcl_id,
     case when lcal_id = '' then null else lcal_id::numeric end  as lcal_id,
     case when rtpl_id = '' then null else rtpl_id::numeric end  as rtpl_id,
     case when pack_id = '' then null else pack_id::numeric end  as pack_id,
     case when detg_id = '' then null else detg_id::numeric end  as detg_id,
     'dim_subs' as entity,
     now() as load_dttm
  FROM SERV2
 WHERE RN = 1;
commit;

/*
1.2 Потребление Телефонии.
Запуск скрипта после загрузки edw_stg_dds.t_000045_tfct_telephony_consumption_serv2
После обновления xrefa сборка Потребления Телефонии стартует с этого шага.
*/

--delete from edw_stg_mdm.put_dim_service_xref_bis_ural_stg_1 where entity = 'tfct_telephony_consumption';
set optimizer = on;
insert into edw_stg_mdm.put_dim_service_xref_bis_ural_stg_1
(
    service_key,
	r_code,
	srls_id,
	prcl_id,
	lcal_id,
	rtpl_id,
	pack_id,
	detg_id,
	entity,
	load_dttm
)

select
    a.service_key,
	R_CODE,
    case when srls_id = '' then null else srls_id::numeric end   as srls_id,
    case when prcl_id = '' then null else prcl_id::numeric end  as prcl_id,
    case when lcal_id = '' then null else lcal_id::numeric end  as lcal_id,
    case when rtpl_id = '' then null else rtpl_id::numeric end  as rtpl_id,
    case when pack_id = '' then null else pack_id::numeric end  as pack_id,
    case when detg_id = '' then null else detg_id::numeric end  as detg_id,
    'tfct_telephony_consumption'::text as entity,
	now() as load_dttm
from
(
select t.service_key,
	substring(t.service_key, strpos(t.service_key,'SL')+2,strpos(t.service_key,'PL')-strpos(t.service_key,'SL')-3) as srls_id,
	substring(t.service_key, strpos(t.service_key,'PL')+2,strpos(t.service_key,'LC')-strpos(t.service_key,'PL')-3) as prcl_id,
	substring(t.service_key, strpos(t.service_key,'LC')+2,strpos(t.service_key,'RP')-strpos(t.service_key,'LC')-3) as lcal_id,
	substring(t.service_key, strpos(t.service_key,'RP')+2,strpos(t.service_key,'PK')-strpos(t.service_key,'RP')-3) as rtpl_id,
	substring(t.service_key, strpos(t.service_key,'PK')+2,strpos(t.service_key,'DT')-strpos(t.service_key,'PK')-3) as pack_id,
	substring(t.service_key, strpos(t.service_key,'DT')+2,length(t.service_key)) as detg_id,
	R_CODE
from edw_stg_dds.t_000045_tfct_telephony_consumption_serv2 t
  left join edw_stg_dds.t_dim_service_xref_bis_ural xref
    on xref.service_key = t.service_key
	and to_date(t.billing_id::text, 'yyyymm') between xref.eff_dttm and xref.exp_dttm
where  xref.service_key  is null
  and t.service_key != '-1'
) a;
commit;

/*
1.3 Начисления
После обновления XREF необходима полная пересборка
*/
--delete from edw_stg_mdm.put_dim_service_xref_bis_ural_stg_1 where entity = 'tfct_total_charge';
set optimizer = on;
insert into edw_stg_mdm.put_dim_service_xref_bis_ural_stg_1
(
    service_key,
	r_code,
	srls_id,
	prcl_id,
	lcal_id,
	rtpl_id,
	pack_id,
	detg_id,
	entity,
	load_dttm
)

select
    a.service_key,
	R_CODE,
    case when srls_id = '' then null else srls_id::numeric end   as srls_id,
    case when prcl_id = '' then null else prcl_id::numeric end  as prcl_id,
    case when lcal_id = '' then null else lcal_id::numeric end  as lcal_id,
    case when rtpl_id = '' then null else rtpl_id::numeric end  as rtpl_id,
    case when pack_id = '' then null else pack_id::numeric end  as pack_id,
    case when detg_id = '' then null else detg_id::numeric end  as detg_id,
    'tfct_total_charge'::text as entity,
	now() as load_dttm
from
(
select t.service_key,
	case when t.service_key like '%R11%' then split_part(t.service_key,':R11:',2) else  '76.41.03.00' end as R_CODE,
	substring(t.service_key, strpos(t.service_key,'SL')+2,strpos(t.service_key,'PL')-strpos(t.service_key,'SL')-3) as srls_id,
	substring(t.service_key, strpos(t.service_key,'PL')+2,strpos(t.service_key,'LC')-strpos(t.service_key,'PL')-3) as prcl_id,
	substring(t.service_key, strpos(t.service_key,'LC')+2,strpos(t.service_key,'RP')-strpos(t.service_key,'LC')-3) as lcal_id,
	substring(t.service_key, strpos(t.service_key,'RP')+2,strpos(t.service_key,'PK')-strpos(t.service_key,'RP')-3) as rtpl_id,
	substring(t.service_key, strpos(t.service_key,'PK')+2,strpos(t.service_key,'DT')-strpos(t.service_key,'PK')-3) as pack_id,
	case when t.service_key like '%:R11%' then  substring(t.service_key, strpos(t.service_key,'DT')+2,strpos(t.service_key,':R11')-strpos(t.service_key,'DT')-2)
	else substring(t.service_key, strpos(t.service_key,'DT')+2,length(t.service_key)) end
	as detg_id
from edw_stg_dds.t_000045_tfct_total_charge t
  left join edw_stg_dds.t_dim_service_xref_bis_ural xref
    on xref.service_key = t.service_key
	and t.charge_date between xref.eff_dttm and xref.exp_dttm
where  xref.service_key  is null
  and t.service_key != '-1'
) a;
commit;

/*
1.4 Корректировка начислений
После обновления XREFA необходима полная пересборка.
*/
--delete from edw_stg_mdm.put_dim_service_xref_bis_ural_stg_1 where entity = 'tfct_total_charge';
set optimizer = on;
insert into edw_stg_mdm.put_dim_service_xref_bis_ural_stg_1
(
    service_key,
	r_code,
	srls_id,
	prcl_id,
	lcal_id,
	rtpl_id,
	pack_id,
	detg_id,
	entity,
	load_dttm
)

select
    a.service_key,
	R_CODE,
    case when srls_id = '' then null else srls_id::numeric end   as srls_id,
    case when prcl_id = '' then null else prcl_id::numeric end  as prcl_id,
    case when lcal_id = '' then null else lcal_id::numeric end  as lcal_id,
    case when rtpl_id = '' then null else rtpl_id::numeric end  as rtpl_id,
    case when pack_id = '' then null else pack_id::numeric end  as pack_id,
    case when detg_id = '' then null else detg_id::numeric end  as detg_id,
    'tfct_total_charge'::text as entity,
	now() as load_dttm
from
(
select t.service_key,
	case when t.service_key like '%R11%' then split_part(t.service_key,':R11:',2) else  '76.41.03.00' end as R_CODE,
	substring(t.service_key, strpos(t.service_key,'SL')+2,strpos(t.service_key,'PL')-strpos(t.service_key,'SL')-3) as srls_id,
	substring(t.service_key, strpos(t.service_key,'PL')+2,strpos(t.service_key,'LC')-strpos(t.service_key,'PL')-3) as prcl_id,
	substring(t.service_key, strpos(t.service_key,'LC')+2,strpos(t.service_key,'RP')-strpos(t.service_key,'LC')-3) as lcal_id,
	substring(t.service_key, strpos(t.service_key,'RP')+2,strpos(t.service_key,'PK')-strpos(t.service_key,'RP')-3) as rtpl_id,
	substring(t.service_key, strpos(t.service_key,'PK')+2,strpos(t.service_key,'DT')-strpos(t.service_key,'PK')-3) as pack_id,
	case when t.service_key like '%:R11%' then  substring(t.service_key, strpos(t.service_key,'DT')+2,strpos(t.service_key,':R11')-strpos(t.service_key,'DT')-2)
	else substring(t.service_key, strpos(t.service_key,'DT')+2,length(t.service_key)) end
	as detg_id
from edw_stg_dds.t_000045_tfct_adjust t
  left join edw_stg_dds.t_dim_service_xref_bis_ural xref
    on xref.service_key = t.service_key
	and t.adjust_dttm between xref.eff_dttm and xref.exp_dttm
where  xref.service_key  is null and t.service_key != '-1'
) a;
commit;

/*
1.5 Потребление СПД
После обновления XREFA необходима полная пересборка.
*/
--delete from edw_stg_mdm.put_dim_service_xref_bis_ural_stg_1 where entity = 'tfct_bba_consumption';
set optimizer = on;
insert into edw_stg_mdm.put_dim_service_xref_bis_ural_stg_1
(
    service_key,
	r_code,
	srls_id,
	prcl_id,
	lcal_id,
	rtpl_id,
	pack_id,
	detg_id,
	entity,
	load_dttm
)

select
    a.service_key,
	R_CODE,
    case when srls_id = '' then null else srls_id::numeric end   as srls_id,
    case when prcl_id = '' then null else prcl_id::numeric end  as prcl_id,
    case when lcal_id = '' then null else lcal_id::numeric end  as lcal_id,
    case when rtpl_id = '' then null else rtpl_id::numeric end  as rtpl_id,
    case when pack_id = '' then null else pack_id::numeric end  as pack_id,
    case when detg_id = '' then null else detg_id::numeric end  as detg_id,
    'tfct_bba_consumption'::text as entity,
	now() as load_dttm
from
(
select t.service_key,
	case when t.service_key like '%R11%' then split_part(t.service_key,':R11:',2) else  '76.41.03.00' end as R_CODE,
	substring(t.service_key, strpos(t.service_key,'SL')+2,strpos(t.service_key,'PL')-strpos(t.service_key,'SL')-3) as srls_id,
	substring(t.service_key, strpos(t.service_key,'PL')+2,strpos(t.service_key,'LC')-strpos(t.service_key,'PL')-3) as prcl_id,
	substring(t.service_key, strpos(t.service_key,'LC')+2,strpos(t.service_key,'RP')-strpos(t.service_key,'LC')-3) as lcal_id,
	substring(t.service_key, strpos(t.service_key,'RP')+2,strpos(t.service_key,'PK')-strpos(t.service_key,'RP')-3) as rtpl_id,
	substring(t.service_key, strpos(t.service_key,'PK')+2,strpos(t.service_key,'DT')-strpos(t.service_key,'PK')-3) as pack_id,
	case when t.service_key like '%:R11%' then  substring(t.service_key, strpos(t.service_key,'DT')+2,strpos(t.service_key,':R11')-strpos(t.service_key,'DT')-2)
	else substring(t.service_key, strpos(t.service_key,'DT')+2,length(t.service_key)) end
	as detg_id
from edw_stg_dds.t_000045_tfct_bba_consumption t
  left join edw_stg_dds.t_dim_service_xref_bis_ural xref
    on xref.service_key = t.service_key
	and t.consumption_network_dttm between xref.eff_dttm and xref.exp_dttm
where  xref.service_key  is null
  and t.service_key != '-1'
) a;
commit;
analyse edw_stg_mdm.put_dim_service_xref_bis_ural_stg_1;

/* Шаг 2 */
truncate table edw_stg_mdm.put_dim_service_xref_bis_ural;
INSERT INTO edw_stg_mdm.put_dim_service_xref_bis_ural
       ( service_key
       , srls_id
       , srls_name
       , prcl_id
       , prcl_name
       , lcal_id
       , lcal_name
       , rtpl_id
       , rtpl_name
       , pack_id
       , pack_name
       , detg_id
       , detg_name
       , r_code
	   , entity
	   , load_dttm)
select
distinct
	service_key,
	t.srls_id as srls_id,
	sl.def srls_name,
	t.prcl_id,
	prl.def prcl_name,
	t.lcal_id,
	lc.def lcal_name,
	t.rtpl_id,
	rp.name_r rtpl_name,
	t.pack_id,
	p.name_r pack_name,
	t.detg_id,
	dg.name_r detg_name,
	R_CODE,
	entity,
	now()
from  edw_stg_mdm.put_dim_service_xref_bis_ural_stg_1 t
	left join
		edw_ods.t_000045_serv_lists sl
		on t.srls_id=sl.srls_id
	left join edw_ods.t_000045_price_list prl
		on t.prcl_id= prl.prcl_id
	left join
		edw_ods.t_000045_logic_calls lc
		on t.lcal_id=lc.lcal_id
	left join
		edw_ods.t_000045_rate_plans rp
		on (  t.rtpl_id=rp.rtpl_id)
	left join
		edw_ods.t_000045_packs p
		on t.pack_id=p.pack_id
	left join
		edw_ods.t_000045_detail_groups dg
		on t.detg_id=dg.detg_id;


/*Шаг 3 - добавление ...*/

INSERT INTO edw_stg_mdm.put_dim_service_xref_bis_ural (-- в регламенте инкрементально нужно будет догружать по условияю where period_end >= date_trunc('month',to_date ( '20190630', 'YYYYMMDD' )) and period_start <= to_date ( '20190630', 'YYYYMMDD' )
																											 service_key
	, srls_id
	, srls_name
	, prcl_id
	, prcl_name
	, lcal_id
	, lcal_name
	, rtpl_id
	, rtpl_name
	, pack_id
	, pack_name
	, detg_id
	, detg_name
	, r_code
	, entity
	, load_dttm
)
	WITH put_dim_service_xref_bis_ural_stg2 AS (-- в регламенте инкрементально нужно будет догружать по условию date_trunc('day',insert_date) BETWEEN date_trunc('month',to_date ( '20190630', 'YYYYMMDD' )) AND to_date ( '20190630', 'YYYYMMDD' )
		SELECT DISTINCT
			t1.service_key,
			t1.detg_id,
			t1.rtpl_id,
			t1.pack_id AS pack_id2
		FROM (
					 SELECT DISTINCT
						 'SL:PL:LC:RP' || coalesce ( rtpl_rtpl_id :: VARCHAR(10), '' ) || ':PK' ||
						 coalesce ( pack_pack_id :: VARCHAR(10), '' )
						 || ':DT' || coalesce ( detg_detg_id :: VARCHAR(10), '' ) AS service_key,
						 detg_detg_id                                             AS detg_id,
						 rtpl_rtpl_id                                             AS rtpl_id,
						 pack_pack_id                                             AS pack_id
					 FROM edw_ods.t_000045_calls_current_00_mmyyyy
					 WHERE deleted_ind = 0
								 AND date_trunc ( 'day', insert_date ) BETWEEN date_trunc ( 'month', to_date ( '20190630',
																																															 'YYYYMMDD' ) ) AND to_date (
						 '20190630', 'YYYYMMDD' )

					 UNION
					 SELECT DISTINCT
						 'SL:PL:LC:RP' || coalesce ( rtpl_rtpl_id :: VARCHAR(10), '' ) || ':PK' ||
						 coalesce ( pack_pack_id :: VARCHAR(10), '' )
						 || ':DT' || coalesce ( detg_detg_id :: VARCHAR(10), '' ) AS service_key,
						 detg_detg_id                                             AS detg_id,
						 rtpl_rtpl_id                                             AS rtpl_id,
						 pack_pack_id                                             AS pack_id
					 FROM edw_ods.t_000045_calls_late_00_mmyyyy
					 WHERE deleted_ind = 0
								 AND date_trunc ( 'day', insert_date ) BETWEEN date_trunc ( 'month', to_date ( '20190630',
																																															 'YYYYMMDD' ) ) AND to_date (
						 '20190630', 'YYYYMMDD' )

					 UNION
					 SELECT DISTINCT
						 'SL:PL:LC:RP' || coalesce ( rtpl_rtpl_id :: VARCHAR(10), '' ) || ':PK' ||
						 coalesce ( pack_pack_id :: VARCHAR(10), '' )
						 || ':DT' || coalesce ( cost_detg_id :: VARCHAR(10), '6' ) AS service_key,
						 coalesce ( cost_detg_id, 6 )                              AS detg_id,
						 rtpl_rtpl_id                                              AS rtpl_id,
						 pack_pack_id                                              AS pack_id
					 FROM edw_ods.t_000045_roam_calls_current_mmyyyy
					 WHERE deleted_ind = 0
								 AND date_trunc ( 'day', insert_date ) BETWEEN date_trunc ( 'month', to_date ( '20190630',
																																															 'YYYYMMDD' ) ) AND to_date (
						 '20190630', 'YYYYMMDD' )

					 UNION
					 SELECT DISTINCT
						 'SL:PL:LC:RP' || coalesce ( rtpl_rtpl_id :: VARCHAR(10), '' ) || ':PK' ||
						 coalesce ( pack_pack_id :: VARCHAR(10), '' )
						 || ':DT' || coalesce ( cost_detg_id :: VARCHAR(10), '6' ) AS service_key,
						 coalesce ( cost_detg_id, 6 )                              AS detg_id,
						 rtpl_rtpl_id                                              AS rtpl_id,
						 pack_pack_id                                              AS pack_id
					 FROM edw_ods.t_000045_roam_calls_late_mmyyyy
					 WHERE deleted_ind = 0
								 AND date_trunc ( 'day', insert_date ) BETWEEN date_trunc ( 'month', to_date ( '20190630',
																																															 'YYYYMMDD' ) ) AND to_date (
						 '20190630', 'YYYYMMDD' )

				 ) t1
			LEFT JOIN edw_stg_dds.t_dim_service_xref_bis_ural xr
				ON xr.service_key = t1.service_key
					 AND xr.exp_dttm = '2999-12-31 00:00:00'
		WHERE xr.service_key IS NULL OR pkey_src_object = -1
	),
			accc_detg_rtpl AS (
			SELECT
				pack_pack_id,
				detg_detg_id,
				rtpl_rtpl_id,
				ACCC_ACCC_ID
			FROM (
						 SELECT
							 pack_pack_id,
							 detg_detg_id,
							 rtpl_rtpl_id,
							 ACCC_ACCC_ID,
							 row_number ( )
							 OVER (
								 PARTITION BY pack_pack_id, detg_detg_id, rtpl_rtpl_id
								 ORDER BY period_end DESC, period_start DESC
								 ) rn
						 FROM edw_ods.t_000045_accc_detg_rtpl t
						 WHERE period_end >= date_trunc ( 'month', to_date ( '20190630', 'YYYYMMDD' ) ) AND
									 period_start <= to_date ( '20190630', 'YYYYMMDD' )
					 ) q
			WHERE q.rn = 1
		),
			SERV AS (
			SELECT
				cm.RTPL_ID,
				cm.DETG_ID,
				cm.pack_id2,
				AA.ACC_NUM AS R_CODE,
				AA.ACCC_ID AS ACCC_ID,
				CASE
				WHEN ADR1.ACCC_ACCC_ID IS NOT NULL
					THEN 1
				WHEN ADR2.ACCC_ACCC_ID IS NOT NULL
					THEN 2
				WHEN ADR3.ACCC_ACCC_ID IS NOT NULL
					THEN 3
				WHEN ADR4.ACCC_ACCC_ID IS NOT NULL
					THEN 4
				END        AS PR,
				service_key
			FROM put_dim_service_xref_bis_ural_stg2 cm
				-- полное совпадение
				LEFT JOIN accc_detg_rtpl ADR1
					ON /*ADR1.PACK_PACK_ID IS NOT NULL
	  AND */ADR1.PACK_PACK_ID = cm.PACK_ID2
					AND ADR1.DETG_DETG_ID = cm.detg_id
					--AND ADR1.RTPL_RTPL_ID IS NOT NULL
					AND ADR1.RTPL_RTPL_ID = cm.RTPL_ID
				-- нет пакета
				LEFT JOIN accc_detg_rtpl ADR2
					ON cm.detg_id = ADR2.DETG_DETG_ID
						 --AND ADR2.RTPL_RTPL_ID IS NOT NULL
						 AND cm.RTPL_ID = ADR2.RTPL_RTPL_ID
						 AND ADR2.PACK_PACK_ID IS NULL
				-- нет тарифного плана
				LEFT JOIN accc_detg_rtpl ADR3
					ON ADR3.DETG_DETG_ID = cm.detg_id
						 AND ADR3.RTPL_RTPL_ID IS NULL
						 --AND ADR3.PACK_PACK_ID IS NOT NULL
						 AND ADR3.PACK_PACK_ID = cm.PACK_ID2
				-- нет пакета и тарифного плана
				LEFT JOIN accc_detg_rtpl ADR4
					ON cm.detg_id = ADR4.DETG_DETG_ID
						 AND ADR4.RTPL_RTPL_ID IS NULL
						 AND ADR4.PACK_PACK_ID IS NULL
				LEFT JOIN edw_ods.t_000045_acc_accounts AA
					ON COALESCE ( ADR1.ACCC_ACCC_ID,
												ADR2.ACCC_ACCC_ID,
												ADR3.ACCC_ACCC_ID,
												ADR4.ACCC_ACCC_ID ) = AA.ACCC_ID
		),
			SERV2 AS (
			SELECT
				service_key,
				rtpl_id,
				pack_id2 AS                pack_id,
				R_CODE,
				detg_id,
				ROW_NUMBER ( )
				OVER (
					PARTITION BY service_key
					ORDER BY t.PR, ACCC_ID ) RN
			FROM SERV t
		),
			stg AS (
			SELECT
				service_key || ':R11:' || coalesce(R_CODE,'') AS service_key,
				R_CODE,
				rtpl_id,
				pack_id,
				detg_id,
				'tfct_mvno'                      AS entity,
				now ( )                          AS load_dttm
			FROM SERV2
			WHERE RN = 1
		)
	SELECT DISTINCT
		service_key,
		NULL :: NUMERIC(10, 0) AS srls_id,
		NULL                   AS srls_name,
		NULL :: NUMERIC(10, 0) AS prcl_id,
		NULL                   AS prcl_name,
		NULL :: NUMERIC(10, 0) AS lcal_id,
		NULL                   AS lcal_name,
		t.rtpl_id :: NUMERIC(10, 0),
		rp.name_r                 rtpl_name,
		t.pack_id :: NUMERIC(10, 0),
		p.name_r                  pack_name,
		t.detg_id :: NUMERIC(10, 0),
		dg.name_r                 detg_name,
		R_CODE,
		entity,
		now ( )
	FROM stg t
		LEFT JOIN (
								SELECT
									rtpl_id,
									name_r,
									row_number ( )
									OVER (
										PARTITION BY rtpl_id
										ORDER BY number_history DESC ) rn
								FROM edw_ods.t_000045_rate_plans
							) rp
			ON t.rtpl_id = rp.rtpl_id
				 AND rp.rn = 1
		LEFT JOIN (
								SELECT
									pack_id,
									name_r,
									row_number ( )
									OVER (
										PARTITION BY pack_id
										ORDER BY navi_date DESC ) rn
								FROM edw_ods.t_000045_packs
							) p
			ON t.pack_id = p.pack_id
				 AND p.rn = 1
		LEFT JOIN (
								SELECT
									detg_id,
									name_r,
									row_number ( )
									OVER (
										PARTITION BY detg_id
										ORDER BY load_dttm DESC ) rn
								FROM edw_ods.t_000045_detail_groups
							) dg
			ON t.detg_id = dg.detg_id
				 AND dg.rn = 1;
commit;
analyse edw_stg_mdm.put_dim_service_xref_bis_ural;
