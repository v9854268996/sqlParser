/*rev.46053 от 09.01.2020*/
truncate table edw_stg_dds.t_000051_dim_add_service;
insert into edw_stg_dds.t_000051_dim_add_service
  (
      add_service_key
    , add_service_parent_key
    , service_key
    , branch_key
    , account_name
    , subs_name
    , mrf_service_key
    , mrf_add_service_name
    , start_date
    , end_date
    , dop_service_key
    , add_serv_sc_key
    , src_id
  )
with add_service as
  (
    SELECT
        '1#'||ts1.service_id as add_service_key
      , '1#'||coalesce(ts1.serv_first_id,ts1.service_id)  as add_service_parent_key
      , ts1.svc_id as service_key
      , ts1.dev_id as subs_name
      , ts1.svc_id as mrf_service_key
      , ts1.date_begin as start_date
      , coalesce(ts1.date_end, to_date('29991231', 'YYYYMMDD')) as end_date
      , ts1.svc_id as dop_service_key
      , ts1.service_id::text as add_serv_sc_key
      , ts1.src_id
      , ts1.user_id
    FROM
      edw_ods.t_000051_t_services ts1
    WHERE
      ts1.exp_dttm=to_date('29991231', 'YYYYMMDD')
      AND ts1.deleted_ind=0

    UNION ALL

    SELECT
        '2#'||tos.oth_svc_id as add_service_key
      , '2#'||tos.oth_svc_id as add_service_parent_key
      , tos.svc_id as service_key
      , NULL as subs_name
      , tos.svc_id as mrf_service_key
      , tos.svc_date as start_date
      , tos.svc_date as end_date
      , tos.svc_id as dop_service_key
      , '2#'||tos.oth_svc_id as add_serv_sc_key
      , tos.src_id
      , tos.user_id
    FROM
      edw_ods.t_000051_t_other_svc tos
    WHERE
      tos.pack_num NOT IN ('IP')
  )
SELECT
    ts1.add_service_key::text
  , ts1.add_service_parent_key::text
  , ts1.service_key::text
  , tu1.dept_id::text as branch_key
  , tu1.account::numeric as account_name
  , ts1.subs_name
  , ts1.mrf_service_key::text
  , tsr1.name as mrf_add_service_name
  , ts1.start_date
  , ts1.end_date
  , ts1.dop_service_key::text
  , ts1.add_serv_sc_key
  , ts1.src_id
FROM
  add_service ts1
  INNER JOIN
    edw_ods.t_000051_t_users tu1 
      ON tu1.user_id=ts1.user_id
      AND tu1.exp_dttm=to_date('29991231', 'YYYYMMDD')
      AND tu1.deleted_ind=0
      AND tu1.iscorp='N'
  INNER JOIN
    edw_ods.t_000051_t_svc_ref tsr1 
      ON tsr1.svc_id=ts1.service_key
      AND tsr1.exp_dttm=to_date('29991231', 'YYYYMMDD')
      AND tsr1.deleted_ind=0
;

analyze edw_stg_dds.t_000051_dim_add_service;
