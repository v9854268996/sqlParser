--rev.37932 от 18.09.2019
DELETE FROM edw_stg_mdm.put_xref_dim_branch_orpon WHERE src_id = 148;

INSERT INTO edw_stg_mdm.put_xref_dim_branch_orpon
  (
    source_key,
    source_name,
    load_dttm,
    src_id
  )
with fil as
(
  select id as code, name as filial from edw_ods.T_000148_ENT_RF_RTK as mrf -- это МРФ‘ы
  union all
  select id as code, name as filial from edw_ods.T_000148_ENT_R_RTK -- это РФ‘ы
)  
select distinct  
  code as source_key,
  filial as source_name,
  now() as load_dttm,
  148 as src_id
from fil;

analyse edw_stg_mdm.put_xref_dim_branch_orpon;
