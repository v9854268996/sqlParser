--rev.58574 от 22.05.2020

truncate table edw_stg_dds.t_000207_dim_add_serv_sales_channel;

insert into edw_stg_dds.t_000207_dim_add_serv_sales_channel
(
    add_serv_sc_key
    , start_date
    , oper_id
    , oper_name
    , mrf_service_key
    , product_name
    , mrf_add_service_name
    , account_name
    , service_key
    , dop_service_key
    , sales_channel_key
    , sales_channel
    , init_system
    , branch_key
    , src_id
)
select
    t.service_id            as add_serv_sc_key
    , t.date_sys            as start_date
    , t.login_name          as oper_id
    , t.oper_name           as oper_name
    , t.svc_id              as mrf_service_key
    , t.product_cod         as product_name
    , t.svc_name            as mrf_add_service_name
    , t.account             as account_name
    , t.svc_id              as service_key
    , t.svc_id              as dop_service_key
    , t.sales_channel_key
    , t.sales_channel
    , t.init_system
    , t.dept_id as branch_key
    , t.src_id
from (
        select
            '1#' || service_id as service_id
            , date_sys
            , login_name
            , oper_name
            , svc_id
            , product_cod
            , svc_name
            , account::numeric
            , case
                when sales_channel is null
                then '-2'
                else regexp_replace(trim(upper(sales_channel)),'[ ]+',' ','g')
              end as sales_channel_key
            , sales_channel
            , init_system
            , dept_id
            , 000207 as src_id
            , row_number() over (partition by service_id order by tech_dt desc) as rn
        from edw_ods.t_000207_mrf_antivir_connect
) t
where t.rn = 1;
commit;

analyze edw_stg_dds.t_000207_dim_add_serv_sales_channel;
