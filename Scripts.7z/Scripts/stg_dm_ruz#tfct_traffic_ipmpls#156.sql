/*rev.48515 от 06.02.2020*/
	set optimizer = on;
truncate table edw_stg_dm_ruz.tfct_traffic_ipmpls_1_prt_p000156;
insert into edw_stg_dm_ruz.tfct_traffic_ipmpls_1_prt_p000156
(
	period,
	mrf_oebs_r12_code,
	mrf_oebs_r12_name,
	oebs_r12_branch_key,
	branch_code ,
	branch_name,
	rf_oebs_r12_code,
	rf_oebs_r12_name,
	source,
	business_segment_key,
	business_segment_short_name,
	client_name,
	rc_key,
	rc_code,
	rc_short_name,
	cms_order_point2address,
	segment_key,
	segment_name,
	budget_segmentation,
	cms_client_inn,
	business_service_ruz_key,
	business_service_ruz_parent_name,
	business_service_ruz_detail_name,
	business_service_ruz_sap_code,
	has_region_lastmile,
	in_traf,
	out_traf,
	total_traf,
	cms_order,
	cms_service,
	fldincomeitem,
	fldincomeitemnumber,
	fldincomeitemyear,
	src_id
)
with 
cms_order_pir as 
(
	select    
		fldordernumber as ord 
		, fldConnectMode
		, ROW_NUMBER() OVER( PARTITION BY fldordernumber ORDER BY CURRENTVERSION desc) as rn
	from  edw_ods.t_000137_ORDERCMS t
	where fldConnectMode  in ('1','2', '11' ,  '12', '13')
		and ( fldorganizationtype  like   '%Российский оператор%' or  fldorganizationtype like   '%Зарубежный оператор%')
		and fldordernumber is not null
		and deleted_ind = '0'
		and tech_dt between cast(to_date('20190601','YYYYMMDD') as timestamp(0)) - interval '2 year' and cast(to_date('20190630','YYYYMMDD') as timestamp(0))
),
union_ext as (
	select 
		period,
		case when upper (client_name)  like '%БАШИНФОРМСВЯЗЬ%'  then 52 else oebs_r12_branch_key end as oebs_r12_branch_key,
		source,
		business_segment_key,
		client_name,
		rc_key,
		cms_order_point2address,
		segment_key,
		cms_cleint_inn,
		business_service_ruz_key,
		has_region_lastmile,
		in_traf,
		out_traf,
		total_traf,
		cms_order,
		cms_service,
		fldincomeitem,
		fldincomeitemnumber,
		fldincomeitemyear
	from edw_stg_dm_ruz.pre_fct_ip_mpls_traffic_teoco_1_prt_p000156
	where period = to_date('20190601','YYYYMMDD')
	union all
	select 
		period,
		case when upper (client_name)  like '%БАШИНФОРМСВЯЗЬ%'  then 52 else oebs_r12_branch_key end as oebs_r12_branch_key,
		source,
		business_segment_key,
		client_name,
		rc_key,
		cms_order_point2address,
		segment_key,
		cms_cleint_inn,
		business_service_ruz_key,
		has_region_lastmile,
		in_traf,
		out_traf,
		total_traf,
		cms_order,
		cms_service,
		null as FLDINCOMEITEM,
		null as FLDINCOMEITEMNUMBER,
		null as FLDINCOMEITEMYEAR
	from edw_stg_dm_ruz.pre_fct_ip_mpls_traffic_iptv_1_prt_p000156
	where period = to_date('20190601','YYYYMMDD')
	union all
	select 
		period,
		case when upper (client_name)  like '%БАШИНФОРМСВЯЗЬ%'  then 52 else oebs_r12_branch_key end as oebs_r12_branch_key,
		source,
		business_segment_key,
		client_name,
		rc_key,
		cms_order_point2address,
		segment_key,
		cms_cleint_inn,
		business_service_ruz_key,
		has_region_lastmile,
		in_traf,
		out_traf,
		total_traf,
		cms_order,
		cms_service,
		fldincomeitem,
		fldincomeitemnumber,
		fldincomeitemyear
	from edw_stg_dm_ruz.pre_fct_ip_mpls_traffic_teoco_v_1_prt_p000156
	where period = to_date('20190601','YYYYMMDD')
)
select
	period,
	m.oebs_r12_code mrf_oebs_r12_code,
	m.oebs_r12_name mrf_oebs_r12_name,
	br.oebs_r12_branch_ruz_key,
	br.branch_code ,
	br.branch_name,
	br.oebs_r12_code rf_oebs_r12_code,
	br.oebs_r12_name rf_oebs_r12_name,
	t.source,
	bs.business_segment_key,
	bs.business_segment_short_name,
	t.client_name,
	rc.rc_key,
	rc.rc_code,
	rc.rc_short_name,
	t.cms_order_point2address,
	se.segment_key,
	se.segment_name,
	se.budget_segmentation,
	t.cms_cleint_inn,
	coalesce(sr.business_service_ruz_key, -1),
	sr.business_service_ruz_parent_name,
	sr.business_service_ruz_detail_name,
	sr.business_service_ruz_sap_code,
	case when t.has_region_lastmile = 'Y' then 'да' else 'нет' end has_region_lastmile,
	sum(t.in_traf) in_traf,
	sum(t.out_traf) out_traf,
	sum(t.out_traf) total_traf,
	t.cms_order,
	t.cms_service,
	t.fldincomeitem,
	t.fldincomeitemnumber,
	t.fldincomeitemyear,
	000156 src_id
FROM union_ext t
	left join edw_dds.dim_oebs_r12_branch_ruz br 
	on ( 1 = 1
		and t.oebs_r12_branch_key = br.oebs_r12_branch_ruz_key 
		and br.deleted_ind='0'
		and br.exp_dttm = to_date('29991231', 'YYYYMMDD')
	)
	left join 
		(select distinct branch_code::numeric mrf_id,oebs_r12_code, oebs_r12_name 
			from edw_dds.dim_oebs_r12_branch_ruz b 
			where 1 = 1
				and b.deleted_ind = '0' 
				and to_date('20190601','YYYYMMDD') between b.eff_dttm and b.exp_dttm
				and oebs_r12_code in ('011000','012000','013000','014000','015000','016000','017000')		) m 
	on ( 1 = 1
		and case 
			when br.branch_code in ('1003','019000') then '1100' 
			else (substring(br.branch_code,1,2)||'00')::numeric 
		end  = m.mrf_id
	)
	left join edw_dds.dim_business_segment bs      
	on ( 1 = 1
		and t.business_segment_key = bs.business_segment_key          
		and bs.deleted_ind = '0'
		and to_date('20190601','YYYYMMDD') between bs.eff_dttm and bs.exp_dttm
		)
	left join edw_dds.dim_rc rc                    
	on ( 1 = 1
		and t.rc_key = rc.rc_key                                      
		and rc.deleted_ind = '0'
		and to_date('20190601','YYYYMMDD') between rc.eff_dttm and rc.exp_dttm
		)
	left join edw_dds.dim_segment se               
	on ( 1 = 1
		and t.segment_key = se.segment_key                            
		and se.deleted_ind = '0'
		and to_date('20190601','YYYYMMDD') between se.eff_dttm and se.exp_dttm
		)
	left join edw_dds.dim_business_service_ruz sr  
	on ( 1 = 1
		and t.business_service_ruz_key = sr.business_service_ruz_key  
		and sr.deleted_ind = '0'
		and to_date('20190601','YYYYMMDD') between sr.eff_dttm and sr.exp_dttm
		)
		left join  cms_order_pir p  -- Изменение логики искл.пиринга 15.01.2020 
	on ( 1= 1
		and t.cms_order = p.ord 
		and p.rn=1  
		and se.segment_name like '%K03%'
	 	and ( t.business_service_ruz_key  in (1,2,3,4) and 	 p.fldConnectMode  in ( '1',  '2'  )
		or 
		 t.business_service_ruz_key  =21 and 	 p.fldConnectMode  in (  '2', '11' ,  '12', '13' ) 
		)

	)
where 1 = 1
	and  ( p.ord is    null -- Изменение логики искл.пиринга 15.01.2020 
	or 	( p.fldConnectMode  in (  '1', '11' ,  '12', '13'  )  and (  coalesce (fldincomeitemnumber,'-1') like '%R0802020105%'
																or  coalesce (fldincomeitemnumber,'-1') like  '%R0802020106%' ))
	)
group by
	period,
	m.oebs_r12_code,
	m.oebs_r12_name,
	br.oebs_r12_branch_ruz_key,
	br.branch_code ,
	br.branch_name,
	br.oebs_r12_code,
	br.oebs_r12_name,
	t.source,
	bs.business_segment_key,
	bs.business_segment_short_name,
	t.client_name,
	rc.rc_key,
	rc.rc_code,
	rc.rc_short_name,
	t.cms_order_point2address,
	se.segment_key,
	se.segment_name,
	se.budget_segmentation,
	t.cms_cleint_inn,
	sr.business_service_ruz_key,
	sr.business_service_ruz_parent_name,
	sr.business_service_ruz_detail_name,
	sr.business_service_ruz_sap_code,
	t.has_region_lastmile,
	t.cms_order,
	t.cms_service,
	t.fldincomeitem,
	t.fldincomeitemnumber,
	t.fldincomeitemyear
having sum(t.out_traf) >0;
commit;
analyse edw_stg_dm_ruz.tfct_traffic_ipmpls_1_prt_p000156;