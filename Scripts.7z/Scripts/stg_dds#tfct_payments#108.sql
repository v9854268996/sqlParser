/*rev.47175 22.01.2020*/
	truncate table edw_stg_dds.t_000108_tfct_payments;
insert into edw_stg_dds.t_000108_tfct_payments 
	(payment_key
	, account_key
	, payment_amt
	, payment_dttm
	, billing_dttm
	, comments
	, src_id
	, load_dttm
	, eff_dttm
	, exp_dttm)
select 
    payment_key
	, src_id||'#'||account_key as account_key
	, payment_amt
	, payment_dttm
	, billing_dttm
	, comments
	, src_id
	, load_dttm
	, eff_dttm
	, exp_dttm
from(
select  t_payments.payment_id as payment_key -- Идентификатор платежа
		,t_payments.user_id as account_key -- Идентификатор лицевого счета
		,t_payments.summ as payment_amt -- Сумма платежа
		,t_payments.pay_date as payment_dttm -- Дата платежа
		,to_date(Billing_id::text, 'YYYYMM') as billing_dttm -- Дата билинга
		,pdr.name as comments
		,-1 as bill_key -- Идентификатор счета
		,-1 as contract_key -- Идентификатор договора
		,-1 as partner_key -- Идентификатор платежного агента
		,-1 as source_payment_key -- Идентификатор источника платежа
		,000108 as src_id
  		,now() as load_dttm
		,to_date('19000101', 'YYYYMMDD') as eff_dttm
		,to_date('29991231', 'YYYYMMDD')  as exp_dttm
		
from edw_ods.t_000108_t_payments t_payments
left join edw_ods.t_000108_T_PAY_DOC_REF pdr 
  on pdr.PAY_DOC_ID = t_payments.PAY_DOC_ID
 and pdr.deleted_ind = 0
 and to_date(round(t_payments.billing_id)::text, 'YYYYMM') between pdr.eff_dttm and pdr.exp_dttm
where  Billing_id between substr('20190601', 1, 6)::int and substr('20190630', 1, 6)::int
and tech_dt  between to_date('20190601', 'YYYYMMDD') and to_date('20190630', 'YYYYMMDD') + INTERVAL '1 day - 1 second'
)sss
;
commit;
analyse edw_stg_dds.t_000108_tfct_payments;    
