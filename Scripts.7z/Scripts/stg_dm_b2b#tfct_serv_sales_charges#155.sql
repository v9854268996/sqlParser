-- rev. 59310 от 28.05.2020

SET optimizer = ON;
SET search_path = edw_stg_dm_b2b;
COMMIT;

BEGIN;
  TRUNCATE TABLE edw_stg_dm_b2b.tfct_serv_sales_charges_1_prt_p000155;
COMMIT;

BEGIN;
-- загружаем начисления за период
INSERT INTO edw_stg_dm_b2b.tfct_serv_sales_charges_1_prt_p000155
  (period, ch_dt, sale_serv_id, charges_plat, charges_bill, src_id)
SELECT ch.period,
       NULL AS ch_dt,
       ss.sale_serv_id,
       NULL AS charges_plat,
       sum(ch.charge - ch.vat_amount) AS charges_bill,
       ch.src_id
  FROM edw_dm_b2b.tfct_serv_sales ss
       JOIN
       edw_ods.t_000155_rprt_charges_dwh ch
         ON ch.period < date_trunc('month', current_date)
        AND ch.account = ss.account
        AND ch.rf_id = ss.branch_key
        AND ch.period >= ss.period
        AND ss.subs_login ~ ch.login --иногда в логине только номер устройства
 WHERE (CASE
            WHEN 000155 :: smallint = 151 THEN ss.src_id = ANY (ARRAY[48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62])
            WHEN 000155 :: smallint = 152 THEN ss.src_id = ANY (ARRAY[97])
            WHEN 000155 :: smallint = 153 THEN ss.src_id = ANY (ARRAY[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 207])
            --WHEN 000155 :: smallint = 154 THEN ss.src_id = ANY (ARRAY[])
            WHEN 000155 :: smallint = 155 THEN ss.src_id = ANY (ARRAY[45])
            WHEN 000155 :: smallint = 156 THEN ss.src_id = ANY (ARRAY[80, 81, 82, 83, 84, 85, 86, 87, 88, 89])
            WHEN 000155 :: smallint = 157 THEN ss.src_id = ANY (ARRAY[107, 108, 109, 110, 111, 113])
       END)
   AND ch.period >= date_trunc('month', to_date('20190601', 'YYYYMMDD'))
   AND ch.period <= date_trunc('month', to_date('20190630', 'YYYYMMDD'))
 GROUP BY ch.period,
          ss.sale_serv_id,
          ch.src_id;
COMMIT;

BEGIN;
  ANALYZE edw_stg_dm_b2b.tfct_serv_sales_charges_1_prt_p000155;
COMMIT;
