/*rev.33719  19.07.2019 Changed by: YURIY.KLYUEV */

truncate edw_stg_dds.t_000001_tfct_telephony_consumption;
insert into edw_stg_dds.t_000001_tfct_telephony_consumption
(
telephony_consumption_key
, call_start_dttm
, billing_id
, subs_key
, account_key
, service_key
, call_dur_actually_nval
, call_dur_paid_nval
, call_dur_rounded_nval
, src_id
, num_a
, num_b
, rc_key
, mobile_flg
, is_vims
)

select
telephony_consumption_key
, call_start_dttm
, billing_id
, subs_key
, account_key
, service_key
/*,price_plan_key*/
, call_dur_actually_nval
, call_dur_paid_nval
, call_dur_rounded_nval
, src_id
, num_a
, num_b
, rc_key
, mobile_flg
, is_vims

from(
/*t_apus*/
  select
  '1#'||trunc(t_apus.id_connect) as telephony_consumption_key
  , t_apus.talkdate as call_start_dttm   -- Дата и время начала звонка
  , to_date(trunc(t_apus.billing_id)::varchar,'YYYYMMDD') as billing_id   -- Биллинговый период
  , coalesce(dim_subs.subs_key ,dim_subs2.subs_key ,dim_subs1.subs_key) as subs_key       -- Идентификатор Абонента
  , t_apus.src_id||'#'||trunc(t_apus.user_id) as account_key    -- Идентификатор лицевого счета
  , ap.svc_id as service_key
  , t_apus.dlit as call_dur_actually_nval  -- Фактическая длительность звонка логическая
  , t_apus.tarif_dlit as call_dur_paid_nval -- Фактическая протарифицированная длительность звонка логическая
  , t_apus.dlit as call_dur_rounded_nval   -- Округленная Фактическая протарифицированная длительность звонка логическая
  , t_apus.src_id as src_id
  , t_apus.phonea as num_a  --Номер А
  , t_apus.phoneb as num_b  --Номер Б
  , dim_segment.segment_name||'#'||ap.rcode_asr as rc_key
  , case when t_apus.phoneb  like '79%' or  t_apus.phoneb like '89%' then 'Y' else 'N' end as mobile_flg
  , case when lower(t_mts_block.dop) like '%vims%' then 'Y' else 'N' end is_vims
  , row_number() over (partition by t_apus.id_connect order by case when t_apus.src_id||'#'||trunc(t_apus.user_id) = dim_subs.account_key then 1 else 99 end) as key1

  from edw_ods.t_000001_t_apus t_apus
  inner join
  (
    select
    trunc(ap.svc_id) as svc_id
    , trunc(ap.id_plan) as id_plan
    , xref.sub_make
        ,case
      when bs.parent_business_service_key = 10100
        then 10101
      else bs.business_service_key
    end as business_service_key
    , xref.rcode_asr
    from  edw_ods.t_000001_t_apus_plan ap
    left join edw_stg_dds.t_dim_service_xref_start xref
      on xref.source_key =  trunc(ap.svc_id)::text
      and to_date(substr('20190601', 1, 8), 'YYYYMMDD') + INTERVAL '1 MONTH - 1 second' between xref.eff_dttm and xref.exp_dttm
      and xref.region_id = 'VOLGA'
    left join edw_dds.dim_service et
      on et.service_key = xref.service_key
      and to_date(substr('20190601', 1, 8), 'YYYYMMDD') + INTERVAL '1 MONTH - 1 second' between et.eff_dttm and et.exp_dttm
    JOIN edw_dds.dim_business_service bs
      ON bs.business_service_key = et.business_service_key
        and to_date(substr('20190601', 1, 8), 'YYYYMMDD') + INTERVAL '1 MONTH - 1 second' between bs.eff_dttm and bs.exp_dttm
    where ap.deleted_ind = 0
          and to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second'
                between ap.eff_dttm and ap.exp_dttm
  )ap
    on
    trunc(t_apus.plan_id) = ap.id_plan

  JOIN edw_stg_dds.t_000001_dim_account dim_account
    ON
    t_apus.src_id||'#'||trunc(t_apus.user_id) = dim_account.account_key
    and t_apus.src_id = dim_account.src_id
    and to_date(trunc(t_apus.billing_id)::text,'YYYYMMDD') + INTERVAL '1 MONTH - 1 second' between dim_account.eff_dttm and dim_account.exp_dttm

  JOIN edw_stg_dds.t_000001_dim_partner dim_partner
    ON
    dim_account.partner_key = dim_partner.partner_key
    and dim_account.src_id = dim_partner.src_id
    and to_date(trunc(t_apus.billing_id)::text,'YYYYMMDD') + INTERVAL '1 MONTH - 1 second' between dim_partner.eff_dttm and dim_partner.exp_dttm

  LEFT JOIN edw_dds.hub_dim_segment hub_dim_segment
    ON
    hub_dim_segment.source_key = dim_partner.segment_key
    and hub_dim_segment.src_id = dim_partner.src_id
    and to_date(trunc(t_apus.billing_id)::text,'YYYYMMDD') + INTERVAL '1 MONTH - 1 second' between hub_dim_segment.eff_dttm and hub_dim_segment.exp_dttm

  LEFT JOIN edw_dds.dim_segment dim_segment
    ON
    dim_segment.segment_key = hub_dim_segment.segment_key
    and dim_segment.deleted_ind=0
    and to_date(trunc(t_apus.billing_id)::text,'YYYYMMDD') + INTERVAL '1 MONTH - 1 second' between dim_segment.eff_dttm and dim_segment.exp_dttm

  left join

  (
    select
    subs.serv_first_id
    , subs.subs_key
    , subs.start_date
    , subs.end_date
    , subs.account_key

    from  edw_stg_dds.t_000001_dim_subs subs
  ) dim_subs

    on dim_subs.serv_first_id = trunc(t_apus.service_id)::text
    and t_apus.talkdate between dim_subs.start_date and dim_subs.end_date

  left join
  (
    select distinct
    subs.serv_first_id
    , subs.subs_key
    , row_number() over (order by subs.serv_first_id desc, subs.end_date desc, subs.subs_key desc) as numm

    from  edw_stg_dds.t_000001_dim_subs subs

  ) dim_subs1

    on dim_subs1.serv_first_id = trunc(t_apus.service_id)::text
    and dim_subs1.numm = 1

  left join
  (
    select distinct
      subs.subs_key
      ,bs.business_service_key
      , subs.start_date
      , subs.end_date
      , subs.account_key
      , t_services.dev_id
    from  edw_stg_dds.t_000001_dim_subs subs
    left join edw_stg_dds.t_dim_service_xref_start xref
      on xref.source_key =  subs.service_key
      and to_date(substr('20190601', 1, 8), 'YYYYMMDD') + INTERVAL '1 MONTH - 1 second' between xref.eff_dttm and xref.exp_dttm
      and xref.region_id = 'VOLGA'
    left join edw_dds.dim_service et
      on et.service_key = xref.service_key
      and to_date(substr('20190601', 1, 8), 'YYYYMMDD') + INTERVAL '1 MONTH - 1 second' between et.eff_dttm and et.exp_dttm
    JOIN edw_dds.dim_business_service bs
      ON bs.business_service_key = et.business_service_key
        and to_date(substr('20190601', 1, 8), 'YYYYMMDD') + INTERVAL '1 MONTH - 1 second' between bs.eff_dttm and bs.exp_dttm
    inner join edw_ods.t_000001_t_services t_services
      on trunc(t_services.service_id)::text = subs.service_id
            and to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second' + interval '6 days'
                between t_services.eff_dttm and t_services.exp_dttm

  ) dim_subs2

    on t_apus.src_id||'#'||trunc(t_apus.user_id) = dim_subs2.account_key
    and ap.business_service_key = dim_subs2.business_service_key
    and t_apus.talkdate between dim_subs2.start_date and dim_subs2.end_date
    and dim_subs2.dev_id::text = t_apus.phonea
  left join edw_ods.t_000001_t_mts_block t_mts_block
    on 1=1
    and t_mts_block.block_id = t_apus.block_id
    and to_date(trunc(t_apus.billing_id)::text,'YYYYMMDD') + INTERVAL '1 MONTH - 1 second' between t_mts_block.eff_dttm and t_mts_block.exp_dttm
    and t_mts_block.deleted_ind = '0'
  where trunc(t_apus.billing_id) between substr('20190601', 1, 6)::int and substr('20190630', 1, 6)::int
    and t_apus.tech_dt between to_date(substr('20190601', 1, 8), 'YYYYMMDD') and to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second'

)s2
WHERE  key1=1
;

insert into edw_stg_dds.t_000001_tfct_telephony_consumption
(
telephony_consumption_key
, call_start_dttm
, billing_id
, subs_key
, account_key
, service_key
, call_dur_actually_nval
, call_dur_paid_nval
, call_dur_rounded_nval
, src_id
, num_a
, num_b
, rc_key
, mobile_flg
, is_vims
)

select
telephony_consumption_key
, call_start_dttm
, billing_id
, subs_key
, account_key
, service_key
, call_dur_actually_nval
, call_dur_paid_nval
, call_dur_rounded_nval
, src_id
, num_a
, num_b
, rc_key
, mobile_flg
, is_vims

from
(
/*t_mts_sig*/
  select
  '2#'||trunc(t_mts_sig.mtr_id) as telephony_consumption_key -- Идентификатор потребления услуг телефонии
  , t_mts_sig.talkdate as call_start_dttm    -- Дата и время начала звонка
  , to_date(trunc(t_mts_sig.billing_id)::text,'YYYYMMDD') as billing_id    -- Биллинговый период
  , coalesce(dim_subs.subs_key ,dim_subs2.subs_key ,dim_subs1.subs_key) as subs_key       -- Идентификатор Абонента
  , t_mts_sig.src_id||'#'||trunc(t_mts_res.user_id) as account_key    -- Идентификатор лицевого счета
  , case
    when t_mts_sig.avt='Y'
      then trunc(t_mts_zone.A_SVC_ID)
      else trunc(t_mts_zone.Z_SVC_ID)
  end as service_key        -- Идентификатор услуги
  , (t_mts_sig.real_dlit * 60) as call_dur_actually_nval  -- Фактическая длительность звонка логическая
  , case when lower(T_MTS_ZONE.NAME) like '%бесп%' and T_MTS_ZONE.NAME like '%800%' then 0 else t_mts_res.dlit * 60 end  as call_dur_paid_nval -- Фактическая протарифицированная длительность звонка логическая
  , (t_mts_res.dlit * 60) as call_dur_rounded_nval   -- Округленная Фактическая протарифицированная длительность звонка логическая
  , t_mts_sig.src_id as src_id
  , t_mts_sig.phonefrom as num_a --Номер А
  , t_mts_sig.codetown||t_mts_sig.phoneto as num_b --Номер Б
  , dim_segment.segment_name||'#'||xref.rcode_asr as rc_key
  , case when t_mts_zone.is_mobile = 'Y'  or  t_mts_sig.codetown||t_mts_sig.phoneto like '79%' or  t_mts_sig.codetown||t_mts_sig.phoneto like '89%' then 'Y' else 'N' end as mobile_flg
  , case when lower(t_mts_block.dop) like '%vims%' then 'Y' else 'N' end is_vims
  , row_number() over (partition by t_mts_sig.mtr_id order by case when t_mts_res.src_id||'#'||round(t_mts_res.user_id) = dim_subs.account_key  then 1 else 99 end) as key1

  from  edw_ods.t_000001_t_mts_sig t_mts_sig
  inner join edw_ods.t_000001_t_mts_res t_mts_res
    on
    t_mts_sig.MTR_ID = t_mts_res.MTR_ID
  left join edw_ods.t_000001_t_mts_zone t_mts_zone
    on
    t_mts_zone.MTS_ZONE_ID = t_mts_res.MTS_ZONE_ID
    and t_mts_zone.deleted_ind = 0
        and to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second' + interval '6 days' between t_mts_zone.eff_dttm and t_mts_zone.exp_dttm
  /*left join (select * from edw_stg_dds.v_dim_services_xref_volga where to_date(exp_dttm, 'YYYY-MM-DD') = '2999-12-31') ss
    on
    (case when t_mts_sig.avt='y' then trunc(t_mts_zone.a_svc_id) else trunc(t_mts_zone.z_svc_id) end)  = ss.svc_id::numeric
*/
  left join edw_stg_dds.t_dim_service_xref_start xref
      on xref.source_key =  (case when t_mts_sig.avt='y' then trunc(t_mts_zone.a_svc_id) else trunc(t_mts_zone.z_svc_id) end)::text
      and to_date(substr('20190601', 1, 8), 'YYYYMMDD') + INTERVAL '1 MONTH - 1 second' between xref.eff_dttm and xref.exp_dttm
      and xref.region_id = 'VOLGA'
    left join edw_dds.dim_service et
      on et.service_key = xref.service_key
      and to_date(substr('20190601', 1, 8), 'YYYYMMDD') + INTERVAL '1 MONTH - 1 second' between et.eff_dttm and et.exp_dttm
    JOIN edw_dds.dim_business_service bs
      ON bs.business_service_key = et.business_service_key
        and to_date(substr('20190601', 1, 8), 'YYYYMMDD') + INTERVAL '1 MONTH - 1 second' between bs.eff_dttm and bs.exp_dttm

  left join edw_ods.t_000001_t_mts_svc_add t_mts_svc_add
    on
    trunc(t_mts_svc_add.billing_id) = trunc(t_mts_res.billing_id)
        --and t_mts_svc_add.tech_dt = to_date(trunc(t_mts_res.billing_id), 'YYYYMMDD')
    and trunc(t_mts_svc_add.mtr_id) = trunc(t_mts_res.mtr_id)
    and trunc(t_mts_svc_add.mts_tarif_type_id) not in (71490030,400000004372336,400000010520950,400000010550685)
  left join edw_ods.t_000001_t_users t_users
    on trunc(t_mts_res.user_id) = trunc(t_users.user_id)
    and to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second' + interval '6 days' between t_users.eff_dttm and t_users.exp_dttm


  JOIN edw_stg_dds.t_000001_dim_account dim_account
    ON
    t_mts_res.src_id||'#'||trunc(t_mts_res.user_id) = dim_account.account_key
    and t_mts_res.src_id = dim_account.src_id
    and to_date(trunc(t_mts_res.billing_id)::text,'YYYYMMDD') + INTERVAL '1 MONTH - 1 second' between dim_account.eff_dttm and dim_account.exp_dttm

  JOIN edw_stg_dds.t_000001_dim_partner dim_partner
    ON
    dim_account.partner_key = dim_partner.partner_key
    and dim_account.src_id = dim_partner.src_id
    and to_date(trunc(t_mts_res.billing_id)::text,'YYYYMMDD') + INTERVAL '1 MONTH - 1 second' between dim_partner.eff_dttm and dim_partner.exp_dttm

  LEFT JOIN edw_dds.hub_dim_segment hub_dim_segment
    ON
    hub_dim_segment.source_key = dim_partner.segment_key
    and hub_dim_segment.src_id = dim_partner.src_id
    and to_date(trunc(t_mts_res.billing_id)::text,'YYYYMMDD') + INTERVAL '1 MONTH - 1 second' between hub_dim_segment.eff_dttm and hub_dim_segment.exp_dttm

  LEFT JOIN edw_dds.dim_segment dim_segment
    ON
    dim_segment.segment_key = hub_dim_segment.segment_key
    and dim_segment.deleted_ind=0
    and to_date(trunc(t_mts_res.billing_id)::text,'YYYYMMDD') + INTERVAL '1 MONTH - 1 second' between dim_segment.eff_dttm and dim_segment.exp_dttm

  left join

  (
    select
      subs.serv_first_id
      , subs.subs_key
      , subs.start_date
      , subs.end_date
      , subs.account_key
    from edw_stg_dds.t_000001_dim_subs subs

  ) dim_subs

    on
    dim_subs.serv_first_id = trunc(t_mts_res.service_id)::text
    and t_mts_sig.talkdate between dim_subs.start_date and dim_subs.end_date

  left join
  (
    select --distinct
    subs.serv_first_id
    , subs.subs_key
    , row_number() over (order by subs.serv_first_id desc, subs.end_date desc, subs.subs_key desc) as numm

    from edw_stg_dds.t_000001_dim_subs subs

  ) dim_subs1

    on
    dim_subs1.serv_first_id = trunc(t_mts_res.service_id)::text
    and dim_subs1.numm = 1


  left join
  (
    select distinct
    subs.subs_key
    , bs.business_service_key
    , subs.start_date
    , subs.end_date
    , subs.account_key
    , t_services.dev_id

    from edw_stg_dds.t_000001_dim_subs subs
    left join edw_stg_dds.t_dim_service_xref_start xref
      on xref.source_key =    subs.service_key
      and to_date(substr('20190601', 1, 8), 'YYYYMMDD') + INTERVAL '1 MONTH - 1 second' between xref.eff_dttm and xref.exp_dttm
      and xref.region_id = 'VOLGA'
    left join edw_dds.dim_service et
      on et.service_key = xref.service_key
      and to_date(substr('20190601', 1, 8), 'YYYYMMDD') + INTERVAL '1 MONTH - 1 second' between et.eff_dttm and et.exp_dttm
    JOIN edw_dds.dim_business_service bs
      ON bs.business_service_key = et.business_service_key
        and to_date(substr('20190601', 1, 8), 'YYYYMMDD') + INTERVAL '1 MONTH - 1 second' between bs.eff_dttm and bs.exp_dttm



    inner join edw_ods.t_000001_t_services t_services
      on trunc(t_services.service_id)::text = subs.service_id
            and to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second' + interval '6 days'
                between t_services.eff_dttm and t_services.exp_dttm

  ) dim_subs2

    on
    t_mts_res.src_id||'#'||trunc(t_mts_res.user_id) = dim_subs2.account_key
    and case
      when bs.parent_business_service_key =  10100
        then 10101
        else bs.business_service_key
      end  = dim_subs2.business_service_key
    and t_mts_sig.talkdate between dim_subs2.start_date and dim_subs2.end_date
    and dim_subs2.dev_id::text = t_mts_sig.phonefrom
  left join edw_ods.t_000001_t_mts_block t_mts_block
    on 1=1
    and t_mts_block.block_id = t_mts_sig.block_id
    and to_date(substr('20190601', 1, 8), 'YYYYMMDD') + INTERVAL '1 MONTH - 1 second' between t_mts_block.eff_dttm and t_mts_block.exp_dttm
    and t_mts_block.deleted_ind = '0'
  where substr(t_mts_sig.codetown,1,2)!='80'
  and coalesce(t_mts_res.real_vndr_id,1) in (1,2199239,525862019,525919986,200,4375276,3528867,3816572,70409327,70409345,70410991,1001580737825,195304686,2462878)
  and trunc(t_mts_sig.billing_id) between substr('20190601', 1, 6)::int and substr('20190630', 1, 6)::int
    and t_mts_sig.tech_dt between to_date(substr('20190601', 1, 8), 'YYYYMMDD') and to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second'
  and (t_users.USER_TYPE_ID in ('1001135251970','1001135252173','320271653')
  or (decode(t_mts_sig.mts_svc_cod,'1',t_mts_zone.a_svc_id,t_mts_zone.z_svc_id) not in (3871019,22013586,1620861,44273782,10000000000000125975,3871035,22013587,44273783,10000000000000125517,22013588)
  and t_mts_svc_add.mts_tarif_type_id != 71490030))
)s2
where key1=1
;

analyze edw_stg_dds.t_000001_tfct_telephony_consumption;
