/*rev.46890 20.01.2020*/

truncate edw_stg_dds.t_000086_tfct_adjust;
insert into edw_stg_dds.t_000086_tfct_adjust
(
adjust_key
, adjust_type_key
, subs_key
, account_key
, service_key
, payment_key
, bill_detail_key
, contract_key
, vat_rub
, adjust_amt
, adjust_dttm
, corr_billing_id
, src_id
, load_dttm
, eff_dttm
, exp_dttm
, rc_key
, billing_dttm
)
with tsc as (
      select
          tsc.src_id
        , tsc.dt
        , tsc.corr_id
        , tsc.error_billing_id
        , tsc.billing_id
        , tsc.user_id
        , tsc.svc_corr_type
        , tsc.summ
        , tsc.tax
        , tsc.phone
        , tsc.service_id
        , tsc.svc_id
        , tsc.cdate
        , tsc.reason_id
        , dim_partner.segment_key
      from
      (
        select
            tsc.src_id
          , to_date(tsc.billing_id::text,'YYYYMMDD') + INTERVAL '1 MONTH - 1 second' as dt
          , tsc.corr_id
          , tsc.error_billing_id
          , tsc.billing_id
          , tsc.user_id
          , tsc.svc_corr_type
          , tsc.summ
          , tsc.tax
          , tsc.phone
          , tsc.service_id
          , tsc.svc_id
          , tsc.cdate
          , tsc.reason_id
        from edw_ods.t_000086_t_svc_correction tsc
        where tsc.billing_id <> coalesce(tsc.error_billing_id,to_char(tsc.cdate,'YYYYMM')::numeric, tsc.billing_id)
          and tsc.billing_id between substr('20190601', 1, 6)::int and substr('20190630', 1, 6)::int
          and tsc.tech_dt between to_date(substr('20190601', 1, 8), 'YYYYMMDD') and to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second'
      ) tsc
      JOIN edw_stg_dds.t_000086_dim_account dim_account ON
         tsc.src_id||'#'||trunc(tsc.user_id) = dim_account.account_key
        and tsc.src_id = dim_account.src_id
        and tsc.dt between dim_account.eff_dttm and dim_account.exp_dttm
      JOIN edw_stg_dds.t_000086_dim_partner dim_partner ON
        dim_account.partner_key = dim_partner.partner_key
        and dim_account.src_id = dim_partner.src_id
        and tsc.dt between dim_partner.eff_dttm and dim_partner.exp_dttm
  )
SELECT
s.adjust_key
, s.adjust_type_key
, s.subs_key
, src_id||'#'||s.account_key as account_key
, s.service_key
, -1 as payment_key
, s.bill_detail_key
, s.contract_key
, s.vat_rub
, s.adjust_amt
, s.adjust_dttm
, corr_billing_id
, src_id
, now() as load_dttm
, to_date('19000101', 'YYYYMMDD') as eff_dttm
, to_date('29991231', 'YYYYMMDD')  as exp_dttm
, rc_key
, s.billing_dttm

from
(
  select
  '1#'||tsc.corr_id as adjust_key
    , coalesce(tsc.error_billing_id,to_char(cast(cdate as date),'YYYYMM')::numeric, tsc.billing_id) as corr_billing_ID
    , cdate as adjust_dttm
    , tsc.user_id as account_key
    , null as payment_key
    , tsc.svc_id::text as service_key
    , coalesce('1'||'#'||tsc.reason_id,'1') as adjust_type_key
    , decode(tsc.svc_corr_type,'1',-1,'2',-1,1) * (tsc.summ - tsc.tax) as adjust_amt
  , decode(tsc.svc_corr_type,'1',-1,'2',-1,1) * tsc.tax as vat_rub
    , CASE
    WHEN ROW_NUMBER () OVER (PARTITION BY o_contract.user_id ORDER BY DECODE (t_sub_contract.vndr_contract_id, t_sub_contract.contract_id, 1, 2), t_sub_contract.vndr_contract_id) = 1
      THEN  o_contract.contract_id
      ELSE  t_sub_contract.vndr_contract_id
  END as contract_key
  , cpa_charge.charge_id as bill_detail_key
  , u.user_id||'#'||coalesce(tsc.phone,'0') as service_user_key
  , dim_subs.subs_key as subs_key
  , ROW_NUMBER() OVER (partition by tsc.corr_id order by  case
                                when (xref.sub_make=1
                                and tsc.service_id::text = dim_subs.service_id)
                                  then 1
                                when (xref.sub_make=0
                                and (tsc.phone=dim_subs.dev_id)
                                and et.technology_type_key=dim_subs.technology_type_key)
                                  then 2
                                when (xref.sub_make=0
                                and (tsc.phone=dim_subs.dev_id))
                                  then 3
                                when (xref.sub_make=0)
                                  then 4
                                  else 99999
                                      end asc
            )
  as key1
  , tsc.src_id as src_id
  , dim_segment.segment_name||'#'||xref.rcode_asr as rc_key
  , to_date(trunc(tsc.billing_id)::text,'yyyymm') billing_dttm

  from tsc

  LEFT JOIN edw_dds.hub_dim_segment hub_dim_segment
    ON
    hub_dim_segment.source_key = tsc.segment_key
    and hub_dim_segment.src_id = tsc.src_id
    and tsc.dt between hub_dim_segment.eff_dttm and hub_dim_segment.exp_dttm
  LEFT JOIN edw_dds.dim_segment dim_segment
    ON
    dim_segment.segment_key = hub_dim_segment.segment_key
    and dim_segment.deleted_ind=0
    and tsc.dt between dim_segment.eff_dttm and dim_segment.exp_dttm

  LEFT JOIN edw_ods.t_000086_t_users u
        on
    u.user_id = tsc.user_id
    and u.DELETED_IND <> 1
    and to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second' between u.eff_dttm and u.exp_dttm
  left join edw_stg_dds.t_dim_service_xref_start xref
      on xref.source_key =  tsc.svc_id::text
      and tsc.dt between xref.eff_dttm and xref.exp_dttm
      and xref.region_id = 'SIBIR'
  left join edw_dds.dim_service et
      on et.service_key = xref.service_key
      and tsc.dt between et.eff_dttm and et.exp_dttm
  left join edw_ods.t_000086_cpa_charge cpa_charge
    on
    cpa_charge.bid = tsc.billing_id
        and cpa_charge.user_id = tsc.user_id
        and cpa_charge.svc_id = tsc.svc_id
    and cpa_charge.tech_dt between to_date(substr('20190601', 1, 8), 'YYYYMMDD') and to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second'

  left join edw_ods.t_000086_o_contract  o_contract
    on
    o_contract.user_id = tsc.user_id
        and o_contract.DELETED_IND <> 1
    and to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second' between o_contract.eff_dttm and o_contract.exp_dttm
  left join edw_ods.t_000086_t_sub_contract t_sub_contract
    on
    t_sub_contract.contract_id = o_contract.contract_id
    and t_sub_contract.DELETED_IND <> 1
        and to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second' between t_sub_contract.eff_dttm and t_sub_contract.exp_dttm

  left join
  (
      select
    dim_subs.service_id
    , dim_subs.subs_key
    , dim_subs.account_key
    , dim_subs.subs_code as dev_id
    , dim_subs.start_date
    , dim_subs.end_date
    , et.business_service_key
    , et.technology_type_key
    from edw_stg_dds.t_000086_dim_subs dim_subs
    left join edw_stg_dds.t_dim_service_xref_start xref
      on xref.source_key =  dim_subs.service_key
      and to_date('20190601','YYYYMMDD') + INTERVAL '1 MONTH - 1 second' between xref.eff_dttm and xref.exp_dttm
      and xref.region_id = 'SIBIR'
    left join edw_dds.dim_service et
      on et.service_key = xref.service_key
      and to_date('20190601','YYYYMMDD') + INTERVAL '1 MONTH - 1 second' between et.eff_dttm and et.exp_dttm
  ) dim_subs
    on
    tsc.src_id||'#'||tsc.user_id = dim_subs.account_key
    and et.business_service_key = dim_subs.business_service_key
        and date_trunc('month',to_date(coalesce(tsc.error_billing_id,billing_id)::text,'YYYYMM')) between date_trunc('month',dim_subs.start_date) and date_trunc('month',dim_subs.end_date)
) s
where s.key1=1;
commit;
ANALYSE edw_stg_dds.t_000086_tfct_adjust;


/*t_pay_correction*/
/*Корректировки платежей*/
insert into edw_stg_dds.t_000086_tfct_adjust
      ( adjust_key
    , adjust_type_key
    , subs_key
    , account_key
    , service_key
    , payment_key
    , bill_detail_key
    , contract_key
    , vat_rub
    , adjust_amt
    , adjust_dttm
    , corr_billing_id
    , src_id
    , load_dttm
    , eff_dttm
    , exp_dttm
    , billing_dttm)
SELECT
    adjust_key
    , adjust_type_key
  , subs_key
  , src_id||'#'||account_key as account_key
  , service_key
  , payment_key
  , bill_detail_key
  , contract_key
  , vat_rub
  , adjust_amt
  , adjust_dttm
  , corr_billing_id
  , src_id
  , load_dttm
  , eff_dttm
  , exp_dttm
  , billing_dttm
  FROM(
SELECT    '2#'||t_pay_correction.pay_corr_id as adjust_key
    ,coalesce(t_pay_correction.error_billing_id,to_char(cast(pay_date as date),'YYYYMM')::numeric, t_pay_correction.billing_id)::numeric(38,0) as corr_billing_ID
    ,corr_date as adjust_dttm
      ,coalesce('2'||'#'||t_pay_correction.reason_id, '2') as adjust_type_key
      ,-1 as subs_key
      ,-1 as service_key
      ,t_pay_correction.user_id as account_key
      ,t_pay_correction.payment_id as payment_key
      ,-1 as bill_key
      ,-1 as bill_detail_key
      ,-1 as contract_key
      ,(decode(t_pay_correction. pay_corr_type,'1',-1,'2',-1,1)*t_pay_correction.summ)*(0.2/(1+0.2)) as vat_rub
      ,(decode(t_pay_correction. pay_corr_type,'1',-1,'2',-1,1)*t_pay_correction.summ)*(1/(1+0.2)) as adjust_amt
      ,000086 as src_id
      ,now() as load_dttm
    ,to_date('19000101', 'YYYYMMDD') as eff_dttm
    ,to_date('29991231', 'YYYYMMDD')  as exp_dttm
    ,to_date(trunc(t_pay_correction.billing_id)::text,'yyyymm') as billing_dttm
FROM  (select * from edw_ods.t_000086_t_pay_correction t_pay_correction
        where t_pay_correction.billing_id between substr('20190601', 1, 6)::int and substr('20190630', 1, 6)::int
      and tech_dt between  to_date('20190601',  'YYYYMMDD') and to_date('20190630', 'YYYYMMDD') + INTERVAL '1 day - 1 second'
      ) t_pay_correction
)sss
;
commit;
/*СТОРНО*/

set gp_recursive_cte_prototype = on;

insert into edw_stg_dds.t_000086_tfct_adjust( adjust_key, adjust_type_key, subs_key, account_key, service_key, payment_key, bill_detail_key, contract_key, vat_rub, adjust_amt, adjust_dttm, corr_billing_id, src_id, load_dttm, eff_dttm, exp_dttm, billing_dttm)
SELECT adjust_key, adjust_type_key, subs_key, src_id||'#'||account_key as account_key, service_key, payment_key, bill_detail_key, contract_key, vat_rub, adjust_amt, adjust_dttm, corr_billing_id, src_id, load_dttm, eff_dttm, exp_dttm, billing_dttm
FROM(
--------------------------------------
SELECT
 '3#'||charge_id                   as adjust_key -- Идентификатор корректировки
 ,to_char(to_date(adjusted_period_name, 'MM.YYYY'), 'YYYYMM')        as corr_billing_ID -- Идентификатор корректируемого периода
 ,to_date(period_name, 'mm.yyyy')               as adjust_dttm -- Дата создания корректировки
 ,svc_id                     as service_key -- Идентификатор услуги
 ,user_id                     as account_key -- Идентификатор лицевого счета
 ,tax                      as vat_rub -- Сумма НДС, руб.
 ,BASE_AMOUNT                    as adjust_amt -- Сумма корректировки в рублях, без НДС
 ,'3#10605'                    as adjust_type_key -- Идентификатор типа корректировки
 ,to_date(period_name, 'mm.yyyy')              as billing_dttm -- первый день биллингового периода
 ------------------
 ,-1                      as bill_key -- Идентификатор счета
 ,-1                      as bill_detail_key --Идентификатор Детали счета
 ,-1                      as contract_key -- Идентификатор договора
 ,-1                      as payment_key -- Идентификатор платежа
 ,-1                      as subs_key -- Идентификатор Абонента
 ---------------------
 ,000086                    as src_id -- 000086
 ,now()                      as load_dttm
 ,cast('1900-01-01 00:00:00' as timestamp(0) without time zone)        as eff_dttm
 ,cast('2999-12-31 00:00:00' as timestamp(0) without time zone)        as exp_dttm

FROM(
--------------------------------------
  select
  --ITEM_BDR,
  OPERATION_TYPE, -- for period_name
  BASE_AMOUNT,
  --COMMENTS,
  SERVICE_ACCOUNT,
  ADJUSTED_PERIOD_NAME,
  PERIOD_NAME,
  --BOOK_TYPE,
  --IS_ADJ_SHEET,
  SOURCE_SYSTEM,
  --SUPPLIER_TYPE,
  svc_id,
  user_id,
  charge_id,
  tax
 from(
 select
  --ITEM_BDR,
  OPERATION_TYPE,
  sum(BASE_AMOUNT) BASE_AMOUNT,
  --COMMENTS,
  SERVICE_ACCOUNT,
  ADJUSTED_PERIOD_NAME,
  PERIOD_NAME,
  --BOOK_TYPE,
  --decode(BOOK_TYPE,null,null,(case when (BOOK_TYPE='S' and ADJUSTED_PERIOD_NAME is not null) then 'Y' else 'N' end)) IS_ADJ_SHEET,
  SOURCE_SYSTEM,
  --SUPPLIER_TYPE,
  svc_id,
  user_id,
  charge_id,
  tax
 from(
 with
  svc as (select
      svc_id,
      name_svc,
      id_cell_svc,
      name_cell,
      account_svc,
      /*substr(item_svc||' ',1,instr(item_svc||' ',' ')-1) item_svc,*/
      substr(item_svc||' ',1,strpos(item_svc||' ',' ')-1) item_svc
      /*substr(item_svc_old||' ',1,instr(item_svc_old||' ',' ')-1) item_svc_old*/
     from(
     select svc.svc_id,
      svc.name name_svc,
      slc.id_cell_svc,
      slc.name name_cell,
      /*decode(substr(slc.name,1,1),'R','9001100000',nvl(substr(slc.name,1,instr(slc.name,'.')-1),substr(slc.name,1,instr(slc.name,' ')-1))) account_svc,*/
      decode(substr(slc.name,1,1),'R','9001100000',coalesce(substr(slc.name,1,
        case when strpos(slc.name,'.')-1 < 0
        then 0
        else strpos(slc.name,'.')-1
        end
      ),substr(slc.name,1,strpos(slc.name,' ')-1))) account_svc,
      replace(replace(REGEXP_MATCHES(slc.name, 'R\d{1,}', 'gmi')::text,'{',''),'}','') item_svc
      /*(select substr(substr(slc2.name,instr(slc2.name,'R'),instr(slc2.name,' ')-instr(slc2.name,'R')),1,regexp_instr(substr(slc2.name,instr(slc2.name,'R'),instr(slc2.name,' ')-instr(slc2.name,'R')),'(/|$)')-1)
       from t_svc_layer_bunch  slb2, t_svc_layer_cell  slc2
       where slb2.id_layer_svc=slc2.id_layer_svc
          and slb2.id_cell_svc=slc2.id_cell_svc
          and slc2.id_layer_svc=61
          and slb2.svc_id=svc.svc_id) item_svc_old*/
     from edw_ods.t_000086_t_svc_layer_bunch  slb, edw_ods.t_000086_t_svc_layer_cell  slc, edw_ods.t_000086_t_svc_ref  svc
     where slb.id_layer_svc=slc.id_layer_svc
        and slb.id_cell_svc=slc.id_cell_svc
        and slc.id_layer_svc=1
        and slb.svc_id=svc.svc_id
        and slc.id_cell_svc not in (95003)
        ---
        and to_date(20190601::varchar,'YYYYMMDD') + INTERVAL '1 day - 1 second' between slb.eff_dttm and slb.exp_dttm
        and to_date(20190601::varchar,'YYYYMMDD') + INTERVAL '1 day - 1 second' between slc.eff_dttm and slc.exp_dttm
        and to_date(20190601::varchar,'YYYYMMDD') + INTERVAL '1 day - 1 second' between svc.eff_dttm and svc.exp_dttm
        ---
        and slb.deleted_ind = 0
        and slc.deleted_ind = 0
        and svc.deleted_ind = 0
        ) as t_
     where item_svc like 'R040101103%'
        or item_svc like 'R040101104%'
        or item_svc like 'R040102103%'
        or item_svc like 'R040102104%'
        or item_svc like 'R04010302%'
        or item_svc in ('R07010102','R07010202','R07010602')
        ),
   ut as (select ut.user_type_id,
        ulc.cod cod_layer_ut,
        -- substr(ulc.name,instr(ulc.name,' ')+1) name_layer_ut,
        substr(ulc.name,strpos(ulc.name,' ')+1) name_layer_ut,
        ut.name name_ut,
        ulc.cell_id cell_id_ut,
        -- substr(ulc.name,1,instr(ulc.name,' ')-1) type_ut,
        substr(ulc.name,1,strpos(ulc.name,' ')-1) type_ut,
        decode(ulc.cell_id,1173,'Y','N') is_non_resident
    from edw_ods.t_000086_t_ut_layer_cell  ulc, edw_ods.t_000086_t_ut_layer_bunch  ulb, edw_ods.t_000086_t_user_type_ref  ut
    where ulc.cell_id=ulb.cell_id
       and ulc.layer_id=ulb.layer_id
       and ulb.layer_id=8
       and ulb.u_type_id=ut.user_type_id
       and ut.coef=1
       and ulc.cell_id=1170
       ---
       and to_date(20190601::varchar,'YYYYMMDD') + INTERVAL '1 day - 1 second' between ulc.eff_dttm and ulc.exp_dttm
       and to_date(20190601::varchar,'YYYYMMDD') + INTERVAL '1 day - 1 second' between ulb.eff_dttm and ulb.exp_dttm
       and to_date(20190601::varchar,'YYYYMMDD') + INTERVAL '1 day - 1 second' between ut.eff_dttm and ut.exp_dttm
       ---
       and ulc.deleted_ind = 0
       and ulb.deleted_ind = 0
       and ut.deleted_ind = 0
       ),
   dept as (
   with RECURSIVE r_gts as
             (
             select
                    tt.dept_id
                    , tt.dept_manages
                    , null::numeric as main_manages
                    , tt.code
                    , tt.src_id
                    , 1 as level
             from edw_ods.t_000086_t_gts as tt
             where to_date(20190601::varchar,'YYYYMMDD') between tt.eff_dttm and tt.exp_dttm
              and tt.code in ('060101','060299','060399','060499','060599','060699','060799','060899','060999','061099','061199','0620')
             union all
             select
             t.dept_id
             , t.dept_manages
             , r.dept_manages
             , r.code
             , r.src_id
             , r.level + 1
             from r_gts as r
                    inner join  edw_ods.t_000086_t_gts as t
                           on t.dept_manages = r.dept_id
                                 and t.src_id = r.src_id
                                 and to_date(20190601::varchar,'YYYYMMDD') between t.eff_dttm and t.exp_dttm
             )

             select
                    dept_id
                    , case when dept_id in (60313,60316,620,62005,62008,62010, 60321, 60323)
                           then dept_id
                           else coalesce(case when main_manages = 1 then null else main_manages end
                                                      , case when dept_manages = 1 then null else dept_manages end
                                                      , dept_id::numeric
                                               ) end as getdeptgrtu
        from r_gts
   ),
   debt as (select dc.curbid,
       dc.appbid,
       dc.user_id,
       dc.vnd_id,
       dc.cell_id_ut,
       dc.SUPPLIER_TYPE,
       dc.dept_id,
       dc.CONTRACTOR,
       dc.NON_RESIDENT,
       -- to_char(add_months(to_date(GREATEST(NVL((select max(p.bid) from cpa_payment  p where p.user_id=dc.user_id and p.payment_kind!='cc'),200601),dc.appbid),'yyyymm'),4),'yyyymm') bid_charge_begin,
       to_char(to_date(GREATEST(coalesce((select max(p.bid)::varchar from edw_ods.t_000086_cpa_payment  p where p.user_id=dc.user_id and p.payment_kind!='cc'),'200601'),dc.appbid::varchar),'yyyymm') + INTERVAL '4 MONTH','yyyymm') bid_charge_begin,
       dc.sum_debt
      from(
      select dc.curbid,
       dc.appbid,
       dc.user_id,
       dc.vnd_id,
       dc.cell_id_ut,
       dc.SUPPLIER_TYPE,
       dc.dept_id,
       dc.CONTRACTOR,
       dc.NON_RESIDENT,
       dc.sum_debt
      from(
      select dc.curbid,
       dc.user_id,
       dc.vnd_id,
       ut.cell_id_ut,
       ut.type_ut SUPPLIER_TYPE,
       sal.dept_id,
       ut.name_layer_ut CONTRACTOR,
       ut.is_non_resident NON_RESIDENT,
       min(decode(dc.appbid,0,200601,dc.appbid)) appbid,
       sum(dc.instdebt) sum_debt
      from edw_ods.t_000086_cpa_debt_cache  dc, edw_ods.t_000086_t_saldo  sal, ut
      where dc.curbid=substr('20190601', 1, 6)::INT
      and sal.billing_id=substr('20190601', 1, 6)::INT
      and sal.user_id=dc.user_id
      and sal.user_type_id=ut.user_type_id
      and dc.vnd_id in (1/*,2,21543469,21543483,4999999,5000008,5000009,6000070*/)
      ---
      and sal.deleted_ind = 0
      ---
      --and not exists(select 1 from edw_ods.t_000086_cpa_payment  cpap where cpap.user_id=dc.user_id and cpap.payment_kind!='cc' and cpap.bid between to_char(add_months(to_date(20190601,'yyyymm'),-3),'yyyymm') and 20190601)
      and not exists(select 1 from edw_ods.t_000086_cpa_payment  cpap where cpap.user_id=dc.user_id and cpap.payment_kind!='cc' and cpap.bid::varchar between to_char(to_date(substr('20190601', 1, 6),'YYYYMM') - INTERVAL '3 MONTH', 'YYYYMM') and 20190601::varchar)
      --and exists(select 1 from edw_ods.t_000086_t_users  u, edw_ods.t_000086_o_contract  c where u.user_id=dc.user_id and u.user_id=c.user_id and nvl(u.date_begin,c.datebegin)<add_months(to_date(20190601,'yyyymm'),-4))
      and exists(select 1 from edw_ods.t_000086_t_users  u, edw_ods.t_000086_o_contract  c where u.user_id=dc.user_id and u.user_id=c.user_id and coalesce(u.date_begin,c.datebegin)<to_date(substr('20190601', 1, 6),'YYYYMM') - INTERVAL '4 MONTH' and u.deleted_ind = 0 and to_date(20190601::varchar,'YYYYMMDD') + INTERVAL '1 day - 1 second' between u.eff_dttm and u.exp_dttm  and c.deleted_ind = 0 and to_date(20190601::varchar,'YYYYMMDD') + INTERVAL '1 day - 1 second' between c.eff_dttm and c.exp_dttm)
      group by dc.curbid, dc.user_id, dc.vnd_id, ut.cell_id_ut, ut.type_ut, sal.dept_id, ut.name_layer_ut, ut.is_non_resident
      ) dc
      -- where dc.appbid between 201702 and to_char(add_months(to_date(20190601,'yyyymm'),-1),'yyyymm')
      where dc.appbid::varchar between '201702' and to_char(to_date(substr('20190601', 1, 6),'YYYYMM') - INTERVAL '1 MONTH', 'YYYYMM')
      ) dc),
   charge as (select debt.curbid,
         c.vnd_id,
         c.bid,
         c.ebid,
         c.charge_kind,
         sum(c.total-c.tax) BASE_AMOUNT,
         c.tax_rate*100 tax_rate,
         sum(c.tax) VAT_AMOUNT,
         svc.id_cell_svc,
         svc.name_cell,
         svc.account_svc,
         svc.item_svc ITEM_BDR,
         svc.svc_id,
         debt.cell_id_ut,
         debt.SUPPLIER_TYPE,
         debt.dept_id,
         debt.CONTRACTOR,
         debt.NON_RESIDENT,
         debt.user_id,
         c.charge_id,
         c.tax
     from edw_ods.t_000086_cpa_charge  c, debt, svc
     where c.bid::varchar between debt.bid_charge_begin::varchar and debt.curbid::varchar
        and (c.charge_kind='ch'
          or (c.charge_kind='chc' and c.ebid::varchar>=debt.bid_charge_begin))
        and c.svc_id=svc.svc_id
        and c.user_id=debt.user_id
        and c.vnd_id=debt.vnd_id
        and c.total!=0
     group by debt.curbid, c.vnd_id, c.bid, c.ebid, c.charge_kind, c.tax_rate, svc.id_cell_svc, svc.name_cell, svc.account_svc, svc.item_svc, debt.cell_id_ut, debt.SUPPLIER_TYPE, debt.dept_id, debt.CONTRACTOR, debt.NON_RESIDENT, svc.svc_id, debt.user_id, c.charge_id, c.tax)

 select
  --sa.ITEM_BDR,
  sa.OPERATION_TYPE,
  (case when sa.OPERATION_TYPE in ('Начисление ДЗ тек пер','Начисление госпошлины, пени','Списание ДЗ по НДС тек пер','Списание ДЗ по НДС пред пер') then sa.BASE_AMOUNT else abs(sa.BASE_AMOUNT) end) BASE_AMOUNT,
  --sa.COMMENTS,
  (select coalesce(ri.param5,sa.account_svc) from edw_ods.t_000086_stc_rep_ish  ri
   where ri.rep_id='XXGL_CROSS_SERVICE_CHARGE' and ri.param1=sa.vnd_id::varchar and ri.param2=sa.OPERATION_TYPE::varchar and ri.param4=(case when sa.dept_id::varchar in ('620','62005','62008','62010') then '1' else '0' end) and (coalesce(ri.param3,'1')=coalesce(sa.ebid::varchar,'1') or (((sa.ebid::varchar not in ('201101','201102','201103') and ri.param4='0') or (sa.ebid::varchar not in ('201401','201402','201403') and ri.param4='1')) and ri.param3=substr(sa.ebid::varchar,1,4))) limit 1) SERVICE_ACCOUNT,
  sa.PERIOD_NAME,
  decode(sa.OPERATION_TYPE,'Начисление ДЗ отриц корр тек года',coalesce(sa.ADJUSTED_PERIOD_NAME,sa.PERIOD_NAME),sa.ADJUSTED_PERIOD_NAME) ADJUSTED_PERIOD_NAME,
  --(case when sa.OPERATION_TYPE in ('Начисление ДЗ отриц корр тек года','Начисление ДЗ отриц кор (НДС 6802)','Начисление ДЗ отриц корр тек пер без ТК без НДС','Начисление ДЗ отриц кор без ТК без НДС') then 'P'
  --   else 'S' end) BOOK_TYPE,
  (case when sa.dept_id in (620,62005,62008,62010) then 'RTM_SI_START' else 'SI_START' end) SOURCE_SYSTEM,
  --sa.SUPPLIER_TYPE,
  sa.svc_id,
  sa.user_id,
  sa.charge_id,
  sa.tax

 from(
 select
  --c.ITEM_BDR,
  (case when (c.charge_kind='ch') then 'Сторно неоплаченной выручки тек пер'
     when (c.charge_kind='chc' and substr(c.ebid::varchar,1,4)=substr(c.curbid::varchar,1,4) and c.BASE_AMOUNT>=0) then 'Сторно неоплаченной выручки тек пер'
     when (c.charge_kind='chc' and c.BASE_AMOUNT>=0) then 'Сторно неоплаченной выручки пред пер'
     when (c.charge_kind='chc' and substr(c.ebid::varchar,1,4)=substr(c.curbid::varchar,1,4) and c.BASE_AMOUNT<0) then 'Сторно отриц кор неопл выручки тек пер'
     --when (c.charge_kind='chc' and c.ebid=c.bid and c.BASE_AMOUNT<0) then 'Сторно отриц кор неопл выручки тек пер'
     else 'Сторно отриц кор неопл выручки пред пер' end) OPERATION_TYPE,
  c.BASE_AMOUNT,
  -- 'СТОРНО (' || (case when (c.charge_kind = 'ch') then 'НАЧИСЛЕНО'
        -- else (case when c.BASE_AMOUNT >= 0 then 'ДОНАЧИСЛЕНИЕ_' else 'СНЯТИЕ_' end)
       -- || decode(substr(c.ebid::varchar, 1, 4), substr(c.curbid::varchar, 1, 4), 'ТЕКУЩИЙ', substr(c.ebid::varchar, 1, 4))
       -- || (case when ((c.ebid between 201101 and 201103) and c.vnd_id not in (2, 5000009)) then '_1КВ'
          -- else decode(substr(c.ebid::varchar, 1, 4), substr(c.curbid::varchar, 1, 4), decode(c.ebid, c.curbid, '_МЕСЯЦ', '_ГОД'))
          -- end)
        -- end)
     -- || ')' COMMENTS,
  c.account_svc,
  c.vnd_id,
  (select dept.getdeptgrtu from dept where dept.dept_id=c.dept_id) dept_id,
  decode(c.ebid,c.bid,null,c.ebid) ebid,
  decode(c.ebid,c.curbid,null,to_char(to_date(c.ebid::varchar,'yyyymm'),'mm.yyyy')) ADJUSTED_PERIOD_NAME,
  to_char(to_date(c.curbid::varchar,'yyyymm'),'mm.yyyy') PERIOD_NAME,
  --c.SUPPLIER_TYPE,
  c.svc_id,
  c.user_id,
  c.charge_id,
  c.tax
 from charge c

 union all

 select
  --'Е912199' ITEM_BDR,
  (case when (c.charge_kind='ch') then 'Списание ДЗ по НДС тек пер'
     when (c.charge_kind='chc' and substr(c.ebid::varchar,1,4)=substr(c.curbid::varchar,1,4) and c.BASE_AMOUNT>=0) then 'Списание ДЗ по НДС тек пер'
     when (c.charge_kind='chc' and c.BASE_AMOUNT>=0) then 'Списание ДЗ по НДС пред пер'
     when (c.charge_kind='chc' and substr(c.ebid::varchar,1,4)=substr(c.curbid::varchar,1,4) and c.BASE_AMOUNT<0) then 'Списание ДЗ по НДС тек пер'
     else 'Списание ДЗ по НДС пред пер' end) OPERATION_TYPE,
  c.VAT_AMOUNT BASE_AMOUNT,
  -- 'СТОРНО НДС (' || (case when (c.charge_kind = 'ch') then 'НАЧИСЛЕНО'
        -- else (case when c.BASE_AMOUNT >= 0 then 'ДОНАЧИСЛЕНИЕ_' else 'СНЯТИЕ_' end)
       -- || decode(substr(c.ebid::varchar, 1, 4), substr(c.curbid::varchar, 1, 4), 'ТЕКУЩИЙ', substr(c.ebid::varchar, 1, 4))
       -- || (case when ((c.ebid between 201101 and 201103) and c.vnd_id not in (2, 5000009)) then '_1КВ'
          -- else decode(substr(c.ebid::varchar, 1, 4), substr(c.curbid::varchar, 1, 4), decode(c.ebid, c.curbid, '_МЕСЯЦ', '_ГОД'))
          -- end)
        -- end)
     -- || ')' COMMENTS,
  c.account_svc,
  c.vnd_id,
  (select dept.getdeptgrtu from dept where dept.dept_id=c.dept_id) dept_id,
  decode(c.ebid,c.bid,null,c.ebid) ebid,
  decode(c.ebid,c.curbid,null,to_char(to_date(c.ebid::varchar,'yyyymm'),'mm.yyyy')) ADJUSTED_PERIOD_NAME,
  to_char(to_date(c.curbid::varchar,'yyyymm'),'mm.yyyy') PERIOD_NAME,
  --c.SUPPLIER_TYPE,
  c.svc_id,
  c.user_id,
  c.charge_id,
  c.tax
 from charge c

 ) sa

 ) sa
 group by
  --ITEM_BDR,
  OPERATION_TYPE,
  --COMMENTS,
  SERVICE_ACCOUNT,
  ADJUSTED_PERIOD_NAME,
  PERIOD_NAME,
  --BOOK_TYPE,
  SOURCE_SYSTEM,
  --SUPPLIER_TYPE,
  svc_id,
  user_id,
  charge_id,
  tax
 ) as t
 where SOURCE_SYSTEM='SI_START'
 and SERVICE_ACCOUNT = '9001100010'
--------------------------------------
)tt
)t
;
set gp_recursive_cte_prototype = off;
ANALYSE edw_stg_dds.t_000086_tfct_adjust;
