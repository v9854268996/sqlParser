/*rev. 27676*/SET optimizer = ON;
SET search_path = edw_stg_dmcm;

TRUNCATE TABLE edw_stg_dmcm.pre_charges_wifi_stg_1_prt_p000152;

INSERT INTO edw_stg_dmcm.pre_charges_wifi_stg_1_prt_p000152
(
  period,
  mrf_id,
  rf_id,
  rf_id_src,
  inn,
  segment,
  ap_count,
  charge_wifi,
  charge_adv,
  charge_filtr,
  charge_lease,
  charge_sale,
  charge_design,
  charge_connect,
  src_id
)
SELECT
  chgd.period,
  coalesce(vdb.parent_branch_key, 0)                 AS mrf_id,
  coalesce(vdb1.branch_key, 0)                       AS rf_id,
  cast(coalesce(chgd.rf_id, '0') AS NUMERIC(10, 0))  AS rf_id_src, -- рф из начислений, было - из клиента
  coalesce(cl.inn, '')                               AS inn,
  dms.macro_segment                                  AS segment,
  coalesce(cli_ap.ap_count, 0)                       AS ap_count,
  sum(CASE
        WHEN chgd.charge_code IN('R07010208', 'R0701070303')
          THEN
            chgd.charge - chgd.vat_amount
        ELSE 0
      END)                                           AS charge_wifi,

  sum(CASE
        WHEN chgd.charge_code IN('R49190407', 'R491903')
          THEN
            chgd.charge - chgd.vat_amount
        ELSE 0
      END)                                           AS charge_adv,
  sum(CASE
        WHEN chgd.charge_code IN('R5113080202')
          THEN
            chgd.charge - chgd.vat_amount
        ELSE 0
      END)                                           AS charge_filtr,
  sum(CASE
        WHEN chgd.charge_code IN('R491808', 'R491801')
          THEN
            chgd.charge - chgd.vat_amount
        ELSE 0
      END)                                           AS charge_lease,
  sum(CASE
        WHEN chgd.charge_code IN('R49190109')
          THEN
            chgd.charge - chgd.vat_amount
        ELSE 0
      END)                                           AS charge_sale,
  sum(CASE
        WHEN chgd.charge_code IN('R5105')
          THEN
            chgd.charge - chgd.vat_amount
        ELSE 0
      END)                                           AS charge_design,
  sum(CASE
        WHEN chgd.charge_code IN('R0701070302', 'R07010207')
          THEN
            chgd.charge - chgd.vat_amount
        ELSE 0
      END)                                           AS charge_connect,
  chgd.src_id
  FROM edw_ods.t_000152_rprt_charges_dwh chgd
  JOIN edw_ods.t_000152_rprt_client_dwh cl
    ON chgd.cl_id = cl.cl_id
       AND chgd.mrf_id = cl.mrf_id
       AND coalesce(cl.data_close, '2999-12-31 00:00:00') >= (to_date('20190601', 'YYYYMMDD') + INTERVAL '1 month - 1 second')
  -- Определяем РФ через хаб
  LEFT JOIN edw_dds.hub_dim_branch vdb1
    ON chgd.rf_id :: text = vdb1.source_key
       AND vdb1.exp_dttm = '2999-12-31 00:00:00'
       AND vdb1.src_id = 158
  --Определяем МРФ по РФ
  LEFT JOIN edw_dds.dim_branch vdb
    ON vdb1.branch_key = vdb.branch_key
       AND vdb.exp_dttm = '2999-12-31 00:00:00'
       AND vdb.deleted_ind = 0
  -- Выбираем определенные сегменты клиентов
  JOIN edw_ods.t_000158_rprt_dird_macro_sgmnt dms
    ON cl.id_macro_segment_ud = dms.id_macro_segment
       AND dms.macro_segment NOT LIKE 'K04%' --  приведено в соответсвие с дашбордами по новым продуктам
  --рассчет ТД клиента
  LEFT JOIN
  (
    SELECT
      to_date('20190601', 'YYYYMMDD')                                  AS period,
      (to_date('20190601', 'YYYYMMDD') + INTERVAL '1 month - 1 day')   AS period_end,
      fldinn,
      rf_id,
      sum(ap_count) AS ap_count
      FROM --CLIENT_AP
      (
        SELECT
          tbl.cl_id,
          tbl.period,
          cli.fldinn,
          cli.fldfilialab,
          cli.fldrealaddressregion,
          tbl.rf_id,
          sum(ap_count_end) as ap_count
        FROM
        (
          SELECT
            period,
            lead(period, 1, period)
              OVER (PARTITION BY fldordernumber ORDER BY period) AS period_after,
            cl_id,
            fldordernumber,
            rf_id,
            ap_count_end
          FROM edw_stg_dmcm.pre_wifi_services_1_prt_p000152
          WHERE ap_count_end IS NOT NULL
        ) tbl
        JOIN
        (
          SELECT
            cli.fldinn,
            cli.fldfilialab,
            cli.flddocumentunid,
            cli.fldrealaddressregion,
            db.branch_key as rf_id,
            row_number()
              OVER (PARTITION BY cli.flddocumentunid ORDER BY cli.currentversion DESC) AS rn
          FROM edw_ods.t_000137_client cli
          LEFT JOIN edw_dds.hub_dim_region vdr
            ON upper(cli.fldrealaddressregion) = vdr.source_key
               AND vdr.exp_dttm = '2999-12-31 00:00:00'
               AND vdr.src_id = 137
          LEFT JOIN edw_dds.dim_region db
            ON db.region_key = vdr.region_key
            AND db.exp_dttm = '2999-12-31 00:00:00'
            AND db.deleted_ind = 0
          WHERE form = 'formOrganization'
        ) cli
          ON tbl.cl_id = cli.flddocumentunid
          AND cli.rf_id = tbl.rf_id
          AND cli.rn = 1
        WHERE tbl.period = to_date('20190601', 'YYYYMMDD') + INTERVAL '1 month - 1 day'
        GROUP BY 1, 2, 3, 4, 5, 6
      ) ca
      GROUP BY 1, 2, 3, 4
  ) cli_ap
  --РАСЧЕТ ТД клиентов
  ON cli_ap.fldinn = cl.inn
  AND vdb1.branch_key = cli_ap.rf_id
  AND cli_ap.period = chgd.period
WHERE chgd.period = to_date('20190601', 'YYYYMMDD')
  AND chgd.coef_r12 = 1
GROUP BY chgd.period,
   coalesce(vdb.parent_branch_key, 0),
   coalesce(vdb1.branch_key, 0),
   cast(coalesce(chgd.rf_id, '0') AS NUMERIC(10, 0)),
   coalesce(cl.inn, ''),
   dms.macro_segment,
   coalesce(cli_ap.ap_count, 0),
   chgd.src_id;

ANALYSE edw_stg_dmcm.pre_charges_wifi_stg_1_prt_p000152;
