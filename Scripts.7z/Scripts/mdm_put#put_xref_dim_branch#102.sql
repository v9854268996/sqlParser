/*rev.47734 от 29.01.2020*/
delete from edw_stg_mdm.put_xref_dim_branch
where src_id = 000102;

insert into edw_stg_mdm.put_xref_dim_branch
(
  source_key,
  oebs_branch_name,
  load_dttm,
  src_id,
  start_dttm,
  end_dttm,
  period_start_dttm,
  period_end_dttm
)
select
  b.brnc_id as SOURCE_KEY,
  b.code || ' # ' || b.name as BRANCH_NAME,
  now(),
  b.src_id,
  '1900-01-01 00:00:00'::date,
  '2999-12-31 00:00:00'::date,
  '1900-01-01 00:00:00'::date,
  '2999-12-31 00:00:00'::date
from edw_ods.t_000102_branches b;

analyze edw_stg_mdm.put_xref_dim_branch;
