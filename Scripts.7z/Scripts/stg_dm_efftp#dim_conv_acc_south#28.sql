/*rev. 44599 от 12.12.2019*/
truncate table edw_stg_dm_efftp.dim_conv_acc_south_1_prt_p000028;
commit;

insert into edw_stg_dm_efftp.dim_conv_acc_south_1_prt_p000028
  ( 
    tls_account    ,
    tls_id         ,
    tls_subacc_id  ,
    tls_serv_id    ,
    tls_device_num ,
    tls_date_begin ,
    tls_date_end   ,
    tls_serv_name  ,
    kls_account    ,
    kls_subacc_id  ,
    kls_serv_id    ,
    kls_device_num ,
    kls_date_begin ,
    kls_date_end   ,
    kls_serv_name  ,
    src_id
  )
select
  d.dfaccount                                                       ,
  coalesce(d.dfdogovor, 0)::numeric(38, 0)                          ,
  coalesce(els.dfdogovor_ref, 0)::numeric(38, 0)                    ,
  coalesce(sc.dfservconst, 0)::numeric(38, 0)                       ,
  sc.dfnumber                                                       ,
  sc.dfdatebegin                                                    ,
  sc.dfdateend                                                      ,
  s.dfnamerep                                                       ,
  to_char(coalesce(ad.dfnumber, 0)::numeric(38, 0), '999999999999') ,
  coalesce(sc2.dfdogovor, 0)::numeric(38, 0)                        ,
  coalesce(sc2.dfservconst, 0)::numeric(38, 0)                      ,
  sc2.dfnumber                                                      ,
  sc2.dfdatebegin                                                   ,
  sc2.dfdateend                                                     ,
  s2.dfnamerep                                                      ,
  d.src_id
from
  edw_ods.t_000028_tdogovor d
  join
    edw_ods.t_000028_tadddata ad
    on
      d.dfdogovor                                     = ad.dfid
      and ad.dfdatebegin                             <= to_date('20190630', 'yyyymmdd')
      and coalesce(ad.dfdateend, '2999-12-31'::date) >= to_date('20190601', 'yyyymmdd')
      and coalesce(ad.dfdelete, 'F')                  = 'F'
  join
    edw_ods.t_000028_taddtype adt
    on
      ad.dfaddtype    = adt.dfaddtype
      and adt.dftable = 'TDOGOVOR'
      and adt.dfname  = 'KONVERGENT_TLS'
  join
    edw_ods.t_000028_tels_dogovor_link els
    on
      d.dfdogovor                                      = els.dfels_dogovor
      and els.dfdatebegin                             <= to_date('20190630', 'yyyymmdd')
      and coalesce(els.dfdateend, '2999-12-31'::date) >= to_date('20190601', 'yyyymmdd')
  join
    edw_ods.t_000028_tservconst sc
    on
      els.dfdogovor_ref                               = sc.dfdogovor
      and sc.dfdatebegin                             <= to_date('20190630', 'yyyymmdd')
      and coalesce(sc.dfdateend, '2999-12-31'::date) >= to_date('20190601', 'yyyymmdd')
  join
    edw_ods.t_000028_tservice s
    on
      sc.dfservice = s.dfservice
  left join
    edw_ods.t_000028_tservconst sc2
    on
      sc.dfmovemaster = sc2.dfservconst
  left join
    edw_ods.t_000028_tservice s2
    on
      sc2.dfservice = s2.dfservice
where
  d.dfdogtype                 = 1234567
  and sc2.dfdogovor is not null
  and els.deleted_ind         = 0
;

analyze edw_stg_dm_efftp.dim_conv_acc_south_1_prt_p000028;