/*rev.34588 31.07.2019 Changed by: NAREK.ALAVERDYAN */
		--dim_partner
		truncate table edw_stg_ads.dim_partner_1_prt_p000120 ;
		insert into edw_stg_ads.dim_partner_1_prt_p000120 
		( partner_key,  parent_partner_key,  segment_key,  branch_key,  address_key,  partner_role_key,  benefit_category_key,
		  family_role_key,  gender_key,  level_of_doc_key,  master_account_key,  operator_license_key,  service_class_key,
		  type_of_affiliation_key,  city_key8born,  jur_key,  company_group_key,  tax_number_cval,  parent_tax_number_cval,
		  tax_reg_reason_cval,  partner_full_name,  parent_partner_full_name,  partner_alt_name,  doc_number_cval,
		  cust_home_ph_num_cval,  cust_work_ph_num_cval,  e_mail_cval,  contact_detail_cval,  birth_dt,
		  family_status,  occupation,  registration_dt,  credit_rating_dt,  foreign_partner_ind,  controlled_partner_ind,  rate_of_payment_discipline,
		  pns_limit,  credit_limit,  credit_rating,  start_date,  end_date, src_id, md5)
		select
		  dp.partner_key,  dp.parent_partner_key,  dp.segment_key,  dp.branch_key,  dp.address_key,  dp.partner_role_key,  dp.benefit_category_key,
		  dp.family_role_key,  dp.gender_key,  dp.level_of_doc_key,  dp.master_account_key,  dp.operator_license_key,  dp.service_class_key,
		  dp.type_of_affiliation_key,  dp.city_key8born,  dp.jur_key,  dp.company_group_key,  dp.tax_number_cval,  dp.parent_tax_number_cval,
		  dp.tax_reg_reason_cval,  dp.partner_full_name,  dp_par.partner_full_name as parent_partner_full_name,  dp.partner_alt_name,  dp.doc_number_cval,
		  dp.cust_home_ph_num_cval,  dp.cust_work_ph_num_cval,  dp.e_mail_cval,  dp.contact_detail_cval,  dp.birth_dt,
		  dp.family_status,  dp.occupation,  dp.registration_dt,  dp.credit_rating_dt,  dp.foreign_partner_ind,  dp.controlled_partner_ind,  dp.rate_of_payment_discipline,
		  dp.pns_limit,  dp.credit_limit,  dp.credit_rating,  dp.start_date,  dp.end_date,  dp.src_id,
		  md5(((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((coalesce(dp.partner_key::text, ''::text)) || chr(9)) || coalesce(dp.parent_partner_key::text, ''::text)) || chr(9)) || coalesce(dp.segment_key::text, ''::text)) || chr(9)) || coalesce(dp.branch_key::text, ''::text)) || chr(9)) || coalesce(dp.address_key::text, ''::text)) || chr(9)) || coalesce(dp.partner_role_key::text, ''::text)) || chr(9)) || coalesce(dp.benefit_category_key::text, ''::text)) || chr(9)) || coalesce(dp.family_role_key::text, ''::text)) || chr(9)) || coalesce(dp.gender_key::text, ''::text)) || chr(9)) || coalesce(dp.level_of_doc_key::text, ''::text)) || chr(9)) || coalesce(dp.master_account_key::text, ''::text)) || chr(9)) || coalesce(dp.operator_license_key::text, ''::text)) || chr(9)) || coalesce(dp.service_class_key::text, ''::text)) || chr(9)) || coalesce(dp.type_of_affiliation_key::text, ''::text)) || chr(9)) || coalesce(dp.city_key8born::text, ''::text)) || chr(9)) || coalesce(dp.jur_key::text, ''::text)) || chr(9)) || coalesce(dp.company_group_key::text, ''::text)) || chr(9)) ||  coalesce(dp.tax_number_cval::text, ''::text)) || chr(9)) || coalesce(dp.parent_tax_number_cval::text, ''::text)) || chr(9)) || coalesce(dp.tax_reg_reason_cval::text, ''::text)) || chr(9)) || coalesce(dp.partner_full_name::text, ''::text)) || chr(9)) || coalesce(dp_par.partner_full_name::text, ''::text)) || chr(9)) || coalesce(dp.partner_alt_name::text, ''::text)) || chr(9)) || coalesce(dp.doc_number_cval::text, ''::text)) || chr(9)) || coalesce(dp.cust_home_ph_num_cval::text, ''::text)) || chr(9)) || coalesce(dp.cust_work_ph_num_cval::text, ''::text)) || chr(9)) || coalesce(dp.e_mail_cval::text, ''::text)) || chr(9)) || coalesce(dp.contact_detail_cval::text, ''::text)) || chr(9)) || coalesce(dp.birth_dt::text, ''::text)) || chr(9)) || coalesce(dp.family_status::text, ''::text)) || chr(9)) || coalesce(dp.occupation::text, ''::text)) || chr(9)) || coalesce(dp.registration_dt::text, ''::text)) || chr(9)) || coalesce(dp.credit_rating_dt::text, ''::text)) || chr(9)) || coalesce(dp.foreign_partner_ind::text, ''::text)) || chr(9)) || coalesce(dp.controlled_partner_ind::text, ''::text)) || chr(9)) || coalesce(dp.rate_of_payment_discipline::text, ''::text)) || chr(9)) || coalesce(dp.pns_limit::text, ''::text)) || chr(9)) || coalesce(dp.credit_limit::text, ''::text)) || chr(9)) || coalesce(dp.credit_rating::text, ''::text)) || chr(9)) || coalesce(dp.start_date::text, ''::text)) || chr(9)) || coalesce(dp.end_date::text, ''::text)) || chr(9)) ) as md5
		from 
		 edw_dds.dim_partner_1_prt_p000120 dp
		left join edw_dds.dim_partner_1_prt_p000120 dp_par on
		 dp_par.partner_key = dp.parent_partner_key
		 and date_trunc('day', dp_par.exp_dttm) = to_date('29991231', 'yyyymmdd')
		where
		 date_trunc('day', dp.exp_dttm) = to_date('29991231', 'yyyymmdd')
		 and dp.src_id =000120 ; 

		ANALYZE edw_stg_ads.dim_partner_1_prt_p000120 ;
	