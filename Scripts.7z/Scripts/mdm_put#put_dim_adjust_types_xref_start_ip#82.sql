/*rev.10473 от 11.05.2018*/
delete from edw_stg_mdm.put_dim_adjust_types_xref_start where region_id = 'SIBIR' and src_id = 000082;

insert into edw_stg_mdm.put_dim_adjust_types_xref_start (ajtp_key,adjust_type_name,comment,region_id,src_id)
select
	case when IS_CHARGE = 1 then '1'||'#'||REASON_ID when IS_PAYMENT = 1 then '3'||'#'||REASON_ID else REASON_ID::text end as adjust_type_key ,
	NAME as adjust_type_name ,
	ANNOTATION as comments,
	'SIBIR' as region_id,
	src_id
	from edw_ods.t_000082_T_REASON_RECALCULATION 

commit;
analyse edw_stg_mdm.put_dim_adjust_types_xref_start;
