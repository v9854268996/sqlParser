/*rev.33056 от 11.07.2019*/
---set optimizer = on;
truncate table edw_stg_dm_ruz.pre_fct_ip_mpls_traffic_teoco_1_prt_p000157;
insert into edw_stg_dm_ruz.pre_fct_ip_mpls_traffic_teoco_1_prt_p000157
(
	period,
	client_name,
	in_traf,
	out_traf,
	total_traf,
	cms_order,
	cms_service,
	cms_cleint_inn,
	vrf,
	rt_import,
	cms_order_point2address,
	has_region_lastmile,
	business_service_ruz_key,
	segment_key,
	rc_key,
	business_segment_key,
	oebs_r12_branch_key,
	fldincomeitem,
	fldincomeitemnumber,
	fldincomeitemyear,
	source,
	ruz_src_id,
	src_id
)
WITH 
ordercms as (
		select
			fldordernumber,
			FLDINCOMEITEM,
			FLDINCOMEITEMNUMBER,
			FLDINCOMEITEMYEAR, 
			ROW_NUMBER() OVER( PARTITION BY fldordernumber   ORDER BY tech_dt desc) as rn
		from edw_ods.T_000137_ORDERCMS
		where 1=1
		and version=0
		and form='formOrder'
		and fldordernumber is not null
)

,mn as (
	select 
		f.rep_date,
		f.clnt_name as client_name,
		sum(f.in_traf) in_traf,
		sum(f.out_traf) out_traf,
		sum(f.total_traf) total_traf,
		f.cms_order,
		f.cms_service,
		f.cms_client_inn,
		f.vrf,
		f.cms_order_point2address,
		f.has_region_lastmile,
		case when  f.mrf_id = -1 and f.rf_id=-1 and (f.eqp_name  ~ '(klga|kstr|m10|m7-d|mrsk|mscw|msk-|rzan|gcu-%|krtv|nkrn|pvrv|ud_v)' or f.eqp_name  like 'orel%' ) then 11   
			 when  f.mrf_id in (1001, 100000, 100100, 100200, 100300) 		         then 11
			 when  f.mrf_id = -1 and f.rf_id=-1 and f.eqp_name  ~ '(spbr|vlmr|vnov)' then 12
			 when  f.mrf_id = -1 and f.rf_id=-1 and f.eqp_name  ~ '(kazn|kirv)'      then 13
			 when  f.mrf_id = -1 and f.rf_id=-1 and f.eqp_name  ~ '(sohi|vldk|vlkz)' then 14
			 when  f.mrf_id = -1 and f.rf_id in (1409, 14999) 				         then 14 		 
			 when  f.mrf_id = -1 and f.rf_id=-1 and f.eqp_name  ~ '(ebrg|perm)'      then 15
			 when  f.mrf_id = -1 and f.rf_id=-1 and (f.eqp_name  ~ '(grna|kyzl|nvsk|lnsk)' or f.eqp_name  like 'omsk%' or f.eqp_name like 'brnl%') then 16
		else f.mrf_id end  as mrf_id,
		f.cms_segment,
		f.CMS_ORG_LEVEL,
		f.cms_client_type,
		case when  f.mrf_id in (1001, 100000, 100100, 100200, 100300)  then cast ( substring (f.rf_id::text,1,4)  as numeric(4,0)) else f.rf_id end as rf_id,
		f.src_id,
		f.CMS_ORDER_SERVICE_TYPE,
		substring(f.rt_import, 1, 250) as rt_import
	from edw_ods.t_000158_ipmpls_traffic_dwh f
	where 1 = 1
	and f.rep_date = to_date('20190601','YYYYMMDD')
	and f.tech_dt = cast(to_date('20190601','YYYYMMDD') as timestamp(0))
	and 	
		--  13.02.2019 Хардкод для подтягивания бранчей (-1,1001, 100300, 100000, 100200, 100100, 1409, 14999
		case when  f.mrf_id = -1 and f.rf_id=-1 and (f.eqp_name  ~ '(klga|kstr|m10|m7-d|mrsk|mscw|msk-|rzan|gcu-%|krtv|nkrn|pvrv|ud_v)' or f.eqp_name  like 'orel%' ) then 11   
			 when  f.mrf_id in (1001, 100000, 100100, 100200, 100300) 		         then 11
			 when  f.mrf_id = -1 and f.rf_id=-1 and f.eqp_name  ~ '(spbr|vlmr|vnov)' then 12
			 when  f.mrf_id = -1 and f.rf_id=-1 and f.eqp_name  ~ '(kazn|kirv)'      then 13
			 when  f.mrf_id = -1 and f.rf_id=-1 and f.eqp_name  ~ '(sohi|vldk|vlkz)' then 14
			 when  f.mrf_id = -1 and f.rf_id in (1409, 14999) 				         then 14 		 
			 when  f.mrf_id = -1 and f.rf_id=-1 and f.eqp_name  ~ '(ebrg|perm)'      then 15
			 when  f.mrf_id = -1 and f.rf_id=-1 and (f.eqp_name  ~ '(grna|kyzl|nvsk|lnsk)' or f.eqp_name  like 'omsk%' or f.eqp_name like 'brnl%') then 16
		else f.mrf_id end   = case 
																	when 000157 = 151 then 11 
																	when 000157 = 152 then 12
																	when 000157 = 153 then 13
																	when 000157 = 154 then 14
																	when 000157 = 155 then 15
																	when 000157 = 156 then 16
																	when 000157 = 157 then 17
																end  
			
	and f.deleted_ind='0'
	/*Отсечение трафика по IPTV*/
	and ( 
			lower(f.vrf) not in ('vrf_v3560-backlan_iptv', 'vrf_v3560-backlan-iptv', 'vrf_tech-iptv-backlan', 'vrf_v3560-backlan_iptv_nrgr', 'vrf_ri-is-l3vpn-backlan_iptv', 'vrf_v3560-backlan_iptv_ykts'	) 
			or f.vrf is null
		)
	/*Отсечение технологического трафика по согласованию с Булгак Л.*/
	and (
			(lower (EQP_NAME) not like '%nat%' 
			and lower (EQP_NAME) not like '%saa%' ) 
			or EQP_NAME is null
		)
	and (
			lower(CMS_ORDER_SERVICE_TYPE) not like 'international link' 
			or CMS_ORDER_SERVICE_TYPE is null
		)
	and (
			cms_order is not null 
			or cms_service is not null			
		)
	and (
			lower(cms_ord_category) not like 'технологический' 
			or cms_ord_category is null
		)
	/*По согласованию с Яковлевой Е. добавлен хардкод на определение оператора по Телиа Кэрриер - он определяется отдельно в скрипте ниже - введно по причине того, что не согласован полный маппинг по Типу контрагента CMS*/
	/*Дополнительно требование от бизнеса убрать всех клиентов, которые имеют в названии Ростел*/
	and (
			( lower(clnt_name) not like '%телиа%'
			and lower(clnt_name) not like '%ростел%') 
			or clnt_name is null
		)
	and coalesce( UPPER(f.iface_type), '-1') =UPPER( 'Logical interface')
	group by 
		f.rep_date,
		f.clnt_name,
		f.cms_order,
		f.cms_service,
		f.cms_client_inn,
		f.vrf,
		f.cms_order_point2address,
		f.has_region_lastmile,
		f.mrf_id,
		f.cms_segment,
		f.CMS_ORG_LEVEL,
		f.cms_client_type,
		f.rf_id,
		f.src_id,
		f.CMS_ORDER_SERVICE_TYPE,
		f.eqp_name,
		substring(f.rt_import, 1, 250)
)
SELECT
	f.rep_date period,
	f.client_name,
	sum(f.in_traf) in_traf,
	sum(f.out_traf) out_traf,
	sum(f.total_traf) total_traf,
	f.cms_order,
	f.cms_service,
	f.cms_client_inn,
	f.vrf,
	f.rt_import,
	f.cms_order_point2address,
	f.has_region_lastmile,
	map_CMS_type.business_service_ruz_key,
	coalesce(h_s1.segment_key , h_s.segment_key) as segment_key,
	d_mr.rc_key,
	d_bs.business_segment_key,
	h_br.oebs_r12_branch_ruz_key,
	o_cms.FLDINCOMEITEM,
	o_cms.FLDINCOMEITEMNUMBER,
	o_cms.FLDINCOMEITEMYEAR,
	'TEOCO NETRAC' as source,
	000157 ruz_src_id,
	000157 src_id		
FROM mn f 
	left join /*подзапрос для определения записи с максимальной датой по услуге - формируется в виду того, что в ЕИП для одной версии есть несколько услуг*/
			(select 
			fldpoint2lmorgmethod , 
			fldservicenumber 
			from 
			(
				SELECT
				fldpoint2lmorgmethod,
				fldservicenumber,
				row_number() over (partition by fldservicenumber order by attribute_startdate desc, fldpoint2lmorgmethod ) rn
				FROM edw_ods.t_000137_serviceportcms s
				WHERE 1 = 1
				and s.version = 0
				and s.deleted_ind = '0'
				and s.deleted = '0'
				and fldservicenumber is not null
					) x where rn=1)  cs
	on ( 1 = 1
		and f.cms_service = cs.fldservicenumber
		)
	left join edw_dds.hub_dim_business_service_ruz    map_CMS_type
	on ( 1 = 1 
		and  map_CMS_type.src_id = 137 
		and  map_CMS_type.exp_dttm = cast(to_date('29991231','YYYYMMDD') as timestamp(0))
		and  UPPER(f.cms_order_service_type) || '#' like UPPER( split_part( source_key, '#', 1)  ) || '#%'  and 	 '#'  ||  coalesce(UPPER(cs.fldPoint2LMOrgMethod),'-1') like  '#' || coalesce(UPPER(split_part( source_key, '#', 2) ),'-1') || '%' 
		/*Выполнение условия, что если услуга относится к Интернет и тип последней мили = Y, то рассматривается тип технологии, иначе для Интернета все относится на прочее, а для остальных услуг соотнесение происходит по Типу услуги из CMS без учета технологии*/
		)
	--По согласованию с Яковлевой Е. часть соединения с СОО используется после того как определяются значения по маппингу
	left join 
	(	select 
		inn, id_macro_segment_ud
		from 
			(
			select inn, id_macro_segment_ud, 
				row_number() over (partition by inn order by date_snap desc, data_contr desc, cl_id desc) rn
			from edw_ods.t_000157_rprt_client_dwh s
			where 1 = 1
				and coalesce(data_close, to_date('20190601','YYYYMMDD')) >= to_date('20190601','YYYYMMDD')
				and s.deleted_ind = '0'
			) x 
			where x.rn=1
	) c  /*Соединение с клиентами СОО для определния Типа контрагента*/
	on ( 1 = 1 
		and f.cms_client_inn = c.inn 
	)
	left join edw_dds.hub_dim_segment h_s /*HUB Сегмента*/
	on ( 1 = 1
		and c.id_macro_segment_ud::text = h_s.source_key /*Проверка, что если ИНН из ТЕОКО определился в СОО, то берем значения по сегменту от туда, иначе забираем значения из ручного маппинга)*/
		and h_s.src_id = 158
		and to_date('20190601','YYYYMMDD') between h_s.eff_dttm and h_s.exp_dttm 
	)
	left join  edw_ods.t_000158_dir_map_segment_cms s_cms --ref_s_cms s_cms /*Маппинг Типов контрагентов CMS на Сегмент ЦХД - хардкод до реализации на ods*/
	on ( 1 = 1
		and coalesce(s_cms.org_segment,'~')  = coalesce(f.cms_segment,'~') 
		and coalesce(s_cms.org_level,'~')  = coalesce(f.CMS_ORG_LEVEL,'~')
		and coalesce(s_cms.org_type,'~')  = coalesce(f.cms_client_type,'~')
		and s_cms.deleted_ind = '0'
	)
	left join edw_dds.dim_segment h_s1 
	on ( 1 = 1
		and translate(trim (s_cms.k_code), 'АВСЕНКМОРТХасеоху', 'ABCEHKMOPTXaceoxy') = trim( h_s1.segment_name) 
		--and substring(s_cms.segment_name, '^(\\D\\d+)')  = trim(h_s1.segment_name)
		--and h_s1.segment_name||'%' like s_cms.segment_name
		and cast(to_date('20190601','YYYYMMDD') as timestamp(0)) between h_s1.eff_dttm and h_s1.exp_dttm 
		and h_s1.deleted_ind = '0'
	)
	left join edw_dds.dim_matrix_ruz_rc d_mr /*Коммерческая матрица для определения ЦФО*/
	on ( 1 = 1
		and d_mr.business_service_ruz_key = map_CMS_type.business_service_ruz_key
		and d_mr.segment_key  = coalesce(h_s1.segment_key , h_s.segment_key) --h_s1.segment_key --coalesce(h_s.segment_key , h_s1.segment_key)
		and to_date('20190601','YYYYMMDD') between d_mr.eff_dttm and d_mr.exp_dttm 
		and d_mr.deleted_ind = '0'
	)
	left join edw_dds.dim_rc d_c
	on ( 1 = 1
		and d_mr.rc_key = d_c.rc_key 
		and to_date('20190601','YYYYMMDD') between d_c.eff_dttm and d_c.exp_dttm
		and d_c.deleted_ind = '0'
	)
	left join edw_dds.dim_business_segment d_bs
	on ( 1 =1 
		and d_c.business_segment_key = d_bs.business_segment_key 
		and to_date('20190601','YYYYMMDD') between d_bs.eff_dttm and d_bs.exp_dttm
		and d_bs.deleted_ind = '0'
	)	
	left join edw_dds.hub_dim_oebs_r12_branch_ruz h_br /*HUB Орг структуры*/
	on ( 1 = 1
		and case when char_length(rf_id::text)> 5 then  substring(rf_id::text,1, 4) else rf_id::text end=  h_br.source_key
		and f.src_id = h_br.src_id
		and to_date('20190601','YYYYMMDD') between h_br.eff_dttm and h_br.exp_dttm 
	)
	left join ordercms  o_cms on o_cms.fldordernumber=f.cms_order and o_cms.rn=1
WHERE 1 = 1 
GROUP BY 
	f.rep_date,
	f.client_name,
	f.cms_order,
	f.cms_service,
	f.cms_client_inn,
	f.vrf,
	f.rt_import,
	f.cms_order_point2address,
	f.has_region_lastmile,
	map_CMS_type.business_service_ruz_key,
	coalesce(h_s1.segment_key , h_s.segment_key),
	d_mr.rc_key,
	d_bs.business_segment_key,
	h_br.oebs_r12_branch_ruz_key,
	o_cms.FLDINCOMEITEM,
	o_cms.FLDINCOMEITEMNUMBER,
	o_cms.FLDINCOMEITEMYEAR;
commit;
analyse edw_stg_dm_ruz.pre_fct_ip_mpls_traffic_teoco_1_prt_p000157;

insert into edw_stg_dm_ruz.pre_fct_ip_mpls_traffic_teoco_1_prt_p000157
(
	period,
	client_name,
	in_traf,
	out_traf,
	total_traf,
	cms_order,
	cms_service,
	cms_cleint_inn,
	vrf,
	rt_import,
	cms_order_point2address,
	has_region_lastmile,
	business_service_ruz_key,
	segment_key,
	rc_key,
	business_segment_key,
	oebs_r12_branch_key,
	fldincomeitem,
	fldincomeitemnumber,
	fldincomeitemyear,
	source,
	ruz_src_id,
	src_id
)
WITH 
ordercms as (
		select
			fldordernumber,
			FLDINCOMEITEM,
			FLDINCOMEITEMNUMBER,
			FLDINCOMEITEMYEAR, 
			ROW_NUMBER() OVER( PARTITION BY fldordernumber   ORDER BY tech_dt desc) as rn
		from edw_ods.T_000137_ORDERCMS
		where 1=1
		and version=0
		and form='formOrder'
		and fldordernumber is not null
)
,mn as (
	select 
		f.rep_date,
		f.clnt_name as client_name,
		sum(f.in_traf) in_traf,
		sum(f.out_traf) out_traf,
		sum(f.total_traf) total_traf,
		f.cms_order,
		f.cms_service,
		f.cms_client_inn,
		f.vrf,
		f.cms_order_point2address,
		f.has_region_lastmile,
		case when  f.mrf_id = -1 and f.rf_id=-1 and (f.eqp_name  ~ '(klga|kstr|m10|m7-d|mrsk|mscw|msk-|rzan|gcu-%|krtv|nkrn|pvrv|ud_v)' or f.eqp_name  like 'orel%' ) then 11   
			 when  f.mrf_id in (1001, 100000, 100100, 100200, 100300) 		         then 11
			 when  f.mrf_id = -1 and f.rf_id=-1 and f.eqp_name  ~ '(spbr|vlmr|vnov)' then 12
			 when  f.mrf_id = -1 and f.rf_id=-1 and f.eqp_name  ~ '(kazn|kirv)'      then 13
			 when  f.mrf_id = -1 and f.rf_id=-1 and f.eqp_name  ~ '(sohi|vldk|vlkz)' then 14
			 when  f.mrf_id = -1 and f.rf_id in (1409, 14999) 				         then 14 		 
			 when  f.mrf_id = -1 and f.rf_id=-1 and f.eqp_name  ~ '(ebrg|perm)'      then 15
			 when  f.mrf_id = -1 and f.rf_id=-1 and (f.eqp_name  ~ '(grna|kyzl|nvsk|lnsk)' or f.eqp_name  like 'omsk%' or f.eqp_name like 'brnl%') then 16
		else f.mrf_id end  as mrf_id  ,
		f.cms_segment,
		f.CMS_ORG_LEVEL,
		f.cms_client_type,
		case when   f.mrf_id in (1001, 100000, 100100, 100200, 100300)  then cast ( substring (f.rf_id::text,1,4)  as numeric(4,0)) else f.rf_id end as rf_id, -- 13.02.2019 Обрезаем rf_id для подтягивая бранча (100300->1003 и тд)
		f.src_id,
		f.CMS_ORDER_SERVICE_TYPE,
		substring(f.rt_import, 1, 250) as rt_import
	from edw_ods.t_000158_ipmpls_traffic_dwh f
	where 1 = 1
	and f.rep_date = to_date('20190601','YYYYMMDD')
	and f.tech_dt = cast(to_date('20190601','YYYYMMDD') as timestamp(0))
	and 		
		case when  f.mrf_id = -1 and f.rf_id=-1 and (f.eqp_name  ~ '(klga|kstr|m10|m7-d|mrsk|mscw|msk-|rzan|gcu-%|krtv|nkrn|pvrv|ud_v)' or f.eqp_name  like 'orel%' ) then 11   
			 when  f.mrf_id in (1001, 100000, 100100, 100200, 100300) 		         then 11
			 when  f.mrf_id = -1 and f.rf_id=-1 and f.eqp_name  ~ '(spbr|vlmr|vnov)' then 12
			 when  f.mrf_id = -1 and f.rf_id=-1 and f.eqp_name  ~ '(kazn|kirv)'      then 13
			 when  f.mrf_id = -1 and f.rf_id=-1 and f.eqp_name  ~ '(sohi|vldk|vlkz)' then 14
			 when  f.mrf_id = -1 and f.rf_id in (1409, 14999) 				         then 14 		 
			 when  f.mrf_id = -1 and f.rf_id=-1 and f.eqp_name  ~ '(ebrg|perm)'      then 15
			 when  f.mrf_id = -1 and f.rf_id=-1 and (f.eqp_name  ~ '(grna|kyzl|nvsk|lnsk)' or f.eqp_name  like 'omsk%' or f.eqp_name like 'brnl%') then 16
		else f.mrf_id end  = case 
																	when 000157 = 151 then 11 
																	when 000157 = 152 then 12
																	when 000157 = 153 then 13
																	when 000157 = 154 then 14
																	when 000157 = 155 then 15
																	when 000157 = 156 then 16
																	when 000157 = 157 then 17
																end
	/*Отсечение трафика по IPTV*/
	and ( lower(f.vrf) not in ('vrf_v3560-backlan_iptv', 'vrf_v3560-backlan-iptv', 'vrf_tech-iptv-backlan', 'vrf_v3560-backlan_iptv_nrgr', 'vrf_ri-is-l3vpn-backlan_iptv', 'vrf_v3560-backlan_iptv_ykts'	) 
		or f.vrf is null)
	/*Отсечение технологического трафика*/
	and ((lower (EQP_NAME) not like '%nat%' and lower (EQP_NAME) not like '%saa%' ) or EQP_NAME is null)
	and (lower(CMS_ORDER_SERVICE_TYPE) not like 'international link' or CMS_ORDER_SERVICE_TYPE is null)
	and (cms_order is not null or cms_service is not null)
	and (lower(cms_ord_category) not like 'технологический' or cms_ord_category is null)
	and lower(clnt_name) like '%телиа%'
	and coalesce( UPPER(f.iface_type), '-1') =UPPER( 'Logical interface')
	group by 
		f.rep_date,
		f.clnt_name,
		f.cms_order,
		f.cms_service,
		f.cms_client_inn,
		f.vrf,
		f.cms_order_point2address,
		f.has_region_lastmile,
		f.mrf_id,
		f.cms_segment,
		f.CMS_ORG_LEVEL,
		f.cms_client_type,
		f.rf_id,
		f.src_id,
		f.CMS_ORDER_SERVICE_TYPE,
		f.eqp_name,
		substring(f.rt_import, 1, 250) 
)
SELECT
	f.rep_date period,
	f.client_name,
	sum(f.in_traf) in_traf,
	sum(f.out_traf) out_traf,
	sum(f.total_traf) total_traf,
	f.cms_order,
	f.cms_service,
	f.cms_client_inn,
	f.vrf,
	f.rt_import,
	f.cms_order_point2address,
	f.has_region_lastmile,
	map_CMS_type.business_service_ruz_key,
	--coalesce(h_s.segment_key , h_s1.segment_key) 
	--h_s1.segment_key 
	--coalesce(h_s1.segment_key , h_s.segment_key)
	21302 segment_key,
	d_mr.rc_key,
	d_bs.business_segment_key,
	h_br.oebs_r12_branch_ruz_key,
	o_cms.fldincomeitem,
	o_cms.fldincomeitemnumber,
	o_cms.fldincomeitemyear,
	'TEOCO NETRAC' as source,
	000157 ruz_src_id,
	000157 src_id	
FROM mn f 
	left join /*подзапрос для определения записи с максимальной датой по услуге - формируется в виду того, что в ЕИП для одной версии есть несколько услуг*/
		(select 
		fldpoint2lmorgmethod , 
		fldservicenumber 
		from 
		(
			SELECT
			fldpoint2lmorgmethod,
			fldservicenumber,
			row_number() over (partition by fldservicenumber order by attribute_startdate desc, fldpoint2lmorgmethod ) rn
			FROM edw_ods.t_000137_serviceportcms s
			WHERE 1 = 1
			and s.version = 0
			and s.deleted_ind = '0'
			and s.deleted = '0'
			and fldservicenumber is not null
				) x where rn=1
	)  cs
	on ( 1 = 1
		and f.cms_service = cs.fldservicenumber
	)
	left join edw_dds.hub_dim_business_service_ruz    map_CMS_type
	on ( 1 = 1 
		and  map_CMS_type.src_id = 137
		and  map_CMS_type.exp_dttm = cast(to_date('29991231','YYYYMMDD') as timestamp(0))
		and  UPPER(f.cms_order_service_type) || '#' like UPPER( split_part( source_key, '#', 1)  ) || '#%'  and 	 '#'  ||  coalesce(UPPER(cs.fldPoint2LMOrgMethod),'-1') like  '#' || coalesce(UPPER(split_part( source_key, '#', 2) ),'-1') || '%' 
	/*Выполнение условия, что если услуга относится к Интернет и тип последней мили = Y, то рассматривается тип технологии, иначе для Интернета все относится на прочее, а для остальных услуг соотнесение происходит по Типу услуги из CMS без учета технологии*/
	)
	left join edw_dds.dim_matrix_ruz_rc d_mr /*Коммерческая матрица для определения ЦФО*/
	on ( 1 = 1
		and d_mr.business_service_ruz_key = map_CMS_type.business_service_ruz_key
		and d_mr.segment_key  = 21302
		and to_date('20190601','YYYYMMDD') between d_mr.eff_dttm and d_mr.exp_dttm   
		and d_mr.deleted_ind = '0'
	)
	left join edw_dds.dim_rc d_c
	on ( 1 = 1
		and d_mr.rc_key = d_c.rc_key 
		and to_date('20190601','YYYYMMDD') between d_c.eff_dttm and d_c.exp_dttm
		and d_c.deleted_ind = '0'
	)
	left join edw_dds.dim_business_segment d_bs
	on ( 1 =1 
		and d_c.business_segment_key = d_bs.business_segment_key 
		and to_date('20190601','YYYYMMDD') between d_bs.eff_dttm and d_bs.exp_dttm
		and d_bs.deleted_ind = '0'
	)
		
	left join edw_dds.hub_dim_oebs_r12_branch_ruz h_br /*HUB Орг структуры*/
	on ( 1 = 1
		and case when char_length(rf_id::text)> 5 then  substring (rf_id::text,1, 4) else rf_id::text end=  h_br.source_key 
		and f.src_id = h_br.src_id
		and to_date('20190601','YYYYMMDD') between h_br.eff_dttm and h_br.exp_dttm 
	)
	left join ordercms  o_cms on o_cms.fldordernumber=f.cms_order and o_cms.rn=1
WHERE 1 = 1 
GROUP BY 
	f.rep_date,
	f.client_name,
	f.cms_order,
	f.cms_service,
	f.cms_client_inn,
	f.vrf,
	f.rt_import,
	f.cms_order_point2address,
	f.has_region_lastmile,
	map_CMS_type.business_service_ruz_key,
	d_mr.rc_key,
	d_bs.business_segment_key,
	h_br.oebs_r12_branch_ruz_key,
	o_cms.fldincomeitem,
	o_cms.fldincomeitemnumber,
	o_cms.fldincomeitemyear;
commit;
analyse edw_stg_dm_ruz.pre_fct_ip_mpls_traffic_teoco_1_prt_p000157;