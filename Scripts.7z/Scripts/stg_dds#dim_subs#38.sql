/*rev.22691 18.02.2019*/
/*rev.22691 18.02.2019*/
select edw_stg_dds.f_dim_subs_stg_1_root_fill('000038');
select edw_stg_dds.f_dim_subs_stg_2_root_fill_next('000038');


truncate table edw_stg_dds.t_000038_dim_subs_stg_3_pre_mig;
truncate table edw_stg_dds.t_000038_dim_subs_stg_31_pre_mig_copy;
truncate table edw_stg_dds.t_000038_dim_subs_stg_4_pre_pair;
truncate table edw_stg_dds.t_000038_dim_subs_stg_5_pairs;
truncate table edw_stg_dds.t_000038_dim_subs_stg_6_end_chain;

insert into edw_stg_dds.t_000038_dim_subs_stg_3_pre_mig
  select subs_key, account_key, business_service_key, new_start_date,new_end_date,row_number() over(order by subs_key, account_key, business_service_key, new_start_date,new_end_date)
  from(

        select subs_key, account_key, business_service_key,new_start_date,new_end_date,act_date, con_date,
          row_number() over (partition by subs_key, account_key, business_service_key order by new_end_date desc) as rn
        from(

              select subs_key, account_key, business_service_key,
                min(TSERVCONST_dfdatebegin) over (partition by subs_key, account_key, business_service_key) as new_start_date,
                max(TSERVCONST_dfdateend)  over (partition by subs_key, account_key, business_service_key) as new_end_date,
                min(TSERVCONST_dfdatebegin) over (partition by subs_key, account_key) as act_date,
                max(TSERVCONST_dfdateend)  over (partition by subs_key, account_key) as con_date
              from(

                    select
                      tservconst.src_id||';'||root.dfservconst_root as subs_key,
                      tservconst.dfservconst::numeric(38) as dfservconst,
                      tservconst.src_id||';'||tservconst.dfservconst::numeric(38,0) as dfservconst,
                      tservconst.src_id||';'||TSERVCONST.DFDOGOVOR ::numeric(38,0) as account_key,
                      coalesce(date_trunc('day', TSERVCONST.dfdatebegin::timestamp),'1900-01-01'::date) as TSERVCONST_dfdatebegin,
                      coalesce(date_trunc('day', TSERVCONST.dfdateend::timestamp),'2999-12-31'::date) as TSERVCONST_dfdateend,
                      root.level,
                      et.business_service_key


                    from
                      edw_ods.t_000038_tservconst tservconst
                      inner join edw_stg_dds.t_000038_dim_subs_stg_1_root root on tservconst.dfservconst = root.dfservconst
           left join edw_dds.hub_dim_service hub
            on hub.src_id = tservconst.src_id   and hub.source_key =  tservconst.src_id || ';'||to_char(tservconst.dfservice,'fm999999999999999')
            and to_date('20190601', 'YYYYMMDD') + interval '1 month' - interval '1 second'  between hub.eff_dttm and hub.exp_dttm
          left join edw_dds.dim_service et
            on et.service_key = hub.service_key
            and to_date('20190601', 'YYYYMMDD') + interval '1 month' - interval '1 second'  between et.eff_dttm and et.exp_dttm
          left join edw_dds.dim_service_type est
            on et.service_type_key = est.service_type_key
            and to_date('20190601', 'YYYYMMDD') + interval '1 month' - interval '1 second'  between est.eff_dttm and est.exp_dttm
          left join edw_dds.dim_business_service bet
            on et.business_service_key = bet.business_service_key
            and to_date('20190601', 'YYYYMMDD') + interval '1 month' - interval '1 second'  between bet.eff_dttm and bet.exp_dttm
                    left join edw_ods.t_000038_tdogovor tdogovor on  tservconst.dfdogovor = tdogovor.dfdogovor and tdogovor.deleted_ind=0
                    WHERE  tservconst.dfservconstmaster is null
                           and (coalesce(tservconst.DFDELETE,'')<>'T') and (coalesce(tservconst.DFCONDITION,'')<>'T') and (coalesce(tservconst.DFCONDITION,'')<>'Т')
                           and tservconst.dfdatebegin is not null
                           and est.service_type_name = 'Основная'
                           --and bet.business_service_name not in ('ШПД','ШПД по беспроводным технологиям','ШПД в Интернет по проводным технологиям','IP-TV','IP VPN') -- 29.01.2020
               and bet.business_service_key not in (10200,10201,10202,10203,10204,10221,10231, 10401,10402,10403,10408,10500) -- 29.01.2020
                           and tservconst.deleted_ind=0
                           and tservconst.dfdevice not in
                               (      1102 , 111, --IPTV
                                      1001,        -- DSL
                                      1002, 1003,       -- ETTH
                                      191, 500,570, 1000000020 -- Технологические
                               )
                  )t
            )tt
      )ttt
  where rn=1  and con_date=new_end_date
        and date_part('day',new_end_date-new_start_date)>3;

analyze edw_stg_dds.t_000038_dim_subs_stg_3_pre_mig;

insert into edw_stg_dds.t_000038_dim_subs_stg_31_pre_mig_copy
  select * from edw_stg_dds.t_000038_dim_subs_stg_3_pre_mig;

analyze edw_stg_dds.t_000038_dim_subs_stg_31_pre_mig_copy;

select  edw_stg_dds.f_dim_subs_stg_3_get_pairs('000038','20161201');

analyze edw_stg_dds.t_000038_dim_subs_stg_4_pre_pair; --таблицы наполняются внутри процедур
analyze edw_stg_dds.t_000038_dim_subs_stg_5_pairs; --таблицы наполняются внутри процедур

select  edw_stg_dds.f_dim_subs_stg_4_get_chain('000038');

analyze edw_stg_dds.t_000038_dim_subs_stg_6_end_chain; --таблицы наполняются внутри процедур


truncate table edw_stg_dds.t_000038_dim_subs;
insert into edw_stg_dds.t_000038_dim_subs
(subs_key,
 service_id,
 subs_activation_dt,
 subs_cancellation_dt,
 service_key,
 account_key,
 src_id,
 start_date,
 end_date,
 EFF_DTTM,
 EXP_DTTM
)
  select
    h.subs_key,
    dfservconst as service_id,
    min(h.start_date) over(partition by h.subs_key)subs_activation_dt,
    max(h.end_date) over(partition by h.subs_key) + interval '1 day' - interval '1 sec' subs_cancellation_dt,
    h.service_key,
    h.account_key,
    h.src_id,
    h.start_date,
    h.end_date + interval '1 day' - interval '1 sec' as end_date,
    h.start_date as EFF_DTTM,
    h.end_date  + interval '1 day' - interval '1 sec' as EXP_DTTM

  from(
        select
          case when part = 0 then subs_key
          else max(new_subs_key) over (partition by subs_key, part)  end as subs_key
          , dfservconst, subs_activation_dt, subs_cancellation_dt, service_key,  account_key,src_id,start_date, end_date
        from (
               select *,
                 sum(
                     case
                     when
                       new_subs_key is not null then 1 else 0 end) over (partition by  subs_key order by start_date)  as part
               from
                 (
                   select*,
                     case when
                       (date_part('day',start_date - lag(end_date,1) over (partition by subs_key order by start_date) ) >30)
                       or ((lag(business_service_name) over (partition by subs_key order by start_date) <> business_service_name) and
                           (lag(business_service_name) over (partition by subs_key order by start_date) is not null))
                       then dfservconst end
                       as new_subs_key

                   from
                     (
                       select
                         *,
                         second_start_date as start_date,
                         coalesce(
                             case
                             when date_part('day',lead(second_start_date,1) over (partition by subs_key order by rn asc)- second_end_date) >30 then TSERVCONST_dfdateend
                             else
                               lead(second_start_date,1) over (partition by subs_key order by rn asc)-interval '1 day' end,subs_cancellation_dt) as end_date
                       from(
                             select *,
                               row_number () over (partition by subs_key order by level asc) as rn
                             from(
                                   select
                                     *
                                   from(
                                         select *,
                                           firt_start_date as second_start_date,
                                           coalesce(first_end_date,subs_cancellation_dt) as second_end_date
                                         from (
                                                select *,
                                                  TSERVCONST_dfdatebegin as firt_start_date,
                                                  case
                                                  when date_part('day',lead(TSERVCONST_dfdatebegin,1) over (partition by subs_key order by level asc)- TSERVCONST_dfdateend) >30 then TSERVCONST_dfdateend
                                                  else
                                                    min(TSERVCONST_dfdatebegin) over (partition by subs_key order by level asc range between 1 following and UNBOUNDED following ) -interval '1 day' end as first_end_date,
                                                  min(TSERVCONST_dfdatebegin) over (partition  by subs_key) as subs_activation_dt,
                                                  max(TSERVCONST_dfdateend) over (partition  by subs_key) as subs_cancellation_dt
                                                from(
                                                      select subs_key,dfservconst,account_key,service_key,address_key,TSERVCONST_dfdatebegin,TSERVCONST_dfdateend,
                                                        row_number() over (partition by subs_key order by lvlchain,lvlroot) as level,
                                                        service_type_name,business_service_name,service_name,src_id
                                                      from  (
                                                              select
                                                                coalesce(end_chain.sub_root,tservconst.src_id||';'||root.dfservconst_root) as subs_key,
                                                                tservconst.src_id||';'||tservconst.dfservconst::numeric(38,0) as dfservconst,
                                                                tservconst.src_id||';'||TSERVCONST.DFDOGOVOR ::numeric(38,0) as account_key,
                                                                tservconst.src_id||';'||TSERVCONST.DFSERVICE ::numeric(38,0) as service_key,
                                                                TSERVCONST.DFFULL_ADDRESS_STR as address_key,
                                                                coalesce(date_trunc('day', TSERVCONST.dfdatebegin::timestamp),'1900-01-01'::date) as TSERVCONST_dfdatebegin,
                                                                coalesce(date_trunc('day', TSERVCONST.dfdateend::timestamp),'2999-12-31'::date) as TSERVCONST_dfdateend,
                                                                root.level as lvlroot,
                                                                coalesce(end_chain.level,0) as lvlchain,
                                                                est.service_type_name,
                                                                bet.business_service_name,
                                                                et.service_name,
                                                                tservconst.src_id
                                                              from
                                                                edw_ods.t_000038_tservconst tservconst
                                                                inner join edw_stg_dds.t_000038_dim_subs_stg_1_root root on tservconst.dfservconst = root.dfservconst
                                                                left join edw_stg_dds.t_000038_dim_subs_stg_6_end_chain end_chain on tservconst.src_id||';'||root.dfservconst_root = end_chain.sub
                                  left join edw_dds.hub_dim_service hub
                                  on hub.src_id = tservconst.src_id   and hub.source_key =  tservconst.src_id || ';'|| to_char(tservconst.dfservice,'fm999999999999999')
                                  and to_date('20190601', 'YYYYMMDD') + interval '1 month' - interval '1 second'  between hub.eff_dttm and hub.exp_dttm
                                left join edw_dds.dim_service et
                                  on et.service_key = hub.service_key
                                  and to_date('20190601', 'YYYYMMDD') + interval '1 month' - interval '1 second'  between et.eff_dttm and et.exp_dttm
                                left join edw_dds.dim_service_type est
                                  on et.service_type_key = est.service_type_key
                                  and to_date('20190601', 'YYYYMMDD') + interval '1 month' - interval '1 second'  between est.eff_dttm and est.exp_dttm
                                left join edw_dds.dim_business_service bet
                                  on et.business_service_key = bet.business_service_key
                                  and to_date('20190601', 'YYYYMMDD') + interval '1 month' - interval '1 second'  between bet.eff_dttm and bet.exp_dttm
                                                                left join edw_ods.t_000038_tdogovor tdogovor on  tservconst.dfdogovor = tdogovor.dfdogovor and tdogovor.deleted_ind=0
                                                              WHERE  tservconst.dfservconstmaster is null
                                                                     and (coalesce(tservconst.DFDELETE,'')<>'T') and (coalesce(tservconst.DFCONDITION,'')<>'T') and (coalesce(tservconst.DFCONDITION,'')<>'Т')
                                                                     and tservconst.dfdatebegin is not null
                                                                     and est.service_type_name = 'Основная'
                                                                     --and bet.business_service_name not in ('ШПД','ШПД по беспроводным технологиям','ШПД в Интернет по проводным технологиям','IP-TV','IP VPN')-- 29.01.2020
                                    and bet.business_service_key not in (10200,10201,10202,10203,10204,10221,10231, 10401,10402,10403,10408,10500) -- 29.01.2020
                                                                     and (tservconst.src_id!=33 or tdogovor.dflinepartgroup!=1900003436)
                                                                     and tservconst.deleted_ind=0
                                                                     and tservconst.dfdevice not in
                                                                         (      1102 , 111, --IPTV
                                                                                1001,        -- DSL
                                                                                1002, 1003,       -- ETTH
                                                                                191, 500,570, 1000000020 -- Технологические
                                                                         )) abon
                                                    )dopabon
                                              )a
                                       )b
                                   where date_part('day',second_end_date - second_start_date)>=0
                                 )c
                           )d
                     )e
                 )f
             )g
      )h
    left join edw_ods.t_000038_tdogovor tdogovor on tdogovor.src_id||';'||tdogovor.dfdogovor::numeric(38)=h.account_key
    left join edw_stg_dds.t_kurs_group_filter_lts lts on lts.dflinepartgroup=tdogovor.dflinepartgroup
  -- where lts.exept=0;
  where coalesce(lts.exept,0)=0;
commit;
analyze edw_stg_dds.t_000038_dim_subs;
