/*rev.57809 от 15.05.2020 (Hot fix)*/
/*Волга Старт 1-12*/
truncate table edw_stg_mdm.put_xref_dim_sales_channel_1_prt_p000011;

insert into edw_stg_mdm.put_xref_dim_sales_channel_1_prt_p000011
(
    source_key,
    source_name,
    src_id
)
select distinct 
    case
      when sales_channel is null then '-2'
      else regexp_replace(trim(upper(sales_channel)),'[ ]+',' ','g')
    end as source_key,
    case
      when sales_channel is null then '-2'
      else regexp_replace(trim(upper(sales_channel)),'[ ]+',' ','g')
    end as source_name,
    000011 as src_id
from edw_ods.t_000011_mrf_antivir_connect;
commit;

analyze edw_stg_mdm.put_xref_dim_sales_channel_1_prt_p000011;
