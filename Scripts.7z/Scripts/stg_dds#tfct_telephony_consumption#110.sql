/*rev.58232 от 20.05.2020 */
truncate edw_stg_dds.t_000110_tfct_telephony_consumption;
insert into edw_stg_dds.t_000110_tfct_telephony_consumption
(
telephony_consumption_key
, call_start_dttm
, billing_id
, subs_key
, account_key
, service_key
, call_dur_actually_nval
, call_dur_paid_nval
, call_dur_rounded_nval
, src_id
, num_a
, num_b
, rc_key
, mobile_flg
, is_vims
)


select
telephony_consumption_key
, call_start_dttm
, billing_id
, subs_key
, src_id||'#'||account_key as account_key
, service_key
, call_dur_actually_nval
, call_dur_paid_nval
, call_dur_rounded_nval
, src_id
, num_a
, num_b
, rc_key
, mobile_flg
, is_vims
from
(
	/*t_apus*/
	select
	'1#'||t_apus.id_connect as telephony_consumption_key
	, t_apus.talkdate as call_start_dttm			-- Дата и время начала звонка
	, to_date(t_apus.billing_id::text,'YYYYMMDD') as billing_id			-- Биллинговый период
	, coalesce(dim_subs.subs_key ,dim_subs2.subs_key ,dim_subs1.subs_key) as subs_key				-- Идентификатор Абонента
	, t_apus.user_id as account_key				-- Идентификатор лицевого счета
	, ap.svc_id as service_key
	, t_apus.dlit as call_dur_actually_nval		-- Фактическая длительность звонка логическая
	, t_apus.tarif_dlit as call_dur_paid_nval	-- Фактическая протарифицированная длительность звонка логическая
	, t_apus.dlit as call_dur_rounded_nval 		-- Округленная Фактическая протарифицированная длительность звонка логическая
	, t_apus.src_id as src_id
	, t_apus.phonea as num_a  --Номер А
	, t_apus.phoneb as num_b  --Номер Б
	, case
		when ap.svc_id in ('110503','5441','106787','105129','105128','116326','116327','116328','116329','116330','116331','116332','4889','7311','5767','115686','115687','1620','4890','5979','5990','108310','109838','1954')
			then '1'||'#'||ap.svc_id
			else '2'||'#'||dim_partner.segment_key
	end as rc_key
	, case when t_apus.phoneb  like '79%' or  t_apus.phoneb like '89%' then 'Y' else 'N' end as mobile_flg
	, case when substring(lower(t_apus.additional_info),1,1) = 'v' then 'Y' else 'N' end is_vims
	, row_number() over (partition by t_apus.id_connect order by case when t_apus.src_id||'#'||t_apus.user_id = dim_subs.account_key then 1 else 99 end) as key1
	
	from edw_ods.t_000110_t_apus t_apus
	inner join
	(
		select
		ap.svc_id
		, ap.id_plan
		, xref.sub_make
		,case
		when bs.parent_business_service_key =  10100
			then 10101
			else bs.business_service_key
		end as business_service_key
		, xref.rcode_asr
		from  edw_ods.t_000110_t_apus_plan ap
		left join edw_stg_dds.t_dim_service_xref_start xref
			on xref.source_key = ap.svc_id::text
			and to_date('20190601','YYYYMMDD') + INTERVAL '1 MONTH - 1 second' between xref.eff_dttm and xref.exp_dttm
			and xref.region_id = 'DV'
		left join edw_dds.dim_service et
			on et.service_key = xref.service_key
			and to_date('20190601','YYYYMMDD') + INTERVAL '1 MONTH - 1 second' between et.eff_dttm and et.exp_dttm
		JOIN edw_dds.dim_business_service bs
			ON bs.business_service_key = et.business_service_key
				and to_date('20190601','YYYYMMDD') + INTERVAL '1 MONTH - 1 second' between bs.eff_dttm and bs.exp_dttm

		where ap.deleted_ind = 0
			and to_date('20190630', 'YYYYMMDD') + INTERVAL '1 day - 1 second'   between  ap.eff_dttm and ap.exp_dttm
	)ap
		on t_apus.plan_id = ap.id_plan
	inner JOIN edw_stg_dds.t_000110_dim_partner dim_partner
		ON 1=1
		and t_apus.user_id::text = dim_partner.partner_key
		and to_date(t_apus.billing_id::text,'YYYYMMDD') + INTERVAL '1 MONTH - 1 day' between dim_partner.eff_dttm and dim_partner.exp_dttm
	left join
	(
		select
		subs.serv_first_id
		, subs.subs_key
		, subs.start_date
		, subs.end_date
		, subs.account_key
		from  edw_stg_dds.t_000110_dim_subs subs
	) dim_subs
		on dim_subs.serv_first_id = t_apus.service_id::text
		and t_apus.talkdate between dim_subs.start_date and dim_subs.end_date
	left join
	(
		select distinct
		subs.serv_first_id
		, subs.subs_key
		, row_number() over (order by subs.serv_first_id desc, subs.end_date desc, subs.subs_key desc) as numm
		from edw_stg_dds.t_000110_dim_subs subs
	) dim_subs1
		on dim_subs1.serv_first_id = t_apus.service_id::text
		and dim_subs1.numm = 1
	left join
	(
		select distinct
		subs.subs_key
		, bs.business_service_key
		, subs.start_date
		, subs.end_date
		, subs.account_key
		, t_services.dev_id
		from  edw_stg_dds.t_000110_dim_subs subs
		left join edw_stg_dds.t_dim_service_xref_start xref
			on xref.source_key =  subs.service_key
			and to_date('20190601','YYYYMMDD') + INTERVAL '1 MONTH - 1 second' between xref.eff_dttm and xref.exp_dttm
			and xref.region_id = 'DV'
		left join edw_dds.dim_service et
			on et.service_key = xref.service_key
			and to_date('20190601','YYYYMMDD') + INTERVAL '1 MONTH - 1 second' between et.eff_dttm and et.exp_dttm
		JOIN edw_dds.dim_business_service bs
			ON bs.business_service_key = et.business_service_key
				and to_date('20190601','YYYYMMDD') + INTERVAL '1 MONTH - 1 second' between bs.eff_dttm and bs.exp_dttm
		inner join edw_ods.t_000110_t_services t_services
			on t_services.service_id::text = subs.service_id
			and t_services.deleted_ind = 0
			and to_date('20190630', 'YYYYMMDD') + INTERVAL '1 day - 1 second' + interval '7 days' between  t_services.eff_dttm and t_services.exp_dttm
	) dim_subs2
		on t_apus.src_id||'#'||t_apus.user_id = dim_subs2.account_key
		and case
			when ap.business_service_key =  10100     -- это условие выглядит лишним, так как мы уже провели эту операцию выше
				then 10101
				else ap.business_service_key
			end = dim_subs2.business_service_key
		and t_apus.talkdate between dim_subs2.start_date and dim_subs2.end_date
		and dim_subs2.dev_id::text = t_apus.phonea
	where 1=1
	and t_apus.tech_dt between to_date('20190601', 'YYYYMMDD') and to_date('20190630', 'YYYYMMDD') + INTERVAL '1 day - 1 second'
	and t_apus.billing_id between substr('20190601', 1, 6)::int and substr('20190630', 1, 6)::int
)s2
WHERE key1=1;

insert into edw_stg_dds.t_000110_tfct_telephony_consumption
(
telephony_consumption_key
, call_start_dttm
, billing_id
, subs_key
, account_key
, service_key
, call_dur_actually_nval
, call_dur_paid_nval
, call_dur_rounded_nval
, src_id
, num_a
, num_b
, rc_key
, mobile_flg
, is_vims
)
--Из предбиллинга в Старт не приходит привязка ВЗ трафика к VIMS. Выкручиваемся привязкой признака на основании таблицы местной связи: если номер был помечен, как VIMS, в расчетном месяце, то весь его ВЗ трафик помечаем, как VIMS
with apusVimsNums as (
	select phonea 
	from edw_ods.t_000110_t_apus t_apus
	where 1=1
		and substring(lower(t_apus.additional_info),1,1) = 'v' 
		and t_apus.tech_dt between to_date('20190601', 'YYYYMMDD') and to_date('20190630', 'YYYYMMDD') + INTERVAL '1 day - 1 second'
		and t_apus.billing_id between substr('20190601', 1, 6)::int and substr('20190630', 1, 6)::int
	group by phonea	
)
select
 telephony_consumption_key
 , call_start_dttm
 , billing_id
 , subs_key
 , src_id||'#'||account_key as account_key
 , service_key
 , call_dur_actually_nval
 , call_dur_paid_nval
 , call_dur_rounded_nval
 , src_id
 , num_a
 , num_b
 , rc_key
 , mobile_flg
 , is_vims
from
(
	/*t_mts_sig*/
	select
	'2#'||t_mts_sig.mtr_id as telephony_consumption_key -- Идентификатор потребления услуг телефонии
	, t_mts_sig.talkdate as call_start_dttm 			-- Дата и время начала звонка
	, to_date(t_mts_sig.billing_id::text,'YYYYMMDD') as billing_id 				-- Биллинговый период
	, coalesce(dim_subs.subs_key ,dim_subs2.subs_key ,dim_subs1.subs_key) as subs_key
	, t_mts_res.user_id as account_key				-- Идентификатор лицевого счета
	, case
		when t_mts_sig.avt='Y'
			then t_mts_zone.A_SVC_ID
			else t_mts_zone.Z_SVC_ID
	end as service_key 							-- Идентификатор услуги
	, (t_mts_sig.real_dlit * 60) as call_dur_actually_nval 	-- Фактическая длительность звонка логическая
	, case
		when lower(T_MTS_ZONE.NAME) like '%бесп%'
		and lower(T_MTS_ZONE.NAME) like '%800%'
			then 0
			else t_mts_res.dlit * 60
	end  as call_dur_paid_nval
	, (t_mts_res.dlit * 60) as call_dur_rounded_nval 		-- Округленная Фактическая протарифицированная длительность звонка логическая
	, t_mts_sig.src_id as src_id
	, t_mts_sig.phonefrom as num_a --Номер А
	, t_mts_sig.codetown||t_mts_sig.phoneto as num_b --Номер Б
	, case
		when xref.source_key in ('110503','5441','106787','105129','105128','116326','116327','116328','116329','116330','116331','116332','4889','7311','5767','115686','115687','1620','4890','5979','5990','108310','109838','1954')
			then '1'||'#'||xref.source_key
			else '2'||'#'||dim_partner.segment_key
	end as rc_key
	, case when t_mts_zone.is_mobile = 'Y'  or  t_mts_sig.codetown||t_mts_sig.phoneto like '79%' or  t_mts_sig.codetown||t_mts_sig.phoneto like '89%' then 'Y' else 'N' end as mobile_flg
	--, case when substring(lower(t_mts_sig.sved),1,4) = 'vims' then 'Y' else 'N' end is_vims
	, case when apusVimsNums.phonea is not null then 'Y' else 'N' end is_vims
	, case
		when coalesce(t_mts_res.real_vndr_id,1) in (1,2,18,20,21,22,23,25,26,27,28,29,43,44,45,46,47,48,49)
			then 1
			else 0
	end as VND
	, row_number() over (partition by t_mts_sig.mtr_id order by case when t_mts_res.src_id||'#'||t_mts_res.user_id = dim_subs.account_key  then 1 else 99 end) as key1
	from edw_ods.t_000110_t_mts_sig t_mts_sig
	inner join edw_ods.t_000110_t_mts_res t_mts_res
		on t_mts_sig.MTR_ID = t_mts_res.MTR_ID
		and t_mts_res.tech_dt between to_date('20190601', 'YYYYMMDD') and to_date('20190630', 'YYYYMMDD') + INTERVAL '1 day - 1 second'
		--and t_mts_res.deleted_ind = 0
	left join edw_ods.t_000110_t_mts_zone t_mts_zone
		on t_mts_zone.MTS_ZONE_ID = t_mts_res.MTS_ZONE_ID
		and t_mts_zone.deleted_ind = 0
		and to_date('20190630', 'YYYYMMDD') + INTERVAL '1 day - 1 second' + interval '7 days' between  t_mts_zone.eff_dttm and t_mts_zone.exp_dttm
	left join edw_stg_dds.t_dim_service_xref_start xref
			on xref.source_key = (case
				when t_mts_sig.avt='y'
					then t_mts_zone.a_svc_id
					else t_mts_zone.z_svc_id
				end)::text
			and to_date('20190601','YYYYMMDD') + INTERVAL '1 MONTH - 1 second' between xref.eff_dttm and xref.exp_dttm
			and xref.region_id = 'DV'
	left join edw_dds.dim_service et
		on et.service_key = xref.service_key
		and to_date('20190601','YYYYMMDD') + INTERVAL '1 MONTH - 1 second' between et.eff_dttm and et.exp_dttm
	JOIN edw_dds.dim_business_service bs
		ON bs.business_service_key = et.business_service_key
			and to_date('20190601','YYYYMMDD') + INTERVAL '1 MONTH - 1 second' between bs.eff_dttm and bs.exp_dttm

	inner JOIN edw_stg_dds.t_000110_dim_partner dim_partner
		ON 1=1
		and t_mts_res.user_id::text = dim_partner.partner_key
		and to_date(t_mts_sig.billing_id::text,'YYYYMMDD') + INTERVAL '1 MONTH - 1 day' between dim_partner.eff_dttm and dim_partner.exp_dttm
	left join

	(
		select
		subs.serv_first_id
		, subs.subs_key
		, subs.start_date
		, subs.end_date
		, subs.account_key
		from edw_stg_dds.t_000110_dim_subs subs
	) dim_subs
		on
		dim_subs.serv_first_id = t_mts_res.service_id::text
		and t_mts_sig.talkdate between dim_subs.start_date and dim_subs.end_date
	left join
	(
		select
		subs.serv_first_id
		, subs.subs_key
		, row_number() over (order by subs.serv_first_id desc, subs.end_date desc, subs.subs_key desc) as numm
		from edw_stg_dds.t_000110_dim_subs subs
	) dim_subs1
		on
		dim_subs1.serv_first_id = t_mts_res.service_id::text
		and dim_subs1.numm = 1
	left join
	(
		select distinct
		subs.subs_key
		, bs.business_service_key
		, subs.start_date
		, subs.end_date
		, subs.account_key
		, t_services.dev_id
		from edw_stg_dds.t_000110_dim_subs subs
		left join edw_stg_dds.t_dim_service_xref_start xref
			on xref.source_key =  subs.service_key
			and to_date('20190601','YYYYMMDD') + INTERVAL '1 MONTH - 1 second' between xref.eff_dttm and xref.exp_dttm
			and xref.region_id = 'DV'
		left join edw_dds.dim_service et
			on et.service_key = xref.service_key
			and to_date('20190601','YYYYMMDD') + INTERVAL '1 MONTH - 1 second' between et.eff_dttm and et.exp_dttm
		JOIN edw_dds.dim_business_service bs
			ON bs.business_service_key = et.business_service_key
				and to_date('20190601','YYYYMMDD') + INTERVAL '1 MONTH - 1 second' between bs.eff_dttm and bs.exp_dttm
	inner join edw_ods.t_000110_t_services t_services 
			on t_services.service_id::text = subs.service_id
			and t_services.deleted_ind = 0
			and to_date('20190630', 'YYYYMMDD') + INTERVAL '1 day - 1 second' + interval '7 days'   between  t_services.eff_dttm and t_services.exp_dttm

	) dim_subs2
		on t_mts_res.src_id||'#'||t_mts_res.user_id = dim_subs2.account_key
		and case
			when bs.parent_business_service_key =  10100
				then 10101
				else bs.business_service_key
			end = dim_subs2.business_service_key
		and t_mts_sig.talkdate between dim_subs2.start_date and dim_subs2.end_date
		and dim_subs2.dev_id::text = t_mts_sig.phonefrom
	left join apusVimsNums
		on 1=1
		and t_mts_sig.phonefrom = apusVimsNums.phonea
	where 1=1
	--and t_mts_sig.deleted_ind = 0
	and t_mts_sig.tech_dt between to_date('20190601', 'YYYYMMDD') and to_date('20190630', 'YYYYMMDD') + INTERVAL '1 day - 1 second'
	and coalesce(t_mts_res.real_vndr_id,1) in (1,2,18,20,21,22,23,25,26,27,28,29,43,44,45,46,47,48,49)
	and t_mts_sig.billing_id between substr('20190601', 1, 6)::int and substr('20190630', 1, 6)::int
)s2
WHERE key1=1;

commit;
analyze edw_stg_dds.t_000110_tfct_telephony_consumption;