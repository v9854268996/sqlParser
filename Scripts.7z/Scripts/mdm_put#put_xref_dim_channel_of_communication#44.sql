/*rev.54582 от 10.04.2020*/

delete from edw_stg_mdm.put_xref_dim_channel_of_communication
where src_id = 000044;
commit;

insert into edw_stg_mdm.put_xref_dim_channel_of_communication
(
    SOURCE_KEY,
    SOURCE_NAME,
    SRC_ID
)
select
    t1.direction || '#' || t1.type as source_key
    ,decode(t1.direction, 1, 'Входящее', 2, 'Исходящее') || '#' || t1.type as source_name
    ,000044 as src_id
from (
        select
            coalesce(t_000044_table_intrxn.direction, 0) as direction
            ,upper(coalesce(t_000044_table_intrxn.type, 'NULL')) as type
            ,count(*) as ct
        FROM edw_ods.t_000044_table_intrxn
        group by
            coalesce(t_000044_table_intrxn.direction, 0)
            ,upper(coalesce(t_000044_table_intrxn.type, 'NULL'))
) as t1
order by 1;
commit;

analyze edw_stg_mdm.put_xref_dim_channel_of_communication;
