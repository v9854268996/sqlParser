/*rev.46170 10.01.2020 Changed by: YURIY.KLYUEV */

truncate edw_stg_dds.t_000009_tfct_adjust;
insert into edw_stg_dds.t_000009_tfct_adjust
(
    adjust_key
    , adjust_type_key
    , subs_key
    , account_key
    , service_key
    , payment_key
    , bill_detail_key
    , contract_key
    , vat_rub
    , adjust_amt
    , adjust_dttm
    , corr_billing_id
    , src_id
    , load_dttm
    , eff_dttm
    , exp_dttm
    , rc_key
    , billing_dttm
)
with
  tsc as
(
  select
    tsc.*,
    round(tsc.svc_id)::varchar svc_id_,
    tsc.service_id::varchar service_id_var,
    round(tsc.user_id) account_key,
    tsc.src_id||'#'||trunc(tsc.user_id) src_id_user_id,
    coalesce(round(tsc.error_billing_id), to_char(tsc.cdate,'YYYYMM')::numeric, round(tsc.billing_id) ) as corr_billing_ID,
    to_date(coalesce(round(tsc.error_billing_id), round(tsc.billing_id))::varchar,'YYYYMM')billing_id_,
    to_date(trunc(tsc.billing_id)::varchar,'YYYYMMDD') + INTERVAL '1 MONTH - 1 second' DATE_,
    decode(tsc.svc_corr_type::int,1,-1,2,-1,1) * (tsc.summ - tsc.tax) as adjust_amt, -- Сумма корректировки в рублях, без НДС
    decode(tsc.svc_corr_type::int,1,-1,2,-1,1) * tsc.tax as vat_rub,  -- Сумма НДС, руб.
    case when coalesce(tsc.vnd_id,1) in (1,2199239,525862019,525919986,200,4375276,3528867,3816572,70409327,70409345,70410991,1001580737825,195304686,2462878) then 1 else 0 end as vnd,
    tsc.cdate as adjust_dttm, -- Дата создания корректировки
    '1#'||round(tsc.corr_id) as adjust_key, -- Идентификатор корректировки
    coalesce('1'||'#'||round(tsc.reason_id),'1') as adjust_type_key -- Идентификатор типа корректировки
  from
    edw_ods.t_000009_t_svc_correction tsc
    WHERE 1=1
      and round(tsc.billing_id) <> coalesce(round(tsc.error_billing_id), to_char(cdate,'YYYYMM')::numeric, round(tsc.billing_id) )
      and round(tsc.billing_id) between substr('20190601', 1, 6)::int and substr('20190630', 1, 6)::int
      and tsc.tech_dt between to_date(substr('20190601', 1, 8), 'YYYYMMDD') and to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second'
),
  cpa_charge as
(
  select
    cc.*,
    round(cc.charge_id) as bill_detail_key
  from
    (
    select
      cpa_charge.bid,
      cpa_charge.user_id,
      cpa_charge.svc_id,
      min(cpa_charge.charge_id) charge_id
    from
      edw_ods.t_000009_cpa_charge cpa_charge
      WHERE 1 = 1
        and cpa_charge.tech_dt between to_date(substr('20190601', 1, 8), 'YYYYMMDD') and to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second' -- because cpa_charge.bid = tsc.billing_id
     group by
      cpa_charge.bid,
      cpa_charge.user_id,
      cpa_charge.svc_id
    )cc
),
  users as
(
  select
    u.*
  from
    edw_ods.t_000009_t_users u
    WHERE 1 = 1
      and u.DELETED_IND <> 1
      and to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second'  + interval '6 days' between u.eff_dttm and u.exp_dttm
),
  xref as
(
  select
    x.*
  from
    edw_stg_dds.t_dim_service_xref_start x
    WHERE 1 = 1
      and to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second' between x.eff_dttm and x.exp_dttm
      and x.region_id = 'VOLGA'
),
  service as
(
  select
    s.*
  from
    edw_dds.dim_service s
    WHERE 1 = 1
      and to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second' between s.eff_dttm and s.exp_dttm
),
  o_contract as
(
  select
    oc.*
  from
    edw_ods.t_000009_o_contract oc
    WHERE 1 = 1
      and oc.DELETED_IND <> 1
      and to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second' between oc.eff_dttm and oc.exp_dttm
),
  t_sub_contract as
(
  select
    sc.*
  from
    edw_ods.t_000009_t_sub_contract sc
    WHERE 1 = 1
      and sc.DELETED_IND <> 1
      and to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second' between sc.eff_dttm and sc.exp_dttm
),
  dim_subs as
(
  select
    ds.service_id,
    ds.subs_key,
    ds.account_key,
    ds.subs_code as dev_id,
    ds.start_date,
    ds.end_date,
    date_trunc('month',ds.start_date)month_id_begin,
    date_trunc('month',ds.end_date)month_id_end,
    et.business_service_key,
    et.technology_type_key
  from
    edw_stg_dds.t_000009_dim_subs ds
    left join xref x
      on 1 = 1
      and x.source_key = ds.service_key
    left join service et
      on 1 = 1
      and et.service_key = x.service_key
)
select
  adjust_key
  , adjust_type_key
  , subs_key
  , src_id||'#'||account_key as account_key
  , service_key
  , payment_key
  , bill_detail_key
  , contract_key
  , vat_rub
  , adjust_amt
  , adjust_dttm
  , corr_billing_id
  , src_id
  , now() as load_dttm
  , cast('19000101' as timestamp(0) without time zone) as eff_dttm
  , cast('29991231' as timestamp(0) without time zone) as exp_dttm
  , rc_key
  , billing_dttm
FROM
  (
  select
    tsc.adjust_key
    , tsc.corr_billing_ID
    , tsc.adjust_dttm
    , tsc.account_key
    , tsc.svc_id_ as service_key
    , -1 as payment_key
    , CAST(tsc.billing_id as varchar) ||'#'|| LPAD (TRIM (u.account), 12, '0') as bill_ke
    , tsc.adjust_type_key
    , tsc.adjust_amt
    , tsc.vat_rub
    , CASE
      WHEN ROW_NUMBER () OVER (PARTITION BY o_contract.user_id ORDER BY DECODE (t_sub_contract.vndr_contract_id, t_sub_contract.contract_id, 1, 2), t_sub_contract.vndr_contract_id) = 1
        THEN round(o_contract.contract_id)
        ELSE round(t_sub_contract.vndr_contract_id)
    END as contract_key
    , cpa_charge.bill_detail_key
    , u.user_id||'#'||coalesce(tsc.phone,'0') as service_user_key
    , dim_subs.subs_key as subs_key
    , ROW_NUMBER() OVER (partition by tsc.corr_id order by
        case
          when (x.sub_make = 1 and tsc.service_id_var = dim_subs.service_id)then 1
          when (x.sub_make = 0 and tsc.phone = dim_subs.dev_id and et.technology_type_key = dim_subs.technology_type_key) then 2
          when (x.sub_make = 0 and tsc.phone = dim_subs.dev_id) then 3
          when (x.sub_make = 0)then 4
          else 99999
        end asc)
    as key1
    , tsc.src_id as src_id
    , tsc.vnd
    , dim_segment.segment_name||'#'||x.rcode_asr as rc_key
    , to_date(trunc(tsc.billing_id)::varchar,'YYYYMMDD') as billing_dttm
  from
    tsc
    JOIN edw_stg_dds.t_000009_dim_account dim_account
      ON 1 = 1
      and tsc.src_id_user_id = dim_account.account_key
      and tsc.src_id = dim_account.src_id
      and tsc.DATE_ between dim_account.eff_dttm and dim_account.exp_dttm
    JOIN edw_stg_dds.t_000009_dim_partner dim_partner
      ON 1 = 1
      and dim_account.partner_key = dim_partner.partner_key
      and dim_account.src_id = dim_partner.src_id
      and tsc.DATE_ between dim_partner.eff_dttm and dim_partner.exp_dttm
    LEFT JOIN edw_dds.hub_dim_segment hub_dim_segment
      ON 1 = 1
      and hub_dim_segment.source_key = dim_partner.segment_key
      and hub_dim_segment.src_id = dim_partner.src_id
      and tsc.DATE_ between hub_dim_segment.eff_dttm and hub_dim_segment.exp_dttm
    LEFT JOIN edw_dds.dim_segment dim_segment
      ON 1 = 1
      and dim_segment.segment_key = hub_dim_segment.segment_key
      and dim_segment.deleted_ind = 0
      and tsc.DATE_ between dim_segment.eff_dttm and dim_segment.exp_dttm
    LEFT JOIN users u
      on 1 = 1
      and u.user_id = tsc.user_id
    left join xref x
      on 1 = 1
      and x.source_key =  tsc.svc_id_
    left join service et
      on 1 = 1
      and et.service_key = x.service_key
    left join cpa_charge
      on 1 = 1
      and cpa_charge.bid = tsc.billing_id
      and cpa_charge.user_id = tsc.user_id
      and cpa_charge.svc_id = tsc.svc_id
    left join o_contract
      on 1 = 1
      and o_contract.user_id = tsc.user_id
    left join t_sub_contract
      on 1 = 1
      and t_sub_contract.contract_id = o_contract.contract_id
  left join dim_subs
    on 1 = 1
    and tsc.src_id_user_id = dim_subs.account_key
    and et.business_service_key = dim_subs.business_service_key
    and tsc.billing_id_ between dim_subs.month_id_begin and dim_subs.month_id_end
) s
where 1 = 1
  and s.key1 = 1
  and vnd = 1
;
commit;

/*t_pay_correction*/
/*Корректировки платежей*/
insert into edw_stg_dds.t_000009_tfct_adjust
  ( adjust_key
  , adjust_type_key
  , subs_key
  , account_key
  , service_key
  , payment_key
  , /*bill_key,*/ bill_detail_key
  , contract_key
  , vat_rub
  , adjust_amt
  , adjust_dttm
  , corr_billing_id
  , src_id
  , load_dttm
  , eff_dttm
  , exp_dttm
  , billing_dttm)
SELECT adjust_key
     , adjust_type_key
     , subs_key
     , src_id||'#'||account_key as account_key
     , service_key
     , payment_key
     , /*bill_key,*/ bill_detail_key
     , contract_key
     , vat_rub
     , adjust_amt
     , adjust_dttm
     , corr_billing_id
     , src_id
     , load_dttm
     , eff_dttm
     , exp_dttm
   , billing_dttm
FROM(
SELECT  '2#'||round(t_pay_correction.pay_corr_id) as adjust_key
    ,coalesce(t_pay_correction.error_billing_id,to_char(to_date(pay_date::text,'YYYY-MM-DD H24:MI:SS'),'YYYYMM')::numeric, t_pay_correction.billing_id)::numeric(38,0) as corr_billing_ID
    ,t_pay_correction.corr_date as adjust_dttm
    ,coalesce('2'||'#'||t_pay_correction.reason_id, '2') as adjust_type_key
    ,-1 as subs_key
    ,-1 as service_key
    ,round(t_pay_correction.user_id) as account_key
    ,round(t_pay_correction.payment_id) as payment_key
    ,-1 as bill_key
    ,-1 as bill_detail_key
    ,-1 as contract_key
    ,(decode(t_pay_correction.pay_corr_type::int,1,-1,2,-1,1)*t_pay_correction.summ)*(0.2/(1+0.2)) as vat_rub
    ,(decode(t_pay_correction.pay_corr_type::int,1,-1,2,-1,1)*t_pay_correction.summ)*(1/(1+0.2)) as adjust_amt
    ,000009 as src_id
    ,now() as load_dttm
    ,cast('1900-01-01 00:00:00' as timestamp(0) without time zone) as eff_dttm
    ,cast('2999-12-31 00:00:00' as timestamp(0) without time zone) as exp_dttm
    ,cast('1900-01-01 00:00:00' as timestamp(0) without time zone) as start_date
    ,cast('2999-12-31 00:00:00' as timestamp(0) without time zone) as end_date
    ,to_date(trunc(t_pay_correction.billing_id)::varchar,'YYYYMMDD') as billing_dttm
FROM  (select * from edw_ods.t_000009_t_pay_correction t_pay_correction
    where ROUND(t_pay_correction.billing_id) between substr('20190601', 1, 6)::int and substr('20190630', 1, 6)::int
          and t_pay_correction.tech_dt between to_date(substr('20190601', 1, 8), 'YYYYMMDD') and to_date(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second'
    ) t_pay_correction
)sss
;
commit;

ANALYSE edw_stg_dds.t_000009_tfct_adjust;
