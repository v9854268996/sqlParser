--rev. 53393 от 27.03.2020
--TFCT_ASRV
set optimizer=on;

--ASRV 
truncate table edw_stg_dmcm.pre_asrv_nls_acc_1_prt_p000154;
insert into edw_stg_dmcm.pre_asrv_nls_acc_1_prt_p000154
(
  account,
  nls,
  rf_id,
  mrf_id,
  src_id
)
  select
    account,
    nls,
    rf_id,
    mrf_id,
    000154 as src_id
  from
    (
      select
        account,
        nls,
        rf_id,
        mrf_id,
        date_begin,
        coalesce(LEAD (DATE_BEGIN,1) over (partition by account ORDER BY DATE_END)- interval '1 second' ,DATE_END, date '2999-12-31') as DATE_END
      from
        edw_ods.t_000158_efftp_south_nls_accnt
      where
        000154 =154
        and account is not null
        and date_begin <= to_date('20190601', 'YYYYMMDD') + interval '1 month - 1 second'
    )
    SOUTH_NLS_ACCOUNT
  where
    to_date('20190601', 'YYYYMMDD') + interval '1 month - 1 second' between SOUTH_NLS_ACCOUNT.date_begin and SOUTH_NLS_ACCOUNT.date_end
;
analyze edw_stg_dmcm.pre_asrv_nls_acc_1_prt_p000154;

truncate table edw_stg_dmcm.pre_asrv_bba_1_prt_p000154;
insert into edw_stg_dmcm.pre_asrv_bba_1_prt_p000154
( 
  account ,
  shpd_sum,
  src_id
)
with tfct_asrv_bba1 as
  (
    SELECT
      dac.account_name                    as account,
      SUM(bba.total_download_data_volume) as shpd_sum
    FROM
      edw_ads.tfct_bba_consumption as bba
      INNER JOIN
        (
          SELECT distinct
            service_key
          FROM
            edw_ads.dim_service
          where
            business_service_key IN ('10201', '10202', '10203')
            and to_date('20190601', 'YYYYMMDD') between eff_dttm and exp_dttm
            and deleted_ind = 0
        )
        as t1
        ON
          bba.service_key = t1.service_key
      INNER JOIN
        edw_ads.dim_account as dac
        ON
          dac.account_key = bba.account_key
          AND dac.branch_key = bba.branch_key
          and to_date('20190601', 'YYYYMMDD') between dac.eff_dttm and dac.exp_dttm
          and dac.deleted_ind = 0
    where
      1                    =1
      and bba.calendar_key = to_date('20190601', 'YYYYMMDD') + interval '1 month - 1 day'
      and 
      (
        (000154=151 and bba.src_id in (63,64,65,66,67,68,69,70,71,72,73,74,75,76,77))
        or 
        (000154=152 and 1=0)
        or 
        (000154=153 and bba.src_id in (13,14,15,16,17,18,19,20,21,22,23,24))
        or 
        (000154=154 and bba.src_id in (26))
        or 
        (000154=155 and bba.src_id in (45))
        or 
        (000154=156 and bba.src_id in (90,91,92))
        or 
        (000154=157 and bba.src_id in (114, 115, 116))
      )
    GROUP BY
      dac.account_name
  )
  SELECT
    bba.account,
    round(bba.shpd_sum / count_subs, 5) as shpd_sum,
    000154                        as src_id
  FROM
    tfct_asrv_bba1 as bba
    INNER JOIN
      (
        select distinct
          coalesce(SOUTH_NLS_ACCOUNT.NLS, OO_EFF_TP.ACCOUNT) as account,
          OO_EFF_TP.p2_mrf_id,
          count(OO_EFF_TP.subs_id) as count_subs
        from
          edw_ods.t_000154_efftp_oo_eff_tp OO_EFF_TP
          LEFT JOIN
            edw_stg_dmcm.pre_asrv_nls_acc_1_prt_p000154 SOUTH_NLS_ACCOUNT
            on
              SOUTH_NLS_ACCOUNT.rf_id = OO_EFF_TP.p3_rf_id
              and SOUTH_NLS_ACCOUNT.mrf_id  = oo_eff_tp.p2_mrf_id
              and SOUTH_NLS_ACCOUNT.account = oo_eff_tp.account
        where
          OO_EFF_TP.tech_dt = to_date('20190601', 'YYYYMMDD')
          and OO_EFF_TP.serv_id = '2'
          and OO_EFF_TP.abn_id is not null
          and coalesce(CHARGE_ONLY_FLAG,0) <> 1
          and coalesce(p24_qnt_end_rp_shpd,0) + coalesce(p81_qnt_end_rp_ota,0) + coalesce(p83_qnt_end_rp_iptv,0) > 0
        group by
          coalesce(SOUTH_NLS_ACCOUNT.NLS, OO_EFF_TP.ACCOUNT),
          OO_EFF_TP.p2_mrf_id
      )
      acc
      on
        acc.account = bba.account
        and acc.p2_mrf_id <> 12
;
analyze edw_stg_dmcm.pre_asrv_bba_1_prt_p000154;

truncate table edw_stg_dmcm.pre_asrv_t_cons_1_prt_p000154;
insert into edw_stg_dmcm.pre_asrv_t_cons_1_prt_p000154
( 
  mrf_id,
  account_name,
  traf_in_mc_total,
  traf_in_ota,
  traf_in_vz,
  traf_in_mg,
  traf_in_mn,
  src_id
)
with tfct_telephony_consumption_pre as
  (
    select
      ttc.account_key,
      ttc.src_id,
      ttc.service_key,
      sum(coalesce(call_dur_paid_nval,0)) as TRAF_IN
    from
      edw_dds.tfct_telephony_consumption ttc
    where
      ttc.billing_id between to_date('20190601', 'YYYYMMDD') and to_date('20190601', 'YYYYMMDD') + interval '1 month - 1 second'
      and ttc.deleted_ind = 0
      and
      (
        (000154=151 and ttc.src_id in (48,49,50,51,52,53,54,55,56,57,58,59,60,61,62))
        or
        (000154=152 and ttc.src_id in (97))
        or
        (000154=153 and ttc.src_id in (1,2,3,4,5,6,7,8,9,10,11,12))
        or
        (000154=154 and ttc.src_id in (26,27,28,29,30,31,32,33,34,36,37,38,39))
        or
        (000154=155 and ttc.src_id in (45))
        or
        (000154=156 and ttc.src_id in (80,81,82,83,84,85,86,87,88))
        or
        (000154=157 and ttc.src_id in (107,108,109,110,111,112,113))
      )
    group by
      ttc.account_key ,
      ttc.src_id      ,
      ttc.service_key
  )
select
  db.parent_branch_key as MRF_ID,
  dim_account.account_name,
  sum(coalesce(TRAF_IN / 60/acc.kolvo_abn,0)) as TRAF_IN_MC_total ,
  sum(case when business_service_key = 10101 then coalesce(TRAF_IN / 60/acc.kolvo_abn,0) else 0 end) as TRAF_IN_OTA,
  sum(case when business_service_key = 10102 then coalesce(TRAF_IN / 60/acc.kolvo_abn,0) else 0 end) as TRAF_IN_VZ,
  sum(case when business_service_key = 10103 then coalesce(TRAF_IN / 60/acc.kolvo_abn,0) else 0 end) as TRAF_IN_MG,
  sum(case when business_service_key = 10104 then coalesce(TRAF_IN / 60/acc.kolvo_abn,0) else 0 end)as TRAF_IN_MN,
  000154 src_id
from
  tfct_telephony_consumption_pre ttc
  INNER JOIN
    (
      select
        service_key,
        business_service_key
      from
        edw_dds.dim_service
      where
        deleted_ind=0
        AND to_date('20190601', 'YYYYMMDD') + interval '1 month - 1 day' between eff_dttm and exp_dttm
        and business_service_key IN ('10101','10102','10103','10104')
      GROUP BY
        service_key,
        business_service_key
    )
    dim_service
    on
      ttc.service_key = dim_service.service_key
  INNER JOIN
    edw_dds.dim_account as dim_account
    ON
      dim_account.account_key = ttc.account_key
      AND dim_account.src_id = ttc.src_id
      AND dim_account.deleted_ind = 0
      AND dim_account.active_ind  = 'Y'
      --AND to_date('20190601', 'YYYYMMDD') + interval '1 month - 1 day' between dim_account.start_date and dim_account.end_date
      AND to_date('20190601', 'YYYYMMDD') + interval '1 month - 1 day' between dim_account.eff_dttm and dim_account.exp_dttm
  INNER JOIN
    edw_dds.dim_branch db
    on
      dim_account.branch_key = db.branch_key
      and db.deleted_ind     =0
      AND to_date('20190601', 'YYYYMMDD') + interval '1 month - 1 day' between db.eff_dttm and db.exp_dttm
  INNER JOIN
    (
      select
        coalesce(SOUTH_NLS_ACCOUNT.NLS, OO_EFF_TP.ACCOUNT) as account,
        p2_mrf_id,
        serv_id,
        count(subs_id) as kolvo_abn
      from
        edw_ods.t_000154_efftp_oo_eff_tp OO_EFF_TP
        LEFT JOIN
          edw_stg_dmcm.pre_asrv_nls_acc_1_prt_p000154 SOUTH_NLS_ACCOUNT
          on
            SOUTH_NLS_ACCOUNT.rf_id = OO_EFF_TP.p3_rf_id
            and SOUTH_NLS_ACCOUNT.mrf_id  = oo_eff_tp.p2_mrf_id
            and SOUTH_NLS_ACCOUNT.account = oo_eff_tp.account
      where
        OO_EFF_TP.tech_dt = to_date('20190601', 'YYYYMMDD')
        and OO_EFF_TP.serv_id = '1'
        and OO_EFF_TP.abn_id is not null
        and coalesce(CHARGE_ONLY_FLAG,0) <> 1
        and coalesce(p24_qnt_end_rp_shpd,0) + coalesce(p81_qnt_end_rp_ota,0) + coalesce(p83_qnt_end_rp_iptv,0) > 0
      group by
        coalesce(SOUTH_NLS_ACCOUNT.NLS, OO_EFF_TP.ACCOUNT),
        p1_period,
        p2_mrf_id,
        serv_id
    )
    acc
    on
      acc.account = dim_account.account_name
      and acc.p2_mrf_id = db.parent_branch_key
group by
  db.parent_branch_key,
  dim_account.account_name
;
analyze edw_stg_dmcm.pre_asrv_t_cons_1_prt_p000154;            

truncate table edw_stg_dmcm.tfct_ASRV_1_prt_p000154;
--Расчёт ШПД, ОТА, IPTV
insert into edw_stg_dmcm.tfct_ASRV_1_prt_p000154
  ( mrf_id,
    cm_id,
    accn_id,
    subs_id,
    srvs_id,
    srvs_type,
    srvs_region,
    srvs_mr,
    srvs_tech,
    dt_start_srvs,
    sale_ch,
    srvs_member_id,
    tp_bandl,
    tp_full,
    tp_gr,
    LT_CSTM_SRVS_TYPE,
    TRAF_IN_SHPD,
    TRAF_IN_MC_total,
    TRAF_IN_OTA,
    TRAF_IN_VZ,
    TRAF_IN_MG,
    TRAF_IN_MN,
    SRVS_IPTV_CNT_SAN,
    SRVS_IPTV_CNT_MAC,
    dev_ls_on,
    dev_ls_on_cnt,
    TARIF_ZONE_ID,
    PROMO_STATUS,
    eff_dttm,
    exp_dttm,
    load_dttm,
    src_id
  )   
with SAN_PRE as 
(
--11 MRF
  select         
        san,
        account,
    11 as MRF_ID,
        row_number() over (partition by san order by rn) as san_rn
      from (
        select
          san,
          account,
          2 as rn
        from(
          select
            uss_login as san,
            ab_account as account,
            row_number() over (partition by uss_login order by modify_date desc) rn
          from edw_ods.T_000151_sdpdv_SDP_MAP sd
          where ab_account is not null
        ) u
        where rn = 1
        
        union all
        
        select  
          account_number as san,
          oss_account_number as account,
          1 as rn
        from edw_ods.t_000195_v_iptv_dim_subscriber
        where iptv_eff_dttm <= to_date('20190601', 'YYYYMMDD') + interval '1 month - 1 second'
          and iptv_exp_dttm >= to_date('20190601', 'YYYYMMDD')
          and subscriber_is_test = 'Нет'
          and subcriber_state_name = 'Active'
          and subcriber_type_name = 'Физ.лицо'
          and oss_account_number is not null
          and mrf_id in (1,4)
          
        union all

        select 
          san, 
          account ,
          3 as rn
        from edw_dds.dim_san_account
        where eff_dttm <= to_date('20190601', 'YYYYMMDD') + interval '1 month - 1 second'
          and exp_dttm >= to_date('20190601', 'YYYYMMDD')
          and sdp_mrf_id in (1,4)
          and account is not null    
    )sa
UNION ALL
--12 MRF
select         
        san,
        account,
    12 as MRF_ID,
        row_number() over (partition by san order by rn) as san_rn
      from 
      (    
        select
          san,
          account,
          2 as rn
        from
          (
            select
              household as san,
              account,
              row_number() over (partition by household order by di desc) rn
            from edw_ods.T_000158_sdpdv_SDP_MAP_12
          ) a
        where rn = 1
          
        union all
        
        select  
          account_number as san,
          oss_account_number as account,
          1 as rn
        from edw_ods.t_000195_v_iptv_dim_subscriber
        where iptv_eff_dttm <= to_date('20190601', 'YYYYMMDD') + interval '1 month - 1 second'
          and iptv_exp_dttm >= to_date('20190601', 'YYYYMMDD')
          and subscriber_is_test = 'Нет'
          and subcriber_state_name = 'Active'
          and subcriber_type_name = 'Физ.лицо'
          and oss_account_number is not null
          and mrf_id in (5)
          
        union all

        select 
          san, 
          account ,
          3 as rn
        from edw_dds.dim_san_account
        where eff_dttm <= to_date('20190601', 'YYYYMMDD') + interval '1 month - 1 second'
          and exp_dttm >= to_date('20190601', 'YYYYMMDD')
          and sdp_mrf_id in (5)
          and account is not null
      ) sa
UNION ALL
--13 MRF
select         
        san,
        account,
    13 as MRF_ID,
        row_number() over (partition by san order by rn) as san_rn
      from 
      (    
        select
          san,
          account,
          2 as rn
        from
          (
            select
              uss_login as san,
              ab_account as account,
              row_number() over (partition by uss_login order by modify_date desc) rn
            from edw_ods.T_000153_sdpdv_SDP_MAP sd
            where ab_account is not null
          ) u
        where rn = 1
          
        union all
        
        select  
          account_number as san,
          oss_account_number as account,
          1 as rn
        from edw_ods.t_000195_v_iptv_dim_subscriber
        where iptv_eff_dttm <= to_date('20190601', 'YYYYMMDD') + interval '1 month - 1 second'
          and iptv_exp_dttm >= to_date('20190601', 'YYYYMMDD')
          and subscriber_is_test = 'Нет'
          and subcriber_state_name = 'Active'
          and subcriber_type_name = 'Физ.лицо'
          and oss_account_number is not null
          and mrf_id in (9)
          
        union all

        select 
          san, 
          account ,
          3 as rn
        from edw_dds.dim_san_account
        where eff_dttm <= to_date('20190601', 'YYYYMMDD') + interval '1 month - 1 second'
          and exp_dttm >= to_date('20190601', 'YYYYMMDD')
          and sdp_mrf_id in (9)
          and account is not null    
        
) sa
UNION ALL
--14 MRF
select         
        san,
        account,
    14 as MRF_ID,
        row_number() over (partition by san order by rn) as san_rn
      from 
      (     
        select
          san,
          account,
          2 as rn
        from
          (
            select
              san,
              account as account,
              row_number() over (partition by san order by table_num, rn_low) as rn
            from
              (
                select
                  visual_code as san,
                  account,
                  2 as table_num,
                  row_number() over (partition by subscribers_dwh.visual_code
                                   order by
                                     subscribers_dwh.date_snap desc,
                                     subscribers_dwh.log_id desc) as rn_low
                from edw_ods.t_000154_rprt_subscribers_dwh subscribers_dwh
                where subscribers_dwh.mrf_id in (14)
                  and coalesce(format_version,'') not like 'VIRT%'
                  and account                  is not null
                union all
                select
                  visual_code,
                  account,
                  1,
                  row_number() over (partition by visual_code order by account desc)
                from edw_ods.t_000154_rprtsubscribersactual
                where mrf_id in (14)
                  and coalesce(format_version,'') not like 'VIRT%'
                  and account is not null
              ) pre_sub
          ) o
        where rn = 1

        union all
        
        select  
          account_number as san,
          oss_account_number as account,
          1 as rn
        from edw_ods.t_000195_v_iptv_dim_subscriber
        where iptv_eff_dttm <= to_date('20190601', 'YYYYMMDD') + interval '1 month - 1 second'
          and iptv_exp_dttm >= to_date('20190601', 'YYYYMMDD')
          and subscriber_is_test = 'Нет'
          and subcriber_state_name = 'Active'
          and subcriber_type_name  = 'Физ.лицо'
          and oss_account_number is not null
          and mrf_id in (7)
          
        union all

        select 
          san, 
          account ,
          3 as rn
        from edw_dds.dim_san_account
        where eff_dttm <= to_date('20190601', 'YYYYMMDD') + interval '1 month - 1 second'
          and exp_dttm >= to_date('20190601', 'YYYYMMDD')
          and sdp_mrf_id in (7)
          and account is not null              
      ) sa 
UNION ALL
--15 MRF
select         
        san,
        account,
    15 as MRF_ID,
        row_number() over (partition by san order by rn) as san_rn
      from 
      (        
        select
          san,
          account,
          2 as rn
        from
          (
            select
              san,
              account as account,
              row_number() over (partition by san order by table_num, rn_low) as rn
            from
              (
                select
                  login as san,
                  account,
                  2 as table_num,
                  row_number() over (partition by subscribers_dwh.login order by subscribers_dwh.date_snap desc, subscribers_dwh.log_id desc) as rn_low
                from edw_ods.t_000155_rprt_subscribers_dwh subscribers_dwh
                where subscribers_dwh.mrf_id in (15)
                  and coalesce(format_version,'') not like 'VIRT%'
                  and account is not null
                  and login like '77%'
                  and serv_id = 3
                union all
                select
                  login,
                  account,
                  1,
                  row_number() over (partition by login order by account desc)
                from edw_ods.t_000155_rprtsubscribersactual
                where mrf_id in (15)
                  and coalesce(format_version,'') not like 'VIRT%'
                  and account is not null
                  and login like '77%'
                  and serv_id = 33
              ) pre_sub 
          ) o
        where rn = 1
          
        union all
        
        select  
          account_number as san,
          oss_account_number as account,
          1 as rn
        from edw_ods.t_000195_v_iptv_dim_subscriber
        where iptv_eff_dttm <= to_date('20190601', 'YYYYMMDD') + interval '1 month - 1 second'
          and iptv_exp_dttm >= to_date('20190601', 'YYYYMMDD')
          and subscriber_is_test   = 'Нет'
          and subcriber_state_name = 'Active'
          and subcriber_type_name  = 'Физ.лицо'
          and oss_account_number is not null
          and mrf_id in (8)
          
        union all

        select 
          san, 
          account ,
          3 as rn
        from edw_dds.dim_san_account
        where eff_dttm <= to_date('20190601', 'YYYYMMDD') + interval '1 month - 1 second'
          and exp_dttm >= to_date('20190601', 'YYYYMMDD')
          and sdp_mrf_id in (8)
          and account is not null    
      ) sa
UNION ALL
--16 MRF
select         
        san,
        account,
    16 as MRF_ID,
        row_number() over (partition by san order by rn) as san_rn
      from 
      (     
        select
          san,
          account,
          2 as rn
        from
          (
            select
              SRV_LOGIN_NAME as san,
              account,
              row_number() over (partition by srv_login_name order by srv_status_date desc) rn
            from edw_ods.T_000158_sdpdv_SDP_MAP_16
          ) a
        where rn = 1
          
        union all
        
        select  
          account_number as san,
          oss_account_number as account,
          1 as rn
        from edw_ods.t_000195_v_iptv_dim_subscriber
        where iptv_eff_dttm <= to_date('20190601', 'YYYYMMDD') + interval '1 month - 1 second'
          and iptv_exp_dttm >= to_date('20190601', 'YYYYMMDD')
          and subscriber_is_test = 'Нет'
          and subcriber_state_name = 'Active'
          and subcriber_type_name  = 'Физ.лицо'
          and oss_account_number is not null
          and mrf_id in (6)
          
        union all

        select 
          san, 
          account,
          3 as rn
        from edw_dds.dim_san_account
        where eff_dttm <= to_date('20190601', 'YYYYMMDD') + interval '1 month - 1 second'
          and exp_dttm >= to_date('20190601', 'YYYYMMDD')
          and sdp_mrf_id in (6)
          and account is not null    
      ) sa
UNION ALL
--17 MRF
select         
        san,
        account,
    17 as MRF_ID,
        row_number() over (partition by san order by rn) as san_rn
      from 
      (      
        select
          san,
          account,
          2 as rn
        from
          (
            select
              uss_login as san,
              ab_account as account,
              row_number() over (partition by uss_login order by modify_date desc) rn
            from edw_ods.T_000157_sdpdv_SDP_MAP sd
            where ab_account is not null
          ) u
        where rn = 1
          
        union all
        
        select  
          account_number as san,
          oss_account_number as account,
          1 as rn
        from edw_ods.t_000195_v_iptv_dim_subscriber
        where
          iptv_eff_dttm <= to_date('20190601', 'YYYYMMDD') + interval '1 month - 1 second'
          and iptv_exp_dttm >= to_date('20190601', 'YYYYMMDD')
          and subscriber_is_test = 'Нет'
          and subcriber_state_name = 'Active'
          and subcriber_type_name  = 'Физ.лицо'
          and oss_account_number is not null
          and mrf_id in (3)
          
        union all

        select 
          san, 
          account,
          3 as rn
        from edw_dds.dim_san_account
        where eff_dttm <= to_date('20190601', 'YYYYMMDD') + interval '1 month - 1 second'
          and exp_dttm >= to_date('20190601', 'YYYYMMDD')
          and sdp_mrf_id in (3)
          and account is not null    
      ) sa
)    
        
SELECT
  mrf_id,
  cm_id,
  accn_id,
  subs_id,
  srvs_id,
  srvs_type,
  srvs_region,
  srvs_mr,
  srvs_tech,
  dt_start_srvs,
  sale_ch,
  srvs_member_id,
  tp_bandl,
  tp_full,
  tp_gr,
  case
    when to_date('20190601', 'YYYYMMDD') + interval '1 month - 1 day' < date_close
      then date_part('day',(to_date('20190601', 'YYYYMMDD')+interval '1 month - 1 second') - dt_start_srvs)
      else date_part('day',date_trunc('DAY',date_close) - date_trunc('DAY',dt_start_srvs))
  end as LT_CSTM_SRVS_TYPE,
  TRAF_IN_SHPD,
  TRAF_IN_MC_total,
  TRAF_IN_OTA,
  TRAF_IN_VZ,
  TRAF_IN_MG,
  TRAF_IN_MN,
  SRVS_IPTV_CNT_SAN,
  SRVS_IPTV_CNT_MAC,
  dev_ls_on,
  dev_ls_on_cnt,
  TARIF_ZONE_ID,
  PROMO_STATUS,
  eff_dttm,
  exp_dttm,
  load_dttm,
  src_id
from
  (
    select
      OO_EFF_TP.P2_MRF_ID                                      as mrf_id,
      coalesce(OO_EFF_TP.hflat, '-'||nls_acc.nls, '-'||OO_EFF_TP.account) AS cm_id,
      coalesce(nls_acc.nls, OO_EFF_TP.ACCOUNT)                 as accn_id,
      OO_EFF_TP.ABN_ID                                         as subs_id,
      OO_EFF_TP.ABN_ID                                         as srvs_id,
      coalesce(DIR_SERVICES.DEF,'')                            as srvs_type,
      coalesce(DIR_BRANCHES_2.DEF_SHORT,'')                    as srvs_region,
      coalesce(DIR_BRANCHES_1.DEF,'')                          as srvs_mr,
      coalesce(DIR_TECH.DEF,'')                                as srvs_tech,
      coalesce(min(OO_EFF_TP.DATE_START),'1900-01-01')         as dt_start_srvs,
      coalesce(max(date_close),'2999-12-31')                   as date_close,
      CASE
        WHEN OO_EFF_TP.p2_MRF_ID = 12
          then coalesce(SHPD_COUNT_TRAFFIC/1000, 0)
          else coalesce(tfct_bba_consumption.shpd_sum/1000, 0)
      end                                                                                                             as TRAF_IN_SHPD,
      coalesce(max(tl_cons.TRAF_IN_MC_total), 0)                                                                      as TRAF_IN_MC_total,
      coalesce(max(tl_cons.TRAF_IN_OTA), 0)                                                                           as TRAF_IN_OTA,
      coalesce(max(tl_cons.TRAF_IN_VZ), 0)                                                                            as TRAF_IN_VZ,
      coalesce(max(tl_cons.TRAF_IN_MG), 0)                                                                            as TRAF_IN_MG,
      coalesce(max(tl_cons.TRAF_IN_MN), 0)                                                                            as TRAF_IN_MN,
      coalesce(OO_EFF_TP.P86_SALE_CHANNEL, WC_MAP_SUBS.wc_channel_name::varchar, WC_MAP_SUBS2.wc_channel_name::varchar, 'Не определен') AS sale_ch,
      coalesce(SUBSCRIBERS_ACTUAL.LOGIN, OO_EFF_TP.LOGIN,'')                                                          as srvs_member_id,
      ''                                                                                                              as tp_bandl,
      coalesce(OO_EFF_TP.RTPL_NAME,'')                                                                                as tp_full,
       coalesce(VRATE_PLANS_DWH.RTPL_GROUP_NAME,'')                                                                   as tp_gr,
      sum(coalesce(SAN.san_cnt, SAN_2.san_cnt,0)) as SRVS_IPTV_CNT_SAN,
      sum(coalesce(SAN_mac.mac_cnt,0)) as SRVS_IPTV_CNT_MAC  ,
      case
        when sum(coalesce(OO_EFF_TP.P37_AMOUNT_RENT_SHPD,0)+coalesce(OO_EFF_TP.P74_AMOUNT_RENT_IPTV,0)) > 0
          then 1
          else 0
      end as dev_ls_on ,
       case
      when sum(coalesce(cd.amount, cd17.amount,0)) <> 0 and sum(coalesce(OO_EFF_TP.P37_AMOUNT_RENT_SHPD,0)+coalesce(OO_EFF_TP.P74_AMOUNT_RENT_IPTV,0)) > 0 and sum(coalesce(cd.dev_ls_on, cd17.dev_ls_on,0))<>0
            then sum(coalesce(cd.amount, cd17.amount,0))
              else 0
          end as dev_ls_on_cnt,
      coalesce(cast(addr.TARIF_ZONE_ID as varchar), '') as TARIF_ZONE_ID,
      0 as PROMO_STATUS,
      to_date('20190601', 'YYYYMMDD')                                   as eff_dttm,
      to_date('20190601', 'YYYYMMDD') + INTERVAL'1 month - 1 second'    AS exp_dttm,
      now() as load_dttm,
      000154  as src_id
    from
      edw_ods.t_000154_efftp_oo_eff_tp OO_EFF_TP
      inner join
      (
        select
          abn_id ,
          serv_id,
          row_number() over (partition by abn_id order by serv_id DESC) as rn
        from
          (
            select
              abn_id,
              serv_id
            from edw_ods.t_000154_efftp_oo_eff_tp oo_eff_tp
            where oo_eff_tp.tech_dt = to_date('20190601', 'YYYYMMDD')
            group by
              abn_id,
              serv_id
          )
          s
      )
      t2 on oo_eff_tp.abn_id = t2.abn_id and oo_eff_tp.serv_id = t2.serv_id and t2.rn = 1
      left join edw_ods.t_000154_rprtsubscribersactual SUBSCRIBERS_ACTUAL on OO_EFF_TP.abn_id = SUBSCRIBERS_ACTUAL.abn_id
      left join edw_ods.t_000158_rprt_dir_services dir_services on OO_EFF_TP.serv_id = dir_services.serv_id
      left join edw_ods.t_000158_rprt_dir_tech dir_tech on OO_EFF_TP.TECH_ID = dir_tech.TECH_ID
      LEFT JOIN edw_ods.t_000158_rprt_dir_branches DIR_BRANCHES_1 ON OO_EFF_TP.P2_MRF_ID = DIR_BRANCHES_1.BRNC_ID
      LEFT JOIN edw_ods.t_000158_rprt_dir_branches DIR_BRANCHES_2 ON OO_EFF_TP.P3_RF_ID = DIR_BRANCHES_2.BRNC_ID          
      left join
        (
          select
            TECH_ID,
            account,
            mrf_id,
            rf_id,
            abn_id,
            clie_id,
            RTPL_GROUP_NAME,
            row_number() over (partition by account,
                               TECH_ID,
                               mrf_id,
                               rf_id,
                               abn_id,
                               clie_id
                             order by
                               date_snap DESC,
                               log_id DESC) as rn
          from
            edw_ods.t_000154_rprt_vrate_plans_dwh
        )
        VRATE_PLANS_DWH
        on
          OO_EFF_TP.account       = VRATE_PLANS_DWH.account
          and OO_EFF_TP.P2_mrf_id = VRATE_PLANS_DWH.mrf_id
          and OO_EFF_TP.P3_rf_id  = VRATE_PLANS_DWH.rf_id
          and OO_EFF_TP.abn_id    = VRATE_PLANS_DWH.abn_id
          and OO_EFF_TP.clie_id   = VRATE_PLANS_DWH.clie_id
          and OO_EFF_TP.TECH_ID   = VRATE_PLANS_DWH.TECH_ID
          and VRATE_PLANS_DWH.rn  =1
      left join
        edw_stg_dmcm.pre_asrv_nls_acc_1_prt_p000154 nls_acc
        on
          nls_acc.rf_id       = OO_EFF_TP.p3_rf_id
          and nls_acc.mrf_id  = oo_eff_tp.p2_mrf_id
          and nls_acc.account = oo_eff_tp.account
      left join
        (
        select
            equip_id                                                        ,
            case
              when dim_nomenclature.business_service_key = '10200' then 2
              when dim_nomenclature.business_service_key = '10101' then 1
              when dim_nomenclature.business_service_key = '11500' then 0
              when dim_nomenclature.business_service_key = '10401' then 3
              else 0
            end                                                  as serv_id ,
            DATE_CREATE                                                     ,
            cd.MRF_ID                                                       ,
            soo_src_id                                                      ,
            coalesce(tp.account, cd.account)                      as account,
            count(distinct equip_id) over (partition by cd.abn_id,
                                                        case
                                                            when dim_nomenclature.business_service_key = '10200' then 2
                                                            when dim_nomenclature.business_service_key = '10101' then 1
                                                            when dim_nomenclature.business_service_key = '11500' then 0
                                                            when dim_nomenclature.business_service_key = '10401' then 3
                                                            else 0
                                                        end
                                          )                      as amount ,
            case
              when cd.transaction_type in (1,11,47)
                then 1
                else 0
            end as dev_ls_on ,
            coalesce(LEAD (DATE_CREATE,1) over (
                                              partition by cd.equip_id,
                                                cd.abn_id
                                              ORDER BY
                                                DATE_CREATE)- interval '1 second', date '2999-12-31') as DATE_END
        from (select distinct
                  document.transaction_type
                , document.equip_id
                , case when substr(document.account,2,1) = '_' then split_part(document.account,'_',2)
                       else document.account 
                  end as account
                , document.nomenclature_code
                , document.nomenclature_name
                , document.amount
                , document.abn_id
                , document.mrf_id
                , document.rf_id
                , document.date_transfer
                , document.date_create as date_create
                , document.date_end    as date_end
                , document.soo_src_id
            from  edw_ods.t_000154_cpe_cpe_m_document document
          where
            000154<>157
            and document.date_transfer is not null
            and document.abn_id    is not null
            and document.date_create        <= to_date('20190601', 'YYYYMMDD') + interval '1 month - 1 second'            
          )  cd
      
      
            join
              edw_dds.DIM_NOMENCLATURE DIM_NOMENCLATURE
              on
                cd.NOMENCLATURE_CODE = DIM_NOMENCLATURE.nomenclature_code
            join
              (
                select
                  abn_id,
                  account
                from
                  edw_ods.t_000154_efftp_oo_eff_tp
                where
                  000154<>157
                  and tech_dt = to_date('20190601', 'YYYYMMDD') 
                group by
                  abn_id,
                  account
              )
              tp
              on
                tp.abn_id = cd.abn_id
        )
        cd
        on
          cd.account = oo_eff_tp.account
          AND cd.MRF_ID = OO_EFF_TP.P2_MRF_ID
          and oo_eff_tp.p2_mrf_id <>17
          and cd.serv_id = oo_eff_tp.serv_id
          and to_date('20190601', 'YYYYMMDD') + interval'1 month - 1 second' between cd.DATE_CREATE and cd.date_end
      left join
        (
          select
            abn_id                                                          ,
            equip_id                                                        ,
            case
              when dim_nomenclature.business_service_key = '10200' then 2
              when dim_nomenclature.business_service_key = '10101' then 1
              when dim_nomenclature.business_service_key = '11500' then 0
              when dim_nomenclature.business_service_key = '10401' then 3
              else 0
            end                                                  as serv_id ,
            DATE_CREATE                                                     ,
            soo_src_id                                                      ,
            cd.mrf_id                                                       ,
            cd.account                                                      ,
            count(distinct equip_id) over (partition by abn_id,
                                                        case
                                                            when dim_nomenclature.business_service_key = '10200' then 2
                                                            when dim_nomenclature.business_service_key = '10101' then 1
                                                            when dim_nomenclature.business_service_key = '11500' then 0
                                                            when dim_nomenclature.business_service_key = '10401' then 3
                                                            else 0
                                                        end
                                          )                      as amount ,
            case
              when cd.transaction_type in (1,11,47)
                then 1
                else 0
            end as dev_ls_on ,
            coalesce(LEAD (DATE_CREATE,1) over (
                                              partition by soo_src_id,
                                                equip_id             ,
                                                abn_id
                                              ORDER BY
                                                DATE_CREATE)- interval '1 second', date '2999-12-31') as DATE_END
          from
            edw_ods.t_000154_cpe_cpe_m_document cd
            join
              edw_dds.DIM_NOMENCLATURE DIM_NOMENCLATURE
              on
                cd.NOMENCLATURE_CODE = DIM_NOMENCLATURE.nomenclature_code
          where
            000154=157
            and cd.date_transfer is not null
            and cd.abn_id    is not null
            and cd.date_create        <= to_date('20190601', 'YYYYMMDD') + interval '1 month - 1 second'
        )
        cd17
        on
          cd17.account            = oo_eff_tp.account
          AND cd17.MRF_ID         = OO_EFF_TP.P2_MRF_ID
          and oo_eff_tp.p2_mrf_id = 17
          and cd17.serv_id        = oo_eff_tp.serv_id 
          and to_date('20190601', 'YYYYMMDD') + interval'1 month - 1 second' between cd17.DATE_CREATE and cd17.date_end
        left join
        (
          select
            abn_id         ,
            wc_channel_name,
            row_number() over (
                             partition by abn_id
                             order by
                               wc_date_inst DESC,
                               wc_date_create DESC) as rn
          from
            edw_ods.t_000158_efftp_wc_map_subs
          where
            wc_channel_name is not null
            and wc_date_inst         <= to_date('20190601', 'YYYYMMDD') + interval '1 month - 1 second'
        )
        WC_MAP_SUBS
        on
          oo_eff_tp.abn_id  = WC_MAP_SUBS.abn_id
          and WC_MAP_SUBS.rn=1
      left join
        (
          select
            wc_account as account,
            wc_channel_name      ,
            row_number() over (
                             partition by wc_account
                             order by
                               wc_date_inst DESC,
                               wc_date_create DESC) as rn
          from
            edw_ods.t_000158_efftp_wc_map_subs
          where
            wc_channel_name is not null
            and wc_date_inst         <= to_date('20190601', 'YYYYMMDD') + interval '1 month - 1 second'
        )
        WC_MAP_SUBS2
        on
          oo_eff_tp.account  = WC_MAP_SUBS2.account
          and WC_MAP_SUBS2.rn=1
      left join
        (
          select
            ABN_ID                                                                      ,
            mrf_id                                                                      ,
            to_number(to_char(date_trunc('month', t.period), 'YYYYMM'), '999999') as period,
            ROUND(((sum(t.COUNT_TRAFFIC))/1024/1024), 2)                          as SHPD_COUNT_TRAFFIC
          from
            edw_ods.T_000158_CX_IQM_TRAFFIC_SHPD t
          where
            1                                 = 1
            and t.mrf_id                      = 12
            and t.TRAFFIC_TYPE                = '0'
            and date_trunc('month', t.period) = date_trunc('month', to_date('20190601', 'YYYYMMDD'))
            and t.tech_dt                     = (date_trunc('month', to_date('20190601', 'YYYYMMDD')))::timestamp
          group by
            ABN_ID,
            mrf_id,
            to_number(to_char(date_trunc('month', t.period), 'YYYYMM'), '999999')
          ) sh 
          on    OO_EFF_TP.serv_id     = 2
            and OO_EFF_TP.p2_MRF_ID   = 12
            and sh.MRF_ID             = OO_EFF_TP.p2_MRF_ID
            and sh.PERIOD             = OO_EFF_TP.p1_period
            and sh.ABN_ID::varchar    = OO_EFF_TP.subs_ID
      left join
        edw_ods.t_000154_rprt_oo_address addr
        on
          OO_EFF_TP.hlid          = addr.house_lid
          and OO_EFF_TP.p2_mrf_id = addr.mrf_id
      LEFT JOIN edw_stg_dmcm.pre_asrv_bba_1_prt_p000154 tfct_bba_consumption
        on
          coalesce(nls_acc.nls, OO_EFF_TP.ACCOUNT) = tfct_bba_consumption.account
          and OO_EFF_TP.serv_id                    =2
      left join edw_stg_dmcm.pre_asrv_t_cons_1_prt_p000154 tl_cons
        on
          coalesce(nls_acc.nls, OO_EFF_TP.ACCOUNT) = tl_cons.account_name
          and OO_EFF_TP.p2_mrf_id                  = tl_cons.mrf_id
          and OO_EFF_TP.serv_id                    =1
      left join (
    select
            count(distinct SAN) as san_cnt ,
            account                                   ,
            mrf_id
          from SAN_PRE
      where san_rn=1
          group by
            account ,
            mrf_id
      ) SAN on    
        san.account    = oo_eff_tp.account
        and san.mrf_id = oo_eff_tp.p2_mrf_id
      left join (
    
    select
        
          count(distinct t.mac) as mac_cnt,
          sad.account as account,
          decode(s_t.mrf_id,1,11,5,12,9,13,7,14,8,15,6,16,3,17) as mrf_id

      from edw_ods.t_000195_v_iptv_dim_subscriber s_t
      left join edw_ods.t_000195_v_iptv_dim_terminal t on   s_t.dim_subscriber_id = t.subscriber_id
                                      and t.iptv_eff_dttm  <=to_date('20190601', 'YYYYMMDD') + interval '1 month - 1 second'
                                      and t.iptv_exp_dttm  >=to_date('20190601', 'YYYYMMDD')
        
      left join SAN_PRE sad on s_t.account_number = sad.san
                and sad.MRF_ID = decode(s_t.mrf_id,1,11,5,12,9,13,7,14,8,15,6,16,3,17)
                and sad.san_rn =1

      where   s_t.has_stb                 = 'Да'
            and s_t.subscriber_is_test  = 'Нет'
            and s_t.is_deleted          = 0
            and s_t.subcriber_type_name = 'Физ.лицо'
            and s_t.iptv_eff_dttm      <= to_date('20190601', 'YYYYMMDD') + interval '1 month - 1 second'
            and s_t.iptv_exp_dttm      >= to_date('20190601', 'YYYYMMDD')
        
      group by  sad.account
            , decode(s_t.mrf_id,1,11,5,12,9,13,7,14,8,15,6,16,3,17)

      ) SAN_mac on    
        SAN_mac.account    = oo_eff_tp.account
        and SAN_mac.mrf_id = oo_eff_tp.p2_mrf_id   
    left join (
      select 
        ddd.mrf_id, 
        count(distinct ddd.san) as san_cnt, 
        ddd.account
      from (
        select 
          fff.mrf_id, 
          fff.san, 
          fff.nls account,
          row_number() over ( partition by fff.mrf_id, fff.san order by  fff.startdate desc ,fff.persistdate desc ,fff.nls desc) rn
        from (  
          select  
            case 
              when a1.description like '%СЗ%'     then 12
              when a1.description like '%Волга%'  then 13
              when a1.description like '%ДВ%'     then 17
              when a1.description like '%Юг%'     then 14
              when a1.description like '%Сибирь%' then 16
              when a1.description like '%Центр%'  then 11
              when t.client_app_pkid=14           then 15
              else -1 
            end  mrf_id,
            t.san, 
            d.nls,
            t.startdate,   
            t.persistdate
          from edw_ods.T_000129_subscriber t
            inner join  edw_ods.T_000129_client d
             on   
                  d.nls is not null
              and d. deleted=0
              and t.client_app_pkid=d.app_pkid 
              and t.client_version=d.version 
              and t.client_localsystemid=d.localsystemid
            inner join edw_ods.T_000129_APPLICATIONINSTANCE a1
             on 
                  a1.typeapplication_pkid=2
              and t.client_app_pkid=a1.pkid
          where 1=1 
            and t.san is not null 
            and t.startdate <= to_date('20190601', 'YYYYMMDD') + interval '1 month - 1 second' 
            and t.version=0  
        ) fff
      ) ddd
      where ddd.rn=1
      group by ddd.mrf_id, ddd.account
    ) SAN_2 on    SAN_2.account = oo_eff_tp.account
              and SAN_2.mrf_id = oo_eff_tp.p2_mrf_id       
    where
      OO_EFF_TP.tech_dt = to_date('20190601', 'YYYYMMDD') 
      and OO_EFF_TP.serv_id in (1,2,3) 
      and OO_EFF_TP.account                                                                   is not null
      and OO_EFF_TP.abn_id                                                                   is not null
      and coalesce(p24_qnt_end_rp_shpd,0)+coalesce(p81_qnt_end_rp_ota,0)+coalesce(p83_qnt_end_rp_iptv,0)>0
      and coalesce(OO_EFF_TP.charge_only_flag, 0) != 1
    group by
      OO_EFF_TP.P2_MRF_ID,
      coalesce(OO_EFF_TP.hflat, '-'||nls_acc.nls, '-'||OO_EFF_TP.account),
      coalesce(nls_acc.nls, OO_EFF_TP.ACCOUNT),
      OO_EFF_TP.ABN_ID,
      CASE
        WHEN OO_EFF_TP.p2_MRF_ID = 12
          then coalesce(SHPD_COUNT_TRAFFIC/1000, 0)
          else coalesce(tfct_bba_consumption.shpd_sum/1000, 0)
      end,
      coalesce(DIR_SERVICES.DEF,''),
      coalesce(DIR_BRANCHES_2.DEF_SHORT,''),
      coalesce(DIR_BRANCHES_1.DEF,''),
      coalesce(DIR_TECH.DEF,''),
      coalesce(OO_EFF_TP.P86_SALE_CHANNEL, WC_MAP_SUBS.wc_channel_name::varchar, WC_MAP_SUBS2.wc_channel_name::varchar, 'Не определен'),
      coalesce(SUBSCRIBERS_ACTUAL.LOGIN, OO_EFF_TP.LOGIN,''),
      coalesce(OO_EFF_TP.RTPL_NAME,''),
      coalesce(VRATE_PLANS_DWH.RTPL_GROUP_NAME,''),
      coalesce(cast(addr.TARIF_ZONE_ID as varchar), '')
    
  )
  SSS
;


-- ASRV_MVNO

insert into edw_stg_dmcm.tfct_ASRV_1_prt_p000154
(
mrf_id,
cm_id,
accn_id,
subs_id,
srvs_id,
srvs_type,
srvs_region,
srvs_mr,
srvs_tech,
dt_start_srvs,
sale_ch,
srvs_member_id,
tp_bandl,
tp_full,
tp_gr,
SRVS_IPTV_CNT_SAN,
SRVS_IPTV_CNT_MAC,
dev_ls_on,
dev_ls_on_cnt,
LT_CSTM_SRVS_TYPE,
TARIF_ZONE_ID,
TRAF_IN_SHPD,
TRAF_IN_MC_total,
TRAF_IN_OTA,
TRAF_IN_VZ,
TRAF_IN_MG,
TRAF_IN_MN,
PROMO_STATUS,
EFF_DTTM,
EXP_DTTM,
load_dttm,
src_id
)
SELECT
    MRF_ID -- Идентификатор МРФ клиента
    ,CM_ID -- Внутренний идентификатор клиента (ID МРФ+ уникальный ID ЛС)
    ,ACCN_ID -- Идентификатор/номер лицевого счета (НЛС) по единой классификации
    ,SUBS_ID -- ID
    ,SRVS_ID -- Уникальный идентификатор основной услуги
    ,SRVS_TYPE -- Тип услуги: ШПД, ОТА, ИТВ, MVNO
    ,SRVS_region -- РФ предоставления услуги
    ,SRVS_MR -- МРФ предоставления услуги
    ,SRVS_TECH -- Технология услуги
    ,DT_START_SRVS -- Дата активации основной услуги
    ,SALE_CH -- Тип канала продаж (из классификатора)
    ,SRVS_MEMBER_ID
    ,TP_bandl -- Текущий общий тариф (может быть бандлом с другими основными услугами, например, """"""""WEBIPTV Для абонентов ШПД РТ (Web)"""""""")
    ,TP_full -- Текущий тариф на основной услуге (полное название)(для ИТВ основн(ой)/ые пакет телеканалов)
    ,TP_GR -- Текущий тариф на основной услуге стандартизованный (группа тарифных планов)
    ,SRVS_IPTV_CNT_SAN -- SAN приставки ИТВ
    ,SRVS_IPTV_CNT_MAC -- MAC-адрес оборудования
    ,DEV_LS_ON -- Признак аренды оборудования
    ,DEV_LS_ON_CNT -- Количество арендованного оборудования
    ,case
          when EXP_DTTM < END_RTPL
          then date_part('day',date_trunc('DAY',EXP_DTTM) - date_trunc('DAY',DT_START_SRVS))
          else date_part('day',date_trunc('DAY',END_RTPL) - date_trunc('DAY',DT_START_SRVS)) 
    end as LT_CSTM_SRVS_TYPE
    ,TARIF_ZONE_ID
    ,TRAF_IN_SHPD
    ,TRAF_IN_MC_total
    ,TRAF_IN_OTA
    ,TRAF_IN_VZ
    ,TRAF_IN_MG
    ,TRAF_IN_MN
    ,PROMO_STATUS
    ,EFF_DTTM
    ,EXP_DTTM
    ,load_dttm
    ,000154 as src_id
FROM(
select  
OO_EFF_TP.P2_MRF_ID as mrf_id -- Идентификатор МРФ клиента
  , coalesce(OO_EFF_TP.HFLAT, '-'||nls_acc.NLS, '-'||OO_EFF_TP.ACCOUNT) as cm_id -- Внутренний идентификатор клиента (ID МРФ+ уникальный ID ЛС)
  , coalesce(nls_acc.NLS, OO_EFF_TP.ACCOUNT,'') as accn_id -- Идентификатор/номер лицевого счета (НЛС) по единой классификации
  , MVNO.subs_id as subs_id 
  , oo_eff_tp.abn_id as srvs_id 
  , MVNO.SERV as srvs_type -- Тип услуги: ШПД, ОТА, ИТВ, MVNO
  , MVNO.DEF_SHORT as srvs_region -- РФ предоставления услуги
  , MVNO.DEF as srvs_mr -- МРФ предоставления услуги
  ,'Не определено' as srvs_tech -- Технология услуги
  , min(MVNO.DATA_ACTIV) as dt_start_srvs -- Дата активации основной услуги
  , max(MVNO.end_rtpl) as end_rtpl
  , coalesce(b2c_month.chanel_sale, OO_EFF_TP.P86_SALE_CHANNEL, WC_MAP_SUBS_1.wc_channel_name::varchar, WC_MAP_SUBS_2.wc_channel_name::varchar, 'Не определен') as sale_ch -- Тип канала продаж (из классификатора)
  , coalesce(m1.cntct_mob,f1.cntct_fix,m2.cntct_mob,f2.cntct_fix,'') as srvs_member_id -- Логин основной услуги (прописывается в договоре, используется при активации услуги, отражается в том числе в ЕЛК). Для MVNO: мобильный номер телефона
  , '' as tp_bandl -- Текущий общий тариф (может быть бандлом с другими основными услугами, например, """"""""WEBIPTV Для абонентов ШПД РТ (Web)"""""""")
  , coalesce(MVNO.RTPL_NAME,'') as tp_full -- Текущий тариф на основной услуге (полное название)(для ИТВ основн(ой)/ые пакет телеканалов)
  , '' as tp_gr -- Текущий тариф на основной услуге стандартизованный (группа тарифных планов)
  , 0 as SRVS_IPTV_CNT_SAN -- SAN приставки ИТВ
  , 0 as SRVS_IPTV_CNT_MAC -- MAC-адрес оборудования
  , 0 as dev_ls_on -- Признак аренды оборудования
  , 0 as dev_ls_on_cnt -- Количество арендованного оборудования
  , coalesce(OO_ADDRESS.TARIF_ZONE_ID::text,'') as TARIF_ZONE_ID
  , 0 as TRAF_IN_SHPD
  , 0 as TRAF_IN_MC_total
  , 0 as TRAF_IN_OTA
  , 0 as TRAF_IN_VZ
  , 0 as TRAF_IN_MG
  , 0 as TRAF_IN_MN
  , 0 as PROMO_STATUS
  , to_date('20190601', 'YYYYMMDD') as EFF_DTTM
  , to_date('20190601', 'YYYYMMDD') + interval '1 month - 1 second' as EXP_DTTM
  , now() as load_dttm -- Дата последнего обновления данных
  
from edw_ods.t_000154_efftp_oo_eff_tp OO_EFF_TP
inner join
(
  select
    abn_id ,
    serv_id,
    row_number() over (
                     partition by abn_id
                     order by
                       serv_id DESC) as rn
  from
    (
      select
        abn_id,
        serv_id
      from
        edw_ods.t_000154_efftp_oo_eff_tp oo_eff_tp
      where
        oo_eff_tp.tech_dt = to_date('20190601', 'YYYYMMDD')
      group by
        abn_id,
        serv_id
    )
    s
)
t2 on oo_eff_tp.abn_id = t2.abn_id and oo_eff_tp.serv_id = t2.serv_id and t2.rn = 1
INNER JOIN(
      select  
      distinct
      c.abn_id_soo
            ,m.subs_id
                ,c.period
                ,c.mrf_id
                ,m.RTPL_NAME
                ,m.DATA_ACTIV
                ,m.end_rtpl
                ,DIR_BRANCHES_2.DEF_SHORT
                ,DIR_BRANCHES_1.DEF
                ,DIR_SERVICES.DEF as SERV
        ,m.account

      from edw_ods.t_000154_efftp_ooefftpmvnocon c
      join edw_ods.t_000154_efftp_oo_eff_tp_mvno m on m.subs_id = c.subs_id_mvno
                                                  and m.tech_dt = to_date('20190601', 'YYYYMMDD')
                                                  and m.mrf_id = c.mrf_id

    left join edw_ods.t_000158_rprt_dir_branches DIR_BRANCHES_1 on m.mrf_id = DIR_BRANCHES_1.brnc_id

    left join edw_ods.t_000158_rprt_dir_branches DIR_BRANCHES_2 on m.rf_id = DIR_BRANCHES_2.brnc_id

    left join edw_ods.t_000158_rprt_dir_services dir_services on dir_services.serv_id = 6
    where c.tech_dt = to_date('20190601', 'YYYYMMDD')

    )MVNO on  MVNO.abn_id_soo = oo_eff_tp.abn_id
            and MVNO.period = oo_eff_tp.p1_period
              and MVNO.mrf_id = oo_eff_tp.p2_mrf_id
left join edw_ods.t_000171_v_soo_b2c_month b2c_month on MVNO.subs_id = b2c_month.subs_id::varchar and b2c_month.tech_dt = to_date('20190601', 'YYYYMMDD')
left join edw_stg_dmcm.pre_asrv_nls_acc_1_prt_p000154 nls_acc
 on nls_acc.rf_id = OO_EFF_TP.p3_rf_id and nls_acc.mrf_id = oo_eff_tp.p2_mrf_id and nls_acc.account = oo_eff_tp.account
 
left join 
(
select abn_id as abn_id, wc_channel_name, row_number() over (partition by abn_id order by period DESC) as rn
from edw_ods.t_000158_efftp_wc_map_subs
where wc_channel_name is not null
  and tech_dt<to_date('20190601', 'YYYYMMDD') +interval '1 month - 1 second'
) wc_map_subs_1 on wc_map_subs_1.abn_id = OO_EFF_TP.abn_id and wc_map_subs_1.rn = 1

left join 
(
select wc_account as account, wc_channel_name, row_number() over (partition by wc_account order by period DESC) as rn
from edw_ods.t_000158_efftp_wc_map_subs
where wc_channel_name is not null
  and tech_dt<to_date('20190601', 'YYYYMMDD') +interval '1 month - 1 second'
) wc_map_subs_2 on wc_map_subs_2.account = OO_EFF_TP.account and wc_map_subs_2.rn = 1


left join(
select 
t1.abn_id,t1.MRF_ID,t1.date_begin,coalesce(lead(t1.date_begin) over (partition by t1.abn_id order by t1.date_begin, t1.date_end)- interval '1 second',t1.date_end,'2999-12-31 00:00:00'::date) as DATE_END
,t2.city,t2.house_lid,t2.house_gid,t2.N_POSTOFFICE_ID,t2.terr_type,t2.name_terr,t2.CITY_LID,t2.CITY_GID,t2.name_street_type,t2.shortname_street_type,t2.name_street,t2.n_house,t2.n_corpus,t2.ISPRIVATE,t1.flat,t2.TARIF_ZONE_ID
from edw_ods.t_000154_rprt_oo_addressabndwh t1
left join edw_ods.t_000154_rprt_oo_address t2 on t1.HOUSE_LID = t2.HOUSE_LID and t1.MRF_ID = t2.MRF_ID
)OO_ADDRESS on OO_EFF_TP.p2_MRF_ID = OO_ADDRESS.MRF_ID and OO_EFF_TP.ABN_ID = OO_ADDRESS.ABN_ID and to_date(OO_EFF_TP.p1_period::varchar,'YYYYMM')+interval'1 month - 1 day' between OO_ADDRESS.DATE_BEGIN and OO_ADDRESS.DATE_END

left join (select accn_id, cntct_mob, row_number() over (partition by accn_id order by DT_LOAD DESC, mis_src_id DESC) as rn from edw_ods.t_000134_mob where type_mob = 'Основной' and tech_dt<to_date('20190601', 'YYYYMMDD') +interval '1 month - 1 second') m1 on MVNO.account = m1.accn_id and m1.rn = 1
left join (select accn_id, cntct_mob, row_number() over (partition by accn_id order by DT_LOAD DESC, mis_src_id DESC) as rn  from edw_ods.t_000134_mob where type_mob = 'Альтернативный' and tech_dt<to_date('20190601', 'YYYYMMDD') +interval '1 month - 1 second') m2 on MVNO.account = m2.accn_id and m2.rn = 1

left join (select accn_id, cntct_fix, row_number() over (partition by accn_id order by DT_LOAD DESC, mis_src_id DESC) as rn  from edw_ods.t_000134_fix where type_fix = 'Основной' and tech_dt<to_date('20190601', 'YYYYMMDD') +interval '1 month - 1 second') f1 on MVNO.account = f1.accn_id and f1.rn = 1
left join (select accn_id, cntct_fix, row_number() over (partition by accn_id order by DT_LOAD DESC, mis_src_id DESC) as rn  from edw_ods.t_000134_fix where type_fix = 'Альтернативный' and tech_dt<to_date('20190601', 'YYYYMMDD') +interval '1 month - 1 second') f2 on MVNO.account = f2.accn_id and f2.rn = 1

where   
      OO_EFF_TP.tech_dt = to_date('20190601', 'YYYYMMDD')
       and OO_EFF_TP.serv_id in (1,2,3) 
       and coalesce(CHARGE_ONLY_FLAG,0) <> 1 
       and coalesce(p24_qnt_end_rp_shpd,0)+coalesce(p81_qnt_end_rp_ota,0)+coalesce(p83_qnt_end_rp_iptv,0)>0 
       and OO_EFF_TP.ABN_ID is not null
  
group by  
    OO_EFF_TP.P2_MRF_ID
  , coalesce(OO_EFF_TP.HFLAT, '-'||nls_acc.NLS, '-'||OO_EFF_TP.ACCOUNT)
  , coalesce(nls_acc.NLS, OO_EFF_TP.ACCOUNT,'')
  , MVNO.subs_id
  , oo_eff_tp.abn_id
  , MVNO.SERV
  , MVNO.DEF_SHORT
  , MVNO.DEF
  , coalesce(b2c_month.chanel_sale, OO_EFF_TP.P86_SALE_CHANNEL, WC_MAP_SUBS_1.wc_channel_name::varchar, WC_MAP_SUBS_2.wc_channel_name::varchar, 'Не определен')
  , coalesce(m1.cntct_mob,f1.cntct_fix,m2.cntct_mob,f2.cntct_fix,'')
  , coalesce(MVNO.RTPL_NAME,'')
  , coalesce(OO_ADDRESS.TARIF_ZONE_ID::text,'')
)x
;

--ASRV_MONO_MVNO
insert into edw_stg_dmcm.tfct_ASRV_1_prt_p000154
(
    mrf_id,
    cm_id,
    accn_id,
    subs_id,
    srvs_id,
    srvs_type,
    srvs_region,
    srvs_mr,
    srvs_tech,
    dt_start_srvs,
    sale_ch,
    srvs_member_id,
    tp_bandl,
    tp_full,
    tp_gr,
    SRVS_IPTV_CNT_SAN,
    SRVS_IPTV_CNT_MAC,
    dev_ls_on,
    dev_ls_on_cnt,
    LT_CSTM_SRVS_TYPE,
    TARIF_ZONE_ID,
    TRAF_IN_SHPD,
    TRAF_IN_MC_total,
    TRAF_IN_OTA,
    TRAF_IN_VZ,
    TRAF_IN_MG,
    TRAF_IN_MN,
    PROMO_STATUS,
    EFF_DTTM,
    EXP_DTTM,
    load_dttm,
    src_id
)
select  distinct
    mvno.MRF_ID as mrf_id -- Идентификатор МРФ клиента
    , coalesce('-'||mvno.ACCOUNT,'') as cm_id -- Внутренний идентификатор клиента (ID МРФ+ уникальный ID ЛС)
    , coalesce(mvno.ACCOUNT,'') as accn_id -- Идентификатор/номер лицевого счета (НЛС) по единой классификации
    , MVNO.subs_id::numeric as subs_id
    , MVNO.subs_id::numeric as srvs_id -- Уникальный идентификатор основной услуги
    , MVNO.SERV as srvs_type -- Тип услуги: ШПД, ОТА, ИТВ, MVNO
    , MVNO.DEF_SHORT as srvs_region -- РФ предоставления услуги
    , MVNO.DEF as srvs_mr -- МРФ предоставления услуги
    , 'Не определено' as srvs_tech -- Технология услуги
    , min_data_activ as dt_start_srvs -- Дата активации основной услуги
    , coalesce(mvno.chanel_sale, wc_map_subs.wc_channel_name,'Не определен')  as sale_ch -- Тип канала продаж (из классификатора)
    , coalesce(m1.cntct_mob,f1.cntct_fix,m2.cntct_mob,f2.cntct_fix,'') as srvs_member_id -- Логин основной услуги (прописывается в договоре, используется при активации услуги, отражается в том числе в ЕЛК). Для MVNO: мобильный номер телефона
    , '' as tp_bandl -- Текущий общий тариф (может быть бандлом с другими основными услугами, например, ""WEBIPTV Для абонентов ШПД РТ (Web)"")
    , coalesce(MVNO.RTPL_NAME,'') as tp_full -- Текущий тариф на основной услуге (полное название)(для ИТВ основн(ой)/ые пакет телеканалов)
    , '' as tp_gr -- Текущий тариф на основной услуге стандартизованный (группа тарифных планов)
    , 0 as SRVS_IPTV_CNT_SAN -- SAN приставки ИТВ
    , 0 as SRVS_IPTV_CNT_MAC -- MAC-адрес оборудования
    , 0 as dev_ls_on -- Признак аренды оборудования
    , 0 as dev_ls_on_cnt -- Количество арендованного оборудования
    , case when to_date(MVNO.period::varchar,'YYYYMM') + interval '1 month - 1 day' <  max_end_rtpl
    then date_part('day',(to_date(MVNO.period::varchar,'YYYYMM')+interval '1 month - 1 second') - min_data_activ)
    else date_part('day',date_trunc('DAY', max_end_rtpl) - date_trunc('DAY',min_data_activ))
    end as LT_CSTM_SRVS_TYPE
    , coalesce(OO_ADDRESS.TARIF_ZONE_ID::text,'') as TARIF_ZONE_ID -- Тарифная зона
    , 0 as TRAF_IN_SHPD
    , 0 as TRAF_IN_MC_total
    , 0 as TRAF_IN_OTA
    , 0 as TRAF_IN_VZ
    , 0 as TRAF_IN_MG
    , 0 as TRAF_IN_MN
    , 0 as PROMO_STATUS
    , to_date('20190601', 'YYYYMMDD') as EFF_DTTM
    , to_date('20190601', 'YYYYMMDD') + interval '1 month - 1 second' as EXP_DTTM
    , now() as load_dttm -- Дата последнего обновления данных
    , 000154 as src_id
FROM (
        select m.account, m.subs_id, 
            m.period, m.rf_id,
            m.mrf_id, m.RTPL_NAME,
            m.DATA_ACTIV, DIR_BRANCHES_2.DEF_SHORT,
            DIR_BRANCHES_1.DEF, DIR_SERVICES.DEF as SERV,
            max(coalesce(m.end_rtpl,to_date('29991231','YYYYMMDD'))) max_end_rtpl,
            min(coalesce(m.DATA_ACTIV,to_date('19000101','YYYYMMDD'))) min_data_activ,
            b2c_month.chanel_sale
        FROM edw_ods.t_000154_efftp_oo_eff_tp_mvno m 
        left join edw_ods.t_000158_rprt_dir_branches DIR_BRANCHES_1 on m.mrf_id = DIR_BRANCHES_1.brnc_id
        left join edw_ods.t_000158_rprt_dir_branches DIR_BRANCHES_2 on m.rf_id = DIR_BRANCHES_2.brnc_id 
        left join edw_ods.t_000158_rprt_dir_services dir_services on dir_services.serv_id = 6
        left join edw_ods.t_000171_v_soo_b2c_month b2c_month on m.subs_id = b2c_month.subs_id::varchar and b2c_month.tech_dt = to_date('20190601', 'YYYYMMDD')
        where m.account_ext is null and m.tech_dt = to_date('20190601', 'YYYYMMDD')
            and (m.account <> '596011156665' or m.subs_id not in ('1496944','1469407'))
        group by m.account, m.subs_id, 
            m.period, m.rf_id,
            m.mrf_id, m.RTPL_NAME,
            m.DATA_ACTIV, DIR_BRANCHES_2.DEF_SHORT,
            DIR_BRANCHES_1.DEF, DIR_SERVICES.DEF,
            b2c_month.chanel_sale
        )  MVNO
        left join (select accn_id, cntct_mob,row_number() over(partition by accn_id order by tech_dt desc) rn from edw_ods.t_000134_mob where type_mob = 'Основной' and tech_dt<to_date('20190601', 'YYYYMMDD') +interval '1 month - 1 second') m1 on MVNO.account = m1.accn_id and m1.rn=1
        left join (select accn_id, cntct_mob,row_number() over(partition by accn_id order by tech_dt desc) rn from edw_ods.t_000134_mob where type_mob = 'Альтернативный' and tech_dt<to_date('20190601', 'YYYYMMDD') +interval '1 month - 1 second') m2 on MVNO.account = m2.accn_id and m2.rn=1
        left join (select accn_id, cntct_fix,row_number() over(partition by accn_id order by tech_dt desc) rn from edw_ods.t_000134_fix where type_fix = 'Основной' and tech_dt<to_date('20190601', 'YYYYMMDD') +interval '1 month - 1 second') f1 on MVNO.account = f1.accn_id and f1.rn=1
        left join (select accn_id, cntct_fix,row_number() over(partition by accn_id order by tech_dt desc) rn from edw_ods.t_000134_fix where type_fix = 'Альтернативный' and tech_dt<to_date('20190601', 'YYYYMMDD') +interval '1 month - 1 second') f2 on MVNO.account = f2.accn_id and f2.rn=1
        left join (select wc_account as account, wc_channel_name, row_number() over (partition by wc_account order by period DESC) as rn from edw_ods.t_000158_efftp_wc_map_subs where wc_channel_name is not null) wc_map_subs on MVNO.account = wc_map_subs.account and wc_map_subs.rn=1
        left join (
                    select 
                        t1.abn_id,t1.MRF_ID,t1.date_begin,
                        coalesce(lead(t1.date_begin) over (partition by t1.abn_id order by t1.date_begin, t1.date_end)- interval '1 second',t1.date_end,'2999-12-31 00:00:00'::date) as DATE_END
                        ,t2.city,t2.house_lid,
                        t2.house_gid,t2.N_POSTOFFICE_ID,
                        t2.terr_type,t2.name_terr,
                        t2.CITY_LID,t2.CITY_GID,
                        t2.name_street_type,t2.shortname_street_type,
                        t2.name_street,t2.n_house,
                        t2.n_corpus,t2.ISPRIVATE,
                        t1.flat,t2.TARIF_ZONE_ID,
                        account
                    from edw_ods.t_000154_rprt_oo_addressabndwh t1
                    left join edw_ods.t_000154_rprt_oo_address t2 on t1.HOUSE_LID = t2.HOUSE_LID and t1.MRF_ID = t2.MRF_ID
                  ) OO_ADDRESS on MVNO.account = OO_ADDRESS.account
    and to_date(MVNO.period::varchar,'YYYYMM')+interval'1 month - 1 second' between OO_ADDRESS.DATE_BEGIN and OO_ADDRESS.DATE_END
;
commit;

analyze edw_stg_dmcm.tfct_ASRV_1_prt_p000154;
