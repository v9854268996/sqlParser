--rev.38945 от 30.09.2019
delete from edw_stg_mdm.put_xref_dim_house_class where src_id = 148;

insert into edw_stg_mdm.put_xref_dim_house_class
  ( 
    source_key ,
    source_name,
    load_dttm  ,
    src_id
  )
select distinct
  coalesce(n.rus_reg_dwelling_type_id, -1)                                                                                              as source_key ,
  decode(coalesce(n.rus_reg_dwelling_type_id, -1), 818788753, 'Эконом', 818788754, 'Комфорт', 818788755, 'Бизнес', -1, 'Не определено') as source_name,
  now()                                                                                                                                 as load_dttm  ,
  src_id
from
  edw_ods.T_000148_ent_object_ned as n
;

analyse edw_stg_mdm.put_xref_dim_house_class;
