/*rev.55847  23.04.2020 Changed by: MARIYA.PARAMEEVA */
truncate edw_stg_dds.t_000052_dim_partner;

insert into edw_stg_dds.t_000052_dim_partner 
	( 
		partner_key,
		parent_tax_number_cval,
		tax_number_cval,
		segment_key,
		branch_key,
		tax_reg_reason_cval,
		partner_full_name,
		doc_number_cval,
		src_id,
		load_dttm,
		eff_dttm,
		exp_dttm,
		start_date,
		end_date
	)
with
	dates as
(
	select 
		to_date(substr('20190630', 1, 8),'YYYYMMDD') + INTERVAL '1 day - 1 second' as end_date,
		substr('20190601', 1, 6)::int as month_id
),
	tu as 
(
	select round(t.user_type_id)::varchar user_type_id,round(t.user_id)user_id,round(t.dept_id)dept_id,round(t.dept_id)::varchar dept_id_,round(t.billing_id)billing_id,t.src_id from edw_ods.t_000048_t_saldo t join dates d on t.billing_id <= d.month_id and t.tech_dt <= d.end_date union all
	select round(t.user_type_id)::varchar user_type_id,round(t.user_id)user_id,round(t.dept_id)dept_id,round(t.dept_id)::varchar dept_id_,round(t.billing_id)billing_id,t.src_id from edw_ods.t_000049_t_saldo t join dates d on t.billing_id <= d.month_id and t.tech_dt <= d.end_date union all
	select round(t.user_type_id)::varchar user_type_id,round(t.user_id)user_id,round(t.dept_id)dept_id,round(t.dept_id)::varchar dept_id_,round(t.billing_id)billing_id,t.src_id from edw_ods.t_000050_t_saldo t join dates d on t.billing_id <= d.month_id and t.tech_dt <= d.end_date union all
	select round(t.user_type_id)::varchar user_type_id,round(t.user_id)user_id,round(t.dept_id)dept_id,round(t.dept_id)::varchar dept_id_,round(t.billing_id)billing_id,t.src_id from edw_ods.t_000051_t_saldo t join dates d on t.billing_id <= d.month_id and t.tech_dt <= d.end_date union all
	select round(t.user_type_id)::varchar user_type_id,round(t.user_id)user_id,round(t.dept_id)dept_id,round(t.dept_id)::varchar dept_id_,round(t.billing_id)billing_id,t.src_id from edw_ods.t_000052_t_saldo t join dates d on t.billing_id <= d.month_id and t.tech_dt <= d.end_date union all
	select round(t.user_type_id)::varchar user_type_id,round(t.user_id)user_id,round(t.dept_id)dept_id,round(t.dept_id)::varchar dept_id_,round(t.billing_id)billing_id,t.src_id from edw_ods.t_000053_t_saldo t join dates d on t.billing_id <= d.month_id and t.tech_dt <= d.end_date union all
	select round(t.user_type_id)::varchar user_type_id,round(t.user_id)user_id,round(t.dept_id)dept_id,round(t.dept_id)::varchar dept_id_,round(t.billing_id)billing_id,t.src_id from edw_ods.t_000054_t_saldo t join dates d on t.billing_id <= d.month_id and t.tech_dt <= d.end_date union all
	select round(t.user_type_id)::varchar user_type_id,round(t.user_id)user_id,round(t.dept_id)dept_id,round(t.dept_id)::varchar dept_id_,round(t.billing_id)billing_id,t.src_id from edw_ods.t_000055_t_saldo t join dates d on t.billing_id <= d.month_id and t.tech_dt <= d.end_date union all
	select round(t.user_type_id)::varchar user_type_id,round(t.user_id)user_id,round(t.dept_id)dept_id,round(t.dept_id)::varchar dept_id_,round(t.billing_id)billing_id,t.src_id from edw_ods.t_000056_t_saldo t join dates d on t.billing_id <= d.month_id and t.tech_dt <= d.end_date union all
	select round(t.user_type_id)::varchar user_type_id,round(t.user_id)user_id,round(t.dept_id)dept_id,round(t.dept_id)::varchar dept_id_,round(t.billing_id)billing_id,t.src_id from edw_ods.t_000057_t_saldo t join dates d on t.billing_id <= d.month_id and t.tech_dt <= d.end_date union all
	select round(t.user_type_id)::varchar user_type_id,round(t.user_id)user_id,round(t.dept_id)dept_id,round(t.dept_id)::varchar dept_id_,round(t.billing_id)billing_id,t.src_id from edw_ods.t_000058_t_saldo t join dates d on t.billing_id <= d.month_id and t.tech_dt <= d.end_date union all
	select round(t.user_type_id)::varchar user_type_id,round(t.user_id)user_id,round(t.dept_id)dept_id,round(t.dept_id)::varchar dept_id_,round(t.billing_id)billing_id,t.src_id from edw_ods.t_000059_t_saldo t join dates d on t.billing_id <= d.month_id and t.tech_dt <= d.end_date union all
	select round(t.user_type_id)::varchar user_type_id,round(t.user_id)user_id,round(t.dept_id)dept_id,round(t.dept_id)::varchar dept_id_,round(t.billing_id)billing_id,t.src_id from edw_ods.t_000060_t_saldo t join dates d on t.billing_id <= d.month_id and t.tech_dt <= d.end_date union all
	select round(t.user_type_id)::varchar user_type_id,round(t.user_id)user_id,round(t.dept_id)dept_id,round(t.dept_id)::varchar dept_id_,round(t.billing_id)billing_id,t.src_id from edw_ods.t_000061_t_saldo t join dates d on t.billing_id <= d.month_id and t.tech_dt <= d.end_date union all
	select round(t.user_type_id)::varchar user_type_id,round(t.user_id)user_id,round(t.dept_id)dept_id,round(t.dept_id)::varchar dept_id_,round(t.billing_id)billing_id,t.src_id from edw_ods.t_000062_t_saldo t join dates d on t.billing_id <= d.month_id and t.tech_dt <= d.end_date
),
	utr as 
(
	select round(tr.coef)coef,round(tr.user_type_id)::varchar user_type_id,tr.src_id from edw_ods.t_000048_t_user_type_ref tr join dates d on tr.deleted_ind = 0 AND d.end_date between tr.eff_dttm AND tr.exp_dttm union all
	select round(tr.coef)coef,round(tr.user_type_id)::varchar user_type_id,tr.src_id from edw_ods.t_000049_t_user_type_ref tr join dates d on tr.deleted_ind = 0 AND d.end_date between tr.eff_dttm AND tr.exp_dttm union all
	select round(tr.coef)coef,round(tr.user_type_id)::varchar user_type_id,tr.src_id from edw_ods.t_000050_t_user_type_ref tr join dates d on tr.deleted_ind = 0 AND d.end_date between tr.eff_dttm AND tr.exp_dttm union all
	select round(tr.coef)coef,round(tr.user_type_id)::varchar user_type_id,tr.src_id from edw_ods.t_000051_t_user_type_ref tr join dates d on tr.deleted_ind = 0 AND d.end_date between tr.eff_dttm AND tr.exp_dttm union all
	select round(tr.coef)coef,round(tr.user_type_id)::varchar user_type_id,tr.src_id from edw_ods.t_000052_t_user_type_ref tr join dates d on tr.deleted_ind = 0 AND d.end_date between tr.eff_dttm AND tr.exp_dttm union all
	select round(tr.coef)coef,round(tr.user_type_id)::varchar user_type_id,tr.src_id from edw_ods.t_000053_t_user_type_ref tr join dates d on tr.deleted_ind = 0 AND d.end_date between tr.eff_dttm AND tr.exp_dttm union all
	select round(tr.coef)coef,round(tr.user_type_id)::varchar user_type_id,tr.src_id from edw_ods.t_000054_t_user_type_ref tr join dates d on tr.deleted_ind = 0 AND d.end_date between tr.eff_dttm AND tr.exp_dttm union all
	select round(tr.coef)coef,round(tr.user_type_id)::varchar user_type_id,tr.src_id from edw_ods.t_000055_t_user_type_ref tr join dates d on tr.deleted_ind = 0 AND d.end_date between tr.eff_dttm AND tr.exp_dttm union all
	select round(tr.coef)coef,round(tr.user_type_id)::varchar user_type_id,tr.src_id from edw_ods.t_000056_t_user_type_ref tr join dates d on tr.deleted_ind = 0 AND d.end_date between tr.eff_dttm AND tr.exp_dttm union all
	select round(tr.coef)coef,round(tr.user_type_id)::varchar user_type_id,tr.src_id from edw_ods.t_000057_t_user_type_ref tr join dates d on tr.deleted_ind = 0 AND d.end_date between tr.eff_dttm AND tr.exp_dttm union all
	select round(tr.coef)coef,round(tr.user_type_id)::varchar user_type_id,tr.src_id from edw_ods.t_000058_t_user_type_ref tr join dates d on tr.deleted_ind = 0 AND d.end_date between tr.eff_dttm AND tr.exp_dttm union all
	select round(tr.coef)coef,round(tr.user_type_id)::varchar user_type_id,tr.src_id from edw_ods.t_000059_t_user_type_ref tr join dates d on tr.deleted_ind = 0 AND d.end_date between tr.eff_dttm AND tr.exp_dttm union all
	select round(tr.coef)coef,round(tr.user_type_id)::varchar user_type_id,tr.src_id from edw_ods.t_000060_t_user_type_ref tr join dates d on tr.deleted_ind = 0 AND d.end_date between tr.eff_dttm AND tr.exp_dttm union all
	select round(tr.coef)coef,round(tr.user_type_id)::varchar user_type_id,tr.src_id from edw_ods.t_000061_t_user_type_ref tr join dates d on tr.deleted_ind = 0 AND d.end_date between tr.eff_dttm AND tr.exp_dttm union all
	select round(tr.coef)coef,round(tr.user_type_id)::varchar user_type_id,tr.src_id from edw_ods.t_000062_t_user_type_ref tr join dates d on tr.deleted_ind = 0 AND d.end_date between tr.eff_dttm AND tr.exp_dttm 
),
	hub as 
(
	select h.source_key::varchar,h.branch_key,h.src_id from edw_dds.hub_dim_branch h join dates d ON h.src_id between 48 and 62 AND d.end_date between h.eff_dttm AND h.exp_dttm
),	
	ttr as
( 
	SELECT 
		tu.user_type_id, 
		tu.user_id, 
		tu.dept_id, 
		tu.billing_id,
		utr.coef,
		hub.branch_key,
		tu.src_id
	FROM 
		tu
		LEFT JOIN utr 
			ON 1 = 1
			and utr.user_type_id = tu.user_type_id
			and utr.src_id = tu.src_id
		LEFT JOIN hub 
			ON 1 = 1
			and tu.dept_id_ = hub.source_key
			AND hub.src_id = tu.src_id
),
	t_saldo as 
(
	select	
		sl.*,
		coalesce(decode(sl.billing_id,sl.min_billing_id,to_date('19000101', 'YYYYMMDD')),billing_id_) start_date,
		coalesce(decode(sl.billing_id,sl.max_billing_id,to_date('29991231', 'YYYYMMDD')),billing_id_ + interval '1 month - 1 day') end_date
	from 
		(		
		select 
			round(s.user_type_id)::varchar user_type_id,
			round(s.billing_id)billing_id,
			to_date(s.billing_id::varchar, 'YYYYMM') billing_id_,
			round(s.dept_id)dept_id,
			s.user_id,
			max(s.billing_id) over (PARTITION BY s.user_id) as max_billing_id,
			min(s.billing_id) over (PARTITION BY s.user_id) as min_billing_id 
		from 
			edw_ods.t_000052_t_saldo s
			join dates d
				on 1 = 1
				and s.billing_id <= d.month_id
				and s.tech_dt <= end_date
		)sl
),
	t_users as 
(
	select 
		u.user_id,
		round(u.dept_id)dept_id,
		u.user_type_id::varchar,
		u.chief_user_id,
		u.inn,
		u.kpp,
		u.name,
		u.document_text,
		u.src_id,
		u.eff_dttm,
		u.exp_dttm
	from 
		edw_ods.t_000052_t_users u
		join dates d 
			on 1 = 1  
            and d.end_date +  interval '7'  between u.eff_dttm and u.exp_dttm
			and u.deleted_ind = 0
),
	t_chief_users as 
(
	select 
		u.user_id,
		u.inn
	from 
		edw_ods.t_000052_t_users u
		join dates d 
			on 1 = 1
			and u.deleted_ind = 0
			and d.end_date +  interval '7'  between u.eff_dttm and u.exp_dttm
),
	t_vip_sp as 
(
	select 
		round(sp.user_id_sp) as user_id_sp,
		round(v.user_id_vip) as user_id_vip,
		round(sp.dept_id_vip) as dept_id_vip,
		round(sp.dept_id_vip)::text dept_id_vip_,
		case 
			when coalesce(v.date_begin,to_date('19000101','YYYYMMDD')) = min(coalesce(v.date_begin,to_date('19000101','YYYYMMDD'))) over (PARTITION BY v.user_id_sp) 
				then to_date('19000101','YYYYMMDD')
				else coalesce(v.date_begin,to_date('19000101','YYYYMMDD')) 
		end as date_begin_v2,
		case 
			when coalesce(v.date_end,to_date('29991231','YYYYMMDD')) = max(coalesce(v.date_end,to_date('29991231','YYYYMMDD'))) over (PARTITION BY v.user_id_sp) 
				then to_date('29991231','YYYYMMDD') 
				else coalesce(v.date_end,to_date('29991231','YYYYMMDD')) 
		end as date_end_v2
	from 
		edw_ods.t_000052_t_vip_sp sp
		join 
			(select 
				v.user_id_vip,
				v.user_id_sp,
				v.date_begin,
				v.date_end,
				row_number() over (partition by USER_ID_VIP, DEPT_ID_SP, USER_ID_SP order by date_begin desc) as rn 
			from edw_ods.t_000052_t_vip v 
				join dates d 
					on 1 = 1
					and d.end_date between v.eff_dttm and v.exp_dttm 
					and v.deleted_ind = 0
			)v
			on 1 = 1
			and sp.user_id_sp = v.user_id_sp 
			and sp.deleted_ind = 0
			and v.rn = 1 
		join dates d
			on 1 = 1
			and d.end_date between sp.eff_dttm and sp.exp_dttm
),
	main as
(
	select 
		tu.user_id as partner_key,
		tcu.inn as parent_tax_number_cval,
		tu.inn as tax_number_cval,
		coalesce(ttr.user_type_id,s.user_type_id,tu.user_type_id, 'ND_EKHD') as segment_key, -- old: coalesce(round(s.user_type_id)::varchar, tu.user_type_id::varchar, 'ND_EKHD') as segment_key,
		coalesce(s.dept_id,tu.dept_id) as branch_key,
		tu.kpp as tax_reg_reason_cval,
		tu.name as partner_full_name,
		tu.document_text as doc_number_cval,
		tu.src_id as src_id,
		coalesce(s.start_date, to_date('19000101','YYYYMMDD')) as start_date,
		coalesce(s.end_date, to_date('29991231','YYYYMMDD')) + interval '1 day - 1 second' as end_date	
	from 
		t_users tu
		left join t_saldo s
			on 1 = 1
			and tu.user_id = s.user_id 
		left join t_chief_users tcu
			on 1 = 1
			and tcu.user_id = tu.chief_user_id 
		left join t_vip_sp tvs
			on 1 = 1
			and tu.user_id = tvs.user_id_sp 
			and s.billing_id_ between tvs.date_begin_v2 and tvs.date_end_v2
		left join hub 
			on 1 = 1
			and tvs.dept_id_vip_ = hub.source_key
			and tu.src_id=hub.src_id
		left join ttr
			on  ttr.user_id = tvs.user_id_vip
			and hub.branch_key = ttr.branch_key
			and s.billing_id = ttr.billing_id
)	
select
	partner_key,
	parent_tax_number_cval,
	tax_number_cval,
	segment_key,
	branch_key,
	tax_reg_reason_cval,
	partner_full_name,
	doc_number_cval,
	src_id,
	now() as load_dttm,
	start_date eff_dttm,
	case when date_trunc('day',end_date) = to_date('29991231','YYYYMMDD')
		 then date_trunc('day',end_date)::timestamp 
		 else end_date 
	end as exp_dttm,
	start_date,
	case when date_trunc('day',end_date) = to_date('29991231','YYYYMMDD')
		 then date_trunc('day',end_date)::timestamp 
		 else end_date 
	end as end_date
from
	main
;

commit;

analyze edw_stg_dds.t_000052_dim_partner
;