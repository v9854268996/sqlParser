/*rev. 29.10.2019 Changed by: NAREK.ALAVERDYAN */
TRUNCATE TABLE edw_stg_dds.t_000207_tfct_total_charge_source;

INSERT INTO edw_stg_dds.t_000207_tfct_total_charge_source
	(
		nach_id ,
		user_id ,
		dev_id ,
		billing_id ,
		svc_id ,
		svc_nmb ,
		summ ,
		tax ,
		vat_rub ,
		sum_total ,
		svc_date ,
		price_plan ,
		service_id ,
		sub_make ,
		business_service ,
		technology_type_name ,
		t_name ,
		VND ,
		rcode
	) 
SELECT
	nach_id ,
	user_id ,
	dev_id ,
	billing_id ,
	svc_id ,
	svc_nmb ,
	summ ,
	tax ,
	vat_rub ,
	sum_total ,
	svc_date ,
	price_plan ,
	service_id ,
	sub_make ,
	business_service ,
	technology_type_key ,
	t_name ,
	VND ,
	rcode
FROM (
		SELECT
			'1#' || ROUND(tts.billing_id)|| '#' || ROUND(tts.service_id)|| '#' || ROUND(tts.svc_id)|| '#' || ROUND(tts.user_id)|| '#' || COALESCE(ROUND(tts.day_coef),-1) AS nach_id,
			ROUND(tts.user_id) AS user_id,
			COALESCE((ROUND(ts.dev_id))::TEXT, ts.phone, '0') AS dev_id,
			ROUND(tts.billing_id) AS billing_id,
			ROUND(tts.svc_id) AS svc_id,
			ROUND(tts.svc_nmb) AS svc_nmb,
			tts.summ,
			tts.tax,
			tts.tax AS vat_rub,
			tts.summ - tts.tax AS sum_total,
			CAST( (TO_DATE(tts.billing_id::TEXT, 'YYYYMM') + INTERVAL '1 MONTH - 1 day') AS DATE) AS svc_date,
			-1 AS price_plan,
			ROUND(tts.service_id) AS service_id,
			CASE
				WHEN ts.sub_make = 1 THEN 1
				ELSE 0
			END AS sub_make,
			et.business_service_key AS business_service,
			et.technology_type_key,
			't_tarifed_services' AS t_name,
			1 AS VND,
			dim_segment.segment_name || '#' || xref.rcode_asr AS rcode
		FROM edw_ods.t_000207_t_tarifed_services tts
		LEFT JOIN edw_stg_dds.t_dim_service_xref_start xref ON
			xref.source_key = ROUND(tts.svc_id)::TEXT
			AND TO_DATE(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second' BETWEEN xref.eff_dttm AND xref.exp_dttm
			AND xref.region_id = 'BASH'
		LEFT JOIN edw_dds.dim_service et ON
			et.service_key = xref.service_key
			AND TO_DATE(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second' BETWEEN et.eff_dttm AND et.exp_dttm
		LEFT JOIN (
				SELECT
					xref.sub_make ,
					ts.service_id ,
					ts.dev_id ,
					ts.phone ,
					ts.date_end
				FROM
					edw_ods.t_000207_t_services ts
				LEFT JOIN edw_stg_dds.t_dim_service_xref_start xref ON
					xref.source_key = ROUND(ts.svc_id)::TEXT
					AND TO_DATE('20190601', 'YYYYMMDD') + INTERVAL '1 MONTH - 1 second' BETWEEN xref.eff_dttm AND xref.exp_dttm
				WHERE
					ts.DELETED_IND <> 1
					AND TO_DATE('20190630', 'YYYYMMDD') + INTERVAL '1 day - 1 second' BETWEEN ts.eff_dttm AND ts.exp_dttm 
			) ts
		ON ROUND(tts.service_id) = ROUND(ts.service_id)
		JOIN edw_stg_dds.t_000207_dim_account dim_account ON
			000207 || '#' || ROUND(tts.user_id) = dim_account.account_key
			AND 000207 = dim_account.src_id
			AND TO_DATE(TRUNC(tts.billing_id)::TEXT, 'YYYYMMDD') + INTERVAL '1 MONTH - 1 second' BETWEEN dim_account.eff_dttm AND dim_account.exp_dttm
			AND TO_DATE(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second' BETWEEN dim_account.eff_dttm AND dim_account.exp_dttm
		JOIN edw_stg_dds.t_000207_dim_partner dim_partner ON
			dim_account.partner_key = dim_partner.partner_key
			AND dim_account.src_id = dim_partner.src_id
			AND TO_DATE(TRUNC(tts.billing_id)::TEXT, 'YYYYMMDD') + INTERVAL '1 MONTH - 1 second' BETWEEN dim_partner.eff_dttm AND dim_partner.exp_dttm
			AND TO_DATE(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second' BETWEEN dim_partner.eff_dttm AND dim_partner.exp_dttm
		LEFT JOIN edw_dds.hub_dim_segment hub_dim_segment ON
			hub_dim_segment.source_key = dim_partner.segment_key
			AND hub_dim_segment.src_id = dim_partner.src_id
			AND TO_DATE(TRUNC(tts.billing_id)::TEXT, 'YYYYMMDD') + INTERVAL '1 MONTH - 1 second' BETWEEN hub_dim_segment.eff_dttm AND hub_dim_segment.exp_dttm
			AND TO_DATE(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second' BETWEEN hub_dim_segment.eff_dttm AND hub_dim_segment.exp_dttm
		LEFT JOIN edw_dds.dim_segment dim_segment ON
			dim_segment.segment_key = hub_dim_segment.segment_key
			AND dim_segment.deleted_ind = 0
			AND TO_DATE(TRUNC(tts.billing_id)::TEXT, 'YYYYMMDD') + INTERVAL '1 MONTH - 1 second' BETWEEN dim_segment.eff_dttm AND dim_segment.exp_dttm
			AND TO_DATE(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second' BETWEEN dim_segment.eff_dttm AND dim_segment.exp_dttm
		WHERE
			ROUND(tts.billing_id) = substr('20190601', 1, 6)::INT
			AND tts.tech_dt <= TO_DATE(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second' 
	) s
;
------------------------------------------------------------------------
 /*Начисления из t_other_svc*/
INSERT INTO edw_stg_dds.t_000207_tfct_total_charge_source
(
	nach_id ,
	user_id ,
	dev_id ,
	billing_id ,
	svc_id ,
	svc_nmb ,
	summ ,
	tax ,
	vat_rub ,
	sum_total ,
	svc_date ,
	price_plan ,
	service_id ,
	sub_make ,
	business_service ,
	technology_type_name ,
	t_name ,
	VND ,
	rcode
)
SELECT
	nach_id ,
	user_id ,
	dev_id ,
	billing_id ,
	svc_id ,
	svc_nmb ,
	summ ,
	tax ,
	vat_rub ,
	sum_total ,
	svc_date ,
	price_plan ,
	service_id ,
	sub_make ,
	business_service ,
	technology_type_key ,
	t_name ,
	VND ,
	rcode
FROM (
		SELECT
			'2' || '#' || ROUND(tos.oth_svc_id) AS nach_id,
			ROUND(tos.user_id) user_id,
			COALESCE(tos.phone, '0') AS dev_id,
			ROUND(tos.billing_id) billing_id,
			ROUND(tos.svc_id) svc_id,
			ROUND(tos.svc_nmb) svc_nmb,
			tos.summ,
			tos.tax,
			tos.tax AS vat_rub,
			tos.summ - tos.tax AS sum_total,
			(
			CASE
				WHEN DATE_TRUNC('month', tos.svc_date) < TO_DATE(tos.billing_id::TEXT, 'YYYYMM') THEN CAST(TO_DATE(tos.billing_id::TEXT, 'YYYYMM') AS DATE)
				WHEN DATE_TRUNC('month', tos.svc_date) > TO_DATE(tos.billing_id::TEXT, 'YYYYMM') THEN CAST( (TO_DATE(tos.billing_id::TEXT, 'YYYYMM') + INTERVAL '1 MONTH - 1 day') AS DATE )
				ELSE tos.svc_date
			END ) AS svc_date,
			-1 AS price_plan,
			-1 AS service_id,
			0 AS sub_make,
			et.business_service_key AS business_service,
			et.technology_type_key,
			't_other_svc' AS t_name,
			CASE
				WHEN COALESCE(tos.vnd_id, 1) IN (1,
				2199239,
				525862019,
				525919986,
				200,
				4375276,
				3528867,
				3816572,
				70409327,
				70409345,
				70410991) THEN 1
				ELSE 0
			END AS VND,
			dim_segment.segment_name || '#' || xref.rcode_asr AS rcode
		FROM edw_ods.t_000207_t_other_svc tos
		LEFT JOIN edw_stg_dds.t_dim_service_xref_start xref ON
			xref.source_key = ROUND(tos.svc_id)::TEXT
			AND TO_DATE(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second' BETWEEN xref.eff_dttm AND xref.exp_dttm
			AND xref.region_id = 'BASH'
		LEFT JOIN edw_dds.dim_service et ON
			et.service_key = xref.service_key
			AND TO_DATE(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second' BETWEEN et.eff_dttm AND et.exp_dttm
		JOIN edw_stg_dds.t_000207_dim_account dim_account ON
			000207 || '#' || ROUND(tos.user_id) = dim_account.account_key
			AND 000207 = dim_account.src_id
			AND TO_DATE(TRUNC(tos.billing_id)::TEXT, 'YYYYMMDD') + INTERVAL '1 MONTH - 1 second' BETWEEN dim_account.eff_dttm AND dim_account.exp_dttm
			AND TO_DATE(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second' BETWEEN dim_account.eff_dttm AND dim_account.exp_dttm
		JOIN edw_stg_dds.t_000207_dim_partner dim_partner ON
			dim_account.partner_key = dim_partner.partner_key
			AND dim_account.src_id = dim_partner.src_id
			AND TO_DATE(TRUNC(tos.billing_id)::TEXT, 'YYYYMMDD') + INTERVAL '1 MONTH - 1 second' BETWEEN dim_partner.eff_dttm AND dim_partner.exp_dttm
			AND TO_DATE(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second' BETWEEN dim_partner.eff_dttm AND dim_partner.exp_dttm
		LEFT JOIN edw_dds.hub_dim_segment hub_dim_segment ON
			hub_dim_segment.source_key = dim_partner.segment_key
			AND hub_dim_segment.src_id = dim_partner.src_id
			AND TO_DATE(TRUNC(tos.billing_id)::TEXT, 'YYYYMMDD') + INTERVAL '1 MONTH - 1 second' BETWEEN hub_dim_segment.eff_dttm AND hub_dim_segment.exp_dttm
			AND TO_DATE(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second' BETWEEN hub_dim_segment.eff_dttm AND hub_dim_segment.exp_dttm
		LEFT JOIN edw_dds.dim_segment dim_segment ON
			dim_segment.segment_key = hub_dim_segment.segment_key
			AND dim_segment.deleted_ind = 0
			AND TO_DATE(TRUNC(tos.billing_id)::TEXT, 'YYYYMMDD') + INTERVAL '1 MONTH - 1 second' BETWEEN dim_segment.eff_dttm AND dim_segment.exp_dttm
			AND TO_DATE(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second' BETWEEN dim_segment.eff_dttm AND dim_segment.exp_dttm
		WHERE
			ROUND(tos.billing_id) = substr('20190601', 1, 6)::INT
			AND tos.tech_dt <= TO_DATE(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second' 
	) s
;
------------------------------------------------------------------------
 /*Начисления из t_svc_correction*/
INSERT INTO edw_stg_dds.t_000207_tfct_total_charge_source
(
	nach_id ,
	user_id ,
	dev_id ,
	billing_id ,
	svc_id ,
	svc_nmb ,
	summ ,
	tax ,
	vat_rub ,
	sum_total ,
	svc_date ,
	price_plan ,
	service_id ,
	sub_make ,
	business_service ,
	technology_type_name ,
	t_name ,
	VND ,
	rcode
)
SELECT
	nach_id ,
	user_id ,
	dev_id ,
	billing_id ,
	svc_id ,
	svc_nmb ,
	summ ,
	tax ,
	vat_rub ,
	sum_total ,
	svc_date ,
	price_plan ,
	service_id ,
	sub_make ,
	business_service ,
	technology_type_key ,
	t_name ,
	VND ,
	rcode
FROM (
		SELECT
			'3' || '#' || ROUND(tsc.corr_id) AS nach_id,
			ROUND(tsc.user_id) user_id,
			COALESCE((ROUND(ts.dev_id))::TEXT, ts.phone, '0') AS dev_id,
			ROUND(tsc.billing_id) billing_id,
			ROUND(tsc.svc_id) svc_id,
			ROUND(ts.svc_nmb) svc_nmb,
			tsc.summ,
			tsc.tax,
			DECODE(tsc.svc_corr_type::INT, 1,-1, 2,-1, 1)*(tsc.TAX) AS vat_rub,
			DECODE(tsc.svc_corr_type::INT, 1,-1, 2,-1, 1)*(tsc.summ - tsc.tax) AS sum_total,
			(
			CASE
				WHEN DATE_TRUNC('month', tsc.cdate) < DATE_TRUNC('month', TO_DATE(tsc.billing_id::TEXT, 'YYYYMM') ) THEN CAST(TO_DATE(tsc.billing_id::TEXT, 'YYYYMM') AS DATE)
				WHEN DATE_TRUNC('month', tsc.cdate) > TO_DATE(tsc.billing_id::TEXT, 'YYYYMM') THEN CAST( (TO_DATE(tsc.billing_id::TEXT, 'YYYYMM') + INTERVAL '1 MONTH - 1 day') AS DATE )
				ELSE tsc.cdate
			END ) AS svc_date,
			-1 AS price_plan,
			ROUND(tsc.service_id) service_id,
			CASE
				WHEN ts.sub_make = 1 THEN 1
				ELSE 0
			END AS sub_make,
			et.business_service_key AS business_service,
			et.technology_type_key,
			't_svc_correction' AS t_name,
			CASE
				WHEN COALESCE(tsc.vnd_id, 1) IN (1,
				2199239,
				525862019,
				525919986,
				200,
				4375276,
				3528867,
				3816572,
				70409327,
				70409345,
				70410991) THEN 1
				ELSE 0
			END AS VND,
			dim_segment.segment_name || '#' || xref.rcode_asr AS rcode
		FROM edw_ods.t_000207_t_svc_correction tsc
		LEFT JOIN edw_stg_dds.t_dim_service_xref_start xref ON
			xref.source_key = ROUND(tsc.svc_id)::TEXT
			AND TO_DATE(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second' BETWEEN xref.eff_dttm AND xref.exp_dttm
			AND xref.region_id = 'BASH'
		LEFT JOIN edw_dds.dim_service et ON
			et.service_key = xref.service_key
			AND TO_DATE(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second' BETWEEN et.eff_dttm AND et.exp_dttm
		LEFT JOIN (
				SELECT
					xref.sub_make ,
					ts.service_id ,
					ts.dev_id ,
					ts.phone ,
					ts.svc_nmb
				FROM edw_ods.t_000207_t_services ts
				LEFT JOIN edw_stg_dds.t_dim_service_xref_start xref ON
					xref.source_key = ROUND(ts.svc_id)::TEXT
					AND TO_DATE(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second' BETWEEN xref.eff_dttm AND xref.exp_dttm
					AND xref.region_id = 'BASH'
				WHERE
					TO_DATE(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second' BETWEEN ts.eff_dttm AND ts.exp_dttm
			) ts
		ON ROUND(tsc.service_id) = ROUND(ts.service_id)
		JOIN edw_stg_dds.t_000207_dim_account dim_account ON
			000207 || '#' || ROUND(tsc.user_id) = dim_account.account_key
			AND 000207 = dim_account.src_id
			AND TO_DATE(TRUNC(tsc.billing_id)::TEXT, 'YYYYMMDD') + INTERVAL '1 MONTH - 1 second' BETWEEN dim_account.eff_dttm AND dim_account.exp_dttm
			AND TO_DATE(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second' BETWEEN dim_account.eff_dttm AND dim_account.exp_dttm
		JOIN edw_stg_dds.t_000207_dim_partner dim_partner ON
			dim_account.partner_key = dim_partner.partner_key
			AND dim_account.src_id = dim_partner.src_id
			AND TO_DATE(TRUNC(tsc.billing_id)::TEXT, 'YYYYMMDD') + INTERVAL '1 MONTH - 1 second' BETWEEN dim_partner.eff_dttm AND dim_partner.exp_dttm
			AND TO_DATE(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second' BETWEEN dim_partner.eff_dttm AND dim_partner.exp_dttm
		LEFT JOIN edw_dds.hub_dim_segment hub_dim_segment ON
			hub_dim_segment.source_key = dim_partner.segment_key
			AND hub_dim_segment.src_id = dim_partner.src_id
			AND TO_DATE(TRUNC(tsc.billing_id)::TEXT, 'YYYYMMDD') + INTERVAL '1 MONTH - 1 second' BETWEEN hub_dim_segment.eff_dttm AND hub_dim_segment.exp_dttm
			AND TO_DATE(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second' BETWEEN hub_dim_segment.eff_dttm AND hub_dim_segment.exp_dttm
		LEFT JOIN edw_dds.dim_segment dim_segment ON
			dim_segment.segment_key = hub_dim_segment.segment_key
			AND dim_segment.deleted_ind = 0
			AND TO_DATE(TRUNC(tsc.billing_id)::TEXT, 'YYYYMMDD') + INTERVAL '1 MONTH - 1 second' BETWEEN dim_segment.eff_dttm AND dim_segment.exp_dttm
			AND TO_DATE(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second' BETWEEN dim_segment.eff_dttm AND dim_segment.exp_dttm
		WHERE 1 = 1
			AND ROUND(tsc.billing_id) = COALESCE( tsc.error_billing_id , TO_CHAR(TO_DATE(cdate::TEXT, 'YYYYMMDD'), 'YYYYMM')::INT , tsc.billing_id )
			AND ROUND(tsc.billing_id) = substr('20190601', 1, 6)::INT
			AND tsc.tech_dt <= TO_DATE(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second'
	) s
;

ANALYZE edw_stg_dds.t_000207_tfct_total_charge_source;

COMMIT;
------------------------------------------------------------------------

 /*Загрузка начислений в edw_stg_dds.TFCT_TOTAL_CHARGE*/
TRUNCATE TABLE edw_stg_dds.t_000207_tfct_total_charge;

INSERT INTO edw_stg_dds.t_000207_tfct_total_charge
( 
	total_charge_key ,
	account_key ,
	subs_key ,
	charge_period_start_dttm ,
	charge_rub ,
	billing_id ,
	vat_rub ,
	service_key ,
	price_plan_key ,
	service_user_key ,
	charge_date ,
	src_id ,
	load_dttm ,
	eff_dttm ,
	exp_dttm ,
	rc_key
)
SELECT
	dd.nach_id AS total_charge_key,
	dd.src_id::TEXT || '#' || dd.account_key AS account_key,
	dd.subs_key,
	dd.charge_period_start_dttm,
	dd.sum_total AS charge_rub,
	dd.billing_id,
	dd.vat_rub AS vat_rub,
	dd.svc_id AS service_key,
	dd.price_plan AS price_plan_key,
	dd.service_user_key,
	CAST((CAST(svc_date AS VARCHAR(20))) AS DATE) AS charge_date,
	dd.src_id,
	NOW() AS load_dttm,
	CAST('19000101' AS TIMESTAMP(0) WITHOUT TIME ZONE) AS eff_dttm,
	CAST('29991231' AS TIMESTAMP(0) WITHOUT TIME ZONE) AS exp_dttm,
	rc_key
FROM (
		SELECT
			s.nach_id,
			s.user_id || '#' || '0' AS service_user_key,
			TO_DATE(s.billing_id::TEXT, 'YYYYMM') AS charge_period_start_dttm,
			s.svc_id,
			s.svc_nmb,
			s.summ,
			s.tax,
			s.sum_total,
			s.billing_id,
			s.vat_rub,
			s.svc_date,
			s.service_id,
			s.sub_make,
			s.business_service,
			s.t_name,
			000207 AS src_id,
			-1 AS price_plan,
			b2.subs_key,
			s.user_id AS account_key,
			ROW_NUMBER() OVER (PARTITION BY s.nach_id ORDER BY
															CASE
																WHEN ( s.sub_make::INT = 1
																AND s.service_id::TEXT = b2.service_id
																AND s.svc_date BETWEEN b2.start_date AND b2.end_date
																AND s.business_service = b2.business_service::TEXT ) THEN 1
																WHEN ( s.sub_make::INT = 1
																AND s.service_id::TEXT = b2.service_id
																AND DATE_TRUNC('month', svc_date) BETWEEN DATE_TRUNC('month', b2.start_date) AND DATE_TRUNC('month', b2.end_date)
																AND s.business_service = b2.business_service::TEXT ) THEN 2
																WHEN ( s.sub_make::INT = 0
																AND s.dev_id = b2.subs_code
																AND s.technology_type_name = b2.technology_type_name::TEXT
																AND s.svc_date BETWEEN b2.start_date AND b2.end_date
																AND s.business_service = b2.business_service::TEXT ) THEN 3
																WHEN ( s.sub_make::INT = 0
																AND (s.dev_id = b2.subs_code)
																AND s.technology_type_name = b2.technology_type_name::TEXT
																AND DATE_TRUNC('month', svc_date) BETWEEN DATE_TRUNC('month', b2.start_date) AND DATE_TRUNC('month', b2.end_date)
																AND s.business_service = b2.business_service::TEXT ) THEN 4
																WHEN ( s.sub_make::INT = 0
																AND (s.dev_id = b2.subs_code)
																AND s.svc_date BETWEEN b2.start_date AND b2.end_date
																AND s.business_service = b2.business_service::TEXT ) THEN 5
																WHEN ( s.sub_make::INT = 0
																AND (s.dev_id = b2.subs_code)
																AND DATE_TRUNC('month', svc_date) BETWEEN DATE_TRUNC('month', b2.start_date) AND DATE_TRUNC('month', b2.end_date)
																AND s.business_service = b2.business_service::TEXT ) THEN 6
																WHEN ( s.sub_make::INT = 0
																AND s.svc_date BETWEEN b2.start_date AND b2.end_date
																AND s.business_service = b2.business_service::TEXT ) THEN 7
																WHEN ( s.sub_make::INT = 0
																AND DATE_TRUNC('month', svc_date) BETWEEN DATE_TRUNC('month', b2.start_date) AND DATE_TRUNC('month', b2.end_date)
																AND s.business_service = b2.business_service::TEXT ) THEN 8
																ELSE 99999
															END ASC 
								) AS key1, -- ключ уникальности начисления
			rcode AS rc_key
		FROM edw_stg_dds.t_000207_tfct_total_charge_source s
		LEFT JOIN (
				SELECT
					b2.*,
					et.technology_type_key AS technology_type_name,
					et.business_service_key AS business_service
				FROM edw_stg_dds.t_000207_dim_subs b2
				LEFT JOIN edw_stg_dds.t_dim_service_xref_start xref ON
					xref.source_key = b2.service_key
					AND TO_DATE(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second' BETWEEN xref.eff_dttm AND xref.exp_dttm
					AND xref.region_id = 'BASH'
				LEFT JOIN edw_dds.dim_service et ON
					et.service_key = xref.service_key
					AND TO_DATE(substr('20190630', 1, 8), 'YYYYMMDD') + INTERVAL '1 day - 1 second' BETWEEN et.eff_dttm AND et.exp_dttm 
			) b2
		ON 1=1
			AND 000207::TEXT || '#' || s.user_id = b2.account_key::TEXT
			AND s.business_service = b2.business_service::TEXT
			AND DATE_TRUNC('month', svc_date) BETWEEN DATE_TRUNC('month', b2.start_date) AND DATE_TRUNC('month', b2.end_date) 
		WHERE S.vnd = 1
	) dd
WHERE
	key1 = 1 ;

ANALYZE edw_stg_dds.t_000207_tfct_total_charge;

COMMIT;
	