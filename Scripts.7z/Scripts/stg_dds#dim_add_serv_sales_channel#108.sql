/*rev. х от 07.02.2020*/

truncate table edw_stg_dds.t_000108_dim_add_serv_sales_channel;

insert into edw_stg_dds.t_000108_dim_add_serv_sales_channel
(
    add_serv_sc_key
    , start_date
    , oper_id
    , oper_name
    , mrf_service_key
    , product_name
    , mrf_add_service_name
    , account_name
    , service_key
    , dop_service_key
    , sales_channel_key
    , sales_channel
    , init_system
    , branch_key
    , src_id
)
select service_id
    , dt_from
    , oper_id
    , oper_login
    , svc_id
    , upc_code
    , srv_name
    , account ::numeric
    , svc_id
    , svc_id
    , case
          when chan_sales is null then '-2'
          else regexp_replace(trim(upper(chan_sales)),'[ ]+',' ','g')
      end as chan_sales
    , chan_sales
    , order_creater
    , rf
    , 000108
from (
        select '1#'||service_id as service_id
            , dt_from
            , oper_id
            , oper_login
            , svc_id
            , upc_code
            , srv_name
            , account ::numeric
            , chan_sales
            , order_creater
            , rf ::numeric as rf
            , src_id
            , dat
            , row_number() over(partition by service_id order by tech_dt desc) rn
        from  edw_ods.t_000108_v_case_antivirus
      ) prev
where rn = 1;
commit;

analyze edw_stg_dds.t_000108_dim_add_serv_sales_channel;
