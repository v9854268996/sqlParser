/*rev.33234 12.07.2019*/

TRUNCATE TABLE edw_stg_dds.t_000005_dim_contract;
INSERT INTO edw_stg_dds.t_000005_dim_contract
(contract_key
, partner_key
, account_key
, parent_contract_key
, contract_cancellation_dt
, contract_cval
, src_id
, load_dttm
, eff_dttm
, exp_dttm

)
SELECT 
    c.contract_id as cotract_key
    , round(c.user_id)::text  partner_key
    , c.src_id || '#'|| round(c.user_id) account_key
    , null parent_contract_key
    , c.dateend contract_cancellation_dt
    , c.nmb contract_cval 
	, c.src_id
	, now()
	, c.eff_dttm
	, c.exp_dttm

  FROM edw_ods.t_000005_o_contract c 
 INNER JOIN edw_stg_dds.t_000005_dim_account da 
    ON c.src_id = da.src_id
   AND c.src_id||'#'||round(c.user_id)::text = da.account_key
   AND da.deleted_ind = 0
   AND da.eff_dttm <= to_date('20190630','YYYYMMDD')
   AND da.exp_dttm >= to_date('20190630','YYYYMMDD')
 WHERE 1=1 
   AND c.eff_dttm <= to_date('20190630','YYYYMMDD')
   AND c.exp_dttm >= to_date('20190630','YYYYMMDD');

 
ANALYZE edw_stg_dds.t_000005_dim_contract;