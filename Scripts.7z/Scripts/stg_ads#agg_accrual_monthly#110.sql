/*rev.34457 30.07.2019 Changed by: NAREK.ALAVERDYAN */
		-- Charges Monthly Aggregate
		truncate table edw_stg_ads.agg_accrual_monthly_1_prt_p000110 ;
		insert into edw_stg_ads.agg_accrual_monthly_1_prt_p000110
		(
			calendar_key,
			year_month_key,
			adjust_period,
			adjust_type_key,
			center_num_key,
			duty_num_key,
			service_key,
			frequency_services_key,
			technology_type_key,
			service_rtk_detail_key,
			rc_key,
			segment_key,
			branch_key,
			region_key,
			charge_rub,
			adjust_rub,
			src_id
		)

		Select 
			calendar_key,
			year_month_key,
			adjust_period,
			adjust_type_key,
			center_num_key,
			duty_num_key,
			service_key,
			frequency_services_key,
			technology_type_key,
			service_rtk_detail_key,
			rc_key,
			segment_key,
			branch_key,
			region_key,
			sum(charge_rub)			as charge_rub,
			sum(adjust_rub)			as adjust_rub,
			src_id
		From edw_stg_ads.tfct_accrual_monthly_1_prt_p000110
		where src_id=110
			and calendar_key between date_trunc('month', to_date('20190601', 'YYYYMMDD'))
				and (date_trunc('month', to_date('20190630', 'YYYYMMDD')) + interval '1 month' + interval '-1 day')
		group by 
			calendar_key,
			year_month_key,
			adjust_period,
			adjust_type_key,
			center_num_key,
			duty_num_key,
			service_key,
			frequency_services_key,
			technology_type_key,
			service_rtk_detail_key,
			rc_key,
			segment_key,
			branch_key,
			region_key,
			src_id;
			
		ANALYZE edw_stg_ads.agg_accrual_monthly_1_prt_p000110;
	