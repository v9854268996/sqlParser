/*rev.34588 31.07.2019 Changed by: NAREK.ALAVERDYAN */		
		set optimizer = on;
		truncate table edw_stg_ads.tfct_sub_base_move_1_prt_p000069  ;
		insert into edw_stg_ads.tfct_sub_base_move
		(
			calendar_key,
			year_month_key,
			account_key,
			period_account_name,
			subs_key,
			connected_service_key,
			center_num_key,
			duty_num_key,
			segment_key,
			service_key,
			frequency_services_key,
			technology_type_key,
			prev_technology_type_key,
			service_rtk_detail_key,
			rc_key,
			branch_key,
			region_key,
			partner_key,
			period_tax_number,
			new_subs_count,
			new_subs_count_corr,
			new_subs_corr_period,
			churn_subs_count,
			churn_subs_count_corr,
			churn_subs_corr_period,
			migrated_subs_count,
			migrated_subs_count_corr,
			migrated_subs_corr_period,
			src_id
		)
		with cal as
			(SELECT DISTINCT
				  month_start_date
				, month_end_date + interval '1 day' + interval '-1 sec' as month_end_date
				, to_char(month_end_date, 'YYYYMM') as year_month_key
			 FROM edw_dds.dim_calendar
			 WHERE month_end_date between date_trunc('month', to_date('20190601', 'YYYYMMDD'))
				and (date_trunc('month', to_date('20190630', 'YYYYMMDD')) + interval '1 month' + interval '-1 sec')
			)
		Select
			 date_trunc('day', month_end_date)	as calendar_key
			,year_month_key
			,account_key
			,account_name							as period_account_name
			,subs_key
			,connected_service_key
			,center_num_key
			,duty_num_key
			,coalesce(segment_key, -1) 				as segment_key
			,coalesce(service_key, -1) 				as service_key
			,coalesce(frequency_services_key, -1) 	as frequency_services_key
			,coalesce(technology_type_key, -1) 		as technology_type_key
			,coalesce(prev_technology_type_key, -1) 	as prev_technology_type_key
			,coalesce(service_rtk_detail_key, -1)	as service_rtk_detail_key
			,rc_key
			,coalesce(branch_key, -1)				as branch_key
			,coalesce(region_key, -1) 				as region_key
			,coalesce(partner_key, -1)				as partner_key
			,tax_number_cval							as period_tax_number
			,sum(new_subs_count) as new_subs_count
			,sum(new_subs_count_corr) as new_subs_count_corr
			,max(new_subs_corr_period) as new_subs_corr_period
			,sum(churn_subs_count) as churn_subs_count
			,sum(churn_subs_count_corr) as churn_subs_count_corr
			,max(churn_subs_corr_period) as churn_subs_corr_period
			,sum(migrated_subs_count) as migrated_subs_count
			,sum(migrated_subs_count_corr) as migrated_subs_count_corr
			,max(migrated_subs_corr_period) as migrated_subs_corr_period
			,src_id
		From
			(
		--Новые подключения
			Select
				 cal.month_end_date
				,cal.year_month_key
				,da.account_key
				,da.account_name
				,sb_new.subs_key
				,sa_new.connected_service_key
				,da.center_num_key
				,da.duty_num_key
				,dp.segment_key
				,sa_new.service_key
				,dim_service.frequency_services_key
				,dim_service.technology_type_key
				,-1										as prev_technology_type_key
				,dim_service.service_rtk_detail_key
				,case when sa_new.rc_key <> -1 then sa_new.rc_key
					  when sa_new.rc_key = -1 and  mrc.matrix_rc_key is not null then mrc.rc_key
					   else -1
				 end								as rc_key
				,da.branch_key
				,/*dr.region_key*/ -1 as region_key
				,da.partner_key
				,dp.tax_number_cval
				,case when sb_new.subs_activation_dttm between cal.month_start_date and cal.month_end_date
					then 1
					else 0
				 end new_subs_count
				,case when sb_new.subs_activation_dttm < cal.month_start_date
						and greatest(sb_new.subs_activation_dttm,to_date('01.01.1900','DD.MM.YYYY')) < sb_new.eff_dttm
						and sb_new_corr.subs_activation_dttm is null
						and date_trunc('month',sb_new.eff_dttm) = date_trunc('month',cal.month_end_date)
						then 1
					  when sb_new.subs_activation_dttm >= cal.month_start_date
									and sb_new_corr.subs_activation_dttm < cal.month_start_date
									and date_trunc('month',sb_new.eff_dttm) = date_trunc('month',cal.month_end_date)
						then -1
						else 0
				  end as new_subs_count_corr
				,case when sb_new.subs_activation_dttm < cal.month_start_date
						and greatest(sb_new.subs_activation_dttm,to_date('01.01.1900','DD.MM.YYYY')) < sb_new.eff_dttm
						and sb_new_corr.subs_activation_dttm is null
						and date_trunc('month',sb_new.eff_dttm) = date_trunc('month',cal.month_end_date)
						then to_char(sb_new.subs_activation_dttm, 'YYYYMM')
					  when sb_new.subs_activation_dttm >= cal.month_start_date
									and sb_new_corr.subs_activation_dttm < cal.month_start_date
									and date_trunc('month',sb_new.eff_dttm) = date_trunc('month',cal.month_end_date)
						then to_char(sb_new_corr.subs_activation_dttm, 'YYYYMM')
						else null
				  end as new_subs_corr_period
				,0 as churn_subs_count
				,0 as churn_subs_count_corr
				,null as churn_subs_corr_period
				,0 as migrated_subs_count
				,0 as migrated_subs_count_corr
				,null as migrated_subs_corr_period
				,sa_new.src_id
			from cal
				inner join edw_dds.dim_subscribers_1_prt_p000069 sb_new
					on      cal.month_end_date between sb_new.eff_dttm and sb_new.exp_dttm
						and	sb_new.subs_activation_dttm <= cal.month_end_date
						and date_trunc('day',sb_new.subs_cancellation_dttm) - INTERVAL '3 day' > date_trunc('day',sb_new.subs_activation_dttm)
						and sb_new.deleted_ind=0
						and sb_new.src_id=000069
				left join edw_dds.dim_subscribers_1_prt_p000069 sb_new_corr
					on      sb_new.subs_key = sb_new_corr.subs_key
						and sb_new.eff_dttm = sb_new_corr.exp_dttm + interval '1 sec'
						and sb_new_corr.deleted_ind=0
				inner join edw_dds.dim_connected_service_1_prt_p000069 sa_new
					on 		sb_new.subs_key = sa_new.subs_key
						and cal.month_end_date between sa_new.eff_dttm and sa_new.exp_dttm
						and sb_new.subs_activation_dttm between sa_new.start_date and sa_new.end_date
						and sa_new.deleted_ind=0
						and sa_new.src_id=000069
				inner join edw_dds.dim_account_1_prt_p000069 da
					on da.account_key=sa_new.account_key
						and (cal.month_end_date between da.eff_dttm and da.exp_dttm)
						and da.deleted_ind=0
						and da.branch_key<>-2
				inner join edw_dds.dim_partner_1_prt_p000069 dp
					on dp.partner_key=da.partner_key
						and (cal.month_end_date between dp.eff_dttm and dp.exp_dttm)
						and dp.deleted_ind=0
						and dp.partner_key<>-2
				left join edw_dds.dim_service dim_service
					on dim_service.service_key = sa_new.service_key
						and dim_service.deleted_ind=0
						and dim_service.exp_dttm='2999-12-31'
				left join edw_dds.dim_matrix_rc AS mrc
					on dim_service.service_rtk_detail_key = mrc.service_rtk_detail_key
						AND mrc.segment_key = dp.segment_key
						AND mrc.rc_default = 1
						and mrc.exp_dttm = '2999-12-31'
						and mrc.deleted_ind = 0
				/*left join edw_dds.dim_region as dr
					on da.branch_key = dr.branch_key
						and dr.exp_dttm = '2999-12-31'
						and dr.deleted_ind = 0*/
		UNION ALL
		--Отток
			Select
				 cal.month_end_date
				,cal.year_month_key
				,da.account_key
				,da.account_name
				,sb_churn.subs_key
				,sa_churn.connected_service_key
				,da.center_num_key
				,da.duty_num_key
				,dp.segment_key
				,sa_churn.service_key
				,dim_service.frequency_services_key
				,dim_service.technology_type_key
				,-1										as prev_technology_type_key
				,dim_service.service_rtk_detail_key
				,case when sa_churn.rc_key <> -1 then sa_churn.rc_key
					when sa_churn.rc_key = -1 and  mrc.matrix_rc_key is not null
						then mrc.rc_key
						else -1
				 end										as rc_key
				,da.branch_key
				,/*dr.region_key*/ -1 as region_key
				,da.partner_key
				,dp.tax_number_cval
				,0 as new_subs_count
				,0 as new_subs_count_corr
				,null as new_subs_corr_period
				,case when sb_churn.subs_cancellation_dttm between cal.month_start_date and cal.month_end_date
					  then 1
					  else 0
				 end churn_subs_count
				,case when sb_churn.subs_cancellation_dttm < cal.month_start_date and coalesce(sb_churn_corr.subs_cancellation_dttm, date_trunc('month', cal.month_end_date) - interval '1 sec') > date_trunc('month', cal.month_end_date)
								and date_trunc('month',sb_churn.eff_dttm) = date_trunc('month',cal.month_end_date)
						then  1
					  when sb_churn.subs_cancellation_dttm >= cal.month_start_date and coalesce(sb_churn_corr.subs_cancellation_dttm, cal.month_end_date) < cal.month_start_date
								and date_trunc('month',sb_churn.eff_dttm) = date_trunc('month',cal.month_end_date)
						then -1
						else  0
				 end as churn_subs_count_corr
				,case when sb_churn.subs_cancellation_dttm < cal.month_start_date and coalesce(sb_churn_corr.subs_cancellation_dttm, date_trunc('month', cal.month_end_date) - interval '1 sec') > date_trunc('month', cal.month_end_date)
								and date_trunc('month',sb_churn.eff_dttm) = date_trunc('month',cal.month_end_date)
						then  to_char(sb_churn.subs_cancellation_dttm, 'YYYYMM')
					  when sb_churn.subs_cancellation_dttm >= cal.month_start_date and coalesce(sb_churn_corr.subs_cancellation_dttm, cal.month_end_date) < cal.month_start_date
								and date_trunc('month',sb_churn.eff_dttm) = date_trunc('month',cal.month_end_date)
						then to_char(sb_churn_corr.subs_cancellation_dttm, 'YYYYMM')
						else  null
				 end as churn_subs_corr_period
				 ,0 as migrated_subs_count
				 ,0 as migrated_subs_count_corr
				 ,null as migrated_subs_corr_period
				 ,sa_churn.src_id
			from cal
				inner join edw_dds.dim_subscribers_1_prt_p000069 sb_churn
					on      cal.month_end_date between sb_churn.eff_dttm and sb_churn.exp_dttm
						and sb_churn.deleted_ind=0
						and date_trunc('day',sb_churn.subs_cancellation_dttm) - INTERVAL '3 day' > date_trunc('day',sb_churn.subs_activation_dttm)
						and sb_churn.src_id=000069
				left join edw_dds.dim_subscribers_1_prt_p000069 sb_churn_corr
					on      sb_churn.subs_key = sb_churn_corr.subs_key
						and sb_churn.eff_dttm = sb_churn_corr.exp_dttm + interval '1 sec'
						and sb_churn_corr.deleted_ind=0
						and sb_churn_corr.src_id=000069
				inner join edw_dds.dim_connected_service sa_churn
					on 		sb_churn.subs_key = sa_churn.subs_key
						and cal.month_end_date between sa_churn.eff_dttm and sa_churn.exp_dttm
						and sb_churn.subs_cancellation_dttm between sa_churn.start_date and sa_churn.end_date
						and sa_churn.deleted_ind=0
						and sa_churn.src_id=000069
				inner join edw_dds.dim_account_1_prt_p000069 da
					on da.account_key=sa_churn.account_key
						and (cal.month_end_date between da.eff_dttm and da.exp_dttm)
						and da.deleted_ind=0
						and da.branch_key<>-2
				inner join edw_dds.dim_partner_1_prt_p000069 dp
					on dp.partner_key=da.partner_key
						and (cal.month_end_date between dp.eff_dttm and dp.exp_dttm)
						and dp.deleted_ind=0
						and dp.partner_key<>-2
				left join edw_dds.dim_service dim_service
					on dim_service.service_key = sa_churn.service_key
						and dim_service.deleted_ind=0
						and dim_service.exp_dttm='2999-12-31'
				left join edw_dds.dim_matrix_rc AS mrc
					on dim_service.service_rtk_detail_key = mrc.service_rtk_detail_key
						AND mrc.segment_key = dp.segment_key
						AND mrc.rc_default = 1
						and mrc.exp_dttm = '2999-12-31'
						and mrc.deleted_ind = 0
				/*left join edw_dds.dim_region as dr
					on da.branch_key = dr.branch_key
						and dr.exp_dttm = '2999-12-31'
						and dr.deleted_ind = 0*/
		UNION ALL
		--Миграция
			Select
				 cal.month_end_date
				,cal.year_month_key
				,da.account_key
				,da.account_name
				,sb_migr.subs_key
				,sa_migr.connected_service_key
				,da.center_num_key
				,da.duty_num_key
				,dp.segment_key
				,sa_migr.service_key
				,dim_service.frequency_services_key
				,dim_service.technology_type_key
				,dim_service_prev.technology_type_key as prev_technology_type_key
				,dim_service.service_rtk_detail_key
				,case when sa_migr.rc_key <> -1 then sa_migr.rc_key
					  when sa_migr.rc_key = -1 and  mrc.matrix_rc_key is not null then mrc.rc_key
					  else -1
				 end								as rc_key
				,da.branch_key
				,/*dr.region_key*/ -1 as region_key
				,da.partner_key
				,dp.tax_number_cval
				,0 as new_subs_count
				,0 as new_subs_count_corr
				,null as new_subs_corr_period
				,0 as churn_subs_count
				,0 as churn_subs_count_corr
				,null as churn_subs_corr_period
				,case when sa_migr.start_date between cal.month_start_date and cal.month_end_date
					  then 1
					  else 0
				 end migrated_subs_count
				,case when sa_migr.start_date < cal.month_start_date and coalesce(se_corr.end_date, cal.month_end_date - interval '1 sec') > cal.month_end_date
					  then 1
					  else 0
				 end as migrated_subs_count_corr
				,case when sa_migr.start_date < cal.month_start_date and coalesce(se_corr.end_date, cal.month_end_date - interval '1 sec') > cal.month_end_date
					  then to_char(sa_migr.start_date, 'YYYYMM')
					  else null
				 end as migrated_subs_corr_period
				,sb_migr.src_id
			from cal
				inner join edw_dds.dim_subscribers_1_prt_p000069 sb_migr
					on      cal.month_end_date between sb_migr.eff_dttm and sb_migr.exp_dttm
						and date_trunc('day',sb_migr.subs_cancellation_dttm) - INTERVAL '3 day' > date_trunc('day',sb_migr.subs_activation_dttm)
						and sb_migr.deleted_ind=0
						and sb_migr.src_id=000069
				inner join edw_dds.dim_connected_service_1_prt_p000069 sa_migr
					on      sb_migr.subs_key = sa_migr.subs_key
						and	cal.month_end_date between sa_migr.eff_dttm and sa_migr.exp_dttm
						and sa_migr.start_date <= cal.month_end_date
						and sa_migr.deleted_ind=0
						and sa_migr.src_id=000069
				inner join edw_dds.dim_account_1_prt_p000069 da
					on da.account_key=sa_migr.account_key
						and (cal.month_end_date between da.eff_dttm and da.exp_dttm)
						and da.deleted_ind=0
						and da.branch_key<>-2
				inner join edw_dds.dim_partner_1_prt_p000069 dp
					on dp.partner_key=da.partner_key
						and (cal.month_end_date between dp.eff_dttm and dp.exp_dttm)
						and dp.deleted_ind=0
						and dp.partner_key<>-2
				inner join edw_dds.dim_service dim_service
					on sa_migr.service_key = dim_service.service_key
						and dim_service.active_ind = 'Y'
						and	cal.month_end_date between dim_service.eff_dttm and dim_service.exp_dttm
				inner join edw_dds.dim_connected_service_1_prt_p000069 sa_migr_prev
					on      sa_migr.subs_key = sa_migr_prev.subs_key
						and	cal.month_end_date between sa_migr_prev.eff_dttm and sa_migr_prev.exp_dttm
						and sa_migr.start_date = sa_migr_prev.end_date  + interval '1 sec'
						and sa_migr_prev.deleted_ind=0
						and sa_migr_prev.src_id=000069
				inner join edw_dds.dim_service dim_service_prev
					on sa_migr_prev.service_key = dim_service_prev.service_key
						and dim_service_prev.active_ind = 'Y'
						and	cal.month_end_date between dim_service_prev.eff_dttm and dim_service_prev.exp_dttm
						and dim_service.technology_type_key <> dim_service_prev.technology_type_key
				left join edw_dds.dim_connected_service_1_prt_p000069 se_corr
					on      sa_migr_prev.subs_key = se_corr.subs_key
						and	sa_migr_prev.service_key = se_corr.service_key
						and sa_migr_prev.eff_dttm = se_corr.exp_dttm + interval '1 sec'
						and se_corr.deleted_ind=0
						and se_corr.src_id=000069
				left join edw_dds.dim_matrix_rc as mrc
					on      dim_service.service_rtk_detail_key = mrc.service_rtk_detail_key
						AND mrc.segment_key = dp.segment_key
						AND mrc.rc_default = 1
						and mrc.exp_dttm = '2999-12-31'
						and mrc.deleted_ind = 0
				/*left join edw_dds.dim_region as dr
					on da.branch_key = dr.branch_key
						and dr.exp_dttm = '2999-12-31'
						and dr.deleted_ind = 0*/
		) base
		group by
			  date_trunc('day', month_end_date)
			, year_month_key
			, account_key
			, account_name
			, subs_key
			, connected_service_key
			, center_num_key
			, duty_num_key
			, coalesce(segment_key, -1)
			, coalesce(service_key, -1)
			, coalesce(frequency_services_key, -1)
			, coalesce(technology_type_key, -1)
			, coalesce(prev_technology_type_key, -1)
			, coalesce(service_rtk_detail_key, -1)
			, rc_key
			, coalesce(branch_key, -1)
			, coalesce(region_key, -1)
			, coalesce(partner_key, -1)
			, tax_number_cval
			, src_id
		having  sum(new_subs_count) +
				sum(abs(new_subs_count_corr)) +
				sum(churn_subs_count) +
				sum(abs(churn_subs_count_corr)) +
				sum(migrated_subs_count) +
				sum(abs(migrated_subs_count_corr)) <> 0

		;

		ANALYZE edw_stg_ads.tfct_sub_base_move_1_prt_p000069;
	