/*rev.19027 07.12.2018*/
	delete from edw_stg_mdm.put_xref_dim_business_service_ruz where src_id = 158;
	insert into edw_stg_mdm.put_xref_dim_business_service_ruz
	(
		source_key
		,name_serv_gr
		,src_id
		,load_dttm
	)
	select 
		serv_id
		,def
		,158::int as src_id
		,now() 
	from edw_ods.t_000158_rprt_dir_services;
	commit;
	analyze edw_stg_mdm.put_xref_dim_business_service_ruz;
