/*rev. 27672*/

set optimizer = on;

truncate edw_stg_dm_efftp.tfct_sdp_vitrina_detail_1_prt_p000011;

insert into edw_stg_dm_efftp.tfct_sdp_vitrina_detail_1_prt_p000011
(
period,
mrf,
rf,
account,
san,
abn_id,
subs_id,
name_pack_asr,
name_pack_standart,
flag_type_pack,
flag_pack_begin,
flag_pack_end,
dt,
src_id
)

with svcs as ( --абонентообразующие услуги IPTV  serv_id=3
select r.svc_id from edw_ods.t_000011_t_svc_layer_bunch lb,edw_ods.t_000011_t_svc_layer_cell lc,edw_ods.t_000011_t_svc_ref r 
  where lb.id_layer_svc = 1001 and lb.id_cell_svc = lc.id_cell_svc and r.svc_id=lb.svc_id
    and lc.name in ('У-IPTV-XDSL','У-IPTV-GPON','У-IPTV-FTTB','У-IPTV-ETHERNET','У-IPTV-ADSL')
),

sip_link as
(
select distinct 
u.dept_id,
s.serv_first_id,
u.account,
s.src_id
from edw_ods.t_000011_t_services s,
edw_ods.t_000011_t_users u,
svcs
where s.user_id=u.user_id
and s.svc_id=svcs.svc_id 
and s.date_begin <= (date_trunc('month', to_date('20190601', 'YYYYMMDD')) + interval '1 month')::date
and coalesce(s.date_end, to_date('3000', 'YYYY')) >= (date_trunc('month', to_date('20190601', 'YYYYMMDD')))::date
),

ip_packs as(
-- ===================== 1
SELECT period -- to_char(add_months(trunc(sysdate, 'MM'), -1)) || ' - ' || to_char(trunc(sysdate, 'MM') -1) AS period
, tmp.rep_cat_id
, tmp.rep_cat_name
, tmp.rep_data1
, tmp.rep_data2
, tmp.iscorp
, CASE WHEN tmp.rep_cat_name != 'VI.8' THEN tmp.us_user_name ELSE NULL END us_user_name, ab_account, src_id
FROM(SELECT ls.period AS period, ls.src_id
    , ls.us_user_name
    , ls.ab_account
    , ls.iscorp
    , rp.rep_cat_id
    , rp.rep_cat_name
    , rp.rep_data1
    , rp.rep_data2

    FROM(SELECT res.*
    
      FROM edw_ods.T_000023_KMV_TB_ITVKTV_RES res

      WHERE res.us_user_name NOT IN(SELECT le.logname

        FROM edw_ods.T_000023_KMV_FR_LOGNAME_EXLUSION le
        , edw_dds.dim_region fi

        WHERE le.filial_id = fi.region_key
      )
    ) ls
    , edw_ods.t_000023_kmv_reports rp

    WHERE rp.rep_data2 = ls.pkg_code
    AND rp.rep_name = 'KMV_REP_ITVKTV'
    AND rp.rep_cat_name NOT IN('I.3.2')
    AND rp.rep_data2 NOT IN('IDEAL_HDACT')

--    GROUP BY ls.period
--    , ls.us_user_name
--    , ls.iscorp
--    , ls.pkg_code
--    , rp.rep_cat_id
--    , rp.rep_cat_name
--    , rp.rep_data1
--    , rp.rep_data2
) tmp

--GROUP BY tmp.rep_cat_id
--, tmp.rep_cat_name
--, tmp.rep_data1
--, tmp.rep_data2

UNION ALL
-- ===================== 2

SELECT period -- to_char(add_months(trunc(sysdate, 'MM'), -1)) || ' - ' || to_char(trunc(sysdate, 'MM') -1) AS period
, CASE
    WHEN tmp.cnt = 1 THEN 30000
    WHEN tmp.cnt = 2 THEN 30100
    WHEN tmp.cnt = 3 THEN 30200
    WHEN tmp.cnt = 4 THEN 30300
    WHEN tmp.cnt = 5 THEN 30400
END AS rep_cat_id
, CASE
    WHEN tmp.cnt = 1 THEN 'III.1'
    WHEN tmp.cnt = 2 THEN 'III.2'
    WHEN tmp.cnt = 3 THEN 'III.3'
    WHEN tmp.cnt = 4 THEN 'III.4'
    WHEN tmp.cnt = 5 THEN 'III.5'
END AS rep_cat_name
, CASE
    WHEN tmp.cnt = 1 THEN 'количество абонентов на основной платформе с одним пакетом (в т.ч. Максимальный, Мой РТ, Лёгкий)'
    WHEN tmp.cnt = 2 THEN 'количество абонентов на основной платформе с 2 пакетами (например, Популярный + Кино, Спортивный+Детский)'
    WHEN tmp.cnt = 3 THEN 'количество абонентов на основной платформе с 3 пакетами (например, Популярный + Кино + Музыкальный, Спортивный+Детский+Познавательный)'
    WHEN tmp.cnt = 4 THEN 'количество абонентов на основной платформе с 4 пакетами (например, Популярный + Кино + Музыкальный + Спортивный)'
    WHEN tmp.cnt = 5 THEN 'количество абонентов на основной платформе с 5 пакетами'
END AS rep_data1
, NULL AS rep_data2
, tmp.iscorp
, tmp.us_user_name us_user_name, ab_account, src_id

FROM(SELECT ls.period AS period
    , ls.us_user_name
    , ls.ab_account
    , ls.iscorp
    , COUNT(ls.pkg_code) AS cnt, ls.src_id

    FROM(SELECT res.*
    
      FROM edw_ods.T_000023_KMV_TB_ITVKTV_RES res

      WHERE res.us_user_name NOT IN(SELECT le.logname

        FROM edw_ods.T_000023_KMV_FR_LOGNAME_EXLUSION le
        , edw_dds.dim_region fi

        WHERE le.filial_id = fi.region_key
      )
    ) ls
    , edw_ods.t_000023_kmv_reports rp

    WHERE rp.rep_data2 = ls.pkg_code
    AND rp.rep_name = 'KMV_REP_ITVKTV'
    AND rp.rep_data2 NOT IN('IDEAL_HDACT')
    AND rp.rep_cat_name IN('I.1.1','I.1.2','I.1.3','I.1.4','I.1.5','I.1.6','I.1.7','I.1.8','I.1.9','I.1.10','I.1.11','I.1.12','I.1.13','I.2','I.2.1','I.3.1','I.4')

    GROUP BY ls.period
    , ls.us_user_name
    , ls.ab_account
    , ls.iscorp, ls.src_id

    UNION ALL

    SELECT ls.period AS period
    , ls.us_user_name
    , ls.ab_account
    , ls.iscorp
    , COUNT(ls.pkg_code) AS cnt, ls.src_id

    FROM(SELECT res.*
    
      FROM edw_ods.T_000023_KMV_TB_ITVKTV_RES res

      WHERE res.us_user_name NOT IN(SELECT le.logname

        FROM edw_ods.T_000023_KMV_FR_LOGNAME_EXLUSION le
        , edw_dds.dim_region fi

        WHERE le.filial_id = fi.region_key
      )
    ) ls

    WHERE ls.pkg_code IN('YOUR_OPTIM_ACT2','YOUR_OPTIM_ACT2_POPL','YOUR_OPTIM_ACT')

    GROUP BY ls.period
    , ls.us_user_name
    , ls.ab_account
    , ls.iscorp, ls.src_id
) tmp

WHERE tmp.cnt != 0
AND tmp.cnt < 6

--GROUP BY tmp.cnt


-- ===================== 3
UNION ALL

SELECT period --to_char(add_months(trunc(sysdate, 'MM'), -1)) || ' - ' || to_char(trunc(sysdate, 'MM') -1) AS period
, 30500 AS rep_cat_id
, 'III.6' AS rep_cat_name
, 'количество абонентов на основной платформе с 6 пакетами, но не максимальный ТП!' rep_data1
, NULL AS rep_data2
, tmp.iscorp
, tmp.us_user_name, ab_account, src_id

FROM(SELECT ls.period AS period
    , ls.us_user_name
    , ls.ab_account
    , ls.iscorp
    , COUNT(ls.pkg_code) AS cnt, ls.src_id

    FROM(SELECT res.*
    
      FROM edw_ods.T_000023_KMV_TB_ITVKTV_RES res

      WHERE res.us_user_name NOT IN(SELECT le.logname

        FROM edw_ods.T_000023_KMV_FR_LOGNAME_EXLUSION le
        , edw_dds.dim_region fi

        WHERE le.filial_id = fi.region_key
      )
    ) ls
    , edw_ods.t_000023_kmv_reports rp

    WHERE rp.rep_data2 = ls.pkg_code
    AND rp.rep_name = 'KMV_REP_ITVKTV'
    AND rp.rep_data2 NOT IN('IDEAL_HDACT')
    AND rp.rep_cat_name IN('I.1.1','I.1.2','I.1.3','I.1.4','I.1.5','I.1.6','I.1.7','I.1.8','I.1.9','I.1.10','I.1.11','I.1.12','I.1.13','I.2','I.2.1','I.3.1','I.4')

    GROUP BY ls.period
    , ls.us_user_name
    , ls.ab_account
    , ls.iscorp, ls.src_id

    UNION ALL

    SELECT ls.period AS period
    , ls.us_user_name
    , ls.ab_account
    , ls.iscorp
    , COUNT(ls.pkg_code) AS cnt, ls.src_id

    FROM(SELECT res.*
    
      FROM edw_ods.T_000023_KMV_TB_ITVKTV_RES res

      WHERE res.us_user_name NOT IN(SELECT le.logname

        FROM edw_ods.T_000023_KMV_FR_LOGNAME_EXLUSION le
        , edw_dds.dim_region fi

        WHERE le.filial_id = fi.region_key
      )
    ) ls

    WHERE ls.pkg_code IN('YOUR_OPTIM_ACT2','YOUR_OPTIM_ACT2_POPL','YOUR_OPTIM_ACT')

    GROUP BY ls.period
    , ls.us_user_name
    , ls.ab_account
    , ls.iscorp, ls.src_id
) tmp

WHERE tmp.cnt != 0
AND tmp.cnt >= 6

UNION ALL

-- ===================== 4
SELECT period -- to_char(add_months(trunc(sysdate, 'MM'), -1)) || ' - ' || to_char(trunc(sysdate, 'MM') -1) AS period
, 40650 AS rep_cat_id
, 'IV.8' AS rep_cat_name
, 'Мультирум' rep_data1
, NULL AS rep_data2
, tmp.iscorp
, tmp.us_user_name, ab_account,  src_id

FROM(SELECT al.period AS period
    , al.us_user_name
    , al.ab_account
    , al.iscorp
    , COUNT(1), al.src_id

    FROM(SELECT res.*
    
      FROM edw_ods.T_000023_KMV_TB_ITVKTV_RES res

      WHERE res.us_user_name NOT IN(SELECT le.logname

        FROM edw_ods.T_000023_KMV_FR_LOGNAME_EXLUSION le
        , edw_dds.dim_region fi

        WHERE le.filial_id = fi.region_key
      )
    ) al
    , edw_ods.T_000023_TB_USER_SERV_ATTRS usa
    , edw_ods.T_000023_CT_USER_SERVICES uss

    WHERE uss.uss_us_user_name = al.us_user_name
    AND usa.usa_uss_logname = uss.uss_logname
    AND usa.usa_sl_type = uss.uss_sl_type
    AND usa.usa_sl_type = 'IPTVSTB'
    AND usa.usa_sat_vn_code = '2'
    AND usa.usa_sat_name = 'SerialNumber'

    GROUP BY al.period
    , al.us_user_name
    , al.ab_account
    , al.iscorp, al.src_id

    HAVING COUNT(1) > 1
) tmp


-- ===================== 5
UNION ALL

SELECT period --to_char(add_months(trunc(sysdate, 'MM'), -1)) || ' - ' || to_char(trunc(sysdate, 'MM') -1) AS period
, 60000 AS rep_cat_id
, 'VI.1' AS rep_cat_name
, 'Попробуй HD' rep_data1
, NULL AS rep_data2
, tmp.iscorp
, tmp.us_user_name, ab_account, src_id

FROM(SELECT date_trunc('month', now()) + interval '-1 month' AS period
    , pkg.itvupg_package_external_id AS ab_external_code
    , CASE WHEN ab.ab_lr_legal_status = 'PRIVATE' THEN 'N' ELSE 'Y' END AS iscorp
    , ct.us_user_name, ab.ab_account
    , ct.us_tfp_code AS tfp_code, ab.src_id
    , (SELECT tp.tfp_name FROM edw_ods.t_000023_tb_tariff_plans tp WHERE tp.tfp_code = ct.us_tfp_code) AS tfp_name

    FROM edw_ods.T_000023_ABONENT ab
    , edw_ods.T_000023_CT_USERS ct
    , edw_ods.T_000023_CT_USER_SERVICES cts
    , edw_ods.T_000023_IPTV_USS_PACKAGES pkg

    WHERE ab.ab_id = ct.us_ab_id
    AND ct.us_user_name = cts.uss_us_user_name
    AND cts.uss_logname = pkg.itvupg_uss_logname
    AND pkg.itvupg_package_external_id = 'IDEAL_HDACT'
    AND pkg.itvupg_status = 'A'
    AND cts.input_date <= date_trunc('month', now()) + interval '-1 month'

    GROUP BY pkg.itvupg_package_external_id
    , ab.ab_lr_legal_status
    , ct.us_user_name, ab.ab_account
    , ct.us_tfp_code, ab.src_id

    UNION ALL

    SELECT date_trunc('month', now()) + interval '-1 day' AS period
    , pkg.itvupg_package_external_id AS ab_external_code
    , CASE WHEN ab.ab_lr_legal_status = 'PRIVATE' THEN 'N' ELSE 'Y' END AS iscorp
    , ct.us_user_name, ab.ab_account
    , ct.us_tfp_code AS tfp_code, ab.src_id
    , (SELECT tp.tfp_name FROM edw_ods.t_000023_tb_tariff_plans tp WHERE tp.tfp_code = ct.us_tfp_code) AS tfp_name

    FROM edw_ods.T_000023_ABONENT ab
    , edw_ods.T_000023_CT_USERS ct
    , edw_ods.T_000023_CT_USER_SERVICES cts
    , edw_ods.T_000023_IPTV_USS_PACKAGES pkg

    WHERE ab.ab_id = ct.us_ab_id
    AND ct.us_user_name = cts.uss_us_user_name
    AND cts.uss_logname = pkg.itvupg_uss_logname
    AND pkg.itvupg_package_external_id = 'IDEAL_HDACT'
    AND pkg.itvupg_status = 'A'
    AND cts.input_date <= date_trunc('month', now()) + interval '-1 day'

    GROUP BY pkg.itvupg_package_external_id
    , ab.ab_lr_legal_status
    , ct.us_user_name, ab.ab_account
    , ct.us_tfp_code, ab.src_id
) tmp


-- ===================== 6
/*UNION ALL

SELECT now() period ---to_char(add_months(trunc(sysdate, 'MM'), -1)) || ' - ' || to_char(trunc(sysdate, 'MM') -1) AS period
, 60400 AS rep_cat_id
, 'VI.4' AS rep_cat_name
, 'Амедиа Премиум (Сериалы планеты) - за 1 руб.' rep_data1
, NULL AS rep_data2
, null as is_corp
, null as us_user_name, to_number('000023', '999999') src_id
*/
--FROM dual

UNION ALL

SELECT period --to_char(add_months(trunc(sysdate, 'MM'), -1)) || ' - ' || to_char(trunc(sysdate, 'MM') -1) AS period
, tmp.rep_cat_id
, tmp.rep_cat_name
, tmp.rep_data1
, tmp.rep_data2
, tmp.iscorp
, tmp.us_user_name, ab_account,  src_id

FROM(SELECT ls.period AS period
    , ls.us_user_name
    , ls.ab_account
    , ls.iscorp
    , 1000000 AS rep_cat_id
    , NULL AS rep_cat_name
    , ls.pkg_code AS rep_data1
    , ls.pkg_code AS rep_data2, ls.src_id

    FROM(SELECT res.*
    
      FROM edw_ods.T_000023_KMV_TB_ITVKTV_RES res

      WHERE res.us_user_name NOT IN(SELECT le.logname

        FROM edw_ods.T_000023_KMV_FR_LOGNAME_EXLUSION le
        , edw_dds.dim_region fi

        WHERE le.filial_id = fi.region_key
      )
    ) ls

    WHERE ls.pkg_code NOT IN(SELECT rp.rep_data2 FROM edw_ods.t_000023_kmv_reports rp WHERE rp.rep_data2 IS NOT NULL)

    GROUP BY  ls.period
    , ls.us_user_name
    , ls.ab_account
    , ls.iscorp
    , ls.pkg_code, ls.src_id
) tmp

--GROUP BY tmp.rep_cat_id
--, tmp.rep_cat_name
--, tmp.rep_data1
--, tmp.rep_data2
--
--ORDER BY 2
),
raw_data as
(
select
to_number(to_char(date_trunc('month', i.period), 'YYYYMM'), '999999')::int4 period,
13 mrf,
db.branch_key rf,
s.account account,
null::text san,
tp.abn_id abn_id,
s.serv_first_id subs_id,
i.rep_data1 name_pack_asr,
null::text name_pack_standart,
null::int flag_type_pack,
case when date_trunc('month', i.period) = i.period then 'B' else 'E' end be_flag,
date_trunc('month', to_date('20190601', 'YYYYMMDD'))::timestamp dt,
s.src_id src_id

from ip_packs i

join sip_link s
on i.ab_account = s.account

left join edw_dds.hub_dim_branch db
on s.dept_id = db.source_key
and s.src_id = db.src_id

left join edw_dm_efftp.tfct_oo_eff_tp_1_prt_p000153 tp
on s.account = tp.account
and s.serv_first_id = tp.subs_id
and tp.dt = (date_trunc('month', to_date('20190601', 'YYYYMMDD')))::date
and tp.serv_id = 3

where date_trunc('month', i.period)::date = (date_trunc('month', to_date('20190601', 'YYYYMMDD')))::date
and i.iscorp = 'N'
)
,
gr_data as (
select 
period,
mrf,
rf,
account,
san,
abn_id,
subs_id,
name_pack_asr,
name_pack_standart,
1 amount_pack,
flag_type_pack,
case when min(be_flag) = 'B' then 1 else 0 end flag_pack_begin,
case when max(be_flag) = 'E' then 1 else 0 end flag_pack_end,
dt, 
src_id
from raw_data
group by period,
mrf,
rf,
account,
san,
abn_id,
subs_id,
name_pack_asr,
name_pack_standart,
flag_type_pack,
dt,
src_id
)
select 
period,
mrf,
rf,
account,
san,
abn_id,
subs_id,
name_pack_asr,
name_pack_standart,
flag_type_pack,
flag_pack_begin,
flag_pack_end,
dt,
src_id
from gr_data
;

analyze edw_stg_dm_efftp.tfct_sdp_vitrina_detail_1_prt_p000011
;
