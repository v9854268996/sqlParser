/*rev.54432 от 09.04.2020*/
	set optimizer = on;
truncate table edw_stg_dm_ruz.pre_fct_ip_mpls_traffic_iptv_1_prt_p000154;
insert into edw_stg_dm_ruz.pre_fct_ip_mpls_traffic_iptv_1_prt_p000154
(
	period,
	client_name,
	in_traf,
	out_traf,
	total_traf,
	cms_order,
	cms_service,
	cms_cleint_inn,
	vrf,
	rt_import,
	cms_order_point2address,
	has_region_lastmile,
	business_service_ruz_key,
	segment_key,
	rc_key,
	business_segment_key,
	oebs_r12_branch_key,
	source,
	ruz_src_id,
	src_id
)
/*Согласно информации от Булгак Л. исходя из наименования устройства можно определить филиал*/
with traffic as 
(
	select 
		b1.oebs_r12_branch_ruz_key as rf_id,
		'TEOCO NETRAC' as source,
		sum(in_traf) in_traf,
		sum(out_traf) out_traf,
		sum(total_traf) total_traf
	from edw_ods.t_000158_ipmpls_traffic_dwh f
	left join edw_DDS.hub_dim_oebs_r12_branch_ruz b1 on b1.source_key =	case 
			when rf_id = -1 and EQP_NAME = 'kyzl-rgr2.sib.ip.rostelecom.ru' then 1606 
			when rf_id = -1 and EQP_NAME = 'mrsk-rgr3.sz.ip.rostelecom.ru' then 1205
			when rf_id = -1 and EQP_NAME = 'vnov-rgr3.sz.ip.rostelecom.ru' then 12068
			when   f.mrf_id in (1001, 100000, 100100, 100200, 100300)  then cast ( substring (f.rf_id::text,1,4)  as numeric(4,0))
			else rf_id  end  ::text
			and to_date('20190601','YYYYMMDD')  between b1.eff_dttm and b1.exp_dttm
			and b1.src_id=158
	where 1 = 1
		and f.rep_date = to_date('20190601','YYYYMMDD')
		and f.tech_dt = cast(to_date('20190601','YYYYMMDD') as timestamp(0))
		and 		
		case when  f.mrf_id = -1 and f.rf_id=-1 and (f.eqp_name  ~ '(klga|kstr|m10|m7-d|mrsk|mscw|msk-|rzan|gcu-%|krtv|nkrn|pvrv|ud_v)' or f.eqp_name  like 'orel%' ) then 11   
			 when  f.mrf_id in (1001, 100000, 100100, 100200, 100300) 		         then 11
			 when  f.mrf_id = -1 and f.rf_id=-1 and f.eqp_name  ~ '(spbr|vlmr|vnov)' then 12
			 when  f.mrf_id = -1 and f.rf_id=-1 and f.eqp_name  ~ '(kazn|kirv)'      then 13
			 when  f.mrf_id = -1 and f.rf_id=-1 and f.eqp_name  ~ '(sohi|vldk|vlkz)' then 14
			 when  f.mrf_id = -1 and f.rf_id in (1409, 14999) 				         then 14 		 
			 when  f.mrf_id = -1 and f.rf_id=-1 and f.eqp_name  ~ '(ebrg|perm)'      then 15
			 when  f.mrf_id = -1 and f.rf_id=-1 and (f.eqp_name  ~ '(grna|kyzl|nvsk|lnsk)' or f.eqp_name  like 'omsk%' or f.eqp_name like 'brnl%') then 16
		else f.mrf_id end   = case 
																	when 000154 = 151 then 11 
																	when 000154 = 152 then 12
																	when 000154 = 153 then 13
																	when 000154 = 154 then 14
																	when 000154 = 155 then 15
																	when 000154 = 156 then 16
																	when 000154 = 157 then 17
																end
		and lower(vrf) in ('vrf_v3560-backlan_iptv', 'vrf_v3560-backlan-iptv', 'vrf_tech-iptv-backlan', 'vrf_v3560-backlan_iptv_nrgr', 'vrf_ri-is-l3vpn-backlan_iptv', 'vrf_v3560-backlan_iptv_ykts'	)
		and deleted_ind = '0'
		and coalesce( UPPER(f.iface_type), '-1') =UPPER( 'Logical interface')
	GROUP BY 
		b1.oebs_r12_branch_ruz_key, EQP_NAME, f.mrf_id
	UNION ALL
	select 
		rf_id,
		source,
		in_traf,
		out_traf,
		total_traf
	from ( /*Так как сумма для всех mrf должна быть равна 2737800, то сначала считаем трафик в разрезе mrf_id и только потом оставляем тот id который нужен*/
		SELECT
			r1.oebs_r12_branch_ruz_key  as rf_id,
			'IPTV multicast' as source,
			0 in_traf ,
			2737800.0/count(oebs_r12_branch_ruz_key) over() as out_traf,
			0 total_traf
		from  edw_dds.dim_oebs_r12_branch_ruz r1
		where 1=1
		and ( lower (r1.oebs_r12_name) !~ 'общие расходы|упц рт|крым|оцо |дирекция|город севастополь|корпоративный центр пао ростелеком|не определено|центральная бухгалтерия'
		)	
		 and to_date('20190601','YYYYMMDD') between r1.eff_dttm and r1.exp_dttm
		group by  r1.oebs_r12_branch_ruz_key  )f
	left join edw_dds.dim_oebs_r12_branch_ruz br2 
		on (1 = 1
		and br2.oebs_r12_branch_ruz_key=f.rf_id
		and to_date('20190601','YYYYMMDD') between br2.eff_dttm and br2.exp_dttm
		)
		
	where 1=1
	and  case when  substring (br2.branch_code,1,2)='10' then '11' else substring (br2.branch_code,1,2) end =case 
																	when 000154 = 151 then 11 
																	when 000154 = 152 then 12
																	when 000154 = 153 then 13
																	when 000154 = 154 then 14
																	when 000154 = 155 then 15
																	when 000154 = 156 then 16
																	when 000154 = 157 then 17
																end::text 
  
),
 sad_2 as (

				select 
					p2_mrf_id, 
					tp.tech_dt,
					p3_rf_id, 
					serv_id,
					tp.account  as account_1,  
					s_dwh.account,
					visual_code, 
					macro_segment ,
					tp.abn_id,
					row_number() over (partition by  tp.account ,visual_code   order by date_start desc )as rn
				from edw_ods.t_000154_efftp_oo_eff_tp tp
				inner join  (select  subs_id
									,account
									,visual_code
									,login
								   ,abn_id
								    ,row_number() over (partition by  abn_id  order by date_snap desc )as rn 
							from edw_ods.t_000154_RPRT_SUBSCRIBERS_DWH
							where 1=1

						)s_dwh 
						on (1 = 1 
						and s_dwh.rn=1
						and s_dwh.account=tp.account
						)
	where 1 = 1 
				
					and tech_dt  between   to_date('20190601','YYYYMMDD')   and to_date('20190630','YYYYMMDD')
					and tp.account is not null
					and serv_id = 3 
					and deleted_ind = 0
					and p2_mrf_id = case 
																	when 000154 = 151 then 11 
																	when 000154 = 152 then 12
																	when 000154 = 153 then 13
																	when 000154 = 154 then 14
																	when 000154 = 155 then 15
																	when 000154 = 156 then 16
																	when 000154 = 157 then 17
																end
	 
)

,oo_eff_tp_sad as (

select *
from (
	select 
		sad.san, 
		sad.account as account,
		coalesce( sad_1.visual_code, sad_2_2.visual_code) as   visual_code, 
		sad_1.account_1,
		sad.sdp_mrf_id,
		coalesce(sad_1.p2_mrf_id , sad_2_2.p2_mrf_id ) as p2_mrf_id, 
		coalesce(sad_1.p3_rf_id , sad_2_2.p3_rf_id ) as p3_rf_id,
		coalesce(sad_1.macro_segment , sad_2_2.macro_segment  ) as macro_segment
		,row_number() over (partition by san order by  sad.account desc ) as rn 
	
	from edw_dds.dim_san_account sad   

	left 	join  sad_2   sad_1
		on ( 1 = 1
		
			and decode( sad.sdp_mrf_id,1,11,4,11,5,12,9,13,7,14,8,15,6,16,3,17) = case 
																	when 000154 = 151 then 11 
																	when 000154 = 152 then 12
																	when 000154 = 153 then 13
																	when 000154 = 154 then 14
																	when 000154 = 155 then 15
																	when 000154 = 156 then 16
																	when 000154 = 157 then 17
																end
			and sad_1.rn=1
			and sad_1.visual_code= sad.san 
		
			)
	left 	join  sad_2   sad_2_2 
		on ( 1 = 1
			and decode( sad.sdp_mrf_id,1,11,4,11,5,12,9,13,7,14,8,15,6,16,3,17) = case 
																	when 000154 = 151 then 11 
																	when 000154 = 152 then 12
																	when 000154 = 153 then 13
																	when 000154 = 154 then 14
																	when 000154 = 155 then 15
																	when 000154 = 156 then 16
																	when 000154 = 157 then 17
																end
			and sad_2_2.rn=1
			and sad.account= sad_2_2.account 
			and sad_1.visual_code is  null   )

where 1=1
and sad.exp_dttm= to_date('29991231','YYYYMMDD')  
and  decode( sad.sdp_mrf_id,1,11,4,11,5,12,9,13,7,14,8,15,6,16,3,17) = case 
																	when 000154 = 151 then 11 
																	when 000154 = 152 then 12
																	when 000154 = 153 then 13
																	when 000154 = 154 then 14
																	when 000154 = 155 then 15
																	when 000154 = 156 then 16
																	when 000154 = 157 then 17
																end
) t
where 1=1
and rn=1
and macro_segment is not null 
),
iptv as (
	select 
	/*По абонентам приходит одна разбивка филиалов, а по трафику другая - происходит их соотнесение через case*/
		b1.oebs_r12_branch_ruz_key as  rf_id,
		5 business_service_ruz_key,
		coalesce (h_s.segment_key, 22401) segment_key,
		coalesce (d_c.rc_key, 1015) rc_key,
		coalesce (d_c.business_segment_key, 2) business_segment_key,
		1.0*count(mac)/sum(count(mac)) over(partition by 
														case 
															when oo_eff_tp_sad.p3_rf_id = 1206 or oo_eff_tp_sad.p3_rf_id = 1208 then 12068
															when oo_eff_tp_sad.p3_rf_id = 1401 or oo_eff_tp_sad.p3_rf_id = 1407 then 14999
															when oo_eff_tp_sad.p3_rf_id = 1503 or oo_eff_tp_sad.p3_rf_id = 1506 then 15998
															when oo_eff_tp_sad.p3_rf_id = 12121 or oo_eff_tp_sad.p3_rf_id = 12122 then 1212
															else oo_eff_tp_sad.p3_rf_id 
														end
											) coef
	from
		 edw_ods.t_000195_v_iptv_dim_terminal dt 
		inner join edw_ods.t_000195_v_iptv_dim_subscriber ds 
		on ( 1 = 1 /*Соединение абонента и Терминала IPTV*/
			and dt.subscriber_id = ds.dim_subscriber_id 
			and ds.subscriber_is_test = 'Нет' and ds.has_stb = 'Да'  and dt.device_type_name = 'STB' and mac != '-'
			and to_date('20190601','YYYYMMDD') between ds.iptv_eff_dttm and ds.iptv_exp_dttm
			and ds.deleted_ind = '0'
			and ds.is_deleted = '0'
			and decode(ds.mrf_id,1,11,4,11,5,12,9,13,7,14,8,15,6,16,3,17) = case 
																	when 000154 = 151 then 11 
																	when 000154 = 152 then 12
																	when 000154 = 153 then 13
																	when 000154 = 154 then 14
																	when 000154 = 155 then 15
																	when 000154 = 156 then 16
																	when 000154 = 157 then 17
																end
		)
	LEFT join oo_eff_tp_sad
	on ( 1 = 1
		and oo_eff_tp_sad.san = ds.account_number
		--and decode(ds.mrf_id,1,11,4,11,5,12,9,13,7,14,8,15,6,16,3,17)=oo_eff_tp_sad.p2_mrf_id
		)
	left join 
		(
			select 
				account, 
				nls, 
				rf_id, 
				--mrf_id, 
				date_begin, 
				coalesce(LEAD (DATE_BEGIN,1) over (partition by account ORDER BY DATE_END)- interval '1 second' ,DATE_END, date '2999-12-31') as DATE_END 
			from edw_ods.t_000158_efftp_south_nls_accnt
			where  1 = 1
				and account is not null
				and date_begin <= to_date('20190601','YYYYMMDD') + interval'1 month - 1 second'	
				and mrf_id = case 
																	when 000154 = 151 then 11 
																	when 000154 = 152 then 12
																	when 000154 = 153 then 13
																	when 000154 = 154 then 14
																	when 000154 = 155 then 15
																	when 000154 = 156 then 16
																	when 000154 = 157 then 17
																end
				and date_end is null
				and deleted_ind = '0'
		) nls_acc
		on ( 1 = 1
			and nls_acc.rf_id = oo_eff_tp_sad.p3_rf_id 
			and nls_acc.nls = oo_eff_tp_sad.account------------account->nls
			and to_date('20190601','YYYYMMDD') + interval'1 month - 1 second' between nls_acc.date_begin and nls_acc.date_end
			)
	left join edw_dds.dim_segment h_s 
		on ( 1 = 1
			and oo_eff_tp_sad.macro_segment = h_s.segment_name
			and to_date('20190601','YYYYMMDD') between h_s.eff_dttm and h_s.exp_dttm 
			and h_s.deleted_ind = '0'
		)
	left join edw_dds.dim_matrix_ruz_rc d_mr /*Коммерческая матрица*/
		on ( 1 = 1
			and d_mr.business_service_ruz_key = 5
			and d_mr.segment_key  = h_s.segment_key  
			and to_date('20190601','YYYYMMDD') between d_mr.eff_dttm and d_mr.exp_dttm  
			and d_mr.deleted_ind = '0'
		)
		left join edw_dds.dim_rc d_c
		on ( 1 = 1
			and d_mr.rc_key = d_c.rc_key 
			and to_date('20190601','YYYYMMDD') between d_c.eff_dttm and d_c.exp_dttm
			and d_c.deleted_ind = '0'
		)
		left join edw_dds.hub_dim_oebs_r12_branch_ruz b1 
		on ( 1 = 1
			and b1.src_id=158 
			and b1.source_key=case 
					when oo_eff_tp_sad.p3_rf_id = 1206 or oo_eff_tp_sad.p3_rf_id = 1208 then 12068
					when oo_eff_tp_sad.p3_rf_id = 1401 or oo_eff_tp_sad.p3_rf_id = 1407 then 14999
					when oo_eff_tp_sad.p3_rf_id = 1503 or oo_eff_tp_sad.p3_rf_id = 1506 then 15998
					when oo_eff_tp_sad.p3_rf_id = 12121 or oo_eff_tp_sad.p3_rf_id = 12122 then 1212
					else oo_eff_tp_sad.p3_rf_id 
				end :: text
			and to_date('20190601','YYYYMMDD') between b1.eff_dttm and b1.exp_dttm
			--and b1.deleted_ind = '0'
		)
		where to_date('20190601','YYYYMMDD') between dt.iptv_eff_dttm and dt.iptv_exp_dttm
		and dt.deleted_ind = '0'
group by  
	case 
		when oo_eff_tp_sad.p3_rf_id = 1206 or oo_eff_tp_sad.p3_rf_id = 1208 then 12068
		when oo_eff_tp_sad.p3_rf_id = 1401 or oo_eff_tp_sad.p3_rf_id = 1407 then 14999
		when oo_eff_tp_sad.p3_rf_id = 1503 or oo_eff_tp_sad.p3_rf_id = 1506 then 15998
		when oo_eff_tp_sad.p3_rf_id = 12121 or oo_eff_tp_sad.p3_rf_id = 12122 then 1212
		else oo_eff_tp_sad.p3_rf_id end,
	b1.oebs_r12_branch_ruz_key,
	coalesce (h_s.segment_key, 22401) ,
	coalesce (d_c.rc_key, 1015) ,
	coalesce (d_c.business_segment_key, 2)
)
select 
	f.period,
	f.client_name,
	sum(f.in_traf) in_traf,
	sum(f.out_traf) out_traf,
	sum(f.total_traf) total_traf,
	f.cms_order,
	f.cms_service,
	f.cms_client_inn,
	f.vrf,
	f.rt_import,
	f.cms_order_point2address,
	f.has_region_lastmile,
	f.business_service_ruz_key,
	f.segment_key,
	f.rc_key,
	f.business_segment_key,
	f.oebs_r12_branch_ruz_key,
	f.source ,
	f.ruz_src_id,
	f.src_id
from (
	SELECT	to_date('20190601','YYYYMMDD') period,
			null client_name,
			sum(t.in_traf) * coalesce(iptv.coef,1) in_traf,
			sum(t.out_traf)* coalesce(iptv.coef,1) out_traf,
			sum(t.total_traf)  * coalesce(iptv.coef,1) total_traf,
			null cms_order,
			null cms_service,
			null cms_client_inn,
			null vrf,
			null rt_import,
			null cms_order_point2address,
			null has_region_lastmile,
			coalesce(iptv.business_service_ruz_key,5) as business_service_ruz_key ,
			coalesce(iptv.segment_key, 22401) as segment_key,
			coalesce(iptv.rc_key,1015) as rc_key,
			coalesce(iptv.business_segment_key,2) as business_segment_key,
			t.rf_id as oebs_r12_branch_ruz_key ,
			t.source ,
			000154 ruz_src_id,
			000154 src_id
	from traffic t
	left join iptv
		on t.rf_id = iptv.rf_id
	group by 
	coalesce(iptv.coef,1),
		iptv.business_service_ruz_key,
		iptv.segment_key,
		iptv.rc_key,
		iptv.business_segment_key,
		t.rf_id,
		t.source
) f
group by
	f.period,
	f.client_name,
	f.cms_order,
	f.cms_service,
	f.cms_client_inn,
	f.vrf,
	f.rt_import,
	f.cms_order_point2address,
	f.has_region_lastmile,
	f.business_service_ruz_key,
	f.segment_key,
	f.rc_key,
	f.business_segment_key,
	f.oebs_r12_branch_ruz_key,
	f.source ,
	f.ruz_src_id,
	f.src_id;
commit;
analyse edw_stg_dm_ruz.pre_fct_ip_mpls_traffic_iptv_1_prt_p000154;