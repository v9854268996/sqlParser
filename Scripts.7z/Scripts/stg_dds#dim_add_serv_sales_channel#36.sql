/*rev.48943 от 08.02.2020*/

truncate table EDW_STG_DDS.T_000036_DIM_ADD_SERV_SALES_CHANNEL;

set gp_recursive_cte_prototype = ON;

insert into EDW_STG_DDS.T_000036_DIM_ADD_SERV_SALES_CHANNEL
(
  add_serv_sc_key,
  start_date,
  oper_id,
  oper_name,
  mrf_service_key,
  product_name,
  mrf_add_service_name,
  account_name,
  service_key,
  sales_channel_key,
  sales_channel,
  init_system,
  branch_key,
  dop_service_key,
  src_id
)
WITH dfobj_recur
AS
  (
    WITH recursive dgo
    AS 
    (
      SELECT t.dfobj
      FROM EDW_ODS.T_000041_TSERV_TREE t
      WHERE (t.dfmaster IN (18609288095) OR dfobj IN (22998198791, 26897278077))
        and t.deleted_ind = 0 and t.exp_dttm = '2999-12-31 00:00:00'
      UNION ALL
      SELECT t.dfobj
      FROM EDW_ODS.T_000041_TSERV_TREE t
      JOIN dgo ON t.dfmaster = dgo.dfobj 
      WHERE t.deleted_ind = 0 and t.exp_dttm = '2999-12-31 00:00:00'
    )
    SELECT *
    FROM dgo
  )
SELECT q_cos.dfservconst::bigint 
  || case 
      when q_cos.dfonenach_dgo is not null and tnach.dfservconst is not null then '#' || q_cos.dfonenach_dgo::bigint
      else '' 
    end                    as add_serv_sc_key,  -- ID УСЛУГИ В АСР
  q_cos.dforder_close_date as start_date,  -- ДАТА И ВРЕМЯ ПОДКЛЮЧЕНИЯ
  t_u.dfname               as oper_id, -- ЛОГИН СОТРУДНИКА
  t_e.dfname               as oper_name, -- ФИО СОТРУДНИКА
  tsrv.src_id || ';' || coalesce(tnach_serv.dfservice::numeric(38), tsrv.dfservice::numeric(38)) as mrf_service_key,
  null as product_name,
  serv.dfnamesmall as mrf_add_service_name, --  УСЛУГА "ГАРАНТИЯ ПЛЮС" mrf_add_service_name,  --НАЗВАНИЕ УСЛУГИ ДГО
  q_sa.dfabonent as account_name, -- НОМЕР ЛИЦЕВОГО СЧЁТА АБОНЕНТА
  tsrv.src_id || ';' || coalesce(tnach_serv.dfservice::numeric(38), tsrv.dfservice::numeric(38)) as service_key,
  case
    when t_sch.dfname is null then '-2'
    else regexp_replace(trim(upper(t_sch.dfname)),'[ ]+',' ','g')
  end as sales_channel_key,
  t_sch.dfname as sales_channel,
  null as init_system,
  tsrv.src_id || ';' || tsrv.dfbranch::numeric(38) as branch_key,
  tsrv.src_id || ';' || coalesce(tnach_serv.dfservice::numeric(38), tsrv.dfservice::numeric(38)) as dop_service_key, -- КАНАЛ ПРОДАЖ
  tsrv.src_id -- СИСТЕМА – ИНИЦИАТОР ПОДКЛЮЧЕНИЯ
FROM EDW_ODS.T_000041_TSA_EQUIP t_se 
JOIN edw_ods.T_000041_TUSER t_u ON t_u.dfobj = t_se.a_t_olap_user and t_u.deleted_ind = 0 and t_u.exp_dttm = '2999-12-31 00:00:00'
JOIN edw_ods.T_000041_TCRM_ORDER t_co ON t_co.dfobj = t_se.tsa and t_co.deleted_ind = 0 and t_co.exp_dttm = '2999-12-31 00:00:00'
JOIN edw_ods.T_000041_TSA_SUBORDER t_ss ON t_ss.dfobj = t_se.dfobj and t_ss.deleted_ind = 0 and t_ss.exp_dttm = '2999-12-31 00:00:00'
JOIN (
        SELECT *
        FROM EDW_ODS.T_000041_TCRM_ORDER_RENT sq_cor 
        WHERE (
                SQ_COR.TSERV_TREE_PROMO IN (
                                            SELECT dfobj
                                            FROM dfobj_recur
                                          ) 
                OR sq_cor.DFDGO IS NOT NULL
              )
          and sq_cor.deleted_ind = 0 
          and sq_cor.exp_dttm = '2999-12-31 00:00:00'
      ) t_cor ON t_cor.tsa_suborder = t_se.dfobj
JOIN (
        SELECT -- ОПРЕДЕЛЕНИЕ УСЛУГ С ЕДИНОВРЕМЕННЫМИ ПЛАТЕЖАМИ
          sq_cos.*,
          'SALE' as sale_type
        FROM EDW_ODS.T_000041_TCRM_ORDER_SERVCONST sq_cos 
        WHERE NOT EXISTS (
                            SELECT *
                            FROM EDW_ODS.T_000041_TCRM_ORDER_SERVCONST sq2_cos
                            WHERE sq2_cos.dfservconst_master = sq_cos.dfservconst
                          )
          and sq_cos.deleted_ind = 0 
          and sq_cos.exp_dttm = '2999-12-31 00:00:00'
        UNION ALL
        -- ОПРЕДЕЛЕНИЕ УСЛУГ КАК ДОПУСЛУГИ
        SELECT sq_cos.*,
          'RENT' as sale_type
        FROM EDW_ODS.T_000041_TCRM_ORDER_SERVCONST sq_cos
        WHERE sq_cos.dfservconst_master IS NOT NULL
          AND sq_cos.tcrm_order_servtype IN (20987395431) --УСЛУГА ДЛЯ ДГО ОБОРУДОВАНИЯ
          and sq_cos.deleted_ind = 0 and sq_cos.exp_dttm = '2999-12-31 00:00:00'
      ) q_cos ON q_cos.dfobj = t_cor.tcrm_order_servconst
JOIN EDW_ODS.T_000036_TSERVCONST tsrv on tsrv.dfservconst = q_cos.dfservconst 
  and tsrv.deleted_ind = 0
  and coalesce(tsrv.dfdelete, '') != 'T'
  and coalesce(tsrv.dfcondition, '') <> 'T'
JOIN EDW_ODS.T_000036_TDOGOVOR tdogovor on tdogovor.dfdogovor = tsrv.dfdogovor
  and tdogovor.dfdogtype <> 1234567
  and tdogovor.deleted_ind = 0
  and (tdogovor.src_id = 39 or (tdogovor.dfdelete <> 'T' or tdogovor.dfdelete is null))
  and tdogovor.dfactivity = 23
LEFT JOIN (
            SELECT dfservconst, 
              count(distinct dfservice) as cnt 
            FROM EDW_ODS.T_000036_TSERVNACH 
            WHERE dfonenach is not null
              and deleted_ind = 0
            GROUP BY dfservconst
          ) tnach on tnach.dfservconst = tsrv.dfservconst and tnach.cnt > 1
LEFT JOIN (
            SELECT distinct dfservconst,
              dfservice,
              dfonenach 
            FROM EDW_ODS.T_000036_TSERVNACH
            WHERE dfonenach is not null
              and deleted_ind = 0
          ) tnach_serv on tnach_serv.dfservconst = tsrv.dfservconst
  and q_cos.dfonenach_dgo = tnach_serv.dfonenach
LEFT JOIN EDW_ODS.T_000036_TSERVICE serv on serv.dfservice = coalesce(tnach_serv.dfservice::numeric(38), tsrv.dfservice::numeric(38))
  and serv.deleted_ind = 0
LEFT JOIN EDW_ODS.T_000041_TCLI_EQUIPMENT_SALE t_ces ON t_ces.dfobj = t_cor.tcli_equipment_sale 
  and t_ces.deleted_ind = 0 
  and t_ces.exp_dttm = '2999-12-31 00:00:00'
LEFT JOIN (
            SELECT
              sq_sd.dfobj,
              sq_sa.dfabonent
            FROM EDW_ODS.T_000041_TSA_DOGOVOR sq_sd,
              EDW_ODS.T_000041_TSA_ABONENT sq_sa
            WHERE sq_sa.dfobj = sq_sd.tsa_abonent
              and sq_sd.deleted_ind = 0 and sq_sd.exp_dttm = '2999-12-31 00:00:00'
              and SQ_SA.deleted_ind = 0 and SQ_SA.exp_dttm = '2999-12-31 00:00:00'
          ) q_sa ON q_sa.dfobj = t_cor.tsa_dogovor
LEFT JOIN EDW_ODS.T_000041_TCLI_EQUIPMENT_DGO t_ced ON t_ced.dfobj = t_cor.dfdgo 
  and t_ced.deleted_ind = 0
  and t_ced.exp_dttm = '2999-12-31 00:00:00'
LEFT JOIN EDW_ODS.T_000041_TSERV_TREE t_st ON t_st.dfobj = coalesce(t_ced.tserv_tree, t_cor.tserv_tree_promo)
  and t_st.deleted_ind = 0
  and t_st.exp_dttm = '2999-12-31 00:00:00'
LEFT JOIN EDW_ODS.T_000041_A_T_OLAP_REGION t_or ON t_or.dfobj = t_se.a_t_olap_region
  and t_or.deleted_ind = 0
  and t_or.exp_dttm = '2999-12-31 00:00:00'
LEFT JOIN EDW_ODS.T_000041_TTPO t_t ON t_t.dfobj = t_co.ttpo
  and t_t.deleted_ind = 0
  and t_t.exp_dttm = '2999-12-31 00:00:00'
LEFT JOIN EDW_ODS.T_000041_TSALES_CHANNELS t_sch ON t_sch.dfobj = t_co.tsales_channels
  and t_sch.deleted_ind = 0
  and t_sch.exp_dttm = '2999-12-31 00:00:00'
LEFT JOIN EDW_ODS.T_000041_A_T_EMPLOYEES t_e ON t_e.dfobj = t_u.t_employees
  and t_e.deleted_ind = 0
  and t_e.exp_dttm = '2999-12-31 00:00:00'
WHERE t_se.deleted_ind = 0
  and t_se.exp_dttm = '2999-12-31 00:00:00'
;


analyze EDW_STG_DDS.T_000036_DIM_ADD_SERVICE;