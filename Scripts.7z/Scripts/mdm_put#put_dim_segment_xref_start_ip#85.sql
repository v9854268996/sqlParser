/*rev.10473 от 11.05.2018*/
delete from edw_stg_mdm.put_dim_segment_xref_start where region_id = 'SIBIR' and src_id = 000085;

insert into edw_stg_mdm.put_dim_segment_xref_start (segment_key,segment_name,region_id,src_id)
select distinct 
       (round(user_type.user_type_id)) as code,
       user_type.name,
	   'SIBIR' as region_id
	   ,src_id
from edw_ods.t_000085_t_users t_users
       join edw_ods.t_000085_t_user_type_ref user_type on t_users.user_type_id = user_type.user_type_id	   
;
commit;
analyse edw_stg_mdm.put_dim_segment_xref_start;
