/*rev.45673 от 26.12.2019*/
set optimizer=on;

truncate table edw_stg_dds.t_000049_tfct_add_service_charges;
insert into edw_stg_dds.t_000049_tfct_add_service_charges
  (
    add_service_key,
    service_key,
    branch_key,
    dop_service_key,
    cnt_pay_days,
    cnt_notpay_days,
    charge_rub,
    vat_rub,
    charge_period_start_dttm,
    src_id
  )
with stg_1 as
  (
    select
      '1#'||round(tts.billing_id)
        ||'#'||round(tts.service_id)
        ||'#'||round(tts.svc_id)
        ||'#'||round(tts.user_id)                                       as total_charge_key
      , tts.svc_id                                                      as service_key
      , tts.svc_id                                                      as dop_service_key
      , tu.dept_id                                                      as branch_key
      , null                                                            as city_key
      , to_date(tts.billing_id::text, 'YYYYMM')                         as charge_period_start_dttm
      , tts.summ - tts.tax                                              as sum_total
      , tts.tax                                                         as vat_rub
      , '1#'||round(tts.service_id)                                     as add_service_key
      , tts.src_id                                                      as src_id
    from
      edw_ods.t_000049_t_tarifed_services     tts
      join
        edw_ods.t_000049_t_users              tu
          on tu.user_id=tts.user_id
          and tu.exp_dttm=to_date('29991231', 'YYYYMMDD')
          and tu.iscorp='N'
    where
      round(tts.billing_id) between substr('20190601', 1, 6)::int and substr('20190630', 1, 6)::int

  union all

    /*связанные корректировки*/
    select
        '3#'||tsc.corr_id::text                                         as total_charge_key
      , tsc.svc_id                                                      as service_key
      , tsc.svc_id                                                      as dop_service_key
      , tu.dept_id                                                      as branch_key
      , null                                                            as city_key
      , to_date(tsc.billing_id::text, 'YYYYMM')                         as charge_period_start_dttm
      , decode(tsc.svc_corr_type::numeric,1,-1,2,-1,1)*(tsc.summ - tsc.tax) as sum_total
      , decode(tsc.svc_corr_type::numeric,1,-1,2,-1,1)*(tsc.tax)        as vat_rub
      , coalesce('1#'||tsc.service_id, '2#'||tsc.oth_svc_id)            as add_service_key
      , tsc.src_id                                                      as src_id
    from
      edw_ods.t_000049_t_svc_correction       tsc 
      join
        edw_ods.t_000049_t_users              tu
          on tu.user_id=tsc.user_id
          and tu.exp_dttm=to_date('29991231', 'YYYYMMDD')
          and tu.iscorp='N'
    where 
      tsc.billing_id between substr('20190601', 1, 6)::int and substr('20190630', 1, 6)::int 
      and
        (
          tsc.service_id is not null
          or tsc.oth_svc_id is not null
        )

  union all

    select 
        '2#'||tos.oth_svc_id                                            as total_charge_key
      , tos.svc_id                                                      as service_key
      , tos.svc_id                                                      as dop_service_key
      , tu.dept_id                                                      as branch_key
      , null                                                            as city_key
      , to_date(tos.billing_id::text, 'YYYYMM')                         as charge_period_start_dttm  
      , tos.summ-tos.tax                                                as sum_total
      , tos.tax                                                         as vat_rub
      , '2#'||tos.oth_svc_id                                            as add_service_key
      , tos.src_id                                                      as src_id
    from
      edw_ods.t_000049_t_other_svc            tos 
      join
        edw_ods.t_000049_t_users              tu
          on tu.user_id=tos.user_id
          and tu.exp_dttm=to_date('29991231', 'YYYYMMDD')
          and tu.iscorp='N'
      left join
        edw_ods.t_000049_t_svc_ref            ref2
          on ref2.svc_id = tos.svc_id
          and ref2.exp_dttm = to_date('29991231', 'YYYYMMDD')
    where
      tos.billing_id between substr('20190601', 1, 6)::int and substr('20190630', 1, 6)::int

  union all

    /*остальные корректирвки*/
    select
        total_charge_key                                                as total_charge_key
      , service_key                                                     as service_key
      , dop_service_key                                                 as dop_service_key
      , branch_key                                                      as branch_key
      , city_key                                                        as city_key
      , charge_period_start_dttm                                        as charge_period_start_dttm
      , sum_total                                                       as sum_total
      , vat_rub                                                         as vat_rub
      , add_service_key                                                 as add_service_key
      , src_id                                                          as src_id
    from
      (
        select
            '3#'||tsc.corr_id::text                                     as total_charge_key
          , tsc.svc_id                                                  as service_key
          , tsc.svc_id                                                  as dop_service_key
          , tu.dept_id                                                  as branch_key
          , null                                                        as city_key
          , to_date(tsc.billing_id::text, 'YYYYMM')                     as charge_period_start_dttm
          , decode(tsc.svc_corr_type::numeric,1,-1,2,-1,1)*(tsc.summ - tsc.tax) as sum_total
          , decode(tsc.svc_corr_type::numeric,1,-1,2,-1,1)*(tsc.tax)    as vat_rub
          , coalesce('1#'||ts.service_id, '2#'||tos.oth_svc_id)         as add_service_key
          , tsc.src_id                                                  as src_id
          , row_number() over ( partition by corr_id
                                order by coalesce(ts.date_begin,to_date(tos.billing_id::text,'YYYYMM'))) as rn
        from
          edw_ods.t_000049_t_svc_correction   tsc
        join
          edw_ods.t_000049_t_users            tu
            on tu.user_id=tsc.user_id
            and tu.exp_dttm=to_date('29991231', 'YYYYMMDD')
            and tu.iscorp='N'
        left join
          edw_ods.t_000049_t_services         ts
            on ts.svc_id=tsc.svc_id
            and ts.user_id=tsc.user_id
            and ts.date_begin <=to_date('20190630', 'YYYYMMDD')
        left join
          edw_ods.t_000049_t_other_svc        tos
            on tos.svc_id=tsc.svc_id
            and tos.user_id=tsc.user_id
            and tsc.billing_id>=tos.billing_id
        where
          tsc.billing_id between substr('20190601', 1, 6)::int and substr('20190630', 1, 6)::int 
          and
            (
              tsc.service_id is null
              and tsc.oth_svc_id is null
            )
      ) t1
    where
      rn=1
  )

select
    coalesce(stg_1.add_service_key, das.add_service_key)                                                        as add_service_key
  , coalesce(stg_1.service_key::text, das.service_key)                                                          as service_key
  , coalesce(stg_1.branch_key::text, das.branch_key)                                                            as branch_key
--, stg_1.city_key
  , coalesce(stg_1.dop_service_key::text, das.dop_service_key)                                                  as dop_service_key
  , case
      when coalesce(dds.dop_usluga_promo_name,0) + coalesce(dds.dop_usluga_bonus_type_name, 0)=0
        then greatest(ceil(EXTRACT(epoch from least(date_trunc('day',das.end_date)+interval '1 second'
                                                    , to_date('20190601', 'YYYYMMDD') + interval '1 month')-
                                    greatest(date_trunc('day',das.start_date),to_date('20190601', 'YYYYMMDD')))/86400),0)
      else 0
    end                                                                                                         as cnt_pay_days
  , case
      when coalesce(dds.dop_usluga_promo_name,0) + coalesce(dds.dop_usluga_bonus_type_name, 0)>0 
        then greatest(ceil(EXTRACT(epoch from least(date_trunc('day',das.end_date)+interval '1 second'
                                                    , to_date('20190601', 'YYYYMMDD') + interval '1 month')-
                                    greatest(date_trunc('day',das.start_date),to_date('20190601', 'YYYYMMDD')))/86400),0)
      else 0
    end                                                                                                         as cnt_notpay_days
  , sum(coalesce(stg_1.sum_total,0))                                                                            as charge_rub
  , sum(coalesce(stg_1.vat_rub,0))                                                                              as vat_rub
  , coalesce(stg_1.charge_period_start_dttm,date_trunc('month',to_date('20190601', 'YYYYMMDD'))::timestamp)     as charge_period_start_dttm
  , coalesce(stg_1.src_id,das.src_id)                                                                           as src_id
from
  stg_1
right join
  edw_stg_dds.t_000049_dim_add_service            das
    on stg_1.add_service_key=das.add_service_key
left join
  edw_dds.hub_dim_dop_service                     hdds
    on hdds.source_key=stg_1.dop_service_key::text
    and hdds.src_id=das.src_id 
    and hdds.exp_dttm=to_date('29991231', 'YYYYMMDD')
left join
  edw_dds.dim_dop_service                         dds
    on dds.dop_service_key=hdds.dop_service_key
    and dds.end_dttm=to_date('29991231', 'YYYYMMDD')
where
  (
    stg_1.add_service_key is not null
    or date_trunc('month',to_date('20190601', 'YYYYMMDD'))::timestamp between date_trunc('month',start_date)::timestamp and date_trunc('month',end_date)::timestamp
  )
group by
    coalesce(stg_1.add_service_key, das.add_service_key)
  , coalesce(stg_1.service_key::text, das.service_key)
  , coalesce(stg_1.branch_key::text, das.branch_key)
--, stg_1.city_key
  , coalesce(stg_1.dop_service_key::text, das.dop_service_key)
  , case
      when coalesce(dds.dop_usluga_promo_name,0) +  coalesce(dds.dop_usluga_bonus_type_name, 0)=0
        then greatest(ceil(EXTRACT(epoch from least(date_trunc('day',das.end_date)+interval '1 second'
                                                    , to_date('20190601', 'YYYYMMDD') + interval '1 month')-
                                    greatest(date_trunc('day',das.start_date),to_date('20190601', 'YYYYMMDD')))/86400),0)
      else 0
    end
  , case
      when coalesce(dds.dop_usluga_promo_name,0) +  coalesce(dds.dop_usluga_bonus_type_name, 0)>0 
        then greatest(ceil(EXTRACT(epoch from least(date_trunc('day',das.end_date)+interval '1 second'
                                                    , to_date('20190601', 'YYYYMMDD') + interval '1 month')-
                                    greatest(date_trunc('day',das.start_date),to_date('20190601', 'YYYYMMDD')))/86400),0)
      else 0
    end
  , coalesce(stg_1.charge_period_start_dttm,date_trunc('month',to_date('20190601', 'YYYYMMDD'))::timestamp) 
  , coalesce(stg_1.src_id,das.src_id)
;
analyze edw_stg_dds.t_000049_tfct_add_service_charges;  
