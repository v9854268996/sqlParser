/*rev7550 (19.09.17)*/
truncate table edw_stg_dds.t_000079_dim_port;
insert into edw_stg_dds.t_000079_dim_port (
	eff_dttm, --Идентификатор статуса порта
	exp_dttm,
	network_element_key, --Наименование статуса порта
	port_involv_type_key,
	port_key, --Дата начала действия записи
	port_num,
	port_status_key ,--Дата окончания действия записи
	port_type_key,
	technology_type_key,
	src_id,
	load_dttm
)

select 
eff_dttm, --Идентификатор статуса порта
'2999-12-31 00:00:00' as exp_dttm,
network_element_key, --Наименование статуса порта
port_involv_type_key,
port_key, --Дата начала действия записи
port_num,
port_status_key ,--Дата окончания действия записи
port_type_key,
technology_type_key,
'79' as src_id,
now() as load_dttm
 			from (
 --оборудование
 
 select 
         '01.01.1900'::date as eff_dttm,
            case when p.PRIZNAKDEL = 1 then p.DATEMODIF else '2999-12-31 00:00:00' end  as exp_dttm
            --,case when p.PORT_ID_PRNT > 0 then 1 else 2 end interface_type_key
		   ,(select ent_prefix from edw_ods.t_000079_edwv_edw_sltu_prefix where ent_name='eth_comm_atu')||p.COMM_ID   as network_element_key
            --,th.MAX_SPEED                     as port_capacity_nval
            ,p.TYPPORTUSE_KOD                 as port_involv_type_key
            ,(select ent_prefix from edw_ods.t_000079_edwv_edw_sltu_prefix where ent_name='eth_port_atu')||p.PORT_ID as port_key
            ,case when p.PORT_ID_PRNT > 0 then pp.port_name||'\\'||p.PORT_NAME end  as port_num
           ,(select ent_prefix from edw_ods.t_000079_edwv_edw_sltu_prefix where ent_name='eth_sostport')||p.SOSTPORT_KOD  as port_status_key
           ,(select ent_prefix from edw_ods.t_000079_edwv_edw_sltu_prefix where ent_name='eth_comm_atu')||p.PORTCATEG_KOD as port_type_key
            ,coalesce(th.TECH_KOD,-1) as technology_type_key
            from  edw_ods.t_000079_edwv_eth_port_atu   p
			
  left join edw_ods.t_000079_edwv_eth_portcateg  pc on pc.portcateg_kod = p.PORTCATEG_KOD
   left join edw_ods.t_000079_edwv_typtech_tree   th on pc.TECH_KOD      > 0
and th.TECH_KOD      = case when pc.DSL_TECH_KOD > 0 then pc.DSL_TECH_KOD else pc.TECH_KOD end
left join edw_ods.t_000079_edwv_eth_port_atu   pp on pp.port_id       = p.PORT_ID_PRNT and p.PORT_ID_PRNT > 0

union all

--КУ
			select '01.01.1900'::date as eff_dttm
            ,case when p.PRIZNAKDEL = 1 then p.DATEMODIF else '2999-12-31 00:00:00' end  as exp_dttm
            --,2 as interface_type_key
            ,(select ent_prefix from edw_ods.t_000079_edwv_edw_sltu_prefix where ent_name='eth_patchp_atu')||p.PATCHP_ID as network_element_key
            --,null                             as port_capacity_nval
            ,NULL                             as port_involv_type_key
            ,(select ent_prefix from edw_ods.t_000079_edwv_edw_sltu_prefix where ent_name='eth_port_pp_atu')||p.PORT_PP_ID as port_key
            ,p.NUMB::VARCHAR  as port_num
            ,(select ent_prefix from edw_ods.t_000079_edwv_edw_sltu_prefix where ent_name='eth_sostport')||p.SOSTPORT_KOD  as port_status_key
            ,(select ent_prefix from edw_ods.t_000079_edwv_edw_sltu_prefix where ent_name='eth_patchp_atu')||pp.CATEGPATCHP_KOD as port_type_key
            ,NULL     as technology_type_key
        from edw_ods.t_000079_edwv_eth_port_pp_atu p
  left join edw_ods.t_000079_edwv_eth_patchp_atu  pp on pp.PATCHP_ID       = p.PATCHP_ID



--пары магистрального бокса
union all
select '01.01.1900'::date as eff_dttm   
            , case when p.PRDEL = 1 then p.DATEMODIF else '2999-12-31 00:00:00' end as exp_dttm
            --,2 as interface_type_key
            ,(select ent_prefix from edw_ods.t_000079_edwv_edw_sltu_prefix where ent_name='bboxm_atu')||p.BBOX_ID as network_element_key
            --,null                             as port_capacity_nval
            ,NULL                             as port_involv_type_key
            ,(select ent_prefix from edw_ods.t_000079_edwv_edw_sltu_prefix where ent_name='pairm_atu')||p.PAIR_ID as port_key
            ,p.NUMB::VARCHAR  as port_num
            ,(select ent_prefix from edw_ods.t_000079_edwv_edw_sltu_prefix where ent_name='sost')||p.SOST_KOD  as port_status_key
            ,(select ent_prefix from edw_ods.t_000079_edwv_edw_sltu_prefix where ent_name='pairso_atu')||'0' as port_type_key
            ,NULL   as technology_type_key
        from edw_ods.t_000079_edwv_pairm_atu p
		


union all
--пары передаточного бокса
select '01.01.1900'::date as eff_dttm    
            ,case when p.PRDEL = 1 then p.DATEMODIF else '2999-12-31 00:00:00' end as exp_dttm
            --,2 as interface_type_key
            ,(select ent_prefix from edw_ods.t_000079_edwv_edw_sltu_prefix where ent_name='bboxp_atu')||p.BBOX_ID as network_element_key
            --,null                             as port_capacity_nval
            ,NULL                             as port_involv_type_key
            ,(select ent_prefix from edw_ods.t_000079_edwv_edw_sltu_prefix where ent_name='pairp_atu')||p.PAIR_ID as port_key
            ,p.NUMB::VARCHAR  as port_num
            ,(select ent_prefix from edw_ods.t_000079_edwv_edw_sltu_prefix where ent_name='sost')||p.SOST_KOD  as port_status_key
            ,(select ent_prefix from edw_ods.t_000079_edwv_edw_sltu_prefix where ent_name='pairso_atu')||'0' as port_type_key
            ,NULL    as technology_type_key
        from edw_ods.t_000079_edwv_pairp_atu p
	
union all
--пары распределительного бокса
select '01.01.1900'::date as eff_dttm
            ,case when p.PRDEL = 1 then p.DATEMODIF else '2999-12-31 00:00:00' end as exp_dttm
            --,2 as interface_type_key
            ,(select ent_prefix from edw_ods.t_000079_edwv_edw_sltu_prefix where ent_name='bboxr_atu')||p.BBOX_ID as network_element_key
            --,null                             as port_capacity_nval
            ,NULL                             as port_involv_type_key
            ,(select ent_prefix from edw_ods.t_000079_edwv_edw_sltu_prefix where ent_name='pairr_atu')||p.PAIR_ID as port_key
            ,p.NUMB::VARCHAR  as port_num
            ,(select ent_prefix from edw_ods.t_000079_edwv_edw_sltu_prefix where ent_name='sost')||p.SOST_KOD  as port_status_key
            ,(select ent_prefix from edw_ods.t_000079_edwv_edw_sltu_prefix where ent_name='pairso_atu')||'0' as port_type_key
            ,NULL    as technology_type_key
        from edw_ods.t_000079_edwv_pairr_atu p
	
union all
--пары спец бокса
select '01.01.1900'::date as eff_dttm
            ,case when p.PRIZNAKDEL = 1 then p.DATEMODIF else '2999-12-31 00:00:00' end as exp_dttm
            --,2 as interface_type_key
            ,(select ent_prefix from edw_ods.t_000079_edwv_edw_sltu_prefix where ent_name='bboxso_atu')||p.BBOX_ID as network_element_key
            --,null                             as port_capacity_nval
            ,NULL                            as port_involv_type_key
            ,(select ent_prefix from edw_ods.t_000079_edwv_edw_sltu_prefix where ent_name='pairso_atu')||p.PAIR_ID as port_key
            ,p.NUMB::VARCHAR  as port_num
            ,(select ent_prefix from edw_ods.t_000079_edwv_edw_sltu_prefix where ent_name='sost')||p.SOST_KOD  as port_status_key
            ,(select ent_prefix from edw_ods.t_000079_edwv_edw_sltu_prefix where ent_name='pairso_atu')||'0' as port_type_key
            ,NULL     as technology_type_key
        from edw_ods.t_000079_edwv_pairso_atu p		
		
union all
--пары ПП
select '01.01.1900'::date as eff_dttm
            ,case when p.PRDEL = 1 then p.DATEMODIF else '2999-12-31 00:00:00' end as exp_dttm
            --,2 as interface_type_key
            ,(select ent_prefix from edw_ods.t_000079_edwv_edw_sltu_prefix where ent_name='zp_atu')||p.zp_ID as network_element_key
           -- ,null                             as port_capacity_nval
            ,NULL                            as port_involv_type_key
            ,(select ent_prefix from edw_ods.t_000079_edwv_edw_sltu_prefix where ent_name='pairzp_atu')||p.PAIR_ID as port_key
            ,p.NUMB::VARCHAR  as port_num
            ,(select ent_prefix from edw_ods.t_000079_edwv_edw_sltu_prefix where ent_name='sost')||p.SOST_KOD  as port_status_key
            ,(select ent_prefix from edw_ods.t_000079_edwv_edw_sltu_prefix where ent_name='pairso_atu')||'0' as port_type_key
            ,NULL   as technology_type_key
        from edw_ods.t_000079_edwv_pairzp_atu p
 
 union all
 --пары КМС
 select '01.01.1900'::date as eff_dttm
            ,case when p.PRDEL = 1 then p.DATEMODIF else '2999-12-31 00:00:00' end as exp_dttm
           -- ,2 as interface_type_key
            ,(select ent_prefix from edw_ods.t_000079_edwv_edw_sltu_prefix where ent_name='zpsl_atu')||p.zp_ID as network_element_key
            --,null                             as port_capacity_nval
            ,NULL                             as port_involv_type_key
            ,(select ent_prefix from edw_ods.t_000079_edwv_edw_sltu_prefix where ent_name='pairzpsl_atu')||p.PAIR_ID as port_key
            ,p.NUMB::VARCHAR  as port_num
            ,(select ent_prefix from edw_ods.t_000079_edwv_edw_sltu_prefix where ent_name='sost')||p.SOST_KOD  as port_status_key
            ,(select ent_prefix from edw_ods.t_000079_edwv_edw_sltu_prefix where ent_name='pairso_atu')||'0' as port_type_key
            ,NULL    as technology_type_key
        from edw_ods.t_000079_edwv_pairzpsl_atu p
 
 union all
 --пары рамок
  select '01.01.1900'::date as eff_dttm
            ,case when p.PRIZNAKDEL = 1 then p.DATEMODIF else '2999-12-31 00:00:00' end as exp_dttm
            --,2 as interface_type_key
            ,(select ent_prefix from edw_ods.t_000079_edwv_edw_sltu_prefix where ent_name='zpramki_atu')||p.zp_ID as network_element_key
            --,null                             as port_capacity_nval
            ,NULL                            as port_involv_type_key
            ,(select ent_prefix from edw_ods.t_000079_edwv_edw_sltu_prefix where ent_name='pairzpramki_atu')||p.PAIR_ID as port_key
            ,p.NUMB::VARCHAR  as port_num
            ,(select ent_prefix from edw_ods.t_000079_edwv_edw_sltu_prefix where ent_name='sost')||p.SOST_KOD  as port_status_key
            ,(select ent_prefix from edw_ods.t_000079_edwv_edw_sltu_prefix where ent_name='pairso_atu')||'0' as port_type_key
            ,NULL    as technology_type_key
        from edw_ods.t_000079_edwv_pairzpramki_atu p

 union all
 --пары переходных рамок
select '01.01.1900'::date as eff_dttm
            ,case when p.PRIZNAKDEL = 1 then p.DATEMODIF else '2999-12-31 00:00:00' end as exp_dttm
            --,2 as interface_type_key
            ,(select ent_prefix from edw_ods.t_000079_edwv_edw_sltu_prefix where ent_name='zpramkisl_atu')||p.zp_ID as network_element_key
            --,null                             as port_capacity_nval
            ,NULL                             as port_involv_type_key
            ,(select ent_prefix from edw_ods.t_000079_edwv_edw_sltu_prefix where ent_name='pairzpramkisl_atu')||p.PAIR_ID as port_key
            ,p.NUMB::VARCHAR  as port_num
            ,(select ent_prefix from edw_ods.t_000079_edwv_edw_sltu_prefix where ent_name='sost')||p.SOST_KOD  as port_status_key
            ,(select ent_prefix from edw_ods.t_000079_edwv_edw_sltu_prefix where ent_name='pairso_atu')||'0' as port_type_key
            ,NULL    as technology_type_key
        from edw_ods.t_000079_edwv_pairzpramkisl_atu p

union all
--пары АУ
select '01.01.1900'::date as eff_dttm
            ,case when p.PRDEL = 1 then p.DATEMODIF else '2999-12-31 00:00:00' end as exp_dttm
            --,2 as interface_type_key
            ,(select ent_prefix from edw_ods.t_000079_edwv_edw_sltu_prefix where ent_name='boxsph_atu')||p.BOX_ID as network_element_key
            --,null                             as port_capacity_nval
            ,NULL                             as port_involv_type_key
            ,(select ent_prefix from edw_ods.t_000079_edwv_edw_sltu_prefix where ent_name='pairsph_atu')||p.PAIR_ID as port_key
            ,p.NUMB::VARCHAR  as port_num
            ,(select ent_prefix from edw_ods.t_000079_edwv_edw_sltu_prefix where ent_name='sost')||p.SOST_KOD  as port_status_key
            ,(select ent_prefix from edw_ods.t_000079_edwv_edw_sltu_prefix where ent_name='pairso_atu')||'0' as port_type_key
            ,NULL    as technology_type_key
        from edw_ods.t_000079_edwv_pairsph_atu p
	
		)t
		;
	