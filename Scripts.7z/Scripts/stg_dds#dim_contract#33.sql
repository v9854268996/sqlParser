/*rev.33301 15.07.2019*/
TRUNCATE edw_stg_dds.t_000033_dim_contract;
INSERT INTO edw_stg_dds.t_000033_dim_contract
(
	account_key,
	contract_key,
	parent_contract_key,
	partner_key,
	contract_cancellation_dt,
	contract_cval,
	eff_dttm,
	exp_dttm,
	src_id,
	load_dttm
)
WITH sel AS
(
	select 
		dfdogovor,
		min(dfdatebegin) as dfdatebegin,
		max(dfdateend) as dfdateend
	from (
		SELECT
			dop.dfdogovor,
			coalesce(dop.dfdatebegin,to_date('19000101', 'YYYYMMDD')::timestamp) AS dfdatebegin,
			coalesce(dop.dfdateend, to_date('29991231', 'YYYYMMDD')::timestamp)   AS dfdateend
		FROM edw_ods.t_000033_tdogovor_operator dop
		WHERE dop.deleted_ind = 0

		union all                               

		SELECT
			dfdogovor,
			coalesce(dfdatebegin,to_date('19000101', 'YYYYMMDD')::timestamp) AS dfdatebegin,
			coalesce(dfdateend, to_date('29991231', 'YYYYMMDD')::timestamp)   AS dfdateend
		FROM edw_ods.t_000033_tdogovor_union du
		WHERE du.deleted_ind = 0
	) l
	group by 
		dfdogovor
), 
sel1 AS
(
	SELECT
		d.dfdogovor                                       AS contract_key,
		d.dfabonent                                       AS partner_key,
		d.dfdogovor                                       AS account_key,
		coalesce(sel.dfdateend, to_date('29991231', 'YYYYMMDD')::timestamp)   AS contract_cancellation_dt,
		coalesce(sel.dfdatebegin, to_date('19000101', 'YYYYMMDD')::timestamp) AS start_dates,
		coalesce(sel.dfdateend, to_date('29991231', 'YYYYMMDD')::timestamp)   AS end_dates,
		d.dfnumber                                        AS contract_cval,
		d.src_id                                          AS src_id,
		row_number() OVER (PARTITION BY d.dfdogovor ORDER BY sel.dfdatebegin, sel.dfdateend) AS rn
	FROM edw_ods.t_000033_tdogovor d
	LEFT JOIN sel ON (sel.dfdogovor = d.dfdogovor)
	WHERE 1 = 1
		and d.dfdogtype <> 1234567
		AND d.deleted_ind = 0
		AND (d.src_id = 39 OR (d.dfdelete <> 'T' OR d.dfdelete IS NULL))
),
tds as ( /*схлопывание истории*/
	SELECT
		dfdogovor,
		src_id,
		dfactivity_dop_segment,
		suma,
		min(ndfdatebegin) AS dfdatebegin,
		max(ndfdateend)   AS dfdateend
	FROM (
		SELECT
			*,
			sum(dif) OVER ( PARTITION BY dfdogovor ORDER BY rn ) suma,
			decode(rn, 1, to_date('19000101', 'YYYYMMDD')::timestamp, dfdatebegin) AS ndfdatebegin,
			decode(rn, max(rn) OVER ( PARTITION BY dfdogovor ), to_date('29991231', 'YYYYMMDD')::timestamp, dfdateend) AS ndfdateend
		FROM (
			SELECT
				*,
				CASE
					WHEN lag(dfactivity_dop_segment) OVER ( PARTITION BY dfdogovor ORDER BY rn ) = dfactivity_dop_segment
						THEN 0
						ELSE 1
				END dif
			FROM (
				SELECT
					dfdogovor,
					src_id,
					CASE
						WHEN dfactivity_dop_segment IS NULL or dfactivity_dop_segment = -23
						THEN 'N'
						ELSE 'Y' 
					END  dfactivity_dop_segment,
					dfdatebegin,
					coalesce(dfdateend, to_date('29991231', 'YYYYMMDD')::timestamp) dfdateend,
					row_number() OVER (PARTITION BY dfdogovor ORDER BY dfdatebegin, dfdateend ) as rn
				FROM edw_ods.t_000033_tdog_dop_segment
				WHERE 1 = 1
					and dfactivity_dop_segment IS NOT NULL 
					AND dfdatebegin IS NOT NULL 
					AND deleted_ind = 0
			) lvl1
		) lvl2
	) lvl3
	GROUP BY dfdogovor, src_id, dfactivity_dop_segment, suma
 )
  SELECT
    account_key,
    contract_key,
    null as parent_contract_key,
    partner_key,
    contract_cancellation_dt,
    contract_cval,
    start_date                                     AS eff_dttm,
    end_date                                       AS exp_dttm,
	000033 as src_id,
	now() as load_dttm
  FROM (
     SELECT
       t.account_key,
       t.contract_key,
       t.partner_key || '#' || coalesce(tds.dfactivity_dop_segment, 'N') as partner_key ,
       t.src_id,
       t.contract_cancellation_dt,
       t.contract_cval,
       greatest(t.start_date, dfdatebegin) as start_date,
       least(t.end_date, dfdateend) as end_date
     FROM (
	    SELECT * from 
		(
			 SELECT
				sel1.src_id || ';' || sel1.contract_key :: NUMERIC(38, 0) AS contract_key,
				sel1.src_id || ';' || sel1.account_key :: NUMERIC(38, 0) AS account_key,
				sel1.src_id || ';' || sel1.partner_key :: NUMERIC(38, 0) AS partner_key,
				sel1.src_id,
			    sel1.contract_cancellation_dt,
			    sel1.contract_cval,
				CASE
					WHEN sel1.rn = 1
					THEN to_date('19000101', 'YYYYMMDD')::timestamp
					ELSE sel1.start_dates
				END  AS start_date,
				CASE
					WHEN sel1.rn = max(sel1.rn) OVER (PARTITION BY sel1.contract_key )
					THEN to_date('29991231', 'YYYYMMDD')::timestamp
					ELSE lead(sel1.start_dates)OVER (PARTITION BY sel1.contract_key ORDER BY sel1.rn ) - INTERVAL '1 sec' 
				END  AS end_date
			  FROM sel1
		) t0
		   WHERE 	start_date < end_date
		   and to_date('20190630', 'YYYYMMDD') between start_date and end_date
	 )t	
    left join tds
	 on (1 = 1
		and tds.src_id || ';' || tds.dfdogovor :: NUMERIC(38) = t.account_key
		AND to_date('20190630', 'YYYYMMDD') between  dfdatebegin AND dfdateend
	)
)tttt;
commit;
analyze edw_stg_dds.t_000033_dim_contract;