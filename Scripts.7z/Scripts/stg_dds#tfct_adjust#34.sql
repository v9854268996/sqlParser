/*46632 от 16.01.2020*/ 
  
/*Корректировки начислений*/

truncate edw_stg_dds.t_000034_tfct_adjust;
insert into edw_stg_dds.t_000034_tfct_adjust
(
	adjust_key
	, account_key
	, adjust_amt
	, vat_rub
	, adjust_dttm
	, corr_billing_ID
	, subs_key
	, adjust_type_key
	, service_key
	, src_id
	, rc_key
	, eff_dttm
	, exp_dttm
	, billing_dttm
)
SELECT
    elis1.adjust_key,
    elis1.account_key,
    elis1.adjust_amt,
    elis1.vat_rub,
    elis1.adjust_dttm,
    elis1.corr_billing_id,
    decode(elis1.subs_key26,'-1',elis1.subs_key,elis1.subs_key26) as subs_key,
    elis1.adjust_type_key,
    elis1.service_key,
    elis1.src_id,
    elis1.rc_key,
    elis1.eff_dttm,
    elis1.exp_dttm,
    elis1.billing_dttm	
FROM(
	 select
	   adjust_key
	   , account_key
	   , adjust_amt
	   , vat_rub
	   , adjust_dttm
	   , corr_billing_ID
	   , subs_key
	   , adjust_type_key
	   , service_key
	   , src_id
	   , subs_key26
	   , rc_key
	   , '19000101'::timestamp as eff_dttm
	   , '29991231'::timestamp as exp_dttm
	   , billing_dttm
	 from (
	        --Корректировки Начислений
		SELECT  
		  sn.src_id||';'||Sn.DFSERVNACH::NUMERIC(38,0) as adjust_key   -- Идентификатор корректировки
		  , DECODE( sn.DFNDSINOUT ,'T', sn.DFSUMMA - sn.DFNDSSUMMA,sn.DFSUMMA) as adjust_amt -- Сумма корректировки оплаты
		  , DECODE( Sn.DFNDSINOUT ,'T', Sn.DFNDSSUMMA,0) AS vat_rub -- Сумма НДС, руб.
		  , sn.DFDATEINBEGIN as adjust_dttm   -- Дата создания корректировки. Дата для определения инкримента по корректировкам
		  , sn.src_id||';'||Sn.DFDOGOVOR::NUMERIC(38,0) as account_key   -- Идентификатор лицевого счета
		  , date_part('year', sn.DFDATEBEGIN)||lpad(cast(date_part('month', sn.DFDATEBEGIN) as varchar(2)),2,'0') as corr_billing_ID       -- Идентификатор корректируемого периода
		  , sn.src_id||';'||Sn.DFSERVCONST::NUMERIC(38,0) as subs_key      -- Идентификатор Абонента
		  , 1 as adjust_type_key     -- Идентификатор типа корректировки
		  , sn.src_id||';'||sn.dfservice::NUMERIC(38,0) as service_key -- Идентификатор услуги
		  , sn.src_id
		  , coalesce(subs26.subs_key,'-1') as subs_key26
		  , coalesce(tdopcs.dfcfo_segment::numeric(38),'-1') as rc_key
		  , row_number() over(partition by sn.DFSERVNACH order by coalesce(subs26.subs_key,'-1')) as rn
		  , sn.TPERIODDFDATEBEGIN as billing_dttm
       FROM    edw_ods.t_000034_tservnach sn 
		  left join edw_ods.t_000034_tperiod p 
			on p.dfperiod = sn.dfperiod and p.deleted_ind=0
		  left join edw_ods.t_000034_tdogovor d 
			on sn.dfdogovor = d.dfdogovor and d.deleted_ind=0
		  left join edw_stg_dds.t_000026_dim_subs subs26 
			on subs26.account_key=sn.src_id||';'||sn.DFDOGOVOR::numeric(38)
		   and date_trunc('DAY',p.DFDATEEND) between subs26.start_date and subs26.end_date
		  left join edw_ods.t_000034_TDOG_CFO_SEGMENT tdogcs 
			on tdogcs.DFDOGOVOR=sn.DFDOGOVOR
		     and p.DFDATEEND between tdogcs.dfdatebegin and coalesce(tdogcs.dfdateend,'29991231')
		  left join edw_ods.t_000034_TDOP_CFO_SEGMENT tdopcs on tdogcs.DFDOP_CFO_SEGMENT = tdopcs.DFDOP_CFO_SEGMENT
		WHERE 1=1
		  and sn.TPERIODDFDATEBEGIN between to_date('20190601', 'YYYYMMDD') and to_date('20190630', 'YYYYMMDD')--Ограничение партиций ODS
		  AND sn.dfdatebegin NOT BETWEEN p.dfdatebegin AND p.dfdateend
		  AND Sn.DFOPLATA IS NULL
		  AND (Sn.DFNDSSUMMA <> 0 or sn.DFSUMMA <> 0)
		  and sn.deleted_ind=0
		 -- and date_trunc('DAY',p.DFDATEEND) between to_date('20190601', 'YYYYMMDD') and to_date('20190630', 'YYYYMMDD')
	    )elis
  where rn=1
   )elis1
left join edw_ods.t_000034_tdogovor tdogovor on tdogovor.src_id||';'||tdogovor.dfdogovor::numeric(38)=elis1.account_key
left join edw_stg_dds.t_kurs_group_filter_lts lts on lts.dflinepartgroup=tdogovor.dflinepartgroup
where coalesce(lts.exept,0)=0;
commit;--корректировки платежей
INSERT INTO edw_stg_dds.t_000034_tfct_adjust
(adjust_key,
 account_key,
 adjust_amt,
 vat_rub,
 adjust_type_key,
 adjust_dttm,
 payment_key,
 corr_billing_ID,
 src_id,
 EFF_DTTM,
 EXP_DTTM,
 billing_dttm
)
  SELECT
    l1.adjust_key,
    l1.account_key,
    l1.adjust_amt,
    l1.vat_rub,
    l1.adjust_type_key,
    l1.adjust_dttm,
    l1.payment_key,
    l1.corr_billing_ID,
    l1.src_id,
    '19000101' :: TIMESTAMP AS EFF_DTTM,
    '29991231' :: TIMESTAMP AS EXP_DTTM,
	l1.billing_dttm

  FROM (
    SELECT
      toplata.src_id || ';' || toplata.dfoplata :: NUMERIC(38)                                  AS adjust_key, --Идентификатор корректировки
      toplata.src_id || ';' || toplata.dfdogovor :: NUMERIC(38)                                 AS account_key,-- Идентификатор лицевого счета
      toplata.dfsumma/(1+0.2)                                                                    AS adjust_amt, -- Сумма поступления без НДС
      (toplata.dfsumma/(1+0.2))*0.2                                                           AS vat_rub, -- Сумма НДС
      2                                                                                           AS adjust_type_key,-- Идентификатор типа поступления
      toplata.DFDATEINBEGIN                                                                       AS adjust_dttm,-- Дата платежа
      toplata.src_id || ';' || dfoplatamaster :: NUMERIC(38)                                    AS payment_key,
      date_part('year', tperiod.dfdateend) || lpad(cast(date_part('month', tperiod.dfdateend) as varchar(2)), 2, '0') AS corr_billing_ID, -- Биллинговый период
      toplata.src_id, -- Номер системы
	  tperiod.dfdatebegin billing_dttm
    FROM edw_ods.t_000034_toplata toplata
      JOIN edw_ods.t_000034_treestr treestr ON treestr.dfreestr = toplata.dfreestr
      JOIN edw_ods.t_000034_tperiod tperiod ON treestr.dfperiod = tperiod.dfperiod
    WHERE
      (toplata.dfdelete <> 'T' OR toplata.dfdelete IS NULL) AND
      (treestr.dfdelete <> 'T' OR treestr.dfdelete IS NULL) AND
      toplata.dfsumma < 0
      AND toplata.dftyp_op NOT IN (100000000002084, 862203000000500, 867222000000240)
      AND toplata.deleted_ind = 0
      AND treestr.deleted_ind = 0
      AND tperiod.deleted_ind = 0
      --AND date_trunc('DAY', treestr.dfdate) BETWEEN to_date('20190601', 'YYYYMMDD') AND to_date('20190630', 'YYYYMMDD')
	  and tperiod.dfdatebegin between to_date('20190601', 'YYYYMMDD') AND to_date('20190630', 'YYYYMMDD')
      and toplata.DFDATEINBEGIN >= to_date('20190601', 'YYYYMMDD')  --ограничение запрашиваемых партиций ODS
UNION ALL
SELECT
  toplata.src_id || ';' || toplata.dfoplata :: NUMERIC(38)                                  AS adjust_key,--Идентификатор корректировки
  toplata.src_id || ';' || toplata.dfdogovor :: NUMERIC(38)                                 AS account_key,  -- Идентификатор лицевого счета
  toplata.dfsumma                                                                           AS adjust_amt, -- Сумма поступления
  (toplata.dfsumma / (1+0.2)) * 0.2                                                          AS vat_rub,  -- Сумма НДС
  2                                                                                         AS adjust_type_key,-- Идентификатор типа поступления
  treestr.dfdate                                                                            AS adjust_dttm, -- Дата платежа
  toplata.src_id || ';' || dfoplatamaster :: NUMERIC(38)                                    AS payment_key,
  date_part('year', tperiod.dfdateend) || lpad(cast(date_part('month', tperiod.dfdateend) as varchar(2)) , 2, '0') AS corr_billing_ID, -- Биллинговый период
  toplata.src_id, -- Номер системы
  tperiod.dfdatebegin billing_dttm
FROM edw_ods.t_000034_toplata toplata
  JOIN edw_ods.t_000034_treestr treestr ON treestr.dfreestr = toplata.dfreestr
  JOIN edw_ods.t_000034_tperiod tperiod ON treestr.dfperiod = tperiod.dfperiod
WHERE
  (toplata.dfdelete <> 'T' OR toplata.dfdelete IS NULL) AND
  (treestr.dfdelete <> 'T' OR treestr.dfdelete IS NULL) AND
  toplata.dfsumma <> 0
  AND toplata.dftyp_op IN (100000000002084)
  AND toplata.deleted_ind = 0
  AND treestr.deleted_ind = 0
  AND tperiod.deleted_ind = 0
 -- AND date_trunc('DAY', treestr.dfdate) BETWEEN to_date('20190601', 'YYYYMMDD') AND to_date('20190630', 'YYYYMMDD')
  and tperiod.dfdatebegin between to_date('20190601', 'YYYYMMDD') AND to_date('20190630', 'YYYYMMDD')
  and toplata.DFDATEINBEGIN >= to_date('20190601', 'YYYYMMDD')   --ограничение запрашиваемых партиций ODS
)l1
LEFT JOIN edw_ods.t_000034_tdogovor tdogovor ON tdogovor.src_id||';'||tdogovor.dfdogovor:: NUMERIC(38)=l1.account_key
LEFT JOIN edw_stg_dds.t_kurs_group_filter_lts lts ON lts.dflinepartgroup=tdogovor.dflinepartgroup
WHERE coalesce(lts.exept,0)=0;
COMMIT;
ANALYZE edw_stg_dds.t_000034_tfct_adjust;