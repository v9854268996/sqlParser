-- rev. 54327 от 08.04.2020

SET search_path = edw_stg_dm_b2b;
SET optimizer = ON;
COMMIT;

BEGIN;
  TRUNCATE TABLE edw_stg_dm_b2b.pre_iptv_base_pack_san_1_prt_p000066;
COMMIT;

BEGIN;
INSERT INTO edw_stg_dm_b2b.pre_iptv_base_pack_san_1_prt_p000066
(san, pack_name, serv_first_id, src_id)
SELECT
       san,
       substr(pack_name, 1, 500),
       serv_first_id,
       000066::smallint AS src_id
  FROM
  (
    SELECT
      row_number() OVER (PARTITION BY cus.uss_logname) AS rn,
      cus.uss_logname AS san,
      string_agg(coalesce(cp.itvcp_name, cp1.itvcp_name), ', ') OVER (PARTITION BY cus.uss_logname) AS pack_name,
      ts.serv_first_id
    FROM edw_ods.t_000066_ct_user_services cus -- limit 100
         JOIN
         edw_ods.t_000066_ct_user_services cus1
           ON cus.uss_us_user_name = cus1.uss_us_user_name
          AND cus.uss_login = cus1.uss_login
          AND cus1.uss_sl_type = 'IPTVSTB'
          AND to_date('20190630', 'YYYYMMDD') + INTERVAL '1 day - 1 second' BETWEEN cus1.eff_dttm AND cus1.exp_dttm
          AND cus1.deleted_ind = 0
         JOIN
         (
           SELECT
             row_number() OVER (PARTITION BY service_id ORDER BY date_begin DESC, coalesce(date_end, '2999-01-01') DESC) AS rn,
             *
           FROM edw_ods.t_000066_tb_start_servs  tbs
           WHERE 1=1
             AND coalesce(date_end, to_date('2999-01-01', 'yyyy-mm-dd')) >= to_date('20190601', 'YYYYMMDD')
             AND date_begin <= to_date('20190630', 'YYYYMMDD')
             AND upper(sip_uss_sl_type) = 'IPTVSTB'
             AND tbs.tech_dt = date_trunc('month', to_date('20190630', 'YYYYMMDD'))
         ) tbs
           ON 1=1
          AND tbs.sip_uss_login = cus1.uss_login --cus1.uss_logname
          AND tbs.rn=1
         LEFT JOIN
         edw_ods.t_000051_t_services ts
           ON 1=1
          AND ts.service_id = tbs.service_id
          AND ts.date_begin <= to_date('20190630', 'YYYYMMDD')
          AND coalesce(ts.date_end, '2999-01-01') >= date_trunc('month', to_date('20190630', 'YYYYMMDD'))
          AND to_date('20190630', 'YYYYMMDD') + INTERVAL '1 day - 1 second' BETWEEN ts.eff_dttm AND ts.exp_dttm
          AND ts.deleted_ind = 0
         LEFT JOIN
         edw_ods.t_000051_t_users cu
           ON cu.user_id = ts.user_id
          AND to_date('20190630', 'YYYYMMDD') + INTERVAL '1 day - 1 second' BETWEEN cu.eff_dttm AND cu.exp_dttm
          AND cu.deleted_ind = 0
         JOIN
         edw_ods.t_000066_abonent a
           ON 1=1
          AND cu.account = a.ab_account
          AND to_date('20190630', 'YYYYMMDD') + INTERVAL '1 day - 1 second' BETWEEN a.eff_dttm AND a.exp_dttm
          AND upper(A.ab_ur_ustp) != 'TEST'
          AND ab_lr_legal_status = 'LEGAL'
          AND a.deleted_ind = 0
         LEFT JOIN
         edw_ods.t_000066_tb_user_serv_attrs     j1
           ON cus.uss_logname = j1.usa_uss_logname --j2.uss_logname = j1.usa_uss_logname
          AND j1.usa_sat_name = 'IPTV_ChanelPackage'
          AND CASE
                WHEN to_date('20190601', 'YYYYMMDD') < '2019-04-01 00:00:00' AND j1.tech_dt BETWEEN '2019-04-01 00:00:00' AND '2019-04-30 00:00:00'
                  THEN 1
                WHEN j1.tech_dt BETWEEN to_date('20190601', 'YYYYMMDD') AND to_date('20190630', 'YYYYMMDD')
                  THEN 1
                ELSE 0
              END = 1
         JOIN
         edw_ods.t_000066_tb_user_serv_attrs     j3
           ON cus1.uss_logname = j3.usa_uss_logname
          AND j3.usa_sat_name = 'IPTV_ProfileCode'
          AND CASE
                WHEN to_date('20190601', 'YYYYMMDD') < '2019-04-01 00:00:00' AND j3.tech_dt BETWEEN '2019-04-01 00:00:00' AND '2019-04-30 00:00:00'
                  THEN 1
                WHEN j3.tech_dt BETWEEN to_date('20190601', 'YYYYMMDD') AND to_date('20190630', 'YYYYMMDD')
                  THEN 1
                ELSE 0
              END = 1
         LEFT JOIN
         edw_ods.t_000066_iptv_profiles p
           ON p.itvpf_code = j3.usa_value
          AND to_date('20190630', 'YYYYMMDD') + INTERVAL '1 day - 1 second' BETWEEN p.eff_dttm AND p.exp_dttm
         JOIN
         edw_ods.t_000066_iptv_package_categories pc
           ON pc.itvpc_itvpf_id = p.itvpf_id
          AND (lower(pc.itvpc_name) LIKE ('%осн%пак%') OR lower(pc.itvpc_name) LIKE ('%подпис%закрыта%'))
          AND to_date('20190630', 'YYYYMMDD') + INTERVAL '1 day - 1 second' BETWEEN pc.eff_dttm AND pc.exp_dttm
          AND pc.deleted_ind = 0
         LEFT JOIN
         edw_ods.t_000066_iptv_packages_in_category pic
           ON pc.itvpc_id = pic.itvpic_itvpc_id
          AND to_date('20190630', 'YYYYMMDD') + INTERVAL '1 day - 1 second' BETWEEN pic.eff_dttm AND pic.exp_dttm
          AND pic.deleted_ind = 0
         LEFT JOIN
         edw_ods.t_000066_iptv_channel_packages cp
           ON cp.itvcp_id = pic.itvpic_itvcp_id
          AND cp.itvcp_external_id = j1.usa_value
          AND to_date('20190630', 'YYYYMMDD') + INTERVAL '1 day - 1 second' BETWEEN cp.eff_dttm AND cp.exp_dttm
          AND cp.deleted_ind = 0
         LEFT JOIN
         edw_ods.t_000066_iptv_channel_packages cp1
           ON cp1.itvcp_id = pic.itvpic_itvcp_id
          AND to_date('20190630', 'YYYYMMDD') + INTERVAL '1 day - 1 second' BETWEEN cp1.eff_dttm AND cp1.exp_dttm
          AND cp1.deleted_ind = 0
         JOIN
         edw_ods.t_000066_tb_invoices inv
           ON inv.inv_srd_code = pic.itvpic_srd_code
          AND inv.inv_us_user_name = cus.uss_us_user_name--'419088-2'
          AND date_trunc('month', inv.inv_tdate) = date_trunc('month', to_date('20190630', 'YYYYMMDD'))
    WHERE 1 = 1
      AND cus.uss_login IS NOT NULL
      AND cus.uss_sl_type = 'IPTV'
      AND to_date('20190630', 'YYYYMMDD') + INTERVAL '1 day - 1 second' BETWEEN cus.eff_dttm AND cus.exp_dttm
      AND cus.deleted_ind = 0
      AND CASE
            WHEN j1.usa_sat_name IS NOT NULL THEN cp.itvcp_name
            ELSE cp1.itvcp_name
          END IS NOT NULL
  ) prev
WHERE rn = 1;
COMMIT;

BEGIN;
  ANALYZE edw_stg_dm_b2b.pre_iptv_base_pack_san_1_prt_p000066;
COMMIT;

BEGIN;
  TRUNCATE TABLE edw_stg_dm_b2b.tfct_iptv_base_pack_1_prt_p000066;
COMMIT;

BEGIN;
INSERT INTO edw_stg_dm_b2b.tfct_iptv_base_pack_1_prt_p000066
(
  period,
  mrf_id,
  rf_id,
  inn,
  okved,
  name_okved,
  segment_code,
  segment_name,
  contr_name,
  adress_dev,
  account,
  san,
  data_contr,
  pack_name,
  base_pack_charges,
  rtk_detail_code,
  sub_product,
  src_id
)
WITH
pre_charges AS
(
  SELECT
    j2.san,
    substr(j2.pack_name, 1, 500) AS pack_name,
    sa.abn_id,
    sa.subs_id,
    sa.data_contr,
    sa.adress_dev,
    ch.period,
    ch.mrf_id,
    ch.rf_id,
    ch.inn,
    t.okved,
    t1.name_okved,
    ch.segment_code,
    ch.segment_name,
    coalesce(ch.contr_name, '') AS contr_name,
    '' AS hotel_level,
    ch.account,
    --ch.charge_code,
    ch.rtk_detail_code,
    ch.sub_product,
    ch.charges,
    coalesce(j2.src_id,  ch.chd_src_id) AS src_id
  FROM
  (
    SELECT
      chgd.period,
      vdb.branch_mrf_key AS mrf_id,
      vdb.branch_key AS rf_id,
      chgd.rf_id AS rf_id_soo,
      chgd.cl_id,
      chgd.account,
      chgd.abn_id,
      dms.macro_segment AS segment_code,
      dms.name_microsegment AS segment_name,
      cl.inn,
      cl.contr_name,
      dis.rtk_detail_code,
      dis.sub_product,
      sum(chgd.charge - chgd.vat_amount) AS charges,
      CASE
        WHEN chgd.rf_id = 1101 THEN 63
        WHEN chgd.rf_id = 1102 THEN 64
        WHEN chgd.rf_id = 1116 THEN 65
        WHEN chgd.rf_id = 1118 THEN 65
        WHEN chgd.rf_id = 1104 THEN 66
        WHEN chgd.rf_id = 1117 THEN 66
        WHEN chgd.rf_id = 1105 THEN 67
        WHEN chgd.rf_id = 1106 THEN 68
        WHEN chgd.rf_id = 1107 THEN 69
        WHEN chgd.rf_id = 1108 THEN 70
        WHEN chgd.rf_id = 1109 THEN 71
        WHEN chgd.rf_id = 1151 THEN 71
        WHEN chgd.rf_id = 1110 THEN 72
        WHEN chgd.rf_id = 1111 THEN 73
        WHEN chgd.rf_id = 1112 THEN 74
        WHEN chgd.rf_id = 1113 THEN 75
        WHEN chgd.rf_id = 1114 THEN 76
        WHEN chgd.rf_id = 1115 THEN 77
      END AS chd_src_id
    FROM edw_ods.t_000151_rprt_charges_dwh chgd
         JOIN
         edw_ods.t_000151_rprt_client_dwh cl
           ON chgd.cl_id = cl.cl_id
          AND chgd.mrf_id = cl.mrf_id
          AND coalesce(cl.data_close, '2999-12-31 00:00:00') >= to_date('20190630', 'YYYYMMDD')
         LEFT JOIN
         edw_dds.hub_dim_branch vdb1
           ON coalesce(cl.rf_id, chgd.rf_id)::text = vdb1.source_key
          AND vdb1.exp_dttm = '2999-12-31 00:00:00'
          AND vdb1.src_id = 158
         --Определяем МРФ по РФ
         LEFT JOIN
         edw_ads.dim_branch vdb
           ON vdb1.branch_key = vdb.branch_key
          AND vdb.exp_dttm = '2999-12-31 00:00:00'
          AND vdb.deleted_ind = 0
         -- Выбираем определенные сегменты клиентов
         JOIN
         edw_ods.t_000158_rprt_dird_macro_sgmnt dms
           ON cl.id_macro_segment_ud = dms.id_macro_segment
          AND dms.macro_segment NOT LIKE 'K04%' --  приведено в соответсвие с дашбордами по новым продуктам
          AND dms.deleted_ind = 0
         JOIN
         edw_dm_b2b.dim_iptv_services dis
           ON dis.rtk_detail_code = chgd.charge_code
          AND dis.category = 'Основные пакеты'
          AND dis.exp_dttm = '2999-12-31 00:00:00'
    WHERE chgd.period = date_trunc('month', to_date('20190630', 'YYYYMMDD'))
      AND chgd.coef_r12 = 1
      AND chgd.charge != 0
      AND CASE
            WHEN chgd.rf_id = 1101 THEN 63
            WHEN chgd.rf_id = 1102 THEN 64
            WHEN chgd.rf_id = 1116 THEN 65
            WHEN chgd.rf_id = 1118 THEN 65
            WHEN chgd.rf_id = 1104 THEN 66
            WHEN chgd.rf_id = 1117 THEN 66
            WHEN chgd.rf_id = 1105 THEN 67
            WHEN chgd.rf_id = 1106 THEN 68
            WHEN chgd.rf_id = 1107 THEN 69
            WHEN chgd.rf_id = 1108 THEN 70
            WHEN chgd.rf_id = 1109 THEN 71
            WHEN chgd.rf_id = 1151 THEN 71
            WHEN chgd.rf_id = 1110 THEN 72
            WHEN chgd.rf_id = 1111 THEN 73
            WHEN chgd.rf_id = 1112 THEN 74
            WHEN chgd.rf_id = 1113 THEN 75
            WHEN chgd.rf_id = 1114 THEN 76
            WHEN chgd.rf_id = 1115 THEN 77
          END = 000066::smallint
      -- AND vdb.branch_key BETWEEN 1100 AND 1116
    GROUP BY chgd.period,
             vdb.branch_mrf_key,
             vdb.branch_key,
             chgd.rf_id,
             chgd.cl_id,
             chgd.account,
             chgd.abn_id,
             dis.rtk_detail_code,
             dis.sub_product,
             dms.macro_segment,
             dms.name_microsegment,
             cl.inn,
             cl.contr_name
  ) ch

  LEFT JOIN
  (
    SELECT
           row_number() OVER (PARTITION BY inn, rf_id ORDER BY date_calc DESC) AS rn,
           *
      FROM edw_ods.t_000158_budget_org_detail t
  ) t
    ON t.rf_id::text = ch.rf_id_soo::text
   AND t.inn::text = ch.inn::text
   AND t.rn = 1

  LEFT JOIN
  (
    SELECT
           row_number() OVER (PARTITION BY code_okved ORDER BY date_snap DESC) AS rn,
           *
      FROM edw_ods.t_000158_bd_org_dir_okved
     WHERE date_start <= to_date('20190630', 'YYYYMMDD')
       AND deleted_ind = 0
  ) t1
    ON t1.code_okved = t.okved
   AND t1.rn = 1

  LEFT JOIN
  (
    SELECT
      row_number() OVER (PARTITION BY abn_id ORDER BY date_snap DESC, log_id DESC) AS rn,
      cl_id,
      abn_id,
      subs_id,
      serv_id,
      db.branch_mrf_key AS mrf_id,
      db.branch_key AS rf_id,
      data_contr,
      coalesce(adress_dev, adress) AS adress_dev
    FROM edw_ods.t_000151_rprtsubscribersactual s
         LEFT JOIN
         edw_dds.hub_dim_branch hdb
           ON hdb.source_key = s.rf_id::text
          AND hdb.src_id = 158
          AND hdb.exp_dttm = '2999-12-31 00:00:00'
         LEFT JOIN
         edw_ads.dim_branch db
           ON hdb.branch_key = db.branch_key
          AND db.exp_dttm = '2999-12-31 00:00:00'
  ) sa
    ON ch.abn_id = sa.abn_id
   AND ch.cl_id = sa.cl_id

  LEFT JOIN
  edw_stg_dm_b2b.pre_iptv_base_pack_san_1_prt_p000066 j2
    ON sa.subs_id::text = j2.serv_first_id::text
   AND ch.chd_src_id = j2.src_id
)
SELECT
       period,               -- Период
       mrf_id,               -- Идентификатор МРФ
       rf_id,                -- Идентификатор РФ
       inn::numeric(20, 0),  -- ИНН
       okved,                -- Код ОКВЭД
       name_okved,           -- ОКВЭД
       segment_code,         -- Код сегмента
       segment_name,         -- Наимененование сегмента
       contr_name,           -- Наименование контрагента
       adress_dev,           -- Адрес объекта предоставления услу
       account,              -- ЛС
       san,                  -- САН
       data_contr,           -- Дата подключения
       pack_name,            -- Наименование основного ТВ-пакета
       sum(charges),         -- Сервисная выручка
       rtk_detail_code,      -- Код дохода
       sub_product,          -- Подпродукт
       src_id
  FROM pre_charges
 GROUP BY period,
          mrf_id,
          rf_id,
          inn,
          okved,
          segment_code,
          segment_name,
          contr_name,
          adress_dev,
          account,
          san,
          data_contr,
          pack_name,
          rtk_detail_code,
          sub_product,
          src_id,
          name_okved;
COMMIT;

BEGIN;
  ANALYZE edw_stg_dm_b2b.tfct_iptv_base_pack_1_prt_p000066;
COMMIT;

