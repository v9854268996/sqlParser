/*rev.58232 от 20.05.2020 */

TRUNCATE TABLE edw_stg_dds.t_000112_dim_partner
;

INSERT INTO edw_stg_dds.t_000112_dim_partner
(partner_key, parent_tax_number_cval, tax_number_cval, branch_key, segment_key, tax_reg_reason_cval, partner_full_name, doc_number_cval, src_id, load_dttm, eff_dttm, exp_dttm, start_date, end_date)
with ttr as (
	SELECT 
		tu.account
		,hub.branch_key
		,own_t_saldo.billing_id
		,own_t_saldo.soogu_id
	FROM edw_ods.t_000107_t_users tu
	LEFT JOIN edw_ods.t_000107_own_t_saldo own_t_saldo 
		ON tu.user_id = own_t_saldo.user_id 
		--	AND own_t_saldo.tech_dt between to_date('20190601', 'YYYYMMDD') 
		--							and to_date('20190630', 'YYYYMMDD') + INTERVAL '1 day - 1 second' 	
	LEFT JOIN edw_dds.hub_dim_branch hub 
		ON COALESCE(own_t_saldo.dept_id, tu.dept_id)::text = hub.source_key::text 
			AND hub.src_id = tu.src_id
	WHERE tu.deleted_ind <> 1
		AND to_date('20190630', 'YYYYMMDD') + INTERVAL '1 day - 1 second' + interval '7 days' between tu.eff_dttm and tu.exp_dttm
	union all
	SELECT 
		tu.account
		,hub.branch_key
		,own_t_saldo.billing_id
		,own_t_saldo.soogu_id
	FROM edw_ods.t_000108_t_users tu
	LEFT JOIN edw_ods.t_000108_own_t_saldo own_t_saldo 
		ON tu.user_id = own_t_saldo.user_id 
			--AND own_t_saldo.tech_dt between to_date('20190601', 'YYYYMMDD') 
		--							and to_date('20190630', 'YYYYMMDD') + INTERVAL '1 day - 1 second' 	
	LEFT JOIN edw_dds.hub_dim_branch hub 
		ON COALESCE(own_t_saldo.dept_id, tu.dept_id)::text = hub.source_key::text 
			AND hub.src_id = tu.src_id
	WHERE tu.deleted_ind <> 1
		AND to_date('20190630', 'YYYYMMDD') + INTERVAL '1 day - 1 second' + interval '7 days' between tu.eff_dttm and tu.exp_dttm
	union all
	SELECT 
		tu.account
		,hub.branch_key
		,own_t_saldo.billing_id
		,own_t_saldo.soogu_id
	FROM edw_ods.t_000109_t_users tu
	LEFT JOIN edw_ods.t_000109_own_t_saldo own_t_saldo 
		ON tu.user_id = own_t_saldo.user_id 
			--AND own_t_saldo.tech_dt between to_date('20190601', 'YYYYMMDD') 
			--						and to_date('20190630', 'YYYYMMDD') + INTERVAL '1 day - 1 second' 	
	LEFT JOIN edw_dds.hub_dim_branch hub 
		ON COALESCE(own_t_saldo.dept_id, tu.dept_id)::text = hub.source_key::text 
			AND hub.src_id = tu.src_id
	WHERE tu.deleted_ind <> 1
		AND to_date('20190630', 'YYYYMMDD') + INTERVAL '1 day - 1 second' + interval '7 days' between tu.eff_dttm and tu.exp_dttm	
	union all
	SELECT 
		tu.account
		,hub.branch_key
		,own_t_saldo.billing_id
		,own_t_saldo.soogu_id
	FROM edw_ods.t_000110_t_users tu
	LEFT JOIN edw_ods.t_000110_own_t_saldo own_t_saldo 
		ON tu.user_id = own_t_saldo.user_id 
			--AND own_t_saldo.tech_dt between to_date('20190601', 'YYYYMMDD') 
			--						and to_date('20190630', 'YYYYMMDD') + INTERVAL '1 day - 1 second' 	
	LEFT JOIN edw_dds.hub_dim_branch hub 
		ON COALESCE(own_t_saldo.dept_id, tu.dept_id)::text = hub.source_key::text 
			AND hub.src_id = tu.src_id
	WHERE tu.deleted_ind <> 1
		AND to_date('20190630', 'YYYYMMDD') + INTERVAL '1 day - 1 second' + interval '7 days' between tu.eff_dttm and tu.exp_dttm
	union all
	SELECT 
		tu.account
		,hub.branch_key
		,own_t_saldo.billing_id
		,own_t_saldo.soogu_id
	FROM edw_ods.t_000111_t_users tu
	LEFT JOIN edw_ods.t_000111_own_t_saldo own_t_saldo 
		ON tu.user_id = own_t_saldo.user_id 
			--AND own_t_saldo.tech_dt between to_date('20190601', 'YYYYMMDD') 
			--						and to_date('20190630', 'YYYYMMDD') + INTERVAL '1 day - 1 second' 	
	LEFT JOIN edw_dds.hub_dim_branch hub 
		ON COALESCE(own_t_saldo.dept_id, tu.dept_id)::text = hub.source_key::text 
			AND hub.src_id = tu.src_id
	WHERE tu.deleted_ind <> 1
		AND to_date('20190630', 'YYYYMMDD') + INTERVAL '1 day - 1 second' + interval '7 days' between tu.eff_dttm and tu.exp_dttm	
	union all
	SELECT 
		tu.account
		,hub.branch_key
		,own_t_saldo.billing_id
		,own_t_saldo.soogu_id
	FROM edw_ods.t_000112_t_users tu
	LEFT JOIN edw_ods.t_000112_own_t_saldo own_t_saldo 
		ON tu.user_id = own_t_saldo.user_id 
			--AND own_t_saldo.tech_dt between to_date('20190601', 'YYYYMMDD') 
			--						and to_date('20190630', 'YYYYMMDD') + INTERVAL '1 day - 1 second' 	
	LEFT JOIN edw_dds.hub_dim_branch hub 
		ON COALESCE(own_t_saldo.dept_id, tu.dept_id)::text = hub.source_key::text 
			AND hub.src_id = tu.src_id
	WHERE tu.deleted_ind <> 1
		AND to_date('20190630', 'YYYYMMDD') + INTERVAL '1 day - 1 second' + interval '7 days' between tu.eff_dttm and tu.exp_dttm	
	union all
	SELECT 
		tu.account
		,hub.branch_key
		,own_t_saldo.billing_id
		,own_t_saldo.soogu_id
	FROM edw_ods.t_000113_t_users tu
	LEFT JOIN edw_ods.t_000113_own_t_saldo own_t_saldo 
		ON tu.user_id = own_t_saldo.user_id 
		--	AND own_t_saldo.tech_dt between to_date('20190601', 'YYYYMMDD') 
		--							and to_date('20190630', 'YYYYMMDD') + INTERVAL '1 day - 1 second' 	
	LEFT JOIN edw_dds.hub_dim_branch hub 
		ON COALESCE(own_t_saldo.dept_id, tu.dept_id)::text = hub.source_key::text 
			AND hub.src_id = tu.src_id
	WHERE tu.deleted_ind <> 1
		AND to_date('20190630', 'YYYYMMDD') + INTERVAL '1 day - 1 second' + interval '7 days' between tu.eff_dttm and tu.exp_dttm		
)
SELECT partner_key,
       parent_tax_number_cval,
       tax_number_cval,
       branch_key,
       CASE
         WHEN segment_key IS NOT NULL
                 THEN segment_key
         WHEN segment_key IS NULL AND iscorp = 'N'
                 THEN '400001'
         WHEN segment_key IS NULL AND iscorp = 'Y'
                 THEN 'ND_EKHD'
       END AS segment_key,
       tax_reg_reason_cval,
       partner_full_name,
       doc_number_cval,
       src_id,
       load_dttm,
       eff_dttm,
       CASE
         WHEN date_trunc('day', exp_dttm) = '2999-12-31'
                 THEN date_trunc('day', exp_dttm)
         ELSE exp_dttm
       END AS exp_dttm,
       start_date,
       CASE
         WHEN date_trunc('day', end_date) = '2999-12-31'
                 THEN date_trunc('day', end_date)
         ELSE end_date
       END AS end_date
FROM 
(
	SELECT t_users.user_id AS partner_key,
             t_chief_users.inn AS parent_tax_number_cval,
             t_users.inn AS tax_number_cval,
             t_users.dept_id AS branch_key,
             coalesce(ttr.soogu_id, t_saldo.soogu_id, t_users.soogu_id) :: text AS segment_key,
             t_users.kpp AS tax_reg_reason_cval,
             trim(t_users.name) AS partner_full_name,
             t_users.document_text AS doc_number_cval,
             t_users.iscorp,
             000112 AS src_id,
             now() AS load_dttm,
             coalesce(decode(t_saldo.billing_id, t_saldo.min_billing_id, to_date('1900-01-01', 'YYYY-MM-DD')),
                      to_date(t_saldo.billing_id::text, 'YYYYMM'), to_date('1900-01-01', 'YYYY-MM-DD')) AS eff_dttm,
             coalesce(decode(t_saldo.billing_id, t_saldo.max_billing_id, to_date('2999-12-31', 'YYYY-MM-DD')),
                      to_date(t_saldo.billing_id::text, 'YYYYMM') + INTERVAL '1 month - 1 day',
                      to_date('2999-12-31', 'YYYY-MM-DD')) + INTERVAL '1 day - 1 second' AS exp_dttm,
             coalesce(decode(t_saldo.billing_id, t_saldo.min_billing_id, to_date('1900-01-01', 'YYYY-MM-DD')),
                      to_date(t_saldo.billing_id::text, 'YYYYMM'), to_date('1900-01-01', 'YYYY-MM-DD')) AS start_date,
             coalesce(decode(t_saldo.billing_id, t_saldo.max_billing_id, to_date('2999-12-31', 'YYYY-MM-DD')),
                      to_date(t_saldo.billing_id::text, 'YYYYMM') + INTERVAL '1 month - 1 day',
                      to_date('2999-12-31', 'YYYY-MM-DD')) + INTERVAL '1 day - 1 second' AS end_date
	FROM 
		(
			SELECT 
				user_id,inn,dept_id,kpp,iscorp, name,soogu_id,document_text,chief_user_id,account
			FROM 
				edw_ods.t_000112_t_users tu
			WHERE 
				to_date('20190630', 'YYYYMMDD') + INTERVAL '1 day - 1 second' + interval '7 days' between tu.eff_dttm and tu.exp_dttm
				AND tu.deleted_ind = 0
		)t_users
		LEFT JOIN (
					SELECT 
						billing_id,user_id,soogu_id, 
						max(billing_id) OVER (PARTITION BY user_id) AS max_billing_id, 
						MIN (billing_id) OVER (PARTITION BY user_id) AS min_billing_id 
					FROM 
						edw_ods.t_000112_own_t_saldo  
				 --   WHERE tech_dt between to_date('20190601', 'YYYYMMDD') 
				--				and to_date('20190630', 'YYYYMMDD') + INTERVAL '1 day - 1 second' 	
		)t_saldo 
			ON t_users.user_id = t_saldo.user_id 
		LEFT JOIN edw_ods.t_000112_t_users t_chief_users 
			ON t_chief_users.user_id = t_users.chief_user_id 
			AND t_chief_users.deleted_ind = 0
			AND to_date('20190630', 'YYYYMMDD') + INTERVAL '1 day - 1 second' + interval '7 days' between t_chief_users.eff_dttm and t_chief_users.exp_dttm
		LEFT JOIN edw_ods.t_000112_mrk_common_accounts vp 
			ON t_users.account = vp.from_account 
			AND vp.DELETED_IND = 0
			AND to_date('20190601', 'YYYYMMDD') + INTERVAL '1 MONTH - 1 second' 
				BETWEEN to_date(vp.bid_begin::text, 'YYYYMM') 
				AND to_date(vp.bid_end::text, 'YYYYMM') + INTERVAL '1 MONTH - 1 second'
			AND to_date('20190630', 'YYYYMMDD') + INTERVAL '1 day - 1 second' between vp.eff_dttm and vp.exp_dttm
		LEFT JOIN edw_dds.hub_dim_branch hub 
			ON vp.to_filail_id::text = hub.source_key 
			AND vp.src_id = hub.src_id
			AND to_date('20190601', 'YYYYMMDD') + INTERVAL '1 MONTH - 1 second' 
				BETWEEN hub.eff_dttm AND hub.exp_dttm
		LEFT JOIN /*edw_stg_dds.v_dim_account_dv*/ ttr 
			ON ttr.account = vp.to_account 
			AND hub.branch_key = ttr.branch_key 
			AND ttr.billing_id = t_saldo.billing_id
)s1;
 commit; analyze edw_stg_dds.t_000112_dim_partner;