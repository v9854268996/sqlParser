/*rev.53645 от 31.03.2020*/
	set optimizer = on;
truncate table edw_stg_dm_ruz.pre_fct_ip_mpls_traffic_mis;
insert into edw_stg_dm_ruz.pre_fct_ip_mpls_traffic_mis
(
	period,
	oebs_r12_branch_key,
	segment_key,
	business_service_ruz_key,
	in_traf,
	source,
	rc_key,
	business_segment_key,
	ruz_src_id
)
SELECT 
	dt as period,
	h_br.oebs_r12_branch_ruz_key,
	h_s.segment_key,
	h_bsr.business_service_ruz_key,
	sum(kpi_value) as in_traf,
	'МИС' as source,
	d_c.rc_key,
	d_bs.business_segment_key,
	000133 ruz_src_id
FROM 
	edw_ods.t_000133_prtl_v_fct_bi_monthly f
	inner join edw_ods.t_000133_prtl_dim_region_hier r
	on ( 1=1
		and f.region_key = r.region_key
		and r.main_org_name = 'Ростелеком'
		and r.deleted_ind = '0'
		and cast(to_date('20190601','YYYYMMDD') as timestamp(0)) between r.mis_eff_dttm and r.mis_exp_dttm
		)
	left join edw_dds.hub_dim_oebs_r12_branch_ruz h_br /*HUB Орг структуры*/
	on ( 1 = 1
		and f.region_key = h_br.source_key::numeric
		and h_br.src_id = 000133
		and f.dt between h_br.eff_dttm and h_br.exp_dttm 
	)
	left join edw_dds.hub_dim_segment h_s /*HUB Сегмента*/
	on ( 1 = 1
		and f.segm_key = h_s.source_key::numeric
		and h_s.src_id = 000133
		and f.dt between h_s.eff_dttm and h_s.exp_dttm 
	)
	left join edw_dds.hub_dim_business_service_ruz h_bsr  /*HUB БУ РУЗ*/
	on ( 1 = 1
		and f.service_key = h_bsr.source_key::numeric
		and h_bsr.src_id = 000133
		and f.dt between h_bsr.eff_dttm and h_bsr.exp_dttm 
	)
	left join edw_dds.dim_matrix_ruz_rc d_mr 
	on ( 1 = 1 
		and d_mr.business_service_ruz_key = h_bsr.business_service_ruz_key
		and d_mr.segment_key  = h_s.segment_key  
		and f.dt between d_mr.eff_dttm and d_mr.exp_dttm 
		and d_mr.deleted_ind = '0'
	)
	left join edw_dds.dim_rc d_c
	on ( 1 = 1
			and d_mr.rc_key = d_c.rc_key 
			and f.dt between d_c.eff_dttm and d_c.exp_dttm
			and d_c.deleted_ind = '0'
		)

	left join edw_dds.dim_business_segment d_bs
	on ( 1 =1 
			and d_c.business_segment_key = d_bs.business_segment_key 
			and f.dt between d_bs.eff_dttm and d_bs.exp_dttm
			and d_bs.deleted_ind = '0'
		)
WHERE 1 = 1
	and f.kpi_key IN(209,2687)
	and f.mis_ind = 1
	and f.kpi_value>0
	and f.dt = to_date('20190601','YYYYMMDD')
	and f.deleted_ind='0'
GROUP BY 
	dt,
	h_br.oebs_r12_branch_ruz_key,
	h_s.segment_key,
	h_bsr.business_service_ruz_key,
	d_c.rc_key,
	d_bs.business_segment_key;
commit;
analyse edw_stg_dm_ruz.pre_fct_ip_mpls_traffic_mis;

truncate table edw_stg_dm_ruz.tfct_traffic_ipmpls_1_prt_p000133;
insert into edw_stg_dm_ruz.tfct_traffic_ipmpls_1_prt_p000133
(
	period,
	mrf_oebs_r12_code,
	mrf_oebs_r12_name,
	oebs_r12_branch_key,
	branch_code ,
	branch_name,
	rf_oebs_r12_code,
	rf_oebs_r12_name,
	source,
	business_segment_key,
	business_segment_short_name,
	client_name,
	rc_key,
	rc_code,
	rc_short_name,
	cms_order_point2address,
	segment_key,
	segment_name,
	budget_segmentation,
	cms_client_inn,
	business_service_ruz_key,
	business_service_ruz_parent_name,
	business_service_ruz_detail_name,
	business_service_ruz_sap_code,
	has_region_lastmile,
	in_traf,
	out_traf,
	total_traf,
	cms_order,
	cms_service,
	src_id
)
with extract_mis as (
	select
		s.period,
		s.oebs_r12_branch_key,
		'МИС VOIP' source,
		d_bs.business_segment_key,
		null client_name,
		d_c.rc_key,
		null cms_order_point2address,
		null vrf,
		null rt_import,
		s.segment_key,
		null cms_client_inn,
		19 business_service_ruz_key,
		null has_region_lastmile,
		s.in_traf*0.02 in_traf,
		null out_traf,
		null total_traf,
		null cms_order,
		null cms_service
	from edw_stg_dm_ruz.pre_fct_ip_mpls_traffic_mis s
		left join edw_dds.dim_matrix_ruz_rc d_mr /*Коммерческая матрица*/
		on ( 1 = 1
			and d_mr.business_service_ruz_key = 19
			and d_mr.segment_key  = s.segment_key  
			and s.period between d_mr.eff_dttm and  d_mr.exp_dttm 
			and d_mr.deleted_ind = '0'
		)
		left join edw_dds.dim_rc d_c
		on ( 1 = 1
			and d_mr.rc_key = d_c.rc_key 
			and s.period between d_c.eff_dttm and d_c.exp_dttm
			and d_c.deleted_ind = '0'
		)
		left join edw_dds.dim_business_segment d_bs
		on ( 1 =1 
			and d_c.business_segment_key = d_bs.business_segment_key 
			and s.period between d_bs.eff_dttm and d_bs.exp_dttm
			and d_bs.deleted_ind = '0'
		)
	where 1 = 1
		and s.business_service_ruz_key in (1,2,3,4) /*Услуга относится к Интернету*/
		and s.period = to_date('20190601','YYYYMMDD')
	union all
	select
		period,
		oebs_r12_branch_key,
		source,
		business_segment_key,
		null client_name,
		rc_key,
		null cms_order_point2address,
		null vrf,
		null rt_import,
		segment_key,
		null cms_client_inn,
		business_service_ruz_key,
		null has_region_lastmile,
		in_traf,
		null out_traf,
		null total_traf,
		null cms_order,
		null cms_service
	from edw_stg_dm_ruz.pre_fct_ip_mpls_traffic_mis s
)
select
	t.period,
	m.oebs_r12_code mrf_oebs_r12_code,
	m.oebs_r12_name mrf_oebs_r12_name,
	br.oebs_r12_branch_ruz_key,
	br.branch_code ,
	br.branch_name,
	br.oebs_r12_code rf_oebs_r12_code,
	br.oebs_r12_name rf_oebs_r12_name,
	t.source,
	bs.business_segment_key,
	bs.business_segment_short_name,
	null client_name,
	rc.rc_key,
	rc.rc_code,
	rc.rc_short_name,
	null cms_order_point2address,
	se.segment_key,
	se.segment_name,
	se.budget_segmentation,
	null cms_client_inn,
	sr.business_service_ruz_key,
	sr.business_service_ruz_parent_name,
	sr.business_service_ruz_detail_name,
	sr.business_service_ruz_sap_code,
	'нет' has_region_lastmile,
	t.in_traf,
	null out_traf,
	t.in_traf total_traf, --по согласованию с бизнесом трафик всего равен трафику входящему в МИС
	null cms_order,
	null cms_service,
	000133 src_id
from extract_mis t
	left join edw_dds.dim_oebs_r12_branch_ruz br 
	on ( 1 = 1
		and t.oebs_r12_branch_key = br.oebs_r12_branch_ruz_key 
		and br.deleted_ind='0'
		and br.exp_dttm = to_date('29991231', 'YYYYMMDD')
	)
	left join 
		(select distinct branch_code::numeric mrf_id,oebs_r12_code, oebs_r12_name 
			from edw_dds.dim_oebs_r12_branch_ruz b 
			where 1 = 1
				and b.deleted_ind = '0' 
				and to_date('20190601','YYYYMMDD') between b.eff_dttm and b.exp_dttm
				and oebs_r12_code in ('011000','012000','013000','014000','015000','016000','017000')	) m 
	on ( 1 = 1
		and case 
			when br.branch_code in ('1003','019000') then '1100' 
			else (substring(br.branch_code,1,2)||'00')::numeric 
		end  = m.mrf_id
	)
	left join edw_dds.dim_business_segment bs      
	on ( 1 = 1
		and t.business_segment_key = bs.business_segment_key          
		and bs.deleted_ind = '0'
		and t.period between bs.eff_dttm and bs.exp_dttm
		)
	left join edw_dds.dim_rc rc                    
	on ( 1 = 1
		and t.rc_key = rc.rc_key                                      
		and rc.deleted_ind = '0'
		and t.period between rc.eff_dttm and rc.exp_dttm
		)
	left join edw_dds.dim_segment se               
	on ( 1 = 1
		and t.segment_key = se.segment_key                            
		and se.deleted_ind = '0'
		and t.period between se.eff_dttm and se.exp_dttm
		)
	left join edw_dds.dim_business_service_ruz sr  
	on ( 1 = 1
		and t.business_service_ruz_key = sr.business_service_ruz_key  
		and sr.deleted_ind = '0'
		and t.period between sr.eff_dttm and sr.exp_dttm
		)
where t.period = to_date('20190601','YYYYMMDD')
	and t.in_traf>0;
commit;
analyse edw_stg_dm_ruz.tfct_traffic_ipmpls_1_prt_p000133;