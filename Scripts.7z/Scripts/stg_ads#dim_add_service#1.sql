--rev. 51466 от 06.03.2020ы

truncate table edw_stg_ads.dim_add_service_1_prt_p000001;
commit;

insert into edw_stg_ads.dim_add_service_1_prt_p000001 
(
    add_service_key
    , add_service_parent_key
    , add_serv_sc_key
    , service_key
    , branch_key
    , city_key
    , account_name
    , subs_name
    , mrf_service_key
    , mrf_add_service_name
    , start_date
    , end_date
    , dop_service_key
    , sales_channel_key
    , init_system
    , oper_id
    , oper_name
    , src_id
    , md5
)
select aas.add_service_key
    , aas.add_service_parent_key
    , coalesce(aas.add_serv_sc_key, '-1') add_serv_sc_key
    , aas.service_key
    , aas.branch_key
    , aas.city_key
    , aas.account_name
    , aas.subs_name
    , aas.mrf_service_key
    , aas.mrf_add_service_name
    , aas.start_date
    , aas.end_date
    , aas.dop_service_key             as dop_service_key
    , aas.sales_channel_key           as sales_channel_key
    , coalesce(aas.init_system, '-1') as init_system
    , coalesce(aas.oper_id, '-1')     as oper_id
    , coalesce(aas.oper_name, '-1')   as oper_name
    , aas.src_id
    , md5(((((((((((((((((((((((((((((((((coalesce(aas.add_service_key::text, ''::text) || chr(9)) || coalesce(aas.add_service_parent_key::text, ''::text)) || chr(9))
        || coalesce(aas.add_serv_sc_key::text, '-1'::text)) || chr(9)) || coalesce(aas.service_key::text, ''::text)) || chr(9)) || coalesce(aas.branch_key::text, ''::text))
        || chr(9)) || coalesce(aas.city_key::text, ''::text)) || chr(9)) || coalesce(aas.account_name::text, ''::text)) || chr(9)) || coalesce(aas.subs_name::text, ''::text))
        || chr(9)) || coalesce(aas.mrf_service_key::text, ''::text)) || chr(9)) || coalesce(aas.mrf_add_service_name::text, ''::text)) || chr(9))
        || coalesce(aas.start_date::text, ''::text)) || chr(9)) || coalesce(aas.end_date::text, ''::text)) || chr(9)) || coalesce(aas.dop_service_key ::text, ''::text))
        || chr(9)) || coalesce(aas.sales_channel_key::text, ''::text)) || chr(9)) || coalesce(aas.init_system,''::text, '-1'::text)) || chr(9))
        || coalesce(aas.oper_id::text, '-1'::text)) || chr(9)) || coalesce(aas.oper_name::text, '-1'::text)) || chr(9)) as md5
from  (
        select coalesce(reestr.add_service_key ,-1)                               as  add_service_key
            , coalesce(reestr.add_service_parent_key ,-1)                         as  add_service_parent_key
            , coalesce(reestr.add_serv_sc_key::bigint ,schan.add_serv_sc_key)     as  add_serv_sc_key
            , coalesce(reestr.service_key ,schan.service_key)                     as  service_key
            , coalesce(reestr.branch_key ,schan.branch_key)                       as  branch_key
            , coalesce(city_key ,'-1')                                            as  city_key
            , coalesce(reestr.account_name ,schan.account_name)                   as  account_name
            , coalesce(subs_name ,'-1')                                           as  subs_name
            , coalesce(reestr.mrf_service_key ,schan.mrf_service_key)             as  mrf_service_key
            , coalesce(reestr.mrf_add_service_name ,schan.mrf_add_service_name)   as  mrf_add_service_name
            , coalesce(reestr.start_date ,schan.start_date)                       as  start_date
            , coalesce(reestr.end_date ,schan.end_date)                           as  end_date
            , coalesce(reestr.dop_service_key ,schan.dop_service_key)             as  dop_service_key
            , coalesce(reestr.sales_channel_key::bigint ,schan.sales_channel_key) as  sales_channel_key
            , coalesce(reestr.init_system ,schan.init_system)                     as  init_system
            , coalesce(reestr.oper_id ,schan.oper_id)                             as  oper_id
            , coalesce(reestr.oper_name ,schan.oper_name)                         as  oper_name
            , coalesce(reestr.src_id ,schan.src_id)                               as  src_id
        from (
                select das.add_service_key
                    , das.add_service_parent_key
                    , das.service_key
                    , das.branch_key
                    , das.account_name
                    , das.subs_name
                    , das.city_key
                    , das.mrf_service_key
                    , das.mrf_add_service_name
                    , das.start_date
                    , das.end_date
                    , das.dop_service_key
                    , decode(das.add_serv_sc_key,'-1',das_p.add_serv_sc_key,das.add_serv_sc_key)             as add_serv_sc_key
                    , decode(dassc.sales_channel_key,'-1',dassc_p.sales_channel_key,dassc.sales_channel_key) as sales_channel_key
                    , coalesce(dassc.init_system, dassc_p.init_system)                                       as init_system
                    , coalesce(dassc.oper_id, dassc_p.oper_id)                                               as oper_id
                    , coalesce(dassc.oper_name, dassc_p.oper_name)                                           as oper_name
                    , das.src_id
                from  edw_dds.dim_add_service das
                left join edw_dds.dim_add_serv_sales_channel dassc on das.add_serv_sc_key::bigint=dassc.add_serv_sc_key 
                    and das.src_id = dassc.src_id 
                    and dassc.active_ind = 'Y'
                    and dassc.deleted_ind = 0
                left join edw_dds.dim_add_service das_p on das.add_service_parent_key=das_p.add_service_key 
                    and das.src_id = das_p.src_id 
                    and das_p.active_ind = 'Y'
                    and das_p.deleted_ind = 0
                left join edw_dds.dim_add_serv_sales_channel dassc_p on das_p.add_serv_sc_key::bigint=dassc_p.add_serv_sc_key 
                    and das_p.src_id = dassc_p.src_id 
                    and dassc_p.active_ind = 'Y'
                    and dassc_p.deleted_ind = 0
                where das.src_id = 000001::numeric 
                  and das.active_ind = 'Y'
                  and das.deleted_ind = 0
              ) reestr
         left join (
                      select '-1' as add_service_key
                          , service_key
                          , branch_key
                          , account_name
                          , mrf_service_key
                          , mrf_add_service_name
                          , start_date
                          , to_date('31122999','ddmmyyyy') as end_date
                          , dop_service_key
                          , add_serv_sc_key
                          , sales_channel_key
                          , init_system
                          , oper_id
                          , oper_name
                          , src_id
                      from  edw_dds.dim_add_serv_sales_channel 
                      where src_id = 000001::numeric  
                          and active_ind = 'Y'
                          and deleted_ind = 0
                    ) schan on schan.add_serv_sc_key = reestr.add_serv_sc_key::bigint
      ) aas;
commit;

insert into edw_stg_ads.dim_add_service_1_prt_p000001
(
    add_service_key
    , add_service_parent_key
    , add_serv_sc_key
    , service_key
    , branch_key
    , city_key
    , account_name
    , subs_name
    , mrf_service_key
    , mrf_add_service_name
    , start_date
    , end_date
    , dop_service_key
    , sales_channel_key
    , init_system
    , oper_id
    , oper_name
    , src_id
    , md5
)
with dass2 as 
(
    select distinct add_serv_sc_key::bigint as add_serv_sc_key
    from edw_dds.dim_add_service das
    where das.src_id = 000001::numeric
        and das.active_ind = 'Y'
        and das.deleted_ind=0
)
select 
    -1                           as add_service_key
    , -1                         as add_service_parent_key
    , schan.add_serv_sc_key      as add_serv_sc_key
    , schan.service_key          as service_key
    , schan.branch_key           as branch_key
    , '-1'                       as city_key
    , schan.account_name         as account_name
    , '-1'                       as subs_name
    , schan.mrf_service_key      as mrf_service_key
    , schan.mrf_add_service_name as mrf_add_service_name
    , schan.start_date           as start_date
    , schan.end_date             as end_date
    , schan.dop_service_key      as dop_service_key
    , schan.sales_channel_key    as sales_channel_key
    , schan.init_system          as init_system
    , schan.oper_id              as oper_id
    , schan.oper_name            as oper_name
    , schan.src_id               as src_id

    , md5((((((((((((((((((((((((((((((((('-1'::text || chr(9)) || '-1'::text) || chr(9))
        || coalesce(schan.add_serv_sc_key::text, ''::text)) || chr(9)) || coalesce(schan.service_key::text, ''::text)) || chr(9)) || coalesce(schan.branch_key::text, ''::text))
        || chr(9)) || '-1'::text) || chr(9)) || coalesce(schan.account_name::text, ''::text)) || chr(9)) || '-1'::text)
        || chr(9)) || coalesce(schan.mrf_service_key::text, ''::text)) || chr(9)) || coalesce(schan.mrf_add_service_name::text, ''::text)) || chr(9))
        || coalesce(schan.start_date::text, ''::text)) || chr(9)) || coalesce(schan.end_date::text, ''::text)) || chr(9)) || coalesce(schan.dop_service_key ::text, ''::text))
        || chr(9)) || coalesce(schan.sales_channel_key::text, ''::text)) || chr(9)) || coalesce(schan.init_system,''::text, ''::text)) || chr(9))
        || coalesce(schan.oper_id::text, ''::text)) || chr(9)) || coalesce(schan.oper_name::text, ''::text)) || chr(9)) as md5
from (
        select '-1' as add_service_key
            , service_key
            , branch_key
            , account_name
            , mrf_service_key
            , mrf_add_service_name
            , start_date
            , to_date('31122999','ddmmyyyy') as end_date
            , dop_service_key
            , add_serv_sc_key
            , sales_channel_key
            , init_system
            , oper_id
            , oper_name
            , src_id
        from edw_dds.dim_add_serv_sales_channel 
        where src_id = 000001::numeric  
            and active_ind = 'Y'
            and deleted_ind = 0
      ) schan
left join dass2 on dass2.add_serv_sc_key = schan.add_serv_sc_key
where dass2.add_serv_sc_key is null;

commit;

analyze edw_stg_ads.dim_add_service_1_prt_p000001;

