/*rev.27682 19.04.2019*/
	delete from edw_stg_mdm.put_xref_dim_business_service where src_id = 158;
insert into edw_stg_mdm.put_xref_dim_business_service
(
	source_key
	,serv_name
	,tech_name
	,src_id
)
SELECT
  stg.source_key,
  serv.def AS serv_name,
  tech.def AS tech_name,
  158      AS src_id
FROM (
       SELECT DISTINCT
         coalesce ( SERV_ID, -1 ) || '#' || coalesce ( TECH_ID, -1 ) AS source_key,
         coalesce ( SERV_ID, -1 )                                    AS serv_id,
         coalesce ( TECH_ID, -1 )                                    AS tech_id
       FROM edw_ods.T_000151_RPRTSUBSCRIBERSACTUAL
       UNION
       SELECT DISTINCT
         coalesce ( SERV_ID, -1 ) || '#' || coalesce ( TECH_ID, -1 ) AS source_key,
         coalesce ( SERV_ID, -1 )                                    AS serv_id,
         coalesce ( TECH_ID, -1 )                                    AS tech_id
       FROM edw_ods.T_000152_RPRTSUBSCRIBERSACTUAL
       UNION
       SELECT DISTINCT
         coalesce ( SERV_ID, -1 ) || '#' || coalesce ( TECH_ID, -1 ) AS source_key,
         coalesce ( SERV_ID, -1 )                                    AS serv_id,
         coalesce ( TECH_ID, -1 )                                    AS tech_id
       FROM edw_ods.T_000153_RPRTSUBSCRIBERSACTUAL
       UNION
       SELECT DISTINCT
         coalesce ( SERV_ID, -1 ) || '#' || coalesce ( TECH_ID, -1 ) AS source_key,
         coalesce ( SERV_ID, -1 )                                    AS serv_id,
         coalesce ( TECH_ID, -1 )                                    AS tech_id
       FROM edw_ods.T_000154_RPRTSUBSCRIBERSACTUAL
       UNION
       SELECT DISTINCT
         coalesce ( SERV_ID, -1 ) || '#' || coalesce ( TECH_ID, -1 ) AS source_key,
         coalesce ( SERV_ID, -1 )                                    AS serv_id,
         coalesce ( TECH_ID, -1 )                                    AS tech_id
       FROM edw_ods.T_000155_RPRTSUBSCRIBERSACTUAL
       UNION
       SELECT DISTINCT
         coalesce ( SERV_ID, -1 ) || '#' || coalesce ( TECH_ID, -1 ) AS source_key,
         coalesce ( SERV_ID, -1 )                                    AS serv_id,
         coalesce ( TECH_ID, -1 )                                    AS tech_id
       FROM edw_ods.T_000156_RPRTSUBSCRIBERSACTUAL
       UNION
       SELECT DISTINCT
         coalesce ( SERV_ID, -1 ) || '#' || coalesce ( TECH_ID, -1 ) AS source_key,
         coalesce ( SERV_ID, -1 )                                    AS serv_id,
         coalesce ( TECH_ID, -1 )                                    AS tech_id
       FROM edw_ods.T_000157_RPRTSUBSCRIBERSACTUAL
       UNION
       SELECT DISTINCT
         coalesce ( SERV_ID, -1 ) || '#' || coalesce ( TECH_ID, -1 ) AS source_key,
         coalesce ( SERV_ID, -1 )                                    AS serv_id,
         coalesce ( TECH_ID, -1 )                                    AS tech_id
       FROM edw_ods.T_000158_RPRTSUBSCRIBERSACTUAL
     ) stg
  LEFT JOIN edw_ods.t_000158_rprt_dir_services serv
    ON serv.serv_id = stg.SERV_ID
  LEFT JOIN edw_ods.t_000158_rprt_dir_tech tech
    ON tech.tech_id = stg.TECH_ID;
commit;
analyze edw_stg_mdm.put_xref_dim_business_service;
