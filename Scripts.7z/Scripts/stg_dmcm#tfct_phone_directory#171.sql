/*rev. 27839 от 23.04.2019*/
truncate table edw_stg_dmcm.tfct_phone_directory_1_prt_p000171;
insert into edw_stg_dmcm.tfct_phone_directory_1_prt_p000171 ( mrf_id
                                                                  , accn_id
                                                                  , subs_id
                                                                  , msisdn_mvno
                                                                  , is_mnp
                                                                  , is_parent
                                                                  , subs_state 
                                                                  , eff_dttm
                                                                  , exp_dttm
                                                                  , load_dttm
                                                                  , src_id
                                                                  )
select coalesce(decode(m.mrf_id,2,13,3,17,4,12,5,16,6,15,7,11,8,14), m.mrf_id) as mrf_id -- идентификатор мрф клиента
     , coalesce(m.account,'')                                                  as accn_id -- идентификатор/номер лицевого счета (нлс) по единой классификации
     , m.subs_id                                                               as subs_id -- уникальный идентификатор абонента по услуге
     , coalesce(m.msisdn,'')                                                   as msisdn_mvno -- актуальный номер телефона mvno
     , coalesce(m.is_mnp,0) -- признак перехода абонента mvno от другого оператора со своим номером (1-да, 0- нет)
     , coalesce(m.is_parent,0) -- признак родительского номера абонента mvno (1-главный, 0 - не главный)
     , coalesce(m.subs_state,0) -- статус абонента
     , to_date('20190601', 'yyyymmdd')                                     as eff_dttm -- дата начала жизни версии объекта
     , to_date('20190601', 'yyyymmdd') + interval '1 month - 1 second'     as exp_dttm -- дата окончания жизни версии объекта
     , now()                                                                   as load_dttm -- дата последнего обновления данных
     , 000171                                                            as src_id
 from  edw_ods.t_000171_v_soo_b2c_month m
 where m.tech_dt  = to_date('20190601', 'yyyymmdd')
   and m.clnt_cat = 'B2C'
   and m.subs_id is not null;
analyze edw_stg_dmcm.tfct_phone_directory_1_prt_p000171;
