/*rev.41870 от 07.11.2019*/
	set optimizer = on ;
truncate table edw_stg_dds.t_000004_tfct_account_delivery_state ;
insert into edw_stg_dds.t_000004_tfct_account_delivery_state 
(
 account_key,
 snap_dt,
 delivery_type_key,
 manager_fio,
 src_id,
 deleted_ind
)
select  
    src_id||'#'||trunc(user_id) account_key
    , date_trunc('month', to_date('20190630', 'YYYYMMDD')) snap_dt
	, case 
		when sum(case when id_obj = 1999900 and content_str =  'Отказ'                                           then 1 else 0 end)   > 0 then 0 
		when sum(case when id_obj = 1999900 and content_str =  'ЭДО Тензор'                                      then 1 else 0 end)   > 0 then 18
		when sum(case when id_obj = 1999900 and content_str =  'ЭДО Контур'                                      then 1 else 0 end)   > 0 then 19
		when sum(case when id_obj = 1999900 and content_str =  'НСЭД'                               	           then 1 else 0 end)   > 0 then 28
		when sum(case when id_obj = 1999900 and content_str in ('ЭДО Корус Консалтинг СНГ','ЭДО')                then 1 else 0 end)   > 0 then 17
		when sum(case when id_obj = 1999900 and content_str =  'бумажный' or lower(content_str) like 'расширен%' then 1 else 0 end)   > 0 then 6
		when sum(case when id_obj = 1999900 and content_str =  'email' or content_str like '%@%'                 then 1 else 0 end)   > 0 then 3
		when sum(case when id_obj = 1999900 and content_str =  'ЛК'                                              then 1 else 0 end)   > 0 then 2
		when sum(case when id_obj = 1999900 and content_str =  'Офис '                                           then 1 else 0 end)   > 0 then 1
		else  6
	 end delivery_type_key
    , max(case when id_obj = 1999949 then content_str end) fio
    , src_id
    , deleted_ind
 from 
 (
	select 
	u.user_id,
	u.src_id,
	first_value(nc.content_str) OVER (PARTITION BY u.user_id, nc.id_obj 
		ORDER BY nc.date_begin desc,nc.action_id desc
		ROWS BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING) content_str,
	nc.id_obj,
	coalesce(nullif(nt.deleted_ind, 0), nullif(u.deleted_ind, 0), nc.deleted_ind) as deleted_ind
	from edw_ods.t_000004_n_titul_treaty nt
		inner join edw_ods.t_000004_t_users u
		on ( 1 = 1 
			and nt.id_host=u.user_id 
			and to_date('20190630', 'YYYYMMDD') between coalesce(u.date_begin,to_date('19000101', 'YYYYMMDD')) and coalesce(u.date_end,to_date('29991231', 'YYYYMMDD'))
			and cast(to_date('20190630', 'YYYYMMDD') as timestamp(0)) between u.eff_dttm and u.exp_dttm
		)
		inner join edw_ods.t_000004_n_content_treaty nc
		on ( 1 = 1 
			and nc.id_treaty=nt.id_treaty 
			and nc.id_obj in (1999900,1999949)
			and to_date('20190630', 'YYYYMMDD') >= nc.date_begin
			and cast(to_date('20190630', 'YYYYMMDD') as timestamp(0)) between nc.eff_dttm and nc.exp_dttm
		)
	where 1 = 1  
		and to_date('20190630', 'YYYYMMDD') between coalesce(nt.date_begin,to_date('19000101', 'YYYYMMDD')) and coalesce(nt.date_end,to_date('29991231', 'YYYYMMDD'))
		and cast(to_date('20190630', 'YYYYMMDD') as timestamp(0)) between nt.eff_dttm and nt.exp_dttm
) u
where deleted_ind = '0'
 group by account_key, src_id, deleted_ind;

analyze edw_stg_dds.t_000004_tfct_account_delivery_state;

 