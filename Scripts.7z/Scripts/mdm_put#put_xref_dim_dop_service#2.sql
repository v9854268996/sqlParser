/*rev.47398 от 24.01.2020*/

delete from edw_stg_mdm.put_xref_dim_dop_service
where src_id = 000002;

insert into edw_stg_mdm.put_xref_dim_dop_service
(
    source_key,
    mrf_add_service_name,
    src_id
)
select distinct
    svc_id,
    name,
    src_id
from edw_ods.t_000002_t_svc_ref
where src_id = 000002
    and exp_dttm = '2999-12-31 00:00:00';

analyze edw_stg_mdm.put_xref_dim_dop_service;
