/*rev.21245 от 30.01.2019*/
set optimizer = on ;
truncate table edw_stg_dm_feb.tfct_edo_statistic_1_prt_p000065;
insert into edw_stg_dm_feb.tfct_edo_statistic_1_prt_p000065
(
	id
	,branch_mrf_key
	,branch_key
	,period
	,src_id
	,base_src_id
	,segment_key
	,type_doc_key
	,cnt
)
with
calendar as (
	select 
		c.month_end_date as report_dt
	from edw_dds.dim_calendar c
	where 1 = 1
		and c.month_end_date between to_date('20190601', 'YYYYMMDD') and   to_date('20190630', 'YYYYMMDD')
		and c.month_end_date = c.date_key
	)
SELECT 
	u.id
	,u.branch_mrf_key
	,u.branch_key
	,u.period
	,u.src_id
	,u.base_src_id
	,u.segment_key
	,u.type_doc_key
	,u.cnt
FROM (select
	to_char(d.period,'yyyymm')||d.branch_key||d.segment_key||d.base_src_id||'#'||dt.type_doc as id
	,d.BRANCH_MRF_KEY
	,d.BRANCH_KEY
	,d.PERIOD
	,000065::integer as SRC_ID
	,d.BASE_SRC_ID
	,d.SEGMENT_KEY
	,m.TYPE_DOC_KEY
	,count(*) CNT
from calendar c
inner join edw_stg_dm_feb.tfct_edo_statistic_detail_1_prt_p000065 d 
	on ( 1 = 1
		and date_trunc('month', c.report_dt) = d.PERIOD
	)
inner join edw_dm_feb.DIM_DELIVERY_DOC_TYPES_MAPPING m 
	on ( 1 = 1
		and d.delivery_type_key = m.delivery_type_key
		and m.exp_dttm = cast(to_date('29991231', 'YYYYMMDD') as timestamp(0))
	)
inner join edw_dm_feb.DIM_DELIVERY_DOC_TYPES dt 
	on ( 1 = 1
		and m.TYPE_DOC_KEY = dt.TYPE_DOC_KEY
		and dt.exp_dttm = cast(to_date('29991231', 'YYYYMMDD') as timestamp(0))
	)
group by 
	to_char(d.period,'yyyymm')||d.branch_key||d.segment_key||d.base_src_id||'#'||dt.type_doc
	,d.BRANCH_MRF_KEY
	,d.BRANCH_KEY
	,d.BASE_SRC_ID
	,d.PERIOD
	,d.SRC_ID
	,d.SEGMENT_KEY
	,m.TYPE_DOC_KEY) u ;
commit; 
analyse edw_stg_dm_feb.tfct_edo_statistic_1_prt_p000065;