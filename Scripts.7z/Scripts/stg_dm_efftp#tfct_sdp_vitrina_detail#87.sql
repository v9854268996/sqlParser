/*rev.30055 от 03.06.2019*/

set optimizer = on;

truncate edw_stg_dm_efftp.tfct_sdp_vitrina_detail_1_prt_p000087;

insert into edw_stg_dm_efftp.tfct_sdp_vitrina_detail_1_prt_p000087
	(
	period,
	mrf,
	rf,
	account,
	san,
	abn_id,
	subs_id,
	name_pack_asr,
	name_pack_standart,
	--amount_pack,
	flag_type_pack,
	flag_pack_begin,
	flag_pack_end,
	dt,
	--load_dttm,
	src_id,
	--eff_dttm,
	--exp_dttm
	id_asr_pack
	)
with svcs_tp as --svcs_tp
(
select sr.svc_id,
		sr.cod::int8,
         case
           when sr.cod in ('80410') then '1. Популярный (Архив 2015)' -- -80612
           when sr.cod in ('80606') then '2. Популярный Малый (Архив 2015)'
           when sr.cod in ('80411') then '3. Познавательный (Архив 2015)'
           when sr.cod in ('80412') then '4. Детский (Архив 2015)'
           when sr.cod in ('80413') then '5. Музыкальный (Архив 2015)'
           when sr.cod in ('80414') then '6. Спортивный (Архив 2015)'
           when sr.cod in ('80415') then '7. Кино (Архив 2015)'
           when sr.cod in ('804171', '804172', '804173') then '8. HD'
           when sr.cod in ('804181', '804182', '804183', '99262') then '9. Взрослый'
           when sr.cod in ('804191', '804192', '804193', '99261') then '10. Наш Футбол'
           when sr.cod in ('806981', '806982', '806983') then '11. Наш Футбол (малый пакет)'
           when sr.cod in ('80416') then '12. Максимальный (Архив 2015)'
           when sr.cod in ('804241', '804242', '804243') then '13. Обычный'
           when sr.cod in ('5502321', '5502322', '5502323', '5503811', '5503812', '5503813', '20449') then '14. Предоставление услуги IPTV на ПК'
           when sr.cod in ('80444') then '15. Мой Ростелеком I'
           when sr.cod in ('80445') then '16. Мой Ростелеком II'
           when sr.cod in ('805870', '805872', '805873', '806971') then '17. Viasat Премиум HD (Архив 2016)'
           when sr.cod in ('82364', '82365', '82366') then '18. Попробуй Идеальный HD'         
           when sr.cod in ('804251', '804252', '804253') then '19. HD+'
           when sr.cod in ('82231') then '20. ТВОЙ СТАРТОВЫЙ'
           when sr.cod in ('82235') then '21. ТВОЙ СТАРТОВЫЙ - неосновная территория'
           when sr.cod in ('82232') then '22. ТВОЙ ОПТИМАЛЬНЫЙ'
           when sr.cod in ('82233') then '23. ТВОЙ ПРОДВИНУТЫЙ'
           when sr.cod in ('82234') then '24. ТВОЙ МАКСИМАЛЬНЫЙ'
           when sr.cod in ('82236', '82237', '82238', '99259') then '25. ТВОЕ КИНО'
           when sr.cod in ('82245', '82246', '82247') then '26. ТВОЙ ИДЕАЛЬНЫЙ HD (Архив 2016)'
           when sr.cod in ('82242', '82243', '82244', '99265') then '27. Amedia Premium (Архив 2018)' --++
           when sr.cod in ('82239', '82240', '82241', '99264') then '28. Матч! Футбол'
           when sr.cod in ('82361', '82362', '82363', '99260') then '29. Твой Идеальный HD'
           when sr.cod in ('82433', '82434', '82435', '99266') then '30. Amedia+Viasat Premium HD'
           when sr.cod in ('99272', '99273', '99274', '99261') then '31. Viasat Премиум HD new2016 (пакет за 299р.)'
           when sr.cod in ('99345', '99346', '99347', '99348') then '32. Шант Премиум HD'
           when sr.cod in ('806741', '806742', '806743') then '33. Базовый Деловой (Архив 2015)'
           when sr.cod in ('96632') then '34. Базовый Деловой (Архив 2017)'          
           when sr.cod in ('806761', '806762', '806763') then '35. HD Деловой (Архив 2015)'
           when sr.cod in ('96634') then '36. HD Деловой (Архив 2017)'         
           when sr.cod in ('99491', '99492', '99493', '99471', '99472', '99473', '99508', '99509', '99510') then '37. Взрослый Деловой'
           when sr.cod in ('806771', '806772', '806773') then '38. Взрослый Деловой (Архив 2015)'
           when sr.cod in ('96635') then '39. Взрослый Деловой (Архив 2017)'          
           when sr.cod in ('806751', '806752', '806753') then '40. Максимальный Деловой (Архив 2015)'
           when sr.cod in ('96633') then '41. Максимальный Деловой (Архив 2017)'         
           when sr.cod in ('806781', '806782', '806783') then '42. Публичный (Архив 2015)'
           when sr.cod in ('96636') then '43. Публичный (Архив 2017)'         
           when sr.cod in ('821161', '821162', '821163') then '44. КХЛ HD'
           when sr.cod in ('821171', '821172', '821173') then '45. Публичный Лайт (Архив 2015)'
           when sr.cod in ('96637') then '46. Публичный Лайт (Архив 2017)'         
           when sr.cod in ('99479') then '47. Стандарт'
           when sr.cod in ('821181', '821182', '821183') then '48. Стандарт (Архив 2015)'
           when sr.cod in ('96638') then '49. Стандарт (Архив 2017)'         
           when sr.cod in ('99480') then '50. Люкс'
           when sr.cod in ('821191', '821192', '821193') then '51. Люкс (Архив 2015)'
           when sr.cod in ('96639') then '52. Люкс (Архив 2017)'         
           when sr.cod in ('99481') then '53. Престиж'
           when sr.cod in ('821201', '821202', '821203') then '54. Престиж (Архив 2015)'
           when sr.cod in ('96640') then '55. Престиж (Архив 2017)'         
           when sr.cod in ('99486') then '56. Стандарт суточный'
           when sr.cod in ('99064') then '57. Стандарт (Архив 2017)  суточный'         
           when sr.cod in ('99487') then '58. Люкс суточный' 
           when sr.cod in ('99065') then '59. Люкс (Архив 2017) суточный '         
           when sr.cod in ('99488') then '60. Престиж суточный'
           when sr.cod in ('99066') then '61. Престиж (Архив 2017) суточный '         
           when sr.cod in ('82427') then '62. HD суточный'
           when sr.cod in ('82430') then '63. КХЛ суточный'
           when sr.cod in ('99055') then '64. Взрослый суточный'
           when sr.cod in ('96620', '96621', '96622', '96623', '96624', '96625', '96623', '96624',
                           '96625', '96626', '96627', '96628', '96629', '96630', '96631', '96642') then '65. Взрослый для Гостиниц'
           when sr.cod in ('96608', '96609', '96610', '96611', '96612', '96613', '96614',
                           '96615', '96616', '96617', '96618', '96619', '96641') then '66. HD для гостиниц'
           when sr.cod in ('99268') then '67. ОТТ-Деловой'
           when sr.cod in ('99269') then '68. ОТТ-Публичный'
           when sr.cod in ('99270') then '69. ОТТ-Гостиница'
           when sr.cod in ('99474') then '70. ОТТ-Гостиница (суточный)'         
           when sr.cod in ('805851', '805852', '805853') then '71. Подписка Детский клуб'
           when sr.cod in ('805861', '805862', '805863') then '72. Подписка PictureBox'
           when sr.cod in ('80550281', '80550282', '80550283') then '74. Подписка Волшебный мир Disney'
           when sr.cod in ('80550271', '80550272', '80550273') then '74. Подписка Amedia Premium'
           when sr.cod in ('82251', '82252', '82253') then '75. Абонемент "PictureBox NEW"'
           when sr.cod in ('82254', '82255', '82256') then '76. Абонемент "Детский мир NEW"'
           when sr.cod in ('80387', '80388', '80389') then '77. Абонемент "Женский мир"'
           when sr.cod in ('82325', '82326', '82327') then '78. Подписка «Сделано в России»'
           when sr.cod in ('55457', '55458', '55459') then '79. Подписка «ABC Studios Лучшие сериалы»'
           when sr.cod in ('82436', '82437', '82438') then '80. Подписка "Amediateka Home of HBO" (Архив 2018) (Категория 50)'         
           when sr.cod in ('99619', '99620', '99621', '99623') then '81. Подписка «Amediateka Home of HBO»' --++   ++++!!!!         
           when sr.cod in ('99624', '99625', '99626') then '82. Amedia Premium (Архив 2018) (Категория 83.1)' --++   ++++!!!!        
           when sr.cod in ('82352', '99271') then '83. Твой Стартовый 2.0'
           when sr.cod in ('80498') then '84. HD 2.0 (Архив 2016)'
           when sr.cod in ('80499') then '85. Взрослый 2.0'
           when sr.cod in ('80508') then '86. ТВОЙ ОПТИМАЛЬНЫЙ 2.0'
           when sr.cod in ('80509') then '87. ТВОЙ ПРОДВИНУТЫЙ 2.0'
           when sr.cod in ('80510') then '88. ТВОЙ МАКСИМАЛЬНЫЙ 2.0'
           when sr.cod in ('80511') then '89. ТВОЙ ИДЕАЛЬНЫЙ HD 2.0'
           when sr.cod in ('80512') then '90. ТВОЕ КИНО 2.0'
           when sr.cod in ('80513') then '91. Amedia Premium (Архив 2018) OTT' --++
           when sr.cod in ('80514') then '92. Viasat Премиум HD'
           when sr.cod in ('80515') then '93. Amedia+Viasat Premium HD 2.0'
           when sr.cod in ('99124') then '94. Лёгкий 2.0'
           when sr.cod in ('96643') then '95. ТВОЙ ПРЕМЬЕРНЫЙ'
           when sr.cod in ('82334') then '96. Минимальный'
           when sr.cod in ('82335') then '97. Минимальный неосновные'
           when sr.cod in ('96732', '98360', '99350') then '98. Легкий основные' --++
           when sr.cod in ('96733', '98359', '99349') then '99. Легкий неосновные' --++
           when sr.cod in ('99332') then '100. Пакет "Viasat Premium HD", акция "Киномарафон"'
           when sr.cod in ('99315') then '101. Пакет "AmediaPremium", акция "Больше сериалов"'
           when sr.cod in ('99312') then '102. Подписка "AMEDIATEKA", акция "Больше сериалов"'         
           when sr.cod in ('99475') then '103. Базовый'
           when sr.cod in ('99476') then '104. Просто бизнес'
           when sr.cod in ('99477') then '105. Базовый для детских учреждений'
           when sr.cod in ('99478') then '106. Базовый для баров, ресторанов и сферы услугс'
           when sr.cod in ('99381', '99382', '99383', '99467', '99468', '99469', '99505', '99506', '99507') then '107. "СУПЕР МАТЧ!" (непубличный показ)'
           when sr.cod in ('99378', '99379', '99380', '99465', '99466', '99467', '99502', '99503', '99504') then '108. "МАТЧ!" (непубличный показ)'
           when sr.cod in ('99375', '99376', '99377', '99462', '99463', '99464', '99499', '99500', '99501') then '109. "ФУТБОЛ" (непубличный показ) '
           when sr.cod in ('99459', '99460', '99461', '99496', '99497', '99498') then '110. "Телеканал "КХЛ HD" (непубличный показ)'
           when sr.cod in ('99420', '99421', '99422') then '111. "СУПЕР МАТЧ!" (публичный показ)'
           when sr.cod in ('99417', '99418', '99419') then '112. "МАТЧ!" (публичный показ)'
           when sr.cod in ('99414', '99415', '99416') then '113. "ФУТБОЛ" (публичный показ)'
           when sr.cod in ('99411', '99412', '99413') then '114. "Телеканал "КХЛ HD" (публичный показ)'         
           when sr.cod in ('99522') then '115. "Лёгкий +", акция "Год кино"' -- 20171225 Garz CR0003043720
           when sr.cod in ('99526', '99527', '99528') then '116. "Год кино в подарок", акция "Год кино"'
           when sr.cod in ('99529', '99530', '99531') then '117. "Год кино", акция "Год кино"'
           when sr.cod in ('99356', '99357', '99358') then '118. "Весь Футбол", акция "Весь футбол"' -- 20171225 Garz CR0003043720
         --------------------------------------------------
           when sr.cod in ('99632','99633', '99634', '99635', '99627', '99628', '99629', '99630') then '119. Пакет "Год кино 2018", акция "Год кино 2018"'
           when sr.cod in ('99659') then '120. Пакет "Лёгкий", акция "Киномания"' -- +++
           when sr.cod in ('99647', '99648', '99649', '99650', '99651', '99652') then '121. Пакет "Киномания мини", акция "Киномания"' -- +++
           when sr.cod in ('99653', '99654', '99655', '99656', '99657', '99658') then '122. Пакет "Киномания", акция "Киномания"' -- +++         
           else
            NULL         
         end tp_name,
         sr.isconst
    from edw_ods.T_000087_T_SVC_REF sr
   where sr.COD in ('80410',  '80606',   '80411',   '80412',   '80413',   '80414',   '80415',    '804171',
                    '804172', '804173',  '804181',  '804182',  '804183',  '99262',   '804191',   '804192',
                    '804193', '99261',   '806981',  '806982',  '806983',  '80416',   '804241',   '804242',
                    '804243', '5502321', '5502322', '5502323', '5503811', '5503812', '5503813',  '20449',
                    '80444',  '80445',   '805870',  '805872',  '805873',  '806971',  '82364',    '82365',
                    '82366',  '804251',  '804252',  '804253',  '82231',   '82235',   '82232',    '82233',
                    '82234',  '82236',   '82237',   '82238',   '99259',   '82245',   '82246',    '82247',
                    '82242',  '82243',   '82244',   '99265',   '82239',   '82240',   '82241',    '99264',
                    '82361',  '82362',   '82363',   '99260',   '82433',   '82434',   '82435',    '99266',
                    '99272',  '99273',   '99274',   '99261',   '99345',   '99346',   '99347',    '99348',
                    '806741', '806742',  '806743',  '96632',   '806761',  '806762',  '806763',   '96634',
                    '99491',  '99492',   '99493',   '99471',   '99472',   '99473',   '99508',    '99509',
                    '99510',  '806771',  '806772',  '806773',  '96635',   '806751',  '806752',   '806753',
                    '96633',  '806781',  '806782',  '806783',  '96636',   '806791',  '806792',   '806793',
                    '821161', '821162',  '821163',  '821171',  '821172',  '821173',  '96637',    '99479',
                    '821181', '821182',  '821183',  '96638',   '99480',   '821191',  '821192',   '821193',
                    '96639',  '99481',   '821201',  '821202',  '821203',  '96640',   '99486',    '99064',
                    '99487',  '99065',   '99488',   '99066',   '82427',   '82430',   '99055',    '96620',
                    '96621',  '96622',   '96623',   '96624',   '96625',   '96623',   '96624',    '96625',
                    '96626',  '96627',   '96628',   '96629',   '96630',   '96631',   '96642',    '96608',
                    '96609',  '96610',   '96611',   '96612',   '96613',   '96614',   '96615',    '96616',
                    '96617',  '96618',   '96619',   '96641',   '99268',   '99269',   '99270',    '99474',
                    '805851', '805852',  '805853',  '805861',  '805862',  '805863',  '80550281', '80550282',
                    '80550283','99507',  '80550272','82251',   '82252',   '82253',   '82254',    '99378',
                    '82255',  '82256',   '80387',   '80388',   '80389',   '82325',   '82326',    '82327',
                    '55457',  '55458',   '55459',   '82436',   '82437',   '82438',   '82352',    '99271',
                    '80498',  '80499',   '80508',   '80509',   '80510',   '80511',   '80512',    '80513',
                    '80514',  '80515',   '99124',   '96643',   '82334',   '82335',   '96732',    '98360',
                    '96733',  '98359',   '99332',   '99315',   '99312',   '99475',   '99476',    '99477',
                    '99478',  '99381',   '99382',   '99383',   '99467',   '99468',   '99469',    '99505',
                    '99506',  '80550271','80550273','99379',   '99380',   '99465',   '99466',    '99467',
                    '99502',  '99503',   '99504',   '99375',   '99376',   '99377',   '99462',    '99463',
                    '99464',  '99499',   '99500',   '99501',   '99459',   '99460',   '99461',    '99496',
                    '99497',  '99498',   '99420',   '99421',   '99422',   '99417',   '99418',    '99419',
                    '99414',  '99415',   '99416',   '99411',   '99412',   '99413',   '99522',    '99526',
                    '99527',  '99528',   '99529',   '99530',   '99531',   '99356',   '99357',    '99358',
                    '99619',  '99620',   '99621',   '99623',   '99624',   '99625',   '99626',    '80513',
                    '99350',  '99349',   '99632',   '99633',   '99634',   '99635',   '99627',    '99628',
                    '99629',  '99630',   '99659',   '99647',   '99648',   '99649',   '99650',    '99651',
                    '99652',  '99653',   '99654',   '99655',   '99656',   '99657',   '99658' 
                    )        
     and sr.COD not in ('821481',  '821482', '821483',  '821471',
                        '821472',  '821473', '8058711', '8058712',
                        '8058713', '82248',  '82249',   '82250',
                        '82440',   '82441',  '82442',   '82351', '99267')
),
/*
curdept as
(
   with g0 as
 (SELECT 0              lvl,
         a.dept_id,
         a.name,
         null           dm1,
         null           dm2,
         null           dm3,
         null           dm4,
         a.dept_manages
    from edw_ods.T_000087_T_GTS a
   where dept_id = 1),
g1 as
 (SELECT 1               lvl,
         a.dept_id,
         a.name,
         g0.dept_manages dm1,
         null            dm2,
         a.dept_id       dm3,
         null            dm4,
         a.dept_manages
    from edw_ods.T_000087_T_GTS a, g0
   where a.dept_manages = g0.dept_id),
g2 as
 (SELECT 2               lvl,
         a.dept_id,
         a.name,
         g0.dept_manages dm1,
         g1.dept_manages dm2,
         a.dept_manages  dm3,
         null            dm4,
         a.dept_id       dept_manages
    from edw_ods.T_000087_T_GTS a, g1, g0
   where a.dept_manages = g1.dept_id
     and g1.dept_manages = g0.dept_id),
g3 as
 (SELECT 3               lvl,
         a.dept_id,
         a.name,
         g0.dept_manages dm1,
         g1.dept_manages dm2,
         g2.dm3          dm3,
         null            dm4,
         a.dept_manages
    from edw_ods.T_000087_T_GTS a, g2, g1, g0
   where a.dept_manages = g2.dept_id
     and g2.dm3 = g1.dept_id
     and g1.dept_manages = g0.dept_id)
select lvl, dept_id, name NAME_DEPT, dm3 GETDEPTGRTU2, dept_manages GETDEPTGRTU3
  from g1
union
select lvl, dept_id, name NAME_DEPT, dm3 GETDEPTGRTU2, dept_manages GETDEPTGRTU3
  from g2
union
select lvl, dept_id, name NAME_DEPT, dm3 GETDEPTGRTU2, dept_manages GETDEPTGRTU3 from g3 order by 5, 4, 2
),
*/
reestr as (
select distinct
       u.dept_id, -- cd.root, 
       svc.tp_name "name",
	   svc.cod,
       decode(svc.isconst, 'Y', 1, 'N', 0, null) ocn,
       1 kol_usl,
       s.service_id,
       s.serv_first_id,
       ss.serv_first_id ss_serv_first_id,
       s.main_serv_first_id,
       s.date_begin,
       s.date_end,
       u.account,
       s.src_id,
--       case
--         when s.date_begin <= date_trunc('month', to_date('20190601', 'YYYYMMDD')) then u.account
--         else null
--       end kol_on_begin,
--       case 
--         when coalesce(s.date_end, to_date('299912', 'yyyymm')) >= date_trunc('month', to_date('20190601', 'YYYYMMDD')) + interval '1 month' then u.account
--         else null
--       end kol_on_end,
       case
         when  v1.sv_status_id is null
               and s2.service_id is null 
               and s.date_begin < date_trunc('month', to_date('20190601', 'YYYYMMDD'))
         then u.account
         else null
       end not_in_block_begin,       
--       case
--         when s2.service_id is null
--              and s.date_begin < date_trunc('month', to_date('20190601', 'YYYYMMDD'))
--         then u.account
--         else null
--       end not_in_dobr_block_begin,
       
       case
         when v2.sv_status_id is null
              and ss2.service_id is null 
              and coalesce(s.date_end, to_date('299912', 'yyyymm')) >= date_trunc('month', to_date('20190601', 'YYYYMMDD')) + interval '1 month - 1 day'
         then u.account
         else null
       end not_in_block_end--,
--       case
--         when ss2.service_id is null
--              and coalesce(s.date_end, to_date('299912', 'yyyymm')) >= date_trunc('month', to_date('20190601', 'YYYYMMDD')) + interval '1 month - 1 day'
--         then u.account
--         else null
--       end not_in_dobr_block_end
       
  from edw_ods.T_000087_T_SERVICES s
  
  join svcs_tp svc
    on s.svc_id = svc.svc_id
       
  join edw_ods.T_000087_T_USERS u
    on s.user_id = u.user_id	
	
  join edw_ods.T_000087_T_USER_TYPE_REF utr
    on u.user_type_id = utr.user_type_id
    and utr.coef = 1
   
  --left join curdept cd on  u.dept_id = cd.dept_id
       
  join edw_ods.T_000087_T_SERVICES ss
      on s.main_serv_first_id = ss.main_serv_first_id
      
  left join 
  (
  select *
                                from edw_ods.T_000087_T_SERVICES s2
                               where s2.svc_id in (99069, 99070, 99071, 99072, 99073, 99074, 99075,
                                                   99076, 99077, 99084, 99085, 99086, 99087, 99088,
                                                   99089, 99090, 99091, 99092, 99184, 99185, 99186,
                                                   99078, 99079, 99080, 99081, 99082, 99083)
                                 and date_trunc('month', to_date('20190601', 'YYYYMMDD')) + interval'-1 day'
                                   between s2.date_begin and coalesce(s2.date_end, to_date('299912', 'yyyymm'))
                              
  ) s2 on s2.user_id = s.user_id
  
  left join 
  (select *
                               from edw_ods.T_000087_T_SERVICES s2
                              where s2.svc_id in (99069, 99070, 99071, 99072, 99073, 99074, 99075,
                                                  99076, 99077, 99084, 99085, 99086, 99087, 99088,
                                                  99089, 99090, 99091, 99092, 99184, 99185, 99186,
                                                  99078, 99079, 99080, 99081, 99082, 99083)
                                and date_trunc('month', to_date('20190601', 'YYYYMMDD')) + interval '1 month - 1 day'
                                  between s2.date_begin and coalesce(s2.date_end, to_date('299912', 'yyyymm'))
    ) ss2 on ss2.user_id = s.user_id
    
   left join (SELECT sv_status_id, serv_first_id
               FROM edw_ods.T_000087_T_SV_STATUS v
              WHERE date_trunc('month', to_date('20190601', 'YYYYMMDD')) between v.date_begin and coalesce(v.date_end, to_date('299912', 'yyyymm'))
   ) v1 on v1.serv_first_id = s.serv_first_id
   
   left join (SELECT sv_status_id, serv_first_id
           FROM edw_ods.T_000087_T_SV_STATUS v
          WHERE date_trunc('month', to_date('20190601', 'YYYYMMDD')) + interval '1 month - 1 day'
              between v.date_begin and coalesce(v.date_end, to_date('299912', 'yyyymm'))
          ) v2 on v2.serv_first_id = s.serv_first_id          
   
   where s.date_begin <= date_trunc('month', to_date('20190601', 'YYYYMMDD')) + interval '1 month - 1 day'
     and coalesce(s.date_end, to_date('299912', 'yyyymm')) >= date_trunc('month', to_date('20190601', 'YYYYMMDD'))      

)

select
distinct
tp.p1_period,
tp.p2_mrf_id,
tp.p3_rf_id,
tp.account,
null san,
tp.abn_id,
tp.subs_id, 
s.name name_pack_asr,
s.name name_pack_standart,
--s.kol_usl amount_pack,
s.ocn flag_type_pack,
--case when coalesce(kol_on_begin, not_in_block_begin, not_in_dobr_block_begin) is not null then 1 else 0 end flag_pack_begin,
--case when coalesce(kol_on_end,   not_in_block_end,   not_in_dobr_block_end)   is not null then 1 else 0 end flag_pack_end,
case when not_in_block_begin is not null then 1 else 0 end flag_pack_begin,
case when not_in_block_end is not null then 1 else 0 end flag_pack_end,
date_trunc('month', to_date('20190601', 'YYYYMMDD'))::timestamp,
--default,
s.src_id,
--default,
--default
s.cod 

from reestr s --limit 10

 join edw_ods.t_000156_efftp_oo_eff_tp tp
    on 1 = 1
   --and tp.p1_period = to_number(to_char(date_trunc('month', to_date('20190601', 'YYYYMMDD')), 'YYYYMM'), '999999')
   and tp.tech_dt = (date_trunc('month', to_date('20190601', 'YYYYMMDD')))::date
   --
   and tp.p2_mrf_id = 16
   and tp.subs_id = s.ss_serv_first_id::varchar
   and tp.account = s.account   
   and tp.serv_id = 3
;

commit
;

analyse edw_stg_dm_efftp.tfct_sdp_vitrina_detail_1_prt_p000087
;
	
