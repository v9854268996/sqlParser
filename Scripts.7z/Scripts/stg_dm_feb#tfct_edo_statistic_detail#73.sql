/*rev.34044 от 24.07.2019*/
set optimizer = on ;
truncate table edw_stg_dm_feb.tfct_edo_statistic_detail_1_prt_p000073;
insert into edw_stg_dm_feb.tfct_edo_statistic_detail_1_prt_p000073
(
	id,
	branch_mrf_key,
	branch_key,
	period,
	src_id,
	segment_key,
	partner_full_name,
	partner_inn,
	account_key,
	delivery_type_key,
	fio,
	amount,
	base_src_id,
	account_name,
	contract_cval,
	load_dttm
)
with
calendar as (
	select 
		c.month_end_date as report_dt
	from edw_dds.dim_calendar c
	where 1 = 1
		and c.month_end_date between to_date('20190601', 'YYYYMMDD') and   to_date('20190630', 'YYYYMMDD')
		and c.month_end_date = c.date_key
	),
segm as
  (
	select 
		s.segment_key
		, c.report_dt
	from calendar as c
	inner join edw_dds.dim_segment s 
		on (1 = 1
			and c.report_dt between s.eff_dttm and s.exp_dttm )
	inner join edw_dds.dim_segment p
		on ( 1 = 1 
			and s.parent_segment_key=p.segment_key
			and p.deleted_ind = 0
			and c.report_dt between p.eff_dttm and p.exp_dttm )
	inner join edw_dds.dim_segment g
		on ( 1 = 1 
			and p.parent_segment_key=g.segment_key
			and g.parent_segment_key=21000
			and g.deleted_ind = 0
			and c.report_dt between g.eff_dttm and g.exp_dttm )
	where 1 = 1 
		and s.deleted_ind = 0
	union all 
	select 
		s.segment_key 
		, c.report_dt
	from calendar as c
	inner join edw_dds.dim_segment s 
		on (1 = 1
			and c.report_dt between s.eff_dttm and s.exp_dttm )
	inner join edw_dds.dim_segment p
		on ( 1 = 1
			and s.parent_segment_key=p.segment_key 
			and p.parent_segment_key=21000 
			and p.deleted_ind = 0
			and c.report_dt between p.eff_dttm and p.exp_dttm)
	where 1 = 1
		and s.deleted_ind = 0
	union all
	select 
		s.segment_key 
		, c.report_dt
	from calendar as c
	inner join edw_dds.dim_segment s 
		on (1 = 1
			and c.report_dt between s.eff_dttm and s.exp_dttm )
	where 1 = 1
		and s.parent_segment_key=21000
		and s.deleted_ind = 0
	union all
	select 
		s.segment_key 
		, c.report_dt
	from calendar as c
	inner join edw_dds.dim_segment s 
		on (1 = 1
			and c.report_dt between s.eff_dttm and s.exp_dttm )
	where 1 = 1
		and s.segment_key=21000
		and s.deleted_ind = 0
  ),
   partner as (
  select 
	c.report_dt
	, dim_partner.partner_key 
	, dim_partner.segment_key
	, dim_partner.partner_full_name
	, dim_partner.tax_number_cval
  from calendar as c
  inner join edw_dds.dim_partner_1_prt_p000073 dim_partner  
		on ( 1 = 1
           and cast(c.report_dt as timestamp(0)) between dim_partner.eff_dttm and dim_partner.exp_dttm 
		   and dim_partner.deleted_ind = 0
		   )
   inner join segm 
		on ( 1 = 1 
			and dim_partner.segment_key = segm.segment_key
			and segm.report_dt = c.report_dt ) 
  ),
  total_charge as 
  (
	select c.report_dt, bs.billing_id, bs.charge_period_start_dttm, bs.account_key, round(sum(bs.charge_rub),2) amount
	from calendar c 
	inner join edw_dds.tfct_total_charge_1_prt_p000073 bs
		on ( 1 = 1
			and date_trunc('month', c.report_dt) = bs.charge_period_start_dttm
			and bs.deleted_ind = 0
			and bs.charge_period_start_dttm between cast(to_date('20190601', 'YYYYMMDD') as timestamp(0)) and  cast(to_date('20190630', 'YYYYMMDD') as timestamp(0))
			)
	group by c.report_dt, bs.billing_id, bs.charge_period_start_dttm, bs.account_key
  )
select 
	u.id
 , u.branch_mrf_key
 , u.branch_key
 , u.period
 , u.src_id
 , u.segment_key
 , u.partner_full_name
 , u.partner_inn
 , u.account_key
 , u.delivery_type_key
 , u.fio
 , u.amount
 , u.base_src_id
 , u.account_name
 , string_agg(u.contract_cval,', ') as contract_cval
 , CURRENT_TIMESTAMP as load_dttm
from (select 
to_char(bs.charge_period_start_dttm,'yyyymm')||dim_branch.branch_key||dim_partner.segment_key||'73'||'#'||dim_account.account_key||'#'||coalesce(delivstate.delivery_type_key,-1) id
 , dim_branch.parent_branch_key branch_mrf_key
 , dim_branch.branch_key
 , 0 as code_mrf
 , bs.charge_period_start_dttm period
 , bs.billing_id
 , 000073::integer src_id
 , dim_partner.segment_key
, coalesce( dim_partner.partner_full_name, 'N/A') as partner_full_name 
 , coalesce(dim_partner.tax_number_cval, 'N/A') as partner_inn
 , dim_account.account_key
 , coalesce(delivstate.delivery_type_key,-1) as delivery_type_key
 , coalesce(delivstate.manager_fio,'N/A') fio
 , round(sum(bs.amount),2) amount
 , dim_account.account_name
 , 000073 as base_src_id
 , dim_contract.contract_cval as contract_cval
  from total_charge bs
  inner join edw_dds.dim_account_1_prt_p000073 dim_account
		on ( 1 = 1
           and dim_account.account_key = bs.account_key 
           and bs.charge_period_start_dttm between dim_account.eff_dttm and dim_account.exp_dttm 
           and dim_account.duty_num_key = 0  
           and dim_account.center_num_key = 0 
		   and dim_account.deleted_ind = 0 
		   )
   left join edw_dds.tfct_account_delivery_state_1_prt_p000073 delivstate 
		on ( 1 = 1 
			and delivstate.snap_dt between  to_date('20190601', 'YYYYMMDD') and  to_date('20190630', 'YYYYMMDD')
			and delivstate.account_key = dim_account.account_key  
			and delivstate.snap_dt = date_trunc('month', bs.report_dt)
			and delivstate.delivery_type_key not in (-1,0) 
			and delivstate.deleted_ind = 0
			)
   inner join partner dim_partner 
		on ( 1 = 1
           and dim_account.partner_key = dim_partner.partner_key 
		   and bs.report_dt = dim_partner.report_dt )       
   inner join edw_dds.dim_branch dim_branch 
		on ( 1 = 1
           and dim_branch.branch_key = dim_account.branch_key  
           and dim_branch.deleted_ind=0 
           and dim_branch.exp_dttm = cast(to_date('29991231', 'YYYYMMDD') as timestamp(0)))
   left join edw_dds.dim_contract dim_contract on
		1=1
		and dim_account.account_key = dim_contract.account_key
		and dim_account.src_id = dim_contract.src_id
		and dim_contract.deleted_ind = 0
		and to_date('20190630', 'YYYYMMDD') + INTERVAL '1 Day - 1 second' between dim_contract.eff_dttm and dim_contract.exp_dttm		   
group by  dim_branch.branch_key
   , dim_branch.parent_branch_key
   , dim_partner.segment_key
   , dim_partner.partner_full_name
   , dim_account.account_key
   , delivstate.manager_fio
   , period
   , bs.billing_id
   , id
   , delivstate.delivery_type_key 
   , dim_partner.tax_number_cval
   , dim_account.src_id
   , dim_account.account_name
   , bs.charge_period_start_dttm
   , dim_contract.contract_cval
having round(sum(bs.amount),2) > 0 ) u
group by u.id
 , u.branch_mrf_key
 , u.branch_key
 , u.period
 , u.src_id
 , u.segment_key
 , u.partner_full_name
 , u.partner_inn
 , u.account_key
 , u.delivery_type_key
 , u.fio
 , u.amount
 , u.base_src_id
 , u.account_name;
commit; 
analyse edw_stg_dm_feb.tfct_edo_statistic_detail_1_prt_p000073;